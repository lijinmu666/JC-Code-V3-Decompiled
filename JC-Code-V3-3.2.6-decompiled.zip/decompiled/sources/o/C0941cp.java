package o;

import java.util.List;
import org.conscrypt.BuildConfig;

/* renamed from: o.cp, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0941cp extends AbstractC1010dy implements Ly {
    private static final C0941cp zbb;
    private int zbd;
    private int zbe;
    private String zbf = BuildConfig.FLAVOR;
    private InterfaceC1491ly zbg = AbstractC1010dy.wJVbdd();

    static {
        C0941cp c0941cp = new C0941cp();
        zbb = c0941cp;
        AbstractC1010dy.YoKzxo(C0941cp.class, c0941cp);
    }

    public static C0941cp CqaNbM(byte[] bArr, Kx kx) {
        return (C0941cp) AbstractC1010dy.vI(zbb, bArr, kx);
    }

    @Override // o.AbstractC1010dy
    public final Object IEE(int i, Object obj, Object obj2) {
        int i2 = i - 1;
        if (i2 == 0) {
            return (byte) 1;
        }
        if (i2 == 2) {
            return AbstractC1010dy.ETF(zbb, "\u0001\u0003\u0000\u0001\u0001\u0003\u0003\u0000\u0001\u0000\u0001င\u0000\u0002ဈ\u0001\u0003\u001b", new Object[]{"zbd", "zbe", "zbf", "zbg", C0176Af.class});
        }
        if (i2 == 3) {
            return new C0941cp();
        }
        AbstractC0738Yo abstractC0738Yo = null;
        if (i2 == 4) {
            return new C0820ap(abstractC0738Yo);
        }
        if (i2 != 5) {
            return null;
        }
        return zbb;
    }

    public final List KLMXS() {
        return this.zbg;
    }

    public final int OjSQV() {
        return this.zbe;
    }

    public final String xrEuO() {
        return this.zbf;
    }
}
