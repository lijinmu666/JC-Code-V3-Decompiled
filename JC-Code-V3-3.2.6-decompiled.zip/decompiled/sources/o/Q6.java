package o;

import android.widget.ListView;

/* loaded from: classes.dex */
public interface Q6 {
    boolean Dt();

    ListView KLFTb();

    void ZfxDd();

    void mjFkc();
}
