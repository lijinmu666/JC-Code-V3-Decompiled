package o;

import android.database.sqlite.SQLiteDatabase;
import o.C0959d6;

/* renamed from: o.a6, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final /* synthetic */ class C0777a6 implements C0959d6.AZxh {
    public final String mjFkc;

    public C0777a6(String str) {
        this.mjFkc = str;
    }

    public static C0959d6.AZxh mjFkc(String str) {
        return new C0777a6(str);
    }

    @Override // o.C0959d6.AZxh
    public Object apply(Object obj) {
        return C0959d6.xrEuO(this.mjFkc, (SQLiteDatabase) obj);
    }
}
