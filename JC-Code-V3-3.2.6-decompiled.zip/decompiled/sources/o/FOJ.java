package o;

import java.util.ArrayList;
import o.gjvQ;

/* loaded from: classes.dex */
public class FOJ {
    public gjvQ AZxh;
    public int Dt;
    public float ETF = 0.0f;
    public boolean IEE;
    public gjvQ JHa;
    public gjvQ KLFTb;
    public int MiMN;
    public boolean Pq;
    public boolean Ucbh;
    public int VA;
    public int YoKzxo;
    public gjvQ ZfxDd;
    public boolean diqgf;
    public boolean eyqo;
    public boolean fehf;
    public ArrayList lgHUyS;
    public gjvQ mjFkc;
    public int qGY;
    public int qdMbNW;
    public boolean rkYL;
    public gjvQ wA;
    public gjvQ xJ;

    public FOJ(gjvQ gjvq, int i, boolean z) {
        this.mjFkc = gjvq;
        this.qGY = i;
        this.fehf = z;
    }

    public static boolean wA(gjvQ gjvq, int i) {
        int i2;
        return gjvq.NPj() != 8 && gjvq.rWxwaT[i] == gjvQ.AZxh.MATCH_CONSTRAINT && ((i2 = gjvq.YoKzxo[i]) == 0 || i2 == 3);
    }

    public final void AZxh() {
        int i = this.qGY * 2;
        gjvQ gjvq = this.mjFkc;
        this.rkYL = true;
        gjvQ gjvq2 = gjvq;
        boolean z = false;
        while (!z) {
            this.qdMbNW++;
            gjvQ[] gjvqArr = gjvq.Qr;
            int i2 = this.qGY;
            gjvQ gjvq3 = null;
            gjvqArr[i2] = null;
            gjvq.SOS[i2] = null;
            if (gjvq.NPj() != 8) {
                this.VA++;
                gjvQ.AZxh aZxhPq = gjvq.Pq(this.qGY);
                gjvQ.AZxh aZxh = gjvQ.AZxh.MATCH_CONSTRAINT;
                if (aZxhPq != aZxh) {
                    this.MiMN += gjvq.VocHEe(this.qGY);
                }
                int iWA = this.MiMN + gjvq.KLMXS[i].wA();
                this.MiMN = iWA;
                int i3 = i + 1;
                this.MiMN = iWA + gjvq.KLMXS[i3].wA();
                int iWA2 = this.YoKzxo + gjvq.KLMXS[i].wA();
                this.YoKzxo = iWA2;
                this.YoKzxo = iWA2 + gjvq.KLMXS[i3].wA();
                if (this.AZxh == null) {
                    this.AZxh = gjvq;
                }
                this.ZfxDd = gjvq;
                gjvQ.AZxh[] aZxhArr = gjvq.rWxwaT;
                int i4 = this.qGY;
                if (aZxhArr[i4] == aZxh) {
                    int i5 = gjvq.YoKzxo[i4];
                    if (i5 == 0 || i5 == 3 || i5 == 2) {
                        this.Dt++;
                        float f = gjvq.SmIWf[i4];
                        if (f > 0.0f) {
                            this.ETF += f;
                        }
                        if (wA(gjvq, i4)) {
                            if (f < 0.0f) {
                                this.IEE = true;
                            } else {
                                this.Pq = true;
                            }
                            if (this.lgHUyS == null) {
                                this.lgHUyS = new ArrayList();
                            }
                            this.lgHUyS.add(gjvq);
                        }
                        if (this.JHa == null) {
                            this.JHa = gjvq;
                        }
                        gjvQ gjvq4 = this.xJ;
                        if (gjvq4 != null) {
                            gjvq4.SOS[this.qGY] = gjvq;
                        }
                        this.xJ = gjvq;
                    }
                    if (this.qGY == 0) {
                        if (gjvq.VA != 0 || gjvq.rkYL != 0 || gjvq.qGY != 0) {
                            this.rkYL = false;
                        }
                    } else if (gjvq.MiMN != 0 || gjvq.IEE != 0 || gjvq.Pq != 0) {
                        this.rkYL = false;
                    }
                    if (gjvq.oCFDzJ != 0.0f) {
                        this.rkYL = false;
                        this.eyqo = true;
                    }
                }
            }
            if (gjvq2 != gjvq) {
                gjvq2.Qr[this.qGY] = gjvq;
            }
            qtZIjO qtzijo = gjvq.KLMXS[i + 1].ZfxDd;
            if (qtzijo != null) {
                gjvQ gjvq5 = qtzijo.AZxh;
                qtZIjO qtzijo2 = gjvq5.KLMXS[i].ZfxDd;
                if (qtzijo2 != null && qtzijo2.AZxh == gjvq) {
                    gjvq3 = gjvq5;
                }
            }
            if (gjvq3 == null) {
                gjvq3 = gjvq;
                z = true;
            }
            gjvq2 = gjvq;
            gjvq = gjvq3;
        }
        gjvQ gjvq6 = this.AZxh;
        if (gjvq6 != null) {
            this.MiMN -= gjvq6.KLMXS[i].wA();
        }
        gjvQ gjvq7 = this.ZfxDd;
        if (gjvq7 != null) {
            this.MiMN -= gjvq7.KLMXS[i + 1].wA();
        }
        this.wA = gjvq;
        if (this.qGY == 0 && this.fehf) {
            this.KLFTb = gjvq;
        } else {
            this.KLFTb = this.mjFkc;
        }
        this.diqgf = this.Pq && this.IEE;
    }

    public void mjFkc() {
        if (!this.Ucbh) {
            AZxh();
        }
        this.Ucbh = true;
    }
}
