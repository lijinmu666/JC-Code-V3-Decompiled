package o;

/* renamed from: o.m4, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC1498m4 {
    public static int AZxh = 2131099798;
    public static int mjFkc = 2131099797;
    public static int wA = 2131099799;
}
