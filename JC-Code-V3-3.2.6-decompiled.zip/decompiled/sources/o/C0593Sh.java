package o;

/* renamed from: o.Sh, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0593Sh extends AbstractC1010dy implements Ly {
    private static final C0593Sh zbb;
    private int zbd;
    private C1895si zbe;
    private C1895si zbf;

    static {
        C0593Sh c0593Sh = new C0593Sh();
        zbb = c0593Sh;
        AbstractC1010dy.YoKzxo(C0593Sh.class, c0593Sh);
    }

    @Override // o.AbstractC1010dy
    public final Object IEE(int i, Object obj, Object obj2) {
        int i2 = i - 1;
        if (i2 == 0) {
            return (byte) 1;
        }
        if (i2 == 2) {
            return AbstractC1010dy.ETF(zbb, "\u0000\u0002\u0000\u0001\u0001\u0002\u0002\u0000\u0000\u0000\u0001ဉ\u0000\u0002ဉ\u0001", new Object[]{"zbd", "zbe", "zbf"});
        }
        if (i2 == 3) {
            return new C0593Sh();
        }
        AbstractC0363Ih abstractC0363Ih = null;
        if (i2 == 4) {
            return new C0570Rh(abstractC0363Ih);
        }
        if (i2 != 5) {
            return null;
        }
        return zbb;
    }
}
