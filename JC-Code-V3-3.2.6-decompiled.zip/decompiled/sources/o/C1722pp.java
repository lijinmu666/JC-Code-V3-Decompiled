package o;

/* renamed from: o.pp, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C1722pp extends Vx implements Ly {
    public /* synthetic */ C1722pp(AbstractC1422kp abstractC1422kp) {
        super(C1841rp.zbb);
    }
}
