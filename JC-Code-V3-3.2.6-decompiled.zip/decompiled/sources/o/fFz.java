package o;

/* loaded from: classes.dex */
public final class fFz {
    public final StackTraceElement AZxh() {
        return UMza.AZxh(new Exception(), AbstractC0380Jb.class.getSimpleName());
    }

    public final StackTraceElement mjFkc() {
        return UMza.AZxh(new Exception(), AbstractC0357Ib.class.getSimpleName());
    }
}
