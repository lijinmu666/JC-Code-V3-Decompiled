package o;

import android.content.Context;
import android.content.pm.PackageManager;
import android.text.TextUtils;
import java.util.Locale;
import org.conscrypt.BuildConfig;

/* loaded from: classes.dex */
public abstract class XyP {
    public static final C0831b mjFkc = new C0831b("CommonUtils", BuildConfig.FLAVOR);

    public static String AZxh(Locale locale) {
        if (AbstractC2158x3.ZfxDd()) {
            return locale.toLanguageTag();
        }
        StringBuilder sb = new StringBuilder(locale.getLanguage());
        if (!TextUtils.isEmpty(locale.getCountry())) {
            sb.append("-");
            sb.append(locale.getCountry());
        }
        if (!TextUtils.isEmpty(locale.getVariant())) {
            sb.append("-");
            sb.append(locale.getVariant());
        }
        return sb.toString();
    }

    public static String mjFkc(Context context) {
        try {
            return String.valueOf(context.getPackageManager().getPackageInfo(context.getPackageName(), 0).versionCode);
        } catch (PackageManager.NameNotFoundException e) {
            mjFkc.wA("CommonUtils", "Exception thrown when trying to get app version ".concat(e.toString()));
            return BuildConfig.FLAVOR;
        }
    }
}
