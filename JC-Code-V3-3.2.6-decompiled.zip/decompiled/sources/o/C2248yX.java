package o;

import java.util.ArrayList;
import java.util.Iterator;
import o.Y0;
import o.Z6;
import org.conscrypt.BuildConfig;

/* renamed from: o.yX, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public class C2248yX implements Y0.mjFkc {
    public mjFkc KLFTb;
    public Z6 mjFkc = null;
    public float AZxh = 0.0f;
    public boolean wA = false;
    public ArrayList ZfxDd = new ArrayList();
    public boolean JHa = false;

    /* renamed from: o.yX$mjFkc */
    public interface mjFkc {
        void AZxh(Z6 z6, float f, boolean z);

        float Dt(Z6 z6, boolean z);

        void ETF();

        float JHa(C2248yX c2248yX, boolean z);

        boolean KLFTb(Z6 z6);

        int ZfxDd();

        void clear();

        Z6 lgHUyS(int i);

        float mjFkc(int i);

        void qdMbNW(float f);

        void wA(Z6 z6, float f);

        float xJ(Z6 z6);
    }

    public C2248yX() {
    }

    @Override // o.Y0.mjFkc
    public Z6 AZxh(Y0 y0, boolean[] zArr) {
        return Gd(zArr, null);
    }

    public void BAnRFn(Y0 y0, Z6 z6, boolean z) {
        if (z6.xJ) {
            this.AZxh += z6.JHa * this.KLFTb.xJ(z6);
            this.KLFTb.Dt(z6, z);
            if (z) {
                z6.wA(this);
            }
        }
    }

    public C2248yX Dt(Z6 z6, Z6 z62, float f) {
        this.KLFTb.wA(z6, -1.0f);
        this.KLFTb.wA(z62, f);
        return this;
    }

    public C2248yX ETF(Z6 z6, Z6 z62, Z6 z63, Z6 z64, float f) {
        this.KLFTb.wA(z6, -1.0f);
        this.KLFTb.wA(z62, 1.0f);
        this.KLFTb.wA(z63, f);
        this.KLFTb.wA(z64, -f);
        return this;
    }

    public final Z6 Gd(boolean[] zArr, Z6 z6) {
        Z6.mjFkc mjfkc;
        int iZfxDd = this.KLFTb.ZfxDd();
        Z6 z62 = null;
        float f = 0.0f;
        for (int i = 0; i < iZfxDd; i++) {
            float fMjFkc = this.KLFTb.mjFkc(i);
            if (fMjFkc < 0.0f) {
                Z6 z6LgHUyS = this.KLFTb.lgHUyS(i);
                if ((zArr == null || !zArr[z6LgHUyS.wA]) && z6LgHUyS != z6 && (((mjfkc = z6LgHUyS.Dt) == Z6.mjFkc.SLACK || mjfkc == Z6.mjFkc.ERROR) && fMjFkc < f)) {
                    f = fMjFkc;
                    z62 = z6LgHUyS;
                }
            }
        }
        return z62;
    }

    public void HGpJ(Z6 z6) {
        Z6 z62 = this.mjFkc;
        if (z62 != null) {
            this.KLFTb.wA(z62, -1.0f);
            this.mjFkc = null;
        }
        float fDt = this.KLFTb.Dt(z6, true) * (-1.0f);
        this.mjFkc = z6;
        if (fDt == 1.0f) {
            return;
        }
        this.AZxh /= fDt;
        this.KLFTb.qdMbNW(fDt);
    }

    public void IEE() {
        float f = this.AZxh;
        if (f < 0.0f) {
            this.AZxh = f * (-1.0f);
            this.KLFTb.ETF();
        }
    }

    public boolean JHa(Y0 y0) {
        boolean z;
        Z6 z6XJ = xJ(y0);
        if (z6XJ == null) {
            z = true;
        } else {
            HGpJ(z6XJ);
            z = false;
        }
        if (this.KLFTb.ZfxDd() == 0) {
            this.JHa = true;
        }
        return z;
    }

    public C2248yX KLFTb(Z6 z6, int i) {
        this.KLFTb.wA(z6, i);
        return this;
    }

    public C2248yX MiMN(Z6 z6, int i) {
        if (i < 0) {
            this.AZxh = i * (-1);
            this.KLFTb.wA(z6, 1.0f);
        } else {
            this.AZxh = i;
            this.KLFTb.wA(z6, -1.0f);
        }
        return this;
    }

    public boolean Pq() {
        Z6 z6 = this.mjFkc;
        return z6 != null && (z6.Dt == Z6.mjFkc.UNRESTRICTED || this.AZxh >= 0.0f);
    }

    public final boolean Ucbh(Z6 z6, Y0 y0) {
        return z6.MiMN <= 1;
    }

    public C2248yX VA(float f, float f2, float f3, Z6 z6, Z6 z62, Z6 z63, Z6 z64) {
        this.AZxh = 0.0f;
        if (f2 == 0.0f || f == f3) {
            this.KLFTb.wA(z6, 1.0f);
            this.KLFTb.wA(z62, -1.0f);
            this.KLFTb.wA(z64, 1.0f);
            this.KLFTb.wA(z63, -1.0f);
        } else if (f == 0.0f) {
            this.KLFTb.wA(z6, 1.0f);
            this.KLFTb.wA(z62, -1.0f);
        } else if (f3 == 0.0f) {
            this.KLFTb.wA(z63, 1.0f);
            this.KLFTb.wA(z64, -1.0f);
        } else {
            float f4 = (f / f2) / (f3 / f2);
            this.KLFTb.wA(z6, 1.0f);
            this.KLFTb.wA(z62, -1.0f);
            this.KLFTb.wA(z64, f4);
            this.KLFTb.wA(z63, -f4);
        }
        return this;
    }

    /* JADX WARN: Removed duplicated region for block: B:29:0x00c0  */
    /* JADX WARN: Removed duplicated region for block: B:30:0x00d0  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public String VocHEe() {
        boolean z;
        String str = (this.mjFkc == null ? BuildConfig.FLAVOR + "0" : BuildConfig.FLAVOR + this.mjFkc) + " = ";
        if (this.AZxh != 0.0f) {
            str = str + this.AZxh;
            z = true;
        } else {
            z = false;
        }
        int iZfxDd = this.KLFTb.ZfxDd();
        for (int i = 0; i < iZfxDd; i++) {
            Z6 z6LgHUyS = this.KLFTb.lgHUyS(i);
            if (z6LgHUyS != null) {
                float fMjFkc = this.KLFTb.mjFkc(i);
                if (fMjFkc != 0.0f) {
                    String string = z6LgHUyS.toString();
                    if (!z) {
                        if (fMjFkc < 0.0f) {
                            str = str + "- ";
                            fMjFkc *= -1.0f;
                        }
                        str = fMjFkc == 1.0f ? str + string : str + fMjFkc + " " + string;
                        z = true;
                    } else if (fMjFkc > 0.0f) {
                        str = str + " + ";
                        if (fMjFkc == 1.0f) {
                        }
                        z = true;
                    } else {
                        str = str + " - ";
                        fMjFkc *= -1.0f;
                        if (fMjFkc == 1.0f) {
                        }
                        z = true;
                    }
                }
            }
        }
        if (z) {
            return str;
        }
        return str + "0.0";
    }

    public C2248yX YoKzxo(Z6 z6, Z6 z62, int i) {
        boolean z = false;
        if (i != 0) {
            if (i < 0) {
                i *= -1;
                z = true;
            }
            this.AZxh = i;
        }
        if (z) {
            this.KLFTb.wA(z6, 1.0f);
            this.KLFTb.wA(z62, -1.0f);
        } else {
            this.KLFTb.wA(z6, -1.0f);
            this.KLFTb.wA(z62, 1.0f);
        }
        return this;
    }

    public C2248yX ZfxDd(Y0 y0, int i) {
        this.KLFTb.wA(y0.rkYL(i, "ep"), 1.0f);
        this.KLFTb.wA(y0.rkYL(i, "em"), -1.0f);
        return this;
    }

    @Override // o.Y0.mjFkc
    public void clear() {
        this.KLFTb.clear();
        this.mjFkc = null;
        this.AZxh = 0.0f;
    }

    public boolean diqgf(Z6 z6) {
        return this.KLFTb.KLFTb(z6);
    }

    public boolean eyqo() {
        return this.mjFkc == null && this.AZxh == 0.0f && this.KLFTb.ZfxDd() == 0;
    }

    public C2248yX fehf(Z6 z6, Z6 z62, Z6 z63, Z6 z64, float f) {
        this.KLFTb.wA(z63, 0.5f);
        this.KLFTb.wA(z64, 0.5f);
        this.KLFTb.wA(z6, -0.5f);
        this.KLFTb.wA(z62, -0.5f);
        this.AZxh = -f;
        return this;
    }

    @Override // o.Y0.mjFkc
    public Z6 getKey() {
        return this.mjFkc;
    }

    public Z6 huTpC(Z6 z6) {
        return Gd(null, z6);
    }

    public void lB(C2248yX c2248yX, boolean z) {
        this.AZxh += c2248yX.AZxh * this.KLFTb.JHa(c2248yX, z);
        if (z) {
            c2248yX.mjFkc.wA(this);
        }
    }

    public C2248yX lgHUyS(Z6 z6, Z6 z62, int i, float f, Z6 z63, Z6 z64, int i2) {
        if (z62 == z63) {
            this.KLFTb.wA(z6, 1.0f);
            this.KLFTb.wA(z64, 1.0f);
            this.KLFTb.wA(z62, -2.0f);
            return this;
        }
        if (f == 0.5f) {
            this.KLFTb.wA(z6, 1.0f);
            this.KLFTb.wA(z62, -1.0f);
            this.KLFTb.wA(z63, -1.0f);
            this.KLFTb.wA(z64, 1.0f);
            if (i > 0 || i2 > 0) {
                this.AZxh = (-i) + i2;
            }
        } else if (f <= 0.0f) {
            this.KLFTb.wA(z6, -1.0f);
            this.KLFTb.wA(z62, 1.0f);
            this.AZxh = i;
        } else if (f >= 1.0f) {
            this.KLFTb.wA(z64, -1.0f);
            this.KLFTb.wA(z63, 1.0f);
            this.AZxh = -i2;
        } else {
            float f2 = 1.0f - f;
            this.KLFTb.wA(z6, f2 * 1.0f);
            this.KLFTb.wA(z62, f2 * (-1.0f));
            this.KLFTb.wA(z63, (-1.0f) * f);
            this.KLFTb.wA(z64, 1.0f * f);
            if (i > 0 || i2 > 0) {
                this.AZxh = ((-i) * f2) + (i2 * f);
            }
        }
        return this;
    }

    @Override // o.Y0.mjFkc
    public void mjFkc(Z6 z6) {
        int i = z6.KLFTb;
        float f = 1.0f;
        if (i != 1) {
            if (i == 2) {
                f = 1000.0f;
            } else if (i == 3) {
                f = 1000000.0f;
            } else if (i == 4) {
                f = 1.0E9f;
            } else if (i == 5) {
                f = 1.0E12f;
            }
        }
        this.KLFTb.wA(z6, f);
    }

    public C2248yX qGY(Z6 z6, Z6 z62, Z6 z63, int i) {
        boolean z = false;
        if (i != 0) {
            if (i < 0) {
                i *= -1;
                z = true;
            }
            this.AZxh = i;
        }
        if (z) {
            this.KLFTb.wA(z6, 1.0f);
            this.KLFTb.wA(z62, -1.0f);
            this.KLFTb.wA(z63, 1.0f);
        } else {
            this.KLFTb.wA(z6, -1.0f);
            this.KLFTb.wA(z62, 1.0f);
            this.KLFTb.wA(z63, -1.0f);
        }
        return this;
    }

    public C2248yX qdMbNW(Z6 z6, int i) {
        this.mjFkc = z6;
        float f = i;
        z6.JHa = f;
        this.AZxh = f;
        this.JHa = true;
        return this;
    }

    public C2248yX rkYL(Z6 z6, Z6 z62, Z6 z63, int i) {
        boolean z = false;
        if (i != 0) {
            if (i < 0) {
                i *= -1;
                z = true;
            }
            this.AZxh = i;
        }
        if (z) {
            this.KLFTb.wA(z6, 1.0f);
            this.KLFTb.wA(z62, -1.0f);
            this.KLFTb.wA(z63, -1.0f);
        } else {
            this.KLFTb.wA(z6, -1.0f);
            this.KLFTb.wA(z62, 1.0f);
            this.KLFTb.wA(z63, 1.0f);
        }
        return this;
    }

    public String toString() {
        return VocHEe();
    }

    public void vI() {
        this.mjFkc = null;
        this.KLFTb.clear();
        this.AZxh = 0.0f;
        this.JHa = false;
    }

    @Override // o.Y0.mjFkc
    public void wA(Y0.mjFkc mjfkc) {
        if (mjfkc instanceof C2248yX) {
            C2248yX c2248yX = (C2248yX) mjfkc;
            this.mjFkc = null;
            this.KLFTb.clear();
            for (int i = 0; i < c2248yX.KLFTb.ZfxDd(); i++) {
                this.KLFTb.AZxh(c2248yX.KLFTb.lgHUyS(i), c2248yX.KLFTb.mjFkc(i), true);
            }
        }
    }

    public void wJVbdd(Y0 y0) {
        if (y0.JHa.length == 0) {
            return;
        }
        boolean z = false;
        while (!z) {
            int iZfxDd = this.KLFTb.ZfxDd();
            for (int i = 0; i < iZfxDd; i++) {
                Z6 z6LgHUyS = this.KLFTb.lgHUyS(i);
                if (z6LgHUyS.ZfxDd != -1 || z6LgHUyS.xJ) {
                    this.ZfxDd.add(z6LgHUyS);
                }
            }
            if (this.ZfxDd.size() > 0) {
                Iterator it = this.ZfxDd.iterator();
                while (it.hasNext()) {
                    Z6 z6 = (Z6) it.next();
                    if (z6.xJ) {
                        BAnRFn(y0, z6, true);
                    } else {
                        lB(y0.JHa[z6.ZfxDd], true);
                    }
                }
                this.ZfxDd.clear();
            } else {
                z = true;
            }
        }
    }

    public Z6 xJ(Y0 y0) {
        int iZfxDd = this.KLFTb.ZfxDd();
        Z6 z6 = null;
        float f = 0.0f;
        float f2 = 0.0f;
        boolean z = false;
        boolean z2 = false;
        Z6 z62 = null;
        for (int i = 0; i < iZfxDd; i++) {
            float fMjFkc = this.KLFTb.mjFkc(i);
            Z6 z6LgHUyS = this.KLFTb.lgHUyS(i);
            if (z6LgHUyS.Dt == Z6.mjFkc.UNRESTRICTED) {
                if (z6 == null || f > fMjFkc) {
                    boolean zUcbh = Ucbh(z6LgHUyS, y0);
                    z = zUcbh;
                    f = fMjFkc;
                    z6 = z6LgHUyS;
                } else if (!z && Ucbh(z6LgHUyS, y0)) {
                    f = fMjFkc;
                    z6 = z6LgHUyS;
                    z = true;
                }
            } else if (z6 == null && fMjFkc < 0.0f) {
                if (z62 == null || f2 > fMjFkc) {
                    boolean zUcbh2 = Ucbh(z6LgHUyS, y0);
                    z2 = zUcbh2;
                    f2 = fMjFkc;
                    z62 = z6LgHUyS;
                } else if (!z2 && Ucbh(z6LgHUyS, y0)) {
                    f2 = fMjFkc;
                    z62 = z6LgHUyS;
                    z2 = true;
                }
            }
        }
        return z6 != null ? z6 : z62;
    }

    public C2248yX(RWyiuY rWyiuY) {
        this.KLFTb = new kism(this, rWyiuY);
    }
}
