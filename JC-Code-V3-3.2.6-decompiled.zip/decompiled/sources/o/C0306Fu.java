package o;

import android.os.Parcel;
import android.os.Parcelable;

/* renamed from: o.Fu, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0306Fu implements Parcelable.Creator {
    @Override // android.os.Parcelable.Creator
    public final /* bridge */ /* synthetic */ Object createFromParcel(Parcel parcel) {
        int iIEE = AbstractC1319j6.IEE(parcel);
        long jRkYL = 0;
        int iYoKzxo = 0;
        int iYoKzxo2 = 0;
        int iYoKzxo3 = 0;
        int iYoKzxo4 = 0;
        while (parcel.dataPosition() < iIEE) {
            int iVA = AbstractC1319j6.VA(parcel);
            int iQdMbNW = AbstractC1319j6.qdMbNW(iVA);
            if (iQdMbNW == 1) {
                iYoKzxo = AbstractC1319j6.YoKzxo(parcel, iVA);
            } else if (iQdMbNW == 2) {
                iYoKzxo2 = AbstractC1319j6.YoKzxo(parcel, iVA);
            } else if (iQdMbNW == 3) {
                iYoKzxo3 = AbstractC1319j6.YoKzxo(parcel, iVA);
            } else if (iQdMbNW == 4) {
                iYoKzxo4 = AbstractC1319j6.YoKzxo(parcel, iVA);
            } else if (iQdMbNW != 5) {
                AbstractC1319j6.fehf(parcel, iVA);
            } else {
                jRkYL = AbstractC1319j6.rkYL(parcel, iVA);
            }
        }
        AbstractC1319j6.lgHUyS(parcel, iIEE);
        return new C0283Eu(iYoKzxo, iYoKzxo2, iYoKzxo3, iYoKzxo4, jRkYL);
    }

    @Override // android.os.Parcelable.Creator
    public final /* synthetic */ Object[] newArray(int i) {
        return new C0283Eu[i];
    }
}
