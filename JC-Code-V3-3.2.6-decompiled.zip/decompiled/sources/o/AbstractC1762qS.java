package o;

/* renamed from: o.qS, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC1762qS {
}
