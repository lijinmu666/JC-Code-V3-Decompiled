package o;

import java.util.List;

/* loaded from: classes.dex */
public interface ArO {
    List mjFkc();
}
