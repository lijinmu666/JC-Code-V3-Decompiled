package o;

/* renamed from: o.No, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0484No extends Vx implements Ly {
    public /* synthetic */ C0484No(AbstractC0439Lo abstractC0439Lo) {
        super(C0530Po.zbb);
    }
}
