package o;

/* renamed from: o.ws, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C2146ws extends AbstractC2086vs {
    public static final AbstractC2206xs AZxh = new C2146ws();

    public C2146ws() {
        super("CharMatcher.none()");
    }
}
