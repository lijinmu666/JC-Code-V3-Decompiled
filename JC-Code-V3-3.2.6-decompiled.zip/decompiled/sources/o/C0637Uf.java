package o;

/* renamed from: o.Uf, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0637Uf extends Vx implements Ly {
    public /* synthetic */ C0637Uf(AbstractC0521Pf abstractC0521Pf) {
        super(C0706Xf.zbb);
    }
}
