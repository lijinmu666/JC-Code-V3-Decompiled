package o;

/* renamed from: o.Mg, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0453Mg extends AbstractC1010dy implements Ly {
    private static final C0453Mg zbb;
    private InterfaceC1491ly zbd = AbstractC1010dy.wJVbdd();

    static {
        C0453Mg c0453Mg = new C0453Mg();
        zbb = c0453Mg;
        AbstractC1010dy.YoKzxo(C0453Mg.class, c0453Mg);
    }

    @Override // o.AbstractC1010dy
    public final Object IEE(int i, Object obj, Object obj2) {
        int i2 = i - 1;
        if (i2 == 0) {
            return (byte) 1;
        }
        if (i2 == 2) {
            return AbstractC1010dy.ETF(zbb, "\u0001\u0001\u0000\u0000\u0001\u0001\u0001\u0000\u0001\u0000\u0001\u001b", new Object[]{"zbd", C0408Kg.class});
        }
        if (i2 == 3) {
            return new C0453Mg();
        }
        AbstractC0362Ig abstractC0362Ig = null;
        if (i2 == 4) {
            return new C0431Lg(abstractC0362Ig);
        }
        if (i2 != 5) {
            return null;
        }
        return zbb;
    }
}
