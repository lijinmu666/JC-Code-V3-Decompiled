package o;

/* renamed from: o.jk, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C1357jk extends Vx implements Ly {
    public /* synthetic */ C1357jk(AbstractC1297ik abstractC1297ik) {
        super(C1417kk.zbb);
    }
}
