package o;

import java.util.ArrayList;
import java.util.Collection;

/* renamed from: o.wC, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C2107wC extends AbstractC2288zC {
    public C2107wC() {
        super(new C1687pD(12));
    }

    public static C2107wC qGY() {
        return new C2107wC();
    }

    @Override // o.AbstractC1566nC
    public final /* bridge */ /* synthetic */ Collection xJ() {
        return new ArrayList(3);
    }
}
