package o;

import android.os.DeadObjectException;
import android.os.RemoteException;
import com.google.android.gms.common.api.Status;

/* renamed from: o.Jc, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC0381Jc extends AbstractC2190xc {
    public final D7 AZxh;

    public AbstractC0381Jc(int i, D7 d7) {
        super(i);
        this.AZxh = d7;
    }

    @Override // o.AbstractC1410kd
    public final void AZxh(Exception exc) {
        this.AZxh.ZfxDd(exc);
    }

    public abstract void lgHUyS(C1409kc c1409kc);

    @Override // o.AbstractC1410kd
    public final void mjFkc(Status status) {
        this.AZxh.ZfxDd(new WrLQs(status));
    }

    @Override // o.AbstractC1410kd
    public final void wA(C1409kc c1409kc) throws DeadObjectException {
        try {
            lgHUyS(c1409kc);
        } catch (DeadObjectException e) {
            mjFkc(AbstractC1410kd.KLFTb(e));
            throw e;
        } catch (RemoteException e2) {
            mjFkc(AbstractC1410kd.KLFTb(e2));
        } catch (RuntimeException e3) {
            this.AZxh.ZfxDd(e3);
        }
    }
}
