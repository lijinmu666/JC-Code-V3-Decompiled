package o;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.RippleDrawable;
import android.util.AttributeSet;
import android.widget.ImageView;

/* loaded from: classes.dex */
public class alEkx {
    public C2223y8 AZxh;
    public int KLFTb = 0;
    public C2223y8 ZfxDd;
    public final ImageView mjFkc;
    public C2223y8 wA;

    public alEkx(ImageView imageView) {
        this.mjFkc = imageView;
    }

    public void AZxh() {
        if (this.mjFkc.getDrawable() != null) {
            this.mjFkc.getDrawable().setLevel(this.KLFTb);
        }
    }

    public void Dt(ColorStateList colorStateList) {
        if (this.wA == null) {
            this.wA = new C2223y8();
        }
        C2223y8 c2223y8 = this.wA;
        c2223y8.mjFkc = colorStateList;
        c2223y8.ZfxDd = true;
        wA();
    }

    public void ETF(PorterDuff.Mode mode) {
        if (this.wA == null) {
            this.wA = new C2223y8();
        }
        C2223y8 c2223y8 = this.wA;
        c2223y8.AZxh = mode;
        c2223y8.wA = true;
        wA();
    }

    public boolean JHa() {
        return !(this.mjFkc.getBackground() instanceof RippleDrawable);
    }

    public PorterDuff.Mode KLFTb() {
        C2223y8 c2223y8 = this.wA;
        if (c2223y8 != null) {
            return c2223y8.AZxh;
        }
        return null;
    }

    public final boolean VA() {
        return this.AZxh != null;
    }

    public ColorStateList ZfxDd() {
        C2223y8 c2223y8 = this.wA;
        if (c2223y8 != null) {
            return c2223y8.mjFkc;
        }
        return null;
    }

    public void lgHUyS(Drawable drawable) {
        this.KLFTb = drawable.getLevel();
    }

    public final boolean mjFkc(Drawable drawable) {
        if (this.ZfxDd == null) {
            this.ZfxDd = new C2223y8();
        }
        C2223y8 c2223y8 = this.ZfxDd;
        c2223y8.mjFkc();
        ColorStateList colorStateListMjFkc = J.mjFkc(this.mjFkc);
        if (colorStateListMjFkc != null) {
            c2223y8.ZfxDd = true;
            c2223y8.mjFkc = colorStateListMjFkc;
        }
        PorterDuff.Mode modeAZxh = J.AZxh(this.mjFkc);
        if (modeAZxh != null) {
            c2223y8.wA = true;
            c2223y8.AZxh = modeAZxh;
        }
        if (!c2223y8.ZfxDd && !c2223y8.wA) {
            return false;
        }
        bbzow.xJ(drawable, c2223y8, this.mjFkc.getDrawableState());
        return true;
    }

    public void qdMbNW(int i) {
        if (i != 0) {
            Drawable drawableAZxh = vjlshU.AZxh(this.mjFkc.getContext(), i);
            if (drawableAZxh != null) {
                awnh.AZxh(drawableAZxh);
            }
            this.mjFkc.setImageDrawable(drawableAZxh);
        } else {
            this.mjFkc.setImageDrawable(null);
        }
        wA();
    }

    public void wA() {
        Drawable drawable = this.mjFkc.getDrawable();
        if (drawable != null) {
            awnh.AZxh(drawable);
        }
        if (drawable != null) {
            if (VA() && mjFkc(drawable)) {
                return;
            }
            C2223y8 c2223y8 = this.wA;
            if (c2223y8 != null) {
                bbzow.xJ(drawable, c2223y8, this.mjFkc.getDrawableState());
                return;
            }
            C2223y8 c2223y82 = this.AZxh;
            if (c2223y82 != null) {
                bbzow.xJ(drawable, c2223y82, this.mjFkc.getDrawableState());
            }
        }
    }

    public void xJ(AttributeSet attributeSet, int i) {
        int iMiMN;
        A8 a8Diqgf = A8.diqgf(this.mjFkc.getContext(), attributeSet, AbstractC0837b5.OjSQV, i, 0);
        ImageView imageView = this.mjFkc;
        T9.jm(imageView, imageView.getContext(), AbstractC0837b5.OjSQV, attributeSet, a8Diqgf.qGY(), i, 0);
        try {
            Drawable drawable = this.mjFkc.getDrawable();
            if (drawable == null && (iMiMN = a8Diqgf.MiMN(AbstractC0837b5.Ne, -1)) != -1 && (drawable = vjlshU.AZxh(this.mjFkc.getContext(), iMiMN)) != null) {
                this.mjFkc.setImageDrawable(drawable);
            }
            if (drawable != null) {
                awnh.AZxh(drawable);
            }
            if (a8Diqgf.fehf(AbstractC0837b5.CqaNbM)) {
                J.wA(this.mjFkc, a8Diqgf.wA(AbstractC0837b5.CqaNbM));
            }
            if (a8Diqgf.fehf(AbstractC0837b5.xrEuO)) {
                J.ZfxDd(this.mjFkc, awnh.ZfxDd(a8Diqgf.Dt(AbstractC0837b5.xrEuO, -1), null));
            }
            a8Diqgf.eyqo();
        } catch (Throwable th) {
            a8Diqgf.eyqo();
            throw th;
        }
    }
}
