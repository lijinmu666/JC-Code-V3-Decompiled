package o;

import android.graphics.drawable.Drawable;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewGroupOverlay;

/* renamed from: o.ba, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public class C0866ba implements InterfaceC0926ca {
    public final ViewGroupOverlay mjFkc;

    public C0866ba(ViewGroup viewGroup) {
        this.mjFkc = viewGroup.getOverlay();
    }

    @Override // o.InterfaceC1587na
    public void AZxh(Drawable drawable) {
        this.mjFkc.add(drawable);
    }

    @Override // o.InterfaceC1587na
    public void ZfxDd(Drawable drawable) {
        this.mjFkc.remove(drawable);
    }

    @Override // o.InterfaceC0926ca
    public void mjFkc(View view) {
        this.mjFkc.add(view);
    }

    @Override // o.InterfaceC0926ca
    public void wA(View view) {
        this.mjFkc.remove(view);
    }
}
