package o;

/* renamed from: o.pg, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C1713pg implements InterfaceC1252hy {
    public static final InterfaceC1252hy mjFkc = new C1713pg();

    @Override // o.InterfaceC1252hy
    public final boolean mjFkc(int i) {
        return i == 0 || i == 1;
    }
}
