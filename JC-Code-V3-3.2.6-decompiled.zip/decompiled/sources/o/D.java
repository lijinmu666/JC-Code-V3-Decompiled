package o;

import android.os.IInterface;

/* loaded from: classes.dex */
public interface D extends IInterface {
    void qdMbNW(C c, nVsW nvsw);
}
