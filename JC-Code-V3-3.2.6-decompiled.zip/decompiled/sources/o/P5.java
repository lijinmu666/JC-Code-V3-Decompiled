package o;

import android.database.Cursor;
import java.util.List;
import o.C0959d6;

/* loaded from: classes.dex */
public final /* synthetic */ class P5 implements C0959d6.AZxh {
    public final List AZxh;
    public final C0959d6 mjFkc;
    public final X8 wA;

    public P5(C0959d6 c0959d6, List list, X8 x8) {
        this.mjFkc = c0959d6;
        this.AZxh = list;
        this.wA = x8;
    }

    public static C0959d6.AZxh mjFkc(C0959d6 c0959d6, List list, X8 x8) {
        return new P5(c0959d6, list, x8);
    }

    @Override // o.C0959d6.AZxh
    public Object apply(Object obj) {
        return C0959d6.mByQ(this.mjFkc, this.AZxh, this.wA, (Cursor) obj);
    }
}
