package o;

import android.content.Context;
import android.util.Log;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.animation.Interpolator;
import android.widget.OverScroller;
import com.indidevs.android.adbeesh.notifications.NotificationFlowConfig;
import java.util.Arrays;

/* loaded from: classes.dex */
public class Y9 {
    public static final Interpolator Gd = new mjFkc();
    public int AZxh;
    public int[] Dt;
    public int ETF;
    public OverScroller IEE;
    public float[] JHa;
    public float[] KLFTb;
    public float MiMN;
    public final wA Pq;
    public final ViewGroup Ucbh;
    public VelocityTracker VA;
    public float YoKzxo;
    public float[] ZfxDd;
    public View diqgf;
    public boolean eyqo;
    public int fehf;
    public int[] lgHUyS;
    public int mjFkc;
    public final int qGY;
    public int[] qdMbNW;
    public int rkYL;
    public float[] xJ;
    public int wA = -1;
    public final Runnable huTpC = new AZxh();

    public class AZxh implements Runnable {
        public AZxh() {
        }

        @Override // java.lang.Runnable
        public void run() {
            Y9.this.mByQ(0);
        }
    }

    public class mjFkc implements Interpolator {
        @Override // android.animation.TimeInterpolator
        public float getInterpolation(float f) {
            float f2 = f - 1.0f;
            return (f2 * f2 * f2 * f2 * f2) + 1.0f;
        }
    }

    public static abstract class wA {
        public abstract int AZxh(View view, int i, int i2);

        public abstract void Dt(int i);

        public abstract void ETF(View view, int i, int i2, int i3, int i4);

        public void JHa(int i, int i2) {
        }

        public int KLFTb(View view) {
            return 0;
        }

        public abstract boolean MiMN(View view, int i);

        public abstract void VA(View view, float f, float f2);

        public int ZfxDd(View view) {
            return 0;
        }

        public void lgHUyS(int i, int i2) {
        }

        public abstract int mjFkc(View view, int i, int i2);

        public void qdMbNW(View view, int i) {
        }

        public int wA(int i) {
            return i;
        }

        public boolean xJ(int i) {
            return false;
        }
    }

    public Y9(Context context, ViewGroup viewGroup, wA wAVar) {
        if (viewGroup == null) {
            throw new IllegalArgumentException("Parent view may not be null");
        }
        if (wAVar == null) {
            throw new IllegalArgumentException("Callback may not be null");
        }
        this.Ucbh = viewGroup;
        this.Pq = wAVar;
        ViewConfiguration viewConfiguration = ViewConfiguration.get(context);
        int i = (int) ((context.getResources().getDisplayMetrics().density * 20.0f) + 0.5f);
        this.qGY = i;
        this.rkYL = i;
        this.AZxh = viewConfiguration.getScaledTouchSlop();
        this.MiMN = viewConfiguration.getScaledMaximumFlingVelocity();
        this.YoKzxo = viewConfiguration.getScaledMinimumFlingVelocity();
        this.IEE = new OverScroller(context, Gd);
    }

    public static Y9 MiMN(ViewGroup viewGroup, wA wAVar) {
        return new Y9(viewGroup.getContext(), viewGroup, wAVar);
    }

    public static Y9 VA(ViewGroup viewGroup, float f, wA wAVar) {
        Y9 y9MiMN = MiMN(viewGroup, wAVar);
        y9MiMN.AZxh = (int) (y9MiMN.AZxh * (1.0f / f));
        return y9MiMN;
    }

    public void AZxh(View view, int i) {
        if (view.getParent() == this.Ucbh) {
            this.diqgf = view;
            this.wA = i;
            this.Pq.qdMbNW(view, i);
            mByQ(1);
            return;
        }
        throw new IllegalArgumentException("captureChildView: parameter must be a descendant of the ViewDragHelper's tracked parent view (" + this.Ucbh + ")");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v15 */
    /* JADX WARN: Type inference failed for: r0v16 */
    /* JADX WARN: Type inference failed for: r0v4, types: [int] */
    /* JADX WARN: Type inference failed for: r0v6 */
    /* JADX WARN: Type inference failed for: r0v7 */
    /* JADX WARN: Type inference failed for: r2v1, types: [o.Y9$wA] */
    public final void BAnRFn(float f, float f2, int i) {
        boolean zWA = wA(f, f2, i, 1);
        boolean z = zWA;
        if (wA(f2, f, i, 4)) {
            z = (zWA ? 1 : 0) | 4;
        }
        boolean z2 = z;
        if (wA(f, f2, i, 2)) {
            z2 = (z ? 1 : 0) | 2;
        }
        ?? r0 = z2;
        if (wA(f2, f, i, 8)) {
            r0 = (z2 ? 1 : 0) | 8;
        }
        if (r0 != 0) {
            int[] iArr = this.qdMbNW;
            iArr[i] = iArr[i] | r0;
            this.Pq.JHa(r0, i);
        }
    }

    public boolean CqaNbM(View view, int i, int i2) {
        this.diqgf = view;
        this.wA = -1;
        boolean zPq = Pq(i, i2, 0, 0);
        if (!zPq && this.mjFkc == 0 && this.diqgf != null) {
            this.diqgf = null;
        }
        return zPq;
    }

    public final int Dt(View view, int i, int i2, int i3, int i4) {
        float f;
        float f2;
        float f3;
        float f4;
        int iJHa = JHa(i3, (int) this.YoKzxo, (int) this.MiMN);
        int iJHa2 = JHa(i4, (int) this.YoKzxo, (int) this.MiMN);
        int iAbs = Math.abs(i);
        int iAbs2 = Math.abs(i2);
        int iAbs3 = Math.abs(iJHa);
        int iAbs4 = Math.abs(iJHa2);
        int i5 = iAbs3 + iAbs4;
        int i6 = iAbs + iAbs2;
        if (iJHa != 0) {
            f = iAbs3;
            f2 = i5;
        } else {
            f = iAbs;
            f2 = i6;
        }
        float f5 = f / f2;
        if (iJHa2 != 0) {
            f3 = iAbs4;
            f4 = i5;
        } else {
            f3 = iAbs2;
            f4 = i6;
        }
        return (int) ((qdMbNW(i, iJHa, this.Pq.ZfxDd(view)) * f5) + (qdMbNW(i2, iJHa2, this.Pq.KLFTb(view)) * (f3 / f4)));
    }

    public boolean ETF(boolean z) {
        if (this.mjFkc == 2) {
            boolean zComputeScrollOffset = this.IEE.computeScrollOffset();
            int currX = this.IEE.getCurrX();
            int currY = this.IEE.getCurrY();
            int left = currX - this.diqgf.getLeft();
            int top = currY - this.diqgf.getTop();
            if (left != 0) {
                T9.WrLQs(this.diqgf, left);
            }
            if (top != 0) {
                T9.KRTLGT(this.diqgf, top);
            }
            if (left != 0 || top != 0) {
                this.Pq.ETF(this.diqgf, currX, currY, left, top);
            }
            if (zComputeScrollOffset && currX == this.IEE.getFinalX() && currY == this.IEE.getFinalY()) {
                this.IEE.abortAnimation();
                zComputeScrollOffset = false;
            }
            if (!zComputeScrollOffset) {
                if (z) {
                    this.Ucbh.post(this.huTpC);
                } else {
                    mByQ(0);
                }
            }
        }
        return this.mjFkc == 2;
    }

    public final boolean Gd(int i) {
        if (huTpC(i)) {
            return true;
        }
        Log.e("ViewDragHelper", "Ignoring pointerId=" + i + " because ACTION_DOWN was not received for this pointer before ACTION_MOVE. It likely happened because  ViewDragHelper did not receive all the events in the event stream.");
        return false;
    }

    public boolean HGpJ(View view, int i, int i2) {
        return view != null && i >= view.getLeft() && i < view.getRight() && i2 >= view.getTop() && i2 < view.getBottom();
    }

    public View IEE(int i, int i2) {
        for (int childCount = this.Ucbh.getChildCount() - 1; childCount >= 0; childCount--) {
            View childAt = this.Ucbh.getChildAt(this.Pq.wA(childCount));
            if (i >= childAt.getLeft() && i < childAt.getRight() && i2 >= childAt.getTop() && i2 < childAt.getBottom()) {
                return childAt;
            }
        }
        return null;
    }

    public final int JHa(int i, int i2, int i3) {
        int iAbs = Math.abs(i);
        if (iAbs < i2) {
            return 0;
        }
        return iAbs > i3 ? i > 0 ? i3 : -i3 : i;
    }

    public final float KLFTb(float f, float f2, float f3) {
        float fAbs = Math.abs(f);
        if (fAbs < f2) {
            return 0.0f;
        }
        return fAbs > f3 ? f > 0.0f ? f3 : -f3 : f;
    }

    /* JADX WARN: Removed duplicated region for block: B:54:0x00e6  */
    /* JADX WARN: Removed duplicated region for block: B:63:0x00ff  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public boolean Ne(MotionEvent motionEvent) {
        boolean z;
        View viewIEE;
        int actionMasked = motionEvent.getActionMasked();
        int actionIndex = motionEvent.getActionIndex();
        if (actionMasked == 0) {
            mjFkc();
        }
        if (this.VA == null) {
            this.VA = VelocityTracker.obtain();
        }
        this.VA.addMovement(motionEvent);
        if (actionMasked == 0) {
            float x = motionEvent.getX();
            float y = motionEvent.getY();
            z = false;
            int pointerId = motionEvent.getPointerId(0);
            lB(x, y, pointerId);
            View viewIEE2 = IEE((int) x, (int) y);
            if (viewIEE2 == this.diqgf && this.mjFkc == 2) {
                xrEuO(viewIEE2, pointerId);
            }
            int i = this.lgHUyS[pointerId];
            int i2 = this.fehf;
            if ((i & i2) != 0) {
                this.Pq.lgHUyS(i & i2, pointerId);
            }
        } else if (actionMasked == 1) {
            mjFkc();
            z = false;
        } else {
            if (actionMasked != 2) {
                if (actionMasked != 3) {
                    if (actionMasked == 5) {
                        int pointerId2 = motionEvent.getPointerId(actionIndex);
                        float x2 = motionEvent.getX(actionIndex);
                        float y2 = motionEvent.getY(actionIndex);
                        lB(x2, y2, pointerId2);
                        int i3 = this.mjFkc;
                        if (i3 == 0) {
                            int i4 = this.lgHUyS[pointerId2];
                            int i5 = this.fehf;
                            if ((i4 & i5) != 0) {
                                this.Pq.lgHUyS(i4 & i5, pointerId2);
                            }
                        } else if (i3 == 2 && (viewIEE = IEE((int) x2, (int) y2)) == this.diqgf) {
                            xrEuO(viewIEE, pointerId2);
                        }
                    } else if (actionMasked == 6) {
                        lgHUyS(motionEvent.getPointerId(actionIndex));
                    }
                }
            } else if (this.ZfxDd != null && this.KLFTb != null) {
                int pointerCount = motionEvent.getPointerCount();
                for (int i6 = 0; i6 < pointerCount; i6++) {
                    int pointerId3 = motionEvent.getPointerId(i6);
                    if (Gd(pointerId3)) {
                        float x3 = motionEvent.getX(i6);
                        float y3 = motionEvent.getY(i6);
                        float f = x3 - this.ZfxDd[pointerId3];
                        float f2 = y3 - this.KLFTb[pointerId3];
                        View viewIEE3 = IEE((int) x3, (int) y3);
                        boolean z2 = viewIEE3 != null && ZfxDd(viewIEE3, f, f2);
                        if (z2) {
                            int left = viewIEE3.getLeft();
                            int i7 = (int) f;
                            int iMjFkc = this.Pq.mjFkc(viewIEE3, left + i7, i7);
                            int top = viewIEE3.getTop();
                            int i8 = (int) f2;
                            int iAZxh = this.Pq.AZxh(viewIEE3, top + i8, i8);
                            int iZfxDd = this.Pq.ZfxDd(viewIEE3);
                            int iKLFTb = this.Pq.KLFTb(viewIEE3);
                            if ((iZfxDd == 0 || (iZfxDd > 0 && iMjFkc == left)) && (iKLFTb == 0 || (iKLFTb > 0 && iAZxh == top))) {
                                break;
                            }
                            BAnRFn(f, f2, pointerId3);
                            if (this.mjFkc == 1 || (z2 && xrEuO(viewIEE3, pointerId3))) {
                                break;
                            }
                        }
                    }
                }
                wJVbdd(motionEvent);
            }
            z = false;
        }
        if (this.mjFkc == 1) {
            return true;
        }
        return z;
    }

    public boolean OjSQV(int i, int i2) {
        if (this.eyqo) {
            return Pq(i, i2, (int) this.VA.getXVelocity(this.wA), (int) this.VA.getYVelocity(this.wA));
        }
        throw new IllegalStateException("Cannot settleCapturedViewAt outside of a call to Callback#onViewReleased");
    }

    public final boolean Pq(int i, int i2, int i3, int i4) {
        int left = this.diqgf.getLeft();
        int top = this.diqgf.getTop();
        int i5 = i - left;
        int i6 = i2 - top;
        if (i5 == 0 && i6 == 0) {
            this.IEE.abortAnimation();
            mByQ(0);
            return false;
        }
        this.IEE.startScroll(left, top, i5, i6, Dt(this.diqgf, i5, i6, i3, i4));
        mByQ(2);
        return true;
    }

    public boolean Ucbh(int i, int i2) {
        return HGpJ(this.diqgf, i, i2);
    }

    public final void VocHEe() {
        this.VA.computeCurrentVelocity(NotificationFlowConfig.DEFAULT_BASE_REQUEST_CODE, this.MiMN);
        YoKzxo(KLFTb(this.VA.getXVelocity(this.wA), this.YoKzxo, this.MiMN), KLFTb(this.VA.getYVelocity(this.wA), this.YoKzxo, this.MiMN));
    }

    public final void YoKzxo(float f, float f2) {
        this.eyqo = true;
        this.Pq.VA(this.diqgf, f, f2);
        this.eyqo = false;
        if (this.mjFkc == 1) {
            mByQ(0);
        }
    }

    public final boolean ZfxDd(View view, float f, float f2) {
        if (view == null) {
            return false;
        }
        boolean z = this.Pq.ZfxDd(view) > 0;
        boolean z2 = this.Pq.KLFTb(view) > 0;
        if (!z || !z2) {
            return z ? Math.abs(f) > ((float) this.AZxh) : z2 && Math.abs(f2) > ((float) this.AZxh);
        }
        float f3 = (f * f) + (f2 * f2);
        int i = this.AZxh;
        return f3 > ((float) (i * i));
    }

    public final int diqgf(int i, int i2) {
        int i3 = i < this.Ucbh.getLeft() + this.rkYL ? 1 : 0;
        if (i2 < this.Ucbh.getTop() + this.rkYL) {
            i3 |= 4;
        }
        if (i > this.Ucbh.getRight() - this.rkYL) {
            i3 |= 2;
        }
        return i2 > this.Ucbh.getBottom() - this.rkYL ? i3 | 8 : i3;
    }

    public int eyqo() {
        return this.AZxh;
    }

    public final void fehf(int i) {
        float[] fArr = this.ZfxDd;
        if (fArr == null || fArr.length <= i) {
            int i2 = i + 1;
            float[] fArr2 = new float[i2];
            float[] fArr3 = new float[i2];
            float[] fArr4 = new float[i2];
            float[] fArr5 = new float[i2];
            int[] iArr = new int[i2];
            int[] iArr2 = new int[i2];
            int[] iArr3 = new int[i2];
            if (fArr != null) {
                System.arraycopy(fArr, 0, fArr2, 0, fArr.length);
                float[] fArr6 = this.KLFTb;
                System.arraycopy(fArr6, 0, fArr3, 0, fArr6.length);
                float[] fArr7 = this.JHa;
                System.arraycopy(fArr7, 0, fArr4, 0, fArr7.length);
                float[] fArr8 = this.xJ;
                System.arraycopy(fArr8, 0, fArr5, 0, fArr8.length);
                int[] iArr4 = this.lgHUyS;
                System.arraycopy(iArr4, 0, iArr, 0, iArr4.length);
                int[] iArr5 = this.qdMbNW;
                System.arraycopy(iArr5, 0, iArr2, 0, iArr5.length);
                int[] iArr6 = this.Dt;
                System.arraycopy(iArr6, 0, iArr3, 0, iArr6.length);
            }
            this.ZfxDd = fArr2;
            this.KLFTb = fArr3;
            this.JHa = fArr4;
            this.xJ = fArr5;
            this.lgHUyS = iArr;
            this.qdMbNW = iArr2;
            this.Dt = iArr3;
        }
    }

    public boolean huTpC(int i) {
        return (this.ETF & (1 << i)) != 0;
    }

    public final void lB(float f, float f2, int i) {
        fehf(i);
        float[] fArr = this.ZfxDd;
        this.JHa[i] = f;
        fArr[i] = f;
        float[] fArr2 = this.KLFTb;
        this.xJ[i] = f2;
        fArr2[i] = f2;
        this.lgHUyS[i] = diqgf((int) f, (int) f2);
        this.ETF |= 1 << i;
    }

    public final void lgHUyS(int i) {
        if (this.ZfxDd == null || !huTpC(i)) {
            return;
        }
        this.ZfxDd[i] = 0.0f;
        this.KLFTb[i] = 0.0f;
        this.JHa[i] = 0.0f;
        this.xJ[i] = 0.0f;
        this.lgHUyS[i] = 0;
        this.qdMbNW[i] = 0;
        this.Dt[i] = 0;
        this.ETF = (~(1 << i)) & this.ETF;
    }

    public void mByQ(int i) {
        this.Ucbh.removeCallbacks(this.huTpC);
        if (this.mjFkc != i) {
            this.mjFkc = i;
            this.Pq.Dt(i);
            if (this.mjFkc == 0) {
                this.diqgf = null;
            }
        }
    }

    public void mjFkc() {
        this.wA = -1;
        xJ();
        VelocityTracker velocityTracker = this.VA;
        if (velocityTracker != null) {
            velocityTracker.recycle();
            this.VA = null;
        }
    }

    public final void qGY(int i, int i2, int i3, int i4) {
        int left = this.diqgf.getLeft();
        int top = this.diqgf.getTop();
        if (i3 != 0) {
            i = this.Pq.mjFkc(this.diqgf, i, i3);
            T9.WrLQs(this.diqgf, i - left);
        }
        int i5 = i;
        if (i4 != 0) {
            i2 = this.Pq.AZxh(this.diqgf, i2, i4);
            T9.KRTLGT(this.diqgf, i2 - top);
        }
        int i6 = i2;
        if (i3 == 0 && i4 == 0) {
            return;
        }
        this.Pq.ETF(this.diqgf, i5, i6, i5 - left, i6 - top);
    }

    public final int qdMbNW(int i, int i2, int i3) {
        if (i == 0) {
            return 0;
        }
        int width = this.Ucbh.getWidth();
        float f = width / 2;
        float fRkYL = f + (rkYL(Math.min(1.0f, Math.abs(i) / width)) * f);
        int iAbs = Math.abs(i2);
        return Math.min(iAbs > 0 ? Math.round(Math.abs(fRkYL / iAbs) * 1000.0f) * 4 : (int) (((Math.abs(i) / i3) + 1.0f) * 256.0f), 600);
    }

    public final float rkYL(float f) {
        return (float) Math.sin((f - 0.5f) * 0.47123894f);
    }

    public void vI(MotionEvent motionEvent) {
        int i;
        int actionMasked = motionEvent.getActionMasked();
        int actionIndex = motionEvent.getActionIndex();
        if (actionMasked == 0) {
            mjFkc();
        }
        if (this.VA == null) {
            this.VA = VelocityTracker.obtain();
        }
        this.VA.addMovement(motionEvent);
        int i2 = 0;
        if (actionMasked == 0) {
            float x = motionEvent.getX();
            float y = motionEvent.getY();
            int pointerId = motionEvent.getPointerId(0);
            View viewIEE = IEE((int) x, (int) y);
            lB(x, y, pointerId);
            xrEuO(viewIEE, pointerId);
            int i3 = this.lgHUyS[pointerId];
            int i4 = this.fehf;
            if ((i3 & i4) != 0) {
                this.Pq.lgHUyS(i3 & i4, pointerId);
                return;
            }
            return;
        }
        if (actionMasked == 1) {
            if (this.mjFkc == 1) {
                VocHEe();
            }
            mjFkc();
            return;
        }
        if (actionMasked == 2) {
            if (this.mjFkc == 1) {
                if (Gd(this.wA)) {
                    int iFindPointerIndex = motionEvent.findPointerIndex(this.wA);
                    float x2 = motionEvent.getX(iFindPointerIndex);
                    float y2 = motionEvent.getY(iFindPointerIndex);
                    float[] fArr = this.JHa;
                    int i5 = this.wA;
                    int i6 = (int) (x2 - fArr[i5]);
                    int i7 = (int) (y2 - this.xJ[i5]);
                    qGY(this.diqgf.getLeft() + i6, this.diqgf.getTop() + i7, i6, i7);
                    wJVbdd(motionEvent);
                    return;
                }
                return;
            }
            int pointerCount = motionEvent.getPointerCount();
            while (i2 < pointerCount) {
                int pointerId2 = motionEvent.getPointerId(i2);
                if (Gd(pointerId2)) {
                    float x3 = motionEvent.getX(i2);
                    float y3 = motionEvent.getY(i2);
                    float f = x3 - this.ZfxDd[pointerId2];
                    float f2 = y3 - this.KLFTb[pointerId2];
                    BAnRFn(f, f2, pointerId2);
                    if (this.mjFkc != 1) {
                        View viewIEE2 = IEE((int) x3, (int) y3);
                        if (ZfxDd(viewIEE2, f, f2) && xrEuO(viewIEE2, pointerId2)) {
                            break;
                        }
                    } else {
                        break;
                    }
                }
                i2++;
            }
            wJVbdd(motionEvent);
            return;
        }
        if (actionMasked == 3) {
            if (this.mjFkc == 1) {
                YoKzxo(0.0f, 0.0f);
            }
            mjFkc();
            return;
        }
        if (actionMasked == 5) {
            int pointerId3 = motionEvent.getPointerId(actionIndex);
            float x4 = motionEvent.getX(actionIndex);
            float y4 = motionEvent.getY(actionIndex);
            lB(x4, y4, pointerId3);
            if (this.mjFkc != 0) {
                if (Ucbh((int) x4, (int) y4)) {
                    xrEuO(this.diqgf, pointerId3);
                    return;
                }
                return;
            } else {
                xrEuO(IEE((int) x4, (int) y4), pointerId3);
                int i8 = this.lgHUyS[pointerId3];
                int i9 = this.fehf;
                if ((i8 & i9) != 0) {
                    this.Pq.lgHUyS(i8 & i9, pointerId3);
                    return;
                }
                return;
            }
        }
        if (actionMasked != 6) {
            return;
        }
        int pointerId4 = motionEvent.getPointerId(actionIndex);
        if (this.mjFkc == 1 && pointerId4 == this.wA) {
            int pointerCount2 = motionEvent.getPointerCount();
            while (true) {
                if (i2 >= pointerCount2) {
                    i = -1;
                    break;
                }
                int pointerId5 = motionEvent.getPointerId(i2);
                if (pointerId5 != this.wA) {
                    View viewIEE3 = IEE((int) motionEvent.getX(i2), (int) motionEvent.getY(i2));
                    View view = this.diqgf;
                    if (viewIEE3 == view && xrEuO(view, pointerId5)) {
                        i = this.wA;
                        break;
                    }
                }
                i2++;
            }
            if (i == -1) {
                VocHEe();
            }
        }
        lgHUyS(pointerId4);
    }

    public final boolean wA(float f, float f2, int i, int i2) {
        float fAbs = Math.abs(f);
        float fAbs2 = Math.abs(f2);
        if ((this.lgHUyS[i] & i2) != i2 || (this.fehf & i2) == 0 || (this.Dt[i] & i2) == i2 || (this.qdMbNW[i] & i2) == i2) {
            return false;
        }
        int i3 = this.AZxh;
        if (fAbs <= i3 && fAbs2 <= i3) {
            return false;
        }
        if (fAbs >= fAbs2 * 0.5f || !this.Pq.xJ(i2)) {
            return (this.qdMbNW[i] & i2) == 0 && fAbs > ((float) this.AZxh);
        }
        int[] iArr = this.Dt;
        iArr[i] = iArr[i] | i2;
        return false;
    }

    public final void wJVbdd(MotionEvent motionEvent) {
        int pointerCount = motionEvent.getPointerCount();
        for (int i = 0; i < pointerCount; i++) {
            int pointerId = motionEvent.getPointerId(i);
            if (Gd(pointerId)) {
                float x = motionEvent.getX(i);
                float y = motionEvent.getY(i);
                this.JHa[pointerId] = x;
                this.xJ[pointerId] = y;
            }
        }
    }

    public final void xJ() {
        float[] fArr = this.ZfxDd;
        if (fArr == null) {
            return;
        }
        Arrays.fill(fArr, 0.0f);
        Arrays.fill(this.KLFTb, 0.0f);
        Arrays.fill(this.JHa, 0.0f);
        Arrays.fill(this.xJ, 0.0f);
        Arrays.fill(this.lgHUyS, 0);
        Arrays.fill(this.qdMbNW, 0);
        Arrays.fill(this.Dt, 0);
        this.ETF = 0;
    }

    public boolean xrEuO(View view, int i) {
        if (view == this.diqgf && this.wA == i) {
            return true;
        }
        if (view == null || !this.Pq.MiMN(view, i)) {
            return false;
        }
        this.wA = i;
        AZxh(view, i);
        return true;
    }
}
