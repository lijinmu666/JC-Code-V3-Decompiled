package o;

import java.util.Collections;
import java.util.Map;

/* loaded from: classes.dex */
public final class Kx {
    public static volatile Kx AZxh;
    public static final Kx wA = new Kx(true);
    public final Map mjFkc = Collections.emptyMap();

    public Kx(boolean z) {
    }

    public static Kx AZxh() {
        Kx kx = AZxh;
        if (kx != null) {
            return kx;
        }
        synchronized (Kx.class) {
            try {
                Kx kx2 = AZxh;
                if (kx2 != null) {
                    return kx2;
                }
                Ry ry = Ry.wA;
                Kx kxMjFkc = Tx.mjFkc(Kx.class);
                AZxh = kxMjFkc;
                return kxMjFkc;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public static Kx mjFkc() {
        Ry ry = Ry.wA;
        return wA;
    }

    public final C0950cy wA(Ky ky, int i) {
        return (C0950cy) this.mjFkc.get(new Jx(ky, i));
    }
}
