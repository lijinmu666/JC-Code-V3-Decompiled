package o;

/* loaded from: classes.dex */
public final class DA extends AbstractC1010dy implements Ly {
    private static final DA zbb;
    private int zbd;
    private InterfaceC1491ly zbe = AbstractC1010dy.wJVbdd();
    private HA zbf;
    private Iz zbg;

    static {
        DA da = new DA();
        zbb = da;
        AbstractC1010dy.YoKzxo(DA.class, da);
    }

    @Override // o.AbstractC1010dy
    public final Object IEE(int i, Object obj, Object obj2) {
        int i2 = i - 1;
        if (i2 == 0) {
            return (byte) 1;
        }
        if (i2 == 2) {
            return AbstractC1010dy.ETF(zbb, "\u0001\u0003\u0000\u0001\u0001\u0003\u0003\u0000\u0001\u0000\u0001\u001b\u0002ဉ\u0000\u0003ဉ\u0001", new Object[]{"zbd", "zbe", WA.class, "zbf", "zbg"});
        }
        if (i2 == 3) {
            return new DA();
        }
        AbstractC2274yz abstractC2274yz = null;
        if (i2 == 4) {
            return new CA(abstractC2274yz);
        }
        if (i2 != 5) {
            return null;
        }
        return zbb;
    }
}
