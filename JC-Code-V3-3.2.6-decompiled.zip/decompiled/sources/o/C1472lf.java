package o;

/* renamed from: o.lf, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C1472lf extends Zx implements Ly {
    private static final C1472lf zbd;
    private int zbe;
    private C0871bf zbf;
    private float zbh;
    private float zbi;
    private float zbj;
    private float zbk;
    private float zbl;
    private long zbo;
    private long zbp;
    private long zbq;
    private float zbr;
    private C1173gf zbs;
    private byte zbt = 2;
    private InterfaceC1491ly zbg = AbstractC1010dy.wJVbdd();
    private InterfaceC1491ly zbm = AbstractC1010dy.wJVbdd();
    private InterfaceC1491ly zbn = AbstractC1010dy.wJVbdd();

    static {
        C1472lf c1472lf = new C1472lf();
        zbd = c1472lf;
        AbstractC1010dy.YoKzxo(C1472lf.class, c1472lf);
    }

    @Override // o.AbstractC1010dy
    public final Object IEE(int i, Object obj, Object obj2) {
        int i2 = i - 1;
        if (i2 == 0) {
            return Byte.valueOf(this.zbt);
        }
        if (i2 == 2) {
            return AbstractC1010dy.ETF(zbd, "\u0001\u000e\u0000\u0001\u0001\u000e\u000e\u0000\u0003\u0000\u0001ဉ\u0000\u0002\u001b\u0003ခ\u0001\u0004ခ\u0002\u0005ခ\u0003\u0006ခ\u0004\u0007\u001b\b\u001b\tဃ\u0007\nခ\t\u000bဃ\b\fဃ\u0006\rခ\u0005\u000eဉ\n", new Object[]{"zbe", "zbf", "zbg", C1412kf.class, "zbh", "zbi", "zbj", "zbk", "zbm", C1052ef.class, "zbn", C0705Xe.class, "zbp", "zbr", "zbq", "zbo", "zbl", "zbs"});
        }
        if (i2 == 3) {
            return new C1472lf();
        }
        AbstractC0636Ue abstractC0636Ue = null;
        if (i2 == 4) {
            return new C0931cf(abstractC0636Ue);
        }
        if (i2 == 5) {
            return zbd;
        }
        this.zbt = obj == null ? (byte) 0 : (byte) 1;
        return null;
    }
}
