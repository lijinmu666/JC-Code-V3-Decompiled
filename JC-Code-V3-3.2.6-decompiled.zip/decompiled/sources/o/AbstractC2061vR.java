package o;

/* renamed from: o.vR, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC2061vR {
}
