package o;

/* renamed from: o.Dv, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0261Dv extends Vx implements Ly {
    public /* synthetic */ C0261Dv(AbstractC0192Av abstractC0192Av) {
        super(C0284Ev.zbb);
    }
}
