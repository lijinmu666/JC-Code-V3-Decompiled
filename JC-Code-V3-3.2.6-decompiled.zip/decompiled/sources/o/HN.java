package o;

/* loaded from: classes.dex */
public final class HN implements Runnable {
    public final /* synthetic */ QO AZxh;
    public final /* synthetic */ B7 mjFkc;

    public HN(QO qo, B7 b7) {
        this.AZxh = qo;
        this.mjFkc = b7;
    }

    @Override // java.lang.Runnable
    public final void run() {
        synchronized (this.AZxh.AZxh) {
            try {
                QO qo = this.AZxh;
                if (qo.wA != null) {
                    qo.wA.mjFkc((Exception) I3.xJ(this.mjFkc.KLFTb()));
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }
}
