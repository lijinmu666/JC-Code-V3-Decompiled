package o;

import java.util.List;

/* loaded from: classes.dex */
public final class QB extends TB {
    public final /* synthetic */ TB KLFTb;
    public final transient int ZfxDd;
    public final transient int wA;

    public QB(TB tb, int i, int i2) {
        this.KLFTb = tb;
        this.wA = i;
        this.ZfxDd = i2;
    }

    @Override // o.GB
    public final int JHa() {
        return this.KLFTb.JHa() + this.wA;
    }

    @Override // o.GB
    public final int ZfxDd() {
        return this.KLFTb.JHa() + this.wA + this.ZfxDd;
    }

    @Override // java.util.List
    public final Object get(int i) {
        AbstractC1645oV.mjFkc(i, this.ZfxDd, "index");
        return this.KLFTb.get(i + this.wA);
    }

    @Override // o.TB
    /* renamed from: lgHUyS */
    public final TB subList(int i, int i2) {
        AbstractC1645oV.wA(i, i2, this.ZfxDd);
        int i3 = this.wA;
        return this.KLFTb.subList(i + i3, i2 + i3);
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.List
    public final int size() {
        return this.ZfxDd;
    }

    @Override // o.TB, java.util.List
    public final /* bridge */ /* synthetic */ List subList(int i, int i2) {
        return subList(i, i2);
    }

    @Override // o.GB
    public final Object[] xJ() {
        return this.KLFTb.xJ();
    }
}
