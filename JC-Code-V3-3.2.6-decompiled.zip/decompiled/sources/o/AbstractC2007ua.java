package o;

import android.graphics.Rect;
import android.util.Log;
import android.view.View;
import java.lang.reflect.Method;

/* renamed from: o.ua, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC2007ua {
    public static final boolean AZxh = true;
    public static Method mjFkc;

    static {
        try {
            Method declaredMethod = View.class.getDeclaredMethod("computeFitSystemWindows", Rect.class, Rect.class);
            mjFkc = declaredMethod;
            if (declaredMethod.isAccessible()) {
                return;
            }
            mjFkc.setAccessible(true);
        } catch (NoSuchMethodException unused) {
            Log.d("ViewUtils", "Could not find method computeFitSystemWindows. Oh well.");
        }
    }

    public static boolean mjFkc(View view) {
        return T9.huTpC(view) == 1;
    }
}
