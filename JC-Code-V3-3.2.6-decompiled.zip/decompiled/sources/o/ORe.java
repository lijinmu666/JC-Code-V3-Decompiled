package o;

/* loaded from: classes.dex */
public final class ORe extends RuntimeException {
    public ORe(String str) {
        super(str);
    }

    public ORe(String str, Exception exc) {
        super(str, exc);
    }
}
