package o;

/* loaded from: classes.dex */
public abstract class Gy {
    public static final Fy mjFkc;

    static {
        Ry ry = Ry.wA;
        mjFkc = new Fy();
    }

    public static Fy mjFkc() {
        return mjFkc;
    }
}
