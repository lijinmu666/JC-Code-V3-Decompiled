package o;

/* renamed from: o.de, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0991de extends AbstractC1010dy implements Ly {
    private static final C0991de zbb;
    private int zbd;
    private C1668ov zbf;
    private byte zbg = 2;
    private InterfaceC1491ly zbe = AbstractC1010dy.wJVbdd();

    static {
        C0991de c0991de = new C0991de();
        zbb = c0991de;
        AbstractC1010dy.YoKzxo(C0991de.class, c0991de);
    }

    public static C0991de CqaNbM() {
        return zbb;
    }

    @Override // o.AbstractC1010dy
    public final Object IEE(int i, Object obj, Object obj2) {
        int i2 = i - 1;
        if (i2 == 0) {
            return Byte.valueOf(this.zbg);
        }
        if (i2 == 2) {
            return AbstractC1010dy.ETF(zbb, "\u0001\u0002\u0000\u0001\u0001\u0002\u0002\u0000\u0001\u0002\u0001Л\u0002ᐉ\u0000", new Object[]{"zbd", "zbe", C0870be.class, "zbf"});
        }
        if (i2 == 3) {
            return new C0991de();
        }
        AbstractC0727Yd abstractC0727Yd = null;
        if (i2 == 4) {
            return new C0930ce(abstractC0727Yd);
        }
        if (i2 == 5) {
            return zbb;
        }
        this.zbg = obj == null ? (byte) 0 : (byte) 1;
        return null;
    }

    public final C1668ov OjSQV() {
        C1668ov c1668ov = this.zbf;
        return c1668ov == null ? C1668ov.cMLeY() : c1668ov;
    }
}
