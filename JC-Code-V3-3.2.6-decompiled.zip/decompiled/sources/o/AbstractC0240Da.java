package o;

import o.dkKKW;
import o.gjvQ;

/* renamed from: o.Da, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC0240Da extends AbstractC2154x {
    public int gYa = 0;
    public int LREOK = 0;
    public int fFz = 0;
    public int XbiWeM = 0;
    public int XFUzSY = 0;
    public int XtE = 0;
    public int jx = 0;
    public int uH = 0;
    public boolean tISON = false;
    public int Vgyli = 0;
    public int lti = 0;
    public dkKKW.mjFkc giT = new dkKKW.mjFkc();
    public dkKKW.AZxh sRqPfw = null;

    public int Dp() {
        return this.Vgyli;
    }

    public boolean FbxKQm() {
        return this.tISON;
    }

    public void IyS(int i) {
        this.fFz = i;
        this.gYa = i;
        this.XbiWeM = i;
        this.LREOK = i;
        this.XFUzSY = i;
        this.XtE = i;
    }

    public void Jk(int i) {
        this.XFUzSY = i;
        this.jx = i;
        this.uH = i;
    }

    public void KRckQg(int i) {
        this.gYa = i;
    }

    public int Rc() {
        return this.uH;
    }

    public int SKTn() {
        return this.gYa;
    }

    public void XD() {
        for (int i = 0; i < this.yX; i++) {
            gjvQ gjvq = this.tjSezt[i];
            if (gjvq != null) {
                gjvq.SmIWf(true);
            }
        }
    }

    public void XDdeP(gjvQ gjvq, gjvQ.AZxh aZxh, int i, gjvQ.AZxh aZxh2, int i2) {
        while (this.sRqPfw == null && Ne() != null) {
            this.sRqPfw = ((C1429kw) Ne()).eQ();
        }
        dkKKW.mjFkc mjfkc = this.giT;
        mjfkc.mjFkc = aZxh;
        mjfkc.AZxh = aZxh2;
        mjfkc.wA = i;
        mjfkc.ZfxDd = i2;
        this.sRqPfw.AZxh(gjvq, mjfkc);
        gjvq.jx(this.giT.KLFTb);
        gjvq.ANMGZc(this.giT.JHa);
        gjvq.jm(this.giT.lgHUyS);
        gjvq.XV(this.giT.xJ);
    }

    public void XgAT(int i, int i2) {
        this.Vgyli = i;
        this.lti = i2;
    }

    public void Xxz(int i) {
        this.fFz = i;
        this.jx = i;
    }

    public void Zdbk(int i) {
        this.XbiWeM = i;
        this.uH = i;
    }

    public void dGDT(int i) {
        this.XtE = i;
    }

    public boolean eQ() {
        gjvQ gjvq = this.Vnb;
        dkKKW.AZxh aZxhEQ = gjvq != null ? ((C1429kw) gjvq).eQ() : null;
        if (aZxhEQ == null) {
            return false;
        }
        for (int i = 0; i < this.yX; i++) {
            gjvQ gjvq2 = this.tjSezt[i];
            if (gjvq2 != null && !(gjvq2 instanceof C1553n)) {
                gjvQ.AZxh aZxhPq = gjvq2.Pq(0);
                gjvQ.AZxh aZxhPq2 = gjvq2.Pq(1);
                gjvQ.AZxh aZxh = gjvQ.AZxh.MATCH_CONSTRAINT;
                if (aZxhPq != aZxh || gjvq2.VA == 1 || aZxhPq2 != aZxh || gjvq2.MiMN == 1) {
                    if (aZxhPq == aZxh) {
                        aZxhPq = gjvQ.AZxh.WRAP_CONTENT;
                    }
                    if (aZxhPq2 == aZxh) {
                        aZxhPq2 = gjvQ.AZxh.WRAP_CONTENT;
                    }
                    dkKKW.mjFkc mjfkc = this.giT;
                    mjfkc.mjFkc = aZxhPq;
                    mjfkc.AZxh = aZxhPq2;
                    mjfkc.wA = gjvq2.vadzgd();
                    this.giT.ZfxDd = gjvq2.Ucbh();
                    aZxhEQ.AZxh(gjvq2, this.giT);
                    gjvq2.jx(this.giT.KLFTb);
                    gjvq2.ANMGZc(this.giT.JHa);
                    gjvq2.XV(this.giT.xJ);
                }
            }
        }
        return true;
    }

    public int fLidf() {
        return this.LREOK;
    }

    public int gtr() {
        return this.lti;
    }

    public int hvGY() {
        return this.jx;
    }

    public void jtz(boolean z) {
        this.tISON = z;
    }

    @Override // o.AbstractC2154x, o.InterfaceC2033v
    public void mjFkc(C1429kw c1429kw) {
        XD();
    }

    public abstract void rdJr(int i, int i2, int i3, int i4);

    public void sRqPfw(boolean z) {
        int i = this.XFUzSY;
        if (i > 0 || this.XtE > 0) {
            if (z) {
                this.jx = this.XtE;
                this.uH = i;
            } else {
                this.jx = i;
                this.uH = this.XtE;
            }
        }
    }

    public void tAfC(int i) {
        this.LREOK = i;
    }
}
