package o;

import android.app.Notification;

/* loaded from: classes.dex */
public interface K2 {
    Notification.Builder mjFkc();
}
