package o;

/* renamed from: o.cb, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract /* synthetic */ class AbstractC0927cb {
}
