package o;

import android.os.Parcel;
import android.os.Parcelable;

/* loaded from: classes.dex */
public class BABY extends ETF {
    public static final Parcelable.Creator<BABY> CREATOR = new WP();
    public final boolean AZxh;
    public final int[] JHa;
    public final int KLFTb;
    public final int[] ZfxDd;
    public final E5 mjFkc;
    public final boolean wA;

    public BABY(E5 e5, boolean z, boolean z2, int[] iArr, int i, int[] iArr2) {
        this.mjFkc = e5;
        this.AZxh = z;
        this.wA = z2;
        this.ZfxDd = iArr;
        this.KLFTb = i;
        this.JHa = iArr2;
    }

    public int[] AZxh() {
        return this.ZfxDd;
    }

    public boolean JHa() {
        return this.wA;
    }

    public boolean ZfxDd() {
        return this.AZxh;
    }

    public int mjFkc() {
        return this.KLFTb;
    }

    public int[] wA() {
        return this.JHa;
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i) {
        int iMjFkc = AbstractC1380k6.mjFkc(parcel);
        AbstractC1380k6.Dt(parcel, 1, this.mjFkc, i, false);
        AbstractC1380k6.wA(parcel, 2, ZfxDd());
        AbstractC1380k6.wA(parcel, 3, JHa());
        AbstractC1380k6.lgHUyS(parcel, 4, AZxh(), false);
        AbstractC1380k6.xJ(parcel, 5, mjFkc());
        AbstractC1380k6.lgHUyS(parcel, 6, wA(), false);
        AbstractC1380k6.AZxh(parcel, iMjFkc);
    }

    public final E5 xJ() {
        return this.mjFkc;
    }
}
