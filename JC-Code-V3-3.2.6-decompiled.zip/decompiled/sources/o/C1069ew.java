package o;

/* renamed from: o.ew, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C1069ew extends Yx implements Ly {
    public /* synthetic */ C1069ew(AbstractC0353Hv abstractC0353Hv) {
        super(C1130fw.zbd);
    }
}
