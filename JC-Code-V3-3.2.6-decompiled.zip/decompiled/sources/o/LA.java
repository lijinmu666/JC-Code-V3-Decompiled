package o;

import org.conscrypt.BuildConfig;

/* loaded from: classes.dex */
public final class LA extends AbstractC1010dy implements Ly {
    private static final LA zbb;
    private int zbd;
    private String zbe = BuildConfig.FLAVOR;
    private String zbf = BuildConfig.FLAVOR;
    private String zbg = BuildConfig.FLAVOR;
    private int zbh;
    private int zbi;
    private C1384kA zbj;
    private boolean zbk;
    private int zbl;
    private boolean zbm;
    private boolean zbn;
    private boolean zbo;
    private long zbp;

    static {
        LA la = new LA();
        zbb = la;
        AbstractC1010dy.YoKzxo(LA.class, la);
    }

    @Override // o.AbstractC1010dy
    public final Object IEE(int i, Object obj, Object obj2) {
        int i2 = i - 1;
        if (i2 == 0) {
            return (byte) 1;
        }
        if (i2 == 2) {
            return AbstractC1010dy.ETF(zbb, "\u0001\f\u0000\u0001\u0001\f\f\u0000\u0000\u0000\u0001ဈ\u0000\u0002ဈ\u0001\u0003ဈ\u0002\u0004᠌\u0003\u0005င\u0004\u0006ဉ\u0005\u0007ဇ\u0006\b᠌\u0007\tဇ\b\nဇ\t\u000bဇ\n\fဂ\u000b", new Object[]{"zbd", "zbe", "zbf", "zbg", "zbh", OA.mjFkc, "zbi", "zbj", "zbk", "zbl", PA.mjFkc, "zbm", "zbn", "zbo", "zbp"});
        }
        if (i2 == 3) {
            return new LA();
        }
        AbstractC2274yz abstractC2274yz = null;
        if (i2 == 4) {
            return new KA(abstractC2274yz);
        }
        if (i2 != 5) {
            return null;
        }
        return zbb;
    }
}
