package o;

/* renamed from: o.Uw, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0654Uw extends Vx implements Ly {
    public /* synthetic */ C0654Uw(AbstractC1848rw abstractC1848rw) {
        super(C2091vx.zbb);
    }
}
