package o;

/* renamed from: o.fm, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C1120fm extends AbstractC1010dy implements Ly {
    private static final C1120fm zbb;
    private int zbd;
    private InterfaceC1491ly zbe = AbstractC1010dy.wJVbdd();
    private C0735Yl zbf;

    static {
        C1120fm c1120fm = new C1120fm();
        zbb = c1120fm;
        AbstractC1010dy.YoKzxo(C1120fm.class, c1120fm);
    }

    @Override // o.AbstractC1010dy
    public final Object IEE(int i, Object obj, Object obj2) {
        int i2 = i - 1;
        if (i2 == 0) {
            return (byte) 1;
        }
        if (i2 == 2) {
            return AbstractC1010dy.ETF(zbb, "\u0001\u0002\u0000\u0001\u0001\u0002\u0002\u0000\u0001\u0000\u0001\u001b\u0002ဉ\u0000", new Object[]{"zbd", "zbe", C2204xq.class, "zbf"});
        }
        if (i2 == 3) {
            return new C1120fm();
        }
        AbstractC0817am abstractC0817am = null;
        if (i2 == 4) {
            return new C0938cm(abstractC0817am);
        }
        if (i2 != 5) {
            return null;
        }
        return zbb;
    }
}
