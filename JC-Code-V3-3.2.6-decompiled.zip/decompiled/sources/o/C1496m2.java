package o;

import org.conscrypt.BuildConfig;

/* renamed from: o.m2, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public class C1496m2 {
    public final C1315j2 mjFkc;
    public static final C0831b AZxh = new C0831b("ModelFileHelper", BuildConfig.FLAVOR);
    public static final String wA = String.format("com.google.mlkit.%s.models", "translate");
    public static final String ZfxDd = String.format("com.google.mlkit.%s.models", "custom");
    public static final String KLFTb = String.format("com.google.mlkit.%s.models", "base");

    public C1496m2(C1315j2 c1315j2) {
        this.mjFkc = c1315j2;
    }
}
