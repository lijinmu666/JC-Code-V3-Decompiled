package o;

/* renamed from: o.g3, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public interface InterfaceC1138g3 {
    void mjFkc();
}
