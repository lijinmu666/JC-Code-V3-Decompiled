package o;

/* renamed from: o.Gk, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0319Gk extends AbstractC1010dy implements Ly {
    private static final C0319Gk zbb;
    private int zbd;
    private double zbe;
    private double zbf;

    static {
        C0319Gk c0319Gk = new C0319Gk();
        zbb = c0319Gk;
        AbstractC1010dy.YoKzxo(C0319Gk.class, c0319Gk);
    }

    @Override // o.AbstractC1010dy
    public final Object IEE(int i, Object obj, Object obj2) {
        int i2 = i - 1;
        if (i2 == 0) {
            return (byte) 1;
        }
        if (i2 == 2) {
            return AbstractC1010dy.ETF(zbb, "\u0001\u0002\u0000\u0001\u0001\u0002\u0002\u0000\u0000\u0000\u0001က\u0000\u0002က\u0001", new Object[]{"zbd", "zbe", "zbf"});
        }
        if (i2 == 3) {
            return new C0319Gk();
        }
        AbstractC0227Ck abstractC0227Ck = null;
        if (i2 == 4) {
            return new C0273Ek(abstractC0227Ck);
        }
        if (i2 != 5) {
            return null;
        }
        return zbb;
    }
}
