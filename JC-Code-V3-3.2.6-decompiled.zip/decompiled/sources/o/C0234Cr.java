package o;

/* renamed from: o.Cr, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0234Cr extends AbstractC1010dy implements Ly {
    private static final C0234Cr zbb;
    private InterfaceC1491ly zbd = AbstractC1010dy.wJVbdd();

    static {
        C0234Cr c0234Cr = new C0234Cr();
        zbb = c0234Cr;
        AbstractC1010dy.YoKzxo(C0234Cr.class, c0234Cr);
    }

    @Override // o.AbstractC1010dy
    public final Object IEE(int i, Object obj, Object obj2) {
        int i2 = i - 1;
        if (i2 == 0) {
            return (byte) 1;
        }
        if (i2 == 2) {
            return AbstractC1010dy.ETF(zbb, "\u0001\u0001\u0000\u0000\u0001\u0001\u0001\u0000\u0001\u0000\u0001\u001b", new Object[]{"zbd", C0303Fr.class});
        }
        if (i2 == 3) {
            return new C0234Cr();
        }
        AbstractC0188Ar abstractC0188Ar = null;
        if (i2 == 4) {
            return new C0211Br(abstractC0188Ar);
        }
        if (i2 != 5) {
            return null;
        }
        return zbb;
    }
}
