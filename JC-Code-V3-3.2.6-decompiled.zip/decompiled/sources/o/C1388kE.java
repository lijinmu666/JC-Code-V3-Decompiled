package o;

import o.C0797aQ;

/* renamed from: o.kE, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C1388kE implements R2 {
    public static final C0797aQ AZxh;
    public static final C0797aQ JHa;
    public static final C0797aQ KLFTb;
    public static final C0797aQ ZfxDd;
    public static final C1388kE mjFkc = new C1388kE();
    public static final C0797aQ wA;

    static {
        C0797aQ.AZxh aZxhMjFkc = C0797aQ.mjFkc("errorCode");
        OB ob = new OB();
        ob.mjFkc(1);
        AZxh = aZxhMjFkc.AZxh(ob.AZxh()).mjFkc();
        C0797aQ.AZxh aZxhMjFkc2 = C0797aQ.mjFkc("isColdCall");
        OB ob2 = new OB();
        ob2.mjFkc(2);
        wA = aZxhMjFkc2.AZxh(ob2.AZxh()).mjFkc();
        C0797aQ.AZxh aZxhMjFkc3 = C0797aQ.mjFkc("inputsFormats");
        OB ob3 = new OB();
        ob3.mjFkc(3);
        ZfxDd = aZxhMjFkc3.AZxh(ob3.AZxh()).mjFkc();
        C0797aQ.AZxh aZxhMjFkc4 = C0797aQ.mjFkc("outputFormats");
        OB ob4 = new OB();
        ob4.mjFkc(4);
        KLFTb = aZxhMjFkc4.AZxh(ob4.AZxh()).mjFkc();
        C0797aQ.AZxh aZxhMjFkc5 = C0797aQ.mjFkc("options");
        OB ob5 = new OB();
        ob5.mjFkc(5);
        JHa = aZxhMjFkc5.AZxh(ob5.AZxh()).mjFkc();
    }

    @Override // o.mYYU
    public final /* bridge */ /* synthetic */ void mjFkc(Object obj, Object obj2) {
        AbstractC2102w7.mjFkc(obj);
        throw null;
    }
}
