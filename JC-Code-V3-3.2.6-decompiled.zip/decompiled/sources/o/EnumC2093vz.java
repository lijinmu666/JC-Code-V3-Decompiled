package o;

/* JADX WARN: Enum visitor error
jadx.core.utils.exceptions.JadxRuntimeException: Init of enum field 'KLFTb' uses external variables
	at jadx.core.dex.visitors.EnumVisitor.createEnumFieldByConstructor(EnumVisitor.java:451)
	at jadx.core.dex.visitors.EnumVisitor.processEnumFieldByRegister(EnumVisitor.java:395)
	at jadx.core.dex.visitors.EnumVisitor.extractEnumFieldsFromFilledArray(EnumVisitor.java:324)
	at jadx.core.dex.visitors.EnumVisitor.extractEnumFieldsFromInsn(EnumVisitor.java:262)
	at jadx.core.dex.visitors.EnumVisitor.convertToEnum(EnumVisitor.java:151)
	at jadx.core.dex.visitors.EnumVisitor.visit(EnumVisitor.java:100)
 */
/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* renamed from: o.vz, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class EnumC2093vz {
    public static final EnumC2093vz Dt;
    public static final EnumC2093vz ETF;
    public static final EnumC2093vz IEE;
    public static final EnumC2093vz JHa;
    public static final EnumC2093vz KLFTb;
    public static final EnumC2093vz MiMN;
    public static final EnumC2093vz Pq;
    public static final EnumC2093vz VA;
    public static final EnumC2093vz YoKzxo;
    public static final EnumC2093vz ZfxDd;
    public static final EnumC2093vz diqgf;
    public static final /* synthetic */ EnumC2093vz[] eyqo;
    public static final EnumC2093vz fehf;
    public static final EnumC2093vz lgHUyS;
    public static final EnumC2093vz qGY;
    public static final EnumC2093vz qdMbNW;
    public static final EnumC2093vz rkYL;
    public static final EnumC2093vz wA;
    public static final EnumC2093vz xJ;
    public final int AZxh;
    public final EnumC2153wz mjFkc;

    static {
        EnumC2093vz enumC2093vz = new EnumC2093vz("DOUBLE", 0, EnumC2153wz.DOUBLE, 1);
        wA = enumC2093vz;
        EnumC2093vz enumC2093vz2 = new EnumC2093vz("FLOAT", 1, EnumC2153wz.FLOAT, 5);
        ZfxDd = enumC2093vz2;
        EnumC2153wz enumC2153wz = EnumC2153wz.LONG;
        EnumC2093vz enumC2093vz3 = new EnumC2093vz("INT64", 2, enumC2153wz, 0);
        KLFTb = enumC2093vz3;
        EnumC2093vz enumC2093vz4 = new EnumC2093vz("UINT64", 3, enumC2153wz, 0);
        JHa = enumC2093vz4;
        EnumC2153wz enumC2153wz2 = EnumC2153wz.INT;
        EnumC2093vz enumC2093vz5 = new EnumC2093vz("INT32", 4, enumC2153wz2, 0);
        xJ = enumC2093vz5;
        EnumC2093vz enumC2093vz6 = new EnumC2093vz("FIXED64", 5, enumC2153wz, 1);
        lgHUyS = enumC2093vz6;
        EnumC2093vz enumC2093vz7 = new EnumC2093vz("FIXED32", 6, enumC2153wz2, 5);
        qdMbNW = enumC2093vz7;
        EnumC2093vz enumC2093vz8 = new EnumC2093vz("BOOL", 7, EnumC2153wz.BOOLEAN, 0);
        Dt = enumC2093vz8;
        EnumC2093vz enumC2093vz9 = new EnumC2093vz("STRING", 8, EnumC2153wz.STRING, 2);
        ETF = enumC2093vz9;
        EnumC2153wz enumC2153wz3 = EnumC2153wz.MESSAGE;
        EnumC2093vz enumC2093vz10 = new EnumC2093vz("GROUP", 9, enumC2153wz3, 3);
        VA = enumC2093vz10;
        EnumC2093vz enumC2093vz11 = new EnumC2093vz("MESSAGE", 10, enumC2153wz3, 2);
        MiMN = enumC2093vz11;
        EnumC2093vz enumC2093vz12 = new EnumC2093vz("BYTES", 11, EnumC2153wz.BYTE_STRING, 2);
        YoKzxo = enumC2093vz12;
        EnumC2093vz enumC2093vz13 = new EnumC2093vz("UINT32", 12, enumC2153wz2, 0);
        rkYL = enumC2093vz13;
        EnumC2093vz enumC2093vz14 = new EnumC2093vz("ENUM", 13, EnumC2153wz.ENUM, 0);
        qGY = enumC2093vz14;
        EnumC2093vz enumC2093vz15 = new EnumC2093vz("SFIXED32", 14, enumC2153wz2, 5);
        fehf = enumC2093vz15;
        EnumC2093vz enumC2093vz16 = new EnumC2093vz("SFIXED64", 15, enumC2153wz, 1);
        IEE = enumC2093vz16;
        EnumC2093vz enumC2093vz17 = new EnumC2093vz("SINT32", 16, enumC2153wz2, 0);
        Pq = enumC2093vz17;
        EnumC2093vz enumC2093vz18 = new EnumC2093vz("SINT64", 17, enumC2153wz, 0);
        diqgf = enumC2093vz18;
        eyqo = new EnumC2093vz[]{enumC2093vz, enumC2093vz2, enumC2093vz3, enumC2093vz4, enumC2093vz5, enumC2093vz6, enumC2093vz7, enumC2093vz8, enumC2093vz9, enumC2093vz10, enumC2093vz11, enumC2093vz12, enumC2093vz13, enumC2093vz14, enumC2093vz15, enumC2093vz16, enumC2093vz17, enumC2093vz18};
    }

    public EnumC2093vz(String str, int i, EnumC2153wz enumC2153wz, int i2) {
        this.mjFkc = enumC2153wz;
        this.AZxh = i2;
    }

    public static EnumC2093vz[] values() {
        return (EnumC2093vz[]) eyqo.clone();
    }

    public final EnumC2153wz KLFTb() {
        return this.mjFkc;
    }

    public final int mjFkc() {
        return this.AZxh;
    }
}
