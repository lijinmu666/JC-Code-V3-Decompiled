package o;

import android.os.Parcelable;

/* loaded from: classes.dex */
public abstract class sjsh implements Parcelable {
}
