package o;

import org.conscrypt.BuildConfig;

/* renamed from: o.Nw, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0492Nw extends AbstractC1010dy implements Ly {
    private static final C0492Nw zbb;
    private int zbd;
    private String zbe = BuildConfig.FLAVOR;
    private double zbf = 1.0d;
    private InterfaceC1491ly zbg = AbstractC1010dy.wJVbdd();

    static {
        C0492Nw c0492Nw = new C0492Nw();
        zbb = c0492Nw;
        AbstractC1010dy.YoKzxo(C0492Nw.class, c0492Nw);
    }

    @Override // o.AbstractC1010dy
    public final Object IEE(int i, Object obj, Object obj2) {
        int i2 = i - 1;
        if (i2 == 0) {
            return (byte) 1;
        }
        if (i2 == 2) {
            return AbstractC1010dy.ETF(zbb, "\u0001\u0003\u0000\u0001\u0001\u000f\u0003\u0000\u0001\u0000\u0001ဈ\u0000\u0002က\u0001\u000f\u001a", new Object[]{"zbd", "zbe", "zbf", "zbg"});
        }
        if (i2 == 3) {
            return new C0492Nw();
        }
        AbstractC0446Lw abstractC0446Lw = null;
        if (i2 == 4) {
            return new C0469Mw(abstractC0446Lw);
        }
        if (i2 != 5) {
            return null;
        }
        return zbb;
    }
}
