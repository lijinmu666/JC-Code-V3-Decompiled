package o;

import android.util.Log;
import androidx.fragment.app.Fragment;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import o.C1228ha;

/* loaded from: classes.dex */
public final class bzZHlx extends AbstractC1168ga {
    public static final C1228ha.mjFkc ETF = new mjFkc();
    public final boolean xJ;
    public final HashMap ZfxDd = new HashMap();
    public final HashMap KLFTb = new HashMap();
    public final HashMap JHa = new HashMap();
    public boolean lgHUyS = false;
    public boolean qdMbNW = false;
    public boolean Dt = false;

    public class mjFkc implements C1228ha.mjFkc {
        @Override // o.C1228ha.mjFkc
        public AbstractC1168ga mjFkc(Class cls) {
            return new bzZHlx(true);
        }
    }

    public bzZHlx(boolean z) {
        this.xJ = z;
    }

    @Override // o.AbstractC1168ga
    public void AZxh() {
        if (androidx.fragment.app.KLFTb.dm(3)) {
            Log.d("FragmentManager", "onCleared called for " + this);
        }
        this.lgHUyS = true;
    }

    public boolean Dt(Fragment fragment) {
        if (this.ZfxDd.containsKey(fragment.KLFTb)) {
            return this.xJ ? this.lgHUyS : !this.qdMbNW;
        }
        return true;
    }

    public Collection JHa() {
        return new ArrayList(this.ZfxDd.values());
    }

    public bzZHlx KLFTb(Fragment fragment) {
        bzZHlx bzzhlx = (bzZHlx) this.KLFTb.get(fragment.KLFTb);
        if (bzzhlx != null) {
            return bzzhlx;
        }
        bzZHlx bzzhlx2 = new bzZHlx(this.xJ);
        this.KLFTb.put(fragment.KLFTb, bzzhlx2);
        return bzzhlx2;
    }

    public Fragment ZfxDd(String str) {
        return (Fragment) this.ZfxDd.get(str);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || bzZHlx.class != obj.getClass()) {
            return false;
        }
        bzZHlx bzzhlx = (bzZHlx) obj;
        return this.ZfxDd.equals(bzzhlx.ZfxDd) && this.KLFTb.equals(bzzhlx.KLFTb) && this.JHa.equals(bzzhlx.JHa);
    }

    public int hashCode() {
        return (((this.ZfxDd.hashCode() * 31) + this.KLFTb.hashCode()) * 31) + this.JHa.hashCode();
    }

    public void lgHUyS(Fragment fragment) {
        if (this.Dt) {
            if (androidx.fragment.app.KLFTb.dm(2)) {
                Log.v("FragmentManager", "Ignoring removeRetainedFragment as the state is already saved");
            }
        } else {
            if (this.ZfxDd.remove(fragment.KLFTb) == null || !androidx.fragment.app.KLFTb.dm(2)) {
                return;
            }
            Log.v("FragmentManager", "Updating retained Fragments: Removed " + fragment);
        }
    }

    public void qdMbNW(boolean z) {
        this.Dt = z;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder("FragmentManagerViewModel{");
        sb.append(Integer.toHexString(System.identityHashCode(this)));
        sb.append("} Fragments (");
        Iterator it = this.ZfxDd.values().iterator();
        while (it.hasNext()) {
            sb.append(it.next());
            if (it.hasNext()) {
                sb.append(", ");
            }
        }
        sb.append(") Child Non Config (");
        Iterator it2 = this.KLFTb.keySet().iterator();
        while (it2.hasNext()) {
            sb.append((String) it2.next());
            if (it2.hasNext()) {
                sb.append(", ");
            }
        }
        sb.append(") ViewModelStores (");
        Iterator it3 = this.JHa.keySet().iterator();
        while (it3.hasNext()) {
            sb.append((String) it3.next());
            if (it3.hasNext()) {
                sb.append(", ");
            }
        }
        sb.append(')');
        return sb.toString();
    }

    public void wA(Fragment fragment) {
        if (this.Dt) {
            if (androidx.fragment.app.KLFTb.dm(2)) {
                Log.v("FragmentManager", "Ignoring addRetainedFragment as the state is already saved");
            }
        } else {
            if (this.ZfxDd.containsKey(fragment.KLFTb)) {
                return;
            }
            this.ZfxDd.put(fragment.KLFTb, fragment);
            if (androidx.fragment.app.KLFTb.dm(2)) {
                Log.v("FragmentManager", "Updating retained Fragments: Added " + fragment);
            }
        }
    }

    public C1288ia xJ(Fragment fragment) {
        C1288ia c1288ia = (C1288ia) this.JHa.get(fragment.KLFTb);
        if (c1288ia != null) {
            return c1288ia;
        }
        C1288ia c1288ia2 = new C1288ia();
        this.JHa.put(fragment.KLFTb, c1288ia2);
        return c1288ia2;
    }
}
