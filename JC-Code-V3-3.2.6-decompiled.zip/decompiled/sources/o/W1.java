package o;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.view.MenuItem;

/* loaded from: classes.dex */
public abstract class W1 {

    public static class mjFkc {
        public static CharSequence AZxh(MenuItem menuItem) {
            return menuItem.getContentDescription();
        }

        public static MenuItem Dt(MenuItem menuItem, PorterDuff.Mode mode) {
            return menuItem.setIconTintMode(mode);
        }

        public static MenuItem ETF(MenuItem menuItem, char c, int i) {
            return menuItem.setNumericShortcut(c, i);
        }

        public static CharSequence JHa(MenuItem menuItem) {
            return menuItem.getTooltipText();
        }

        public static int KLFTb(MenuItem menuItem) {
            return menuItem.getNumericModifiers();
        }

        public static MenuItem MiMN(MenuItem menuItem, CharSequence charSequence) {
            return menuItem.setTooltipText(charSequence);
        }

        public static MenuItem VA(MenuItem menuItem, char c, char c2, int i, int i2) {
            return menuItem.setShortcut(c, c2, i, i2);
        }

        public static PorterDuff.Mode ZfxDd(MenuItem menuItem) {
            return menuItem.getIconTintMode();
        }

        public static MenuItem lgHUyS(MenuItem menuItem, CharSequence charSequence) {
            return menuItem.setContentDescription(charSequence);
        }

        public static int mjFkc(MenuItem menuItem) {
            return menuItem.getAlphabeticModifiers();
        }

        public static MenuItem qdMbNW(MenuItem menuItem, ColorStateList colorStateList) {
            return menuItem.setIconTintList(colorStateList);
        }

        public static ColorStateList wA(MenuItem menuItem) {
            return menuItem.getIconTintList();
        }

        public static MenuItem xJ(MenuItem menuItem, char c, int i) {
            return menuItem.setAlphabeticShortcut(c, i);
        }
    }

    public static void AZxh(MenuItem menuItem, CharSequence charSequence) {
        if (menuItem instanceof InterfaceMenuItemC2162x7) {
            ((InterfaceMenuItemC2162x7) menuItem).setContentDescription(charSequence);
        } else {
            mjFkc.lgHUyS(menuItem, charSequence);
        }
    }

    public static void JHa(MenuItem menuItem, CharSequence charSequence) {
        if (menuItem instanceof InterfaceMenuItemC2162x7) {
            ((InterfaceMenuItemC2162x7) menuItem).setTooltipText(charSequence);
        } else {
            mjFkc.MiMN(menuItem, charSequence);
        }
    }

    public static void KLFTb(MenuItem menuItem, char c, int i) {
        if (menuItem instanceof InterfaceMenuItemC2162x7) {
            ((InterfaceMenuItemC2162x7) menuItem).setNumericShortcut(c, i);
        } else {
            mjFkc.ETF(menuItem, c, i);
        }
    }

    public static void ZfxDd(MenuItem menuItem, PorterDuff.Mode mode) {
        if (menuItem instanceof InterfaceMenuItemC2162x7) {
            ((InterfaceMenuItemC2162x7) menuItem).setIconTintMode(mode);
        } else {
            mjFkc.Dt(menuItem, mode);
        }
    }

    public static void mjFkc(MenuItem menuItem, char c, int i) {
        if (menuItem instanceof InterfaceMenuItemC2162x7) {
            ((InterfaceMenuItemC2162x7) menuItem).setAlphabeticShortcut(c, i);
        } else {
            mjFkc.xJ(menuItem, c, i);
        }
    }

    public static void wA(MenuItem menuItem, ColorStateList colorStateList) {
        if (menuItem instanceof InterfaceMenuItemC2162x7) {
            ((InterfaceMenuItemC2162x7) menuItem).setIconTintList(colorStateList);
        } else {
            mjFkc.qdMbNW(menuItem, colorStateList);
        }
    }
}
