package o;

import android.content.res.Resources;
import android.os.SystemClock;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.AnimationUtils;
import android.view.animation.Interpolator;

/* loaded from: classes.dex */
public abstract class XtE implements View.OnTouchListener {
    public static final int IEE = ViewConfiguration.getTapTimeout();
    public boolean MiMN;
    public boolean VA;
    public boolean YoKzxo;
    public Runnable ZfxDd;
    public boolean fehf;
    public int lgHUyS;
    public boolean qGY;
    public boolean rkYL;
    public final View wA;
    public int xJ;
    public final mjFkc mjFkc = new mjFkc();
    public final Interpolator AZxh = new AccelerateInterpolator();
    public float[] KLFTb = {0.0f, 0.0f};
    public float[] JHa = {Float.MAX_VALUE, Float.MAX_VALUE};
    public float[] qdMbNW = {0.0f, 0.0f};
    public float[] Dt = {0.0f, 0.0f};
    public float[] ETF = {Float.MAX_VALUE, Float.MAX_VALUE};

    public class AZxh implements Runnable {
        public AZxh() {
        }

        @Override // java.lang.Runnable
        public void run() {
            XtE xtE = XtE.this;
            if (xtE.rkYL) {
                if (xtE.MiMN) {
                    xtE.MiMN = false;
                    xtE.mjFkc.MiMN();
                }
                mjFkc mjfkc = XtE.this.mjFkc;
                if (mjfkc.lgHUyS() || !XtE.this.eyqo()) {
                    XtE.this.rkYL = false;
                    return;
                }
                XtE xtE2 = XtE.this;
                if (xtE2.YoKzxo) {
                    xtE2.YoKzxo = false;
                    xtE2.wA();
                }
                mjfkc.mjFkc();
                XtE.this.Dt(mjfkc.AZxh(), mjfkc.wA());
                T9.WGXroI(XtE.this.wA, this);
            }
        }
    }

    public static class mjFkc {
        public int AZxh;
        public float Dt;
        public int ETF;
        public float ZfxDd;
        public int mjFkc;
        public float wA;
        public long KLFTb = Long.MIN_VALUE;
        public long qdMbNW = -1;
        public long JHa = 0;
        public int xJ = 0;
        public int lgHUyS = 0;

        public int AZxh() {
            return this.xJ;
        }

        public void Dt(int i) {
            this.AZxh = i;
        }

        public void ETF(int i) {
            this.mjFkc = i;
        }

        public int JHa() {
            float f = this.ZfxDd;
            return (int) (f / Math.abs(f));
        }

        public final float KLFTb(long j) {
            if (j < this.KLFTb) {
                return 0.0f;
            }
            long j2 = this.qdMbNW;
            if (j2 < 0 || j < j2) {
                return XtE.KLFTb((j - r0) / this.mjFkc, 0.0f, 1.0f) * 0.5f;
            }
            float f = this.Dt;
            return (1.0f - f) + (f * XtE.KLFTb((j - j2) / this.ETF, 0.0f, 1.0f));
        }

        public void MiMN() {
            long jCurrentAnimationTimeMillis = AnimationUtils.currentAnimationTimeMillis();
            this.KLFTb = jCurrentAnimationTimeMillis;
            this.qdMbNW = -1L;
            this.JHa = jCurrentAnimationTimeMillis;
            this.Dt = 0.5f;
            this.xJ = 0;
            this.lgHUyS = 0;
        }

        public void VA(float f, float f2) {
            this.wA = f;
            this.ZfxDd = f2;
        }

        public int ZfxDd() {
            float f = this.wA;
            return (int) (f / Math.abs(f));
        }

        public boolean lgHUyS() {
            return this.qdMbNW > 0 && AnimationUtils.currentAnimationTimeMillis() > this.qdMbNW + ((long) this.ETF);
        }

        public void mjFkc() {
            if (this.JHa == 0) {
                throw new RuntimeException("Cannot compute scroll delta before calling start()");
            }
            long jCurrentAnimationTimeMillis = AnimationUtils.currentAnimationTimeMillis();
            float fXJ = xJ(KLFTb(jCurrentAnimationTimeMillis));
            long j = jCurrentAnimationTimeMillis - this.JHa;
            this.JHa = jCurrentAnimationTimeMillis;
            float f = j * fXJ;
            this.xJ = (int) (this.wA * f);
            this.lgHUyS = (int) (f * this.ZfxDd);
        }

        public void qdMbNW() {
            long jCurrentAnimationTimeMillis = AnimationUtils.currentAnimationTimeMillis();
            this.ETF = XtE.JHa((int) (jCurrentAnimationTimeMillis - this.KLFTb), 0, this.AZxh);
            this.Dt = KLFTb(jCurrentAnimationTimeMillis);
            this.qdMbNW = jCurrentAnimationTimeMillis;
        }

        public int wA() {
            return this.lgHUyS;
        }

        public final float xJ(float f) {
            return ((-4.0f) * f * f) + (f * 4.0f);
        }
    }

    public XtE(View view) {
        this.wA = view;
        float f = Resources.getSystem().getDisplayMetrics().density;
        float f2 = (int) ((1575.0f * f) + 0.5f);
        rkYL(f2, f2);
        float f3 = (int) ((f * 315.0f) + 0.5f);
        qGY(f3, f3);
        VA(1);
        YoKzxo(Float.MAX_VALUE, Float.MAX_VALUE);
        Pq(0.2f, 0.2f);
        diqgf(1.0f, 1.0f);
        ETF(IEE);
        IEE(500);
        fehf(500);
    }

    public static int JHa(int i, int i2, int i3) {
        return i > i3 ? i3 : i < i2 ? i2 : i;
    }

    public static float KLFTb(float f, float f2, float f3) {
        return f > f3 ? f3 : f < f2 ? f2 : f;
    }

    public abstract boolean AZxh(int i);

    public abstract void Dt(int i, int i2);

    public XtE ETF(int i) {
        this.lgHUyS = i;
        return this;
    }

    public XtE IEE(int i) {
        this.mjFkc.ETF(i);
        return this;
    }

    public XtE MiMN(boolean z) {
        if (this.qGY && !z) {
            qdMbNW();
        }
        this.qGY = z;
        return this;
    }

    public XtE Pq(float f, float f2) {
        float[] fArr = this.KLFTb;
        fArr[0] = f;
        fArr[1] = f2;
        return this;
    }

    public final void Ucbh() {
        int i;
        if (this.ZfxDd == null) {
            this.ZfxDd = new AZxh();
        }
        this.rkYL = true;
        this.MiMN = true;
        if (this.VA || (i = this.lgHUyS) <= 0) {
            this.ZfxDd.run();
        } else {
            T9.XV(this.wA, this.ZfxDd, i);
        }
        this.VA = true;
    }

    public XtE VA(int i) {
        this.xJ = i;
        return this;
    }

    public XtE YoKzxo(float f, float f2) {
        float[] fArr = this.JHa;
        fArr[0] = f;
        fArr[1] = f2;
        return this;
    }

    public final float ZfxDd(int i, float f, float f2, float f3) {
        float fLgHUyS = lgHUyS(this.KLFTb[i], f2, this.JHa[i], f);
        if (fLgHUyS == 0.0f) {
            return 0.0f;
        }
        float f4 = this.qdMbNW[i];
        float f5 = this.Dt[i];
        float f6 = this.ETF[i];
        float f7 = f4 * f3;
        return fLgHUyS > 0.0f ? KLFTb(fLgHUyS * f7, f5, f6) : -KLFTb((-fLgHUyS) * f7, f5, f6);
    }

    public XtE diqgf(float f, float f2) {
        float[] fArr = this.qdMbNW;
        fArr[0] = f / 1000.0f;
        fArr[1] = f2 / 1000.0f;
        return this;
    }

    public boolean eyqo() {
        mjFkc mjfkc = this.mjFkc;
        int iJHa = mjfkc.JHa();
        int iZfxDd = mjfkc.ZfxDd();
        return (iJHa != 0 && AZxh(iJHa)) || (iZfxDd != 0 && mjFkc(iZfxDd));
    }

    public XtE fehf(int i) {
        this.mjFkc.Dt(i);
        return this;
    }

    public final float lgHUyS(float f, float f2, float f3, float f4) {
        float interpolation;
        float fKLFTb = KLFTb(f * f2, 0.0f, f3);
        float fXJ = xJ(f2 - f4, fKLFTb) - xJ(f4, fKLFTb);
        if (fXJ < 0.0f) {
            interpolation = -this.AZxh.getInterpolation(-fXJ);
        } else {
            if (fXJ <= 0.0f) {
                return 0.0f;
            }
            interpolation = this.AZxh.getInterpolation(fXJ);
        }
        return KLFTb(interpolation, -1.0f, 1.0f);
    }

    public abstract boolean mjFkc(int i);

    /* JADX WARN: Removed duplicated region for block: B:13:0x0016  */
    @Override // android.view.View.OnTouchListener
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public boolean onTouch(View view, MotionEvent motionEvent) {
        if (!this.qGY) {
            return false;
        }
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked != 0) {
            if (actionMasked == 1) {
                qdMbNW();
            } else if (actionMasked != 2) {
                if (actionMasked == 3) {
                }
            }
            return this.fehf && this.rkYL;
        }
        this.YoKzxo = true;
        this.VA = false;
        this.mjFkc.VA(ZfxDd(0, motionEvent.getX(), view.getWidth(), this.wA.getWidth()), ZfxDd(1, motionEvent.getY(), view.getHeight(), this.wA.getHeight()));
        if (!this.rkYL && eyqo()) {
            Ucbh();
        }
        if (this.fehf) {
            return false;
        }
    }

    public XtE qGY(float f, float f2) {
        float[] fArr = this.Dt;
        fArr[0] = f / 1000.0f;
        fArr[1] = f2 / 1000.0f;
        return this;
    }

    public final void qdMbNW() {
        if (this.MiMN) {
            this.rkYL = false;
        } else {
            this.mjFkc.qdMbNW();
        }
    }

    public XtE rkYL(float f, float f2) {
        float[] fArr = this.ETF;
        fArr[0] = f / 1000.0f;
        fArr[1] = f2 / 1000.0f;
        return this;
    }

    public void wA() {
        long jUptimeMillis = SystemClock.uptimeMillis();
        MotionEvent motionEventObtain = MotionEvent.obtain(jUptimeMillis, jUptimeMillis, 3, 0.0f, 0.0f, 0);
        this.wA.onTouchEvent(motionEventObtain);
        motionEventObtain.recycle();
    }

    public final float xJ(float f, float f2) {
        if (f2 == 0.0f) {
            return 0.0f;
        }
        int i = this.xJ;
        if (i == 0 || i == 1) {
            if (f < f2) {
                if (f >= 0.0f) {
                    return 1.0f - (f / f2);
                }
                if (this.rkYL && i == 1) {
                    return 1.0f;
                }
            }
        } else if (i == 2 && f < 0.0f) {
            return f / (-f2);
        }
        return 0.0f;
    }
}
