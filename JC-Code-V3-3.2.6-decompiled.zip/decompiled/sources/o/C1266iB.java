package o;

/* renamed from: o.iB, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C1266iB implements InterfaceC1077f3 {
    public final /* synthetic */ InterfaceC1138g3 mjFkc;

    public C1266iB(C1567nD c1567nD, InterfaceC1138g3 interfaceC1138g3) {
        this.mjFkc = interfaceC1138g3;
    }

    @Override // o.InterfaceC1077f3
    public final /* bridge */ /* synthetic */ void mjFkc(Object obj) {
        this.mjFkc.mjFkc();
    }
}
