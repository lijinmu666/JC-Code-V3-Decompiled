package o;

import android.text.Editable;

/* loaded from: classes.dex */
public final class YDiFPt extends Editable.Factory {
    public static volatile Editable.Factory AZxh;
    public static final Object mjFkc = new Object();
    public static Class wA;

    public YDiFPt() {
        try {
            wA = Class.forName("android.text.DynamicLayout$ChangeWatcher", false, YDiFPt.class.getClassLoader());
        } catch (Throwable unused) {
        }
    }

    public static Editable.Factory getInstance() {
        if (AZxh == null) {
            synchronized (mjFkc) {
                try {
                    if (AZxh == null) {
                        AZxh = new YDiFPt();
                    }
                } finally {
                }
            }
        }
        return AZxh;
    }

    @Override // android.text.Editable.Factory
    public Editable newEditable(CharSequence charSequence) {
        Class cls = wA;
        return cls != null ? C0960d7.wA(cls, charSequence) : super.newEditable(charSequence);
    }
}
