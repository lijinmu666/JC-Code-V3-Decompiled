package o;

/* renamed from: o.ii, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C1295ii extends AbstractC1010dy implements Ly {
    private static final C1295ii zbb;
    private int zbd = 0;
    private Object zbe;
    private float zbf;

    static {
        C1295ii c1295ii = new C1295ii();
        zbb = c1295ii;
        AbstractC1010dy.YoKzxo(C1295ii.class, c1295ii);
    }

    @Override // o.AbstractC1010dy
    public final Object IEE(int i, Object obj, Object obj2) {
        int i2 = i - 1;
        if (i2 == 0) {
            return (byte) 1;
        }
        if (i2 == 2) {
            return AbstractC1010dy.ETF(zbb, "\u0000\u0004\u0001\u0000\u0001\u0004\u0004\u0000\u0000\u0000\u0001?\u0000\u0002Ȼ\u0000\u0003\u0001\u0004<\u0000", new Object[]{"zbe", "zbd", "zbf", C1415ki.class});
        }
        if (i2 == 3) {
            return new C1295ii();
        }
        AbstractC0363Ih abstractC0363Ih = null;
        if (i2 == 4) {
            return new C1236hi(abstractC0363Ih);
        }
        if (i2 != 5) {
            return null;
        }
        return zbb;
    }
}
