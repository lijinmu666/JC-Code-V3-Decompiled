package o;

/* renamed from: o.z5, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public interface InterfaceC2281z5 {
    Object mjFkc(Object obj, Object obj2);
}
