package o;

/* renamed from: o.xs, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC2206xs {
}
