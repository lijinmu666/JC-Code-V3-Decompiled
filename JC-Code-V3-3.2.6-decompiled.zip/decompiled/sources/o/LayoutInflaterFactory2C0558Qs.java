package o;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentContainerView;

/* renamed from: o.Qs, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public class LayoutInflaterFactory2C0558Qs implements LayoutInflater.Factory2 {
    public final androidx.fragment.app.KLFTb mjFkc;

    public LayoutInflaterFactory2C0558Qs(androidx.fragment.app.KLFTb kLFTb) {
        this.mjFkc = kLFTb;
    }

    @Override // android.view.LayoutInflater.Factory
    public View onCreateView(String str, Context context, AttributeSet attributeSet) {
        return onCreateView(null, str, context, attributeSet);
    }

    @Override // android.view.LayoutInflater.Factory2
    public View onCreateView(View view, String str, Context context, AttributeSet attributeSet) {
        if (FragmentContainerView.class.getName().equals(str)) {
            return new FragmentContainerView(context, attributeSet, this.mjFkc);
        }
        if (!"fragment".equals(str)) {
            return null;
        }
        String attributeValue = attributeSet.getAttributeValue(null, "class");
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, Y4.ZfxDd);
        if (attributeValue == null) {
            attributeValue = typedArrayObtainStyledAttributes.getString(Y4.KLFTb);
        }
        int resourceId = typedArrayObtainStyledAttributes.getResourceId(Y4.JHa, -1);
        String string = typedArrayObtainStyledAttributes.getString(Y4.xJ);
        typedArrayObtainStyledAttributes.recycle();
        if (attributeValue == null || !AbstractC0853bL.AZxh(context.getClassLoader(), attributeValue)) {
            return null;
        }
        int id = view != null ? view.getId() : 0;
        if (id == -1 && resourceId == -1 && string == null) {
            throw new IllegalArgumentException(attributeSet.getPositionDescription() + ": Must specify unique android:id, android:tag, or have a parent with an id for " + attributeValue);
        }
        Fragment fragmentOCFDzJ = resourceId != -1 ? this.mjFkc.oCFDzJ(resourceId) : null;
        if (fragmentOCFDzJ == null && string != null) {
            fragmentOCFDzJ = this.mjFkc.aqHPIZ(string);
        }
        if (fragmentOCFDzJ == null && id != -1) {
            fragmentOCFDzJ = this.mjFkc.oCFDzJ(id);
        }
        if (fragmentOCFDzJ == null) {
            Fragment fragmentMjFkc = this.mjFkc.JYgkl().mjFkc(context.getClassLoader(), attributeValue);
            fragmentMjFkc.VA = true;
            if (resourceId == 0) {
                resourceId = id;
            }
            fragmentMjFkc.diqgf = resourceId;
            fragmentMjFkc.eyqo = id;
            fragmentMjFkc.Ucbh = string;
            fragmentMjFkc.MiMN = true;
            androidx.fragment.app.KLFTb kLFTb = this.mjFkc;
            fragmentMjFkc.fehf = kLFTb;
            kLFTb.nxI();
            this.mjFkc.nxI();
            throw null;
        }
        if (!fragmentOCFDzJ.MiMN) {
            fragmentOCFDzJ.MiMN = true;
            androidx.fragment.app.KLFTb kLFTb2 = this.mjFkc;
            fragmentOCFDzJ.fehf = kLFTb2;
            kLFTb2.nxI();
            this.mjFkc.nxI();
            throw null;
        }
        throw new IllegalArgumentException(attributeSet.getPositionDescription() + ": Duplicate id 0x" + Integer.toHexString(resourceId) + ", tag " + string + ", or parent id 0x" + Integer.toHexString(id) + " with another fragment for " + attributeValue);
    }
}
