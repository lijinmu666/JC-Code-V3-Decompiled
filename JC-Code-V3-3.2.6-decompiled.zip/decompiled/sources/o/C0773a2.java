package o;

import android.content.ComponentName;
import android.content.Context;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.os.Bundle;
import android.util.Log;
import com.google.android.datatransport.runtime.backends.TransportBackendDiscovery;
import java.lang.reflect.InvocationTargetException;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/* renamed from: o.a2, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public class C0773a2 implements tAfC {
    public final GaZ AZxh;
    public final mjFkc mjFkc;
    public final Map wA;

    /* renamed from: o.a2$mjFkc */
    public static class mjFkc {
        public Map AZxh = null;
        public final Context mjFkc;

        public mjFkc(Context context) {
            this.mjFkc = context;
        }

        public static Bundle ZfxDd(Context context) throws PackageManager.NameNotFoundException {
            try {
                PackageManager packageManager = context.getPackageManager();
                if (packageManager == null) {
                    Log.w("BackendRegistry", "Context has no PackageManager.");
                    return null;
                }
                ServiceInfo serviceInfo = packageManager.getServiceInfo(new ComponentName(context, (Class<?>) TransportBackendDiscovery.class), 128);
                if (serviceInfo != null) {
                    return serviceInfo.metaData;
                }
                Log.w("BackendRegistry", "TransportBackendDiscovery has no service info.");
                return null;
            } catch (PackageManager.NameNotFoundException unused) {
                Log.w("BackendRegistry", "Application info not found.");
                return null;
            }
        }

        public IyS AZxh(String str) {
            String str2 = (String) wA().get(str);
            if (str2 == null) {
                return null;
            }
            try {
                return (IyS) Class.forName(str2).asSubclass(IyS.class).getDeclaredConstructor(null).newInstance(null);
            } catch (ClassNotFoundException e) {
                Log.w("BackendRegistry", String.format("Class %s is not found.", str2), e);
                return null;
            } catch (IllegalAccessException e2) {
                Log.w("BackendRegistry", String.format("Could not instantiate %s.", str2), e2);
                return null;
            } catch (InstantiationException e3) {
                Log.w("BackendRegistry", String.format("Could not instantiate %s.", str2), e3);
                return null;
            } catch (NoSuchMethodException e4) {
                Log.w("BackendRegistry", String.format("Could not instantiate %s", str2), e4);
                return null;
            } catch (InvocationTargetException e5) {
                Log.w("BackendRegistry", String.format("Could not instantiate %s", str2), e5);
                return null;
            }
        }

        public final Map mjFkc(Context context) throws PackageManager.NameNotFoundException {
            Bundle bundleZfxDd = ZfxDd(context);
            if (bundleZfxDd == null) {
                Log.w("BackendRegistry", "Could not retrieve metadata, returning empty list of transport backends.");
                return Collections.emptyMap();
            }
            HashMap map = new HashMap();
            for (String str : bundleZfxDd.keySet()) {
                Object obj = bundleZfxDd.get(str);
                if ((obj instanceof String) && str.startsWith("backend:")) {
                    for (String str2 : ((String) obj).split(",", -1)) {
                        String strTrim = str2.trim();
                        if (!strTrim.isEmpty()) {
                            map.put(strTrim, str.substring(8));
                        }
                    }
                }
            }
            return map;
        }

        public final Map wA() {
            if (this.AZxh == null) {
                this.AZxh = mjFkc(this.mjFkc);
            }
            return this.AZxh;
        }
    }

    public C0773a2(Context context, GaZ gaZ) {
        this(new mjFkc(context), gaZ);
    }

    @Override // o.tAfC
    public synchronized W8 get(String str) {
        if (this.wA.containsKey(str)) {
            return (W8) this.wA.get(str);
        }
        IyS iySAZxh = this.mjFkc.AZxh(str);
        if (iySAZxh == null) {
            return null;
        }
        W8 w8Create = iySAZxh.create(this.AZxh.mjFkc(str));
        this.wA.put(str, w8Create);
        return w8Create;
    }

    public C0773a2(mjFkc mjfkc, GaZ gaZ) {
        this.wA = new HashMap();
        this.mjFkc = mjfkc;
        this.AZxh = gaZ;
    }
}
