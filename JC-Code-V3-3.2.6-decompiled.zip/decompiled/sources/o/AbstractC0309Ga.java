package o;

/* renamed from: o.Ga, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC0309Ga {

    /* renamed from: o.Ga$mjFkc */
    public static abstract class mjFkc {
        public abstract mjFkc AZxh(boolean z);

        public abstract mjFkc ZfxDd(String str);

        public abstract AbstractC0309Ga mjFkc();

        public abstract mjFkc wA(String str);
    }

    public static mjFkc mjFkc(String str, String str2, String str3) {
        C1240hm c1240hm = new C1240hm();
        c1240hm.KLFTb(str);
        if (str2 == null) {
            str2 = "mlkit-google-ocr-models";
        }
        c1240hm.ZfxDd(str2);
        c1240hm.wA(str3);
        c1240hm.AZxh(false);
        return c1240hm;
    }

    public abstract String AZxh();

    public abstract boolean KLFTb();

    public abstract String ZfxDd();

    public abstract String wA();
}
