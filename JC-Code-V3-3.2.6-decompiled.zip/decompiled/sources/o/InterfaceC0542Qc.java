package o;

import android.os.IInterface;
import com.google.android.gms.common.api.Status;

/* renamed from: o.Qc, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public interface InterfaceC0542Qc extends IInterface {
    void Pq(Status status, C1795r2 c1795r2);

    void VA(Status status, C1916t2 c1916t2);

    void fehf(Status status);

    void lgHUyS(Status status, C1616o2 c1616o2);
}
