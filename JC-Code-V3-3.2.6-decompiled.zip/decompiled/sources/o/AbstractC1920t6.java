package o;

import android.content.Context;

/* renamed from: o.t6, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC1920t6 {
    public static InterfaceC2250yb mjFkc(Context context, wfQA wfqa, AbstractC1740q6 abstractC1740q6, aDq adq) {
        return new C1135g0(context, wfqa, abstractC1740q6);
    }
}
