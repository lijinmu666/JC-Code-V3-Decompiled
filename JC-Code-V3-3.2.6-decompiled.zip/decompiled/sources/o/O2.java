package o;

/* loaded from: classes.dex */
public abstract /* synthetic */ class O2 {
}
