package o;

import android.os.Bundle;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityNodeProvider;
import java.util.ArrayList;
import java.util.List;

/* loaded from: classes.dex */
public class huTpC {
    public final Object mjFkc;

    public static class AZxh extends mjFkc {
        public AZxh(huTpC hutpc) {
            super(hutpc);
        }

        @Override // android.view.accessibility.AccessibilityNodeProvider
        public void addExtraDataToAccessibilityNodeInfo(int i, AccessibilityNodeInfo accessibilityNodeInfo, String str, Bundle bundle) {
            this.mjFkc.mjFkc(i, Ucbh.XtE(accessibilityNodeInfo), str, bundle);
        }
    }

    public static class mjFkc extends AccessibilityNodeProvider {
        public final huTpC mjFkc;

        public mjFkc(huTpC hutpc) {
            this.mjFkc = hutpc;
        }

        @Override // android.view.accessibility.AccessibilityNodeProvider
        public AccessibilityNodeInfo createAccessibilityNodeInfo(int i) {
            Ucbh ucbhAZxh = this.mjFkc.AZxh(i);
            if (ucbhAZxh == null) {
                return null;
            }
            return ucbhAZxh.XFUzSY();
        }

        @Override // android.view.accessibility.AccessibilityNodeProvider
        public List findAccessibilityNodeInfosByText(String str, int i) {
            List listWA = this.mjFkc.wA(str, i);
            if (listWA == null) {
                return null;
            }
            ArrayList arrayList = new ArrayList();
            int size = listWA.size();
            for (int i2 = 0; i2 < size; i2++) {
                arrayList.add(((Ucbh) listWA.get(i2)).XFUzSY());
            }
            return arrayList;
        }

        @Override // android.view.accessibility.AccessibilityNodeProvider
        public AccessibilityNodeInfo findFocus(int i) {
            Ucbh ucbhZfxDd = this.mjFkc.ZfxDd(i);
            if (ucbhZfxDd == null) {
                return null;
            }
            return ucbhZfxDd.XFUzSY();
        }

        @Override // android.view.accessibility.AccessibilityNodeProvider
        public boolean performAction(int i, int i2, Bundle bundle) {
            return this.mjFkc.JHa(i, i2, bundle);
        }
    }

    public huTpC() {
        this.mjFkc = new AZxh(this);
    }

    public Ucbh AZxh(int i) {
        return null;
    }

    public boolean JHa(int i, int i2, Bundle bundle) {
        return false;
    }

    public Object KLFTb() {
        return this.mjFkc;
    }

    public Ucbh ZfxDd(int i) {
        return null;
    }

    public void mjFkc(int i, Ucbh ucbh, String str, Bundle bundle) {
    }

    public List wA(String str, int i) {
        return null;
    }

    public huTpC(Object obj) {
        this.mjFkc = obj;
    }
}
