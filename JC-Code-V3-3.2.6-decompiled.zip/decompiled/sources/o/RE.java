package o;

import o.C0797aQ;

/* loaded from: classes.dex */
public final class RE implements R2 {
    public static final C0797aQ AZxh;
    public static final C0797aQ KLFTb;
    public static final C0797aQ ZfxDd;
    public static final RE mjFkc = new RE();
    public static final C0797aQ wA;

    static {
        C0797aQ.AZxh aZxhMjFkc = C0797aQ.mjFkc("errorCode");
        OB ob = new OB();
        ob.mjFkc(1);
        AZxh = aZxhMjFkc.AZxh(ob.AZxh()).mjFkc();
        C0797aQ.AZxh aZxhMjFkc2 = C0797aQ.mjFkc("isColdCall");
        OB ob2 = new OB();
        ob2.mjFkc(2);
        wA = aZxhMjFkc2.AZxh(ob2.AZxh()).mjFkc();
        C0797aQ.AZxh aZxhMjFkc3 = C0797aQ.mjFkc("imageInfo");
        OB ob3 = new OB();
        ob3.mjFkc(3);
        ZfxDd = aZxhMjFkc3.AZxh(ob3.AZxh()).mjFkc();
        C0797aQ.AZxh aZxhMjFkc4 = C0797aQ.mjFkc("detectorOptions");
        OB ob4 = new OB();
        ob4.mjFkc(4);
        KLFTb = aZxhMjFkc4.AZxh(ob4.AZxh()).mjFkc();
    }

    @Override // o.mYYU
    public final /* bridge */ /* synthetic */ void mjFkc(Object obj, Object obj2) {
        AbstractC2102w7.mjFkc(obj);
        throw null;
    }
}
