package o;

import java.util.Objects;

/* renamed from: o.ct, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0945ct extends AbstractC0627Ts {
    public static final AbstractC0627Ts KLFTb = new C0945ct(new Object[0], 0);
    public final transient int ZfxDd;
    public final transient Object[] wA;

    public C0945ct(Object[] objArr, int i) {
        this.wA = objArr;
        this.ZfxDd = i;
    }

    @Override // o.AbstractC0511Os
    public final int JHa() {
        return 0;
    }

    @Override // o.AbstractC0511Os
    public final int ZfxDd() {
        return this.ZfxDd;
    }

    @Override // java.util.List
    public final Object get(int i) {
        AbstractC0258Ds.mjFkc(i, this.ZfxDd, "index");
        Object obj = this.wA[i];
        Objects.requireNonNull(obj);
        return obj;
    }

    @Override // o.AbstractC0627Ts, o.AbstractC0511Os
    public final int mjFkc(Object[] objArr, int i) {
        System.arraycopy(this.wA, 0, objArr, 0, this.ZfxDd);
        return this.ZfxDd;
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.List
    public final int size() {
        return this.ZfxDd;
    }

    @Override // o.AbstractC0511Os
    public final Object[] xJ() {
        return this.wA;
    }
}
