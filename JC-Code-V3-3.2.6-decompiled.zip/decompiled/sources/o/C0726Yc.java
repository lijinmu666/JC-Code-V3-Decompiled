package o;

import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;

/* renamed from: o.Yc, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0726Yc extends AbstractC0448Mb implements IInterface {
    public C0726Yc(IBinder iBinder) {
        super(iBinder, "com.google.android.gms.signin.internal.ISignInService");
    }

    public final void Ucbh(C1350jd c1350jd, InterfaceC0611Tc interfaceC0611Tc) {
        Parcel parcelZfxDd = ZfxDd();
        AbstractC2070vc.wA(parcelZfxDd, c1350jd);
        AbstractC2070vc.ZfxDd(parcelZfxDd, interfaceC0611Tc);
        KLFTb(12, parcelZfxDd);
    }
}
