package o;

/* renamed from: o.Al, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0182Al extends AbstractC1010dy implements Ly {
    private static final C0182Al zbb;
    private int zbd;
    private int zbe;
    private int zbf;
    private int zbg;
    private boolean zbh;
    private int zbi;
    private boolean zbj;
    private int zbk;

    static {
        C0182Al c0182Al = new C0182Al();
        zbb = c0182Al;
        AbstractC1010dy.YoKzxo(C0182Al.class, c0182Al);
    }

    @Override // o.AbstractC1010dy
    public final Object IEE(int i, Object obj, Object obj2) {
        int i2 = i - 1;
        if (i2 == 0) {
            return (byte) 1;
        }
        if (i2 == 2) {
            return AbstractC1010dy.ETF(zbb, "\u0001\u0007\u0000\u0001\u0001\u0007\u0007\u0000\u0000\u0000\u0001င\u0000\u0002င\u0001\u0003င\u0002\u0004ဇ\u0003\u0005င\u0004\u0006ဇ\u0005\u0007င\u0006", new Object[]{"zbd", "zbe", "zbf", "zbg", "zbh", "zbi", "zbj", "zbk"});
        }
        if (i2 == 3) {
            return new C0182Al();
        }
        AbstractC2139wl abstractC2139wl = null;
        if (i2 == 4) {
            return new C2260yl(abstractC2139wl);
        }
        if (i2 != 5) {
            return null;
        }
        return zbb;
    }
}
