package o;

/* renamed from: o.Er, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0280Er extends Vx implements Ly {
    public /* synthetic */ C0280Er(AbstractC0257Dr abstractC0257Dr) {
        super(C0303Fr.zbb);
    }
}
