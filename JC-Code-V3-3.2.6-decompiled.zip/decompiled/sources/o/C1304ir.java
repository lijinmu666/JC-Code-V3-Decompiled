package o;

/* renamed from: o.ir, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C1304ir extends Vx implements Ly {
    public /* synthetic */ C1304ir(AbstractC0943cr abstractC0943cr) {
        super(C1364jr.zbb);
    }
}
