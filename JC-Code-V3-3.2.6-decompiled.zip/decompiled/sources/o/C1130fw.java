package o;

import org.conscrypt.BuildConfig;

/* renamed from: o.fw, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C1130fw extends Zx implements Ly {
    private static final C1130fw zbd;
    private int zbA;
    private float zbB;
    private boolean zbC;
    private int zbD;
    private int zbe;
    private C0400Jv zbg;
    private C0400Jv zbh;
    private C0400Jv zbi;
    private float zbk;
    private float zbn;
    private boolean zbp;
    private int zbr;
    private int zbs;
    private boolean zbt;
    private C0722Xv zbu;
    private boolean zbv;
    private int zbw;
    private int zbx;
    private int zby;
    private C0585Rw zbz;
    private byte zbE = 2;
    private InterfaceC1491ly zbf = AbstractC1010dy.wJVbdd();
    private String zbj = BuildConfig.FLAVOR;
    private InterfaceC1491ly zbl = AbstractC1010dy.wJVbdd();
    private InterfaceC1491ly zbm = AbstractC1010dy.wJVbdd();
    private String zbo = BuildConfig.FLAVOR;
    private InterfaceC1491ly zbq = AbstractC1010dy.wJVbdd();

    static {
        C1130fw c1130fw = new C1130fw();
        zbd = c1130fw;
        AbstractC1010dy.YoKzxo(C1130fw.class, c1130fw);
    }

    @Override // o.AbstractC1010dy
    public final Object IEE(int i, Object obj, Object obj2) {
        int i2 = i - 1;
        if (i2 == 0) {
            return Byte.valueOf(this.zbE);
        }
        if (i2 == 2) {
            return AbstractC1010dy.ETF(zbd, "\u0001\u0019\u0000\u0001\u0001d\u0019\u0000\u0004\u0006\u0001Л\u0002ᐉ\u0000\u0003ᐉ\u0001\u0004ဈ\u0003\u0005ခ\u0004\u0006\u001b\u0007ခ\u0005\bဈ\u0006\tЛ\nဇ\u0007\u000b\u001b\fင\b\rင\t\u000eဇ\n\u000fᐉ\u000b\u0010ဇ\f\u0011င\r\u0012င\u000e\u0013ᐉ\u0002\u0014င\u000f\u0015ဉ\u0010\u0016᠌\u0011\u0017ခ\u0012\u0018ဇ\u0013dင\u0014", new Object[]{"zbe", "zbf", C0424Kw.class, "zbg", "zbh", "zbj", "zbk", "zbm", C0445Lv.class, "zbn", "zbo", "zbl", C0537Pv.class, "zbp", "zbq", C2029uw.class, "zbr", "zbs", "zbt", "zbu", "zbv", "zbw", "zbx", "zbi", "zby", "zbz", "zbA", AbstractC0198Be.mjFkc(), "zbB", "zbC", "zbD"});
        }
        if (i2 == 3) {
            return new C1130fw();
        }
        AbstractC0353Hv abstractC0353Hv = null;
        if (i2 == 4) {
            return new C1069ew(abstractC0353Hv);
        }
        if (i2 == 5) {
            return zbd;
        }
        this.zbE = obj == null ? (byte) 0 : (byte) 1;
        return null;
    }
}
