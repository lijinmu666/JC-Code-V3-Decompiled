package o;

import android.view.View;

/* loaded from: classes.dex */
public abstract class HBzZAD {
    public static String mjFkc(View view) {
        try {
            return view.getContext().getResources().getResourceEntryName(view.getId());
        } catch (Exception unused) {
            return "UNKNOWN";
        }
    }
}
