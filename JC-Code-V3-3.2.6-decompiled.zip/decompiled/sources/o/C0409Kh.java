package o;

/* renamed from: o.Kh, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0409Kh extends Vx implements Ly {
    public /* synthetic */ C0409Kh(AbstractC0363Ih abstractC0363Ih) {
        super(C0477Nh.zbb);
    }
}
