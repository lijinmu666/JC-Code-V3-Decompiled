package o;

import android.app.Activity;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.content.res.XmlResourceParser;
import android.graphics.PorterDuff;
import android.util.AttributeSet;
import android.util.Log;
import android.util.Xml;
import android.view.InflateException;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import org.bouncycastle.crypto.digests.Blake2xsDigest;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

/* renamed from: o.v7, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public class C2041v7 extends MenuInflater {
    public static final Class[] JHa;
    public static final Class[] KLFTb;
    public final Object[] AZxh;
    public Object ZfxDd;
    public final Object[] mjFkc;
    public Context wA;

    /* renamed from: o.v7$AZxh */
    public class AZxh {
        public int AZxh;
        public CharSequence BAnRFn;
        public int Dt;
        public CharSequence ETF;
        public String Gd;
        public String HGpJ;
        public int IEE;
        public boolean JHa;
        public int KLFTb;
        public int MiMN;
        public boolean Pq;
        public int Ucbh;
        public CharSequence VA;
        public CharSequence VocHEe;
        public char YoKzxo;
        public int ZfxDd;
        public boolean diqgf;
        public boolean eyqo;
        public int fehf;
        public int huTpC;
        public boolean lgHUyS;
        public Menu mjFkc;
        public char qGY;
        public int qdMbNW;
        public int rkYL;
        public String vI;
        public int wA;
        public boolean xJ;
        public ColorStateList lB = null;
        public PorterDuff.Mode wJVbdd = null;

        public AZxh(Menu menu) {
            this.mjFkc = menu;
            lgHUyS();
        }

        public SubMenu AZxh() {
            this.lgHUyS = true;
            SubMenu subMenuAddSubMenu = this.mjFkc.addSubMenu(this.AZxh, this.qdMbNW, this.Dt, this.ETF);
            qdMbNW(subMenuAddSubMenu.getItem());
            return subMenuAddSubMenu;
        }

        public void JHa(AttributeSet attributeSet) {
            TypedArray typedArrayObtainStyledAttributes = C2041v7.this.wA.obtainStyledAttributes(attributeSet, AbstractC0837b5.giT);
            this.AZxh = typedArrayObtainStyledAttributes.getResourceId(AbstractC0837b5.XD, 0);
            this.wA = typedArrayObtainStyledAttributes.getInt(AbstractC0837b5.Dp, 0);
            this.ZfxDd = typedArrayObtainStyledAttributes.getInt(AbstractC0837b5.fLidf, 0);
            this.KLFTb = typedArrayObtainStyledAttributes.getInt(AbstractC0837b5.hvGY, 0);
            this.JHa = typedArrayObtainStyledAttributes.getBoolean(AbstractC0837b5.gtr, true);
            this.xJ = typedArrayObtainStyledAttributes.getBoolean(AbstractC0837b5.sRqPfw, true);
            typedArrayObtainStyledAttributes.recycle();
        }

        public final Object KLFTb(String str, Class[] clsArr, Object[] objArr) throws NoSuchMethodException, SecurityException {
            try {
                Constructor<?> constructor = Class.forName(str, false, C2041v7.this.wA.getClassLoader()).getConstructor(clsArr);
                constructor.setAccessible(true);
                return constructor.newInstance(objArr);
            } catch (Exception e) {
                Log.w("SupportMenuInflater", "Cannot instantiate class: " + str, e);
                return null;
            }
        }

        public boolean ZfxDd() {
            return this.lgHUyS;
        }

        public void lgHUyS() {
            this.AZxh = 0;
            this.wA = 0;
            this.ZfxDd = 0;
            this.KLFTb = 0;
            this.JHa = true;
            this.xJ = true;
        }

        public void mjFkc() {
            this.lgHUyS = true;
            qdMbNW(this.mjFkc.add(this.AZxh, this.qdMbNW, this.Dt, this.ETF));
        }

        public final void qdMbNW(MenuItem menuItem) {
            boolean z = false;
            menuItem.setChecked(this.Pq).setVisible(this.diqgf).setEnabled(this.eyqo).setCheckable(this.IEE >= 1).setTitleCondensed(this.VA).setIcon(this.MiMN);
            int i = this.Ucbh;
            if (i >= 0) {
                menuItem.setShowAsAction(i);
            }
            if (this.vI != null) {
                if (C2041v7.this.wA.isRestricted()) {
                    throw new IllegalStateException("The android:onClick attribute cannot be used within a restricted context");
                }
                menuItem.setOnMenuItemClickListener(new mjFkc(C2041v7.this.AZxh(), this.vI));
            }
            if (this.IEE >= 2 && (menuItem instanceof androidx.appcompat.view.menu.KLFTb)) {
                ((androidx.appcompat.view.menu.KLFTb) menuItem).Pq(true);
            }
            String str = this.Gd;
            if (str != null) {
                menuItem.setActionView((View) KLFTb(str, C2041v7.KLFTb, C2041v7.this.mjFkc));
                z = true;
            }
            int i2 = this.huTpC;
            if (i2 > 0) {
                if (z) {
                    Log.w("SupportMenuInflater", "Ignoring attribute 'itemActionViewLayout'. Action view already specified.");
                } else {
                    menuItem.setActionView(i2);
                }
            }
            W1.AZxh(menuItem, this.VocHEe);
            W1.JHa(menuItem, this.BAnRFn);
            W1.mjFkc(menuItem, this.YoKzxo, this.rkYL);
            W1.KLFTb(menuItem, this.qGY, this.fehf);
            PorterDuff.Mode mode = this.wJVbdd;
            if (mode != null) {
                W1.ZfxDd(menuItem, mode);
            }
            ColorStateList colorStateList = this.lB;
            if (colorStateList != null) {
                W1.wA(menuItem, colorStateList);
            }
        }

        public final char wA(String str) {
            if (str == null) {
                return (char) 0;
            }
            return str.charAt(0);
        }

        public void xJ(AttributeSet attributeSet) {
            A8 a8Pq = A8.Pq(C2041v7.this.wA, attributeSet, AbstractC0837b5.Rc);
            this.qdMbNW = a8Pq.MiMN(AbstractC0837b5.XDdeP, 0);
            this.Dt = (a8Pq.Dt(AbstractC0837b5.jtz, this.wA) & (-65536)) | (a8Pq.Dt(AbstractC0837b5.XgAT, this.ZfxDd) & Blake2xsDigest.UNKNOWN_DIGEST_LENGTH);
            this.ETF = a8Pq.rkYL(AbstractC0837b5.IyS);
            this.VA = a8Pq.rkYL(AbstractC0837b5.tAfC);
            this.MiMN = a8Pq.MiMN(AbstractC0837b5.SKTn, 0);
            this.YoKzxo = wA(a8Pq.YoKzxo(AbstractC0837b5.dGDT));
            this.rkYL = a8Pq.Dt(AbstractC0837b5.NV, 4096);
            this.qGY = wA(a8Pq.YoKzxo(AbstractC0837b5.Xxz));
            this.fehf = a8Pq.Dt(AbstractC0837b5.knzZ, 4096);
            if (a8Pq.fehf(AbstractC0837b5.Zdbk)) {
                this.IEE = a8Pq.mjFkc(AbstractC0837b5.Zdbk, false) ? 1 : 0;
            } else {
                this.IEE = this.KLFTb;
            }
            this.Pq = a8Pq.mjFkc(AbstractC0837b5.eQ, false);
            this.diqgf = a8Pq.mjFkc(AbstractC0837b5.FbxKQm, this.JHa);
            this.eyqo = a8Pq.mjFkc(AbstractC0837b5.rdJr, this.xJ);
            this.Ucbh = a8Pq.Dt(AbstractC0837b5.ybBTr, -1);
            this.vI = a8Pq.YoKzxo(AbstractC0837b5.Jk);
            this.huTpC = a8Pq.MiMN(AbstractC0837b5.KRckQg, 0);
            this.Gd = a8Pq.YoKzxo(AbstractC0837b5.dkKKW);
            String strYoKzxo = a8Pq.YoKzxo(AbstractC0837b5.mPWV);
            this.HGpJ = strYoKzxo;
            boolean z = strYoKzxo != null;
            if (z && this.huTpC == 0 && this.Gd == null) {
                AbstractC2102w7.mjFkc(KLFTb(strYoKzxo, C2041v7.JHa, C2041v7.this.AZxh));
            } else if (z) {
                Log.w("SupportMenuInflater", "Ignoring attribute 'actionProviderClass'. Action view already specified.");
            }
            this.VocHEe = a8Pq.rkYL(AbstractC0837b5.Jidt);
            this.BAnRFn = a8Pq.rkYL(AbstractC0837b5.sqndV);
            if (a8Pq.fehf(AbstractC0837b5.APn)) {
                this.wJVbdd = awnh.ZfxDd(a8Pq.Dt(AbstractC0837b5.APn, -1), this.wJVbdd);
            } else {
                this.wJVbdd = null;
            }
            if (a8Pq.fehf(AbstractC0837b5.IvRQOa)) {
                this.lB = a8Pq.wA(AbstractC0837b5.IvRQOa);
            } else {
                this.lB = null;
            }
            a8Pq.eyqo();
            this.lgHUyS = false;
        }
    }

    /* renamed from: o.v7$mjFkc */
    public static class mjFkc implements MenuItem.OnMenuItemClickListener {
        public static final Class[] wA = {MenuItem.class};
        public Method AZxh;
        public Object mjFkc;

        public mjFkc(Object obj, String str) {
            this.mjFkc = obj;
            Class<?> cls = obj.getClass();
            try {
                this.AZxh = cls.getMethod(str, wA);
            } catch (Exception e) {
                InflateException inflateException = new InflateException("Couldn't resolve menu item onClick handler " + str + " in class " + cls.getName());
                inflateException.initCause(e);
                throw inflateException;
            }
        }

        @Override // android.view.MenuItem.OnMenuItemClickListener
        public boolean onMenuItemClick(MenuItem menuItem) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException {
            try {
                if (this.AZxh.getReturnType() == Boolean.TYPE) {
                    return ((Boolean) this.AZxh.invoke(this.mjFkc, menuItem)).booleanValue();
                }
                this.AZxh.invoke(this.mjFkc, menuItem);
                return true;
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }
    }

    static {
        Class[] clsArr = {Context.class};
        KLFTb = clsArr;
        JHa = clsArr;
    }

    public C2041v7(Context context) {
        super(context);
        this.wA = context;
        Object[] objArr = {context};
        this.mjFkc = objArr;
        this.AZxh = objArr;
    }

    public Object AZxh() {
        if (this.ZfxDd == null) {
            this.ZfxDd = mjFkc(this.wA);
        }
        return this.ZfxDd;
    }

    @Override // android.view.MenuInflater
    public void inflate(int i, Menu menu) {
        if (!(menu instanceof InterfaceMenuC1981u7)) {
            super.inflate(i, menu);
            return;
        }
        XmlResourceParser layout = null;
        try {
            try {
                try {
                    layout = this.wA.getResources().getLayout(i);
                    wA(layout, Xml.asAttributeSet(layout), menu);
                } catch (IOException e) {
                    throw new InflateException("Error inflating menu XML", e);
                }
            } catch (XmlPullParserException e2) {
                throw new InflateException("Error inflating menu XML", e2);
            }
        } finally {
            if (layout != null) {
                layout.close();
            }
        }
    }

    public final Object mjFkc(Object obj) {
        return (!(obj instanceof Activity) && (obj instanceof ContextWrapper)) ? mjFkc(((ContextWrapper) obj).getBaseContext()) : obj;
    }

    public final void wA(XmlPullParser xmlPullParser, AttributeSet attributeSet, Menu menu) throws XmlPullParserException, IOException {
        AZxh aZxh = new AZxh(menu);
        int eventType = xmlPullParser.getEventType();
        while (true) {
            if (eventType == 2) {
                String name = xmlPullParser.getName();
                if (!name.equals("menu")) {
                    throw new RuntimeException("Expecting menu, got " + name);
                }
                eventType = xmlPullParser.next();
            } else {
                eventType = xmlPullParser.next();
                if (eventType == 1) {
                    break;
                }
            }
        }
        boolean z = false;
        boolean z2 = false;
        String str = null;
        while (!z) {
            if (eventType == 1) {
                throw new RuntimeException("Unexpected end of document");
            }
            if (eventType != 2) {
                if (eventType == 3) {
                    String name2 = xmlPullParser.getName();
                    if (z2 && name2.equals(str)) {
                        z2 = false;
                        str = null;
                    } else if (name2.equals("group")) {
                        aZxh.lgHUyS();
                    } else if (name2.equals("item")) {
                        if (!aZxh.ZfxDd()) {
                            aZxh.mjFkc();
                        }
                    } else if (name2.equals("menu")) {
                        z = true;
                    }
                }
            } else if (!z2) {
                String name3 = xmlPullParser.getName();
                if (name3.equals("group")) {
                    aZxh.JHa(attributeSet);
                } else if (name3.equals("item")) {
                    aZxh.xJ(attributeSet);
                } else if (name3.equals("menu")) {
                    wA(xmlPullParser, attributeSet, aZxh.AZxh());
                } else {
                    str = name3;
                    z2 = true;
                }
            }
            eventType = xmlPullParser.next();
        }
    }
}
