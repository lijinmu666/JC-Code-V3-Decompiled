package o;

import org.conscrypt.BuildConfig;

/* renamed from: o.vh, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C2075vh extends AbstractC1010dy implements Ly {
    private static final C2075vh zbb;
    private int zbd;
    private long zbe;
    private int zbh;
    private int zbi;
    private C1594nh zbl;
    private AbstractC2272yx zbm;
    private C0339Hh zbn;
    private String zbo;
    private InterfaceC1491ly zbp;
    private InterfaceC1491ly zbq;
    private AbstractC2272yx zbr;
    private String zbs;
    private byte zbt = 2;
    private String zbf = BuildConfig.FLAVOR;
    private String zbg = BuildConfig.FLAVOR;
    private InterfaceC1491ly zbj = AbstractC1010dy.wJVbdd();
    private String zbk = BuildConfig.FLAVOR;

    static {
        C2075vh c2075vh = new C2075vh();
        zbb = c2075vh;
        AbstractC1010dy.YoKzxo(C2075vh.class, c2075vh);
    }

    public C2075vh() {
        AbstractC2272yx abstractC2272yx = AbstractC2272yx.AZxh;
        this.zbm = abstractC2272yx;
        this.zbo = BuildConfig.FLAVOR;
        this.zbp = AbstractC1010dy.wJVbdd();
        this.zbq = AbstractC1010dy.wJVbdd();
        this.zbr = abstractC2272yx;
        this.zbs = BuildConfig.FLAVOR;
    }

    @Override // o.AbstractC1010dy
    public final Object IEE(int i, Object obj, Object obj2) {
        int i2 = i - 1;
        if (i2 == 0) {
            return Byte.valueOf(this.zbt);
        }
        if (i2 == 2) {
            return AbstractC1010dy.ETF(zbb, "\u0001\u000f\u0000\u0001\u0001\u001c\u000f\u0000\u0003\u0004\u0001ᔂ\u0000\u0002б\u0010ဈ\u0001\u0011ဈ\u0002\u0012င\u0003\u0013င\u0004\u0014\u001a\u0015ဈ\u0005\u0016ည\u0007\u0017ᐉ\b\u0018ᐉ\u0006\u0019ည\n\u001aဈ\t\u001bဈ\u000b\u001c\u001b", new Object[]{"zbd", "zbe", "zbp", C2014uh.class, "zbf", "zbg", "zbh", "zbi", "zbj", "zbk", "zbm", "zbn", "zbl", "zbr", "zbo", "zbs", "zbq", C1774qh.class});
        }
        if (i2 == 3) {
            return new C2075vh();
        }
        AbstractC1833rh abstractC1833rh = null;
        if (i2 == 4) {
            return new C1894sh(abstractC1833rh);
        }
        if (i2 == 5) {
            return zbb;
        }
        this.zbt = obj == null ? (byte) 0 : (byte) 1;
        return null;
    }
}
