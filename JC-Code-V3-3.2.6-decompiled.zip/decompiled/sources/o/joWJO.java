package o;

import android.content.ClipData;
import android.view.ContentInfo;

/* loaded from: classes.dex */
public abstract /* synthetic */ class joWJO {
    public static /* synthetic */ ContentInfo.Builder mjFkc(ClipData clipData, int i) {
        return new ContentInfo.Builder(clipData, i);
    }
}
