package o;

import com.google.android.gms.dynamite.DynamiteModule;
import java.util.concurrent.atomic.AtomicReference;

/* renamed from: o.h8, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC1203h8 {
    public static boolean mjFkc(AtomicReference atomicReference, String str) {
        if (atomicReference.get() != null) {
            return ((Boolean) atomicReference.get()).booleanValue();
        }
        boolean z = DynamiteModule.mjFkc(C1315j2.wA().AZxh(), str) > 0;
        atomicReference.set(Boolean.valueOf(z));
        return z;
    }
}
