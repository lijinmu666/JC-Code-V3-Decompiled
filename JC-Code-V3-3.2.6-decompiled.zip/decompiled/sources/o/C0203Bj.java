package o;

/* renamed from: o.Bj, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0203Bj extends Vx implements Ly {
    public /* synthetic */ C0203Bj(AbstractC0180Aj abstractC0180Aj) {
        super(C0226Cj.zbb);
    }
}
