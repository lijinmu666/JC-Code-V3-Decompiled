package o;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.UUID;

/* loaded from: classes.dex */
public class N6 {
    public static final UOnCkw AZxh = UOnCkw.mjFkc(N6.class).AZxh(qqdo.xJ(C1315j2.class)).AZxh(qqdo.xJ(Context.class)).ZfxDd(new Otxclu() { // from class: o.uU
        @Override // o.Otxclu
        public final Object mjFkc(wGscSa wgscsa) {
            return new N6((Context) wgscsa.mjFkc(Context.class));
        }
    }).wA();
    public final Context mjFkc;

    public N6(Context context) {
        this.mjFkc = context;
    }

    public final SharedPreferences AZxh() {
        return this.mjFkc.getSharedPreferences("com.google.mlkit.internal", 0);
    }

    public synchronized String mjFkc() {
        String string = AZxh().getString("ml_sdk_instance_id", null);
        if (string != null) {
            return string;
        }
        String string2 = UUID.randomUUID().toString();
        AZxh().edit().putString("ml_sdk_instance_id", string2).apply();
        return string2;
    }
}
