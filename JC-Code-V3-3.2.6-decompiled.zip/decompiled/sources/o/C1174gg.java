package o;

/* renamed from: o.gg, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C1174gg implements InterfaceC1252hy {
    public static final InterfaceC1252hy mjFkc = new C1174gg();

    @Override // o.InterfaceC1252hy
    public final boolean mjFkc(int i) {
        return i == 0 || i == 1 || i == 2;
    }
}
