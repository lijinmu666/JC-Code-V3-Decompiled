package o;

/* renamed from: o.ek, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C1057ek extends AbstractC1010dy implements Ly {
    private static final C1057ek zbb;
    private int zbd;
    private C0572Rj zbe;
    private double zbf;
    private double zbg;

    static {
        C1057ek c1057ek = new C1057ek();
        zbb = c1057ek;
        AbstractC1010dy.YoKzxo(C1057ek.class, c1057ek);
    }

    @Override // o.AbstractC1010dy
    public final Object IEE(int i, Object obj, Object obj2) {
        int i2 = i - 1;
        if (i2 == 0) {
            return (byte) 1;
        }
        if (i2 == 2) {
            return AbstractC1010dy.ETF(zbb, "\u0000\u0003\u0000\u0001\u0001\u0003\u0003\u0000\u0000\u0000\u0001ဉ\u0000\u0002\u0000\u0003\u0000", new Object[]{"zbd", "zbe", "zbf", "zbg"});
        }
        if (i2 == 3) {
            return new C1057ek();
        }
        AbstractC0936ck abstractC0936ck = null;
        if (i2 == 4) {
            return new C0997dk(abstractC0936ck);
        }
        if (i2 != 5) {
            return null;
        }
        return zbb;
    }
}
