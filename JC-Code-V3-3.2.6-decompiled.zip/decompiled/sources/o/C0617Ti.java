package o;

import org.conscrypt.BuildConfig;

/* renamed from: o.Ti, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0617Ti extends AbstractC1010dy implements Ly {
    private static final C0617Ti zbb;
    private String zbd = BuildConfig.FLAVOR;
    private InterfaceC1491ly zbe = AbstractC1010dy.wJVbdd();

    static {
        C0617Ti c0617Ti = new C0617Ti();
        zbb = c0617Ti;
        AbstractC1010dy.YoKzxo(C0617Ti.class, c0617Ti);
    }

    @Override // o.AbstractC1010dy
    public final Object IEE(int i, Object obj, Object obj2) {
        int i2 = i - 1;
        if (i2 == 0) {
            return (byte) 1;
        }
        if (i2 == 2) {
            return AbstractC1010dy.ETF(zbb, "\u0000\u0002\u0000\u0000\u0001\u0002\u0002\u0000\u0001\u0000\u0001Ȉ\u0002\u001b", new Object[]{"zbd", "zbe", C0755Zi.class});
        }
        if (i2 == 3) {
            return new C0617Ti();
        }
        AbstractC0524Pi abstractC0524Pi = null;
        if (i2 == 4) {
            return new C0594Si(abstractC0524Pi);
        }
        if (i2 != 5) {
            return null;
        }
        return zbb;
    }
}
