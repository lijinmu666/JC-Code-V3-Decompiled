package o;

/* renamed from: o.il, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C1298il extends Vx implements Ly {
    public /* synthetic */ C1298il(AbstractC1179gl abstractC1179gl) {
        super(C1658ol.zbb);
    }

    public final C1298il IEE(C1908sv c1908sv) {
        YoKzxo();
        C1658ol.zvd((C1658ol) this.AZxh, (C1968tv) c1908sv.ZfxDd());
        return this;
    }

    public final C1298il Pq(String str) {
        YoKzxo();
        C1658ol.CqaNbM((C1658ol) this.AZxh, str);
        return this;
    }

    public final C1298il diqgf(boolean z) {
        YoKzxo();
        C1658ol.KLMXS((C1658ol) this.AZxh, true);
        return this;
    }

    public final C1298il fehf(boolean z) {
        YoKzxo();
        C1658ol.cMLeY((C1658ol) this.AZxh, true);
        return this;
    }

    public final C1298il qGY(String str) {
        YoKzxo();
        C1658ol.xrEuO((C1658ol) this.AZxh, str);
        return this;
    }
}
