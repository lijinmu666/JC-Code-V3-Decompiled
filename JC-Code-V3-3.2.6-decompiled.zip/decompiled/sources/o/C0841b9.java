package o;

/* renamed from: o.b9, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0841b9 implements V8 {
    public final String AZxh;
    public final InterfaceC0901c9 KLFTb;
    public final M8 ZfxDd;
    public final X8 mjFkc;
    public final dXmy wA;

    public C0841b9(X8 x8, String str, dXmy dxmy, M8 m8, InterfaceC0901c9 interfaceC0901c9) {
        this.mjFkc = x8;
        this.AZxh = str;
        this.wA = dxmy;
        this.ZfxDd = m8;
        this.KLFTb = interfaceC0901c9;
    }

    public static /* synthetic */ void AZxh(Exception exc) {
    }

    @Override // o.V8
    public void mjFkc(uhQ uhq) {
        wA(uhq, C0780a9.AZxh());
    }

    public void wA(uhQ uhq, InterfaceC1144g9 interfaceC1144g9) {
        this.KLFTb.mjFkc(C6.mjFkc().KLFTb(this.mjFkc).wA(uhq).JHa(this.AZxh).ZfxDd(this.ZfxDd).AZxh(this.wA).mjFkc(), interfaceC1144g9);
    }
}
