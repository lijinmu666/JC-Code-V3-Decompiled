package o;

/* renamed from: o.ue, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C2011ue extends Vx implements Ly {
    public /* synthetic */ C2011ue(AbstractC0727Yd abstractC0727Yd) {
        super(C2314ze.zbb);
    }
}
