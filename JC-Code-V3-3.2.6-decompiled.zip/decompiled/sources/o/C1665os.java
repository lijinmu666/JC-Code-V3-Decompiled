package o;

/* renamed from: o.os, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C1665os extends AbstractC1010dy implements Ly {
    private static final C1665os zbb;
    private int zbd;
    private int zbf;
    private int zbe = 1;
    private int zbg = 4;
    private int zbh = 240;
    private InterfaceC1371jy zbi = AbstractC1010dy.BAnRFn();

    static {
        C1665os c1665os = new C1665os();
        zbb = c1665os;
        AbstractC1010dy.YoKzxo(C1665os.class, c1665os);
    }

    @Override // o.AbstractC1010dy
    public final Object IEE(int i, Object obj, Object obj2) {
        int i2 = i - 1;
        if (i2 == 0) {
            return (byte) 1;
        }
        if (i2 == 2) {
            return AbstractC1010dy.ETF(zbb, "\u0001\u0005\u0000\u0001\u0003\n\u0005\u0000\u0001\u0000\u0003᠌\u0000\u0007င\u0001\bင\u0002\tင\u0003\nࠬ", new Object[]{"zbd", "zbe", C1605ns.mjFkc, "zbf", "zbg", "zbh", "zbi", C1545ms.mjFkc});
        }
        if (i2 == 3) {
            return new C1665os();
        }
        AbstractC1425ks abstractC1425ks = null;
        if (i2 == 4) {
            return new C1485ls(abstractC1425ks);
        }
        if (i2 != 5) {
            return null;
        }
        return zbb;
    }
}
