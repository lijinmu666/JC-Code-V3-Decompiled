package o;

/* renamed from: o.fP, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC1099fP {
}
