package o;

/* renamed from: o.Vi, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0663Vi extends Vx implements Ly {
    public /* synthetic */ C0663Vi(AbstractC0640Ui abstractC0640Ui) {
        super(C0686Wi.zbb);
    }
}
