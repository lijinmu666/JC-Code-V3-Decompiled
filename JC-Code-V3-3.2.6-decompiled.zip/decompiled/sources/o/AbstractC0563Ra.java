package o;

/* renamed from: o.Ra, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract /* synthetic */ class AbstractC0563Ra {
}
