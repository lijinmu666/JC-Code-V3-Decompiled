package o;

import android.net.Uri;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.common.api.Scope;
import java.util.ArrayList;

/* renamed from: o.dc, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0989dc implements Parcelable.Creator {
    @Override // android.os.Parcelable.Creator
    public final /* bridge */ /* synthetic */ Object createFromParcel(Parcel parcel) {
        int iIEE = AbstractC1319j6.IEE(parcel);
        String strZfxDd = null;
        String strZfxDd2 = null;
        String strZfxDd3 = null;
        String strZfxDd4 = null;
        Uri uri = null;
        String strZfxDd5 = null;
        String strZfxDd6 = null;
        ArrayList arrayListXJ = null;
        String strZfxDd7 = null;
        String strZfxDd8 = null;
        long jRkYL = 0;
        int iYoKzxo = 0;
        while (parcel.dataPosition() < iIEE) {
            int iVA = AbstractC1319j6.VA(parcel);
            switch (AbstractC1319j6.qdMbNW(iVA)) {
                case 1:
                    iYoKzxo = AbstractC1319j6.YoKzxo(parcel, iVA);
                    break;
                case 2:
                    strZfxDd = AbstractC1319j6.ZfxDd(parcel, iVA);
                    break;
                case 3:
                    strZfxDd2 = AbstractC1319j6.ZfxDd(parcel, iVA);
                    break;
                case 4:
                    strZfxDd3 = AbstractC1319j6.ZfxDd(parcel, iVA);
                    break;
                case 5:
                    strZfxDd4 = AbstractC1319j6.ZfxDd(parcel, iVA);
                    break;
                case 6:
                    uri = (Uri) AbstractC1319j6.wA(parcel, iVA, Uri.CREATOR);
                    break;
                case 7:
                    strZfxDd5 = AbstractC1319j6.ZfxDd(parcel, iVA);
                    break;
                case 8:
                    jRkYL = AbstractC1319j6.rkYL(parcel, iVA);
                    break;
                case 9:
                    strZfxDd6 = AbstractC1319j6.ZfxDd(parcel, iVA);
                    break;
                case 10:
                    arrayListXJ = AbstractC1319j6.xJ(parcel, iVA, Scope.CREATOR);
                    break;
                case 11:
                    strZfxDd7 = AbstractC1319j6.ZfxDd(parcel, iVA);
                    break;
                case 12:
                    strZfxDd8 = AbstractC1319j6.ZfxDd(parcel, iVA);
                    break;
                default:
                    AbstractC1319j6.fehf(parcel, iVA);
                    break;
            }
        }
        AbstractC1319j6.lgHUyS(parcel, iIEE);
        return new GoogleSignInAccount(iYoKzxo, strZfxDd, strZfxDd2, strZfxDd3, strZfxDd4, uri, strZfxDd5, jRkYL, strZfxDd6, arrayListXJ, strZfxDd7, strZfxDd8);
    }

    @Override // android.os.Parcelable.Creator
    public final /* synthetic */ Object[] newArray(int i) {
        return new GoogleSignInAccount[i];
    }
}
