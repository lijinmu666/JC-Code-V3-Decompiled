package o;

/* loaded from: classes.dex */
public final class IC extends TC {
    public final /* synthetic */ C1687pD KLFTb;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public IC(C1687pD c1687pD) {
        super(c1687pD, null);
        this.KLFTb = c1687pD;
    }

    @Override // o.TC
    public final /* bridge */ /* synthetic */ Object AZxh(int i) {
        return new XC(this.KLFTb, i);
    }
}
