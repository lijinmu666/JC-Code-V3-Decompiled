package o;

/* loaded from: classes.dex */
public final class WB {
    public final Object AZxh;
    public final Object mjFkc;
    public final Object wA;

    public WB(Object obj, Object obj2, Object obj3) {
        this.mjFkc = obj;
        this.AZxh = obj2;
        this.wA = obj3;
    }

    public final IllegalArgumentException mjFkc() {
        Object obj = this.wA;
        Object obj2 = this.AZxh;
        Object obj3 = this.mjFkc;
        return new IllegalArgumentException("Multiple entries with same key: " + String.valueOf(obj3) + "=" + String.valueOf(obj2) + " and " + String.valueOf(obj3) + "=" + String.valueOf(obj));
    }
}
