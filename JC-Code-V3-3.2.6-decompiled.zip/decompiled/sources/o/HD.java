package o;

import java.util.List;

/* loaded from: classes.dex */
public final class HD extends JD {
    public final /* synthetic */ JD KLFTb;
    public final transient int ZfxDd;
    public final transient int wA;

    public HD(JD jd, int i, int i2) {
        this.KLFTb = jd;
        this.wA = i;
        this.ZfxDd = i2;
    }

    @Override // o.AbstractC2289zD
    public final int JHa() {
        return this.KLFTb.JHa() + this.wA;
    }

    @Override // o.AbstractC2289zD
    public final int ZfxDd() {
        return this.KLFTb.JHa() + this.wA + this.ZfxDd;
    }

    @Override // java.util.List
    public final Object get(int i) {
        XW.mjFkc(i, this.ZfxDd, "index");
        return this.KLFTb.get(i + this.wA);
    }

    @Override // o.JD
    /* renamed from: lgHUyS */
    public final JD subList(int i, int i2) {
        XW.wA(i, i2, this.ZfxDd);
        int i3 = this.wA;
        return this.KLFTb.subList(i + i3, i2 + i3);
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.List
    public final int size() {
        return this.ZfxDd;
    }

    @Override // o.JD, java.util.List
    public final /* bridge */ /* synthetic */ List subList(int i, int i2) {
        return subList(i, i2);
    }

    @Override // o.AbstractC2289zD
    public final Object[] xJ() {
        return this.KLFTb.xJ();
    }
}
