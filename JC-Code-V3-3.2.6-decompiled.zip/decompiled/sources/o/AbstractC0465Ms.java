package o;

/* renamed from: o.Ms, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC0465Ms extends AbstractC0488Ns {
    public boolean wA;
    public Object[] mjFkc = new Object[4];
    public int AZxh = 0;

    public AbstractC0465Ms(int i) {
    }
}
