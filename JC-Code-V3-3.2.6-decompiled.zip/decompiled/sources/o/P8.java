package o;

import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator;

/* loaded from: classes.dex */
public abstract class P8 {
    public static N8 mjFkc = new C1370jx();
    public static ThreadLocal AZxh = new ThreadLocal();
    public static ArrayList wA = new ArrayList();

    public static class mjFkc implements ViewTreeObserver.OnPreDrawListener, View.OnAttachStateChangeListener {
        public ViewGroup AZxh;
        public N8 mjFkc;

        /* renamed from: o.P8$mjFkc$mjFkc, reason: collision with other inner class name */
        public class C0050mjFkc extends O8 {
            public final /* synthetic */ tjSezt mjFkc;

            public C0050mjFkc(tjSezt tjsezt) {
                this.mjFkc = tjsezt;
            }

            @Override // o.N8.JHa
            public void wA(N8 n8) {
                ((ArrayList) this.mjFkc.get(mjFkc.this.AZxh)).remove(n8);
                n8.aqHPIZ(this);
            }
        }

        public mjFkc(N8 n8, ViewGroup viewGroup) {
            this.mjFkc = n8;
            this.AZxh = viewGroup;
        }

        public final void mjFkc() {
            this.AZxh.getViewTreeObserver().removeOnPreDrawListener(this);
            this.AZxh.removeOnAttachStateChangeListener(this);
        }

        @Override // android.view.ViewTreeObserver.OnPreDrawListener
        public boolean onPreDraw() {
            mjFkc();
            if (!P8.wA.remove(this.AZxh)) {
                return true;
            }
            tjSezt tjseztAZxh = P8.AZxh();
            ArrayList arrayList = (ArrayList) tjseztAZxh.get(this.AZxh);
            ArrayList arrayList2 = null;
            if (arrayList == null) {
                arrayList = new ArrayList();
                tjseztAZxh.put(this.AZxh, arrayList);
            } else if (arrayList.size() > 0) {
                arrayList2 = new ArrayList(arrayList);
            }
            arrayList.add(this.mjFkc);
            this.mjFkc.mjFkc(new C0050mjFkc(tjseztAZxh));
            this.mjFkc.MiMN(this.AZxh, false);
            if (arrayList2 != null) {
                Iterator it = arrayList2.iterator();
                while (it.hasNext()) {
                    ((N8) it.next()).KRTLGT(this.AZxh);
                }
            }
            this.mjFkc.oCFDzJ(this.AZxh);
            return true;
        }

        @Override // android.view.View.OnAttachStateChangeListener
        public void onViewAttachedToWindow(View view) {
        }

        @Override // android.view.View.OnAttachStateChangeListener
        public void onViewDetachedFromWindow(View view) {
            mjFkc();
            P8.wA.remove(this.AZxh);
            ArrayList arrayList = (ArrayList) P8.AZxh().get(this.AZxh);
            if (arrayList != null && arrayList.size() > 0) {
                Iterator it = arrayList.iterator();
                while (it.hasNext()) {
                    ((N8) it.next()).KRTLGT(this.AZxh);
                }
            }
            this.mjFkc.YoKzxo(true);
        }
    }

    public static tjSezt AZxh() {
        tjSezt tjsezt;
        WeakReference weakReference = (WeakReference) AZxh.get();
        if (weakReference != null && (tjsezt = (tjSezt) weakReference.get()) != null) {
            return tjsezt;
        }
        tjSezt tjsezt2 = new tjSezt();
        AZxh.set(new WeakReference(tjsezt2));
        return tjsezt2;
    }

    public static void ZfxDd(ViewGroup viewGroup, N8 n8) {
        ArrayList arrayList = (ArrayList) AZxh().get(viewGroup);
        if (arrayList != null && arrayList.size() > 0) {
            Iterator it = arrayList.iterator();
            while (it.hasNext()) {
                ((N8) it.next()).vadzgd(viewGroup);
            }
        }
        if (n8 != null) {
            n8.MiMN(viewGroup, true);
        }
        AbstractC1620o6.mjFkc(viewGroup);
    }

    public static void mjFkc(ViewGroup viewGroup, N8 n8) {
        if (wA.contains(viewGroup) || !T9.rWxwaT(viewGroup)) {
            return;
        }
        wA.add(viewGroup);
        if (n8 == null) {
            n8 = mjFkc;
        }
        N8 n8Clone = n8.clone();
        ZfxDd(viewGroup, n8Clone);
        AbstractC1620o6.AZxh(viewGroup, null);
        wA(viewGroup, n8Clone);
    }

    public static void wA(ViewGroup viewGroup, N8 n8) {
        if (n8 == null || viewGroup == null) {
            return;
        }
        mjFkc mjfkc = new mjFkc(n8, viewGroup);
        viewGroup.addOnAttachStateChangeListener(mjfkc);
        viewGroup.getViewTreeObserver().addOnPreDrawListener(mjfkc);
    }
}
