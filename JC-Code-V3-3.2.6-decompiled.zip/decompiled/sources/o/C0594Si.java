package o;

/* renamed from: o.Si, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0594Si extends Vx implements Ly {
    public /* synthetic */ C0594Si(AbstractC0524Pi abstractC0524Pi) {
        super(C0617Ti.zbb);
    }
}
