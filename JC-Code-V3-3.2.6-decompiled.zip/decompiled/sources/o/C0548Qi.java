package o;

import org.conscrypt.BuildConfig;

/* renamed from: o.Qi, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0548Qi extends AbstractC1010dy implements Ly {
    private static final C0548Qi zbb;
    private int zbd;
    private String zbe = BuildConfig.FLAVOR;
    private int zbf;

    static {
        C0548Qi c0548Qi = new C0548Qi();
        zbb = c0548Qi;
        AbstractC1010dy.YoKzxo(C0548Qi.class, c0548Qi);
    }

    @Override // o.AbstractC1010dy
    public final Object IEE(int i, Object obj, Object obj2) {
        int i2 = i - 1;
        if (i2 == 0) {
            return (byte) 1;
        }
        if (i2 == 2) {
            return AbstractC1010dy.ETF(zbb, "\u0001\u0002\u0000\u0001\u0001\u0002\u0002\u0000\u0000\u0000\u0001ဈ\u0000\u0002င\u0001", new Object[]{"zbd", "zbe", "zbf"});
        }
        if (i2 == 3) {
            return new C0548Qi();
        }
        AbstractC0432Lh abstractC0432Lh = null;
        if (i2 == 4) {
            return new C1595ni(abstractC0432Lh);
        }
        if (i2 != 5) {
            return null;
        }
        return zbb;
    }
}
