package o;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.Gravity;

/* loaded from: classes.dex */
public abstract class niM extends androidx.appcompat.widget.AZxh {
    public final Rect IEE;
    public int Pq;
    public boolean diqgf;
    public boolean eyqo;
    public final Rect fehf;
    public Drawable qGY;

    public niM(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.fehf = new Rect();
        this.IEE = new Rect();
        this.Pq = 119;
        this.diqgf = true;
        this.eyqo = false;
        TypedArray typedArrayLgHUyS = AbstractC1622o8.lgHUyS(context, attributeSet, AbstractC0776a5.Fztqa, i, 0, new int[0]);
        this.Pq = typedArrayLgHUyS.getInt(AbstractC0776a5.VfB, this.Pq);
        Drawable drawable = typedArrayLgHUyS.getDrawable(AbstractC0776a5.mzUGzO);
        if (drawable != null) {
            setForeground(drawable);
        }
        this.diqgf = typedArrayLgHUyS.getBoolean(AbstractC0776a5.Htq, true);
        typedArrayLgHUyS.recycle();
    }

    @Override // android.view.View
    public void draw(Canvas canvas) {
        super.draw(canvas);
        Drawable drawable = this.qGY;
        if (drawable != null) {
            if (this.eyqo) {
                this.eyqo = false;
                Rect rect = this.fehf;
                Rect rect2 = this.IEE;
                int right = getRight() - getLeft();
                int bottom = getBottom() - getTop();
                if (this.diqgf) {
                    rect.set(0, 0, right, bottom);
                } else {
                    rect.set(getPaddingLeft(), getPaddingTop(), right - getPaddingRight(), bottom - getPaddingBottom());
                }
                Gravity.apply(this.Pq, drawable.getIntrinsicWidth(), drawable.getIntrinsicHeight(), rect, rect2);
                drawable.setBounds(rect2);
            }
            drawable.draw(canvas);
        }
    }

    @Override // android.view.View
    public void drawableHotspotChanged(float f, float f2) {
        super.drawableHotspotChanged(f, f2);
        Drawable drawable = this.qGY;
        if (drawable != null) {
            drawable.setHotspot(f, f2);
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public void drawableStateChanged() {
        super.drawableStateChanged();
        Drawable drawable = this.qGY;
        if (drawable == null || !drawable.isStateful()) {
            return;
        }
        this.qGY.setState(getDrawableState());
    }

    @Override // android.view.View
    public Drawable getForeground() {
        return this.qGY;
    }

    @Override // android.view.View
    public int getForegroundGravity() {
        return this.Pq;
    }

    @Override // android.view.ViewGroup, android.view.View
    public void jumpDrawablesToCurrentState() {
        super.jumpDrawablesToCurrentState();
        Drawable drawable = this.qGY;
        if (drawable != null) {
            drawable.jumpToCurrentState();
        }
    }

    @Override // androidx.appcompat.widget.AZxh, android.view.ViewGroup, android.view.View
    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        super.onLayout(z, i, i2, i3, i4);
        this.eyqo = z | this.eyqo;
    }

    @Override // android.view.View
    public void onSizeChanged(int i, int i2, int i3, int i4) {
        super.onSizeChanged(i, i2, i3, i4);
        this.eyqo = true;
    }

    @Override // android.view.View
    public void setForeground(Drawable drawable) {
        Drawable drawable2 = this.qGY;
        if (drawable2 != drawable) {
            if (drawable2 != null) {
                drawable2.setCallback(null);
                unscheduleDrawable(this.qGY);
            }
            this.qGY = drawable;
            this.eyqo = true;
            if (drawable != null) {
                setWillNotDraw(false);
                drawable.setCallback(this);
                if (drawable.isStateful()) {
                    drawable.setState(getDrawableState());
                }
                if (this.Pq == 119) {
                    drawable.getPadding(new Rect());
                }
            } else {
                setWillNotDraw(true);
            }
            requestLayout();
            invalidate();
        }
    }

    @Override // android.view.View
    public void setForegroundGravity(int i) {
        if (this.Pq != i) {
            if ((8388615 & i) == 0) {
                i |= 8388611;
            }
            if ((i & 112) == 0) {
                i |= 48;
            }
            this.Pq = i;
            if (i == 119 && this.qGY != null) {
                this.qGY.getPadding(new Rect());
            }
            requestLayout();
        }
    }

    @Override // android.view.View
    public boolean verifyDrawable(Drawable drawable) {
        return super.verifyDrawable(drawable) || drawable == this.qGY;
    }
}
