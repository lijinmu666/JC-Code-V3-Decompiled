package o;

import android.os.Trace;

/* loaded from: classes.dex */
public abstract class L8 {
    public static void AZxh() {
        Trace.endSection();
    }

    public static void mjFkc(String str) {
        Trace.beginSection(str);
    }
}
