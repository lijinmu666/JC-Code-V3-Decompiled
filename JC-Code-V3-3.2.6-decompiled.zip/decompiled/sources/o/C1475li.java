package o;

import org.conscrypt.BuildConfig;

/* renamed from: o.li, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C1475li extends AbstractC1010dy implements Ly {
    private static final C1475li zbb;
    private int zbd;
    private long zbh;
    private C1055ei zbl;
    private C0593Sh zbm;
    private int zbo;
    private InterfaceC1491ly zbe = AbstractC1010dy.wJVbdd();
    private InterfaceC1491ly zbf = AbstractC1010dy.wJVbdd();
    private InterfaceC1491ly zbg = AbstractC1010dy.wJVbdd();
    private String zbi = BuildConfig.FLAVOR;
    private InterfaceC1491ly zbj = AbstractC1010dy.wJVbdd();
    private String zbk = BuildConfig.FLAVOR;
    private InterfaceC1431ky zbn = AbstractC1010dy.lB();

    static {
        C1475li c1475li = new C1475li();
        zbb = c1475li;
        AbstractC1010dy.YoKzxo(C1475li.class, c1475li);
    }

    @Override // o.AbstractC1010dy
    public final Object IEE(int i, Object obj, Object obj2) {
        int i2 = i - 1;
        if (i2 == 0) {
            return (byte) 1;
        }
        if (i2 == 2) {
            return AbstractC1010dy.ETF(zbb, "\u0000\u000b\u0000\u0001\u0001\u000b\u000b\u0000\u0005\u0000\u0001\u001b\u0002\u001b\u0003\u0002\u0004Ȉ\u0005Ț\u0006Ȉ\u0007ဉ\u0001\b%\t\u0004\n\u001b\u000bဉ\u0000", new Object[]{"zbd", "zbe", C1176gi.class, "zbf", C1295ii.class, "zbh", "zbi", "zbj", "zbk", "zbm", "zbn", "zbo", "zbg", C0934ci.class, "zbl"});
        }
        if (i2 == 3) {
            return new C1475li();
        }
        AbstractC0363Ih abstractC0363Ih = null;
        if (i2 == 4) {
            return new C0813ai(abstractC0363Ih);
        }
        if (i2 != 5) {
            return null;
        }
        return zbb;
    }
}
