package o;

import o.qGgY;

/* renamed from: o.ui, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final /* synthetic */ class C2015ui implements SbhK {
    public final qGgY mjFkc;

    public C2015ui(qGgY qggy) {
        this.mjFkc = qggy;
    }

    public static SbhK mjFkc(qGgY qggy) {
        return new C2015ui(qggy);
    }

    @Override // o.SbhK
    public Object apply(Object obj) {
        return this.mjFkc.ZfxDd((qGgY.mjFkc) obj);
    }
}
