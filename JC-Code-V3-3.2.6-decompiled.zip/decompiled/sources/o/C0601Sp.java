package o;

/* renamed from: o.Sp, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0601Sp extends Vx implements Ly {
    public /* synthetic */ C0601Sp(AbstractC0578Rp abstractC0578Rp) {
        super(C0624Tp.zbb);
    }
}
