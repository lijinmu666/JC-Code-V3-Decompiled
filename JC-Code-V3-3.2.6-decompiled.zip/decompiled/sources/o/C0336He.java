package o;

/* renamed from: o.He, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0336He extends Yx implements Ly {
    public /* synthetic */ C0336He(AbstractC0727Yd abstractC0727Yd) {
        super(C0360Ie.zbd);
    }
}
