package o;

import android.animation.TimeInterpolator;
import android.util.AndroidRuntimeException;
import android.view.View;
import android.view.ViewGroup;
import java.util.ArrayList;
import java.util.Iterator;
import o.N8;

/* loaded from: classes.dex */
public class R8 extends N8 {
    public int cMLeY;
    public ArrayList KLMXS = new ArrayList();
    public boolean zvd = true;
    public boolean rWxwaT = false;
    public int Vnb = 0;

    public static class AZxh extends O8 {
        public R8 mjFkc;

        public AZxh(R8 r8) {
            this.mjFkc = r8;
        }

        @Override // o.O8, o.N8.JHa
        public void ZfxDd(N8 n8) {
            R8 r8 = this.mjFkc;
            if (r8.rWxwaT) {
                return;
            }
            r8.bbzow();
            this.mjFkc.rWxwaT = true;
        }

        @Override // o.N8.JHa
        public void wA(N8 n8) {
            R8 r8 = this.mjFkc;
            int i = r8.cMLeY - 1;
            r8.cMLeY = i;
            if (i == 0) {
                r8.rWxwaT = false;
                r8.IEE();
            }
            n8.aqHPIZ(this);
        }
    }

    public class mjFkc extends O8 {
        public final /* synthetic */ N8 mjFkc;

        public mjFkc(N8 n8) {
            this.mjFkc = n8;
        }

        @Override // o.N8.JHa
        public void wA(N8 n8) {
            this.mjFkc.uHVRx();
            n8.aqHPIZ(this);
        }
    }

    public final void ANMGZc(N8 n8) {
        this.KLMXS.add(n8);
        n8.IEE = this;
    }

    @Override // o.N8
    public void ETF(T8 t8) {
        super.ETF(t8);
        int size = this.KLMXS.size();
        for (int i = 0; i < size; i++) {
            ((N8) this.KLMXS.get(i)).ETF(t8);
        }
    }

    public R8 IVlxe(int i) {
        if (i == 0) {
            this.zvd = true;
        } else {
            if (i != 1) {
                throw new AndroidRuntimeException("Invalid parameter for TransitionSet ordering: " + i);
            }
            this.zvd = false;
        }
        return this;
    }

    @Override // o.N8
    /* renamed from: JBhc, reason: merged with bridge method [inline-methods] */
    public R8 mjFkc(N8.JHa jHa) {
        return (R8) super.mjFkc(jHa);
    }

    @Override // o.N8
    public void JYgkl(N8.KLFTb kLFTb) {
        super.JYgkl(kLFTb);
        this.Vnb |= 8;
        int size = this.KLMXS.size();
        for (int i = 0; i < size; i++) {
            ((N8) this.KLMXS.get(i)).JYgkl(kLFTb);
        }
    }

    @Override // o.N8
    public void KRTLGT(View view) {
        super.KRTLGT(view);
        int size = this.KLMXS.size();
        for (int i = 0; i < size; i++) {
            ((N8) this.KLMXS.get(i)).KRTLGT(view);
        }
    }

    @Override // o.N8
    /* renamed from: Moer, reason: merged with bridge method [inline-methods] */
    public R8 XV(long j) {
        return (R8) super.XV(j);
    }

    public final void SmIWf() {
        AZxh aZxh = new AZxh(this);
        Iterator it = this.KLMXS.iterator();
        while (it.hasNext()) {
            ((N8) it.next()).mjFkc(aZxh);
        }
        this.cMLeY = this.KLMXS.size();
    }

    @Override // o.N8
    public String SwgkN(String str) {
        String strSwgkN = super.SwgkN(str);
        for (int i = 0; i < this.KLMXS.size(); i++) {
            StringBuilder sb = new StringBuilder();
            sb.append(strSwgkN);
            sb.append("\n");
            sb.append(((N8) this.KLMXS.get(i)).SwgkN(str + "  "));
            strSwgkN = sb.toString();
        }
        return strSwgkN;
    }

    @Override // o.N8
    public void VA(T8 t8) {
        if (xrEuO(t8.AZxh)) {
            Iterator it = this.KLMXS.iterator();
            while (it.hasNext()) {
                N8 n8 = (N8) it.next();
                if (n8.xrEuO(t8.AZxh)) {
                    n8.VA(t8);
                    t8.wA.add(n8);
                }
            }
        }
    }

    @Override // o.N8
    /* renamed from: Vdz, reason: merged with bridge method [inline-methods] */
    public R8 AZxh(View view) {
        for (int i = 0; i < this.KLMXS.size(); i++) {
            ((N8) this.KLMXS.get(i)).AZxh(view);
        }
        return (R8) super.AZxh(view);
    }

    @Override // o.N8
    public void WGXroI(Q8 q8) {
        super.WGXroI(q8);
        this.Vnb |= 2;
        int size = this.KLMXS.size();
        for (int i = 0; i < size; i++) {
            ((N8) this.KLMXS.get(i)).WGXroI(q8);
        }
    }

    public N8 alEkx(int i) {
        if (i < 0 || i >= this.KLMXS.size()) {
            return null;
        }
        return (N8) this.KLMXS.get(i);
    }

    public int dm() {
        return this.KLMXS.size();
    }

    @Override // o.N8
    public void fehf(ViewGroup viewGroup, U8 u8, U8 u82, ArrayList arrayList, ArrayList arrayList2) {
        long jVocHEe = VocHEe();
        int size = this.KLMXS.size();
        for (int i = 0; i < size; i++) {
            N8 n8 = (N8) this.KLMXS.get(i);
            if (jVocHEe > 0 && (this.zvd || i == 0)) {
                long jVocHEe2 = n8.VocHEe();
                if (jVocHEe2 > 0) {
                    n8.XV(jVocHEe2 + jVocHEe);
                } else {
                    n8.XV(jVocHEe);
                }
            }
            n8.fehf(viewGroup, u8, u82, arrayList, arrayList2);
        }
    }

    public R8 jm(N8 n8) {
        ANMGZc(n8);
        long j = this.wA;
        if (j >= 0) {
            n8.JYn(j);
        }
        if ((this.Vnb & 1) != 0) {
            n8.JrJO(eyqo());
        }
        if ((this.Vnb & 2) != 0) {
            HGpJ();
            n8.WGXroI(null);
        }
        if ((this.Vnb & 4) != 0) {
            n8.nxI(Gd());
        }
        if ((this.Vnb & 8) != 0) {
            n8.JYgkl(diqgf());
        }
        return this;
    }

    @Override // o.N8
    public void nxI(AbstractC1917t3 abstractC1917t3) {
        super.nxI(abstractC1917t3);
        this.Vnb |= 4;
        if (this.KLMXS != null) {
            for (int i = 0; i < this.KLMXS.size(); i++) {
                ((N8) this.KLMXS.get(i)).nxI(abstractC1917t3);
            }
        }
    }

    @Override // o.N8
    public void qdMbNW(T8 t8) {
        if (xrEuO(t8.AZxh)) {
            Iterator it = this.KLMXS.iterator();
            while (it.hasNext()) {
                N8 n8 = (N8) it.next();
                if (n8.xrEuO(t8.AZxh)) {
                    n8.qdMbNW(t8);
                    t8.wA.add(n8);
                }
            }
        }
    }

    @Override // o.N8
    /* renamed from: rkYL, reason: merged with bridge method [inline-methods] */
    public N8 clone() {
        R8 r8 = (R8) super.clone();
        r8.KLMXS = new ArrayList();
        int size = this.KLMXS.size();
        for (int i = 0; i < size; i++) {
            r8.ANMGZc(((N8) this.KLMXS.get(i)).clone());
        }
        return r8;
    }

    @Override // o.N8
    /* renamed from: tQ, reason: merged with bridge method [inline-methods] */
    public R8 aqHPIZ(N8.JHa jHa) {
        return (R8) super.aqHPIZ(jHa);
    }

    @Override // o.N8
    public void uHVRx() {
        if (this.KLMXS.isEmpty()) {
            bbzow();
            IEE();
            return;
        }
        SmIWf();
        if (this.zvd) {
            Iterator it = this.KLMXS.iterator();
            while (it.hasNext()) {
                ((N8) it.next()).uHVRx();
            }
            return;
        }
        for (int i = 1; i < this.KLMXS.size(); i++) {
            ((N8) this.KLMXS.get(i - 1)).mjFkc(new mjFkc((N8) this.KLMXS.get(i)));
        }
        N8 n8 = (N8) this.KLMXS.get(0);
        if (n8 != null) {
            n8.uHVRx();
        }
    }

    @Override // o.N8
    public void vadzgd(View view) {
        super.vadzgd(view);
        int size = this.KLMXS.size();
        for (int i = 0; i < size; i++) {
            ((N8) this.KLMXS.get(i)).vadzgd(view);
        }
    }

    @Override // o.N8
    /* renamed from: vjlshU, reason: merged with bridge method [inline-methods] */
    public R8 JYn(long j) {
        ArrayList arrayList;
        super.JYn(j);
        if (this.wA >= 0 && (arrayList = this.KLMXS) != null) {
            int size = arrayList.size();
            for (int i = 0; i < size; i++) {
                ((N8) this.KLMXS.get(i)).JYn(j);
            }
        }
        return this;
    }

    @Override // o.N8
    /* renamed from: xROA, reason: merged with bridge method [inline-methods] */
    public R8 JrJO(TimeInterpolator timeInterpolator) {
        this.Vnb |= 1;
        ArrayList arrayList = this.KLMXS;
        if (arrayList != null) {
            int size = arrayList.size();
            for (int i = 0; i < size; i++) {
                ((N8) this.KLMXS.get(i)).JrJO(timeInterpolator);
            }
        }
        return (R8) super.JrJO(timeInterpolator);
    }

    @Override // o.N8
    /* renamed from: yfx, reason: merged with bridge method [inline-methods] */
    public R8 WrLQs(View view) {
        for (int i = 0; i < this.KLMXS.size(); i++) {
            ((N8) this.KLMXS.get(i)).WrLQs(view);
        }
        return (R8) super.WrLQs(view);
    }
}
