package o;

/* renamed from: o.xk, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C2198xk extends AbstractC1010dy implements Ly {
    private static final C2198xk zbb;
    private int zbd;
    private Object zbf;
    private boolean zbg;
    private C0419Kr zbh;
    private boolean zbi;
    private C0509Oq zbj;
    private float zbk;
    private boolean zbl;
    private boolean zbm;
    private boolean zbo;
    private float zbp;
    private int zbq;
    private C0458Ml zbr;
    private int zbe = 0;
    private byte zbs = 2;
    private int zbn = -1;

    static {
        C2198xk c2198xk = new C2198xk();
        zbb = c2198xk;
        AbstractC1010dy.YoKzxo(C2198xk.class, c2198xk);
    }

    @Override // o.AbstractC1010dy
    public final Object IEE(int i, Object obj, Object obj2) {
        int i2 = i - 1;
        if (i2 == 0) {
            return Byte.valueOf(this.zbs);
        }
        if (i2 == 2) {
            return AbstractC1010dy.ETF(zbb, "\u0004\u000e\u0001\u0001\u0001\u000e\u000e\u0000\u0000\u0001\u0001м\u0000\u0002ဉ\u0001\u0003ဉ\u0003\u0004ဇ\u0006\u0005င\u0007\u0006ဇ\b\u0007ဇ\u0000\bခ\t\tင\n\nဇ\u0002\u000bဉ\u000b\fခ\u0004\rဇ\u0005\u000e<\u0000", new Object[]{"zbf", "zbe", "zbd", C0707Xg.class, "zbh", "zbj", "zbm", "zbn", "zbo", "zbg", "zbp", "zbq", "zbi", "zbr", "zbk", "zbl", C1360jn.class});
        }
        if (i2 == 3) {
            return new C2198xk();
        }
        AbstractC1896sj abstractC1896sj = null;
        if (i2 == 4) {
            return new C0664Vj(abstractC1896sj);
        }
        if (i2 == 5) {
            return zbb;
        }
        this.zbs = obj == null ? (byte) 0 : (byte) 1;
        return null;
    }
}
