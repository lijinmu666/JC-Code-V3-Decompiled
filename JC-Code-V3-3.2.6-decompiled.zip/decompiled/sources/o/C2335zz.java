package o;

import org.conscrypt.BuildConfig;

/* renamed from: o.zz, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C2335zz extends AbstractC1010dy implements Ly {
    private static final C2335zz zbb;
    private int zbd;
    private C0433Li zbe;
    private String zbf = BuildConfig.FLAVOR;
    private boolean zbg;
    private C0346Ho zbh;

    static {
        C2335zz c2335zz = new C2335zz();
        zbb = c2335zz;
        AbstractC1010dy.YoKzxo(C2335zz.class, c2335zz);
    }

    @Override // o.AbstractC1010dy
    public final Object IEE(int i, Object obj, Object obj2) {
        int i2 = i - 1;
        if (i2 == 0) {
            return (byte) 1;
        }
        if (i2 == 2) {
            return AbstractC1010dy.ETF(zbb, "\u0001\u0004\u0000\u0001\u0001\u0004\u0004\u0000\u0000\u0000\u0001ဉ\u0000\u0002ဈ\u0001\u0003ဇ\u0002\u0004ဉ\u0003", new Object[]{"zbd", "zbe", "zbf", "zbg", "zbh"});
        }
        if (i2 == 3) {
            return new C2335zz();
        }
        AbstractC2152wy abstractC2152wy = null;
        if (i2 == 4) {
            return new Xy(abstractC2152wy);
        }
        if (i2 != 5) {
            return null;
        }
        return zbb;
    }
}
