package o;

import java.util.Collections;
import java.util.Set;
import java.util.WeakHashMap;

/* renamed from: o.g, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC1134g {
    public static final Set mjFkc = Collections.newSetFromMap(new WeakHashMap());

    /* renamed from: o.g$AZxh */
    public interface AZxh extends InterfaceC0774a3 {
    }

    /* renamed from: o.g$mjFkc */
    public interface mjFkc extends jpz {
    }
}
