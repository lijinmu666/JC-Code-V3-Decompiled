package o;

/* renamed from: o.aA, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0781aA implements InterfaceC1252hy {
    public static final InterfaceC1252hy mjFkc = new C0781aA();

    @Override // o.InterfaceC1252hy
    public final boolean mjFkc(int i) {
        switch (i) {
            case 0:
            case 1:
            case 2:
            case 3:
            case 4:
            case 5:
            case 6:
            case 7:
                return true;
            default:
                return false;
        }
    }
}
