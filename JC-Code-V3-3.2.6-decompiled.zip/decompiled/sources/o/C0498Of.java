package o;

import org.conscrypt.BuildConfig;

/* renamed from: o.Of, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0498Of extends Zx implements Ly {
    private static final C0498Of zbd;
    private int zbe;
    private Object zbg;
    private Object zbi;
    private AbstractC2272yx zbl;
    private Cz zbm;
    private int zbn;
    private int zbo;
    private boolean zbp;
    private int zbq;
    private AbstractC2272yx zbr;
    private int zbf = 0;
    private int zbh = 0;
    private byte zbs = 2;
    private String zbj = "FaceAttributesClientBrainEmbedder";
    private String zbk = BuildConfig.FLAVOR;

    static {
        C0498Of c0498Of = new C0498Of();
        zbd = c0498Of;
        AbstractC1010dy.YoKzxo(C0498Of.class, c0498Of);
    }

    public C0498Of() {
        AbstractC2272yx abstractC2272yx = AbstractC2272yx.AZxh;
        this.zbl = abstractC2272yx;
        this.zbp = true;
        this.zbq = 1;
        this.zbr = abstractC2272yx;
    }

    @Override // o.AbstractC1010dy
    public final Object IEE(int i, Object obj, Object obj2) {
        int i2 = i - 1;
        if (i2 == 0) {
            return Byte.valueOf(this.zbs);
        }
        if (i2 == 2) {
            return AbstractC1010dy.ETF(zbd, "\u0004\r\u0002\u0001\u0002\u0010\r\u0000\u0000\u0001\u0002<\u0000\u0003;\u0000\u0004ဇ\u0006\u0005᠌\u0007\u0007м\u0001\b;\u0001\tဈ\u0000\nဈ\u0001\fင\u0004\rဉ\u0003\u000eည\b\u000fည\u0002\u0010င\u0005", new Object[]{"zbg", "zbf", "zbi", "zbh", "zbe", C0451Me.class, "zbp", "zbq", C0452Mf.mjFkc, C0872bg.class, "zbj", "zbk", "zbn", "zbm", "zbr", "zbl", "zbo"});
        }
        if (i2 == 3) {
            return new C0498Of();
        }
        AbstractC0430Lf abstractC0430Lf = null;
        if (i2 == 4) {
            return new C0475Nf(abstractC0430Lf);
        }
        if (i2 == 5) {
            return zbd;
        }
        this.zbs = obj == null ? (byte) 0 : (byte) 1;
        return null;
    }
}
