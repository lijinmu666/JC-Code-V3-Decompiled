package o;

import org.conscrypt.BuildConfig;

/* renamed from: o.Fk, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0296Fk extends AbstractC1010dy implements Ly {
    private static final C0296Fk zbb;
    private int zbd;
    private String zbe = BuildConfig.FLAVOR;
    private InterfaceC1491ly zbf = AbstractC1010dy.wJVbdd();
    private InterfaceC1491ly zbg = AbstractC1010dy.wJVbdd();
    private long zbh;

    static {
        C0296Fk c0296Fk = new C0296Fk();
        zbb = c0296Fk;
        AbstractC1010dy.YoKzxo(C0296Fk.class, c0296Fk);
    }

    @Override // o.AbstractC1010dy
    public final Object IEE(int i, Object obj, Object obj2) {
        int i2 = i - 1;
        if (i2 == 0) {
            return (byte) 1;
        }
        if (i2 == 2) {
            return AbstractC1010dy.ETF(zbb, "\u0001\u0004\u0000\u0001\u0001\u0004\u0004\u0000\u0002\u0000\u0001ဈ\u0000\u0002\u001a\u0003\u001b\u0004ဂ\u0001", new Object[]{"zbd", "zbe", "zbf", "zbg", C0435Lk.class, "zbh"});
        }
        if (i2 == 3) {
            return new C0296Fk();
        }
        AbstractC2320zk abstractC2320zk = null;
        if (i2 == 4) {
            return new C0250Dk(abstractC2320zk);
        }
        if (i2 != 5) {
            return null;
        }
        return zbb;
    }
}
