package o;

import java.util.concurrent.CopyOnWriteArrayList;

/* loaded from: classes.dex */
public abstract class Y2 {
    public CopyOnWriteArrayList AZxh = new CopyOnWriteArrayList();
    public boolean mjFkc;
    public KbE wA;

    public Y2(boolean z) {
        this.mjFkc = z;
    }

    public final void AZxh(boolean z) {
        this.mjFkc = z;
        KbE kbE = this.wA;
        if (kbE != null) {
            kbE.mjFkc(Boolean.valueOf(z));
        }
    }

    public void mjFkc(VfB vfB) {
        this.AZxh.remove(vfB);
    }
}
