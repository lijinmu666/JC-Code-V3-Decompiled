package o;

import org.conscrypt.BuildConfig;

/* renamed from: o.Sq, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0602Sq extends AbstractC1010dy implements Ly {
    private static final C0602Sq zbb;
    private int zbd;
    private Object zbf;
    private float zbg;
    private boolean zbi;
    private int zbe = 0;
    private String zbh = BuildConfig.FLAVOR;

    static {
        C0602Sq c0602Sq = new C0602Sq();
        zbb = c0602Sq;
        AbstractC1010dy.YoKzxo(C0602Sq.class, c0602Sq);
    }

    @Override // o.AbstractC1010dy
    public final Object IEE(int i, Object obj, Object obj2) {
        int i2 = i - 1;
        if (i2 == 0) {
            return (byte) 1;
        }
        if (i2 == 2) {
            return AbstractC1010dy.ETF(zbb, "\u0004\u0005\u0001\u0001\u0001\u0005\u0005\u0000\u0000\u0000\u0001;\u0000\u0002ခ\u0000\u0003;\u0000\u0004ဈ\u0001\u0005ဇ\u0002", new Object[]{"zbf", "zbe", "zbd", "zbg", "zbh", "zbi"});
        }
        if (i2 == 3) {
            return new C0602Sq();
        }
        AbstractC0556Qq abstractC0556Qq = null;
        if (i2 == 4) {
            return new C0579Rq(abstractC0556Qq);
        }
        if (i2 != 5) {
            return null;
        }
        return zbb;
    }
}
