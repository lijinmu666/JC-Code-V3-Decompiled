package o;

import android.app.Dialog;
import android.app.PendingIntent;
import com.google.android.gms.common.api.GoogleApiActivity;

/* renamed from: o.yd, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class RunnableC2252yd implements Runnable {
    public final /* synthetic */ AbstractDialogInterfaceOnCancelListenerC0220Cd AZxh;
    public final C1770qd mjFkc;

    public RunnableC2252yd(AbstractDialogInterfaceOnCancelListenerC0220Cd abstractDialogInterfaceOnCancelListenerC0220Cd, C1770qd c1770qd) {
        this.AZxh = abstractDialogInterfaceOnCancelListenerC0220Cd;
        this.mjFkc = c1770qd;
    }

    @Override // java.lang.Runnable
    public final void run() {
        if (this.AZxh.AZxh) {
            eEOGOh eeogohAZxh = this.mjFkc.AZxh();
            if (eeogohAZxh.ZfxDd()) {
                AbstractDialogInterfaceOnCancelListenerC0220Cd abstractDialogInterfaceOnCancelListenerC0220Cd = this.AZxh;
                abstractDialogInterfaceOnCancelListenerC0220Cd.mjFkc.startActivityForResult(GoogleApiActivity.mjFkc(abstractDialogInterfaceOnCancelListenerC0220Cd.AZxh(), (PendingIntent) I3.xJ(eeogohAZxh.wA()), this.mjFkc.mjFkc(), false), 1);
                return;
            }
            AbstractDialogInterfaceOnCancelListenerC0220Cd abstractDialogInterfaceOnCancelListenerC0220Cd2 = this.AZxh;
            if (abstractDialogInterfaceOnCancelListenerC0220Cd2.KLFTb.AZxh(abstractDialogInterfaceOnCancelListenerC0220Cd2.AZxh(), eeogohAZxh.mjFkc(), null) != null) {
                AbstractDialogInterfaceOnCancelListenerC0220Cd abstractDialogInterfaceOnCancelListenerC0220Cd3 = this.AZxh;
                abstractDialogInterfaceOnCancelListenerC0220Cd3.KLFTb.Ucbh(abstractDialogInterfaceOnCancelListenerC0220Cd3.AZxh(), abstractDialogInterfaceOnCancelListenerC0220Cd3.mjFkc, eeogohAZxh.mjFkc(), 2, this.AZxh);
                return;
            }
            if (eeogohAZxh.mjFkc() != 18) {
                this.AZxh.VA(eeogohAZxh, this.mjFkc.mjFkc());
                return;
            }
            AbstractDialogInterfaceOnCancelListenerC0220Cd abstractDialogInterfaceOnCancelListenerC0220Cd4 = this.AZxh;
            Dialog dialogFehf = abstractDialogInterfaceOnCancelListenerC0220Cd4.KLFTb.fehf(abstractDialogInterfaceOnCancelListenerC0220Cd4.AZxh(), abstractDialogInterfaceOnCancelListenerC0220Cd4);
            AbstractDialogInterfaceOnCancelListenerC0220Cd abstractDialogInterfaceOnCancelListenerC0220Cd5 = this.AZxh;
            abstractDialogInterfaceOnCancelListenerC0220Cd5.KLFTb.IEE(abstractDialogInterfaceOnCancelListenerC0220Cd5.AZxh().getApplicationContext(), new C2010ud(this, dialogFehf));
        }
    }
}
