package o;

import java.util.Arrays;

/* loaded from: classes.dex */
public final class KN extends DM {
    public final byte[] AZxh;

    public KN(byte[] bArr) {
        super(Arrays.copyOfRange(bArr, 0, 25));
        this.AZxh = bArr;
    }

    @Override // o.DM
    public final byte[] xJ() {
        return this.AZxh;
    }
}
