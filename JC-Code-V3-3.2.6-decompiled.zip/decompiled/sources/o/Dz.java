package o;

/* loaded from: classes.dex */
public final class Dz extends Vx implements Ly {
    public /* synthetic */ Dz(AbstractC2274yz abstractC2274yz) {
        super(Ez.zbb);
    }
}
