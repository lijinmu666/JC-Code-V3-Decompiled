package o;

import o.aqHPIZ;

/* renamed from: o.g5, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC1140g5 {
    public abstract UokA[] AZxh();

    public abstract boolean ZfxDd();

    public abstract void mjFkc();

    public abstract void wA(aqHPIZ.AZxh aZxh, D7 d7);
}
