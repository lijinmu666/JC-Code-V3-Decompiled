package o;

import android.os.Bundle;
import com.google.android.gms.common.api.internal.LifecycleCallback;

/* renamed from: o.pE, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class RunnableC1688pE implements Runnable {
    public final /* synthetic */ String AZxh;
    public final /* synthetic */ LifecycleCallback mjFkc;
    public final /* synthetic */ HF wA;

    public RunnableC1688pE(HF hf, LifecycleCallback lifecycleCallback, String str) {
        this.wA = hf;
        this.mjFkc = lifecycleCallback;
        this.AZxh = str;
    }

    @Override // java.lang.Runnable
    public final void run() {
        Bundle bundle;
        HF hf = this.wA;
        if (hf.nxI > 0) {
            LifecycleCallback lifecycleCallback = this.mjFkc;
            if (hf.WGXroI != null) {
                bundle = hf.WGXroI.getBundle(this.AZxh);
            } else {
                bundle = null;
            }
            lifecycleCallback.JHa(bundle);
        }
        if (this.wA.nxI >= 2) {
            this.mjFkc.Dt();
        }
        if (this.wA.nxI >= 3) {
            this.mjFkc.lgHUyS();
        }
        if (this.wA.nxI >= 4) {
            this.mjFkc.ETF();
        }
        if (this.wA.nxI >= 5) {
            this.mjFkc.xJ();
        }
    }
}
