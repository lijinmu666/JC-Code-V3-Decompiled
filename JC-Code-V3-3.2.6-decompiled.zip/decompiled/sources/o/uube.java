package o;

import android.content.Context;
import android.graphics.Color;

/* loaded from: classes.dex */
public class uube {
    public static final int JHa = (int) Math.round(5.1000000000000005d);
    public final int AZxh;
    public final float KLFTb;
    public final int ZfxDd;
    public final boolean mjFkc;
    public final int wA;

    public uube(Context context) {
        this(F1.AZxh(context, AbstractC1199h4.VA, false), L1.AZxh(context, AbstractC1199h4.ETF, 0), L1.AZxh(context, AbstractC1199h4.Dt, 0), L1.AZxh(context, AbstractC1199h4.lgHUyS, 0), context.getResources().getDisplayMetrics().density);
    }

    public int AZxh(int i, float f) {
        int i2;
        float fMjFkc = mjFkc(f);
        int iAlpha = Color.alpha(i);
        int iQdMbNW = L1.qdMbNW(xfXeiC.ETF(i, 255), this.AZxh, fMjFkc);
        if (fMjFkc > 0.0f && (i2 = this.wA) != 0) {
            iQdMbNW = L1.lgHUyS(iQdMbNW, xfXeiC.ETF(i2, JHa));
        }
        return xfXeiC.ETF(iQdMbNW, iAlpha);
    }

    public final boolean KLFTb(int i) {
        return xfXeiC.ETF(i, 255) == this.ZfxDd;
    }

    public boolean ZfxDd() {
        return this.mjFkc;
    }

    public float mjFkc(float f) {
        if (this.KLFTb <= 0.0f || f <= 0.0f) {
            return 0.0f;
        }
        return Math.min(((((float) Math.log1p(f / r2)) * 4.5f) + 2.0f) / 100.0f, 1.0f);
    }

    public int wA(int i, float f) {
        return (this.mjFkc && KLFTb(i)) ? AZxh(i, f) : i;
    }

    public uube(boolean z, int i, int i2, int i3, float f) {
        this.mjFkc = z;
        this.AZxh = i;
        this.wA = i2;
        this.ZfxDd = i3;
        this.KLFTb = f;
    }
}
