package o;

import o.C0797aQ;

/* renamed from: o.wJ, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C2114wJ implements R2 {
    public static final C0797aQ AZxh;
    public static final C2114wJ mjFkc = new C2114wJ();

    static {
        C0797aQ.AZxh aZxhMjFkc = C0797aQ.mjFkc("errorCode");
        OB ob = new OB();
        ob.mjFkc(1);
        AZxh = aZxhMjFkc.AZxh(ob.AZxh()).mjFkc();
    }

    @Override // o.mYYU
    public final /* bridge */ /* synthetic */ void mjFkc(Object obj, Object obj2) {
        AbstractC2102w7.mjFkc(obj);
        throw null;
    }
}
