package o;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import org.bouncycastle.asn1.cmc.BodyPartID;

/* renamed from: o.e2, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC1015e2 {

    /* renamed from: o.e2$AZxh */
    public static class AZxh {
        public final long AZxh;
        public final long mjFkc;

        public AZxh(long j, long j2) {
            this.mjFkc = j;
            this.AZxh = j2;
        }

        public long mjFkc() {
            return this.mjFkc;
        }
    }

    /* renamed from: o.e2$mjFkc */
    public static class mjFkc implements wA {
        public final ByteBuffer mjFkc;

        public mjFkc(ByteBuffer byteBuffer) {
            this.mjFkc = byteBuffer;
            byteBuffer.order(ByteOrder.BIG_ENDIAN);
        }

        @Override // o.AbstractC1015e2.wA
        public long AZxh() {
            return AbstractC1015e2.wA(this.mjFkc.getInt());
        }

        @Override // o.AbstractC1015e2.wA
        public long getPosition() {
            return this.mjFkc.position();
        }

        @Override // o.AbstractC1015e2.wA
        public void mjFkc(int i) {
            ByteBuffer byteBuffer = this.mjFkc;
            byteBuffer.position(byteBuffer.position() + i);
        }

        @Override // o.AbstractC1015e2.wA
        public int readUnsignedShort() {
            return AbstractC1015e2.ZfxDd(this.mjFkc.getShort());
        }

        @Override // o.AbstractC1015e2.wA
        public int wA() {
            return this.mjFkc.getInt();
        }
    }

    /* renamed from: o.e2$wA */
    public interface wA {
        long AZxh();

        long getPosition();

        void mjFkc(int i);

        int readUnsignedShort();

        int wA();
    }

    public static C0955d2 AZxh(ByteBuffer byteBuffer) {
        ByteBuffer byteBufferDuplicate = byteBuffer.duplicate();
        byteBufferDuplicate.position((int) mjFkc(new mjFkc(byteBufferDuplicate)).mjFkc());
        return C0955d2.lgHUyS(byteBufferDuplicate);
    }

    public static int ZfxDd(short s) {
        return s & 65535;
    }

    public static AZxh mjFkc(wA wAVar) throws IOException {
        long jAZxh;
        wAVar.mjFkc(4);
        int unsignedShort = wAVar.readUnsignedShort();
        if (unsignedShort > 100) {
            throw new IOException("Cannot read metadata.");
        }
        wAVar.mjFkc(6);
        int i = 0;
        while (true) {
            if (i >= unsignedShort) {
                jAZxh = -1;
                break;
            }
            int iWA = wAVar.wA();
            wAVar.mjFkc(4);
            jAZxh = wAVar.AZxh();
            wAVar.mjFkc(4);
            if (1835365473 == iWA) {
                break;
            }
            i++;
        }
        if (jAZxh != -1) {
            wAVar.mjFkc((int) (jAZxh - wAVar.getPosition()));
            wAVar.mjFkc(12);
            long jAZxh2 = wAVar.AZxh();
            for (int i2 = 0; i2 < jAZxh2; i2++) {
                int iWA2 = wAVar.wA();
                long jAZxh3 = wAVar.AZxh();
                long jAZxh4 = wAVar.AZxh();
                if (1164798569 == iWA2 || 1701669481 == iWA2) {
                    return new AZxh(jAZxh3 + jAZxh, jAZxh4);
                }
            }
        }
        throw new IOException("Cannot read metadata.");
    }

    public static long wA(int i) {
        return i & BodyPartID.bodyIdMax;
    }
}
