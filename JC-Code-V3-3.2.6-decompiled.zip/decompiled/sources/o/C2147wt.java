package o;

import org.conscrypt.BuildConfig;

/* renamed from: o.wt, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C2147wt extends AbstractC1010dy implements Ly {
    private static final C2147wt zbb;
    private int zbd;
    private C0351Ht zbg;
    private byte zbh = 2;
    private String zbe = BuildConfig.FLAVOR;
    private String zbf = BuildConfig.FLAVOR;

    static {
        C2147wt c2147wt = new C2147wt();
        zbb = c2147wt;
        AbstractC1010dy.YoKzxo(C2147wt.class, c2147wt);
    }

    @Override // o.AbstractC1010dy
    public final Object IEE(int i, Object obj, Object obj2) {
        int i2 = i - 1;
        if (i2 == 0) {
            return Byte.valueOf(this.zbh);
        }
        if (i2 == 2) {
            return AbstractC1010dy.ETF(zbb, "\u0000\u0003\u0000\u0001\u0001\u0003\u0003\u0000\u0000\u0001\u0001Ȉ\u0002Ȉ\u0003ᐉ\u0000", new Object[]{"zbd", "zbe", "zbf", "zbg"});
        }
        if (i2 == 3) {
            return new C2147wt();
        }
        AbstractC1786qt abstractC1786qt = null;
        if (i2 == 4) {
            return new C2087vt(abstractC1786qt);
        }
        if (i2 == 5) {
            return zbb;
        }
        this.zbh = obj == null ? (byte) 0 : (byte) 1;
        return null;
    }
}
