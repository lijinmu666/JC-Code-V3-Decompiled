package o;

/* renamed from: o.gd, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C1171gd extends AbstractC0381Jc {
    public final AbstractC0893c1 wA;

    public C1171gd(AbstractC0893c1 abstractC0893c1, D7 d7) {
        super(4, d7);
    }

    @Override // o.AbstractC2190xc
    public final boolean JHa(C1409kc c1409kc) {
        return false;
    }

    @Override // o.AbstractC1410kd
    public final /* bridge */ /* synthetic */ void ZfxDd(C0633Ub c0633Ub, boolean z) {
    }

    @Override // o.AbstractC0381Jc
    public final void lgHUyS(C1409kc c1409kc) {
        this.AZxh.KLFTb(Boolean.FALSE);
    }

    @Override // o.AbstractC2190xc
    public final UokA[] xJ(C1409kc c1409kc) {
        return null;
    }
}
