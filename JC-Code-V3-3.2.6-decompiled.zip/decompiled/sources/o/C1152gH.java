package o;

import o.C0797aQ;

/* renamed from: o.gH, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C1152gH implements R2 {
    public static final C0797aQ AZxh;
    public static final C0797aQ JHa;
    public static final C0797aQ KLFTb;
    public static final C0797aQ ZfxDd;
    public static final C0797aQ lgHUyS;
    public static final C1152gH mjFkc = new C1152gH();
    public static final C0797aQ wA;
    public static final C0797aQ xJ;

    static {
        C0797aQ.AZxh aZxhMjFkc = C0797aQ.mjFkc("durationMs");
        OB ob = new OB();
        ob.mjFkc(1);
        AZxh = aZxhMjFkc.AZxh(ob.AZxh()).mjFkc();
        C0797aQ.AZxh aZxhMjFkc2 = C0797aQ.mjFkc("imageSource");
        OB ob2 = new OB();
        ob2.mjFkc(2);
        wA = aZxhMjFkc2.AZxh(ob2.AZxh()).mjFkc();
        C0797aQ.AZxh aZxhMjFkc3 = C0797aQ.mjFkc("imageFormat");
        OB ob3 = new OB();
        ob3.mjFkc(3);
        ZfxDd = aZxhMjFkc3.AZxh(ob3.AZxh()).mjFkc();
        C0797aQ.AZxh aZxhMjFkc4 = C0797aQ.mjFkc("imageByteSize");
        OB ob4 = new OB();
        ob4.mjFkc(4);
        KLFTb = aZxhMjFkc4.AZxh(ob4.AZxh()).mjFkc();
        C0797aQ.AZxh aZxhMjFkc5 = C0797aQ.mjFkc("imageWidth");
        OB ob5 = new OB();
        ob5.mjFkc(5);
        JHa = aZxhMjFkc5.AZxh(ob5.AZxh()).mjFkc();
        C0797aQ.AZxh aZxhMjFkc6 = C0797aQ.mjFkc("imageHeight");
        OB ob6 = new OB();
        ob6.mjFkc(6);
        xJ = aZxhMjFkc6.AZxh(ob6.AZxh()).mjFkc();
        C0797aQ.AZxh aZxhMjFkc7 = C0797aQ.mjFkc("rotationDegrees");
        OB ob7 = new OB();
        ob7.mjFkc(7);
        lgHUyS = aZxhMjFkc7.AZxh(ob7.AZxh()).mjFkc();
    }

    @Override // o.mYYU
    public final /* bridge */ /* synthetic */ void mjFkc(Object obj, Object obj2) {
        C1035eM c1035eM = (C1035eM) obj;
        S2 s2 = (S2) obj2;
        s2.wA(AZxh, c1035eM.xJ());
        s2.wA(wA, c1035eM.AZxh());
        s2.wA(ZfxDd, c1035eM.mjFkc());
        s2.wA(KLFTb, c1035eM.wA());
        s2.wA(JHa, c1035eM.KLFTb());
        s2.wA(xJ, c1035eM.ZfxDd());
        s2.wA(lgHUyS, c1035eM.JHa());
    }
}
