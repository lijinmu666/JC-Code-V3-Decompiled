package o;

/* renamed from: o.ar, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0822ar extends Vx implements Ly {
    public /* synthetic */ C0822ar(AbstractC0763Zq abstractC0763Zq) {
        super(C0883br.zbb);
    }
}
