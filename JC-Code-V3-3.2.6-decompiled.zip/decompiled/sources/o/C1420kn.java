package o;

import org.conscrypt.BuildConfig;

/* renamed from: o.kn, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C1420kn extends AbstractC1010dy implements Ly {
    private static final C1420kn zbb;
    private int zbd;
    private boolean zbe;
    private String zbf = BuildConfig.FLAVOR;

    static {
        C1420kn c1420kn = new C1420kn();
        zbb = c1420kn;
        AbstractC1010dy.YoKzxo(C1420kn.class, c1420kn);
    }

    @Override // o.AbstractC1010dy
    public final Object IEE(int i, Object obj, Object obj2) {
        int i2 = i - 1;
        if (i2 == 0) {
            return (byte) 1;
        }
        if (i2 == 2) {
            return AbstractC1010dy.ETF(zbb, "\u0001\u0002\u0000\u0001\u0001\u0002\u0002\u0000\u0000\u0000\u0001ဇ\u0000\u0002ဈ\u0001", new Object[]{"zbd", "zbe", "zbf"});
        }
        if (i2 == 3) {
            return new C1420kn();
        }
        AbstractC0877bl abstractC0877bl = null;
        if (i2 == 4) {
            return new C1180gm(abstractC0877bl);
        }
        if (i2 != 5) {
            return null;
        }
        return zbb;
    }
}
