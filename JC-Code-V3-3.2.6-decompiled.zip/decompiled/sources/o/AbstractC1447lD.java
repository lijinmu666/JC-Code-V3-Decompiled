package o;

/* renamed from: o.lD, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC1447lD extends AbstractC2106wB {
    public static boolean mjFkc(Object obj, Object obj2) {
        if (obj != obj2) {
            return obj != null && obj.equals(obj2);
        }
        return true;
    }
}
