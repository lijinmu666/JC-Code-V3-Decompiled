package o;

/* renamed from: o.Ho, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0346Ho extends AbstractC1010dy implements Ly {
    private static final C0346Ho zbb;
    private int zbd;
    private C0300Fo zbe;

    static {
        C0346Ho c0346Ho = new C0346Ho();
        zbb = c0346Ho;
        AbstractC1010dy.YoKzxo(C0346Ho.class, c0346Ho);
    }

    @Override // o.AbstractC1010dy
    public final Object IEE(int i, Object obj, Object obj2) {
        int i2 = i - 1;
        if (i2 == 0) {
            return (byte) 1;
        }
        if (i2 == 2) {
            return AbstractC1010dy.ETF(zbb, "\u0001\u0001\u0000\u0001\u0001\u0001\u0001\u0000\u0000\u0000\u0001ဉ\u0000", new Object[]{"zbd", "zbe"});
        }
        if (i2 == 3) {
            return new C0346Ho();
        }
        AbstractC2263yo abstractC2263yo = null;
        if (i2 == 4) {
            return new C0208Bo(abstractC2263yo);
        }
        if (i2 != 5) {
            return null;
        }
        return zbb;
    }
}
