package o;

import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.RemoteException;
import android.util.Log;

/* loaded from: classes.dex */
public final class OH extends AbstractC1745qB {
    public final /* synthetic */ KRckQg lgHUyS;
    public final IBinder xJ;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public OH(KRckQg kRckQg, int i, IBinder iBinder, Bundle bundle) {
        super(kRckQg, i, bundle);
        this.lgHUyS = kRckQg;
        this.xJ = iBinder;
    }

    @Override // o.AbstractC1745qB
    public final void JHa(eEOGOh eeogoh) {
        if (this.lgHUyS.Ucbh != null) {
            this.lgHUyS.Ucbh.ZfxDd(eeogoh);
        }
        this.lgHUyS.zvd(eeogoh);
    }

    @Override // o.AbstractC1745qB
    public final boolean xJ() throws RemoteException {
        try {
            IBinder iBinder = this.xJ;
            I3.xJ(iBinder);
            String interfaceDescriptor = iBinder.getInterfaceDescriptor();
            if (!this.lgHUyS.wJVbdd().equals(interfaceDescriptor)) {
                Log.w("GmsClient", "service descriptor mismatch: " + this.lgHUyS.wJVbdd() + " vs. " + interfaceDescriptor);
                return false;
            }
            IInterface iInterfaceIEE = this.lgHUyS.IEE(this.xJ);
            if (iInterfaceIEE == null || !(KRckQg.JBhc(this.lgHUyS, 2, 4, iInterfaceIEE) || KRckQg.JBhc(this.lgHUyS, 3, 4, iInterfaceIEE))) {
                return false;
            }
            this.lgHUyS.vI = null;
            KRckQg kRckQg = this.lgHUyS;
            Bundle bundleHuTpC = kRckQg.huTpC();
            if (kRckQg.eyqo == null) {
                return true;
            }
            this.lgHUyS.eyqo.xJ(bundleHuTpC);
            return true;
        } catch (RemoteException unused) {
            Log.w("GmsClient", "service probably died");
            return false;
        }
    }
}
