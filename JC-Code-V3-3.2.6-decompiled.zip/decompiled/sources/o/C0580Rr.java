package o;

import org.conscrypt.BuildConfig;

/* renamed from: o.Rr, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0580Rr extends AbstractC1010dy implements Ly {
    private static final C0580Rr zbb;
    private int zbd;
    private C0671Vq zbg;
    private C0671Vq zbh;
    private boolean zbi;
    private boolean zbj;
    private boolean zbk;
    private Cz zbm;
    private String zbe = BuildConfig.FLAVOR;
    private String zbf = BuildConfig.FLAVOR;
    private int zbl = 1;

    static {
        C0580Rr c0580Rr = new C0580Rr();
        zbb = c0580Rr;
        AbstractC1010dy.YoKzxo(C0580Rr.class, c0580Rr);
    }

    @Override // o.AbstractC1010dy
    public final Object IEE(int i, Object obj, Object obj2) {
        int i2 = i - 1;
        if (i2 == 0) {
            return (byte) 1;
        }
        if (i2 == 2) {
            return AbstractC1010dy.ETF(zbb, "\u0001\t\u0000\u0001\u0001\n\t\u0000\u0000\u0000\u0001ဈ\u0000\u0002ဇ\u0005\u0003ဇ\u0006\u0004ဉ\u0002\u0006ဇ\u0004\u0007င\u0007\bဉ\b\tဉ\u0003\nဈ\u0001", new Object[]{"zbd", "zbe", "zbj", "zbk", "zbg", "zbi", "zbl", "zbm", "zbh", "zbf"});
        }
        if (i2 == 3) {
            return new C0580Rr();
        }
        Lr lr = null;
        if (i2 == 4) {
            return new C0464Mr(lr);
        }
        if (i2 != 5) {
            return null;
        }
        return zbb;
    }
}
