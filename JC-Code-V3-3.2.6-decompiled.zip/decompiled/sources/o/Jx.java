package o;

import org.bouncycastle.crypto.digests.Blake2xsDigest;

/* loaded from: classes.dex */
public final class Jx {
    public final int AZxh;
    public final Object mjFkc;

    public Jx(Object obj, int i) {
        this.mjFkc = obj;
        this.AZxh = i;
    }

    public final boolean equals(Object obj) {
        if (!(obj instanceof Jx)) {
            return false;
        }
        Jx jx = (Jx) obj;
        return this.mjFkc == jx.mjFkc && this.AZxh == jx.AZxh;
    }

    public final int hashCode() {
        return (System.identityHashCode(this.mjFkc) * Blake2xsDigest.UNKNOWN_DIGEST_LENGTH) + this.AZxh;
    }
}
