package o;

import o.C0797aQ;

/* renamed from: o.vQ, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C2060vQ implements R2 {
    public static final C2060vQ mjFkc = new C2060vQ();

    static {
        C0797aQ.AZxh aZxhMjFkc = C0797aQ.mjFkc("errorCode");
        C1389kF c1389kF = new C1389kF();
        c1389kF.mjFkc(1);
        aZxhMjFkc.AZxh(c1389kF.AZxh()).mjFkc();
        C0797aQ.AZxh aZxhMjFkc2 = C0797aQ.mjFkc("textDetectionOptions");
        C1389kF c1389kF2 = new C1389kF();
        c1389kF2.mjFkc(2);
        aZxhMjFkc2.AZxh(c1389kF2.AZxh()).mjFkc();
    }

    @Override // o.mYYU
    public final /* bridge */ /* synthetic */ void mjFkc(Object obj, Object obj2) {
        AbstractC2102w7.mjFkc(obj);
        throw null;
    }
}
