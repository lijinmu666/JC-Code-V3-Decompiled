package o;

import android.os.Parcel;
import android.os.Parcelable;

/* loaded from: classes.dex */
public final class MW implements Parcelable.Creator {
    @Override // android.os.Parcelable.Creator
    public final /* bridge */ /* synthetic */ Object createFromParcel(Parcel parcel) {
        int iIEE = AbstractC1319j6.IEE(parcel);
        boolean zDt = false;
        int iYoKzxo = 0;
        boolean zDt2 = false;
        String strZfxDd = null;
        String strZfxDd2 = null;
        String strZfxDd3 = null;
        String strZfxDd4 = null;
        while (parcel.dataPosition() < iIEE) {
            int iVA = AbstractC1319j6.VA(parcel);
            switch (AbstractC1319j6.qdMbNW(iVA)) {
                case 1:
                    strZfxDd = AbstractC1319j6.ZfxDd(parcel, iVA);
                    break;
                case 2:
                    strZfxDd2 = AbstractC1319j6.ZfxDd(parcel, iVA);
                    break;
                case 3:
                    strZfxDd3 = AbstractC1319j6.ZfxDd(parcel, iVA);
                    break;
                case 4:
                    zDt = AbstractC1319j6.Dt(parcel, iVA);
                    break;
                case 5:
                    iYoKzxo = AbstractC1319j6.YoKzxo(parcel, iVA);
                    break;
                case 6:
                    strZfxDd4 = AbstractC1319j6.ZfxDd(parcel, iVA);
                    break;
                case 7:
                    zDt2 = AbstractC1319j6.Dt(parcel, iVA);
                    break;
                default:
                    AbstractC1319j6.fehf(parcel, iVA);
                    break;
            }
        }
        AbstractC1319j6.lgHUyS(parcel, iIEE);
        return new LW(strZfxDd, strZfxDd2, strZfxDd3, zDt, iYoKzxo, strZfxDd4, zDt2);
    }

    @Override // android.os.Parcelable.Creator
    public final /* synthetic */ Object[] newArray(int i) {
        return new LW[i];
    }
}
