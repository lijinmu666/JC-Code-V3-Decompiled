package o;

/* loaded from: classes.dex */
public abstract class F9 {
    public static F9 mjFkc;

    public static F9 mjFkc() {
        if (mjFkc == null) {
            mjFkc = new G9();
        }
        return mjFkc;
    }
}
