package o;

/* renamed from: o.zc, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C2312zc {
    public final int AZxh;
    public final int ZfxDd;
    public final C1137g2 mjFkc;
    public final long wA;

    public C2312zc(C1137g2 c1137g2, int i, long j, int i2) {
        this.mjFkc = c1137g2;
        this.AZxh = i;
        this.wA = j;
        this.ZfxDd = i2;
    }
}
