package o;

/* renamed from: o.sF, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public @interface InterfaceC1868sF {
    int zza();

    EnumC1749qF zzb() default EnumC1749qF.DEFAULT;
}
