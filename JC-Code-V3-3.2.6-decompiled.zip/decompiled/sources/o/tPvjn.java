package o;

/* loaded from: classes.dex */
public final /* synthetic */ class tPvjn implements InterfaceC0775a4 {
    public final String mjFkc;

    public tPvjn(String str) {
        this.mjFkc = str;
    }

    public static InterfaceC0775a4 mjFkc(String str) {
        return new tPvjn(str);
    }

    @Override // o.InterfaceC0775a4
    public Object get() {
        return TFbkuO.wA(this.mjFkc);
    }
}
