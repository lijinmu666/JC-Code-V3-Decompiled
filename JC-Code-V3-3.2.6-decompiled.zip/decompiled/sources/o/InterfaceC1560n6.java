package o;

/* renamed from: o.n6, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public interface InterfaceC1560n6 extends W0 {
    androidx.savedstate.mjFkc mjFkc();
}
