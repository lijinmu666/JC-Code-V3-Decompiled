package o;

import android.app.PendingIntent;
import android.os.Parcel;
import android.os.Parcelable;

/* renamed from: o.Xb, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0702Xb implements Parcelable.Creator {
    @Override // android.os.Parcelable.Creator
    public final /* bridge */ /* synthetic */ Object createFromParcel(Parcel parcel) {
        int iIEE = AbstractC1319j6.IEE(parcel);
        PendingIntent pendingIntent = null;
        while (parcel.dataPosition() < iIEE) {
            int iVA = AbstractC1319j6.VA(parcel);
            if (AbstractC1319j6.qdMbNW(iVA) != 1) {
                AbstractC1319j6.fehf(parcel, iVA);
            } else {
                pendingIntent = (PendingIntent) AbstractC1319j6.wA(parcel, iVA, PendingIntent.CREATOR);
            }
        }
        AbstractC1319j6.lgHUyS(parcel, iIEE);
        return new C1795r2(pendingIntent);
    }

    @Override // android.os.Parcelable.Creator
    public final /* synthetic */ Object[] newArray(int i) {
        return new C1795r2[i];
    }
}
