package o;

/* renamed from: o.Ao, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0185Ao extends Vx implements Ly {
    public /* synthetic */ C0185Ao(AbstractC2082vo abstractC2082vo) {
        super(C0231Co.zbb);
    }
}
