package o;

import android.R;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.InsetDrawable;
import android.graphics.drawable.StateListDrawable;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.google.android.material.internal.CheckableImageButton;
import java.util.Iterator;
import java.util.LinkedHashSet;
import o.C0806ab;

/* loaded from: classes.dex */
public final class M1<S> extends ZlB {
    public int LREOK;
    public AbstractC2098w3 NKyg;
    public int Qr;
    public O1 Vgyli;
    public CharSequence XD;
    public int XFUzSY;
    public CharSequence XbiWeM;
    public CharSequence XtE;
    public int fFz;
    public boolean gYa;
    public boolean giT;
    public com.google.android.material.datepicker.mjFkc gtIJp;
    public TextView jx;
    public com.google.android.material.datepicker.AZxh kism;
    public Button lti;
    public CharSequence sRqPfw;
    public CheckableImageButton tISON;
    public int tjSezt;
    public TextView uH;
    public CharSequence yX;
    public static final Object gtr = "CONFIRM_BUTTON_TAG";
    public static final Object Dp = "CANCEL_BUTTON_TAG";
    public static final Object fLidf = "TOGGLE_BUTTON_TAG";
    public final LinkedHashSet IVlxe = new LinkedHashSet();
    public final LinkedHashSet Moer = new LinkedHashSet();
    public final LinkedHashSet SmIWf = new LinkedHashSet();
    public final LinkedHashSet SOS = new LinkedHashSet();

    public class AZxh extends AbstractC1016e3 {
        public AZxh() {
        }
    }

    public class mjFkc implements X2 {
        public final /* synthetic */ View AZxh;
        public final /* synthetic */ int mjFkc;
        public final /* synthetic */ int wA;

        public mjFkc(int i, View view, int i2) {
            this.mjFkc = i;
            this.AZxh = view;
            this.wA = i2;
        }

        @Override // o.X2
        public C0806ab mjFkc(View view, C0806ab c0806ab) {
            int i = c0806ab.JHa(C0806ab.VA.ZfxDd()).AZxh;
            if (this.mjFkc >= 0) {
                this.AZxh.getLayoutParams().height = this.mjFkc + i;
                View view2 = this.AZxh;
                view2.setLayoutParams(view2.getLayoutParams());
            }
            View view3 = this.AZxh;
            view3.setPadding(view3.getPaddingLeft(), this.wA + i, this.AZxh.getPaddingRight(), this.AZxh.getPaddingBottom());
            return c0806ab;
        }
    }

    public class wA implements View.OnClickListener {
        public wA() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            Button unused = M1.this.lti;
            M1.Xxz(M1.this);
            throw null;
        }
    }

    public static int IvRQOa(Context context) throws Resources.NotFoundException {
        Resources resources = context.getResources();
        int dimensionPixelOffset = resources.getDimensionPixelOffset(AbstractC1558n4.BAnRFn);
        int i = C1976u2.ETF().ZfxDd;
        return (dimensionPixelOffset * 2) + (resources.getDimensionPixelSize(AbstractC1558n4.wJVbdd) * i) + ((i - 1) * resources.getDimensionPixelOffset(AbstractC1558n4.Ne));
    }

    public static Drawable Jk(Context context) {
        StateListDrawable stateListDrawable = new StateListDrawable();
        stateListDrawable.addState(new int[]{R.attr.state_checked}, vjlshU.AZxh(context, AbstractC1797r4.AZxh));
        stateListDrawable.addState(new int[0], vjlshU.AZxh(context, AbstractC1797r4.wA));
        return stateListDrawable;
    }

    public static boolean RWyiuY(Context context, int i) throws Resources.NotFoundException {
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(F1.ZfxDd(context, AbstractC1199h4.qGY, com.google.android.material.datepicker.AZxh.class.getCanonicalName()), new int[]{i});
        boolean z = typedArrayObtainStyledAttributes.getBoolean(0, false);
        typedArrayObtainStyledAttributes.recycle();
        return z;
    }

    public static /* synthetic */ UlIi Xxz(M1 m1) {
        m1.mPWV();
        return null;
    }

    public static CharSequence dkKKW(CharSequence charSequence) {
        if (charSequence == null) {
            return null;
        }
        String[] strArrSplit = TextUtils.split(String.valueOf(charSequence), "\n");
        return strArrSplit.length > 1 ? strArrSplit[0] : charSequence;
    }

    private UlIi mPWV() {
        AbstractC2102w7.mjFkc(VA().getParcelable("DATE_SELECTOR_KEY"));
        return null;
    }

    public static boolean oaI(Context context) {
        return RWyiuY(context, AbstractC1199h4.wJVbdd);
    }

    public static boolean ybBTr(Context context) {
        return RWyiuY(context, R.attr.windowFullscreen);
    }

    public final int APn(Context context) {
        int i = this.Qr;
        if (i != 0) {
            return i;
        }
        mPWV();
        throw null;
    }

    public final void CTcA(CheckableImageButton checkableImageButton) {
        this.tISON.setContentDescription(this.tISON.isChecked() ? checkableImageButton.getContext().getString(N4.rkYL) : checkableImageButton.getContext().getString(N4.fehf));
    }

    @Override // o.ZlB
    public final Dialog FbxKQm(Bundle bundle) {
        Dialog dialog = new Dialog(fFz(), APn(fFz()));
        Context context = dialog.getContext();
        this.gYa = ybBTr(context);
        int iZfxDd = F1.ZfxDd(context, AbstractC1199h4.lgHUyS, M1.class.getCanonicalName());
        O1 o1 = new O1(context, null, AbstractC1199h4.qGY, R4.VA);
        this.Vgyli = o1;
        o1.cMLeY(context);
        this.Vgyli.uHVRx(ColorStateList.valueOf(iZfxDd));
        this.Vgyli.GMIER(T9.IEE(dialog.getWindow().getDecorView()));
        return dialog;
    }

    @Override // o.ZlB, androidx.fragment.app.Fragment
    public final void JYn(Bundle bundle) throws Resources.NotFoundException {
        super.JYn(bundle);
        if (bundle == null) {
            bundle = VA();
        }
        this.Qr = bundle.getInt("OVERRIDE_THEME_RES_ID");
        AbstractC2102w7.mjFkc(bundle.getParcelable("DATE_SELECTOR_KEY"));
        this.gtIJp = (com.google.android.material.datepicker.mjFkc) bundle.getParcelable("CALENDAR_CONSTRAINTS_KEY");
        AbstractC2102w7.mjFkc(bundle.getParcelable("DAY_VIEW_DECORATOR_KEY"));
        this.tjSezt = bundle.getInt("TITLE_TEXT_RES_ID_KEY");
        this.yX = bundle.getCharSequence("TITLE_TEXT_KEY");
        this.LREOK = bundle.getInt("INPUT_MODE_KEY");
        this.fFz = bundle.getInt("POSITIVE_BUTTON_TEXT_RES_ID_KEY");
        this.XbiWeM = bundle.getCharSequence("POSITIVE_BUTTON_TEXT_KEY");
        this.XFUzSY = bundle.getInt("NEGATIVE_BUTTON_TEXT_RES_ID_KEY");
        this.XtE = bundle.getCharSequence("NEGATIVE_BUTTON_TEXT_KEY");
        CharSequence text = this.yX;
        if (text == null) {
            text = fFz().getResources().getText(this.tjSezt);
        }
        this.sRqPfw = text;
        this.XD = dkKKW(text);
    }

    public String Jidt() {
        mPWV();
        YoKzxo();
        throw null;
    }

    public final void KRckQg(Window window) {
        if (this.giT) {
            return;
        }
        View viewFindViewById = XbiWeM().findViewById(D4.JHa);
        LyQ.mjFkc(window, true, AbstractC1887sa.wA(viewFindViewById), null);
        T9.yX(viewFindViewById, new mjFkc(viewFindViewById.getLayoutParams().height, viewFindViewById, viewFindViewById.getPaddingTop()));
        this.giT = true;
    }

    public final String NV() {
        mPWV();
        fFz();
        throw null;
    }

    public final void Vu() {
        AbstractC2098w3 abstractC2098w3SKTn;
        int iAPn = APn(fFz());
        mPWV();
        this.kism = com.google.android.material.datepicker.AZxh.KRckQg(null, iAPn, this.gtIJp, null);
        boolean zIsChecked = this.tISON.isChecked();
        if (zIsChecked) {
            mPWV();
            abstractC2098w3SKTn = Q1.SKTn(null, iAPn, this.gtIJp);
        } else {
            abstractC2098w3SKTn = this.kism;
        }
        this.NKyg = abstractC2098w3SKTn;
        oVXlhB(zIsChecked);
        uxlM(Jidt());
        androidx.fragment.app.lgHUyS lghuysDt = MiMN().Dt();
        lghuysDt.VA(D4.Ucbh, this.NKyg);
        lghuysDt.xJ();
        this.NKyg.hvGY(new AZxh());
    }

    @Override // o.ZlB, androidx.fragment.app.Fragment
    public void alEkx() throws Resources.NotFoundException {
        super.alEkx();
        Window window = tAfC().getWindow();
        if (this.gYa) {
            window.setLayout(-1, -1);
            window.setBackgroundDrawable(this.Vgyli);
            KRckQg(window);
        } else {
            window.setLayout(-2, -2);
            int dimensionPixelOffset = OjSQV().getDimensionPixelOffset(AbstractC1558n4.OjSQV);
            Rect rect = new Rect(dimensionPixelOffset, dimensionPixelOffset, dimensionPixelOffset, dimensionPixelOffset);
            window.setBackgroundDrawable(new InsetDrawable((Drawable) this.Vgyli, dimensionPixelOffset, dimensionPixelOffset, dimensionPixelOffset, dimensionPixelOffset));
            window.getDecorView().setOnTouchListener(new Q(tAfC(), rect));
        }
        Vu();
    }

    @Override // o.ZlB, androidx.fragment.app.Fragment
    public void dm() {
        this.NKyg.Rc();
        super.dm();
    }

    public final void knzZ(Context context) {
        this.tISON.setTag(fLidf);
        this.tISON.setImageDrawable(Jk(context));
        this.tISON.setChecked(this.LREOK != 0);
        T9.alEkx(this.tISON, null);
        CTcA(this.tISON);
        this.tISON.setOnClickListener(new wA());
    }

    @Override // androidx.fragment.app.Fragment
    public final View nxI(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View viewInflate = layoutInflater.inflate(this.gYa ? G4.eyqo : G4.diqgf, viewGroup);
        Context context = viewInflate.getContext();
        if (this.gYa) {
            viewInflate.findViewById(D4.Ucbh).setLayoutParams(new LinearLayout.LayoutParams(IvRQOa(context), -2));
        } else {
            viewInflate.findViewById(D4.huTpC).setLayoutParams(new LinearLayout.LayoutParams(IvRQOa(context), -1));
        }
        TextView textView = (TextView) viewInflate.findViewById(D4.VocHEe);
        this.uH = textView;
        T9.tQ(textView, 1);
        this.tISON = (CheckableImageButton) viewInflate.findViewById(D4.BAnRFn);
        this.jx = (TextView) viewInflate.findViewById(D4.lB);
        knzZ(context);
        this.lti = (Button) viewInflate.findViewById(D4.wA);
        mPWV();
        throw null;
    }

    public final void oVXlhB(boolean z) {
        this.jx.setText((z && sqndV()) ? this.XD : this.sRqPfw);
    }

    @Override // o.ZlB, android.content.DialogInterface.OnCancelListener
    public final void onCancel(DialogInterface dialogInterface) {
        Iterator it = this.SmIWf.iterator();
        while (it.hasNext()) {
            ((DialogInterface.OnCancelListener) it.next()).onCancel(dialogInterface);
        }
        super.onCancel(dialogInterface);
    }

    @Override // o.ZlB, android.content.DialogInterface.OnDismissListener
    public final void onDismiss(DialogInterface dialogInterface) {
        Iterator it = this.SOS.iterator();
        while (it.hasNext()) {
            ((DialogInterface.OnDismissListener) it.next()).onDismiss(dialogInterface);
        }
        ViewGroup viewGroup = (ViewGroup) rWxwaT();
        if (viewGroup != null) {
            viewGroup.removeAllViews();
        }
        super.onDismiss(dialogInterface);
    }

    public final boolean sqndV() {
        return OjSQV().getConfiguration().orientation == 2;
    }

    public void uxlM(String str) {
        this.uH.setContentDescription(NV());
        this.uH.setText(str);
    }
}
