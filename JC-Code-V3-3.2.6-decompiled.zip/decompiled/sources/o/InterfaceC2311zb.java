package o;

import android.graphics.drawable.Drawable;

/* renamed from: o.zb, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public interface InterfaceC2311zb {
    Drawable mjFkc();
}
