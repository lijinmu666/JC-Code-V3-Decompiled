package o;

/* renamed from: o.rH, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C1810rH {
    public Integer AZxh;
    public C2232yH mjFkc;
    public HR wA;

    public final C1810rH AZxh(HR hr) {
        this.wA = hr;
        return this;
    }

    public final CH KLFTb() {
        return new CH(this, null);
    }

    public final C1810rH mjFkc(Integer num) {
        this.AZxh = Integer.valueOf(num.intValue() & Integer.MAX_VALUE);
        return this;
    }

    public final C1810rH wA(C2232yH c2232yH) {
        this.mjFkc = c2232yH;
        return this;
    }
}
