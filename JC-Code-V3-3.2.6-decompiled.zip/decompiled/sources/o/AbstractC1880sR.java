package o;

/* renamed from: o.sR, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC1880sR {
}
