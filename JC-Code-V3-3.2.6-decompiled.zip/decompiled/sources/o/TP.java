package o;

/* loaded from: classes.dex */
public final class TP extends AbstractC1580nQ {
    public boolean AZxh;
    public byte ZfxDd;
    public String mjFkc;
    public int wA;

    @Override // o.AbstractC1580nQ
    public final AbstractC1580nQ AZxh(int i) {
        this.wA = 1;
        this.ZfxDd = (byte) (this.ZfxDd | 2);
        return this;
    }

    public final AbstractC1580nQ ZfxDd(String str) {
        this.mjFkc = "vision-common";
        return this;
    }

    @Override // o.AbstractC1580nQ
    public final AbstractC1580nQ mjFkc(boolean z) {
        this.AZxh = true;
        this.ZfxDd = (byte) (1 | this.ZfxDd);
        return this;
    }

    @Override // o.AbstractC1580nQ
    public final AbstractC1700pQ wA() {
        String str;
        if (this.ZfxDd == 3 && (str = this.mjFkc) != null) {
            return new C1221hQ(str, this.AZxh, this.wA, null);
        }
        StringBuilder sb = new StringBuilder();
        if (this.mjFkc == null) {
            sb.append(" libraryName");
        }
        if ((this.ZfxDd & 1) == 0) {
            sb.append(" enableFirelog");
        }
        if ((this.ZfxDd & 2) == 0) {
            sb.append(" firelogEventType");
        }
        throw new IllegalStateException("Missing required properties:".concat(sb.toString()));
    }
}
