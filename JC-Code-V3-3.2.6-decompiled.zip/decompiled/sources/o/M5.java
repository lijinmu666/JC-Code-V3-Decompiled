package o;

import android.database.sqlite.SQLiteDatabase;
import o.C0959d6;

/* loaded from: classes.dex */
public final /* synthetic */ class M5 implements C0959d6.AZxh {
    public final X8 AZxh;
    public final C0959d6 mjFkc;

    public M5(C0959d6 c0959d6, X8 x8) {
        this.mjFkc = c0959d6;
        this.AZxh = x8;
    }

    public static C0959d6.AZxh mjFkc(C0959d6 c0959d6, X8 x8) {
        return new M5(c0959d6, x8);
    }

    @Override // o.C0959d6.AZxh
    public Object apply(Object obj) {
        return C0959d6.wJVbdd(this.mjFkc, this.AZxh, (SQLiteDatabase) obj);
    }
}
