package o;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.PointF;
import android.graphics.Rect;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.util.Property;
import android.view.View;
import android.view.ViewGroup;
import java.util.Map;

/* loaded from: classes.dex */
public class JOe extends N8 {
    public static final String[] rWxwaT = {"android:changeBounds:bounds", "android:changeBounds:clip", "android:changeBounds:parent", "android:changeBounds:windowX", "android:changeBounds:windowY"};
    public static final Property Vnb = new AZxh(PointF.class, "boundsOrigin");
    public static final Property NPj = new wA(PointF.class, "topLeft");
    public static final Property vadzgd = new ZfxDd(PointF.class, "bottomRight");
    public static final Property oCFDzJ = new KLFTb(PointF.class, "bottomRight");
    public static final Property aqHPIZ = new JHa(PointF.class, "topLeft");
    public static final Property WrLQs = new xJ(PointF.class, "position");
    public static C1018e5 KRTLGT = new C1018e5();
    public int[] KLMXS = new int[2];
    public boolean zvd = false;
    public boolean cMLeY = false;

    public static class AZxh extends Property {
        public Rect mjFkc;

        public AZxh(Class cls, String str) {
            super(cls, str);
            this.mjFkc = new Rect();
        }

        @Override // android.util.Property
        /* renamed from: AZxh, reason: merged with bridge method [inline-methods] */
        public void set(Drawable drawable, PointF pointF) {
            drawable.copyBounds(this.mjFkc);
            this.mjFkc.offsetTo(Math.round(pointF.x), Math.round(pointF.y));
            drawable.setBounds(this.mjFkc);
        }

        @Override // android.util.Property
        /* renamed from: mjFkc, reason: merged with bridge method [inline-methods] */
        public PointF get(Drawable drawable) {
            drawable.copyBounds(this.mjFkc);
            Rect rect = this.mjFkc;
            return new PointF(rect.left, rect.top);
        }
    }

    public class Dt extends O8 {
        public final /* synthetic */ ViewGroup AZxh;
        public boolean mjFkc = false;

        public Dt(ViewGroup viewGroup) {
            this.AZxh = viewGroup;
        }

        @Override // o.O8, o.N8.JHa
        public void AZxh(N8 n8) {
            AbstractC0987da.AZxh(this.AZxh, false);
            this.mjFkc = true;
        }

        @Override // o.O8, o.N8.JHa
        public void KLFTb(N8 n8) {
            AbstractC0987da.AZxh(this.AZxh, true);
        }

        @Override // o.O8, o.N8.JHa
        public void mjFkc(N8 n8) {
            AbstractC0987da.AZxh(this.AZxh, false);
        }

        @Override // o.N8.JHa
        public void wA(N8 n8) {
            if (!this.mjFkc) {
                AbstractC0987da.AZxh(this.AZxh, false);
            }
            n8.aqHPIZ(this);
        }
    }

    public static class ETF {
        public int AZxh;
        public int JHa;
        public View KLFTb;
        public int ZfxDd;
        public int mjFkc;
        public int wA;
        public int xJ;

        public ETF(View view) {
            this.KLFTb = view;
        }

        public final void AZxh() {
            AbstractC1947ta.JHa(this.KLFTb, this.mjFkc, this.AZxh, this.wA, this.ZfxDd);
            this.JHa = 0;
            this.xJ = 0;
        }

        public void mjFkc(PointF pointF) {
            this.wA = Math.round(pointF.x);
            this.ZfxDd = Math.round(pointF.y);
            int i = this.xJ + 1;
            this.xJ = i;
            if (this.JHa == i) {
                AZxh();
            }
        }

        public void wA(PointF pointF) {
            this.mjFkc = Math.round(pointF.x);
            this.AZxh = Math.round(pointF.y);
            int i = this.JHa + 1;
            this.JHa = i;
            if (i == this.xJ) {
                AZxh();
            }
        }
    }

    public static class JHa extends Property {
        public JHa(Class cls, String str) {
            super(cls, str);
        }

        @Override // android.util.Property
        /* renamed from: AZxh, reason: merged with bridge method [inline-methods] */
        public void set(View view, PointF pointF) {
            AbstractC1947ta.JHa(view, Math.round(pointF.x), Math.round(pointF.y), view.getRight(), view.getBottom());
        }

        @Override // android.util.Property
        /* renamed from: mjFkc, reason: merged with bridge method [inline-methods] */
        public PointF get(View view) {
            return null;
        }
    }

    public static class KLFTb extends Property {
        public KLFTb(Class cls, String str) {
            super(cls, str);
        }

        @Override // android.util.Property
        /* renamed from: AZxh, reason: merged with bridge method [inline-methods] */
        public void set(View view, PointF pointF) {
            AbstractC1947ta.JHa(view, view.getLeft(), view.getTop(), Math.round(pointF.x), Math.round(pointF.y));
        }

        @Override // android.util.Property
        /* renamed from: mjFkc, reason: merged with bridge method [inline-methods] */
        public PointF get(View view) {
            return null;
        }
    }

    public static class ZfxDd extends Property {
        public ZfxDd(Class cls, String str) {
            super(cls, str);
        }

        @Override // android.util.Property
        /* renamed from: AZxh, reason: merged with bridge method [inline-methods] */
        public void set(ETF etf, PointF pointF) {
            etf.mjFkc(pointF);
        }

        @Override // android.util.Property
        /* renamed from: mjFkc, reason: merged with bridge method [inline-methods] */
        public PointF get(ETF etf) {
            return null;
        }
    }

    public class lgHUyS extends AnimatorListenerAdapter {
        private ETF mViewBounds;
        public final /* synthetic */ ETF mjFkc;

        public lgHUyS(ETF etf) {
            this.mjFkc = etf;
            this.mViewBounds = etf;
        }
    }

    public class mjFkc extends AnimatorListenerAdapter {
        public final /* synthetic */ BitmapDrawable AZxh;
        public final /* synthetic */ float ZfxDd;
        public final /* synthetic */ ViewGroup mjFkc;
        public final /* synthetic */ View wA;

        public mjFkc(ViewGroup viewGroup, BitmapDrawable bitmapDrawable, View view, float f) {
            this.mjFkc = viewGroup;
            this.AZxh = bitmapDrawable;
            this.wA = view;
            this.ZfxDd = f;
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationEnd(Animator animator) {
            AbstractC1947ta.AZxh(this.mjFkc).ZfxDd(this.AZxh);
            AbstractC1947ta.xJ(this.wA, this.ZfxDd);
        }
    }

    public class qdMbNW extends AnimatorListenerAdapter {
        public final /* synthetic */ View AZxh;
        public final /* synthetic */ int JHa;
        public final /* synthetic */ int KLFTb;
        public final /* synthetic */ int ZfxDd;
        public boolean mjFkc;
        public final /* synthetic */ Rect wA;
        public final /* synthetic */ int xJ;

        public qdMbNW(View view, Rect rect, int i, int i2, int i3, int i4) {
            this.AZxh = view;
            this.wA = rect;
            this.ZfxDd = i;
            this.KLFTb = i2;
            this.JHa = i3;
            this.xJ = i4;
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationCancel(Animator animator) {
            this.mjFkc = true;
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationEnd(Animator animator) {
            if (this.mjFkc) {
                return;
            }
            T9.Moer(this.AZxh, this.wA);
            AbstractC1947ta.JHa(this.AZxh, this.ZfxDd, this.KLFTb, this.JHa, this.xJ);
        }
    }

    public static class wA extends Property {
        public wA(Class cls, String str) {
            super(cls, str);
        }

        @Override // android.util.Property
        /* renamed from: AZxh, reason: merged with bridge method [inline-methods] */
        public void set(ETF etf, PointF pointF) {
            etf.wA(pointF);
        }

        @Override // android.util.Property
        /* renamed from: mjFkc, reason: merged with bridge method [inline-methods] */
        public PointF get(ETF etf) {
            return null;
        }
    }

    public static class xJ extends Property {
        public xJ(Class cls, String str) {
            super(cls, str);
        }

        @Override // android.util.Property
        /* renamed from: AZxh, reason: merged with bridge method [inline-methods] */
        public void set(View view, PointF pointF) {
            int iRound = Math.round(pointF.x);
            int iRound2 = Math.round(pointF.y);
            AbstractC1947ta.JHa(view, iRound, iRound2, view.getWidth() + iRound, view.getHeight() + iRound2);
        }

        @Override // android.util.Property
        /* renamed from: mjFkc, reason: merged with bridge method [inline-methods] */
        public PointF get(View view) {
            return null;
        }
    }

    public final void JBhc(T8 t8) {
        View view = t8.AZxh;
        if (!T9.rWxwaT(view) && view.getWidth() == 0 && view.getHeight() == 0) {
            return;
        }
        t8.mjFkc.put("android:changeBounds:bounds", new Rect(view.getLeft(), view.getTop(), view.getRight(), view.getBottom()));
        t8.mjFkc.put("android:changeBounds:parent", t8.AZxh.getParent());
        if (this.cMLeY) {
            t8.AZxh.getLocationInWindow(this.KLMXS);
            t8.mjFkc.put("android:changeBounds:windowX", Integer.valueOf(this.KLMXS[0]));
            t8.mjFkc.put("android:changeBounds:windowY", Integer.valueOf(this.KLMXS[1]));
        }
        if (this.zvd) {
            t8.mjFkc.put("android:changeBounds:clip", T9.qGY(view));
        }
    }

    @Override // o.N8
    public String[] OjSQV() {
        return rWxwaT;
    }

    @Override // o.N8
    public void VA(T8 t8) {
        JBhc(t8);
    }

    public final boolean Vdz(View view, View view2) {
        if (!this.cMLeY) {
            return true;
        }
        T8 t8Ucbh = Ucbh(view, true);
        if (t8Ucbh == null) {
            if (view == view2) {
                return true;
            }
        } else if (view2 == t8Ucbh.AZxh) {
            return true;
        }
        return false;
    }

    @Override // o.N8
    public Animator qGY(ViewGroup viewGroup, T8 t8, T8 t82) {
        int i;
        View view;
        int i2;
        ObjectAnimator objectAnimator;
        Animator animatorWA;
        if (t8 == null || t82 == null) {
            return null;
        }
        Map map = t8.mjFkc;
        Map map2 = t82.mjFkc;
        ViewGroup viewGroup2 = (ViewGroup) map.get("android:changeBounds:parent");
        ViewGroup viewGroup3 = (ViewGroup) map2.get("android:changeBounds:parent");
        if (viewGroup2 == null || viewGroup3 == null) {
            return null;
        }
        View view2 = t82.AZxh;
        if (!Vdz(viewGroup2, viewGroup3)) {
            int iIntValue = ((Integer) t8.mjFkc.get("android:changeBounds:windowX")).intValue();
            int iIntValue2 = ((Integer) t8.mjFkc.get("android:changeBounds:windowY")).intValue();
            int iIntValue3 = ((Integer) t82.mjFkc.get("android:changeBounds:windowX")).intValue();
            int iIntValue4 = ((Integer) t82.mjFkc.get("android:changeBounds:windowY")).intValue();
            if (iIntValue == iIntValue3 && iIntValue2 == iIntValue4) {
                return null;
            }
            viewGroup.getLocationInWindow(this.KLMXS);
            Bitmap bitmapCreateBitmap = Bitmap.createBitmap(view2.getWidth(), view2.getHeight(), Bitmap.Config.ARGB_8888);
            view2.draw(new Canvas(bitmapCreateBitmap));
            BitmapDrawable bitmapDrawable = new BitmapDrawable(bitmapCreateBitmap);
            float fWA = AbstractC1947ta.wA(view2);
            AbstractC1947ta.xJ(view2, 0.0f);
            AbstractC1947ta.AZxh(viewGroup).AZxh(bitmapDrawable);
            AbstractC1917t3 abstractC1917t3Gd = Gd();
            int[] iArr = this.KLMXS;
            int i3 = iArr[0];
            int i4 = iArr[1];
            ObjectAnimator objectAnimatorOfPropertyValuesHolder = ObjectAnimator.ofPropertyValuesHolder(bitmapDrawable, Y3.mjFkc(Vnb, abstractC1917t3Gd.mjFkc(iIntValue - i3, iIntValue2 - i4, iIntValue3 - i3, iIntValue4 - i4)));
            objectAnimatorOfPropertyValuesHolder.addListener(new mjFkc(viewGroup, bitmapDrawable, view2, fWA));
            return objectAnimatorOfPropertyValuesHolder;
        }
        Rect rect = (Rect) t8.mjFkc.get("android:changeBounds:bounds");
        Rect rect2 = (Rect) t82.mjFkc.get("android:changeBounds:bounds");
        int i5 = rect.left;
        int i6 = rect2.left;
        int i7 = rect.top;
        int i8 = rect2.top;
        int i9 = rect.right;
        int i10 = rect2.right;
        int i11 = rect.bottom;
        int i12 = rect2.bottom;
        int i13 = i9 - i5;
        int i14 = i11 - i7;
        int i15 = i10 - i6;
        int i16 = i12 - i8;
        Rect rect3 = (Rect) t8.mjFkc.get("android:changeBounds:clip");
        Rect rect4 = (Rect) t82.mjFkc.get("android:changeBounds:clip");
        if ((i13 == 0 || i14 == 0) && (i15 == 0 || i16 == 0)) {
            i = 0;
        } else {
            i = (i5 == i6 && i7 == i8) ? 0 : 1;
            if (i9 != i10 || i11 != i12) {
                i++;
            }
        }
        if ((rect3 != null && !rect3.equals(rect4)) || (rect3 == null && rect4 != null)) {
            i++;
        }
        if (i <= 0) {
            return null;
        }
        if (this.zvd) {
            view = view2;
            AbstractC1947ta.JHa(view, i5, i7, Math.max(i13, i15) + i5, Math.max(i14, i16) + i7);
            ObjectAnimator objectAnimatorMjFkc = (i5 == i6 && i7 == i8) ? null : Q2.mjFkc(view, WrLQs, Gd().mjFkc(i5, i7, i6, i8));
            if (rect3 == null) {
                i2 = 0;
                rect3 = new Rect(0, 0, i13, i14);
            } else {
                i2 = 0;
            }
            Rect rect5 = rect4 == null ? new Rect(i2, i2, i15, i16) : rect4;
            if (rect3.equals(rect5)) {
                objectAnimator = null;
            } else {
                T9.Moer(view, rect3);
                ObjectAnimator objectAnimatorOfObject = ObjectAnimator.ofObject(view, "clipBounds", KRTLGT, rect3, rect5);
                objectAnimatorOfObject.addListener(new qdMbNW(view, rect4, i6, i8, i10, i12));
                objectAnimator = objectAnimatorOfObject;
            }
            animatorWA = S8.wA(objectAnimatorMjFkc, objectAnimator);
        } else {
            view = view2;
            AbstractC1947ta.JHa(view, i5, i7, i9, i11);
            if (i != 2) {
                animatorWA = (i5 == i6 && i7 == i8) ? Q2.mjFkc(view, oCFDzJ, Gd().mjFkc(i9, i11, i10, i12)) : Q2.mjFkc(view, aqHPIZ, Gd().mjFkc(i5, i7, i6, i8));
            } else if (i13 == i15 && i14 == i16) {
                animatorWA = Q2.mjFkc(view, WrLQs, Gd().mjFkc(i5, i7, i6, i8));
            } else {
                ETF etf = new ETF(view);
                ObjectAnimator objectAnimatorMjFkc2 = Q2.mjFkc(etf, NPj, Gd().mjFkc(i5, i7, i6, i8));
                ObjectAnimator objectAnimatorMjFkc3 = Q2.mjFkc(etf, vadzgd, Gd().mjFkc(i9, i11, i10, i12));
                AnimatorSet animatorSet = new AnimatorSet();
                animatorSet.playTogether(objectAnimatorMjFkc2, objectAnimatorMjFkc3);
                animatorSet.addListener(new lgHUyS(etf));
                animatorWA = animatorSet;
            }
        }
        if (view.getParent() instanceof ViewGroup) {
            ViewGroup viewGroup4 = (ViewGroup) view.getParent();
            AbstractC0987da.AZxh(viewGroup4, true);
            mjFkc(new Dt(viewGroup4));
        }
        return animatorWA;
    }

    @Override // o.N8
    public void qdMbNW(T8 t8) {
        JBhc(t8);
    }
}
