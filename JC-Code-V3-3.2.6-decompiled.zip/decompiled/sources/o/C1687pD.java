package o;

import java.io.Serializable;
import java.util.AbstractMap;
import java.util.Arrays;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import kotlinx.coroutines.internal.LockFreeTaskQueueCore;

/* renamed from: o.pD, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C1687pD extends AbstractMap implements Serializable {
    public static final Object Dt = new Object();
    public transient int[] AZxh;
    public transient int JHa;
    public transient int KLFTb;
    public transient Object[] ZfxDd;
    public transient Set lgHUyS;
    public transient Object mjFkc;
    public transient Collection qdMbNW;
    public transient Object[] wA;
    public transient Set xJ;

    public C1687pD(int i) {
        Pq(12);
    }

    public static /* synthetic */ Object Dt(C1687pD c1687pD, int i) {
        return c1687pD.AZxh()[i];
    }

    public static /* synthetic */ Object MiMN(C1687pD c1687pD, int i) {
        return c1687pD.wA()[i];
    }

    public static /* synthetic */ Object VA(C1687pD c1687pD) {
        Object obj = c1687pD.mjFkc;
        Objects.requireNonNull(obj);
        return obj;
    }

    public static /* synthetic */ void fehf(C1687pD c1687pD, int i, Object obj) {
        c1687pD.wA()[i] = obj;
    }

    public final Object[] AZxh() {
        Object[] objArr = this.wA;
        Objects.requireNonNull(objArr);
        return objArr;
    }

    public final Object BAnRFn(Object obj) {
        if (!eyqo()) {
            int iHGpJ = HGpJ();
            Object obj2 = this.mjFkc;
            Objects.requireNonNull(obj2);
            int iAZxh = AbstractC1806rD.AZxh(obj, null, iHGpJ, obj2, mjFkc(), AZxh(), null);
            if (iAZxh != -1) {
                Object obj3 = wA()[iAZxh];
                diqgf(iAZxh, iHGpJ);
                this.JHa--;
                IEE();
                return obj3;
            }
        }
        return Dt;
    }

    public final int HGpJ() {
        return (1 << (this.KLFTb & 31)) - 1;
    }

    public final void IEE() {
        this.KLFTb += 32;
    }

    public final void Pq(int i) {
        this.KLFTb = AbstractC1028eF.mjFkc(i, 1, LockFreeTaskQueueCore.MAX_CAPACITY_MASK);
    }

    public final int VocHEe(int i, int i2, int i3, int i4) {
        int i5 = i2 - 1;
        Object objZfxDd = AbstractC1806rD.ZfxDd(i2);
        if (i4 != 0) {
            AbstractC1806rD.KLFTb(objZfxDd, i3 & i5, i4 + 1);
        }
        Object obj = this.mjFkc;
        Objects.requireNonNull(obj);
        int[] iArrMjFkc = mjFkc();
        for (int i6 = 0; i6 <= i; i6++) {
            int iWA = AbstractC1806rD.wA(obj, i6);
            while (iWA != 0) {
                int i7 = iWA - 1;
                int i8 = iArrMjFkc[i7];
                int i9 = ((~i) & i8) | i6;
                int i10 = i9 & i5;
                int iWA2 = AbstractC1806rD.wA(objZfxDd, i10);
                AbstractC1806rD.KLFTb(objZfxDd, i10, iWA);
                iArrMjFkc[i7] = ((~i5) & i9) | (iWA2 & i5);
                iWA = i8 & i;
            }
        }
        this.mjFkc = objZfxDd;
        lB(i5);
        return i5;
    }

    @Override // java.util.AbstractMap, java.util.Map
    public final void clear() {
        if (eyqo()) {
            return;
        }
        IEE();
        Map mapRkYL = rkYL();
        if (mapRkYL != null) {
            this.KLFTb = AbstractC1028eF.mjFkc(size(), 3, LockFreeTaskQueueCore.MAX_CAPACITY_MASK);
            mapRkYL.clear();
            this.mjFkc = null;
            this.JHa = 0;
            return;
        }
        Arrays.fill(AZxh(), 0, this.JHa, (Object) null);
        Arrays.fill(wA(), 0, this.JHa, (Object) null);
        Object obj = this.mjFkc;
        Objects.requireNonNull(obj);
        if (obj instanceof byte[]) {
            Arrays.fill((byte[]) obj, (byte) 0);
        } else if (obj instanceof short[]) {
            Arrays.fill((short[]) obj, (short) 0);
        } else {
            Arrays.fill((int[]) obj, 0);
        }
        Arrays.fill(mjFkc(), 0, this.JHa, 0);
        this.JHa = 0;
    }

    @Override // java.util.AbstractMap, java.util.Map
    public final boolean containsKey(Object obj) {
        Map mapRkYL = rkYL();
        return mapRkYL != null ? mapRkYL.containsKey(obj) : vI(obj) != -1;
    }

    @Override // java.util.AbstractMap, java.util.Map
    public final boolean containsValue(Object obj) {
        Map mapRkYL = rkYL();
        if (mapRkYL != null) {
            return mapRkYL.containsValue(obj);
        }
        for (int i = 0; i < this.JHa; i++) {
            if (SW.mjFkc(obj, wA()[i])) {
                return true;
            }
        }
        return false;
    }

    public final void diqgf(int i, int i2) {
        Object obj = this.mjFkc;
        Objects.requireNonNull(obj);
        int[] iArrMjFkc = mjFkc();
        Object[] objArrAZxh = AZxh();
        Object[] objArrWA = wA();
        int size = size();
        int i3 = size - 1;
        if (i >= i3) {
            objArrAZxh[i] = null;
            objArrWA[i] = null;
            iArrMjFkc[i] = 0;
            return;
        }
        int i4 = i + 1;
        Object obj2 = objArrAZxh[i3];
        objArrAZxh[i] = obj2;
        objArrWA[i] = objArrWA[i3];
        objArrAZxh[i3] = null;
        objArrWA[i3] = null;
        iArrMjFkc[i] = iArrMjFkc[i3];
        iArrMjFkc[i3] = 0;
        int iMjFkc = AbstractC1927tD.mjFkc(obj2) & i2;
        int iWA = AbstractC1806rD.wA(obj, iMjFkc);
        if (iWA == size) {
            AbstractC1806rD.KLFTb(obj, iMjFkc, i4);
            return;
        }
        while (true) {
            int i5 = iWA - 1;
            int i6 = iArrMjFkc[i5];
            int i7 = i6 & i2;
            if (i7 == size) {
                iArrMjFkc[i5] = ((~i2) & i6) | (i4 & i2);
                return;
            }
            iWA = i7;
        }
    }

    @Override // java.util.AbstractMap, java.util.Map
    public final Set entrySet() {
        Set set = this.lgHUyS;
        if (set != null) {
            return set;
        }
        OC oc = new OC(this);
        this.lgHUyS = oc;
        return oc;
    }

    public final boolean eyqo() {
        return this.mjFkc == null;
    }

    @Override // java.util.AbstractMap, java.util.Map
    public final Object get(Object obj) {
        Map mapRkYL = rkYL();
        if (mapRkYL != null) {
            return mapRkYL.get(obj);
        }
        int iVI = vI(obj);
        if (iVI == -1) {
            return null;
        }
        return wA()[iVI];
    }

    @Override // java.util.AbstractMap, java.util.Map
    public final boolean isEmpty() {
        return size() == 0;
    }

    @Override // java.util.AbstractMap, java.util.Map
    public final Set keySet() {
        Set set = this.xJ;
        if (set != null) {
            return set;
        }
        VC vc = new VC(this);
        this.xJ = vc;
        return vc;
    }

    public final void lB(int i) {
        this.KLFTb = ((32 - Integer.numberOfLeadingZeros(i)) & 31) | (this.KLFTb & (-32));
    }

    public final int lgHUyS() {
        return isEmpty() ? -1 : 0;
    }

    public final int[] mjFkc() {
        int[] iArr = this.AZxh;
        Objects.requireNonNull(iArr);
        return iArr;
    }

    @Override // java.util.AbstractMap, java.util.Map
    public final Object put(Object obj, Object obj2) {
        int iMin;
        if (eyqo()) {
            XW.ZfxDd(eyqo(), "Arrays already allocated");
            int i = this.KLFTb;
            int iMax = Math.max(i + 1, 2);
            int iHighestOneBit = Integer.highestOneBit(iMax);
            if (iMax > iHighestOneBit && (iHighestOneBit = iHighestOneBit + iHighestOneBit) <= 0) {
                iHighestOneBit = 1073741824;
            }
            int iMax2 = Math.max(4, iHighestOneBit);
            this.mjFkc = AbstractC1806rD.ZfxDd(iMax2);
            lB(iMax2 - 1);
            this.AZxh = new int[i];
            this.wA = new Object[i];
            this.ZfxDd = new Object[i];
        }
        Map mapRkYL = rkYL();
        if (mapRkYL != null) {
            return mapRkYL.put(obj, obj2);
        }
        int[] iArrMjFkc = mjFkc();
        Object[] objArrAZxh = AZxh();
        Object[] objArrWA = wA();
        int i2 = this.JHa;
        int i3 = i2 + 1;
        int iMjFkc = AbstractC1927tD.mjFkc(obj);
        int iHGpJ = HGpJ();
        int i4 = iMjFkc & iHGpJ;
        Object obj3 = this.mjFkc;
        Objects.requireNonNull(obj3);
        int iWA = AbstractC1806rD.wA(obj3, i4);
        if (iWA != 0) {
            int i5 = ~iHGpJ;
            int i6 = iMjFkc & i5;
            int i7 = 0;
            while (true) {
                int i8 = iWA - 1;
                int i9 = iArrMjFkc[i8];
                int i10 = i9 & i5;
                if (i10 == i6 && SW.mjFkc(obj, objArrAZxh[i8])) {
                    Object obj4 = objArrWA[i8];
                    objArrWA[i8] = obj2;
                    return obj4;
                }
                int i11 = i9 & iHGpJ;
                i7++;
                if (i11 != 0) {
                    iWA = i11;
                } else {
                    if (i7 >= 9) {
                        LinkedHashMap linkedHashMap = new LinkedHashMap(HGpJ() + 1, 1.0f);
                        int iLgHUyS = lgHUyS();
                        while (iLgHUyS >= 0) {
                            linkedHashMap.put(AZxh()[iLgHUyS], wA()[iLgHUyS]);
                            iLgHUyS = qdMbNW(iLgHUyS);
                        }
                        this.mjFkc = linkedHashMap;
                        this.AZxh = null;
                        this.wA = null;
                        this.ZfxDd = null;
                        IEE();
                        return linkedHashMap.put(obj, obj2);
                    }
                    if (i3 > iHGpJ) {
                        iHGpJ = VocHEe(iHGpJ, AbstractC1806rD.mjFkc(iHGpJ), iMjFkc, i2);
                    } else {
                        iArrMjFkc[i8] = (i3 & iHGpJ) | i10;
                    }
                }
            }
        } else if (i3 > iHGpJ) {
            iHGpJ = VocHEe(iHGpJ, AbstractC1806rD.mjFkc(iHGpJ), iMjFkc, i2);
        } else {
            Object obj5 = this.mjFkc;
            Objects.requireNonNull(obj5);
            AbstractC1806rD.KLFTb(obj5, i4, i3);
        }
        int length = mjFkc().length;
        if (i3 > length && (iMin = Math.min(LockFreeTaskQueueCore.MAX_CAPACITY_MASK, (Math.max(1, length >>> 1) + length) | 1)) != length) {
            this.AZxh = Arrays.copyOf(mjFkc(), iMin);
            this.wA = Arrays.copyOf(AZxh(), iMin);
            this.ZfxDd = Arrays.copyOf(wA(), iMin);
        }
        mjFkc()[i2] = (~iHGpJ) & iMjFkc;
        AZxh()[i2] = obj;
        wA()[i2] = obj2;
        this.JHa = i3;
        IEE();
        return null;
    }

    public final int qdMbNW(int i) {
        int i2 = i + 1;
        if (i2 < this.JHa) {
            return i2;
        }
        return -1;
    }

    @Override // java.util.AbstractMap, java.util.Map
    public final Object remove(Object obj) {
        Map mapRkYL = rkYL();
        if (mapRkYL != null) {
            return mapRkYL.remove(obj);
        }
        Object objBAnRFn = BAnRFn(obj);
        if (objBAnRFn == Dt) {
            return null;
        }
        return objBAnRFn;
    }

    public final Map rkYL() {
        Object obj = this.mjFkc;
        if (obj instanceof Map) {
            return (Map) obj;
        }
        return null;
    }

    @Override // java.util.AbstractMap, java.util.Map
    public final int size() {
        Map mapRkYL = rkYL();
        return mapRkYL != null ? mapRkYL.size() : this.JHa;
    }

    public final int vI(Object obj) {
        if (eyqo()) {
            return -1;
        }
        int iMjFkc = AbstractC1927tD.mjFkc(obj);
        int iHGpJ = HGpJ();
        Object obj2 = this.mjFkc;
        Objects.requireNonNull(obj2);
        int iWA = AbstractC1806rD.wA(obj2, iMjFkc & iHGpJ);
        if (iWA != 0) {
            int i = ~iHGpJ;
            int i2 = iMjFkc & i;
            do {
                int i3 = iWA - 1;
                int i4 = mjFkc()[i3];
                if ((i4 & i) == i2 && SW.mjFkc(obj, AZxh()[i3])) {
                    return i3;
                }
                iWA = i4 & iHGpJ;
            } while (iWA != 0);
        }
        return -1;
    }

    @Override // java.util.AbstractMap, java.util.Map
    public final Collection values() {
        Collection collection = this.qdMbNW;
        if (collection != null) {
            return collection;
        }
        ZC zc = new ZC(this);
        this.qdMbNW = zc;
        return zc;
    }

    public final Object[] wA() {
        Object[] objArr = this.ZfxDd;
        Objects.requireNonNull(objArr);
        return objArr;
    }
}
