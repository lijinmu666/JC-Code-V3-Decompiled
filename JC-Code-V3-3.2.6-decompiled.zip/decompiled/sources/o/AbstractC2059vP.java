package o;

/* renamed from: o.vP, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC2059vP {
}
