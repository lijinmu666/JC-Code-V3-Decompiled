package o;

/* loaded from: classes.dex */
public final class DxPQMO implements qpjZLY {

    public static final class mjFkc {
        public static final DxPQMO mjFkc = new DxPQMO();
    }

    public static DxPQMO mjFkc() {
        return mjFkc.mjFkc;
    }

    public static int wA() {
        return NBXYLM.AZxh();
    }

    @Override // o.Z3
    /* renamed from: AZxh, reason: merged with bridge method [inline-methods] */
    public Integer get() {
        return Integer.valueOf(wA());
    }
}
