package o;

import java.util.Arrays;
import o.AbstractC1256i1;
import org.conscrypt.BuildConfig;

/* loaded from: classes.dex */
public final class fLidf extends AbstractC1256i1 {
    public final Integer AZxh;
    public final long JHa;
    public final String KLFTb;
    public final byte[] ZfxDd;
    public final long mjFkc;
    public final long wA;
    public final H2 xJ;

    public static final class AZxh extends AbstractC1256i1.mjFkc {
        public Integer AZxh;
        public Long JHa;
        public String KLFTb;
        public byte[] ZfxDd;
        public Long mjFkc;
        public Long wA;
        public H2 xJ;

        @Override // o.AbstractC1256i1.mjFkc
        public AbstractC1256i1.mjFkc AZxh(Integer num) {
            this.AZxh = num;
            return this;
        }

        @Override // o.AbstractC1256i1.mjFkc
        public AbstractC1256i1.mjFkc JHa(byte[] bArr) {
            this.ZfxDd = bArr;
            return this;
        }

        @Override // o.AbstractC1256i1.mjFkc
        public AbstractC1256i1.mjFkc KLFTb(H2 h2) {
            this.xJ = h2;
            return this;
        }

        @Override // o.AbstractC1256i1.mjFkc
        public AbstractC1256i1.mjFkc ZfxDd(long j) {
            this.wA = Long.valueOf(j);
            return this;
        }

        @Override // o.AbstractC1256i1.mjFkc
        public AbstractC1256i1.mjFkc lgHUyS(long j) {
            this.JHa = Long.valueOf(j);
            return this;
        }

        @Override // o.AbstractC1256i1.mjFkc
        public AbstractC1256i1 mjFkc() {
            Long l = this.mjFkc;
            String str = BuildConfig.FLAVOR;
            if (l == null) {
                str = BuildConfig.FLAVOR + " eventTimeMs";
            }
            if (this.wA == null) {
                str = str + " eventUptimeMs";
            }
            if (this.JHa == null) {
                str = str + " timezoneOffsetSeconds";
            }
            if (str.isEmpty()) {
                return new fLidf(this.mjFkc.longValue(), this.AZxh, this.wA.longValue(), this.ZfxDd, this.KLFTb, this.JHa.longValue(), this.xJ);
            }
            throw new IllegalStateException("Missing required properties:" + str);
        }

        @Override // o.AbstractC1256i1.mjFkc
        public AbstractC1256i1.mjFkc wA(long j) {
            this.mjFkc = Long.valueOf(j);
            return this;
        }

        @Override // o.AbstractC1256i1.mjFkc
        public AbstractC1256i1.mjFkc xJ(String str) {
            this.KLFTb = str;
            return this;
        }
    }

    @Override // o.AbstractC1256i1
    public Integer AZxh() {
        return this.AZxh;
    }

    @Override // o.AbstractC1256i1
    public byte[] JHa() {
        return this.ZfxDd;
    }

    @Override // o.AbstractC1256i1
    public H2 KLFTb() {
        return this.xJ;
    }

    @Override // o.AbstractC1256i1
    public long ZfxDd() {
        return this.wA;
    }

    public boolean equals(Object obj) {
        Integer num;
        String str;
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof AbstractC1256i1)) {
            return false;
        }
        AbstractC1256i1 abstractC1256i1 = (AbstractC1256i1) obj;
        if (this.mjFkc == abstractC1256i1.wA() && ((num = this.AZxh) != null ? num.equals(abstractC1256i1.AZxh()) : abstractC1256i1.AZxh() == null) && this.wA == abstractC1256i1.ZfxDd()) {
            if (Arrays.equals(this.ZfxDd, abstractC1256i1 instanceof fLidf ? ((fLidf) abstractC1256i1).ZfxDd : abstractC1256i1.JHa()) && ((str = this.KLFTb) != null ? str.equals(abstractC1256i1.xJ()) : abstractC1256i1.xJ() == null) && this.JHa == abstractC1256i1.lgHUyS()) {
                H2 h2 = this.xJ;
                if (h2 == null) {
                    if (abstractC1256i1.KLFTb() == null) {
                        return true;
                    }
                } else if (h2.equals(abstractC1256i1.KLFTb())) {
                    return true;
                }
            }
        }
        return false;
    }

    public int hashCode() {
        long j = this.mjFkc;
        int i = (((int) (j ^ (j >>> 32))) ^ 1000003) * 1000003;
        Integer num = this.AZxh;
        int iHashCode = num == null ? 0 : num.hashCode();
        long j2 = this.wA;
        int iHashCode2 = (((((i ^ iHashCode) * 1000003) ^ ((int) (j2 ^ (j2 >>> 32)))) * 1000003) ^ Arrays.hashCode(this.ZfxDd)) * 1000003;
        String str = this.KLFTb;
        int iHashCode3 = str == null ? 0 : str.hashCode();
        long j3 = this.JHa;
        int i2 = (((iHashCode2 ^ iHashCode3) * 1000003) ^ ((int) ((j3 >>> 32) ^ j3))) * 1000003;
        H2 h2 = this.xJ;
        return i2 ^ (h2 != null ? h2.hashCode() : 0);
    }

    @Override // o.AbstractC1256i1
    public long lgHUyS() {
        return this.JHa;
    }

    public String toString() {
        return "LogEvent{eventTimeMs=" + this.mjFkc + ", eventCode=" + this.AZxh + ", eventUptimeMs=" + this.wA + ", sourceExtension=" + Arrays.toString(this.ZfxDd) + ", sourceExtensionJsonProto3=" + this.KLFTb + ", timezoneOffsetSeconds=" + this.JHa + ", networkConnectionInfo=" + this.xJ + "}";
    }

    @Override // o.AbstractC1256i1
    public long wA() {
        return this.mjFkc;
    }

    @Override // o.AbstractC1256i1
    public String xJ() {
        return this.KLFTb;
    }

    public fLidf(long j, Integer num, long j2, byte[] bArr, String str, long j3, H2 h2) {
        this.mjFkc = j;
        this.AZxh = num;
        this.wA = j2;
        this.ZfxDd = bArr;
        this.KLFTb = str;
        this.JHa = j3;
        this.xJ = h2;
    }
}
