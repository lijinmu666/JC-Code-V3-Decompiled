package o;

/* loaded from: classes.dex */
public final class UR {
    public final Integer AZxh;
    public final SR mjFkc;
    public final Integer wA = null;
    public final Boolean ZfxDd = null;

    public /* synthetic */ UR(RR rr, TR tr) {
        this.mjFkc = rr.mjFkc;
        this.AZxh = rr.AZxh;
    }

    public final Integer AZxh() {
        return this.AZxh;
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof UR)) {
            return false;
        }
        UR ur = (UR) obj;
        return U2.mjFkc(this.mjFkc, ur.mjFkc) && U2.mjFkc(this.AZxh, ur.AZxh) && U2.mjFkc(null, null) && U2.mjFkc(null, null);
    }

    public final int hashCode() {
        return U2.AZxh(this.mjFkc, this.AZxh, null, null);
    }

    public final SR mjFkc() {
        return this.mjFkc;
    }
}
