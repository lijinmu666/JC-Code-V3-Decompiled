package o;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.util.AttributeSet;
import android.widget.ImageButton;

/* loaded from: classes.dex */
public class ANMGZc extends ImageButton {
    public final alEkx AZxh;
    public final JrJO mjFkc;
    public boolean wA;

    public ANMGZc(Context context, AttributeSet attributeSet, int i) {
        super(C2163x8.AZxh(context), attributeSet, i);
        this.wA = false;
        AbstractC1682p8.mjFkc(this, getContext());
        JrJO jrJO = new JrJO(this);
        this.mjFkc = jrJO;
        jrJO.KLFTb(attributeSet, i);
        alEkx alekx = new alEkx(this);
        this.AZxh = alekx;
        alekx.xJ(attributeSet, i);
    }

    @Override // android.widget.ImageView, android.view.View
    public void drawableStateChanged() {
        super.drawableStateChanged();
        JrJO jrJO = this.mjFkc;
        if (jrJO != null) {
            jrJO.AZxh();
        }
        alEkx alekx = this.AZxh;
        if (alekx != null) {
            alekx.wA();
        }
    }

    public ColorStateList getSupportBackgroundTintList() {
        JrJO jrJO = this.mjFkc;
        if (jrJO != null) {
            return jrJO.wA();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        JrJO jrJO = this.mjFkc;
        if (jrJO != null) {
            return jrJO.ZfxDd();
        }
        return null;
    }

    public ColorStateList getSupportImageTintList() {
        alEkx alekx = this.AZxh;
        if (alekx != null) {
            return alekx.ZfxDd();
        }
        return null;
    }

    public PorterDuff.Mode getSupportImageTintMode() {
        alEkx alekx = this.AZxh;
        if (alekx != null) {
            return alekx.KLFTb();
        }
        return null;
    }

    @Override // android.widget.ImageView, android.view.View
    public boolean hasOverlappingRendering() {
        return this.AZxh.JHa() && super.hasOverlappingRendering();
    }

    @Override // android.view.View
    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        JrJO jrJO = this.mjFkc;
        if (jrJO != null) {
            jrJO.JHa(drawable);
        }
    }

    @Override // android.view.View
    public void setBackgroundResource(int i) {
        super.setBackgroundResource(i);
        JrJO jrJO = this.mjFkc;
        if (jrJO != null) {
            jrJO.xJ(i);
        }
    }

    @Override // android.widget.ImageView
    public void setImageBitmap(Bitmap bitmap) {
        super.setImageBitmap(bitmap);
        alEkx alekx = this.AZxh;
        if (alekx != null) {
            alekx.wA();
        }
    }

    @Override // android.widget.ImageView
    public void setImageDrawable(Drawable drawable) {
        alEkx alekx = this.AZxh;
        if (alekx != null && drawable != null && !this.wA) {
            alekx.lgHUyS(drawable);
        }
        super.setImageDrawable(drawable);
        alEkx alekx2 = this.AZxh;
        if (alekx2 != null) {
            alekx2.wA();
            if (this.wA) {
                return;
            }
            this.AZxh.AZxh();
        }
    }

    @Override // android.widget.ImageView
    public void setImageLevel(int i) {
        super.setImageLevel(i);
        this.wA = true;
    }

    @Override // android.widget.ImageView
    public void setImageResource(int i) {
        this.AZxh.qdMbNW(i);
    }

    @Override // android.widget.ImageView
    public void setImageURI(Uri uri) {
        super.setImageURI(uri);
        alEkx alekx = this.AZxh;
        if (alekx != null) {
            alekx.wA();
        }
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        JrJO jrJO = this.mjFkc;
        if (jrJO != null) {
            jrJO.qdMbNW(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        JrJO jrJO = this.mjFkc;
        if (jrJO != null) {
            jrJO.Dt(mode);
        }
    }

    public void setSupportImageTintList(ColorStateList colorStateList) {
        alEkx alekx = this.AZxh;
        if (alekx != null) {
            alekx.Dt(colorStateList);
        }
    }

    public void setSupportImageTintMode(PorterDuff.Mode mode) {
        alEkx alekx = this.AZxh;
        if (alekx != null) {
            alekx.ETF(mode);
        }
    }
}
