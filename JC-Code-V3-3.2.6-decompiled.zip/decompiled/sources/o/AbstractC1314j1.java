package o;

import java.util.List;
import o.hvGY;

/* renamed from: o.j1, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC1314j1 {

    /* renamed from: o.j1$mjFkc */
    public static abstract class mjFkc {
        public abstract mjFkc AZxh(xbjHT xbjht);

        public mjFkc Dt(String str) {
            return KLFTb(str);
        }

        public abstract mjFkc JHa(EnumC0896c4 enumC0896c4);

        public abstract mjFkc KLFTb(String str);

        public abstract mjFkc ZfxDd(Integer num);

        public abstract mjFkc lgHUyS(long j);

        public abstract AbstractC1314j1 mjFkc();

        public mjFkc qdMbNW(int i) {
            return ZfxDd(Integer.valueOf(i));
        }

        public abstract mjFkc wA(List list);

        public abstract mjFkc xJ(long j);
    }

    public static mjFkc mjFkc() {
        return new hvGY.AZxh();
    }

    public abstract xbjHT AZxh();

    public abstract EnumC0896c4 JHa();

    public abstract String KLFTb();

    public abstract Integer ZfxDd();

    public abstract long lgHUyS();

    public abstract List wA();

    public abstract long xJ();
}
