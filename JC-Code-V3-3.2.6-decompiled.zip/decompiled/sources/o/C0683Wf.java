package o;

import org.conscrypt.BuildConfig;

/* renamed from: o.Wf, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0683Wf extends AbstractC1010dy implements Ly {
    private static final C0683Wf zbb;
    private int zbd;
    private String zbe = BuildConfig.FLAVOR;
    private InterfaceC1310iy zbf = AbstractC1010dy.VocHEe();
    private InterfaceC1310iy zbg = AbstractC1010dy.VocHEe();
    private InterfaceC1491ly zbh = AbstractC1010dy.wJVbdd();

    static {
        C0683Wf c0683Wf = new C0683Wf();
        zbb = c0683Wf;
        AbstractC1010dy.YoKzxo(C0683Wf.class, c0683Wf);
    }

    @Override // o.AbstractC1010dy
    public final Object IEE(int i, Object obj, Object obj2) {
        int i2 = i - 1;
        if (i2 == 0) {
            return (byte) 1;
        }
        if (i2 == 2) {
            return AbstractC1010dy.ETF(zbb, "\u0001\u0004\u0000\u0001\u0001\u0004\u0004\u0000\u0003\u0000\u0001ဈ\u0000\u0002$\u0003$\u0004\u001a", new Object[]{"zbd", "zbe", "zbf", "zbg", "zbh"});
        }
        if (i2 == 3) {
            return new C0683Wf();
        }
        AbstractC0521Pf abstractC0521Pf = null;
        if (i2 == 4) {
            return new C0660Vf(abstractC0521Pf);
        }
        if (i2 != 5) {
            return null;
        }
        return zbb;
    }
}
