package o;

import android.util.Log;
import org.conscrypt.BuildConfig;

/* renamed from: o.Rm, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0575Rm {
    public static final C0575Rm AZxh = new C0575Rm("VisionKit", 2);
    public final String mjFkc = "VisionKit";

    public C0575Rm(String str, int i) {
    }

    public static final String KLFTb(Object obj, String str, Object... objArr) {
        String str2;
        if (obj instanceof String) {
            str2 = (String) obj;
        } else {
            String name = obj.getClass().getName();
            if (obj instanceof Class) {
                name = ((Class) obj).getName();
            }
            String[] strArrSplit = name.split("\\.");
            int length = strArrSplit.length;
            str2 = length == 0 ? BuildConfig.FLAVOR : strArrSplit[length - 1];
        }
        return "[" + str2 + "] " + str;
    }

    public final void AZxh(Object obj, String str, Object... objArr) {
        if (ZfxDd(4)) {
            Log.i(this.mjFkc, KLFTb(obj, str, objArr));
        }
    }

    public final boolean ZfxDd(int i) {
        return Log.isLoggable(this.mjFkc, i);
    }

    public final void mjFkc(Throwable th, String str, Object... objArr) {
        if (ZfxDd(6)) {
            Log.e(this.mjFkc, "Error in result from JNI layer", th);
        }
    }

    public final void wA(Object obj, String str, Object... objArr) {
        if (ZfxDd(5)) {
            Log.w(this.mjFkc, KLFTb(obj, str, objArr));
        }
    }
}
