package o;

import java.util.Iterator;

/* renamed from: o.ft, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC1127ft implements Iterator {
    @Override // java.util.Iterator
    public final void remove() {
        throw new UnsupportedOperationException();
    }
}
