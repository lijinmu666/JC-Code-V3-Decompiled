package o;

import java.util.Iterator;
import java.util.concurrent.Executor;

/* renamed from: o.wb, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public class C2129wb {
    public final wfQA AZxh;
    public final InterfaceC2283z7 ZfxDd;
    public final Executor mjFkc;
    public final InterfaceC2250yb wA;

    public C2129wb(Executor executor, wfQA wfqa, InterfaceC2250yb interfaceC2250yb, InterfaceC2283z7 interfaceC2283z7) {
        this.mjFkc = executor;
        this.AZxh = wfqa;
        this.wA = interfaceC2250yb;
        this.ZfxDd = interfaceC2283z7;
    }

    public static /* synthetic */ Object AZxh(C2129wb c2129wb) {
        Iterator it = c2129wb.AZxh.JHa().iterator();
        while (it.hasNext()) {
            c2129wb.wA.mjFkc((X8) it.next(), 1);
        }
        return null;
    }

    public void mjFkc() {
        this.mjFkc.execute(RunnableC1948tb.mjFkc(this));
    }
}
