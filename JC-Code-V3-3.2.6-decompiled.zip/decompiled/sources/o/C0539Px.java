package o;

import java.nio.charset.Charset;
import java.util.Collections;
import java.util.Iterator;
import java.util.Map;

/* renamed from: o.Px, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0539Px {
    public static final C0539Px ZfxDd = new C0539Px(true);
    public boolean AZxh;
    public final AbstractC1193gz mjFkc = new Zy();
    public boolean wA;

    public C0539Px() {
    }

    public static int AZxh(Ox ox, Object obj) {
        EnumC2093vz enumC2093vzJHa = ox.JHa();
        ox.mjFkc();
        ox.ZfxDd();
        return mjFkc(enumC2093vzJHa, 32149011, obj);
    }

    public static void ETF(Gx gx, EnumC2093vz enumC2093vz, int i, Object obj) {
        if (enumC2093vz == EnumC2093vz.VA) {
            Ky ky = (Ky) obj;
            AbstractC1551my.ZfxDd(ky);
            gx.BAnRFn(i, 3);
            ky.AZxh(gx);
            gx.BAnRFn(i, 4);
            return;
        }
        gx.BAnRFn(i, enumC2093vz.mjFkc());
        EnumC2153wz enumC2153wz = EnumC2153wz.INT;
        switch (enumC2093vz.ordinal()) {
            case 0:
                gx.IEE(Double.doubleToRawLongBits(((Double) obj).doubleValue()));
                break;
            case 1:
                gx.qGY(Float.floatToRawIntBits(((Float) obj).floatValue()));
                break;
            case 2:
                gx.OjSQV(((Long) obj).longValue());
                break;
            case 3:
                gx.OjSQV(((Long) obj).longValue());
                break;
            case 4:
                gx.diqgf(((Integer) obj).intValue());
                break;
            case 5:
                gx.IEE(((Long) obj).longValue());
                break;
            case 6:
                gx.qGY(((Integer) obj).intValue());
                break;
            case 7:
                gx.Dt(((Boolean) obj).booleanValue() ? (byte) 1 : (byte) 0);
                break;
            case 8:
                if (!(obj instanceof AbstractC2272yx)) {
                    gx.VocHEe((String) obj);
                    break;
                } else {
                    gx.YoKzxo((AbstractC2272yx) obj);
                    break;
                }
            case 9:
                ((Ky) obj).AZxh(gx);
                break;
            case 10:
                gx.huTpC((Ky) obj);
                break;
            case 11:
                if (!(obj instanceof AbstractC2272yx)) {
                    byte[] bArr = (byte[]) obj;
                    gx.VA(bArr, 0, bArr.length);
                    break;
                } else {
                    gx.YoKzxo((AbstractC2272yx) obj);
                    break;
                }
            case 12:
                gx.wJVbdd(((Integer) obj).intValue());
                break;
            case 13:
                gx.diqgf(((Integer) obj).intValue());
                break;
            case 14:
                gx.qGY(((Integer) obj).intValue());
                break;
            case 15:
                gx.IEE(((Long) obj).longValue());
                break;
            case 16:
                int iIntValue = ((Integer) obj).intValue();
                gx.wJVbdd((iIntValue >> 31) ^ (iIntValue + iIntValue));
                break;
            case 17:
                long jLongValue = ((Long) obj).longValue();
                gx.OjSQV((jLongValue >> 63) ^ (jLongValue + jLongValue));
                break;
        }
    }

    public static C0539Px KLFTb() {
        return ZfxDd;
    }

    public static Object YoKzxo(Object obj) {
        if (!(obj instanceof byte[])) {
            return obj;
        }
        byte[] bArr = (byte[]) obj;
        int length = bArr.length;
        byte[] bArr2 = new byte[length];
        System.arraycopy(bArr, 0, bArr2, 0, length);
        return bArr2;
    }

    public static final int fehf(Map.Entry entry) {
        Ox ox = (Ox) entry.getKey();
        Object value = entry.getValue();
        if (ox.AZxh() != EnumC2153wz.MESSAGE) {
            return AZxh(ox, value);
        }
        ox.ZfxDd();
        ox.wA();
        ((Ox) entry.getKey()).mjFkc();
        int iZfxDd = Gx.ZfxDd(8);
        return iZfxDd + iZfxDd + Gx.ZfxDd(16) + Gx.ZfxDd(32149011) + Gx.ZfxDd(24) + Gx.mjFkc((Ky) value);
    }

    public static int mjFkc(EnumC2093vz enumC2093vz, int i, Object obj) {
        int iJHa;
        int iZfxDd;
        int iZfxDd2 = Gx.ZfxDd(i << 3);
        if (enumC2093vz == EnumC2093vz.VA) {
            AbstractC1551my.ZfxDd((Ky) obj);
            iZfxDd2 += iZfxDd2;
        }
        EnumC2153wz enumC2153wz = EnumC2153wz.INT;
        int iKLFTb = 4;
        switch (enumC2093vz.ordinal()) {
            case 0:
                ((Double) obj).doubleValue();
                iKLFTb = 8;
                return iZfxDd2 + iKLFTb;
            case 1:
                ((Float) obj).floatValue();
                return iZfxDd2 + iKLFTb;
            case 2:
                iKLFTb = Gx.KLFTb(((Long) obj).longValue());
                return iZfxDd2 + iKLFTb;
            case 3:
                iKLFTb = Gx.KLFTb(((Long) obj).longValue());
                return iZfxDd2 + iKLFTb;
            case 4:
                iKLFTb = Gx.KLFTb(((Integer) obj).intValue());
                return iZfxDd2 + iKLFTb;
            case 5:
                ((Long) obj).longValue();
                iKLFTb = 8;
                return iZfxDd2 + iKLFTb;
            case 6:
                ((Integer) obj).intValue();
                return iZfxDd2 + iKLFTb;
            case 7:
                ((Boolean) obj).booleanValue();
                iKLFTb = 1;
                return iZfxDd2 + iKLFTb;
            case 8:
                if (!(obj instanceof AbstractC2272yx)) {
                    iKLFTb = Gx.wA((String) obj);
                    return iZfxDd2 + iKLFTb;
                }
                iJHa = ((AbstractC2272yx) obj).JHa();
                iZfxDd = Gx.ZfxDd(iJHa);
                iKLFTb = iZfxDd + iJHa;
                return iZfxDd2 + iKLFTb;
            case 9:
                iKLFTb = ((Ky) obj).mjFkc();
                return iZfxDd2 + iKLFTb;
            case 10:
                iKLFTb = Gx.mjFkc((Ky) obj);
                return iZfxDd2 + iKLFTb;
            case 11:
                if (obj instanceof AbstractC2272yx) {
                    iJHa = ((AbstractC2272yx) obj).JHa();
                    iZfxDd = Gx.ZfxDd(iJHa);
                } else {
                    iJHa = ((byte[]) obj).length;
                    iZfxDd = Gx.ZfxDd(iJHa);
                }
                iKLFTb = iZfxDd + iJHa;
                return iZfxDd2 + iKLFTb;
            case 12:
                iKLFTb = Gx.ZfxDd(((Integer) obj).intValue());
                return iZfxDd2 + iKLFTb;
            case 13:
                iKLFTb = Gx.KLFTb(((Integer) obj).intValue());
                return iZfxDd2 + iKLFTb;
            case 14:
                ((Integer) obj).intValue();
                return iZfxDd2 + iKLFTb;
            case 15:
                ((Long) obj).longValue();
                iKLFTb = 8;
                return iZfxDd2 + iKLFTb;
            case 16:
                int iIntValue = ((Integer) obj).intValue();
                iKLFTb = Gx.ZfxDd((iIntValue >> 31) ^ (iIntValue + iIntValue));
                return iZfxDd2 + iKLFTb;
            case 17:
                long jLongValue = ((Long) obj).longValue();
                iKLFTb = Gx.KLFTb((jLongValue >> 63) ^ (jLongValue + jLongValue));
                return iZfxDd2 + iKLFTb;
            default:
                throw new RuntimeException("There is no way to get here, but the compiler thinks otherwise.");
        }
    }

    public static boolean qGY(Map.Entry entry) {
        Ox ox = (Ox) entry.getKey();
        if (ox.AZxh() != EnumC2153wz.MESSAGE) {
            return true;
        }
        ox.ZfxDd();
        Object value = entry.getValue();
        if (value instanceof Ly) {
            return ((Ly) value).wA();
        }
        throw new IllegalArgumentException("Wrong object type used with protocol message reflection.");
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Code restructure failed: missing block: B:14:0x002c, code lost:
    
        if ((r4 instanceof byte[]) == false) goto L25;
     */
    /* JADX WARN: Code restructure failed: missing block: B:22:0x0040, code lost:
    
        if (r0 == false) goto L25;
     */
    /* JADX WARN: Code restructure failed: missing block: B:6:0x001e, code lost:
    
        if ((r4 instanceof o.Ky) != false) goto L23;
     */
    /* JADX WARN: Code restructure failed: missing block: B:9:0x0023, code lost:
    
        if ((r4 instanceof java.lang.Integer) != false) goto L23;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void Dt(Ox ox, Object obj) {
        boolean z;
        ox.ZfxDd();
        ox.JHa();
        Charset charset = AbstractC1551my.mjFkc;
        obj.getClass();
        EnumC2093vz enumC2093vz = EnumC2093vz.wA;
        EnumC2153wz enumC2153wz = EnumC2153wz.INT;
        switch (r0.KLFTb()) {
            case INT:
                z = obj instanceof Integer;
                break;
            case LONG:
                z = obj instanceof Long;
                break;
            case FLOAT:
                z = obj instanceof Float;
                break;
            case DOUBLE:
                z = obj instanceof Double;
                break;
            case BOOLEAN:
                z = obj instanceof Boolean;
                break;
            case STRING:
                z = obj instanceof String;
                break;
            case BYTE_STRING:
                if (!(obj instanceof AbstractC2272yx)) {
                    break;
                }
                this.mjFkc.put(ox, obj);
                return;
            case ENUM:
                break;
            case MESSAGE:
                break;
            default:
                ox.mjFkc();
                throw new IllegalArgumentException(String.format("Wrong object type used with protocol message reflection.\nField number: %d, field java type: %s, value type: %s\n", 32149011, ox.JHa().KLFTb(), obj.getClass().getName()));
        }
    }

    public final Object JHa(Ox ox) {
        return this.mjFkc.get(ox);
    }

    public final boolean MiMN() {
        int iWA = this.mjFkc.wA();
        for (int i = 0; i < iWA; i++) {
            if (!qGY(this.mjFkc.xJ(i))) {
                return false;
            }
        }
        Iterator it = this.mjFkc.ZfxDd().iterator();
        while (it.hasNext()) {
            if (!qGY((Map.Entry) it.next())) {
                return false;
            }
        }
        return true;
    }

    public final boolean VA() {
        return this.AZxh;
    }

    /* renamed from: ZfxDd, reason: merged with bridge method [inline-methods] */
    public final C0539Px clone() {
        C0539Px c0539Px = new C0539Px();
        int iWA = this.mjFkc.wA();
        for (int i = 0; i < iWA; i++) {
            Map.Entry entryXJ = this.mjFkc.xJ(i);
            c0539Px.Dt((Ox) ((C0830az) entryXJ).KLFTb(), entryXJ.getValue());
        }
        for (Map.Entry entry : this.mjFkc.ZfxDd()) {
            c0539Px.Dt((Ox) entry.getKey(), entry.getValue());
        }
        c0539Px.wA = this.wA;
        return c0539Px;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof C0539Px) {
            return this.mjFkc.equals(((C0539Px) obj).mjFkc);
        }
        return false;
    }

    public final int hashCode() {
        return this.mjFkc.hashCode();
    }

    public final void lgHUyS() {
        if (this.AZxh) {
            return;
        }
        int iWA = this.mjFkc.wA();
        for (int i = 0; i < iWA; i++) {
            Map.Entry entryXJ = this.mjFkc.xJ(i);
            if (entryXJ.getValue() instanceof AbstractC1010dy) {
                ((AbstractC1010dy) entryXJ.getValue()).VA();
            }
        }
        this.mjFkc.mjFkc();
        this.AZxh = true;
    }

    public final void qdMbNW(C0539Px c0539Px) {
        int iWA = c0539Px.mjFkc.wA();
        for (int i = 0; i < iWA; i++) {
            rkYL(c0539Px.mjFkc.xJ(i));
        }
        Iterator it = c0539Px.mjFkc.ZfxDd().iterator();
        while (it.hasNext()) {
            rkYL((Map.Entry) it.next());
        }
    }

    public final void rkYL(Map.Entry entry) {
        Ox ox = (Ox) entry.getKey();
        Object value = entry.getValue();
        ox.ZfxDd();
        if (ox.AZxh() != EnumC2153wz.MESSAGE) {
            this.mjFkc.put(ox, YoKzxo(value));
            return;
        }
        Object objJHa = JHa(ox);
        if (objJHa == null) {
            this.mjFkc.put(ox, YoKzxo(value));
        } else {
            this.mjFkc.put(ox, ox.xJ(((Ky) objJHa).JHa(), (Ky) value).ZfxDd());
        }
    }

    public final int wA() {
        int iWA = this.mjFkc.wA();
        int iFehf = 0;
        for (int i = 0; i < iWA; i++) {
            iFehf += fehf(this.mjFkc.xJ(i));
        }
        Iterator it = this.mjFkc.ZfxDd().iterator();
        while (it.hasNext()) {
            iFehf += fehf((Map.Entry) it.next());
        }
        return iFehf;
    }

    public final Iterator xJ() {
        return this.mjFkc.isEmpty() ? Collections.emptyIterator() : this.wA ? new C1850ry(this.mjFkc.entrySet().iterator()) : this.mjFkc.entrySet().iterator();
    }

    public C0539Px(boolean z) {
        lgHUyS();
        lgHUyS();
    }
}
