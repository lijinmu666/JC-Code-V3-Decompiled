package o;

import android.content.Context;

/* renamed from: o.nW, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C1586nW implements OV {
    public final InterfaceC0775a4 AZxh;
    public InterfaceC0775a4 mjFkc;
    public final QV wA;

    public C1586nW(Context context, QV qv) {
        this.wA = qv;
        oaI oai = oaI.xJ;
        C0962d9.JHa(context);
        final Y8 y8XJ = C0962d9.wA().xJ(oai);
        if (oai.mjFkc().contains(dXmy.AZxh("json"))) {
            this.mjFkc = new O0(new InterfaceC0775a4() { // from class: o.kW
                @Override // o.InterfaceC0775a4
                public final Object get() {
                    return y8XJ.mjFkc("FIREBASE_ML_SDK", byte[].class, dXmy.AZxh("json"), new M8() { // from class: o.mW
                        @Override // o.M8
                        public final Object apply(Object obj) {
                            return (byte[]) obj;
                        }
                    });
                }
            });
        }
        this.AZxh = new O0(new InterfaceC0775a4() { // from class: o.lW
            @Override // o.InterfaceC0775a4
            public final Object get() {
                return y8XJ.mjFkc("FIREBASE_ML_SDK", byte[].class, dXmy.AZxh("proto"), new M8() { // from class: o.jW
                    @Override // o.M8
                    public final Object apply(Object obj) {
                        return (byte[]) obj;
                    }
                });
            }
        });
    }

    public static uhQ AZxh(QV qv, MV mv) {
        int iMjFkc = qv.mjFkc();
        return mv.zza() != 0 ? uhQ.ZfxDd(mv.mjFkc(iMjFkc, false)) : uhQ.KLFTb(mv.mjFkc(iMjFkc, false));
    }

    @Override // o.OV
    public final void mjFkc(MV mv) {
        if (this.wA.mjFkc() != 0) {
            ((V8) this.AZxh.get()).mjFkc(AZxh(this.wA, mv));
            return;
        }
        InterfaceC0775a4 interfaceC0775a4 = this.mjFkc;
        if (interfaceC0775a4 != null) {
            ((V8) interfaceC0775a4.get()).mjFkc(AZxh(this.wA, mv));
        }
    }
}
