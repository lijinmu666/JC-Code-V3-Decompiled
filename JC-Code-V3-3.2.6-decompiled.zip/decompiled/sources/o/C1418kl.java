package o;

/* renamed from: o.kl, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C1418kl extends Vx implements Ly {
    public /* synthetic */ C1418kl(AbstractC1179gl abstractC1179gl) {
        super(C1538ml.zbb);
    }
}
