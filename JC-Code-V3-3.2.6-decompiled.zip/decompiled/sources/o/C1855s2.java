package o;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executor;

/* renamed from: o.s2, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C1855s2 {
    public final Executor AZxh;
    public final List mjFkc;

    /* renamed from: o.s2$mjFkc */
    public static class mjFkc {
        public Executor AZxh;
        public final List mjFkc = new ArrayList();

        public C1855s2 AZxh() {
            return new C1855s2(this.mjFkc, null, this.AZxh, true, null);
        }

        public mjFkc mjFkc(InterfaceC1316j3 interfaceC1316j3) {
            this.mjFkc.add(interfaceC1316j3);
            return this;
        }
    }

    public /* synthetic */ C1855s2(List list, U u, Executor executor, boolean z, AbstractC1949tc abstractC1949tc) {
        I3.lgHUyS(list, "APIs must not be null.");
        I3.AZxh(!list.isEmpty(), "APIs must not be empty.");
        if (executor != null) {
            I3.lgHUyS(u, "Listener must not be null when listener executor is set.");
        }
        this.mjFkc = list;
        this.AZxh = executor;
    }

    public static mjFkc ZfxDd() {
        return new mjFkc();
    }

    public U AZxh() {
        return null;
    }

    public List mjFkc() {
        return this.mjFkc;
    }

    public Executor wA() {
        return this.AZxh;
    }
}
