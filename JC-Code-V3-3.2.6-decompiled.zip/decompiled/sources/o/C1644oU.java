package o;

/* renamed from: o.oU, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C1644oU {
    public final UR AZxh;
    public final C0799aS mjFkc;
    public final DU wA;

    public /* synthetic */ C1644oU(C1524mU c1524mU, AbstractC1584nU abstractC1584nU) {
        this.mjFkc = c1524mU.mjFkc;
        this.AZxh = c1524mU.AZxh;
        this.wA = c1524mU.wA;
    }

    public final C0799aS AZxh() {
        return this.mjFkc;
    }

    public final UR mjFkc() {
        return this.AZxh;
    }

    public final DU wA() {
        return this.wA;
    }
}
