package o;

import org.conscrypt.BuildConfig;

/* JADX WARN: Enum visitor error
jadx.core.utils.exceptions.JadxRuntimeException: Init of enum field 'wA' uses external variables
	at jadx.core.dex.visitors.EnumVisitor.createEnumFieldByConstructor(EnumVisitor.java:451)
	at jadx.core.dex.visitors.EnumVisitor.processEnumFieldByRegister(EnumVisitor.java:395)
	at jadx.core.dex.visitors.EnumVisitor.extractEnumFieldsFromFilledArray(EnumVisitor.java:324)
	at jadx.core.dex.visitors.EnumVisitor.extractEnumFieldsFromInsn(EnumVisitor.java:262)
	at jadx.core.dex.visitors.EnumVisitor.convertToEnum(EnumVisitor.java:151)
	at jadx.core.dex.visitors.EnumVisitor.visit(EnumVisitor.java:100)
 */
/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* renamed from: o.py, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class EnumC1731py {
    public static final EnumC1731py AZxh;
    public static final EnumC1731py Dt;
    public static final EnumC1731py ETF;
    public static final EnumC1731py JHa;
    public static final EnumC1731py KLFTb;
    public static final /* synthetic */ EnumC1731py[] VA;
    public static final EnumC1731py ZfxDd;
    public static final EnumC1731py lgHUyS;
    public static final EnumC1731py qdMbNW;
    public static final EnumC1731py wA;
    public static final EnumC1731py xJ;
    public final Class mjFkc;

    static {
        EnumC1731py enumC1731py = new EnumC1731py("VOID", 0, Void.class, Void.class, null);
        AZxh = enumC1731py;
        Class cls = Integer.TYPE;
        EnumC1731py enumC1731py2 = new EnumC1731py("INT", 1, cls, Integer.class, 0);
        wA = enumC1731py2;
        EnumC1731py enumC1731py3 = new EnumC1731py("LONG", 2, Long.TYPE, Long.class, 0L);
        ZfxDd = enumC1731py3;
        EnumC1731py enumC1731py4 = new EnumC1731py("FLOAT", 3, Float.TYPE, Float.class, Float.valueOf(0.0f));
        KLFTb = enumC1731py4;
        EnumC1731py enumC1731py5 = new EnumC1731py("DOUBLE", 4, Double.TYPE, Double.class, Double.valueOf(0.0d));
        JHa = enumC1731py5;
        EnumC1731py enumC1731py6 = new EnumC1731py("BOOLEAN", 5, Boolean.TYPE, Boolean.class, Boolean.FALSE);
        xJ = enumC1731py6;
        EnumC1731py enumC1731py7 = new EnumC1731py("STRING", 6, String.class, String.class, BuildConfig.FLAVOR);
        lgHUyS = enumC1731py7;
        EnumC1731py enumC1731py8 = new EnumC1731py("BYTE_STRING", 7, AbstractC2272yx.class, AbstractC2272yx.class, AbstractC2272yx.AZxh);
        qdMbNW = enumC1731py8;
        EnumC1731py enumC1731py9 = new EnumC1731py("ENUM", 8, cls, Integer.class, null);
        Dt = enumC1731py9;
        EnumC1731py enumC1731py10 = new EnumC1731py("MESSAGE", 9, Object.class, Object.class, null);
        ETF = enumC1731py10;
        VA = new EnumC1731py[]{enumC1731py, enumC1731py2, enumC1731py3, enumC1731py4, enumC1731py5, enumC1731py6, enumC1731py7, enumC1731py8, enumC1731py9, enumC1731py10};
    }

    public EnumC1731py(String str, int i, Class cls, Class cls2, Object obj) {
        this.mjFkc = cls2;
    }

    public static EnumC1731py[] values() {
        return (EnumC1731py[]) VA.clone();
    }

    public final Class KLFTb() {
        return this.mjFkc;
    }
}
