package o;

/* renamed from: o.Kv, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0423Kv extends Vx implements Ly {
    public /* synthetic */ C0423Kv(AbstractC0353Hv abstractC0353Hv) {
        super(C0445Lv.zbb);
    }
}
