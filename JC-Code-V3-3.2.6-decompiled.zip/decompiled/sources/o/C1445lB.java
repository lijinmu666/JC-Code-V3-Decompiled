package o;

import android.content.Context;
import android.content.res.Configuration;

/* renamed from: o.lB, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public class C1445lB {
    public Context mjFkc;

    public C1445lB(Context context) {
        this.mjFkc = context;
    }

    public static C1445lB mjFkc(Context context) {
        return new C1445lB(context);
    }

    public int AZxh() {
        return this.mjFkc.getResources().getDisplayMetrics().widthPixels / 2;
    }

    public boolean ZfxDd() {
        return true;
    }

    public int wA() {
        Configuration configuration = this.mjFkc.getResources().getConfiguration();
        int i = configuration.screenWidthDp;
        int i2 = configuration.screenHeightDp;
        if (configuration.smallestScreenWidthDp > 600 || i > 600) {
            return 5;
        }
        if (i > 960 && i2 > 720) {
            return 5;
        }
        if (i > 720 && i2 > 960) {
            return 5;
        }
        if (i >= 500) {
            return 4;
        }
        if (i > 640 && i2 > 480) {
            return 4;
        }
        if (i <= 480 || i2 <= 640) {
            return i >= 360 ? 3 : 2;
        }
        return 4;
    }
}
