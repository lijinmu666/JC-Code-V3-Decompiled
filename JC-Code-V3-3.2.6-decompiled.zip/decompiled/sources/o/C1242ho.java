package o;

/* renamed from: o.ho, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C1242ho extends AbstractC1010dy implements Ly {
    private static final C1242ho zbb;
    private int zbd;
    private C0459Mm zbe;
    private C0480Nk zbf;
    private C1235hh zbg;
    private C1962tp zbh;
    private boolean zbi;
    private C0619Tk zbj;
    private C0598Sm zbk;
    private C2019um zbl;

    static {
        C1242ho c1242ho = new C1242ho();
        zbb = c1242ho;
        AbstractC1010dy.YoKzxo(C1242ho.class, c1242ho);
    }

    @Override // o.AbstractC1010dy
    public final Object IEE(int i, Object obj, Object obj2) {
        int i2 = i - 1;
        if (i2 == 0) {
            return (byte) 1;
        }
        if (i2 == 2) {
            return AbstractC1010dy.ETF(zbb, "\u0001\b\u0000\u0001\u0001\t\b\u0000\u0000\u0000\u0001ဉ\u0001\u0003ဉ\u0005\u0004ဉ\u0000\u0005ဉ\u0002\u0006ဉ\u0003\u0007ဇ\u0004\bဉ\u0006\tဉ\u0007", new Object[]{"zbd", "zbf", "zbj", "zbe", "zbg", "zbh", "zbi", "zbk", "zbl"});
        }
        if (i2 == 3) {
            return new C1242ho();
        }
        AbstractC0940co abstractC0940co = null;
        if (i2 == 4) {
            return new C1122fo(abstractC0940co);
        }
        if (i2 != 5) {
            return null;
        }
        return zbb;
    }
}
