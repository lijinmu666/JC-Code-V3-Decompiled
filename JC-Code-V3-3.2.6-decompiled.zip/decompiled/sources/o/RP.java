package o;

import android.os.SystemClock;
import java.io.Closeable;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/* loaded from: classes.dex */
public class RP implements Closeable {
    public static final Map lgHUyS = new HashMap();
    public int AZxh;
    public long JHa;
    public long KLFTb;
    public long ZfxDd;
    public final String mjFkc;
    public double wA;
    public long xJ;

    public RP(String str) {
        this.JHa = 2147483647L;
        this.xJ = -2147483648L;
        this.mjFkc = str;
    }

    public static RP qdMbNW(String str) {
        C0798aR.mjFkc();
        if (!C0798aR.AZxh()) {
            return MP.qdMbNW;
        }
        Map map = lgHUyS;
        if (map.get("detectorTaskWithResource#run") == null) {
            map.put("detectorTaskWithResource#run", new RP("detectorTaskWithResource#run"));
        }
        return (RP) map.get("detectorTaskWithResource#run");
    }

    public RP KLFTb() {
        this.ZfxDd = SystemClock.elapsedRealtimeNanos() / 1000;
        return this;
    }

    public final void ZfxDd() {
        this.AZxh = 0;
        this.wA = 0.0d;
        this.ZfxDd = 0L;
        this.JHa = 2147483647L;
        this.xJ = -2147483648L;
    }

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public void close() {
        long j = this.ZfxDd;
        if (j == 0) {
            throw new IllegalStateException("Did you forget to call start()?");
        }
        lgHUyS(j);
    }

    public void lgHUyS(long j) {
        xJ((SystemClock.elapsedRealtimeNanos() / 1000) - j);
    }

    public void xJ(long j) {
        long jElapsedRealtimeNanos = SystemClock.elapsedRealtimeNanos() / 1000;
        long j2 = this.KLFTb;
        if (j2 != 0 && jElapsedRealtimeNanos - j2 >= 1000000) {
            ZfxDd();
        }
        this.KLFTb = jElapsedRealtimeNanos;
        this.AZxh++;
        this.wA += j;
        this.JHa = Math.min(this.JHa, j);
        this.xJ = Math.max(this.xJ, j);
        if (this.AZxh % 50 == 0) {
            String.format(Locale.US, "[%s] cur=%dus, counts=%d, min=%dus, max=%dus, avg=%dus", this.mjFkc, Long.valueOf(j), Integer.valueOf(this.AZxh), Long.valueOf(this.JHa), Long.valueOf(this.xJ), Integer.valueOf((int) (this.wA / this.AZxh)));
            C0798aR.mjFkc();
        }
        if (this.AZxh % 500 == 0) {
            ZfxDd();
        }
    }
}
