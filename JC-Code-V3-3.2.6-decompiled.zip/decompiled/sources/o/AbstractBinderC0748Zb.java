package o;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;

/* renamed from: o.Zb, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractBinderC0748Zb extends Binder implements IInterface {
    public AbstractBinderC0748Zb(String str) {
        attachInterface(this, str);
    }

    public abstract boolean Ucbh(int i, Parcel parcel, Parcel parcel2, int i2);

    @Override // android.os.IInterface
    public final IBinder asBinder() {
        return this;
    }

    @Override // android.os.Binder
    public final boolean onTransact(int i, Parcel parcel, Parcel parcel2, int i2) {
        if (i <= 16777215) {
            parcel.enforceInterface(getInterfaceDescriptor());
        } else if (super.onTransact(i, parcel, parcel2, i2)) {
            return true;
        }
        return Ucbh(i, parcel, parcel2, i2);
    }
}
