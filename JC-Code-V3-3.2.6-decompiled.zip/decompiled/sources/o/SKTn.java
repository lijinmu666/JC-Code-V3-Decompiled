package o;

import o.H2;

/* loaded from: classes.dex */
public final class SKTn extends H2 {
    public final H2.AZxh AZxh;
    public final H2.wA mjFkc;

    public static final class AZxh extends H2.mjFkc {
        public H2.AZxh AZxh;
        public H2.wA mjFkc;

        @Override // o.H2.mjFkc
        public H2.mjFkc AZxh(H2.AZxh aZxh) {
            this.AZxh = aZxh;
            return this;
        }

        @Override // o.H2.mjFkc
        public H2 mjFkc() {
            return new SKTn(this.mjFkc, this.AZxh);
        }

        @Override // o.H2.mjFkc
        public H2.mjFkc wA(H2.wA wAVar) {
            this.mjFkc = wAVar;
            return this;
        }
    }

    @Override // o.H2
    public H2.AZxh AZxh() {
        return this.AZxh;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof H2)) {
            return false;
        }
        H2 h2 = (H2) obj;
        H2.wA wAVar = this.mjFkc;
        if (wAVar != null ? wAVar.equals(h2.wA()) : h2.wA() == null) {
            H2.AZxh aZxh = this.AZxh;
            if (aZxh == null) {
                if (h2.AZxh() == null) {
                    return true;
                }
            } else if (aZxh.equals(h2.AZxh())) {
                return true;
            }
        }
        return false;
    }

    public int hashCode() {
        H2.wA wAVar = this.mjFkc;
        int iHashCode = ((wAVar == null ? 0 : wAVar.hashCode()) ^ 1000003) * 1000003;
        H2.AZxh aZxh = this.AZxh;
        return iHashCode ^ (aZxh != null ? aZxh.hashCode() : 0);
    }

    public String toString() {
        return "NetworkConnectionInfo{networkType=" + this.mjFkc + ", mobileSubtype=" + this.AZxh + "}";
    }

    @Override // o.H2
    public H2.wA wA() {
        return this.mjFkc;
    }

    public SKTn(H2.wA wAVar, H2.AZxh aZxh) {
        this.mjFkc = wAVar;
        this.AZxh = aZxh;
    }
}
