package o;

/* renamed from: o.xq, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C2204xq extends AbstractC1010dy implements Ly {
    private static final C2204xq zbb;
    private int zbd;
    private float zbe;
    private float zbf;
    private float zbg;
    private float zbh;

    static {
        C2204xq c2204xq = new C2204xq();
        zbb = c2204xq;
        AbstractC1010dy.YoKzxo(C2204xq.class, c2204xq);
    }

    @Override // o.AbstractC1010dy
    public final Object IEE(int i, Object obj, Object obj2) {
        int i2 = i - 1;
        if (i2 == 0) {
            return (byte) 1;
        }
        if (i2 == 2) {
            return AbstractC1010dy.ETF(zbb, "\u0001\u0004\u0000\u0001\u0001\u0004\u0004\u0000\u0000\u0000\u0001ခ\u0000\u0002ခ\u0001\u0003ခ\u0002\u0004ခ\u0003", new Object[]{"zbd", "zbe", "zbf", "zbg", "zbh"});
        }
        if (i2 == 3) {
            return new C2204xq();
        }
        AbstractC2084vq abstractC2084vq = null;
        if (i2 == 4) {
            return new C2144wq(abstractC2084vq);
        }
        if (i2 != 5) {
            return null;
        }
        return zbb;
    }
}
