package o;

/* renamed from: o.Jh, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0386Jh extends Vx implements Ly {
    public /* synthetic */ C0386Jh(AbstractC0363Ih abstractC0363Ih) {
        super(C0500Oh.zbb);
    }
}
