package o;

/* renamed from: o.wO, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC2119wO {
}
