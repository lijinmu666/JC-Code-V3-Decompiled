package o;

/* renamed from: o.e6, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C1019e6 implements qpjZLY {
    public final Z3 AZxh;
    public final Z3 ZfxDd;
    public final Z3 mjFkc;
    public final Z3 wA;

    public C1019e6(Z3 z3, Z3 z32, Z3 z33, Z3 z34) {
        this.mjFkc = z3;
        this.AZxh = z32;
        this.wA = z33;
        this.ZfxDd = z34;
    }

    public static C1019e6 mjFkc(Z3 z3, Z3 z32, Z3 z33, Z3 z34) {
        return new C1019e6(z3, z32, z33, z34);
    }

    public static C0959d6 wA(aDq adq, aDq adq2, Object obj, Object obj2) {
        return new C0959d6(adq, adq2, (YxdwU) obj, (C2282z6) obj2);
    }

    @Override // o.Z3
    /* renamed from: AZxh, reason: merged with bridge method [inline-methods] */
    public C0959d6 get() {
        return wA((aDq) this.mjFkc.get(), (aDq) this.AZxh.get(), this.wA.get(), this.ZfxDd.get());
    }
}
