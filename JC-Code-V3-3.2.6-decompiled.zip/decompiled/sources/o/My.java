package o;

import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import kotlin.text.Typography;
import org.conscrypt.BuildConfig;

/* loaded from: classes.dex */
public abstract class My {
    public static final char[] mjFkc;

    static {
        char[] cArr = new char[80];
        mjFkc = cArr;
        Arrays.fill(cArr, ' ');
    }

    public static void AZxh(StringBuilder sb, int i, String str, Object obj) throws SecurityException {
        if (obj instanceof List) {
            Iterator it = ((List) obj).iterator();
            while (it.hasNext()) {
                AZxh(sb, i, str, it.next());
            }
            return;
        }
        if (obj instanceof Map) {
            Iterator it2 = ((Map) obj).entrySet().iterator();
            while (it2.hasNext()) {
                AZxh(sb, i, str, (Map.Entry) it2.next());
            }
            return;
        }
        sb.append('\n');
        wA(i, sb);
        if (!str.isEmpty()) {
            StringBuilder sb2 = new StringBuilder();
            sb2.append(Character.toLowerCase(str.charAt(0)));
            for (int i2 = 1; i2 < str.length(); i2++) {
                char cCharAt = str.charAt(i2);
                if (Character.isUpperCase(cCharAt)) {
                    sb2.append("_");
                }
                sb2.append(Character.toLowerCase(cCharAt));
            }
            str = sb2.toString();
        }
        sb.append(str);
        if (obj instanceof String) {
            sb.append(": \"");
            sb.append(AbstractC1253hz.mjFkc(new C2211xx(((String) obj).getBytes(AbstractC1551my.mjFkc))));
            sb.append(Typography.quote);
            return;
        }
        if (obj instanceof AbstractC2272yx) {
            sb.append(": \"");
            sb.append(AbstractC1253hz.mjFkc((AbstractC2272yx) obj));
            sb.append(Typography.quote);
            return;
        }
        if (obj instanceof AbstractC1010dy) {
            sb.append(" {");
            ZfxDd((AbstractC1010dy) obj, sb, i + 2);
            sb.append("\n");
            wA(i, sb);
            sb.append("}");
            return;
        }
        if (!(obj instanceof Map.Entry)) {
            sb.append(": ");
            sb.append(obj);
            return;
        }
        int i3 = i + 2;
        sb.append(" {");
        Map.Entry entry = (Map.Entry) obj;
        AZxh(sb, i3, "key", entry.getKey());
        AZxh(sb, i3, "value", entry.getValue());
        sb.append("\n");
        wA(i, sb);
        sb.append("}");
    }

    /* JADX WARN: Removed duplicated region for block: B:102:0x01fa  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static void ZfxDd(Ky ky, StringBuilder sb, int i) throws SecurityException {
        int i2;
        boolean zEquals;
        Method method;
        Method method2;
        HashSet hashSet = new HashSet();
        HashMap map = new HashMap();
        TreeMap treeMap = new TreeMap();
        Method[] declaredMethods = ky.getClass().getDeclaredMethods();
        int length = declaredMethods.length;
        int i3 = 0;
        while (true) {
            i2 = 3;
            if (i3 >= length) {
                break;
            }
            Method method3 = declaredMethods[i3];
            if (!Modifier.isStatic(method3.getModifiers()) && method3.getName().length() >= 3) {
                if (method3.getName().startsWith("set")) {
                    hashSet.add(method3.getName());
                } else if (Modifier.isPublic(method3.getModifiers()) && method3.getParameterTypes().length == 0) {
                    if (method3.getName().startsWith("has")) {
                        map.put(method3.getName(), method3);
                    } else if (method3.getName().startsWith("get")) {
                        treeMap.put(method3.getName(), method3);
                    }
                }
            }
            i3++;
        }
        for (Map.Entry entry : treeMap.entrySet()) {
            String strSubstring = ((String) entry.getKey()).substring(i2);
            if (strSubstring.endsWith("List") && !strSubstring.endsWith("OrBuilderList") && !strSubstring.equals("List") && (method2 = (Method) entry.getValue()) != null && method2.getReturnType().equals(List.class)) {
                AZxh(sb, i, strSubstring.substring(0, strSubstring.length() - 4), AbstractC1010dy.mByQ(method2, ky, new Object[0]));
            } else if (strSubstring.endsWith("Map") && !strSubstring.equals("Map") && (method = (Method) entry.getValue()) != null && method.getReturnType().equals(Map.class) && !method.isAnnotationPresent(Deprecated.class) && Modifier.isPublic(method.getModifiers())) {
                AZxh(sb, i, strSubstring.substring(0, strSubstring.length() - 3), AbstractC1010dy.mByQ(method, ky, new Object[0]));
            } else if (hashSet.contains("set".concat(strSubstring)) && (!strSubstring.endsWith("Bytes") || !treeMap.containsKey("get".concat(String.valueOf(strSubstring.substring(0, strSubstring.length() - 5)))))) {
                Method method4 = (Method) entry.getValue();
                Method method5 = (Method) map.get("has".concat(strSubstring));
                if (method4 != null) {
                    Object objMByQ = AbstractC1010dy.mByQ(method4, ky, new Object[0]);
                    if (method5 == null) {
                        if (objMByQ instanceof Boolean) {
                            if (((Boolean) objMByQ).booleanValue()) {
                                AZxh(sb, i, strSubstring, objMByQ);
                            }
                        } else if (objMByQ instanceof Integer) {
                            if (((Integer) objMByQ).intValue() != 0) {
                            }
                        } else if (objMByQ instanceof Float) {
                            if (Float.floatToRawIntBits(((Float) objMByQ).floatValue()) != 0) {
                            }
                        } else if (!(objMByQ instanceof Double)) {
                            if (objMByQ instanceof String) {
                                zEquals = objMByQ.equals(BuildConfig.FLAVOR);
                            } else if (objMByQ instanceof AbstractC2272yx) {
                                zEquals = objMByQ.equals(AbstractC2272yx.AZxh);
                            } else if (objMByQ instanceof Ky) {
                                if (objMByQ != ((Ky) objMByQ).lgHUyS()) {
                                }
                            } else if (!(objMByQ instanceof Enum) || ((Enum) objMByQ).ordinal() != 0) {
                            }
                            if (!zEquals) {
                            }
                        } else if (Double.doubleToRawLongBits(((Double) objMByQ).doubleValue()) != 0) {
                        }
                    } else if (((Boolean) AbstractC1010dy.mByQ(method5, ky, new Object[0])).booleanValue()) {
                    }
                }
            }
            i2 = 3;
        }
        if (ky instanceof Zx) {
            Iterator itXJ = ((Zx) ky).zbb.xJ();
            while (itXJ.hasNext()) {
                Map.Entry entry2 = (Map.Entry) itXJ.next();
                AZxh(sb, i, "[32149011]", entry2.getValue());
            }
        }
        C1432kz c1432kz = ((AbstractC1010dy) ky).zbc;
        if (c1432kz != null) {
            c1432kz.qdMbNW(sb, i);
        }
    }

    public static String mjFkc(Ky ky, String str) throws SecurityException {
        StringBuilder sb = new StringBuilder();
        sb.append("# ");
        sb.append(str);
        ZfxDd(ky, sb, 0);
        return sb.toString();
    }

    public static void wA(int i, StringBuilder sb) {
        while (i > 0) {
            int i2 = 80;
            if (i <= 80) {
                i2 = i;
            }
            sb.append(mjFkc, 0, i2);
            i -= i2;
        }
    }
}
