package o;

import org.conscrypt.BuildConfig;

/* renamed from: o.Ge, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0313Ge extends Zx implements Ly {
    private static final C0313Ge zbd;
    private int zbD;
    private C1531me zbE;
    private C0704Xd zbF;
    private int zbG;
    private int zbe;
    private C1051ee zbh;
    private C1651oe zbi;
    private int zbk;
    private C1428kv zbl;
    private float zbm;
    private float zbn;
    private float zbo;
    private float zbp;
    private float zbq;
    private C1891se zbs;
    private C1232he zbu;
    private C2314ze zbv;
    private C0290Fe zbw;
    private int zbx;
    private long zby;
    private C1430kx zbz;
    private byte zbH = 2;
    private int zbf = -1;
    private InterfaceC1371jy zbg = AbstractC1010dy.BAnRFn();
    private int zbj = 2;
    private String zbr = BuildConfig.FLAVOR;
    private String zbt = BuildConfig.FLAVOR;
    private String zbA = BuildConfig.FLAVOR;
    private InterfaceC1491ly zbB = AbstractC1010dy.wJVbdd();
    private InterfaceC1310iy zbC = AbstractC1010dy.VocHEe();

    static {
        C0313Ge c0313Ge = new C0313Ge();
        zbd = c0313Ge;
        AbstractC1010dy.YoKzxo(C0313Ge.class, c0313Ge);
    }

    public final int CqaNbM() {
        int iMjFkc = AbstractC0244De.mjFkc(this.zbj);
        if (iMjFkc == 0) {
            return 3;
        }
        return iMjFkc;
    }

    @Override // o.AbstractC1010dy
    public final Object IEE(int i, Object obj, Object obj2) {
        int i2 = i - 1;
        if (i2 == 0) {
            return Byte.valueOf(this.zbH);
        }
        if (i2 == 2) {
            return AbstractC1010dy.ETF(zbd, "\u0001\u001c\u0000\u0001\u0001 \u001c\u0000\u0003\u0005\u0001င\u0000\u0002ᐉ\u0001\u0003ᐉ\u0002\u0004᠌\u0003\u0005᠌\u0004\u0006ဉ\u0005\u0007ခ\t\bဈ\u000b\rᐉ\f\u000eခ\u0006\u000fဈ\r\u0010ᐉ\u000e\u0011ဉ\u000f\u0012ဉ\u0010\u0013င\u0011\u0014ဂ\u0012\u0015ဉ\u0013\u0016ခ\b\u0017ဈ\u0014\u0018\u001a\u0019\u0013\u001aင\u0015\u001bခ\u0007\u001cဉ\u0016\u001d'\u001eᐉ\u0017\u001fခ\n င\u0018", new Object[]{"zbe", "zbf", "zbh", "zbi", "zbj", C0221Ce.mjFkc, "zbk", C0175Ae.mjFkc, "zbl", "zbp", "zbr", "zbs", "zbm", "zbt", "zbu", "zbv", "zbw", "zbx", "zby", "zbz", "zbo", "zbA", "zbB", "zbC", "zbD", "zbn", "zbE", "zbg", "zbF", "zbq", "zbG"});
        }
        if (i2 == 3) {
            return new C0313Ge();
        }
        AbstractC0727Yd abstractC0727Yd = null;
        if (i2 == 4) {
            return new C1951te(abstractC0727Yd);
        }
        if (i2 == 5) {
            return zbd;
        }
        this.zbH = obj == null ? (byte) 0 : (byte) 1;
        return null;
    }

    public final int KLMXS() {
        return this.zbf;
    }

    public final String Ne() {
        return this.zbt;
    }

    public final C1891se cMLeY() {
        C1891se c1891se = this.zbs;
        return c1891se == null ? C1891se.Ne() : c1891se;
    }

    public final float xrEuO() {
        return this.zbp;
    }

    public final C1051ee zvd() {
        C1051ee c1051ee = this.zbh;
        return c1051ee == null ? C1051ee.zvd() : c1051ee;
    }
}
