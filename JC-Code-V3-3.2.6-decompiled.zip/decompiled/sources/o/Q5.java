package o;

import android.database.Cursor;
import o.C0959d6;

/* loaded from: classes.dex */
public final /* synthetic */ class Q5 implements C0959d6.AZxh {
    public static final Q5 mjFkc = new Q5();

    public static C0959d6.AZxh mjFkc() {
        return mjFkc;
    }

    @Override // o.C0959d6.AZxh
    public Object apply(Object obj) {
        return C0959d6.CqaNbM((Cursor) obj);
    }
}
