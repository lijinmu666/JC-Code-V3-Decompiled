package o;

/* loaded from: classes.dex */
public final class OA implements InterfaceC1252hy {
    public static final InterfaceC1252hy mjFkc = new OA();

    @Override // o.InterfaceC1252hy
    public final boolean mjFkc(int i) {
        return i == 0 || i == 1 || i == 2 || i == 3;
    }
}
