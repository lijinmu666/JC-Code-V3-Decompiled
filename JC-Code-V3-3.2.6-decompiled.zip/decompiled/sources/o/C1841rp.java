package o;

import org.conscrypt.BuildConfig;

/* renamed from: o.rp, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C1841rp extends AbstractC1010dy implements Ly {
    private static final C1841rp zbb;
    private int zbd;
    private String zbe = BuildConfig.FLAVOR;
    private InterfaceC1491ly zbf = AbstractC1010dy.wJVbdd();
    private boolean zbg;

    static {
        C1841rp c1841rp = new C1841rp();
        zbb = c1841rp;
        AbstractC1010dy.YoKzxo(C1841rp.class, c1841rp);
    }

    @Override // o.AbstractC1010dy
    public final Object IEE(int i, Object obj, Object obj2) {
        int i2 = i - 1;
        if (i2 == 0) {
            return (byte) 1;
        }
        if (i2 == 2) {
            return AbstractC1010dy.ETF(zbb, "\u0001\u0003\u0000\u0001\u0001\u0003\u0003\u0000\u0001\u0000\u0001ဈ\u0000\u0002\u001a\u0003ဇ\u0001", new Object[]{"zbd", "zbe", "zbf", "zbg"});
        }
        if (i2 == 3) {
            return new C1841rp();
        }
        AbstractC1422kp abstractC1422kp = null;
        if (i2 == 4) {
            return new C1722pp(abstractC1422kp);
        }
        if (i2 != 5) {
            return null;
        }
        return zbb;
    }
}
