package o;

/* renamed from: o.Hm, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0344Hm extends AbstractC1010dy implements Ly {
    private static final C0344Hm zbb;
    private int zbd;
    private C1120fm zbe;
    private InterfaceC1310iy zbf = AbstractC1010dy.VocHEe();

    static {
        C0344Hm c0344Hm = new C0344Hm();
        zbb = c0344Hm;
        AbstractC1010dy.YoKzxo(C0344Hm.class, c0344Hm);
    }

    @Override // o.AbstractC1010dy
    public final Object IEE(int i, Object obj, Object obj2) {
        int i2 = i - 1;
        if (i2 == 0) {
            return (byte) 1;
        }
        if (i2 == 2) {
            return AbstractC1010dy.ETF(zbb, "\u0001\u0002\u0000\u0001\u0001\u0002\u0002\u0000\u0001\u0000\u0001ဉ\u0000\u0002\u0013", new Object[]{"zbd", "zbe", "zbf"});
        }
        if (i2 == 3) {
            return new C0344Hm();
        }
        AbstractC0252Dm abstractC0252Dm = null;
        if (i2 == 4) {
            return new C0298Fm(abstractC0252Dm);
        }
        if (i2 != 5) {
            return null;
        }
        return zbb;
    }
}
