package o;

/* renamed from: o.uu, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C2027uu implements InterfaceC1252hy {
    public static final InterfaceC1252hy mjFkc = new C2027uu();

    @Override // o.InterfaceC1252hy
    public final boolean mjFkc(int i) {
        return i == 0 || i == 1 || i == 2;
    }
}
