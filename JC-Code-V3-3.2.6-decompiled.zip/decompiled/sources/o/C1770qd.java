package o;

/* renamed from: o.qd, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C1770qd {
    public final eEOGOh AZxh;
    public final int mjFkc;

    public C1770qd(eEOGOh eeogoh, int i) {
        I3.xJ(eeogoh);
        this.AZxh = eeogoh;
        this.mjFkc = i;
    }

    public final eEOGOh AZxh() {
        return this.AZxh;
    }

    public final int mjFkc() {
        return this.mjFkc;
    }
}
