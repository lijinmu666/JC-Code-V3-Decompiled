package o;

/* renamed from: o.ja, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public interface InterfaceC1347ja {
    C1288ia wA();
}
