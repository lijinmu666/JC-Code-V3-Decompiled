package o;

import o.Xxz;

/* loaded from: classes.dex */
public final class Vgyli extends Xxz {
    public final long AZxh;
    public final Xxz.mjFkc mjFkc;

    public Vgyli(Xxz.mjFkc mjfkc, long j) {
        if (mjfkc == null) {
            throw new NullPointerException("Null status");
        }
        this.mjFkc = mjfkc;
        this.AZxh = j;
    }

    @Override // o.Xxz
    public long AZxh() {
        return this.AZxh;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof Xxz)) {
            return false;
        }
        Xxz xxz = (Xxz) obj;
        return this.mjFkc.equals(xxz.wA()) && this.AZxh == xxz.AZxh();
    }

    public int hashCode() {
        int iHashCode = (this.mjFkc.hashCode() ^ 1000003) * 1000003;
        long j = this.AZxh;
        return ((int) (j ^ (j >>> 32))) ^ iHashCode;
    }

    public String toString() {
        return "BackendResponse{status=" + this.mjFkc + ", nextRequestWaitMillis=" + this.AZxh + "}";
    }

    @Override // o.Xxz
    public Xxz.mjFkc wA() {
        return this.mjFkc;
    }
}
