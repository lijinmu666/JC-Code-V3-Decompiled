package o;

/* renamed from: o.Jp, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0394Jp extends Vx implements Ly {
    public /* synthetic */ C0394Jp(AbstractC0371Ip abstractC0371Ip) {
        super(C0417Kp.zbb);
    }
}
