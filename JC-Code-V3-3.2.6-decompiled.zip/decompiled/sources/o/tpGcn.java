package o;

import o.qGgY;

/* loaded from: classes.dex */
public final /* synthetic */ class tpGcn implements InterfaceC2281z5 {
    public static final tpGcn mjFkc = new tpGcn();

    public static InterfaceC2281z5 AZxh() {
        return mjFkc;
    }

    @Override // o.InterfaceC2281z5
    public Object mjFkc(Object obj, Object obj2) {
        return qGgY.ETF((qGgY.mjFkc) obj, (qGgY.AZxh) obj2);
    }
}
