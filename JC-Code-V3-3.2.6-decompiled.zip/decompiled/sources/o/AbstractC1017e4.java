package o;

/* renamed from: o.e4, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC1017e4 {
    public static int mjFkc = 2130903342;
}
