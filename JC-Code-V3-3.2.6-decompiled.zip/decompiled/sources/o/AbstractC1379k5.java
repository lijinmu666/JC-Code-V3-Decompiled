package o;

/* renamed from: o.k5, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC1379k5 {
}
