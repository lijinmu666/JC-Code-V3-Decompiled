package o;

import o.tISON;

/* loaded from: classes.dex */
public abstract class dGDT {

    public static abstract class mjFkc {
        public abstract mjFkc AZxh(Iterable iterable);

        public abstract dGDT mjFkc();

        public abstract mjFkc wA(byte[] bArr);
    }

    public static mjFkc mjFkc() {
        return new tISON.AZxh();
    }

    public abstract Iterable AZxh();

    public abstract byte[] wA();
}
