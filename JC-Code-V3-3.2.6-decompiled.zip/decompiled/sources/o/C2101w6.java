package o;

import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import o.C2282z6;

/* renamed from: o.w6, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final /* synthetic */ class C2101w6 implements C2282z6.mjFkc {
    public static final C2101w6 mjFkc = new C2101w6();

    public static C2282z6.mjFkc AZxh() {
        return mjFkc;
    }

    @Override // o.C2282z6.mjFkc
    public void mjFkc(SQLiteDatabase sQLiteDatabase) throws SQLException {
        C2282z6.xJ(sQLiteDatabase);
    }
}
