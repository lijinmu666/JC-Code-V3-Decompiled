package o;

/* renamed from: o.Iv, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0377Iv extends Vx implements Ly {
    public /* synthetic */ C0377Iv(AbstractC0353Hv abstractC0353Hv) {
        super(C0400Jv.zbb);
    }
}
