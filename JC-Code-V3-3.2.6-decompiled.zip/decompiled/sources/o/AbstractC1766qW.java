package o;

/* renamed from: o.qW, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC1766qW {
    public static C1706pW mjFkc;

    public static synchronized C1106fW AZxh(String str) {
        return mjFkc(QV.ZfxDd(str).wA());
    }

    public static synchronized C1106fW mjFkc(QV qv) {
        try {
            if (mjFkc == null) {
                mjFkc = new C1706pW(null);
            }
        } catch (Throwable th) {
            throw th;
        }
        return (C1106fW) mjFkc.AZxh(qv);
    }
}
