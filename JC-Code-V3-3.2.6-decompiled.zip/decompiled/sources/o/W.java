package o;

import android.content.Context;

/* loaded from: classes.dex */
public abstract class W {
    public static Boolean AZxh;
    public static Context mjFkc;

    public static synchronized boolean mjFkc(Context context) {
        Boolean bool;
        Context applicationContext = context.getApplicationContext();
        Context context2 = mjFkc;
        if (context2 != null && (bool = AZxh) != null && context2 == applicationContext) {
            return bool.booleanValue();
        }
        AZxh = null;
        if (AbstractC2158x3.JHa()) {
            AZxh = Boolean.valueOf(applicationContext.getPackageManager().isInstantApp());
        } else {
            try {
                context.getClassLoader().loadClass("com.google.android.instantapps.supervisor.InstantAppsRuntime");
                AZxh = Boolean.TRUE;
            } catch (ClassNotFoundException unused) {
                AZxh = Boolean.FALSE;
            }
        }
        mjFkc = applicationContext;
        return AZxh.booleanValue();
    }
}
