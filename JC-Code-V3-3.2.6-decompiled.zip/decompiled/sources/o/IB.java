package o;

import java.util.Collection;
import java.util.Iterator;
import java.util.Map;

/* loaded from: classes.dex */
public final class IB implements Iterator {
    public Collection AZxh;
    public final Iterator mjFkc;
    public final /* synthetic */ MB wA;

    public IB(MB mb) {
        this.wA = mb;
        this.mjFkc = mb.wA.entrySet().iterator();
    }

    @Override // java.util.Iterator
    public final boolean hasNext() {
        return this.mjFkc.hasNext();
    }

    @Override // java.util.Iterator
    public final /* bridge */ /* synthetic */ Object next() {
        Map.Entry entry = (Map.Entry) this.mjFkc.next();
        this.AZxh = (Collection) entry.getValue();
        Object key = entry.getKey();
        return new BD(key, this.wA.ZfxDd.lgHUyS(key, (Collection) entry.getValue()));
    }

    @Override // java.util.Iterator
    public final void remove() {
        XW.ZfxDd(this.AZxh != null, "no calls to next() since the last call to remove()");
        this.mjFkc.remove();
        this.wA.ZfxDd.ZfxDd -= this.AZxh.size();
        this.AZxh.clear();
        this.AZxh = null;
    }
}
