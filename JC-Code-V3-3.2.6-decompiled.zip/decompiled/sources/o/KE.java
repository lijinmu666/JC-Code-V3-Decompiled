package o;

import java.util.Iterator;
import java.util.Map;

/* loaded from: classes.dex */
public final class KE extends PD {
    public final transient int KLFTb = 1;
    public final transient Object[] ZfxDd;
    public final transient ND wA;

    public KE(ND nd, Object[] objArr, int i, int i2) {
        this.wA = nd;
        this.ZfxDd = objArr;
    }

    @Override // o.AbstractC2289zD, java.util.AbstractCollection, java.util.Collection, java.util.List
    public final boolean contains(Object obj) {
        if (obj instanceof Map.Entry) {
            Map.Entry entry = (Map.Entry) obj;
            Object key = entry.getKey();
            Object value = entry.getValue();
            if (value != null && value.equals(this.wA.get(key))) {
                return true;
            }
        }
        return false;
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.lang.Iterable, java.util.Set
    public final /* synthetic */ Iterator iterator() {
        return lgHUyS().listIterator(0);
    }

    @Override // o.AbstractC2289zD
    public final int mjFkc(Object[] objArr, int i) {
        return lgHUyS().mjFkc(objArr, 0);
    }

    @Override // o.PD
    public final JD qdMbNW() {
        return new IE(this);
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.Set
    public final int size() {
        return this.KLFTb;
    }
}
