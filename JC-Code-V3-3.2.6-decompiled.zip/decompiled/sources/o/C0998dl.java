package o;

/* renamed from: o.dl, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0998dl extends AbstractC0376Iu {
    public final AbstractC0235Cs AZxh;
    public final int mjFkc;

    public C0998dl(int i, AbstractC0235Cs abstractC0235Cs) {
        this.mjFkc = i;
        this.AZxh = abstractC0235Cs;
    }

    @Override // o.AbstractC0376Iu
    public final AbstractC0235Cs AZxh() {
        return this.AZxh;
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (obj instanceof AbstractC0376Iu) {
            AbstractC0376Iu abstractC0376Iu = (AbstractC0376Iu) obj;
            if (this.mjFkc == abstractC0376Iu.mjFkc() && this.AZxh.equals(abstractC0376Iu.AZxh())) {
                return true;
            }
        }
        return false;
    }

    public final int hashCode() {
        int i = this.mjFkc;
        return this.AZxh.hashCode() ^ ((i ^ 1000003) * 1000003);
    }

    @Override // o.AbstractC0376Iu
    public final int mjFkc() {
        return this.mjFkc;
    }

    public final String toString() {
        return "VkpStatus{exceptionType=" + this.mjFkc + ", remoteException=" + this.AZxh.toString() + "}";
    }
}
