package o;

/* renamed from: o.ni, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C1595ni extends Vx implements Ly {
    public /* synthetic */ C1595ni(AbstractC0432Lh abstractC0432Lh) {
        super(C0548Qi.zbb);
    }
}
