package o;

/* renamed from: o.Wp, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0693Wp extends AbstractC1010dy implements Ly {
    private static final C0693Wp zbb;
    private InterfaceC1491ly zbd = AbstractC1010dy.wJVbdd();

    static {
        C0693Wp c0693Wp = new C0693Wp();
        zbb = c0693Wp;
        AbstractC1010dy.YoKzxo(C0693Wp.class, c0693Wp);
    }

    @Override // o.AbstractC1010dy
    public final Object IEE(int i, Object obj, Object obj2) {
        int i2 = i - 1;
        if (i2 == 0) {
            return (byte) 1;
        }
        if (i2 == 2) {
            return AbstractC1010dy.ETF(zbb, "\u0001\u0001\u0000\u0000\u0001\u0001\u0001\u0000\u0001\u0000\u0001\u001b", new Object[]{"zbd", C0624Tp.class});
        }
        if (i2 == 3) {
            return new C0693Wp();
        }
        AbstractC0647Up abstractC0647Up = null;
        if (i2 == 4) {
            return new C0670Vp(abstractC0647Up);
        }
        if (i2 != 5) {
            return null;
        }
        return zbb;
    }
}
