package o;

import android.accounts.Account;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.api.Scope;

/* renamed from: o.eR, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C1040eR implements Parcelable.Creator {
    public static void mjFkc(nVsW nvsw, Parcel parcel, int i) {
        int iMjFkc = AbstractC1380k6.mjFkc(parcel);
        AbstractC1380k6.xJ(parcel, 1, nvsw.mjFkc);
        AbstractC1380k6.xJ(parcel, 2, nvsw.AZxh);
        AbstractC1380k6.xJ(parcel, 3, nvsw.wA);
        AbstractC1380k6.ETF(parcel, 4, nvsw.ZfxDd, false);
        AbstractC1380k6.JHa(parcel, 5, nvsw.KLFTb, false);
        AbstractC1380k6.MiMN(parcel, 6, nvsw.JHa, i, false);
        AbstractC1380k6.ZfxDd(parcel, 7, nvsw.xJ, false);
        AbstractC1380k6.Dt(parcel, 8, nvsw.lgHUyS, i, false);
        AbstractC1380k6.MiMN(parcel, 10, nvsw.qdMbNW, i, false);
        AbstractC1380k6.MiMN(parcel, 11, nvsw.Dt, i, false);
        AbstractC1380k6.wA(parcel, 12, nvsw.ETF);
        AbstractC1380k6.xJ(parcel, 13, nvsw.VA);
        AbstractC1380k6.wA(parcel, 14, nvsw.MiMN);
        AbstractC1380k6.ETF(parcel, 15, nvsw.mjFkc(), false);
        AbstractC1380k6.AZxh(parcel, iMjFkc);
    }

    @Override // android.os.Parcelable.Creator
    public final /* bridge */ /* synthetic */ Object createFromParcel(Parcel parcel) {
        int iIEE = AbstractC1319j6.IEE(parcel);
        Scope[] scopeArr = nVsW.rkYL;
        Bundle bundle = new Bundle();
        UokA[] uokAArr = nVsW.qGY;
        UokA[] uokAArr2 = uokAArr;
        String strZfxDd = null;
        IBinder iBinderMiMN = null;
        Account account = null;
        String strZfxDd2 = null;
        int iYoKzxo = 0;
        int iYoKzxo2 = 0;
        int iYoKzxo3 = 0;
        boolean zDt = false;
        int iYoKzxo4 = 0;
        boolean zDt2 = false;
        while (parcel.dataPosition() < iIEE) {
            int iVA = AbstractC1319j6.VA(parcel);
            switch (AbstractC1319j6.qdMbNW(iVA)) {
                case 1:
                    iYoKzxo = AbstractC1319j6.YoKzxo(parcel, iVA);
                    break;
                case 2:
                    iYoKzxo2 = AbstractC1319j6.YoKzxo(parcel, iVA);
                    break;
                case 3:
                    iYoKzxo3 = AbstractC1319j6.YoKzxo(parcel, iVA);
                    break;
                case 4:
                    strZfxDd = AbstractC1319j6.ZfxDd(parcel, iVA);
                    break;
                case 5:
                    iBinderMiMN = AbstractC1319j6.MiMN(parcel, iVA);
                    break;
                case 6:
                    scopeArr = (Scope[]) AbstractC1319j6.JHa(parcel, iVA, Scope.CREATOR);
                    break;
                case 7:
                    bundle = AbstractC1319j6.mjFkc(parcel, iVA);
                    break;
                case 8:
                    account = (Account) AbstractC1319j6.wA(parcel, iVA, Account.CREATOR);
                    break;
                case 9:
                default:
                    AbstractC1319j6.fehf(parcel, iVA);
                    break;
                case 10:
                    uokAArr = (UokA[]) AbstractC1319j6.JHa(parcel, iVA, UokA.CREATOR);
                    break;
                case 11:
                    uokAArr2 = (UokA[]) AbstractC1319j6.JHa(parcel, iVA, UokA.CREATOR);
                    break;
                case 12:
                    zDt = AbstractC1319j6.Dt(parcel, iVA);
                    break;
                case 13:
                    iYoKzxo4 = AbstractC1319j6.YoKzxo(parcel, iVA);
                    break;
                case 14:
                    zDt2 = AbstractC1319j6.Dt(parcel, iVA);
                    break;
                case 15:
                    strZfxDd2 = AbstractC1319j6.ZfxDd(parcel, iVA);
                    break;
            }
        }
        AbstractC1319j6.lgHUyS(parcel, iIEE);
        return new nVsW(iYoKzxo, iYoKzxo2, iYoKzxo3, strZfxDd, iBinderMiMN, scopeArr, bundle, account, uokAArr, uokAArr2, zDt, iYoKzxo4, zDt2, strZfxDd2);
    }

    @Override // android.os.Parcelable.Creator
    public final /* synthetic */ Object[] newArray(int i) {
        return new nVsW[i];
    }
}
