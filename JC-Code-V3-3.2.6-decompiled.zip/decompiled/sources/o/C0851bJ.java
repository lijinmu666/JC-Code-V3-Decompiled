package o;

/* renamed from: o.bJ, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0851bJ {
    public final KU AZxh;
    public final C1315j2 mjFkc;

    public C0851bJ(C1315j2 c1315j2) {
        KU kuAZxh = AbstractC1044eV.AZxh("common");
        this.mjFkc = c1315j2;
        this.AZxh = kuAZxh;
    }
}
