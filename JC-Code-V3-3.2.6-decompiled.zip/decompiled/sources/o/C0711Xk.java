package o;

/* renamed from: o.Xk, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0711Xk extends Vx implements Ly {
    public /* synthetic */ C0711Xk(AbstractC0665Vk abstractC0665Vk) {
        super(C0757Zk.zbb);
    }
}
