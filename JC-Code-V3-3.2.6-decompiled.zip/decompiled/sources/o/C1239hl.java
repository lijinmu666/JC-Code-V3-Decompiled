package o;

/* renamed from: o.hl, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C1239hl extends Vx implements Ly {
    public /* synthetic */ C1239hl(AbstractC1119fl abstractC1119fl) {
        super(C1358jl.zbb);
    }
}
