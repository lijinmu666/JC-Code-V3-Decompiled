package o;

/* renamed from: o.iz, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C1311iz extends RuntimeException {
    public C1311iz(Ky ky) {
        super("Message was missing required fields.  (Lite runtime could not determine which fields were missing).");
    }

    public final C1671oy mjFkc() {
        return new C1671oy(getMessage());
    }
}
