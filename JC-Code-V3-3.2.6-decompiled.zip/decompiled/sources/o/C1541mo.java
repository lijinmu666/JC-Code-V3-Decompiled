package o;

/* renamed from: o.mo, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C1541mo extends AbstractC1010dy implements Ly {
    private static final C1541mo zbb;
    private int zbd;
    private C0345Hn zbe;
    private C0714Xn zbf;
    private C0529Pn zbg;
    private C1182go zbh;

    static {
        C1541mo c1541mo = new C1541mo();
        zbb = c1541mo;
        AbstractC1010dy.YoKzxo(C1541mo.class, c1541mo);
    }

    @Override // o.AbstractC1010dy
    public final Object IEE(int i, Object obj, Object obj2) {
        int i2 = i - 1;
        if (i2 == 0) {
            return (byte) 1;
        }
        if (i2 == 2) {
            return AbstractC1010dy.ETF(zbb, "\u0001\u0004\u0000\u0001\u0001\u0004\u0004\u0000\u0000\u0000\u0001ဉ\u0000\u0002ဉ\u0001\u0003ဉ\u0002\u0004ဉ\u0003", new Object[]{"zbd", "zbe", "zbf", "zbg", "zbh"});
        }
        if (i2 == 3) {
            return new C1541mo();
        }
        AbstractC1301io abstractC1301io = null;
        if (i2 == 4) {
            return new C1421ko(abstractC1301io);
        }
        if (i2 != 5) {
            return null;
        }
        return zbb;
    }
}
