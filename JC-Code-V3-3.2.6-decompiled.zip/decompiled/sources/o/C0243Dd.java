package o;

import android.content.Context;
import android.os.Looper;
import o.aqHPIZ;

/* renamed from: o.Dd, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0243Dd extends aqHPIZ.mjFkc {
    @Override // o.aqHPIZ.mjFkc
    public final /* synthetic */ aqHPIZ.JHa mjFkc(Context context, Looper looper, zPp zpp, Object obj, jpz jpzVar, InterfaceC0774a3 interfaceC0774a3) {
        return new C0473Nd(context, looper, zpp, jpzVar, interfaceC0774a3);
    }
}
