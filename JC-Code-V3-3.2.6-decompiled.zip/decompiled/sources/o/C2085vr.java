package o;

/* renamed from: o.vr, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C2085vr implements InterfaceC1252hy {
    public static final InterfaceC1252hy mjFkc = new C2085vr();

    @Override // o.InterfaceC1252hy
    public final boolean mjFkc(int i) {
        return i == 0 || i == 1 || i == 2;
    }
}
