package o;

/* loaded from: classes.dex */
public abstract class PV {
    public abstract PV AZxh(int i);

    public abstract PV mjFkc(boolean z);

    public abstract QV wA();
}
