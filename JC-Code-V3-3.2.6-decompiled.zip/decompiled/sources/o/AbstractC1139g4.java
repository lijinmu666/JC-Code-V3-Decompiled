package o;

/* renamed from: o.g4, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC1139g4 {
    public static int mjFkc = 2130903890;
}
