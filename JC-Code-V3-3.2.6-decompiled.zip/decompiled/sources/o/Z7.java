package o;

import java.util.Locale;

/* loaded from: classes.dex */
public abstract class Z7 {
    public static final Y7 JHa;
    public static final Y7 KLFTb;
    public static final Y7 ZfxDd;
    public static final Y7 wA;
    public static final Y7 mjFkc = new KLFTb(null, false);
    public static final Y7 AZxh = new KLFTb(null, true);

    public static class AZxh implements wA {
        public static final AZxh mjFkc = new AZxh();

        @Override // o.Z7.wA
        public int mjFkc(CharSequence charSequence, int i, int i2) {
            int i3 = i2 + i;
            int iAZxh = 2;
            while (i < i3 && iAZxh == 2) {
                iAZxh = Z7.AZxh(Character.getDirectionality(charSequence.charAt(i)));
                i++;
            }
            return iAZxh;
        }
    }

    public static class JHa extends ZfxDd {
        public static final JHa AZxh = new JHa();

        public JHa() {
            super(null);
        }

        @Override // o.Z7.ZfxDd
        public boolean AZxh() {
            return AbstractC1382k8.mjFkc(Locale.getDefault()) == 1;
        }
    }

    public static class KLFTb extends ZfxDd {
        public final boolean AZxh;

        public KLFTb(wA wAVar, boolean z) {
            super(wAVar);
            this.AZxh = z;
        }

        @Override // o.Z7.ZfxDd
        public boolean AZxh() {
            return this.AZxh;
        }
    }

    public static abstract class ZfxDd implements Y7 {
        public final wA mjFkc;

        public ZfxDd(wA wAVar) {
            this.mjFkc = wAVar;
        }

        public abstract boolean AZxh();

        @Override // o.Y7
        public boolean mjFkc(CharSequence charSequence, int i, int i2) {
            if (charSequence == null || i < 0 || i2 < 0 || charSequence.length() - i2 < i) {
                throw new IllegalArgumentException();
            }
            return this.mjFkc == null ? AZxh() : wA(charSequence, i, i2);
        }

        public final boolean wA(CharSequence charSequence, int i, int i2) {
            int iMjFkc = this.mjFkc.mjFkc(charSequence, i, i2);
            if (iMjFkc == 0) {
                return true;
            }
            if (iMjFkc != 1) {
                return AZxh();
            }
            return false;
        }
    }

    public static class mjFkc implements wA {
        public static final mjFkc AZxh = new mjFkc(true);
        public final boolean mjFkc;

        public mjFkc(boolean z) {
            this.mjFkc = z;
        }

        @Override // o.Z7.wA
        public int mjFkc(CharSequence charSequence, int i, int i2) {
            int i3 = i2 + i;
            boolean z = false;
            while (i < i3) {
                int iMjFkc = Z7.mjFkc(Character.getDirectionality(charSequence.charAt(i)));
                if (iMjFkc != 0) {
                    if (iMjFkc != 1) {
                        continue;
                        i++;
                        z = z;
                    } else if (!this.mjFkc) {
                        return 1;
                    }
                } else if (this.mjFkc) {
                    return 0;
                }
                z = true;
                i++;
                z = z;
            }
            if (z) {
                return this.mjFkc ? 1 : 0;
            }
            return 2;
        }
    }

    public interface wA {
        int mjFkc(CharSequence charSequence, int i, int i2);
    }

    static {
        AZxh aZxh = AZxh.mjFkc;
        wA = new KLFTb(aZxh, false);
        ZfxDd = new KLFTb(aZxh, true);
        KLFTb = new KLFTb(mjFkc.AZxh, false);
        JHa = JHa.AZxh;
    }

    public static int AZxh(int i) {
        if (i != 0) {
            if (i == 1 || i == 2) {
                return 0;
            }
            switch (i) {
                case 14:
                case 15:
                    break;
                case 16:
                case 17:
                    return 0;
                default:
                    return 2;
            }
        }
        return 1;
    }

    public static int mjFkc(int i) {
        if (i != 0) {
            return (i == 1 || i == 2) ? 0 : 2;
        }
        return 1;
    }
}
