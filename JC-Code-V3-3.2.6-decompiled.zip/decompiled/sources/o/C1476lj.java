package o;

import org.conscrypt.BuildConfig;

/* renamed from: o.lj, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C1476lj extends AbstractC1010dy implements Ly {
    private static final C1476lj zbb;
    private int zbd;
    private int zbe;
    private int zbf;
    private String zbg = BuildConfig.FLAVOR;

    static {
        C1476lj c1476lj = new C1476lj();
        zbb = c1476lj;
        AbstractC1010dy.YoKzxo(C1476lj.class, c1476lj);
    }

    @Override // o.AbstractC1010dy
    public final Object IEE(int i, Object obj, Object obj2) {
        int i2 = i - 1;
        if (i2 == 0) {
            return (byte) 1;
        }
        if (i2 == 2) {
            return AbstractC1010dy.ETF(zbb, "\u0000\u0004\u0000\u0000\u0001\u0004\u0004\u0000\u0000\u0000\u0001\u000b\u0002\u000b\u0003\u000b\u0004Ȉ", new Object[]{"zbd", "zbe", "zbf", "zbg"});
        }
        if (i2 == 3) {
            return new C1476lj();
        }
        AbstractC1356jj abstractC1356jj = null;
        if (i2 == 4) {
            return new C1416kj(abstractC1356jj);
        }
        if (i2 != 5) {
            return null;
        }
        return zbb;
    }
}
