package o;

import android.os.Parcel;
import android.os.Parcelable;

/* renamed from: o.ts, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C1965ts implements Parcelable.Creator {
    @Override // android.os.Parcelable.Creator
    public final /* bridge */ /* synthetic */ Object createFromParcel(Parcel parcel) {
        int iIEE = AbstractC1319j6.IEE(parcel);
        boolean zDt = false;
        C0372Iq[] c0372IqArr = null;
        C1600nn c1600nn = null;
        C1600nn c1600nn2 = null;
        String strZfxDd = null;
        String strZfxDd2 = null;
        float fETF = 0.0f;
        while (parcel.dataPosition() < iIEE) {
            int iVA = AbstractC1319j6.VA(parcel);
            switch (AbstractC1319j6.qdMbNW(iVA)) {
                case 2:
                    c0372IqArr = (C0372Iq[]) AbstractC1319j6.JHa(parcel, iVA, C0372Iq.CREATOR);
                    break;
                case 3:
                    c1600nn = (C1600nn) AbstractC1319j6.wA(parcel, iVA, C1600nn.CREATOR);
                    break;
                case 4:
                    c1600nn2 = (C1600nn) AbstractC1319j6.wA(parcel, iVA, C1600nn.CREATOR);
                    break;
                case 5:
                    strZfxDd = AbstractC1319j6.ZfxDd(parcel, iVA);
                    break;
                case 6:
                    fETF = AbstractC1319j6.ETF(parcel, iVA);
                    break;
                case 7:
                    strZfxDd2 = AbstractC1319j6.ZfxDd(parcel, iVA);
                    break;
                case 8:
                    zDt = AbstractC1319j6.Dt(parcel, iVA);
                    break;
                default:
                    AbstractC1319j6.fehf(parcel, iVA);
                    break;
            }
        }
        AbstractC1319j6.lgHUyS(parcel, iIEE);
        return new C0533Pr(c0372IqArr, c1600nn, c1600nn2, strZfxDd, fETF, strZfxDd2, zDt);
    }

    @Override // android.os.Parcelable.Creator
    public final /* synthetic */ Object[] newArray(int i) {
        return new C0533Pr[i];
    }
}
