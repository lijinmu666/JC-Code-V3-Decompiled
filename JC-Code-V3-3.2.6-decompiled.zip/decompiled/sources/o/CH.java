package o;

/* loaded from: classes.dex */
public final class CH {
    public final Integer AZxh;
    public final C2232yH mjFkc;
    public final HR wA;

    public /* synthetic */ CH(C1810rH c1810rH, AH ah) {
        this.mjFkc = c1810rH.mjFkc;
        this.AZxh = c1810rH.AZxh;
        this.wA = c1810rH.wA;
    }

    public final HR AZxh() {
        return this.wA;
    }

    public final C2232yH mjFkc() {
        return this.mjFkc;
    }

    public final Integer wA() {
        return this.AZxh;
    }
}
