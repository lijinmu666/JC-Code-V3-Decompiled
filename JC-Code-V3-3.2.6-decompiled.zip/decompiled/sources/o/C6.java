package o;

import o.FbxKQm;

/* loaded from: classes.dex */
public abstract class C6 {

    public static abstract class mjFkc {
        public abstract mjFkc AZxh(dXmy dxmy);

        public abstract mjFkc JHa(String str);

        public abstract mjFkc KLFTb(X8 x8);

        public abstract mjFkc ZfxDd(M8 m8);

        public abstract C6 mjFkc();

        public abstract mjFkc wA(uhQ uhq);
    }

    public static mjFkc mjFkc() {
        return new FbxKQm.AZxh();
    }

    public abstract dXmy AZxh();

    public abstract X8 JHa();

    public abstract M8 KLFTb();

    public byte[] ZfxDd() {
        return (byte[]) KLFTb().apply(wA().AZxh());
    }

    public abstract uhQ wA();

    public abstract String xJ();
}
