package o;

/* renamed from: o.Sl, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0597Sl extends AbstractC1010dy implements Ly {
    private static final C0597Sl zbb;
    private int zbd;
    private float zbe;
    private float zbf;
    private float zbg;
    private float zbh;

    static {
        C0597Sl c0597Sl = new C0597Sl();
        zbb = c0597Sl;
        AbstractC1010dy.YoKzxo(C0597Sl.class, c0597Sl);
    }

    @Override // o.AbstractC1010dy
    public final Object IEE(int i, Object obj, Object obj2) {
        int i2 = i - 1;
        if (i2 == 0) {
            return (byte) 1;
        }
        if (i2 == 2) {
            return AbstractC1010dy.ETF(zbb, "\u0001\u0004\u0000\u0001\u0001\u0004\u0004\u0000\u0000\u0000\u0001ခ\u0000\u0002ခ\u0001\u0003ခ\u0002\u0004ခ\u0003", new Object[]{"zbd", "zbe", "zbf", "zbg", "zbh"});
        }
        if (i2 == 3) {
            return new C0597Sl();
        }
        AbstractC0504Ol abstractC0504Ol = null;
        if (i2 == 4) {
            return new C0551Ql(abstractC0504Ol);
        }
        if (i2 != 5) {
            return null;
        }
        return zbb;
    }
}
