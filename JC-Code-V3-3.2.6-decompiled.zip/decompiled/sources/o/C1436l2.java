package o;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/* renamed from: o.l2, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public class C1436l2 extends SC {
    public static final ThreadLocal AZxh = new ThreadLocal();
    public final ThreadPoolExecutor mjFkc;

    public C1436l2() {
        final ThreadFactory threadFactoryDefaultThreadFactory = Executors.defaultThreadFactory();
        int iAvailableProcessors = Runtime.getRuntime().availableProcessors();
        ThreadPoolExecutor threadPoolExecutor = new ThreadPoolExecutor(iAvailableProcessors, iAvailableProcessors, 60L, TimeUnit.SECONDS, new LinkedBlockingQueue(), new ThreadFactory() { // from class: o.BM
            @Override // java.util.concurrent.ThreadFactory
            public final Thread newThread(final Runnable runnable) {
                return threadFactoryDefaultThreadFactory.newThread(new Runnable() { // from class: o.IN
                    @Override // java.lang.Runnable
                    public final void run() {
                        C1436l2.lgHUyS(runnable);
                    }
                });
            }
        });
        this.mjFkc = threadPoolExecutor;
        threadPoolExecutor.allowCoreThreadTimeOut(true);
    }

    public static /* synthetic */ void lgHUyS(Runnable runnable) {
        AZxh.set(new ArrayDeque());
        runnable.run();
    }

    public static void qdMbNW(Deque deque, Runnable runnable) {
        I3.xJ(deque);
        deque.add(runnable);
        if (deque.size() <= 1) {
            do {
                runnable.run();
                deque.removeFirst();
                runnable = (Runnable) deque.peekFirst();
            } while (runnable != null);
        }
    }

    @Override // o.SC
    public final ExecutorService KLFTb() {
        return this.mjFkc;
    }

    @Override // o.ZW
    public final /* synthetic */ Object ZfxDd() {
        return this.mjFkc;
    }

    @Override // java.util.concurrent.Executor
    public final void execute(final Runnable runnable) {
        Deque deque = (Deque) AZxh.get();
        if (deque == null || deque.size() > 1) {
            this.mjFkc.execute(new Runnable() { // from class: o.sL
                @Override // java.lang.Runnable
                public final void run() {
                    C1436l2.qdMbNW((Deque) C1436l2.AZxh.get(), runnable);
                }
            });
        } else {
            qdMbNW(deque, runnable);
        }
    }
}
