package o;

import android.view.View;

/* renamed from: o.yP, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC2240yP {
    public static float mjFkc(float f, float f2, float f3) {
        return 1.0f - ((f - f3) / (f2 - f3));
    }

    public abstract com.google.android.material.carousel.mjFkc AZxh(wLtdyQ wltdyq, View view);
}
