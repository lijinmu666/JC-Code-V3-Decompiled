package o;

import java.io.Serializable;
import java.util.AbstractList;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.RandomAccess;

/* renamed from: o.Vs, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0673Vs extends AbstractList implements RandomAccess, Serializable {
    public final InterfaceC2328zs AZxh;
    public final List mjFkc;

    public C0673Vs(List list, InterfaceC2328zs interfaceC2328zs) {
        list.getClass();
        this.mjFkc = list;
        this.AZxh = interfaceC2328zs;
    }

    @Override // java.util.AbstractList, java.util.List
    public final Object get(int i) {
        return this.AZxh.mjFkc(this.mjFkc.get(i));
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.List
    public final boolean isEmpty() {
        return this.mjFkc.isEmpty();
    }

    @Override // java.util.AbstractList, java.util.AbstractCollection, java.util.Collection, java.lang.Iterable, java.util.List
    public final Iterator iterator() {
        return listIterator();
    }

    @Override // java.util.AbstractList, java.util.List
    public final ListIterator listIterator(int i) {
        return new C0650Us(this, this.mjFkc.listIterator(i));
    }

    @Override // java.util.AbstractList, java.util.List
    public final Object remove(int i) {
        return this.AZxh.mjFkc(this.mjFkc.remove(i));
    }

    @Override // java.util.AbstractList
    public final void removeRange(int i, int i2) {
        this.mjFkc.subList(i, i2).clear();
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.List
    public final int size() {
        return this.mjFkc.size();
    }
}
