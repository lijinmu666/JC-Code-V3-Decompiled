package o;

import org.conscrypt.BuildConfig;

/* renamed from: o.ww, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C2150ww extends AbstractC1010dy implements Ly {
    private static final C2150ww zbb;
    private int zbd;
    private int zbe;
    private C0400Jv zbg;
    private C0400Jv zbh;
    private float zbj;
    private C0400Jv zbl;
    private C0400Jv zbm;
    private C0888bw zbn;
    private C0193Aw zbp;
    private byte zbq = 2;
    private InterfaceC1371jy zbf = AbstractC1010dy.BAnRFn();
    private String zbi = BuildConfig.FLAVOR;
    private InterfaceC1491ly zbk = AbstractC1010dy.wJVbdd();
    private boolean zbo = true;

    static {
        C2150ww c2150ww = new C2150ww();
        zbb = c2150ww;
        AbstractC1010dy.YoKzxo(C2150ww.class, c2150ww);
    }

    @Override // o.AbstractC1010dy
    public final Object IEE(int i, Object obj, Object obj2) {
        int i2 = i - 1;
        if (i2 == 0) {
            return Byte.valueOf(this.zbq);
        }
        if (i2 == 2) {
            return AbstractC1010dy.ETF(zbb, "\u0001\f\u0000\u0001\u0001\f\f\u0000\u0002\b\u0001ᔄ\u0000\u0002ᔉ\u0001\u0003ᐉ\u0002\u0004ဈ\u0003\u0005ခ\u0004\u0006ᐉ\u0005\u0007ᐉ\u0006\bᐉ\u0007\tဇ\b\nᐉ\t\u000bЛ\f\u0016", new Object[]{"zbd", "zbe", "zbg", "zbh", "zbi", "zbj", "zbl", "zbm", "zbn", "zbo", "zbp", "zbk", C0537Pv.class, "zbf"});
        }
        if (i2 == 3) {
            return new C2150ww();
        }
        AbstractC0353Hv abstractC0353Hv = null;
        if (i2 == 4) {
            return new C2090vw(abstractC0353Hv);
        }
        if (i2 == 5) {
            return zbb;
        }
        this.zbq = obj == null ? (byte) 0 : (byte) 1;
        return null;
    }
}
