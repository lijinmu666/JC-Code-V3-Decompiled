package o;

/* renamed from: o.Zr, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0764Zr extends Vx implements Ly {
    public /* synthetic */ C0764Zr(AbstractC0741Yr abstractC0741Yr) {
        super(C0823as.zbb);
    }
}
