package o;

/* renamed from: o.jP, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC1338jP {
}
