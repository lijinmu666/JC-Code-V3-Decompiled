package o;

import android.util.Log;

/* renamed from: o.m1, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC1495m1 {
    public static void AZxh(String str, String str2, Object... objArr) {
        Log.d(ZfxDd(str), String.format(str2, objArr));
    }

    public static void JHa(String str, String str2, Object obj) {
        Log.w(ZfxDd(str), String.format(str2, obj));
    }

    public static void KLFTb(String str, String str2) {
        Log.i(ZfxDd(str), str2);
    }

    public static String ZfxDd(String str) {
        return "TransportRuntime." + str;
    }

    public static void mjFkc(String str, String str2, Object obj) {
        Log.d(ZfxDd(str), String.format(str2, obj));
    }

    public static void wA(String str, String str2, Throwable th) {
        Log.e(ZfxDd(str), str2, th);
    }
}
