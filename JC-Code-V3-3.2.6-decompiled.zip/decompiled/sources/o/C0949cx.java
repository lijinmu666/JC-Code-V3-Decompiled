package o;

import org.conscrypt.BuildConfig;

/* renamed from: o.cx, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0949cx extends AbstractC1010dy implements Ly {
    private static final C0949cx zbb;
    private int zbd;
    private float zbf;
    private String zbe = BuildConfig.FLAVOR;
    private int zbg = 1;

    static {
        C0949cx c0949cx = new C0949cx();
        zbb = c0949cx;
        AbstractC1010dy.YoKzxo(C0949cx.class, c0949cx);
    }

    @Override // o.AbstractC1010dy
    public final Object IEE(int i, Object obj, Object obj2) {
        int i2 = i - 1;
        if (i2 == 0) {
            return (byte) 1;
        }
        if (i2 == 2) {
            return AbstractC1010dy.ETF(zbb, "\u0004\u0003\u0000\u0001\u0001\u0003\u0003\u0000\u0000\u0000\u0001ဈ\u0000\u0002ခ\u0001\u0003င\u0002", new Object[]{"zbd", "zbe", "zbf", "zbg"});
        }
        if (i2 == 3) {
            return new C0949cx();
        }
        AbstractC0828ax abstractC0828ax = null;
        if (i2 == 4) {
            return new C0889bx(abstractC0828ax);
        }
        if (i2 != 5) {
            return null;
        }
        return zbb;
    }
}
