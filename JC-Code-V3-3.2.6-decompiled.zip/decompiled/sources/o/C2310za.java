package o;

import android.graphics.Matrix;
import android.view.View;

/* renamed from: o.za, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public class C2310za extends AbstractC2249ya {
    @Override // o.AbstractC0171Aa
    public float AZxh(View view) {
        return view.getTransitionAlpha();
    }

    @Override // o.AbstractC0171Aa
    public void JHa(View view, int i) {
        view.setTransitionVisibility(i);
    }

    @Override // o.AbstractC0171Aa
    public void KLFTb(View view, float f) {
        view.setTransitionAlpha(f);
    }

    @Override // o.AbstractC0171Aa
    public void ZfxDd(View view, int i, int i2, int i3, int i4) {
        view.setLeftTopRightBottom(i, i2, i3, i4);
    }

    @Override // o.AbstractC0171Aa
    public void lgHUyS(View view, Matrix matrix) {
        view.transformMatrixToLocal(matrix);
    }

    @Override // o.AbstractC0171Aa
    public void xJ(View view, Matrix matrix) {
        view.transformMatrixToGlobal(matrix);
    }
}
