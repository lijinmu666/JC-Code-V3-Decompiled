package o;

import android.graphics.Matrix;
import android.graphics.Rect;
import android.util.Property;
import android.view.View;

/* renamed from: o.ta, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC1947ta {
    public static final AbstractC0171Aa mjFkc = new C2310za();
    public static final Property AZxh = new mjFkc(Float.class, "translationAlpha");
    public static final Property wA = new AZxh(Rect.class, "clipBounds");

    /* renamed from: o.ta$AZxh */
    public static class AZxh extends Property {
        public AZxh(Class cls, String str) {
            super(cls, str);
        }

        @Override // android.util.Property
        /* renamed from: AZxh, reason: merged with bridge method [inline-methods] */
        public void set(View view, Rect rect) {
            T9.Moer(view, rect);
        }

        @Override // android.util.Property
        /* renamed from: mjFkc, reason: merged with bridge method [inline-methods] */
        public Rect get(View view) {
            return T9.qGY(view);
        }
    }

    /* renamed from: o.ta$mjFkc */
    public static class mjFkc extends Property {
        public mjFkc(Class cls, String str) {
            super(cls, str);
        }

        @Override // android.util.Property
        /* renamed from: AZxh, reason: merged with bridge method [inline-methods] */
        public void set(View view, Float f) {
            AbstractC1947ta.xJ(view, f.floatValue());
        }

        @Override // android.util.Property
        /* renamed from: mjFkc, reason: merged with bridge method [inline-methods] */
        public Float get(View view) {
            return Float.valueOf(AbstractC1947ta.wA(view));
        }
    }

    public static InterfaceC1587na AZxh(View view) {
        return new C1527ma(view);
    }

    public static void Dt(View view, Matrix matrix) {
        mjFkc.lgHUyS(view, matrix);
    }

    public static void JHa(View view, int i, int i2, int i3, int i4) {
        mjFkc.ZfxDd(view, i, i2, i3, i4);
    }

    public static void KLFTb(View view) {
        mjFkc.wA(view);
    }

    public static InterfaceC0447Ma ZfxDd(View view) {
        return new C0425La(view);
    }

    public static void lgHUyS(View view, int i) {
        mjFkc.JHa(view, i);
    }

    public static void mjFkc(View view) {
        mjFkc.mjFkc(view);
    }

    public static void qdMbNW(View view, Matrix matrix) {
        mjFkc.xJ(view, matrix);
    }

    public static float wA(View view) {
        return mjFkc.AZxh(view);
    }

    public static void xJ(View view, float f) {
        mjFkc.KLFTb(view, f);
    }
}
