package o;

import android.content.Context;
import android.content.res.ColorStateList;

/* renamed from: o.bc, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public interface InterfaceC0868bc {
    float AZxh(xCVa xcva);

    void Dt(xCVa xcva);

    float ETF(xCVa xcva);

    float JHa(xCVa xcva);

    void KLFTb(xCVa xcva);

    float MiMN(xCVa xcva);

    void VA(xCVa xcva);

    void YoKzxo(xCVa xcva, float f);

    float ZfxDd(xCVa xcva);

    void lgHUyS();

    ColorStateList mjFkc(xCVa xcva);

    void qdMbNW(xCVa xcva, ColorStateList colorStateList);

    void rkYL(xCVa xcva, float f);

    void wA(xCVa xcva, float f);

    void xJ(xCVa xcva, Context context, ColorStateList colorStateList, float f, float f2, float f3);
}
