package o;

/* renamed from: o.Rh, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0570Rh extends Vx implements Ly {
    public /* synthetic */ C0570Rh(AbstractC0363Ih abstractC0363Ih) {
        super(C0593Sh.zbb);
    }
}
