package o;

import o.C0797aQ;

/* renamed from: o.yK, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C2235yK implements R2 {
    public static final C2235yK mjFkc = new C2235yK();

    static {
        C0797aQ.AZxh aZxhMjFkc = C0797aQ.mjFkc("type");
        C1389kF c1389kF = new C1389kF();
        c1389kF.mjFkc(1);
        aZxhMjFkc.AZxh(c1389kF.AZxh()).mjFkc();
        C0797aQ.AZxh aZxhMjFkc2 = C0797aQ.mjFkc("dims");
        C1389kF c1389kF2 = new C1389kF();
        c1389kF2.mjFkc(2);
        aZxhMjFkc2.AZxh(c1389kF2.AZxh()).mjFkc();
    }

    @Override // o.mYYU
    public final /* bridge */ /* synthetic */ void mjFkc(Object obj, Object obj2) {
        AbstractC2102w7.mjFkc(obj);
        throw null;
    }
}
