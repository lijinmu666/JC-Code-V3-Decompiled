package o;

import org.conscrypt.BuildConfig;

/* renamed from: o.Tf, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0614Tf extends AbstractC1010dy implements Ly {
    private static final C0614Tf zbb;
    private int zbd;
    private InterfaceC1491ly zbe = AbstractC1010dy.wJVbdd();
    private String zbf = BuildConfig.FLAVOR;

    static {
        C0614Tf c0614Tf = new C0614Tf();
        zbb = c0614Tf;
        AbstractC1010dy.YoKzxo(C0614Tf.class, c0614Tf);
    }

    @Override // o.AbstractC1010dy
    public final Object IEE(int i, Object obj, Object obj2) {
        int i2 = i - 1;
        if (i2 == 0) {
            return (byte) 1;
        }
        if (i2 == 2) {
            return AbstractC1010dy.ETF(zbb, "\u0001\u0002\u0000\u0001\u0001\u0002\u0002\u0000\u0001\u0000\u0001\u001a\u0002ဈ\u0000", new Object[]{"zbd", "zbe", "zbf"});
        }
        if (i2 == 3) {
            return new C0614Tf();
        }
        AbstractC0521Pf abstractC0521Pf = null;
        if (i2 == 4) {
            return new C0591Sf(abstractC0521Pf);
        }
        if (i2 != 5) {
            return null;
        }
        return zbb;
    }
}
