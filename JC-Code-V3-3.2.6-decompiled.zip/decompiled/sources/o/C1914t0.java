package o;

import java.io.Closeable;
import java.io.EOFException;
import java.io.IOException;
import java.io.Reader;
import java.util.Arrays;
import kotlin.text.Typography;
import okio.internal.Buffer;

/* renamed from: o.t0, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public class C1914t0 implements Closeable {
    public int Dt;
    public String ETF;
    public int[] VA;
    public String[] YoKzxo;
    public final Reader mjFkc;
    public long qdMbNW;
    public int[] rkYL;
    public boolean AZxh = false;
    public final char[] wA = new char[1024];
    public int ZfxDd = 0;
    public int KLFTb = 0;
    public int JHa = 0;
    public int xJ = 0;
    public int lgHUyS = 0;
    public int MiMN = 1;

    /* renamed from: o.t0$mjFkc */
    public class mjFkc extends AbstractC1974u0 {
    }

    static {
        AbstractC1974u0.mjFkc = new mjFkc();
    }

    public C1914t0(Reader reader) {
        int[] iArr = new int[32];
        this.VA = iArr;
        iArr[0] = 6;
        this.YoKzxo = new String[32];
        this.rkYL = new int[32];
        if (reader == null) {
            throw new NullPointerException("in == null");
        }
        this.mjFkc = reader;
    }

    public String BAnRFn() throws IOException {
        String strMByQ;
        int iQdMbNW = this.lgHUyS;
        if (iQdMbNW == 0) {
            iQdMbNW = qdMbNW();
        }
        if (iQdMbNW == 14) {
            strMByQ = Ne();
        } else if (iQdMbNW == 12) {
            strMByQ = mByQ('\'');
        } else {
            if (iQdMbNW != 13) {
                throw new IllegalStateException("Expected a name but was " + CqaNbM() + huTpC());
            }
            strMByQ = mByQ(Typography.quote);
        }
        this.lgHUyS = 0;
        this.YoKzxo[this.MiMN - 1] = strMByQ;
        return strMByQ;
    }

    public EnumC2095w0 CqaNbM() throws IOException {
        int iQdMbNW = this.lgHUyS;
        if (iQdMbNW == 0) {
            iQdMbNW = qdMbNW();
        }
        switch (iQdMbNW) {
            case 1:
                return EnumC2095w0.BEGIN_OBJECT;
            case 2:
                return EnumC2095w0.END_OBJECT;
            case 3:
                return EnumC2095w0.BEGIN_ARRAY;
            case 4:
                return EnumC2095w0.END_ARRAY;
            case 5:
            case 6:
                return EnumC2095w0.BOOLEAN;
            case 7:
                return EnumC2095w0.NULL;
            case 8:
            case 9:
            case 10:
            case 11:
                return EnumC2095w0.STRING;
            case 12:
            case 13:
            case 14:
                return EnumC2095w0.NAME;
            case 15:
            case 16:
                return EnumC2095w0.NUMBER;
            case 17:
                return EnumC2095w0.END_DOCUMENT;
            default:
                throw new AssertionError();
        }
    }

    public boolean Gd() throws IOException {
        int iQdMbNW = this.lgHUyS;
        if (iQdMbNW == 0) {
            iQdMbNW = qdMbNW();
        }
        if (iQdMbNW == 5) {
            this.lgHUyS = 0;
            int[] iArr = this.rkYL;
            int i = this.MiMN - 1;
            iArr[i] = iArr[i] + 1;
            return true;
        }
        if (iQdMbNW == 6) {
            this.lgHUyS = 0;
            int[] iArr2 = this.rkYL;
            int i2 = this.MiMN - 1;
            iArr2[i2] = iArr2[i2] + 1;
            return false;
        }
        throw new IllegalStateException("Expected a boolean but was " + CqaNbM() + huTpC());
    }

    public double HGpJ() throws IOException, NumberFormatException {
        int iQdMbNW = this.lgHUyS;
        if (iQdMbNW == 0) {
            iQdMbNW = qdMbNW();
        }
        if (iQdMbNW == 15) {
            this.lgHUyS = 0;
            int[] iArr = this.rkYL;
            int i = this.MiMN - 1;
            iArr[i] = iArr[i] + 1;
            return this.qdMbNW;
        }
        if (iQdMbNW == 16) {
            this.ETF = new String(this.wA, this.ZfxDd, this.Dt);
            this.ZfxDd += this.Dt;
        } else if (iQdMbNW == 8 || iQdMbNW == 9) {
            this.ETF = mByQ(iQdMbNW == 8 ? '\'' : Typography.quote);
        } else if (iQdMbNW == 10) {
            this.ETF = Ne();
        } else if (iQdMbNW != 11) {
            throw new IllegalStateException("Expected a double but was " + CqaNbM() + huTpC());
        }
        this.lgHUyS = 11;
        double d = Double.parseDouble(this.ETF);
        if (!this.AZxh && (Double.isNaN(d) || Double.isInfinite(d))) {
            throw new C2156x1("JSON forbids NaN and infinities: " + d + huTpC());
        }
        this.ETF = null;
        this.lgHUyS = 0;
        int[] iArr2 = this.rkYL;
        int i2 = this.MiMN - 1;
        iArr2[i2] = iArr2[i2] + 1;
        return d;
    }

    public void KLFTb() throws IOException {
        int iQdMbNW = this.lgHUyS;
        if (iQdMbNW == 0) {
            iQdMbNW = qdMbNW();
        }
        if (iQdMbNW == 1) {
            zvd(3);
            this.lgHUyS = 0;
        } else {
            throw new IllegalStateException("Expected BEGIN_OBJECT but was " + CqaNbM() + huTpC());
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:54:0x0091, code lost:
    
        if (Ucbh(r14) != false) goto L78;
     */
    /* JADX WARN: Code restructure failed: missing block: B:55:0x0093, code lost:
    
        if (r9 != 2) goto L68;
     */
    /* JADX WARN: Code restructure failed: missing block: B:56:0x0095, code lost:
    
        if (r10 == false) goto L68;
     */
    /* JADX WARN: Code restructure failed: missing block: B:58:0x009b, code lost:
    
        if (r11 != Long.MIN_VALUE) goto L60;
     */
    /* JADX WARN: Code restructure failed: missing block: B:59:0x009d, code lost:
    
        if (r13 == false) goto L68;
     */
    /* JADX WARN: Code restructure failed: missing block: B:61:0x00a3, code lost:
    
        if (r11 != 0) goto L63;
     */
    /* JADX WARN: Code restructure failed: missing block: B:62:0x00a5, code lost:
    
        if (r13 != false) goto L68;
     */
    /* JADX WARN: Code restructure failed: missing block: B:63:0x00a7, code lost:
    
        if (r13 == false) goto L65;
     */
    /* JADX WARN: Code restructure failed: missing block: B:65:0x00aa, code lost:
    
        r11 = -r11;
     */
    /* JADX WARN: Code restructure failed: missing block: B:66:0x00ab, code lost:
    
        r18.qdMbNW = r11;
        r18.ZfxDd += r8;
        r18.lgHUyS = 15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:67:0x00b6, code lost:
    
        return 15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:68:0x00b7, code lost:
    
        if (r9 == 2) goto L76;
     */
    /* JADX WARN: Code restructure failed: missing block: B:70:0x00ba, code lost:
    
        if (r9 == 4) goto L76;
     */
    /* JADX WARN: Code restructure failed: missing block: B:72:0x00bd, code lost:
    
        if (r9 != 7) goto L74;
     */
    /* JADX WARN: Code restructure failed: missing block: B:74:0x00c0, code lost:
    
        return 0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:76:0x00c2, code lost:
    
        r18.Dt = r8;
        r18.lgHUyS = 16;
     */
    /* JADX WARN: Code restructure failed: missing block: B:77:0x00c8, code lost:
    
        return 16;
     */
    /* JADX WARN: Code restructure failed: missing block: B:78:0x00c9, code lost:
    
        return 0;
     */
    /* JADX WARN: Removed duplicated region for block: B:14:0x0030  */
    /* JADX WARN: Removed duplicated region for block: B:97:0x00ec  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final int KLMXS() {
        char c;
        char c2;
        char[] cArr = this.wA;
        int i = this.ZfxDd;
        int i2 = this.KLFTb;
        int i3 = 0;
        int i4 = 0;
        char c3 = 0;
        boolean z = false;
        boolean z2 = true;
        long j = 0;
        while (true) {
            if (i + i4 != i2) {
                c = cArr[i + i4];
                if (c == '+') {
                    if (c == 'E' || c == 'e') {
                        i3 = 0;
                        if (c3 != 2 && c3 != 4) {
                            return 0;
                        }
                        c3 = 5;
                    } else if (c != '-') {
                        c2 = 3;
                        if (c == '.') {
                            i3 = 0;
                            if (c3 != 2) {
                                return 0;
                            }
                        } else {
                            if (c < '0' || c > '9') {
                                break;
                            }
                            if (c3 == 1 || c3 == 0) {
                                j = -(c - '0');
                                c3 = 2;
                            } else if (c3 == 2) {
                                if (j == 0) {
                                    return 0;
                                }
                                long j2 = (10 * j) - (c - '0');
                                z2 &= j > Buffer.OVERFLOW_ZONE || (j == Buffer.OVERFLOW_ZONE && j2 < j);
                                j = j2;
                            } else if (c3 == 3) {
                                i3 = 0;
                                c3 = 4;
                            } else if (c3 == 5 || c3 == 6) {
                                i3 = 0;
                                c3 = 7;
                            }
                            i3 = 0;
                        }
                    } else {
                        c2 = 6;
                        i3 = 0;
                        if (c3 == 0) {
                            c3 = 1;
                            z = true;
                        } else if (c3 != 5) {
                            return 0;
                        }
                    }
                    i4++;
                } else {
                    c2 = 6;
                    i3 = 0;
                    if (c3 != 5) {
                        return 0;
                    }
                }
                c3 = c2;
                i4++;
            } else {
                if (i4 == cArr.length) {
                    return i3;
                }
                if (!fehf(i4 + 1)) {
                    break;
                }
                i = this.ZfxDd;
                i2 = this.KLFTb;
                c = cArr[i + i4];
                if (c == '+') {
                }
                c3 = c2;
                i4++;
            }
        }
    }

    public void MiMN() throws IOException {
        int iQdMbNW = this.lgHUyS;
        if (iQdMbNW == 0) {
            iQdMbNW = qdMbNW();
        }
        if (iQdMbNW != 2) {
            throw new IllegalStateException("Expected END_OBJECT but was " + CqaNbM() + huTpC());
        }
        int i = this.MiMN;
        int i2 = i - 1;
        this.MiMN = i2;
        this.YoKzxo[i2] = null;
        int[] iArr = this.rkYL;
        int i3 = i - 2;
        iArr[i3] = iArr[i3] + 1;
        this.lgHUyS = 0;
    }

    public final void NPj() {
        char c;
        do {
            if (this.ZfxDd >= this.KLFTb && !fehf(1)) {
                return;
            }
            char[] cArr = this.wA;
            int i = this.ZfxDd;
            int i2 = i + 1;
            this.ZfxDd = i2;
            c = cArr[i];
            if (c == '\n') {
                this.JHa++;
                this.xJ = i2;
                return;
            }
        } while (c != '\r');
    }

    /* JADX WARN: Code restructure failed: missing block: B:34:0x004a, code lost:
    
        xJ();
     */
    /* JADX WARN: Failed to find 'out' block for switch in B:32:0x0044. Please report as an issue. */
    /* JADX WARN: Removed duplicated region for block: B:46:0x0080  */
    /* JADX WARN: Removed duplicated region for block: B:47:0x008a  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final String Ne() throws IOException {
        String string;
        StringBuilder sb = null;
        int i = 0;
        do {
            int i2 = 0;
            while (true) {
                int i3 = this.ZfxDd;
                if (i3 + i2 < this.KLFTb) {
                    char c = this.wA[i3 + i2];
                    if (c != '\t' && c != '\n' && c != '\f' && c != '\r' && c != ' ') {
                        if (c != '#') {
                            if (c != ',') {
                                if (c != '/' && c != '=') {
                                    if (c != '{' && c != '}' && c != ':') {
                                        if (c != ';') {
                                            switch (c) {
                                                case '[':
                                                case ']':
                                                    break;
                                                case '\\':
                                                    break;
                                                default:
                                                    i2++;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                } else if (i2 >= this.wA.length) {
                    if (sb == null) {
                        sb = new StringBuilder(Math.max(i2, 16));
                    }
                    sb.append(this.wA, this.ZfxDd, i2);
                    this.ZfxDd += i2;
                } else if (fehf(i2 + 1)) {
                }
            }
            i = i2;
            if (sb != null) {
                string = new String(this.wA, this.ZfxDd, i);
            } else {
                sb.append(this.wA, this.ZfxDd, i);
                string = sb.toString();
            }
            this.ZfxDd += i;
            return string;
        } while (fehf(1));
        if (sb != null) {
        }
        this.ZfxDd += i;
        return string;
    }

    public String OjSQV() throws IOException {
        String str;
        int iQdMbNW = this.lgHUyS;
        if (iQdMbNW == 0) {
            iQdMbNW = qdMbNW();
        }
        if (iQdMbNW == 10) {
            str = Ne();
        } else if (iQdMbNW == 8) {
            str = mByQ('\'');
        } else if (iQdMbNW == 9) {
            str = mByQ(Typography.quote);
        } else if (iQdMbNW == 11) {
            str = this.ETF;
            this.ETF = null;
        } else if (iQdMbNW == 15) {
            str = Long.toString(this.qdMbNW);
        } else {
            if (iQdMbNW != 16) {
                throw new IllegalStateException("Expected a string but was " + CqaNbM() + huTpC());
            }
            str = new String(this.wA, this.ZfxDd, this.Dt);
            this.ZfxDd += this.Dt;
        }
        this.lgHUyS = 0;
        int[] iArr = this.rkYL;
        int i = this.MiMN - 1;
        iArr[i] = iArr[i] + 1;
        return str;
    }

    public String Pq() {
        StringBuilder sb = new StringBuilder();
        sb.append(Typography.dollar);
        int i = this.MiMN;
        for (int i2 = 0; i2 < i; i2++) {
            int i3 = this.VA[i2];
            if (i3 == 1 || i3 == 2) {
                sb.append('[');
                sb.append(this.rkYL[i2]);
                sb.append(']');
            } else if (i3 == 3 || i3 == 4 || i3 == 5) {
                sb.append('.');
                String str = this.YoKzxo[i2];
                if (str != null) {
                    sb.append(str);
                }
            }
        }
        return sb.toString();
    }

    public final boolean Ucbh(char c) throws IOException {
        if (c == '\t' || c == '\n' || c == '\f' || c == '\r' || c == ' ') {
            return false;
        }
        if (c != '#') {
            if (c == ',') {
                return false;
            }
            if (c != '/' && c != '=') {
                if (c == '{' || c == '}' || c == ':') {
                    return false;
                }
                if (c != ';') {
                    switch (c) {
                        case '[':
                        case ']':
                            return false;
                        case '\\':
                            break;
                        default:
                            return true;
                    }
                }
            }
        }
        xJ();
        return false;
    }

    public void VA() throws IOException {
        int iQdMbNW = this.lgHUyS;
        if (iQdMbNW == 0) {
            iQdMbNW = qdMbNW();
        }
        if (iQdMbNW != 4) {
            throw new IllegalStateException("Expected END_ARRAY but was " + CqaNbM() + huTpC());
        }
        int i = this.MiMN;
        this.MiMN = i - 1;
        int[] iArr = this.rkYL;
        int i2 = i - 2;
        iArr[i2] = iArr[i2] + 1;
        this.lgHUyS = 0;
    }

    public final boolean Vnb(String str) {
        int length = str.length();
        while (true) {
            if (this.ZfxDd + length > this.KLFTb && !fehf(length)) {
                return false;
            }
            char[] cArr = this.wA;
            int i = this.ZfxDd;
            if (cArr[i] != '\n') {
                for (int i2 = 0; i2 < length; i2++) {
                    if (this.wA[this.ZfxDd + i2] != str.charAt(i2)) {
                        break;
                    }
                }
                return true;
            }
            this.JHa++;
            this.xJ = i + 1;
            this.ZfxDd++;
        }
    }

    public long VocHEe() throws IOException, NumberFormatException {
        int iQdMbNW = this.lgHUyS;
        if (iQdMbNW == 0) {
            iQdMbNW = qdMbNW();
        }
        if (iQdMbNW == 15) {
            this.lgHUyS = 0;
            int[] iArr = this.rkYL;
            int i = this.MiMN - 1;
            iArr[i] = iArr[i] + 1;
            return this.qdMbNW;
        }
        if (iQdMbNW == 16) {
            this.ETF = new String(this.wA, this.ZfxDd, this.Dt);
            this.ZfxDd += this.Dt;
        } else {
            if (iQdMbNW != 8 && iQdMbNW != 9 && iQdMbNW != 10) {
                throw new IllegalStateException("Expected a long but was " + CqaNbM() + huTpC());
            }
            if (iQdMbNW == 10) {
                this.ETF = Ne();
            } else {
                this.ETF = mByQ(iQdMbNW == 8 ? '\'' : Typography.quote);
            }
            try {
                long j = Long.parseLong(this.ETF);
                this.lgHUyS = 0;
                int[] iArr2 = this.rkYL;
                int i2 = this.MiMN - 1;
                iArr2[i2] = iArr2[i2] + 1;
                return j;
            } catch (NumberFormatException unused) {
            }
        }
        this.lgHUyS = 11;
        double d = Double.parseDouble(this.ETF);
        long j2 = (long) d;
        if (j2 != d) {
            throw new NumberFormatException("Expected a long but was " + this.ETF + huTpC());
        }
        this.ETF = null;
        this.lgHUyS = 0;
        int[] iArr3 = this.rkYL;
        int i3 = this.MiMN - 1;
        iArr3[i3] = iArr3[i3] + 1;
        return j2;
    }

    public void ZfxDd() throws IOException {
        int iQdMbNW = this.lgHUyS;
        if (iQdMbNW == 0) {
            iQdMbNW = qdMbNW();
        }
        if (iQdMbNW == 3) {
            zvd(1);
            this.rkYL[this.MiMN - 1] = 0;
            this.lgHUyS = 0;
        } else {
            throw new IllegalStateException("Expected BEGIN_ARRAY but was " + CqaNbM() + huTpC());
        }
    }

    public final char cMLeY() throws IOException {
        int i;
        if (this.ZfxDd == this.KLFTb && !fehf(1)) {
            throw vadzgd("Unterminated escape sequence");
        }
        char[] cArr = this.wA;
        int i2 = this.ZfxDd;
        int i3 = i2 + 1;
        this.ZfxDd = i3;
        char c = cArr[i2];
        if (c == '\n') {
            this.JHa++;
            this.xJ = i3;
        } else if (c != '\"' && c != '\'' && c != '/' && c != '\\') {
            if (c == 'b') {
                return '\b';
            }
            if (c == 'f') {
                return '\f';
            }
            if (c == 'n') {
                return '\n';
            }
            if (c == 'r') {
                return '\r';
            }
            if (c == 't') {
                return '\t';
            }
            if (c != 'u') {
                throw vadzgd("Invalid escape sequence");
            }
            if (i2 + 5 > this.KLFTb && !fehf(4)) {
                throw vadzgd("Unterminated escape sequence");
            }
            int i4 = this.ZfxDd;
            int i5 = i4 + 4;
            char c2 = 0;
            while (i4 < i5) {
                char c3 = this.wA[i4];
                char c4 = (char) (c2 << 4);
                if (c3 >= '0' && c3 <= '9') {
                    i = c3 - '0';
                } else if (c3 >= 'a' && c3 <= 'f') {
                    i = c3 - 'W';
                } else {
                    if (c3 < 'A' || c3 > 'F') {
                        throw new NumberFormatException("\\u" + new String(this.wA, this.ZfxDd, 4));
                    }
                    i = c3 - '7';
                }
                c2 = (char) (c4 + i);
                i4++;
            }
            this.ZfxDd += 4;
            return c2;
        }
        return c;
    }

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public void close() throws IOException {
        this.lgHUyS = 0;
        this.VA[0] = 8;
        this.MiMN = 1;
        this.mjFkc.close();
    }

    public boolean diqgf() throws IOException {
        int iQdMbNW = this.lgHUyS;
        if (iQdMbNW == 0) {
            iQdMbNW = qdMbNW();
        }
        return (iQdMbNW == 2 || iQdMbNW == 4) ? false : true;
    }

    public final boolean eyqo() {
        return this.AZxh;
    }

    public final boolean fehf(int i) throws IOException {
        int i2;
        int i3;
        char[] cArr = this.wA;
        int i4 = this.xJ;
        int i5 = this.ZfxDd;
        this.xJ = i4 - i5;
        int i6 = this.KLFTb;
        if (i6 != i5) {
            int i7 = i6 - i5;
            this.KLFTb = i7;
            System.arraycopy(cArr, i5, cArr, 0, i7);
        } else {
            this.KLFTb = 0;
        }
        this.ZfxDd = 0;
        do {
            Reader reader = this.mjFkc;
            int i8 = this.KLFTb;
            int i9 = reader.read(cArr, i8, cArr.length - i8);
            if (i9 == -1) {
                return false;
            }
            i2 = this.KLFTb + i9;
            this.KLFTb = i2;
            if (this.JHa == 0 && (i3 = this.xJ) == 0 && i2 > 0 && cArr[0] == 65279) {
                this.ZfxDd++;
                this.xJ = i3 + 1;
                i++;
            }
        } while (i2 < i);
        return true;
    }

    public String huTpC() {
        return " at line " + (this.JHa + 1) + " column " + ((this.ZfxDd - this.xJ) + 1) + " path " + Pq();
    }

    public final int lB(boolean z) throws IOException {
        char[] cArr = this.wA;
        int i = this.ZfxDd;
        int i2 = this.KLFTb;
        while (true) {
            if (i == i2) {
                this.ZfxDd = i;
                if (!fehf(1)) {
                    if (!z) {
                        return -1;
                    }
                    throw new EOFException("End of input" + huTpC());
                }
                i = this.ZfxDd;
                i2 = this.KLFTb;
            }
            int i3 = i + 1;
            char c = cArr[i];
            if (c == '\n') {
                this.JHa++;
                this.xJ = i3;
            } else if (c != ' ' && c != '\r' && c != '\t') {
                if (c == '/') {
                    this.ZfxDd = i3;
                    if (i3 == i2) {
                        this.ZfxDd = i;
                        boolean zFehf = fehf(2);
                        this.ZfxDd++;
                        if (!zFehf) {
                            return c;
                        }
                    }
                    xJ();
                    int i4 = this.ZfxDd;
                    char c2 = cArr[i4];
                    if (c2 == '*') {
                        this.ZfxDd = i4 + 1;
                        if (!Vnb("*/")) {
                            throw vadzgd("Unterminated comment");
                        }
                        i = this.ZfxDd + 2;
                        i2 = this.KLFTb;
                    } else {
                        if (c2 != '/') {
                            return c;
                        }
                        this.ZfxDd = i4 + 1;
                        NPj();
                        i = this.ZfxDd;
                        i2 = this.KLFTb;
                    }
                } else {
                    if (c != '#') {
                        this.ZfxDd = i3;
                        return c;
                    }
                    this.ZfxDd = i3;
                    xJ();
                    NPj();
                    i = this.ZfxDd;
                    i2 = this.KLFTb;
                }
            }
            i = i3;
        }
    }

    public final void lgHUyS() throws IOException {
        lB(true);
        int i = this.ZfxDd;
        int i2 = i - 1;
        this.ZfxDd = i2;
        if (i + 4 <= this.KLFTb || fehf(5)) {
            char[] cArr = this.wA;
            if (cArr[i2] == ')' && cArr[i] == ']' && cArr[i + 1] == '}' && cArr[i + 2] == '\'' && cArr[i + 3] == '\n') {
                this.ZfxDd += 5;
            }
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:25:0x005a, code lost:
    
        if (r1 != null) goto L27;
     */
    /* JADX WARN: Code restructure failed: missing block: B:26:0x005c, code lost:
    
        r1 = new java.lang.StringBuilder(java.lang.Math.max((r2 - r3) * 2, 16));
     */
    /* JADX WARN: Code restructure failed: missing block: B:27:0x006a, code lost:
    
        r1.append(r0, r3, r2 - r3);
        r9.ZfxDd = r2;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final String mByQ(char c) throws IOException {
        char[] cArr = this.wA;
        StringBuilder sb = null;
        do {
            int i = this.ZfxDd;
            int i2 = this.KLFTb;
            while (true) {
                int i3 = i2;
                int i4 = i;
                while (i < i3) {
                    int i5 = i + 1;
                    char c2 = cArr[i];
                    if (c2 == c) {
                        this.ZfxDd = i5;
                        int i6 = (i5 - i4) - 1;
                        if (sb == null) {
                            return new String(cArr, i4, i6);
                        }
                        sb.append(cArr, i4, i6);
                        return sb.toString();
                    }
                    if (c2 == '\\') {
                        this.ZfxDd = i5;
                        int i7 = i5 - i4;
                        int i8 = i7 - 1;
                        if (sb == null) {
                            sb = new StringBuilder(Math.max(i7 * 2, 16));
                        }
                        sb.append(cArr, i4, i8);
                        sb.append(cMLeY());
                        i = this.ZfxDd;
                        i2 = this.KLFTb;
                    } else {
                        if (c2 == '\n') {
                            this.JHa++;
                            this.xJ = i5;
                        }
                        i = i5;
                    }
                }
                break;
            }
        } while (fehf(1));
        throw vadzgd("Unterminated string");
    }

    public int qdMbNW() throws IOException {
        int iLB;
        int[] iArr = this.VA;
        int i = this.MiMN;
        int i2 = iArr[i - 1];
        if (i2 == 1) {
            iArr[i - 1] = 2;
        } else if (i2 == 2) {
            int iLB2 = lB(true);
            if (iLB2 != 44) {
                if (iLB2 != 59) {
                    if (iLB2 != 93) {
                        throw vadzgd("Unterminated array");
                    }
                    this.lgHUyS = 4;
                    return 4;
                }
                xJ();
            }
        } else {
            if (i2 == 3 || i2 == 5) {
                iArr[i - 1] = 4;
                if (i2 == 5 && (iLB = lB(true)) != 44) {
                    if (iLB != 59) {
                        if (iLB != 125) {
                            throw vadzgd("Unterminated object");
                        }
                        this.lgHUyS = 2;
                        return 2;
                    }
                    xJ();
                }
                int iLB3 = lB(true);
                if (iLB3 == 34) {
                    this.lgHUyS = 13;
                    return 13;
                }
                if (iLB3 == 39) {
                    xJ();
                    this.lgHUyS = 12;
                    return 12;
                }
                if (iLB3 == 125) {
                    if (i2 == 5) {
                        throw vadzgd("Expected name");
                    }
                    this.lgHUyS = 2;
                    return 2;
                }
                xJ();
                this.ZfxDd--;
                if (!Ucbh((char) iLB3)) {
                    throw vadzgd("Expected name");
                }
                this.lgHUyS = 14;
                return 14;
            }
            if (i2 == 4) {
                iArr[i - 1] = 5;
                int iLB4 = lB(true);
                if (iLB4 != 58) {
                    if (iLB4 != 61) {
                        throw vadzgd("Expected ':'");
                    }
                    xJ();
                    if (this.ZfxDd < this.KLFTb || fehf(1)) {
                        char[] cArr = this.wA;
                        int i3 = this.ZfxDd;
                        if (cArr[i3] == '>') {
                            this.ZfxDd = i3 + 1;
                        }
                    }
                }
            } else if (i2 == 6) {
                if (this.AZxh) {
                    lgHUyS();
                }
                this.VA[this.MiMN - 1] = 7;
            } else if (i2 == 7) {
                if (lB(false) == -1) {
                    this.lgHUyS = 17;
                    return 17;
                }
                xJ();
                this.ZfxDd--;
            } else if (i2 == 8) {
                throw new IllegalStateException("JsonReader is closed");
            }
        }
        int iLB5 = lB(true);
        if (iLB5 == 34) {
            this.lgHUyS = 9;
            return 9;
        }
        if (iLB5 == 39) {
            xJ();
            this.lgHUyS = 8;
            return 8;
        }
        if (iLB5 != 44 && iLB5 != 59) {
            if (iLB5 == 91) {
                this.lgHUyS = 3;
                return 3;
            }
            if (iLB5 != 93) {
                if (iLB5 == 123) {
                    this.lgHUyS = 1;
                    return 1;
                }
                this.ZfxDd--;
                int iXrEuO = xrEuO();
                if (iXrEuO != 0) {
                    return iXrEuO;
                }
                int iKLMXS = KLMXS();
                if (iKLMXS != 0) {
                    return iKLMXS;
                }
                if (!Ucbh(this.wA[this.ZfxDd])) {
                    throw vadzgd("Expected value");
                }
                xJ();
                this.lgHUyS = 10;
                return 10;
            }
            if (i2 == 1) {
                this.lgHUyS = 4;
                return 4;
            }
        }
        if (i2 != 1 && i2 != 2) {
            throw vadzgd("Unexpected value");
        }
        xJ();
        this.ZfxDd--;
        this.lgHUyS = 7;
        return 7;
    }

    public final void rWxwaT(boolean z) {
        this.AZxh = z;
    }

    public String toString() {
        return getClass().getSimpleName() + huTpC();
    }

    public int vI() throws IOException, NumberFormatException {
        int iQdMbNW = this.lgHUyS;
        if (iQdMbNW == 0) {
            iQdMbNW = qdMbNW();
        }
        if (iQdMbNW == 15) {
            long j = this.qdMbNW;
            int i = (int) j;
            if (j == i) {
                this.lgHUyS = 0;
                int[] iArr = this.rkYL;
                int i2 = this.MiMN - 1;
                iArr[i2] = iArr[i2] + 1;
                return i;
            }
            throw new NumberFormatException("Expected an int but was " + this.qdMbNW + huTpC());
        }
        if (iQdMbNW == 16) {
            this.ETF = new String(this.wA, this.ZfxDd, this.Dt);
            this.ZfxDd += this.Dt;
        } else {
            if (iQdMbNW != 8 && iQdMbNW != 9 && iQdMbNW != 10) {
                throw new IllegalStateException("Expected an int but was " + CqaNbM() + huTpC());
            }
            if (iQdMbNW == 10) {
                this.ETF = Ne();
            } else {
                this.ETF = mByQ(iQdMbNW == 8 ? '\'' : Typography.quote);
            }
            try {
                int i3 = Integer.parseInt(this.ETF);
                this.lgHUyS = 0;
                int[] iArr2 = this.rkYL;
                int i4 = this.MiMN - 1;
                iArr2[i4] = iArr2[i4] + 1;
                return i3;
            } catch (NumberFormatException unused) {
            }
        }
        this.lgHUyS = 11;
        double d = Double.parseDouble(this.ETF);
        int i5 = (int) d;
        if (i5 != d) {
            throw new NumberFormatException("Expected an int but was " + this.ETF + huTpC());
        }
        this.ETF = null;
        this.lgHUyS = 0;
        int[] iArr3 = this.rkYL;
        int i6 = this.MiMN - 1;
        iArr3[i6] = iArr3[i6] + 1;
        return i5;
    }

    public final IOException vadzgd(String str) throws C2156x1 {
        throw new C2156x1(str + huTpC());
    }

    public void wJVbdd() throws IOException {
        int iQdMbNW = this.lgHUyS;
        if (iQdMbNW == 0) {
            iQdMbNW = qdMbNW();
        }
        if (iQdMbNW == 7) {
            this.lgHUyS = 0;
            int[] iArr = this.rkYL;
            int i = this.MiMN - 1;
            iArr[i] = iArr[i] + 1;
            return;
        }
        throw new IllegalStateException("Expected null but was " + CqaNbM() + huTpC());
    }

    public final void xJ() throws IOException {
        if (!this.AZxh) {
            throw vadzgd("Use JsonReader.setLenient(true) to accept malformed JSON");
        }
    }

    public final int xrEuO() {
        String str;
        String str2;
        int i;
        char c = this.wA[this.ZfxDd];
        if (c == 't' || c == 'T') {
            str = "true";
            str2 = "TRUE";
            i = 5;
        } else if (c == 'f' || c == 'F') {
            str = "false";
            str2 = "FALSE";
            i = 6;
        } else {
            if (c != 'n' && c != 'N') {
                return 0;
            }
            str = "null";
            str2 = "NULL";
            i = 7;
        }
        int length = str.length();
        for (int i2 = 1; i2 < length; i2++) {
            if (this.ZfxDd + i2 >= this.KLFTb && !fehf(i2 + 1)) {
                return 0;
            }
            char c2 = this.wA[this.ZfxDd + i2];
            if (c2 != str.charAt(i2) && c2 != str2.charAt(i2)) {
                return 0;
            }
        }
        if ((this.ZfxDd + length < this.KLFTb || fehf(length + 1)) && Ucbh(this.wA[this.ZfxDd + length])) {
            return 0;
        }
        this.ZfxDd += length;
        this.lgHUyS = i;
        return i;
    }

    public final void zvd(int i) {
        int i2 = this.MiMN;
        int[] iArr = this.VA;
        if (i2 == iArr.length) {
            int i3 = i2 * 2;
            this.VA = Arrays.copyOf(iArr, i3);
            this.rkYL = Arrays.copyOf(this.rkYL, i3);
            this.YoKzxo = (String[]) Arrays.copyOf(this.YoKzxo, i3);
        }
        int[] iArr2 = this.VA;
        int i4 = this.MiMN;
        this.MiMN = i4 + 1;
        iArr2[i4] = i;
    }
}
