package o;

/* renamed from: o.qr, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C1784qr extends AbstractC1010dy implements Ly {
    private static final C1784qr zbb;
    private InterfaceC1491ly zbd = AbstractC1010dy.wJVbdd();

    static {
        C1784qr c1784qr = new C1784qr();
        zbb = c1784qr;
        AbstractC1010dy.YoKzxo(C1784qr.class, c1784qr);
    }

    @Override // o.AbstractC1010dy
    public final Object IEE(int i, Object obj, Object obj2) {
        int i2 = i - 1;
        if (i2 == 0) {
            return (byte) 1;
        }
        if (i2 == 2) {
            return AbstractC1010dy.ETF(zbb, "\u0001\u0001\u0000\u0000\u0001\u0001\u0001\u0000\u0001\u0000\u0001\u001b", new Object[]{"zbd", C1604nr.class});
        }
        if (i2 == 3) {
            return new C1784qr();
        }
        AbstractC1664or abstractC1664or = null;
        if (i2 == 4) {
            return new C1724pr(abstractC1664or);
        }
        if (i2 != 5) {
            return null;
        }
        return zbb;
    }
}
