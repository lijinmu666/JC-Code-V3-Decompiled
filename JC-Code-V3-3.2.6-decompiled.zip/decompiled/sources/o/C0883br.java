package o;

/* renamed from: o.br, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0883br extends AbstractC1010dy implements Ly {
    private static final C0883br zbb;
    private int zbd;
    private Object zbf;
    private boolean zbg;
    private long zbi;
    private float zbm;
    private float zbn;
    private float zbo;
    private int zbe = 0;
    private byte zbp = 2;
    private InterfaceC1491ly zbh = AbstractC1010dy.wJVbdd();
    private boolean zbj = true;
    private InterfaceC1310iy zbk = AbstractC1010dy.VocHEe();
    private float zbl = 0.15f;

    static {
        C0883br c0883br = new C0883br();
        zbb = c0883br;
        AbstractC1010dy.YoKzxo(C0883br.class, c0883br);
    }

    @Override // o.AbstractC1010dy
    public final Object IEE(int i, Object obj, Object obj2) {
        int i2 = i - 1;
        if (i2 == 0) {
            return Byte.valueOf(this.zbp);
        }
        if (i2 == 2) {
            return AbstractC1010dy.ETF(zbb, "\u0001\n\u0001\u0001\u0002\r\n\u0000\u0002\u0001\u0002м\u0000\u0003ဇ\u0000\u0004\u001b\u0005\u0013\u0006ခ\u0003\u0007ခ\u0004\bခ\u0005\u000bခ\u0006\fဂ\u0001\rဇ\u0002", new Object[]{"zbf", "zbe", "zbd", C2327zr.class, "zbg", "zbh", C0602Sq.class, "zbk", "zbl", "zbm", "zbn", "zbo", "zbi", "zbj"});
        }
        if (i2 == 3) {
            return new C0883br();
        }
        AbstractC0763Zq abstractC0763Zq = null;
        if (i2 == 4) {
            return new C0822ar(abstractC0763Zq);
        }
        if (i2 == 5) {
            return zbb;
        }
        this.zbp = obj == null ? (byte) 0 : (byte) 1;
        return null;
    }
}
