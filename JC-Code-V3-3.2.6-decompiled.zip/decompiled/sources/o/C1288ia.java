package o;

import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import kotlin.jvm.internal.Intrinsics;

/* renamed from: o.ia, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public class C1288ia {
    public final Map mjFkc = new LinkedHashMap();

    public final Set AZxh() {
        return new HashSet(this.mjFkc.keySet());
    }

    public final AbstractC1168ga mjFkc(String key) {
        Intrinsics.checkNotNullParameter(key, "key");
        return (AbstractC1168ga) this.mjFkc.get(key);
    }

    public final void wA(String key, AbstractC1168ga viewModel) {
        Intrinsics.checkNotNullParameter(key, "key");
        Intrinsics.checkNotNullParameter(viewModel, "viewModel");
        AbstractC1168ga abstractC1168ga = (AbstractC1168ga) this.mjFkc.put(key, viewModel);
        if (abstractC1168ga != null) {
            abstractC1168ga.AZxh();
        }
    }
}
