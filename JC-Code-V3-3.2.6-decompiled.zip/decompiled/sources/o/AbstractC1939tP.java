package o;

/* renamed from: o.tP, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC1939tP {
}
