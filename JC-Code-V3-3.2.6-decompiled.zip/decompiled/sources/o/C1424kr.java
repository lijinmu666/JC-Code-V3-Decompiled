package o;

/* renamed from: o.kr, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C1424kr extends Vx implements Ly {
    public /* synthetic */ C1424kr(AbstractC0325Gq abstractC0325Gq) {
        super(C0487Nr.zbb);
    }
}
