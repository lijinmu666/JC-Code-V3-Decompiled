package o;

/* loaded from: classes.dex */
public class QyqF {
    public final C1567nD mjFkc = new C1567nD();

    public AbstractC0631Tw AZxh() {
        return this.mjFkc;
    }

    public void mjFkc() {
        this.mjFkc.wA();
    }
}
