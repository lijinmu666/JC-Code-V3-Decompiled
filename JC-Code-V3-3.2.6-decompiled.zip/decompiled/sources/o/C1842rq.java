package o;

/* renamed from: o.rq, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C1842rq extends AbstractC1010dy implements Ly {
    private static final C1842rq zbb;
    private InterfaceC1491ly zbd = AbstractC1010dy.wJVbdd();

    static {
        C1842rq c1842rq = new C1842rq();
        zbb = c1842rq;
        AbstractC1010dy.YoKzxo(C1842rq.class, c1842rq);
    }

    @Override // o.AbstractC1010dy
    public final Object IEE(int i, Object obj, Object obj2) {
        int i2 = i - 1;
        if (i2 == 0) {
            return (byte) 1;
        }
        if (i2 == 2) {
            return AbstractC1010dy.ETF(zbb, "\u0001\u0001\u0000\u0000\u0001\u0001\u0001\u0000\u0001\u0000\u0001\u001b", new Object[]{"zbd", C1363jq.class});
        }
        if (i2 == 3) {
            return new C1842rq();
        }
        AbstractC1723pq abstractC1723pq = null;
        if (i2 == 4) {
            return new C1783qq(abstractC1723pq);
        }
        if (i2 != 5) {
            return null;
        }
        return zbb;
    }
}
