package o;

/* renamed from: o.Vd, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0658Vd extends Yx implements Ly {
    public /* synthetic */ C0658Vd(AbstractC1206hB abstractC1206hB) {
        super(C0704Xd.zbd);
    }
}
