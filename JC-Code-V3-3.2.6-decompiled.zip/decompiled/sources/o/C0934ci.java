package o;

/* renamed from: o.ci, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0934ci extends AbstractC1010dy implements Ly {
    private static final C0934ci zbb;
    private int zbd = 0;
    private Object zbe;
    private float zbf;

    static {
        C0934ci c0934ci = new C0934ci();
        zbb = c0934ci;
        AbstractC1010dy.YoKzxo(C0934ci.class, c0934ci);
    }

    @Override // o.AbstractC1010dy
    public final Object IEE(int i, Object obj, Object obj2) {
        int i2 = i - 1;
        if (i2 == 0) {
            return (byte) 1;
        }
        if (i2 == 2) {
            return AbstractC1010dy.ETF(zbb, "\u0000\u0003\u0001\u0000\u0001\u0003\u0003\u0000\u0000\u0000\u0001?\u0000\u0002Ȼ\u0000\u0003\u0001", new Object[]{"zbe", "zbd", "zbf"});
        }
        if (i2 == 3) {
            return new C0934ci();
        }
        AbstractC0363Ih abstractC0363Ih = null;
        if (i2 == 4) {
            return new C0874bi(abstractC0363Ih);
        }
        if (i2 != 5) {
            return null;
        }
        return zbb;
    }
}
