package o;

/* renamed from: o.Uk, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0642Uk extends AbstractC1010dy implements Ly {
    private static final C0642Uk zbb;
    private int zbd;
    private float zbe = 50.0f;
    private int zbf = 1;

    static {
        C0642Uk c0642Uk = new C0642Uk();
        zbb = c0642Uk;
        AbstractC1010dy.YoKzxo(C0642Uk.class, c0642Uk);
    }

    @Override // o.AbstractC1010dy
    public final Object IEE(int i, Object obj, Object obj2) {
        int i2 = i - 1;
        if (i2 == 0) {
            return (byte) 1;
        }
        if (i2 == 2) {
            return AbstractC1010dy.ETF(zbb, "\u0001\u0002\u0000\u0001\u0001\u0002\u0002\u0000\u0000\u0000\u0001ခ\u0000\u0002င\u0001", new Object[]{"zbd", "zbe", "zbf"});
        }
        if (i2 == 3) {
            return new C0642Uk();
        }
        AbstractC0550Qk abstractC0550Qk = null;
        if (i2 == 4) {
            return new C0596Sk(abstractC0550Qk);
        }
        if (i2 != 5) {
            return null;
        }
        return zbb;
    }
}
