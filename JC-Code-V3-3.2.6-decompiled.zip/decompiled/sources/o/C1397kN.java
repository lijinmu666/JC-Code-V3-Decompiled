package o;

import o.C0797aQ;

/* renamed from: o.kN, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C1397kN implements R2 {
    public static final C1397kN mjFkc = new C1397kN();

    static {
        C0797aQ.AZxh aZxhMjFkc = C0797aQ.mjFkc("errorCode");
        C1389kF c1389kF = new C1389kF();
        c1389kF.mjFkc(1);
        aZxhMjFkc.AZxh(c1389kF.AZxh()).mjFkc();
    }

    @Override // o.mYYU
    public final /* bridge */ /* synthetic */ void mjFkc(Object obj, Object obj2) {
        AbstractC2102w7.mjFkc(obj);
        throw null;
    }
}
