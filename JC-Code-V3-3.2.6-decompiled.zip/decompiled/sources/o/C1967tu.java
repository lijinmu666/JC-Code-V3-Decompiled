package o;

/* renamed from: o.tu, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C1967tu extends AbstractC1010dy implements Ly {
    private static final C1967tu zbb;
    private int zbd;
    private C0191Au zbe;
    private float zbf;
    private int zbg;
    private boolean zbh;

    static {
        C1967tu c1967tu = new C1967tu();
        zbb = c1967tu;
        AbstractC1010dy.YoKzxo(C1967tu.class, c1967tu);
    }

    @Override // o.AbstractC1010dy
    public final Object IEE(int i, Object obj, Object obj2) {
        int i2 = i - 1;
        if (i2 == 0) {
            return (byte) 1;
        }
        if (i2 == 2) {
            return AbstractC1010dy.ETF(zbb, "\u0001\u0004\u0000\u0001\u0001\u0004\u0004\u0000\u0000\u0000\u0001ဉ\u0000\u0002ခ\u0001\u0003᠌\u0002\u0004ဇ\u0003", new Object[]{"zbd", "zbe", "zbf", "zbg", C1907su.mjFkc, "zbh"});
        }
        if (i2 == 3) {
            return new C1967tu();
        }
        AbstractC1787qu abstractC1787qu = null;
        if (i2 == 4) {
            return new C1846ru(abstractC1787qu);
        }
        if (i2 != 5) {
            return null;
        }
        return zbb;
    }
}
