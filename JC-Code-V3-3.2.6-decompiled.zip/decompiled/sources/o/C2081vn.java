package o;

/* renamed from: o.vn, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C2081vn extends AbstractC1010dy implements Ly {
    private static final C2081vn zbb;
    private int zbd;
    private C0671Vq zbe;

    static {
        C2081vn c2081vn = new C2081vn();
        zbb = c2081vn;
        AbstractC1010dy.YoKzxo(C2081vn.class, c2081vn);
    }

    @Override // o.AbstractC1010dy
    public final Object IEE(int i, Object obj, Object obj2) {
        int i2 = i - 1;
        if (i2 == 0) {
            return (byte) 1;
        }
        if (i2 == 2) {
            return AbstractC1010dy.ETF(zbb, "\u0001\u0001\u0000\u0001\u0004\u0004\u0001\u0000\u0000\u0000\u0004ဉ\u0000", new Object[]{"zbd", "zbe"});
        }
        if (i2 == 3) {
            return new C2081vn();
        }
        AbstractC1720pn abstractC1720pn = null;
        if (i2 == 4) {
            return new C1960tn(abstractC1720pn);
        }
        if (i2 != 5) {
            return null;
        }
        return zbb;
    }
}
