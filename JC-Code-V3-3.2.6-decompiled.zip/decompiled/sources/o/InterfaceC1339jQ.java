package o;

/* renamed from: o.jQ, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public interface InterfaceC1339jQ {
    InterfaceC1339jQ AZxh(JO jo);

    InterfaceC1339jQ ZfxDd(EnumC1636oM enumC1636oM);

    String mjFkc();

    byte[] wA(int i, boolean z);
}
