package o;

/* loaded from: classes.dex */
public class JtIAgM extends RuntimeException {
    public JtIAgM(String str) {
        super(str);
    }
}
