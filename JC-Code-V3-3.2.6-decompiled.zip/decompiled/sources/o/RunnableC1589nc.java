package o;

import android.util.Log;

/* renamed from: o.nc, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class RunnableC1589nc implements Runnable {
    public final /* synthetic */ C1649oc AZxh;
    public final /* synthetic */ eEOGOh mjFkc;

    public RunnableC1589nc(C1649oc c1649oc, eEOGOh eeogoh) {
        this.AZxh = c1649oc;
        this.mjFkc = eeogoh;
    }

    @Override // java.lang.Runnable
    public final void run() {
        C1649oc c1649oc = this.AZxh;
        C1409kc c1409kc = (C1409kc) c1649oc.JHa.Dt.get(c1649oc.AZxh);
        if (c1409kc == null) {
            return;
        }
        if (!this.mjFkc.JHa()) {
            c1409kc.CqaNbM(this.mjFkc, null);
            return;
        }
        this.AZxh.KLFTb = true;
        if (this.AZxh.mjFkc.YoKzxo()) {
            this.AZxh.qdMbNW();
            return;
        }
        try {
            C1649oc c1649oc2 = this.AZxh;
            c1649oc2.mjFkc.AZxh(null, c1649oc2.mjFkc.wA());
        } catch (SecurityException e) {
            Log.e("GoogleApiManager", "Failed to get service from broker. ", e);
            this.AZxh.mjFkc.ZfxDd("Failed to get service from broker.");
            c1409kc.CqaNbM(new eEOGOh(10), null);
        }
    }
}
