package o;

/* renamed from: o.Tt, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0628Tt extends Zx implements Ly {
    private static final C0628Tt zbd;
    private byte zbe = 2;

    static {
        C0628Tt c0628Tt = new C0628Tt();
        zbd = c0628Tt;
        AbstractC1010dy.YoKzxo(C0628Tt.class, c0628Tt);
    }

    @Override // o.AbstractC1010dy
    public final Object IEE(int i, Object obj, Object obj2) {
        int i2 = i - 1;
        if (i2 == 0) {
            return Byte.valueOf(this.zbe);
        }
        AbstractC0535Pt abstractC0535Pt = null;
        if (i2 == 2) {
            return AbstractC1010dy.ETF(zbd, "\u0001\u0000", null);
        }
        if (i2 == 3) {
            return new C0628Tt();
        }
        if (i2 == 4) {
            return new C0605St(abstractC0535Pt);
        }
        if (i2 == 5) {
            return zbd;
        }
        this.zbe = obj == null ? (byte) 0 : (byte) 1;
        return null;
    }
}
