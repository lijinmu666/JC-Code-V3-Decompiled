package o;

import android.os.Parcel;
import android.os.Parcelable;

/* renamed from: o.g2, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public class C1137g2 extends ETF {
    public static final Parcelable.Creator<C1137g2> CREATOR = new C1829rd();
    public final int AZxh;
    public final String JHa;
    public final long KLFTb;
    public final long ZfxDd;
    public final int lgHUyS;
    public final int mjFkc;
    public final int qdMbNW;
    public final int wA;
    public final String xJ;

    public C1137g2(int i, int i2, int i3, long j, long j2, String str, String str2, int i4, int i5) {
        this.mjFkc = i;
        this.AZxh = i2;
        this.wA = i3;
        this.ZfxDd = j;
        this.KLFTb = j2;
        this.JHa = str;
        this.xJ = str2;
        this.lgHUyS = i4;
        this.qdMbNW = i5;
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i) {
        int i2 = this.mjFkc;
        int iMjFkc = AbstractC1380k6.mjFkc(parcel);
        AbstractC1380k6.xJ(parcel, 1, i2);
        AbstractC1380k6.xJ(parcel, 2, this.AZxh);
        AbstractC1380k6.xJ(parcel, 3, this.wA);
        AbstractC1380k6.qdMbNW(parcel, 4, this.ZfxDd);
        AbstractC1380k6.qdMbNW(parcel, 5, this.KLFTb);
        AbstractC1380k6.ETF(parcel, 6, this.JHa, false);
        AbstractC1380k6.ETF(parcel, 7, this.xJ, false);
        AbstractC1380k6.xJ(parcel, 8, this.lgHUyS);
        AbstractC1380k6.xJ(parcel, 9, this.qdMbNW);
        AbstractC1380k6.AZxh(parcel, iMjFkc);
    }
}
