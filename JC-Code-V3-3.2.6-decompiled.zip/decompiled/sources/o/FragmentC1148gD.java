package o;

import android.app.Activity;
import android.app.Fragment;
import android.content.Intent;
import android.os.Bundle;
import android.os.Looper;
import com.google.android.gms.common.api.internal.LifecycleCallback;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.lang.ref.WeakReference;
import java.util.Collections;
import java.util.Iterator;
import java.util.Map;
import java.util.WeakHashMap;

/* renamed from: o.gD, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class FragmentC1148gD extends Fragment implements U0 {
    public static final WeakHashMap ZfxDd = new WeakHashMap();
    public Bundle wA;
    public final Map mjFkc = Collections.synchronizedMap(new tjSezt());
    public int AZxh = 0;

    public static FragmentC1148gD JHa(Activity activity) {
        FragmentC1148gD fragmentC1148gD;
        WeakHashMap weakHashMap = ZfxDd;
        WeakReference weakReference = (WeakReference) weakHashMap.get(activity);
        if (weakReference != null && (fragmentC1148gD = (FragmentC1148gD) weakReference.get()) != null) {
            return fragmentC1148gD;
        }
        try {
            FragmentC1148gD fragmentC1148gD2 = (FragmentC1148gD) activity.getFragmentManager().findFragmentByTag("LifecycleFragmentImpl");
            if (fragmentC1148gD2 == null || fragmentC1148gD2.isRemoving()) {
                fragmentC1148gD2 = new FragmentC1148gD();
                activity.getFragmentManager().beginTransaction().add(fragmentC1148gD2, "LifecycleFragmentImpl").commitAllowingStateLoss();
            }
            weakHashMap.put(activity, new WeakReference(fragmentC1148gD2));
            return fragmentC1148gD2;
        } catch (ClassCastException e) {
            throw new IllegalStateException("Fragment with tag LifecycleFragmentImpl is not a LifecycleFragmentImpl", e);
        }
    }

    @Override // o.U0
    public final void AZxh(String str, LifecycleCallback lifecycleCallback) {
        if (this.mjFkc.containsKey(str)) {
            throw new IllegalArgumentException("LifecycleCallback with tag " + str + " already added to this fragment.");
        }
        this.mjFkc.put(str, lifecycleCallback);
        if (this.AZxh > 0) {
            new HandlerC1635oL(Looper.getMainLooper()).post(new RunnableC1685pB(this, lifecycleCallback, str));
        }
    }

    @Override // o.U0
    public final Activity KLFTb() {
        return getActivity();
    }

    @Override // o.U0
    public final LifecycleCallback ZfxDd(String str, Class cls) {
        return (LifecycleCallback) cls.cast(this.mjFkc.get(str));
    }

    @Override // android.app.Fragment
    public final void dump(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        super.dump(str, fileDescriptor, printWriter, strArr);
        Iterator it = this.mjFkc.values().iterator();
        while (it.hasNext()) {
            ((LifecycleCallback) it.next()).mjFkc(str, fileDescriptor, printWriter, strArr);
        }
    }

    @Override // android.app.Fragment
    public final void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        Iterator it = this.mjFkc.values().iterator();
        while (it.hasNext()) {
            ((LifecycleCallback) it.next()).KLFTb(i, i2, intent);
        }
    }

    @Override // android.app.Fragment
    public final void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.AZxh = 1;
        this.wA = bundle;
        for (Map.Entry entry : this.mjFkc.entrySet()) {
            ((LifecycleCallback) entry.getValue()).JHa(bundle != null ? bundle.getBundle((String) entry.getKey()) : null);
        }
    }

    @Override // android.app.Fragment
    public final void onDestroy() {
        super.onDestroy();
        this.AZxh = 5;
        Iterator it = this.mjFkc.values().iterator();
        while (it.hasNext()) {
            ((LifecycleCallback) it.next()).xJ();
        }
    }

    @Override // android.app.Fragment
    public final void onResume() {
        super.onResume();
        this.AZxh = 3;
        Iterator it = this.mjFkc.values().iterator();
        while (it.hasNext()) {
            ((LifecycleCallback) it.next()).lgHUyS();
        }
    }

    @Override // android.app.Fragment
    public final void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
        if (bundle == null) {
            return;
        }
        for (Map.Entry entry : this.mjFkc.entrySet()) {
            Bundle bundle2 = new Bundle();
            ((LifecycleCallback) entry.getValue()).qdMbNW(bundle2);
            bundle.putBundle((String) entry.getKey(), bundle2);
        }
    }

    @Override // android.app.Fragment
    public final void onStart() {
        super.onStart();
        this.AZxh = 2;
        Iterator it = this.mjFkc.values().iterator();
        while (it.hasNext()) {
            ((LifecycleCallback) it.next()).Dt();
        }
    }

    @Override // android.app.Fragment
    public final void onStop() {
        super.onStop();
        this.AZxh = 4;
        Iterator it = this.mjFkc.values().iterator();
        while (it.hasNext()) {
            ((LifecycleCallback) it.next()).ETF();
        }
    }
}
