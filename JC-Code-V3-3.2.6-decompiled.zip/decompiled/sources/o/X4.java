package o;

import JC.CODE.V3.R;

/* loaded from: classes.dex */
public abstract class X4 {
    public static int Dt = 1;
    public static int ETF = 2;
    public static int Gd = 7;
    public static int HGpJ = 8;
    public static int IEE = 1;
    public static int JHa = 3;
    public static int KLFTb = 2;
    public static int MiMN = 4;
    public static int Pq = 2;
    public static int Ucbh = 5;
    public static int VA = 3;
    public static int YoKzxo = 5;
    public static int ZfxDd = 1;
    public static int diqgf = 3;
    public static int eyqo = 4;
    public static int fehf = 0;
    public static int huTpC = 6;
    public static int qdMbNW = 0;
    public static int rkYL = 6;
    public static int vI = 9;
    public static int wA = 0;
    public static int xJ = 4;
    public static int[] mjFkc = {R.attr.queryPatterns, R.attr.shortcutMatchRequired};
    public static int[] AZxh = {android.R.attr.color, android.R.attr.alpha, android.R.attr.lStar, R.attr.alpha, R.attr.lStar};
    public static int[] lgHUyS = {R.attr.fontProviderAuthority, R.attr.fontProviderCerts, R.attr.fontProviderFetchStrategy, R.attr.fontProviderFetchTimeout, R.attr.fontProviderPackage, R.attr.fontProviderQuery, R.attr.fontProviderSystemFontFamily};
    public static int[] qGY = {android.R.attr.font, android.R.attr.fontWeight, android.R.attr.fontStyle, android.R.attr.ttcIndex, android.R.attr.fontVariationSettings, R.attr.font, R.attr.fontStyle, R.attr.fontVariationSettings, R.attr.fontWeight, R.attr.ttcIndex};
    public static int[] VocHEe = {android.R.attr.startColor, android.R.attr.endColor, android.R.attr.type, android.R.attr.centerX, android.R.attr.centerY, android.R.attr.gradientRadius, android.R.attr.tileMode, android.R.attr.centerColor, android.R.attr.startX, android.R.attr.startY, android.R.attr.endX, android.R.attr.endY};
    public static int[] BAnRFn = {android.R.attr.color, android.R.attr.offset};
}
