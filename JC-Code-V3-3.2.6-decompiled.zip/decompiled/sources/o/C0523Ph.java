package o;

/* renamed from: o.Ph, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0523Ph extends Vx implements Ly {
    public /* synthetic */ C0523Ph(AbstractC0363Ih abstractC0363Ih) {
        super(C0547Qh.zbb);
    }
}
