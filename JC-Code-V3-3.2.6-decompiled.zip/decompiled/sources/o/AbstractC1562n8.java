package o;

import android.text.TextWatcher;

/* renamed from: o.n8, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC1562n8 implements TextWatcher {
    @Override // android.text.TextWatcher
    public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
    }

    @Override // android.text.TextWatcher
    public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
    }
}
