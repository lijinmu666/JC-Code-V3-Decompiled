package o;

/* loaded from: classes.dex */
public final class XFUzSY implements ZGL {
    public static final ZGL mjFkc = new XFUzSY();

    public static final class AZxh implements R2 {
        public static final AZxh mjFkc = new AZxh();
        public static final C0797aQ AZxh = C0797aQ.ZfxDd("logRequest");

        @Override // o.mYYU
        /* renamed from: AZxh, reason: merged with bridge method [inline-methods] */
        public void mjFkc(NV nv, S2 s2) {
            s2.wA(AZxh, nv.wA());
        }
    }

    public static final class JHa implements R2 {
        public static final JHa mjFkc = new JHa();
        public static final C0797aQ AZxh = C0797aQ.ZfxDd("networkType");
        public static final C0797aQ wA = C0797aQ.ZfxDd("mobileSubtype");

        @Override // o.mYYU
        /* renamed from: AZxh, reason: merged with bridge method [inline-methods] */
        public void mjFkc(H2 h2, S2 s2) {
            s2.wA(AZxh, h2.wA());
            s2.wA(wA, h2.AZxh());
        }
    }

    public static final class KLFTb implements R2 {
        public static final KLFTb mjFkc = new KLFTb();
        public static final C0797aQ AZxh = C0797aQ.ZfxDd("requestTimeMs");
        public static final C0797aQ wA = C0797aQ.ZfxDd("requestUptimeMs");
        public static final C0797aQ ZfxDd = C0797aQ.ZfxDd("clientInfo");
        public static final C0797aQ KLFTb = C0797aQ.ZfxDd("logSource");
        public static final C0797aQ JHa = C0797aQ.ZfxDd("logSourceName");
        public static final C0797aQ xJ = C0797aQ.ZfxDd("logEvent");
        public static final C0797aQ lgHUyS = C0797aQ.ZfxDd("qosTier");

        @Override // o.mYYU
        /* renamed from: AZxh, reason: merged with bridge method [inline-methods] */
        public void mjFkc(AbstractC1314j1 abstractC1314j1, S2 s2) {
            s2.mjFkc(AZxh, abstractC1314j1.xJ());
            s2.mjFkc(wA, abstractC1314j1.lgHUyS());
            s2.wA(ZfxDd, abstractC1314j1.AZxh());
            s2.wA(KLFTb, abstractC1314j1.ZfxDd());
            s2.wA(JHa, abstractC1314j1.KLFTb());
            s2.wA(xJ, abstractC1314j1.wA());
            s2.wA(lgHUyS, abstractC1314j1.JHa());
        }
    }

    public static final class ZfxDd implements R2 {
        public static final ZfxDd mjFkc = new ZfxDd();
        public static final C0797aQ AZxh = C0797aQ.ZfxDd("eventTimeMs");
        public static final C0797aQ wA = C0797aQ.ZfxDd("eventCode");
        public static final C0797aQ ZfxDd = C0797aQ.ZfxDd("eventUptimeMs");
        public static final C0797aQ KLFTb = C0797aQ.ZfxDd("sourceExtension");
        public static final C0797aQ JHa = C0797aQ.ZfxDd("sourceExtensionJsonProto3");
        public static final C0797aQ xJ = C0797aQ.ZfxDd("timezoneOffsetSeconds");
        public static final C0797aQ lgHUyS = C0797aQ.ZfxDd("networkConnectionInfo");

        @Override // o.mYYU
        /* renamed from: AZxh, reason: merged with bridge method [inline-methods] */
        public void mjFkc(AbstractC1256i1 abstractC1256i1, S2 s2) {
            s2.mjFkc(AZxh, abstractC1256i1.wA());
            s2.wA(wA, abstractC1256i1.AZxh());
            s2.mjFkc(ZfxDd, abstractC1256i1.ZfxDd());
            s2.wA(KLFTb, abstractC1256i1.JHa());
            s2.wA(JHa, abstractC1256i1.xJ());
            s2.mjFkc(xJ, abstractC1256i1.lgHUyS());
            s2.wA(lgHUyS, abstractC1256i1.KLFTb());
        }
    }

    public static final class mjFkc implements R2 {
        public static final mjFkc mjFkc = new mjFkc();
        public static final C0797aQ AZxh = C0797aQ.ZfxDd("sdkVersion");
        public static final C0797aQ wA = C0797aQ.ZfxDd("model");
        public static final C0797aQ ZfxDd = C0797aQ.ZfxDd("hardware");
        public static final C0797aQ KLFTb = C0797aQ.ZfxDd("device");
        public static final C0797aQ JHa = C0797aQ.ZfxDd("product");
        public static final C0797aQ xJ = C0797aQ.ZfxDd("osBuild");
        public static final C0797aQ lgHUyS = C0797aQ.ZfxDd("manufacturer");
        public static final C0797aQ qdMbNW = C0797aQ.ZfxDd("fingerprint");
        public static final C0797aQ Dt = C0797aQ.ZfxDd("locale");
        public static final C0797aQ ETF = C0797aQ.ZfxDd("country");
        public static final C0797aQ VA = C0797aQ.ZfxDd("mccMnc");
        public static final C0797aQ MiMN = C0797aQ.ZfxDd("applicationBuild");

        @Override // o.mYYU
        /* renamed from: AZxh, reason: merged with bridge method [inline-methods] */
        public void mjFkc(Vnb vnb, S2 s2) {
            s2.wA(AZxh, vnb.MiMN());
            s2.wA(wA, vnb.Dt());
            s2.wA(ZfxDd, vnb.JHa());
            s2.wA(KLFTb, vnb.ZfxDd());
            s2.wA(JHa, vnb.VA());
            s2.wA(xJ, vnb.ETF());
            s2.wA(lgHUyS, vnb.lgHUyS());
            s2.wA(qdMbNW, vnb.KLFTb());
            s2.wA(Dt, vnb.xJ());
            s2.wA(ETF, vnb.wA());
            s2.wA(VA, vnb.qdMbNW());
            s2.wA(MiMN, vnb.AZxh());
        }
    }

    public static final class wA implements R2 {
        public static final wA mjFkc = new wA();
        public static final C0797aQ AZxh = C0797aQ.ZfxDd("clientType");
        public static final C0797aQ wA = C0797aQ.ZfxDd("androidClientInfo");

        @Override // o.mYYU
        /* renamed from: AZxh, reason: merged with bridge method [inline-methods] */
        public void mjFkc(xbjHT xbjht, S2 s2) {
            s2.wA(AZxh, xbjht.wA());
            s2.wA(wA, xbjht.AZxh());
        }
    }

    @Override // o.ZGL
    public void mjFkc(jxC jxc) {
        AZxh aZxh = AZxh.mjFkc;
        jxc.mjFkc(NV.class, aZxh);
        jxc.mjFkc(lti.class, aZxh);
        KLFTb kLFTb = KLFTb.mjFkc;
        jxc.mjFkc(AbstractC1314j1.class, kLFTb);
        jxc.mjFkc(hvGY.class, kLFTb);
        wA wAVar = wA.mjFkc;
        jxc.mjFkc(xbjHT.class, wAVar);
        jxc.mjFkc(giT.class, wAVar);
        mjFkc mjfkc = mjFkc.mjFkc;
        jxc.mjFkc(Vnb.class, mjfkc);
        jxc.mjFkc(C1991uH.class, mjfkc);
        ZfxDd zfxDd = ZfxDd.mjFkc;
        jxc.mjFkc(AbstractC1256i1.class, zfxDd);
        jxc.mjFkc(fLidf.class, zfxDd);
        JHa jHa = JHa.mjFkc;
        jxc.mjFkc(H2.class, jHa);
        jxc.mjFkc(SKTn.class, jHa);
    }
}
