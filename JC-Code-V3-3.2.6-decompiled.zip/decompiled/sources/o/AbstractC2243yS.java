package o;

/* renamed from: o.yS, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC2243yS {
}
