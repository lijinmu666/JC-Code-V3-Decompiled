package o;

import java.util.Objects;

/* loaded from: classes.dex */
public abstract class V2 {
    public static int AZxh(Object... objArr) {
        return Objects.hash(objArr);
    }

    public static Object ZfxDd(Object obj, String str) {
        if (obj != null) {
            return obj;
        }
        throw new NullPointerException(str);
    }

    public static boolean mjFkc(Object obj, Object obj2) {
        return Objects.equals(obj, obj2);
    }

    public static Object wA(Object obj) {
        obj.getClass();
        return obj;
    }
}
