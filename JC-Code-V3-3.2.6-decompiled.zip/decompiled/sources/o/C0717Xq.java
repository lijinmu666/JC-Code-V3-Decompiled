package o;

/* renamed from: o.Xq, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0717Xq extends Vx implements Ly {
    public /* synthetic */ C0717Xq(AbstractC0694Wq abstractC0694Wq) {
        super(C0740Yq.zbb);
    }
}
