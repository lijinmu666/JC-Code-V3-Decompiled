package o;

/* renamed from: o.yb, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public interface InterfaceC2250yb {
    void AZxh(X8 x8, int i, boolean z);

    void mjFkc(X8 x8, int i);
}
