package o;

import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;

/* renamed from: o.Vc, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0657Vc extends AbstractC0448Mb implements IInterface {
    public C0657Vc(IBinder iBinder) {
        super(iBinder, "com.google.android.gms.common.moduleinstall.internal.IModuleInstallService");
    }

    public final void Ucbh(InterfaceC0542Qc interfaceC0542Qc, uHVRx uhvrx, InterfaceC1050ed interfaceC1050ed) {
        Parcel parcelZfxDd = ZfxDd();
        AbstractC2070vc.ZfxDd(parcelZfxDd, interfaceC0542Qc);
        AbstractC2070vc.wA(parcelZfxDd, uhvrx);
        AbstractC2070vc.ZfxDd(parcelZfxDd, interfaceC1050ed);
        KLFTb(2, parcelZfxDd);
    }
}
