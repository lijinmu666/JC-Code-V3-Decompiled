package o;

import android.view.accessibility.AccessibilityManager;

/* loaded from: classes.dex */
public abstract class rkYL {

    public static final class AZxh implements AccessibilityManager.TouchExplorationStateChangeListener {
        public final mjFkc mjFkc;

        public AZxh(mjFkc mjfkc) {
            this.mjFkc = mjfkc;
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (obj instanceof AZxh) {
                return this.mjFkc.equals(((AZxh) obj).mjFkc);
            }
            return false;
        }

        public int hashCode() {
            return this.mjFkc.hashCode();
        }

        @Override // android.view.accessibility.AccessibilityManager.TouchExplorationStateChangeListener
        public void onTouchExplorationStateChanged(boolean z) {
            this.mjFkc.onTouchExplorationStateChanged(z);
        }
    }

    public interface mjFkc {
        void onTouchExplorationStateChanged(boolean z);
    }

    public static boolean AZxh(AccessibilityManager accessibilityManager, mjFkc mjfkc) {
        return accessibilityManager.removeTouchExplorationStateChangeListener(new AZxh(mjfkc));
    }

    public static boolean mjFkc(AccessibilityManager accessibilityManager, mjFkc mjfkc) {
        return accessibilityManager.addTouchExplorationStateChangeListener(new AZxh(mjfkc));
    }
}
