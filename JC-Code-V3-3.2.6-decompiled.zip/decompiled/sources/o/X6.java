package o;

import android.content.Context;
import android.util.DisplayMetrics;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

/* loaded from: classes.dex */
public abstract class X6 extends LinearLayoutManager {

    public class mjFkc extends androidx.recyclerview.widget.xJ {
        public mjFkc(Context context) {
            super(context);
        }

        @Override // androidx.recyclerview.widget.xJ
        public float Ucbh(DisplayMetrics displayMetrics) {
            return 100.0f / displayMetrics.densityDpi;
        }
    }

    public X6(Context context, int i, boolean z) {
        super(context, i, z);
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, androidx.recyclerview.widget.RecyclerView.qGY
    public void qGgY(RecyclerView recyclerView, RecyclerView.VocHEe vocHEe, int i) {
        mjFkc mjfkc = new mjFkc(recyclerView.getContext());
        mjfkc.qGY(i);
        vUsV(mjfkc);
    }
}
