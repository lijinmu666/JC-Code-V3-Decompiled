package o;

import android.animation.TimeInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.LinearInterpolator;

/* loaded from: classes.dex */
public abstract class NPj {
    public static final TimeInterpolator mjFkc = new LinearInterpolator();
    public static final TimeInterpolator AZxh = new bXx();
    public static final TimeInterpolator wA = new MLqR();
    public static final TimeInterpolator ZfxDd = new X0();
    public static final TimeInterpolator KLFTb = new DecelerateInterpolator();

    public static float AZxh(float f, float f2, float f3, float f4, float f5) {
        return f5 <= f3 ? f : f5 >= f4 ? f2 : mjFkc(f, f2, (f5 - f3) / (f4 - f3));
    }

    public static float mjFkc(float f, float f2, float f3) {
        return f + (f3 * (f2 - f));
    }

    public static int wA(int i, int i2, float f) {
        return i + Math.round(f * (i2 - i));
    }
}
