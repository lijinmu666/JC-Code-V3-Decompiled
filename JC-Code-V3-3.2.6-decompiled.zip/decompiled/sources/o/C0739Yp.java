package o;

/* renamed from: o.Yp, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0739Yp extends Vx implements Ly {
    public /* synthetic */ C0739Yp(AbstractC0716Xp abstractC0716Xp) {
        super(C0762Zp.zbb);
    }
}
