package o;

import org.conscrypt.BuildConfig;

/* renamed from: o.jq, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C1363jq extends AbstractC1010dy implements Ly {
    private static final C1363jq zbb;
    private int zbd;
    private Object zbf;
    private int zbg;
    private long zbj;
    private int zbl;
    private int zbe = 0;
    private String zbh = BuildConfig.FLAVOR;
    private InterfaceC1491ly zbi = AbstractC1010dy.wJVbdd();
    private String zbk = BuildConfig.FLAVOR;

    static {
        C1363jq c1363jq = new C1363jq();
        zbb = c1363jq;
        AbstractC1010dy.YoKzxo(C1363jq.class, c1363jq);
    }

    @Override // o.AbstractC1010dy
    public final Object IEE(int i, Object obj, Object obj2) {
        int i2 = i - 1;
        if (i2 == 0) {
            return (byte) 1;
        }
        if (i2 == 2) {
            return AbstractC1010dy.ETF(zbb, "\u0001\u000b\u0001\u0001\u0001\u000b\u000b\u0000\u0001\u0000\u0001᠌\u0000\u0002ဈ\u0001\u0003\u001b\u0004ဈ\u0003\u0005<\u0000\u0006<\u0000\u0007<\u0000\b<\u0000\t<\u0000\nဂ\u0002\u000b᠌\u0004", new Object[]{"zbf", "zbe", "zbd", "zbg", C1423kq.mjFkc, "zbh", "zbi", C1303iq.class, "zbk", C0206Bm.class, C0571Ri.class, C1719pm.class, C0319Gk.class, C0528Pm.class, "zbj", "zbl", C0882bq.mjFkc});
        }
        if (i2 == 3) {
            return new C1363jq();
        }
        AbstractC0821aq abstractC0821aq = null;
        if (i2 == 4) {
            return new C1124fq(abstractC0821aq);
        }
        if (i2 != 5) {
            return null;
        }
        return zbb;
    }
}
