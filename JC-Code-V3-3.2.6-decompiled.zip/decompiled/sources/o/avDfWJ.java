package o;

import android.util.Base64;
import java.util.List;

/* loaded from: classes.dex */
public final class avDfWJ {
    public final String AZxh;
    public final String JHa;
    public final int KLFTb = 0;
    public final List ZfxDd;
    public final String mjFkc;
    public final String wA;

    public avDfWJ(String str, String str2, String str3, List list) {
        this.mjFkc = (String) K3.xJ(str);
        this.AZxh = (String) K3.xJ(str2);
        this.wA = (String) K3.xJ(str3);
        this.ZfxDd = (List) K3.xJ(list);
        this.JHa = mjFkc(str, str2, str3);
    }

    public List AZxh() {
        return this.ZfxDd;
    }

    public String JHa() {
        return this.AZxh;
    }

    public String KLFTb() {
        return this.mjFkc;
    }

    public String ZfxDd() {
        return this.JHa;
    }

    public final String mjFkc(String str, String str2, String str3) {
        return str + "-" + str2 + "-" + str3;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("FontRequest {mProviderAuthority: " + this.mjFkc + ", mProviderPackage: " + this.AZxh + ", mQuery: " + this.wA + ", mCertificates:");
        for (int i = 0; i < this.ZfxDd.size(); i++) {
            sb.append(" [");
            List list = (List) this.ZfxDd.get(i);
            for (int i2 = 0; i2 < list.size(); i2++) {
                sb.append(" \"");
                sb.append(Base64.encodeToString((byte[]) list.get(i2), 0));
                sb.append("\"");
            }
            sb.append(" ]");
        }
        sb.append("}");
        sb.append("mCertificatesArray: " + this.KLFTb);
        return sb.toString();
    }

    public int wA() {
        return this.KLFTb;
    }

    public String xJ() {
        return this.wA;
    }
}
