package o;

import java.util.NoSuchElementException;

/* renamed from: o.zW, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC2308zW extends NC {
    public int AZxh;
    public final int mjFkc;

    public AbstractC2308zW(int i, int i2) {
        AbstractC1645oV.AZxh(i2, i, "index");
        this.mjFkc = i;
        this.AZxh = i2;
    }

    public abstract Object AZxh(int i);

    @Override // java.util.Iterator, java.util.ListIterator
    public final boolean hasNext() {
        return this.AZxh < this.mjFkc;
    }

    @Override // java.util.ListIterator
    public final boolean hasPrevious() {
        return this.AZxh > 0;
    }

    @Override // java.util.Iterator, java.util.ListIterator
    public final Object next() {
        if (!hasNext()) {
            throw new NoSuchElementException();
        }
        int i = this.AZxh;
        this.AZxh = i + 1;
        return AZxh(i);
    }

    @Override // java.util.ListIterator
    public final int nextIndex() {
        return this.AZxh;
    }

    @Override // java.util.ListIterator
    public final Object previous() {
        if (!hasPrevious()) {
            throw new NoSuchElementException();
        }
        int i = this.AZxh - 1;
        this.AZxh = i;
        return AZxh(i);
    }

    @Override // java.util.ListIterator
    public final int previousIndex() {
        return this.AZxh - 1;
    }
}
