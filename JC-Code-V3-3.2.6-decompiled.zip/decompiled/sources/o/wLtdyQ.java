package o;

/* loaded from: classes.dex */
public interface wLtdyQ {
    int mjFkc();
}
