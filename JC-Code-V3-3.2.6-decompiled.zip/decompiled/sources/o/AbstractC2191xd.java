package o;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;

/* renamed from: o.xd, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC2191xd extends ofHOBL {
    public static Intent ZfxDd(Context context, BroadcastReceiver broadcastReceiver, IntentFilter intentFilter) {
        if (AbstractC1950td.mjFkc()) {
            return context.registerReceiver(broadcastReceiver, intentFilter, true != AbstractC1950td.mjFkc() ? 0 : 2);
        }
        return context.registerReceiver(broadcastReceiver, intentFilter);
    }
}
