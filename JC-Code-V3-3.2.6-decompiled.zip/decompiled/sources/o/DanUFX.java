package o;

import android.os.Bundle;
import android.view.View;
import androidx.fragment.app.Fragment;
import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArrayList;

/* loaded from: classes.dex */
public class DanUFX {
    public final androidx.fragment.app.KLFTb AZxh;
    public final CopyOnWriteArrayList mjFkc = new CopyOnWriteArrayList();

    public DanUFX(androidx.fragment.app.KLFTb kLFTb) {
        this.AZxh = kLFTb;
    }

    public void AZxh(Fragment fragment, boolean z) {
        this.AZxh.nxI();
        throw null;
    }

    public void Dt(Fragment fragment, boolean z) {
        Fragment fragmentXV = this.AZxh.XV();
        if (fragmentXV != null) {
            fragmentXV.vI().WGXroI().Dt(fragment, true);
        }
        Iterator it = this.mjFkc.iterator();
        if (it.hasNext()) {
            AbstractC2102w7.mjFkc(it.next());
            if (!z) {
                throw null;
            }
            throw null;
        }
    }

    public void ETF(Fragment fragment, View view, Bundle bundle, boolean z) {
        Fragment fragmentXV = this.AZxh.XV();
        if (fragmentXV != null) {
            fragmentXV.vI().WGXroI().ETF(fragment, view, bundle, true);
        }
        Iterator it = this.mjFkc.iterator();
        if (it.hasNext()) {
            AbstractC2102w7.mjFkc(it.next());
            if (!z) {
                throw null;
            }
            throw null;
        }
    }

    public void JHa(Fragment fragment, boolean z) {
        this.AZxh.nxI();
        throw null;
    }

    public void KLFTb(Fragment fragment, boolean z) {
        Fragment fragmentXV = this.AZxh.XV();
        if (fragmentXV != null) {
            fragmentXV.vI().WGXroI().KLFTb(fragment, true);
        }
        Iterator it = this.mjFkc.iterator();
        if (it.hasNext()) {
            AbstractC2102w7.mjFkc(it.next());
            if (!z) {
                throw null;
            }
            throw null;
        }
    }

    public void VA(Fragment fragment, boolean z) {
        Fragment fragmentXV = this.AZxh.XV();
        if (fragmentXV != null) {
            fragmentXV.vI().WGXroI().VA(fragment, true);
        }
        Iterator it = this.mjFkc.iterator();
        if (it.hasNext()) {
            AbstractC2102w7.mjFkc(it.next());
            if (!z) {
                throw null;
            }
            throw null;
        }
    }

    public void ZfxDd(Fragment fragment, boolean z) {
        Fragment fragmentXV = this.AZxh.XV();
        if (fragmentXV != null) {
            fragmentXV.vI().WGXroI().ZfxDd(fragment, true);
        }
        Iterator it = this.mjFkc.iterator();
        if (it.hasNext()) {
            AbstractC2102w7.mjFkc(it.next());
            if (!z) {
                throw null;
            }
            throw null;
        }
    }

    public void lgHUyS(Fragment fragment, boolean z) {
        Fragment fragmentXV = this.AZxh.XV();
        if (fragmentXV != null) {
            fragmentXV.vI().WGXroI().lgHUyS(fragment, true);
        }
        Iterator it = this.mjFkc.iterator();
        if (it.hasNext()) {
            AbstractC2102w7.mjFkc(it.next());
            if (!z) {
                throw null;
            }
            throw null;
        }
    }

    public void mjFkc(Fragment fragment, Bundle bundle, boolean z) {
        Fragment fragmentXV = this.AZxh.XV();
        if (fragmentXV != null) {
            fragmentXV.vI().WGXroI().mjFkc(fragment, bundle, true);
        }
        Iterator it = this.mjFkc.iterator();
        if (it.hasNext()) {
            AbstractC2102w7.mjFkc(it.next());
            if (!z) {
                throw null;
            }
            throw null;
        }
    }

    public void qdMbNW(Fragment fragment, boolean z) {
        Fragment fragmentXV = this.AZxh.XV();
        if (fragmentXV != null) {
            fragmentXV.vI().WGXroI().qdMbNW(fragment, true);
        }
        Iterator it = this.mjFkc.iterator();
        if (it.hasNext()) {
            AbstractC2102w7.mjFkc(it.next());
            if (!z) {
                throw null;
            }
            throw null;
        }
    }

    public void wA(Fragment fragment, Bundle bundle, boolean z) {
        Fragment fragmentXV = this.AZxh.XV();
        if (fragmentXV != null) {
            fragmentXV.vI().WGXroI().wA(fragment, bundle, true);
        }
        Iterator it = this.mjFkc.iterator();
        if (it.hasNext()) {
            AbstractC2102w7.mjFkc(it.next());
            if (!z) {
                throw null;
            }
            throw null;
        }
    }

    public void xJ(Fragment fragment, Bundle bundle, boolean z) {
        Fragment fragmentXV = this.AZxh.XV();
        if (fragmentXV != null) {
            fragmentXV.vI().WGXroI().xJ(fragment, bundle, true);
        }
        Iterator it = this.mjFkc.iterator();
        if (it.hasNext()) {
            AbstractC2102w7.mjFkc(it.next());
            if (!z) {
                throw null;
            }
            throw null;
        }
    }
}
