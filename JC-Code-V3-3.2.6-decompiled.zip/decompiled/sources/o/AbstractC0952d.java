package o;

import android.accounts.Account;
import android.app.Activity;
import android.content.Context;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import com.google.android.gms.common.api.GoogleApiActivity;
import java.util.Collections;
import o.aqHPIZ;
import o.zPp;

/* renamed from: o.d, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC0952d {
    public final String AZxh;
    public final C1194h Dt;
    public final Looper JHa;
    public final JYn KLFTb;
    public final aqHPIZ.ZfxDd ZfxDd;
    public final AbstractC1134g lgHUyS;
    public final Context mjFkc;
    public final InterfaceC1441l7 qdMbNW;
    public final aqHPIZ wA;
    public final int xJ;

    /* renamed from: o.d$mjFkc */
    public static class mjFkc {
        public static final mjFkc wA = new C0051mjFkc().mjFkc();
        public final Looper AZxh;
        public final InterfaceC1441l7 mjFkc;

        /* renamed from: o.d$mjFkc$mjFkc, reason: collision with other inner class name */
        public static class C0051mjFkc {
            public Looper AZxh;
            public InterfaceC1441l7 mjFkc;

            /* JADX WARN: Multi-variable type inference failed */
            public mjFkc mjFkc() {
                if (this.mjFkc == null) {
                    this.mjFkc = new KRTLGT();
                }
                if (this.AZxh == null) {
                    this.AZxh = Looper.getMainLooper();
                }
                return new mjFkc(this.mjFkc, this.AZxh);
            }
        }

        public mjFkc(InterfaceC1441l7 interfaceC1441l7, Account account, Looper looper) {
            this.mjFkc = interfaceC1441l7;
            this.AZxh = looper;
        }
    }

    public AbstractC0952d(Context context, Activity activity, aqHPIZ aqhpiz, aqHPIZ.ZfxDd zfxDd, mjFkc mjfkc) {
        I3.lgHUyS(context, "Null context is not permitted.");
        I3.lgHUyS(aqhpiz, "Api must not be null.");
        I3.lgHUyS(mjfkc, "Settings must not be null; use Settings.DEFAULT_SETTINGS instead.");
        Context context2 = (Context) I3.lgHUyS(context.getApplicationContext(), "The provided context did not have an application context.");
        this.mjFkc = context2;
        String attributionTag = Build.VERSION.SDK_INT >= 30 ? context.getAttributionTag() : JHa(context);
        this.AZxh = attributionTag;
        this.wA = aqhpiz;
        this.ZfxDd = zfxDd;
        this.JHa = mjfkc.AZxh;
        JYn jYnMjFkc = JYn.mjFkc(aqhpiz, zfxDd, attributionTag);
        this.KLFTb = jYnMjFkc;
        this.lgHUyS = new C1709pc(this);
        C1194h c1194hDiqgf = C1194h.diqgf(context2);
        this.Dt = c1194hDiqgf;
        this.xJ = c1194hDiqgf.ETF();
        this.qdMbNW = mjfkc.mjFkc;
        if (activity != null && !(activity instanceof GoogleApiActivity) && Looper.myLooper() == Looper.getMainLooper()) {
            C0656Vb.eyqo(activity, c1194hDiqgf, jYnMjFkc);
        }
        c1194hDiqgf.wJVbdd(this);
    }

    /* JADX WARN: Multi-variable type inference failed */
    public final aqHPIZ.JHa Dt(Looper looper, C1409kc c1409kc) {
        zPp zppMjFkc = wA().mjFkc();
        aqHPIZ.JHa jHaAZxh = ((aqHPIZ.mjFkc) I3.xJ(this.wA.mjFkc())).AZxh(this.mjFkc, looper, zppMjFkc, this.ZfxDd, c1409kc, c1409kc);
        String strLgHUyS = lgHUyS();
        if (strLgHUyS != null && (jHaAZxh instanceof KRckQg)) {
            ((KRckQg) jHaAZxh).NPj(strLgHUyS);
        }
        if (strLgHUyS == null || !(jHaAZxh instanceof J2)) {
            return jHaAZxh;
        }
        AbstractC2102w7.mjFkc(jHaAZxh);
        throw null;
    }

    public final BinderC0311Gc ETF(Context context, Handler handler) {
        return new BinderC0311Gc(context, handler, wA().mjFkc());
    }

    public String JHa(Context context) {
        return null;
    }

    public B7 KLFTb(C7 c7) {
        return VA(0, c7);
    }

    public final B7 VA(int i, C7 c7) {
        D7 d7 = new D7();
        this.Dt.vI(this, i, c7, d7, this.qdMbNW);
        return d7.mjFkc();
    }

    public B7 ZfxDd(C7 c7) {
        return VA(2, c7);
    }

    public String lgHUyS() {
        return this.AZxh;
    }

    public final int qdMbNW() {
        return this.xJ;
    }

    public zPp.mjFkc wA() {
        zPp.mjFkc mjfkc = new zPp.mjFkc();
        mjfkc.ZfxDd(null);
        mjfkc.wA(Collections.emptySet());
        mjfkc.KLFTb(this.mjFkc.getClass().getName());
        mjfkc.AZxh(this.mjFkc.getPackageName());
        return mjfkc;
    }

    public final JYn xJ() {
        return this.KLFTb;
    }

    public AbstractC0952d(Context context, aqHPIZ aqhpiz, aqHPIZ.ZfxDd zfxDd, mjFkc mjfkc) {
        this(context, null, aqhpiz, zfxDd, mjfkc);
    }
}
