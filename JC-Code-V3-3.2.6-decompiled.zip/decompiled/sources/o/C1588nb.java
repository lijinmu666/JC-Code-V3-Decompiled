package o;

import android.os.Build;
import android.view.View;
import android.view.Window;
import android.view.WindowInsetsController;

/* renamed from: o.nb, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C1588nb {
    public final KLFTb mjFkc;

    /* renamed from: o.nb$AZxh */
    public static class AZxh extends mjFkc {
        public AZxh(Window window, Y6 y6) {
            super(window, y6);
        }

        @Override // o.C1588nb.KLFTb
        public void AZxh(boolean z) {
            if (!z) {
                KLFTb(8192);
                return;
            }
            JHa(67108864);
            ZfxDd(Integer.MIN_VALUE);
            wA(8192);
        }
    }

    /* renamed from: o.nb$KLFTb */
    public static class KLFTb {
        public abstract void AZxh(boolean z);

        public abstract void mjFkc(boolean z);
    }

    /* renamed from: o.nb$mjFkc */
    public static class mjFkc extends KLFTb {
        public final Y6 AZxh;
        public final Window mjFkc;

        public mjFkc(Window window, Y6 y6) {
            this.mjFkc = window;
            this.AZxh = y6;
        }

        public void JHa(int i) {
            this.mjFkc.clearFlags(i);
        }

        public void KLFTb(int i) {
            View decorView = this.mjFkc.getDecorView();
            decorView.setSystemUiVisibility((~i) & decorView.getSystemUiVisibility());
        }

        public void ZfxDd(int i) {
            this.mjFkc.addFlags(i);
        }

        public void wA(int i) {
            View decorView = this.mjFkc.getDecorView();
            decorView.setSystemUiVisibility(i | decorView.getSystemUiVisibility());
        }
    }

    /* renamed from: o.nb$wA */
    public static class wA extends AZxh {
        public wA(Window window, Y6 y6) {
            super(window, y6);
        }

        @Override // o.C1588nb.KLFTb
        public void mjFkc(boolean z) {
            if (!z) {
                KLFTb(16);
                return;
            }
            JHa(134217728);
            ZfxDd(Integer.MIN_VALUE);
            wA(16);
        }
    }

    public C1588nb(Window window, View view) {
        Y6 y6 = new Y6(view);
        if (Build.VERSION.SDK_INT >= 30) {
            this.mjFkc = new ZfxDd(window, this, y6);
        } else {
            this.mjFkc = new wA(window, y6);
        }
    }

    public void AZxh(boolean z) {
        this.mjFkc.AZxh(z);
    }

    public void mjFkc(boolean z) {
        this.mjFkc.mjFkc(z);
    }

    /* renamed from: o.nb$ZfxDd */
    public static class ZfxDd extends KLFTb {
        public final WindowInsetsController AZxh;
        public Window KLFTb;
        public final W6 ZfxDd;
        public final C1588nb mjFkc;
        public final Y6 wA;

        public ZfxDd(Window window, C1588nb c1588nb, Y6 y6) {
            this(window.getInsetsController(), c1588nb, y6);
            this.KLFTb = window;
        }

        @Override // o.C1588nb.KLFTb
        public void AZxh(boolean z) {
            if (z) {
                if (this.KLFTb != null) {
                    wA(8192);
                }
                this.AZxh.setSystemBarsAppearance(8, 8);
            } else {
                if (this.KLFTb != null) {
                    ZfxDd(8192);
                }
                this.AZxh.setSystemBarsAppearance(0, 8);
            }
        }

        public void ZfxDd(int i) {
            View decorView = this.KLFTb.getDecorView();
            decorView.setSystemUiVisibility((~i) & decorView.getSystemUiVisibility());
        }

        @Override // o.C1588nb.KLFTb
        public void mjFkc(boolean z) {
            if (z) {
                if (this.KLFTb != null) {
                    wA(16);
                }
                this.AZxh.setSystemBarsAppearance(16, 16);
            } else {
                if (this.KLFTb != null) {
                    ZfxDd(16);
                }
                this.AZxh.setSystemBarsAppearance(0, 16);
            }
        }

        public void wA(int i) {
            View decorView = this.KLFTb.getDecorView();
            decorView.setSystemUiVisibility(i | decorView.getSystemUiVisibility());
        }

        public ZfxDd(WindowInsetsController windowInsetsController, C1588nb c1588nb, Y6 y6) {
            this.ZfxDd = new W6();
            this.AZxh = windowInsetsController;
            this.mjFkc = c1588nb;
            this.wA = y6;
        }
    }
}
