package o;

import o.C6;
import org.conscrypt.BuildConfig;

/* loaded from: classes.dex */
public final class FbxKQm extends C6 {
    public final String AZxh;
    public final dXmy KLFTb;
    public final M8 ZfxDd;
    public final X8 mjFkc;
    public final uhQ wA;

    public static final class AZxh extends C6.mjFkc {
        public String AZxh;
        public dXmy KLFTb;
        public M8 ZfxDd;
        public X8 mjFkc;
        public uhQ wA;

        @Override // o.C6.mjFkc
        public C6.mjFkc AZxh(dXmy dxmy) {
            if (dxmy == null) {
                throw new NullPointerException("Null encoding");
            }
            this.KLFTb = dxmy;
            return this;
        }

        @Override // o.C6.mjFkc
        public C6.mjFkc JHa(String str) {
            if (str == null) {
                throw new NullPointerException("Null transportName");
            }
            this.AZxh = str;
            return this;
        }

        @Override // o.C6.mjFkc
        public C6.mjFkc KLFTb(X8 x8) {
            if (x8 == null) {
                throw new NullPointerException("Null transportContext");
            }
            this.mjFkc = x8;
            return this;
        }

        @Override // o.C6.mjFkc
        public C6.mjFkc ZfxDd(M8 m8) {
            if (m8 == null) {
                throw new NullPointerException("Null transformer");
            }
            this.ZfxDd = m8;
            return this;
        }

        @Override // o.C6.mjFkc
        public C6 mjFkc() {
            X8 x8 = this.mjFkc;
            String str = BuildConfig.FLAVOR;
            if (x8 == null) {
                str = BuildConfig.FLAVOR + " transportContext";
            }
            if (this.AZxh == null) {
                str = str + " transportName";
            }
            if (this.wA == null) {
                str = str + " event";
            }
            if (this.ZfxDd == null) {
                str = str + " transformer";
            }
            if (this.KLFTb == null) {
                str = str + " encoding";
            }
            if (str.isEmpty()) {
                return new FbxKQm(this.mjFkc, this.AZxh, this.wA, this.ZfxDd, this.KLFTb);
            }
            throw new IllegalStateException("Missing required properties:" + str);
        }

        @Override // o.C6.mjFkc
        public C6.mjFkc wA(uhQ uhq) {
            if (uhq == null) {
                throw new NullPointerException("Null event");
            }
            this.wA = uhq;
            return this;
        }
    }

    @Override // o.C6
    public dXmy AZxh() {
        return this.KLFTb;
    }

    @Override // o.C6
    public X8 JHa() {
        return this.mjFkc;
    }

    @Override // o.C6
    public M8 KLFTb() {
        return this.ZfxDd;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof C6)) {
            return false;
        }
        C6 c6 = (C6) obj;
        return this.mjFkc.equals(c6.JHa()) && this.AZxh.equals(c6.xJ()) && this.wA.equals(c6.wA()) && this.ZfxDd.equals(c6.KLFTb()) && this.KLFTb.equals(c6.AZxh());
    }

    public int hashCode() {
        return this.KLFTb.hashCode() ^ ((((((((this.mjFkc.hashCode() ^ 1000003) * 1000003) ^ this.AZxh.hashCode()) * 1000003) ^ this.wA.hashCode()) * 1000003) ^ this.ZfxDd.hashCode()) * 1000003);
    }

    public String toString() {
        return "SendRequest{transportContext=" + this.mjFkc + ", transportName=" + this.AZxh + ", event=" + this.wA + ", transformer=" + this.ZfxDd + ", encoding=" + this.KLFTb + "}";
    }

    @Override // o.C6
    public uhQ wA() {
        return this.wA;
    }

    @Override // o.C6
    public String xJ() {
        return this.AZxh;
    }

    public FbxKQm(X8 x8, String str, uhQ uhq, M8 m8, dXmy dxmy) {
        this.mjFkc = x8;
        this.AZxh = str;
        this.wA = uhq;
        this.ZfxDd = m8;
        this.KLFTb = dxmy;
    }
}
