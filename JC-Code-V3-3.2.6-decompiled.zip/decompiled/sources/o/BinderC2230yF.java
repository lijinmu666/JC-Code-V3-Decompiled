package o;

import android.os.Bundle;
import android.os.IBinder;
import android.util.Log;

/* renamed from: o.yF, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class BinderC2230yF extends JB {
    public final int AZxh;
    public KRckQg mjFkc;

    public BinderC2230yF(KRckQg kRckQg, int i) {
        this.mjFkc = kRckQg;
        this.AZxh = i;
    }

    @Override // o.C
    public final void YoKzxo(int i, IBinder iBinder, EN en) {
        KRckQg kRckQg = this.mjFkc;
        I3.lgHUyS(kRckQg, "onPostInitCompleteWithConnectionInfo can be called only once per call togetRemoteService");
        I3.xJ(en);
        KRckQg.WGXroI(kRckQg, en);
        eyqo(i, iBinder, en.mjFkc);
    }

    @Override // o.C
    public final void eyqo(int i, IBinder iBinder, Bundle bundle) {
        I3.lgHUyS(this.mjFkc, "onPostInitComplete can be called only once per call to getRemoteService");
        this.mjFkc.rWxwaT(i, iBinder, bundle, this.AZxh);
        this.mjFkc = null;
    }

    @Override // o.C
    public final void qGY(int i, Bundle bundle) {
        Log.wtf("GmsClient", "received deprecated onAccountValidationComplete callback, ignoring", new Exception());
    }
}
