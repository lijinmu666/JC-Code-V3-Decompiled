package o;

/* loaded from: classes.dex */
public final class Kz extends AbstractC1010dy implements Ly {
    private static final Kz zbb;
    private int zbd;
    private int zbe = -1;

    static {
        Kz kz = new Kz();
        zbb = kz;
        AbstractC1010dy.YoKzxo(Kz.class, kz);
    }

    @Override // o.AbstractC1010dy
    public final Object IEE(int i, Object obj, Object obj2) {
        int i2 = i - 1;
        if (i2 == 0) {
            return (byte) 1;
        }
        if (i2 == 2) {
            return AbstractC1010dy.ETF(zbb, "\u0001\u0001\u0000\u0001\u0001\u0001\u0001\u0000\u0000\u0000\u0001င\u0000", new Object[]{"zbd", "zbe"});
        }
        if (i2 == 3) {
            return new Kz();
        }
        AbstractC2274yz abstractC2274yz = null;
        if (i2 == 4) {
            return new Jz(abstractC2274yz);
        }
        if (i2 != 5) {
            return null;
        }
        return zbb;
    }
}
