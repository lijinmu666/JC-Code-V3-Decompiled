package o;

import java.io.IOException;

/* loaded from: classes.dex */
public final class OF implements I9 {
    public final C2110wF ZfxDd;
    public C0797aQ wA;
    public boolean mjFkc = false;
    public boolean AZxh = false;

    public OF(C2110wF c2110wF) {
        this.ZfxDd = c2110wF;
    }

    private final void wA() {
        if (this.mjFkc) {
            throw new ORe("Cannot encode a second value in the ValueEncoderContext");
        }
        this.mjFkc = true;
    }

    @Override // o.I9
    public final I9 AZxh(boolean z) throws IOException {
        wA();
        this.ZfxDd.JHa(this.wA, z ? 1 : 0, this.AZxh);
        return this;
    }

    @Override // o.I9
    public final I9 add(String str) throws IOException {
        wA();
        this.ZfxDd.KLFTb(this.wA, str, this.AZxh);
        return this;
    }

    public final void mjFkc(C0797aQ c0797aQ, boolean z) {
        this.mjFkc = false;
        this.wA = c0797aQ;
        this.AZxh = z;
    }
}
