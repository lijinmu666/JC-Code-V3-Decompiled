package o;

/* renamed from: o.lp, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C1482lp extends Vx implements Ly {
    public /* synthetic */ C1482lp(AbstractC1362jp abstractC1362jp) {
        super(C1662op.zbb);
    }
}
