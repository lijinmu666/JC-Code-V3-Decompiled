package o;

/* renamed from: o.Mo, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0461Mo extends Vx implements Ly {
    public /* synthetic */ C0461Mo(AbstractC0416Ko abstractC0416Ko) {
        super(C0554Qo.zbb);
    }
}
