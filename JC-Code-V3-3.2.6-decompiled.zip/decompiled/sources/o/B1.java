package o;

import android.content.Context;
import android.os.Build;
import android.security.keystore.KeyGenParameterSpec;
import java.io.IOException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;

/* loaded from: classes.dex */
public final class B1 {
    public final KeyGenParameterSpec AZxh;
    public final String mjFkc;

    public static final class AZxh {
        public KeyGenParameterSpec AZxh;
        public boolean JHa;
        public int KLFTb;
        public boolean ZfxDd;
        public final String mjFkc;
        public wA wA;
        public final Context xJ;

        public static class mjFkc {

            /* renamed from: o.B1$AZxh$mjFkc$AZxh, reason: collision with other inner class name */
            public static class C0044AZxh {
                public static void mjFkc(KeyGenParameterSpec.Builder builder, int i, int i2) {
                    builder.setUserAuthenticationParameters(i, i2);
                }
            }

            /* renamed from: o.B1$AZxh$mjFkc$mjFkc, reason: collision with other inner class name */
            public static class C0045mjFkc {
                public static void mjFkc(KeyGenParameterSpec.Builder builder) {
                    builder.setIsStrongBoxBacked(true);
                }
            }

            public static String AZxh(KeyGenParameterSpec keyGenParameterSpec) {
                return keyGenParameterSpec.getKeystoreAlias();
            }

            public static B1 mjFkc(AZxh aZxh) {
                wA wAVar = aZxh.wA;
                if (wAVar == null && aZxh.AZxh == null) {
                    throw new IllegalArgumentException("build() called before setKeyGenParameterSpec or setKeyScheme.");
                }
                if (wAVar == wA.AES256_GCM) {
                    KeyGenParameterSpec.Builder keySize = new KeyGenParameterSpec.Builder(aZxh.mjFkc, 3).setBlockModes("GCM").setEncryptionPaddings("NoPadding").setKeySize(256);
                    if (aZxh.ZfxDd) {
                        keySize.setUserAuthenticationRequired(true);
                        if (Build.VERSION.SDK_INT >= 30) {
                            C0044AZxh.mjFkc(keySize, aZxh.KLFTb, 3);
                        } else {
                            keySize.setUserAuthenticationValidityDurationSeconds(aZxh.KLFTb);
                        }
                    }
                    if (aZxh.JHa && aZxh.xJ.getPackageManager().hasSystemFeature("android.hardware.strongbox_keystore")) {
                        C0045mjFkc.mjFkc(keySize);
                    }
                    aZxh.AZxh = keySize.build();
                }
                KeyGenParameterSpec keyGenParameterSpec = aZxh.AZxh;
                if (keyGenParameterSpec != null) {
                    return new B1(D1.wA(keyGenParameterSpec), aZxh.AZxh);
                }
                throw new NullPointerException("KeyGenParameterSpec was null after build() check");
            }
        }

        public AZxh(Context context) {
            this(context, "_androidx_security_master_key_");
        }

        public AZxh AZxh(wA wAVar) {
            if (mjFkc.mjFkc[wAVar.ordinal()] == 1) {
                if (this.AZxh != null) {
                    throw new IllegalArgumentException("KeyScheme set after setting a KeyGenParamSpec");
                }
                this.wA = wAVar;
                return this;
            }
            throw new IllegalArgumentException("Unsupported scheme: " + wAVar);
        }

        public B1 mjFkc() {
            return mjFkc.mjFkc(this);
        }

        public AZxh wA(boolean z) {
            this.JHa = z;
            return this;
        }

        public AZxh(Context context, String str) {
            this.xJ = context.getApplicationContext();
            this.mjFkc = str;
        }
    }

    public static /* synthetic */ class mjFkc {
        public static final /* synthetic */ int[] mjFkc;

        static {
            int[] iArr = new int[wA.values().length];
            mjFkc = iArr;
            try {
                iArr[wA.AES256_GCM.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
        }
    }

    public enum wA {
        AES256_GCM
    }

    public B1(String str, Object obj) {
        this.mjFkc = str;
        this.AZxh = (KeyGenParameterSpec) obj;
    }

    public boolean AZxh() throws NoSuchAlgorithmException, IOException, KeyStoreException, CertificateException {
        try {
            KeyStore keyStore = KeyStore.getInstance("AndroidKeyStore");
            keyStore.load(null);
            return keyStore.containsAlias(this.mjFkc);
        } catch (IOException | KeyStoreException | NoSuchAlgorithmException | CertificateException unused) {
            return false;
        }
    }

    public String mjFkc() {
        return this.mjFkc;
    }

    public String toString() {
        return "MasterKey{keyAlias=" + this.mjFkc + ", isKeyStoreBacked=" + AZxh() + "}";
    }
}
