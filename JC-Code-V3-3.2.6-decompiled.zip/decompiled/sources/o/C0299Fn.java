package o;

/* renamed from: o.Fn, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0299Fn extends Vx implements Ly {
    public /* synthetic */ C0299Fn(AbstractC0253Dn abstractC0253Dn) {
        super(C0345Hn.zbb);
    }
}
