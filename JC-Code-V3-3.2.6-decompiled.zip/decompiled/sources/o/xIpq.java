package o;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

/* loaded from: classes.dex */
public final class xIpq {
    public final A3 mjFkc = new C3(10);
    public final W6 AZxh = new W6();
    public final ArrayList wA = new ArrayList();
    public final HashSet ZfxDd = new HashSet();

    public void AZxh(Object obj) {
        if (this.AZxh.containsKey(obj)) {
            return;
        }
        this.AZxh.put(obj, null);
    }

    public final void Dt(ArrayList arrayList) {
        arrayList.clear();
        this.mjFkc.mjFkc(arrayList);
    }

    public final ArrayList JHa() {
        ArrayList arrayList = (ArrayList) this.mjFkc.AZxh();
        return arrayList == null ? new ArrayList() : arrayList;
    }

    public final void KLFTb(Object obj, ArrayList arrayList, HashSet hashSet) {
        if (arrayList.contains(obj)) {
            return;
        }
        if (hashSet.contains(obj)) {
            throw new RuntimeException("This graph contains cyclic dependencies");
        }
        hashSet.add(obj);
        ArrayList arrayList2 = (ArrayList) this.AZxh.get(obj);
        if (arrayList2 != null) {
            int size = arrayList2.size();
            for (int i = 0; i < size; i++) {
                KLFTb(arrayList2.get(i), arrayList, hashSet);
            }
        }
        hashSet.remove(obj);
        arrayList.add(obj);
    }

    public boolean ZfxDd(Object obj) {
        return this.AZxh.containsKey(obj);
    }

    public ArrayList lgHUyS() {
        this.wA.clear();
        this.ZfxDd.clear();
        int size = this.AZxh.size();
        for (int i = 0; i < size; i++) {
            KLFTb(this.AZxh.qdMbNW(i), this.wA, this.ZfxDd);
        }
        return this.wA;
    }

    public void mjFkc(Object obj, Object obj2) {
        if (!this.AZxh.containsKey(obj) || !this.AZxh.containsKey(obj2)) {
            throw new IllegalArgumentException("All nodes must be present in the graph before being added as an edge");
        }
        ArrayList arrayListJHa = (ArrayList) this.AZxh.get(obj);
        if (arrayListJHa == null) {
            arrayListJHa = JHa();
            this.AZxh.put(obj, arrayListJHa);
        }
        arrayListJHa.add(obj2);
    }

    public boolean qdMbNW(Object obj) {
        int size = this.AZxh.size();
        for (int i = 0; i < size; i++) {
            ArrayList arrayList = (ArrayList) this.AZxh.MiMN(i);
            if (arrayList != null && arrayList.contains(obj)) {
                return true;
            }
        }
        return false;
    }

    public void wA() {
        int size = this.AZxh.size();
        for (int i = 0; i < size; i++) {
            ArrayList arrayList = (ArrayList) this.AZxh.MiMN(i);
            if (arrayList != null) {
                Dt(arrayList);
            }
        }
        this.AZxh.clear();
    }

    public List xJ(Object obj) {
        int size = this.AZxh.size();
        ArrayList arrayList = null;
        for (int i = 0; i < size; i++) {
            ArrayList arrayList2 = (ArrayList) this.AZxh.MiMN(i);
            if (arrayList2 != null && arrayList2.contains(obj)) {
                if (arrayList == null) {
                    arrayList = new ArrayList();
                }
                arrayList.add(this.AZxh.qdMbNW(i));
            }
        }
        return arrayList;
    }
}
