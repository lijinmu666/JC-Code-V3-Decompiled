package o;

/* loaded from: classes.dex */
public class Ule implements MC {
    public static final Ule mjFkc = new Ule();

    public static MC mjFkc() {
        return mjFkc;
    }
}
