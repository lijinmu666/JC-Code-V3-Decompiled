package o;

import android.text.PrecomputedText;
import android.text.Spannable;
import android.text.SpannableString;
import java.util.stream.IntStream;

/* renamed from: o.t9, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public class C1923t9 implements Spannable {
    public Spannable AZxh;
    public boolean mjFkc = false;

    /* renamed from: o.t9$AZxh */
    public static class AZxh {
        public abstract boolean mjFkc(CharSequence charSequence);
    }

    /* renamed from: o.t9$mjFkc */
    public static class mjFkc {
        public static IntStream AZxh(CharSequence charSequence) {
            return charSequence.codePoints();
        }

        public static IntStream mjFkc(CharSequence charSequence) {
            return charSequence.chars();
        }
    }

    /* renamed from: o.t9$wA */
    public static class wA extends AZxh {
        @Override // o.C1923t9.AZxh
        public boolean mjFkc(CharSequence charSequence) {
            return charSequence instanceof PrecomputedText;
        }
    }

    public C1923t9(Spannable spannable) {
        this.AZxh = spannable;
    }

    public static AZxh wA() {
        return new wA();
    }

    public Spannable AZxh() {
        return this.AZxh;
    }

    @Override // java.lang.CharSequence
    public char charAt(int i) {
        return this.AZxh.charAt(i);
    }

    @Override // java.lang.CharSequence
    public IntStream chars() {
        return mjFkc.mjFkc(this.AZxh);
    }

    @Override // java.lang.CharSequence
    public IntStream codePoints() {
        return mjFkc.AZxh(this.AZxh);
    }

    @Override // android.text.Spanned
    public int getSpanEnd(Object obj) {
        return this.AZxh.getSpanEnd(obj);
    }

    @Override // android.text.Spanned
    public int getSpanFlags(Object obj) {
        return this.AZxh.getSpanFlags(obj);
    }

    @Override // android.text.Spanned
    public int getSpanStart(Object obj) {
        return this.AZxh.getSpanStart(obj);
    }

    @Override // android.text.Spanned
    public Object[] getSpans(int i, int i2, Class cls) {
        return this.AZxh.getSpans(i, i2, cls);
    }

    @Override // java.lang.CharSequence
    public int length() {
        return this.AZxh.length();
    }

    public final void mjFkc() {
        Spannable spannable = this.AZxh;
        if (!this.mjFkc && wA().mjFkc(spannable)) {
            this.AZxh = new SpannableString(spannable);
        }
        this.mjFkc = true;
    }

    @Override // android.text.Spanned
    public int nextSpanTransition(int i, int i2, Class cls) {
        return this.AZxh.nextSpanTransition(i, i2, cls);
    }

    @Override // android.text.Spannable
    public void removeSpan(Object obj) {
        mjFkc();
        this.AZxh.removeSpan(obj);
    }

    @Override // android.text.Spannable
    public void setSpan(Object obj, int i, int i2, int i3) {
        mjFkc();
        this.AZxh.setSpan(obj, i, i2, i3);
    }

    @Override // java.lang.CharSequence
    public CharSequence subSequence(int i, int i2) {
        return this.AZxh.subSequence(i, i2);
    }

    @Override // java.lang.CharSequence
    public String toString() {
        return this.AZxh.toString();
    }

    public C1923t9(CharSequence charSequence) {
        this.AZxh = new SpannableString(charSequence);
    }
}
