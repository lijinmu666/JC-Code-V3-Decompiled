package o;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.LocaleList;
import android.text.method.PasswordTransformationMethod;
import android.util.AttributeSet;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.TextView;
import java.lang.ref.WeakReference;
import java.util.Locale;
import o.AbstractC1919t5;

/* loaded from: classes.dex */
public class IVlxe {
    public C2223y8 AZxh;
    public int Dt = 0;
    public int ETF = -1;
    public C2223y8 JHa;
    public C2223y8 KLFTb;
    public boolean MiMN;
    public Typeface VA;
    public C2223y8 ZfxDd;
    public C2223y8 lgHUyS;
    public final TextView mjFkc;
    public final SmIWf qdMbNW;
    public C2223y8 wA;
    public C2223y8 xJ;

    public class AZxh implements Runnable {
        public final /* synthetic */ Typeface AZxh;
        public final /* synthetic */ TextView mjFkc;
        public final /* synthetic */ int wA;

        public AZxh(TextView textView, Typeface typeface, int i) {
            this.mjFkc = textView;
            this.AZxh = typeface;
            this.wA = i;
        }

        @Override // java.lang.Runnable
        public void run() {
            this.mjFkc.setTypeface(this.AZxh, this.wA);
        }
    }

    public static class JHa {
        public static Typeface mjFkc(Typeface typeface, int i, boolean z) {
            return Typeface.create(typeface, i, z);
        }
    }

    public static class KLFTb {
        public static void AZxh(TextView textView, int i, int i2, int i3, int i4) {
            textView.setAutoSizeTextTypeUniformWithConfiguration(i, i2, i3, i4);
        }

        public static boolean ZfxDd(TextView textView, String str) {
            return textView.setFontVariationSettings(str);
        }

        public static int mjFkc(TextView textView) {
            return textView.getAutoSizeStepGranularity();
        }

        public static void wA(TextView textView, int[] iArr, int i) {
            textView.setAutoSizeTextTypeUniformWithPresetSizes(iArr, i);
        }
    }

    public static class ZfxDd {
        public static void AZxh(TextView textView, LocaleList localeList) {
            textView.setTextLocales(localeList);
        }

        public static LocaleList mjFkc(String str) {
            return LocaleList.forLanguageTags(str);
        }
    }

    public class mjFkc extends AbstractC1919t5.KLFTb {
        public final /* synthetic */ int AZxh;
        public final /* synthetic */ int mjFkc;
        public final /* synthetic */ WeakReference wA;

        public mjFkc(int i, int i2, WeakReference weakReference) {
            this.mjFkc = i;
            this.AZxh = i2;
            this.wA = weakReference;
        }

        @Override // o.AbstractC1919t5.KLFTb
        /* renamed from: lgHUyS */
        public void JHa(int i) {
        }

        @Override // o.AbstractC1919t5.KLFTb
        /* renamed from: qdMbNW */
        public void xJ(Typeface typeface) {
            int i = this.mjFkc;
            if (i != -1) {
                typeface = JHa.mjFkc(typeface, i, (this.AZxh & 2) != 0);
            }
            IVlxe.this.YoKzxo(this.wA, typeface);
        }
    }

    public static class wA {
        public static void AZxh(TextView textView, Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
            textView.setCompoundDrawablesRelativeWithIntrinsicBounds(drawable, drawable2, drawable3, drawable4);
        }

        public static Drawable[] mjFkc(TextView textView) {
            return textView.getCompoundDrawablesRelative();
        }

        public static void wA(TextView textView, Locale locale) {
            textView.setTextLocale(locale);
        }
    }

    public IVlxe(TextView textView) {
        this.mjFkc = textView;
        this.qdMbNW = new SmIWf(textView);
    }

    public static C2223y8 ZfxDd(Context context, bbzow bbzowVar, int i) {
        ColorStateList colorStateListKLFTb = bbzowVar.KLFTb(context, i);
        if (colorStateListKLFTb == null) {
            return null;
        }
        C2223y8 c2223y8 = new C2223y8();
        c2223y8.ZfxDd = true;
        c2223y8.mjFkc = colorStateListKLFTb;
        return c2223y8;
    }

    public void AZxh() {
        if (this.AZxh != null || this.wA != null || this.ZfxDd != null || this.KLFTb != null) {
            Drawable[] compoundDrawables = this.mjFkc.getCompoundDrawables();
            mjFkc(compoundDrawables[0], this.AZxh);
            mjFkc(compoundDrawables[1], this.wA);
            mjFkc(compoundDrawables[2], this.ZfxDd);
            mjFkc(compoundDrawables[3], this.KLFTb);
        }
        if (this.JHa == null && this.xJ == null) {
            return;
        }
        Drawable[] drawableArrMjFkc = wA.mjFkc(this.mjFkc);
        mjFkc(drawableArrMjFkc[0], this.JHa);
        mjFkc(drawableArrMjFkc[2], this.xJ);
    }

    public final void BAnRFn(int i, float f) {
        this.qdMbNW.diqgf(i, f);
    }

    public ColorStateList Dt() {
        C2223y8 c2223y8 = this.lgHUyS;
        if (c2223y8 != null) {
            return c2223y8.mjFkc;
        }
        return null;
    }

    public PorterDuff.Mode ETF() {
        C2223y8 c2223y8 = this.lgHUyS;
        if (c2223y8 != null) {
            return c2223y8.AZxh;
        }
        return null;
    }

    public void Gd(PorterDuff.Mode mode) {
        if (this.lgHUyS == null) {
            this.lgHUyS = new C2223y8();
        }
        C2223y8 c2223y8 = this.lgHUyS;
        c2223y8.AZxh = mode;
        c2223y8.wA = mode != null;
        vI();
    }

    public final void HGpJ(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4, Drawable drawable5, Drawable drawable6) {
        if (drawable5 != null || drawable6 != null) {
            Drawable[] drawableArrMjFkc = wA.mjFkc(this.mjFkc);
            TextView textView = this.mjFkc;
            if (drawable5 == null) {
                drawable5 = drawableArrMjFkc[0];
            }
            if (drawable2 == null) {
                drawable2 = drawableArrMjFkc[1];
            }
            if (drawable6 == null) {
                drawable6 = drawableArrMjFkc[2];
            }
            if (drawable4 == null) {
                drawable4 = drawableArrMjFkc[3];
            }
            wA.AZxh(textView, drawable5, drawable2, drawable6, drawable4);
            return;
        }
        if (drawable == null && drawable2 == null && drawable3 == null && drawable4 == null) {
            return;
        }
        Drawable[] drawableArrMjFkc2 = wA.mjFkc(this.mjFkc);
        Drawable drawable7 = drawableArrMjFkc2[0];
        if (drawable7 != null || drawableArrMjFkc2[2] != null) {
            TextView textView2 = this.mjFkc;
            if (drawable2 == null) {
                drawable2 = drawableArrMjFkc2[1];
            }
            Drawable drawable8 = drawableArrMjFkc2[2];
            if (drawable4 == null) {
                drawable4 = drawableArrMjFkc2[3];
            }
            wA.AZxh(textView2, drawable7, drawable2, drawable8, drawable4);
            return;
        }
        Drawable[] compoundDrawables = this.mjFkc.getCompoundDrawables();
        TextView textView3 = this.mjFkc;
        if (drawable == null) {
            drawable = compoundDrawables[0];
        }
        if (drawable2 == null) {
            drawable2 = compoundDrawables[1];
        }
        if (drawable3 == null) {
            drawable3 = compoundDrawables[2];
        }
        if (drawable4 == null) {
            drawable4 = compoundDrawables[3];
        }
        textView3.setCompoundDrawablesWithIntrinsicBounds(drawable, drawable2, drawable3, drawable4);
    }

    public void IEE(TextView textView, InputConnection inputConnection, EditorInfo editorInfo) {
        if (Build.VERSION.SDK_INT >= 30 || inputConnection == null) {
            return;
        }
        YuaD.KLFTb(editorInfo, textView.getText());
    }

    public int JHa() {
        return this.qdMbNW.xJ();
    }

    public int KLFTb() {
        return this.qdMbNW.JHa();
    }

    public void MiMN(AttributeSet attributeSet, int i) {
        boolean zMjFkc;
        boolean z;
        String strYoKzxo;
        String strYoKzxo2;
        Context context = this.mjFkc.getContext();
        bbzow bbzowVarAZxh = bbzow.AZxh();
        A8 a8Diqgf = A8.diqgf(context, attributeSet, AbstractC0837b5.zvd, i, 0);
        TextView textView = this.mjFkc;
        T9.jm(textView, textView.getContext(), AbstractC0837b5.zvd, attributeSet, a8Diqgf.qGY(), i, 0);
        int iMiMN = a8Diqgf.MiMN(AbstractC0837b5.cMLeY, -1);
        if (a8Diqgf.fehf(AbstractC0837b5.NPj)) {
            this.AZxh = ZfxDd(context, bbzowVarAZxh, a8Diqgf.MiMN(AbstractC0837b5.NPj, 0));
        }
        if (a8Diqgf.fehf(AbstractC0837b5.rWxwaT)) {
            this.wA = ZfxDd(context, bbzowVarAZxh, a8Diqgf.MiMN(AbstractC0837b5.rWxwaT, 0));
        }
        if (a8Diqgf.fehf(AbstractC0837b5.vadzgd)) {
            this.ZfxDd = ZfxDd(context, bbzowVarAZxh, a8Diqgf.MiMN(AbstractC0837b5.vadzgd, 0));
        }
        if (a8Diqgf.fehf(AbstractC0837b5.Vnb)) {
            this.KLFTb = ZfxDd(context, bbzowVarAZxh, a8Diqgf.MiMN(AbstractC0837b5.Vnb, 0));
        }
        if (a8Diqgf.fehf(AbstractC0837b5.oCFDzJ)) {
            this.JHa = ZfxDd(context, bbzowVarAZxh, a8Diqgf.MiMN(AbstractC0837b5.oCFDzJ, 0));
        }
        if (a8Diqgf.fehf(AbstractC0837b5.aqHPIZ)) {
            this.xJ = ZfxDd(context, bbzowVarAZxh, a8Diqgf.MiMN(AbstractC0837b5.aqHPIZ, 0));
        }
        a8Diqgf.eyqo();
        boolean z2 = this.mjFkc.getTransformationMethod() instanceof PasswordTransformationMethod;
        boolean z3 = true;
        if (iMiMN != -1) {
            A8 a8IEE = A8.IEE(context, iMiMN, AbstractC0837b5.KSf);
            if (z2 || !a8IEE.fehf(AbstractC0837b5.MC)) {
                zMjFkc = false;
                z = false;
            } else {
                zMjFkc = a8IEE.mjFkc(AbstractC0837b5.MC, false);
                z = true;
            }
            lB(context, a8IEE);
            strYoKzxo = a8IEE.fehf(AbstractC0837b5.aDq) ? a8IEE.YoKzxo(AbstractC0837b5.aDq) : null;
            strYoKzxo2 = a8IEE.fehf(AbstractC0837b5.zPp) ? a8IEE.YoKzxo(AbstractC0837b5.zPp) : null;
            a8IEE.eyqo();
        } else {
            zMjFkc = false;
            z = false;
            strYoKzxo = null;
            strYoKzxo2 = null;
        }
        A8 a8Diqgf2 = A8.diqgf(context, attributeSet, AbstractC0837b5.KSf, i, 0);
        if (z2 || !a8Diqgf2.fehf(AbstractC0837b5.MC)) {
            z3 = z;
        } else {
            zMjFkc = a8Diqgf2.mjFkc(AbstractC0837b5.MC, false);
        }
        if (a8Diqgf2.fehf(AbstractC0837b5.aDq)) {
            strYoKzxo = a8Diqgf2.YoKzxo(AbstractC0837b5.aDq);
        }
        if (a8Diqgf2.fehf(AbstractC0837b5.zPp)) {
            strYoKzxo2 = a8Diqgf2.YoKzxo(AbstractC0837b5.zPp);
        }
        if (a8Diqgf2.fehf(AbstractC0837b5.Vptz) && a8Diqgf2.JHa(AbstractC0837b5.Vptz, -1) == 0) {
            this.mjFkc.setTextSize(0, 0.0f);
        }
        lB(context, a8Diqgf2);
        a8Diqgf2.eyqo();
        if (!z2 && z3) {
            Pq(zMjFkc);
        }
        Typeface typeface = this.VA;
        if (typeface != null) {
            if (this.ETF == -1) {
                this.mjFkc.setTypeface(typeface, this.Dt);
            } else {
                this.mjFkc.setTypeface(typeface);
            }
        }
        if (strYoKzxo2 != null) {
            KLFTb.ZfxDd(this.mjFkc, strYoKzxo2);
        }
        if (strYoKzxo != null) {
            ZfxDd.AZxh(this.mjFkc, ZfxDd.mjFkc(strYoKzxo));
        }
        this.qdMbNW.rkYL(attributeSet, i);
        if (AbstractC2007ua.AZxh && this.qdMbNW.Dt() != 0) {
            int[] iArrQdMbNW = this.qdMbNW.qdMbNW();
            if (iArrQdMbNW.length > 0) {
                if (KLFTb.mjFkc(this.mjFkc) != -1.0f) {
                    KLFTb.AZxh(this.mjFkc, this.qdMbNW.xJ(), this.qdMbNW.JHa(), this.qdMbNW.lgHUyS(), 0);
                } else {
                    KLFTb.wA(this.mjFkc, iArrQdMbNW, 0);
                }
            }
        }
        A8 a8Pq = A8.Pq(context, attributeSet, AbstractC0837b5.WrLQs);
        int iMiMN2 = a8Pq.MiMN(AbstractC0837b5.WGXroI, -1);
        Drawable drawableWA = iMiMN2 != -1 ? bbzowVarAZxh.wA(context, iMiMN2) : null;
        int iMiMN3 = a8Pq.MiMN(AbstractC0837b5.Vdz, -1);
        Drawable drawableWA2 = iMiMN3 != -1 ? bbzowVarAZxh.wA(context, iMiMN3) : null;
        int iMiMN4 = a8Pq.MiMN(AbstractC0837b5.XV, -1);
        Drawable drawableWA3 = iMiMN4 != -1 ? bbzowVarAZxh.wA(context, iMiMN4) : null;
        int iMiMN5 = a8Pq.MiMN(AbstractC0837b5.JrJO, -1);
        Drawable drawableWA4 = iMiMN5 != -1 ? bbzowVarAZxh.wA(context, iMiMN5) : null;
        int iMiMN6 = a8Pq.MiMN(AbstractC0837b5.bbzow, -1);
        Drawable drawableWA5 = iMiMN6 != -1 ? bbzowVarAZxh.wA(context, iMiMN6) : null;
        int iMiMN7 = a8Pq.MiMN(AbstractC0837b5.nxI, -1);
        HGpJ(drawableWA, drawableWA2, drawableWA3, drawableWA4, drawableWA5, iMiMN7 != -1 ? bbzowVarAZxh.wA(context, iMiMN7) : null);
        if (a8Pq.fehf(AbstractC0837b5.SwgkN)) {
            AbstractC1442l8.JHa(this.mjFkc, a8Pq.wA(AbstractC0837b5.SwgkN));
        }
        if (a8Pq.fehf(AbstractC0837b5.JBhc)) {
            AbstractC1442l8.xJ(this.mjFkc, awnh.ZfxDd(a8Pq.Dt(AbstractC0837b5.JBhc, -1), null));
        }
        int iJHa = a8Pq.JHa(AbstractC0837b5.ANMGZc, -1);
        int iJHa2 = a8Pq.JHa(AbstractC0837b5.alEkx, -1);
        int iJHa3 = a8Pq.JHa(AbstractC0837b5.dm, -1);
        a8Pq.eyqo();
        if (iJHa != -1) {
            AbstractC1442l8.qdMbNW(this.mjFkc, iJHa);
        }
        if (iJHa2 != -1) {
            AbstractC1442l8.Dt(this.mjFkc, iJHa2);
        }
        if (iJHa3 != -1) {
            AbstractC1442l8.ETF(this.mjFkc, iJHa3);
        }
    }

    public void Pq(boolean z) {
        this.mjFkc.setAllCaps(z);
    }

    public void Ucbh(int i) {
        this.qdMbNW.IEE(i);
    }

    public boolean VA() {
        return this.qdMbNW.YoKzxo();
    }

    public void VocHEe(int i, float f) {
        if (AbstractC2007ua.AZxh || VA()) {
            return;
        }
        BAnRFn(i, f);
    }

    public void YoKzxo(WeakReference weakReference, Typeface typeface) {
        if (this.MiMN) {
            this.VA = typeface;
            TextView textView = (TextView) weakReference.get();
            if (textView != null) {
                if (T9.cMLeY(textView)) {
                    textView.post(new AZxh(textView, typeface, this.Dt));
                } else {
                    textView.setTypeface(typeface, this.Dt);
                }
            }
        }
    }

    public void diqgf(int i, int i2, int i3, int i4) {
        this.qdMbNW.qGY(i, i2, i3, i4);
    }

    public void eyqo(int[] iArr, int i) {
        this.qdMbNW.fehf(iArr, i);
    }

    public void fehf(Context context, int i) {
        String strYoKzxo;
        A8 a8IEE = A8.IEE(context, i, AbstractC0837b5.KSf);
        if (a8IEE.fehf(AbstractC0837b5.MC)) {
            Pq(a8IEE.mjFkc(AbstractC0837b5.MC, false));
        }
        if (a8IEE.fehf(AbstractC0837b5.Vptz) && a8IEE.JHa(AbstractC0837b5.Vptz, -1) == 0) {
            this.mjFkc.setTextSize(0, 0.0f);
        }
        lB(context, a8IEE);
        if (a8IEE.fehf(AbstractC0837b5.zPp) && (strYoKzxo = a8IEE.YoKzxo(AbstractC0837b5.zPp)) != null) {
            KLFTb.ZfxDd(this.mjFkc, strYoKzxo);
        }
        a8IEE.eyqo();
        Typeface typeface = this.VA;
        if (typeface != null) {
            this.mjFkc.setTypeface(typeface, this.Dt);
        }
    }

    public void huTpC(ColorStateList colorStateList) {
        if (this.lgHUyS == null) {
            this.lgHUyS = new C2223y8();
        }
        C2223y8 c2223y8 = this.lgHUyS;
        c2223y8.mjFkc = colorStateList;
        c2223y8.ZfxDd = colorStateList != null;
        vI();
    }

    public final void lB(Context context, A8 a8) {
        String strYoKzxo;
        this.Dt = a8.Dt(AbstractC0837b5.CcoH, this.Dt);
        int iDt = a8.Dt(AbstractC0837b5.EoC, -1);
        this.ETF = iDt;
        if (iDt != -1) {
            this.Dt &= 2;
        }
        if (!a8.fehf(AbstractC0837b5.HX) && !a8.fehf(AbstractC0837b5.xbjHT)) {
            if (a8.fehf(AbstractC0837b5.qrxT)) {
                this.MiMN = false;
                int iDt2 = a8.Dt(AbstractC0837b5.qrxT, 1);
                if (iDt2 == 1) {
                    this.VA = Typeface.SANS_SERIF;
                    return;
                } else if (iDt2 == 2) {
                    this.VA = Typeface.SERIF;
                    return;
                } else {
                    if (iDt2 != 3) {
                        return;
                    }
                    this.VA = Typeface.MONOSPACE;
                    return;
                }
            }
            return;
        }
        this.VA = null;
        int i = a8.fehf(AbstractC0837b5.xbjHT) ? AbstractC0837b5.xbjHT : AbstractC0837b5.HX;
        int i2 = this.ETF;
        int i3 = this.Dt;
        if (!context.isRestricted()) {
            try {
                Typeface typefaceQdMbNW = a8.qdMbNW(i, this.Dt, new mjFkc(i2, i3, new WeakReference(this.mjFkc)));
                if (typefaceQdMbNW != null) {
                    if (this.ETF != -1) {
                        this.VA = JHa.mjFkc(Typeface.create(typefaceQdMbNW, 0), this.ETF, (this.Dt & 2) != 0);
                    } else {
                        this.VA = typefaceQdMbNW;
                    }
                }
                this.MiMN = this.VA == null;
            } catch (Resources.NotFoundException | UnsupportedOperationException unused) {
            }
        }
        if (this.VA != null || (strYoKzxo = a8.YoKzxo(i)) == null) {
            return;
        }
        if (this.ETF != -1) {
            this.VA = JHa.mjFkc(Typeface.create(strYoKzxo, 0), this.ETF, (this.Dt & 2) != 0);
        } else {
            this.VA = Typeface.create(strYoKzxo, this.Dt);
        }
    }

    public int[] lgHUyS() {
        return this.qdMbNW.qdMbNW();
    }

    public final void mjFkc(Drawable drawable, C2223y8 c2223y8) {
        if (drawable == null || c2223y8 == null) {
            return;
        }
        bbzow.xJ(drawable, c2223y8, this.mjFkc.getDrawableState());
    }

    public void qGY() {
        AZxh();
    }

    public int qdMbNW() {
        return this.qdMbNW.Dt();
    }

    public void rkYL(boolean z, int i, int i2, int i3, int i4) {
        if (AbstractC2007ua.AZxh) {
            return;
        }
        wA();
    }

    public final void vI() {
        C2223y8 c2223y8 = this.lgHUyS;
        this.AZxh = c2223y8;
        this.wA = c2223y8;
        this.ZfxDd = c2223y8;
        this.KLFTb = c2223y8;
        this.JHa = c2223y8;
        this.xJ = c2223y8;
    }

    public void wA() {
        this.qdMbNW.mjFkc();
    }

    public int xJ() {
        return this.qdMbNW.lgHUyS();
    }
}
