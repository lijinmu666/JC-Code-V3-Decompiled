package o;

import o.InterfaceC2283z7;

/* renamed from: o.z9, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final /* synthetic */ class C2285z9 implements InterfaceC2283z7.mjFkc {
    public final wfQA mjFkc;

    public C2285z9(wfQA wfqa) {
        this.mjFkc = wfqa;
    }

    public static InterfaceC2283z7.mjFkc AZxh(wfQA wfqa) {
        return new C2285z9(wfqa);
    }

    @Override // o.InterfaceC2283z7.mjFkc
    public Object mjFkc() {
        return Integer.valueOf(this.mjFkc.mjFkc());
    }
}
