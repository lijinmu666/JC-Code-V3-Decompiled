package o;

/* loaded from: classes.dex */
public interface Y7 {
    boolean mjFkc(CharSequence charSequence, int i, int i2);
}
