package o;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewParent;
import androidx.constraintlayout.widget.ConstraintLayout;

/* renamed from: o.Ca, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC0217Ca extends androidx.constraintlayout.widget.AZxh {
    public boolean Dt;
    public boolean qdMbNW;

    public AbstractC0217Ca(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public abstract void YoKzxo(AbstractC0240Da abstractC0240Da, int i, int i2);

    @Override // androidx.constraintlayout.widget.AZxh, android.view.View
    public void onAttachedToWindow() throws IllegalAccessException, Resources.NotFoundException, IllegalArgumentException {
        ViewParent parent;
        super.onAttachedToWindow();
        if ((this.qdMbNW || this.Dt) && (parent = getParent()) != null && (parent instanceof ConstraintLayout)) {
            ConstraintLayout constraintLayout = (ConstraintLayout) parent;
            int visibility = getVisibility();
            float elevation = getElevation();
            for (int i = 0; i < this.AZxh; i++) {
                View viewLgHUyS = constraintLayout.lgHUyS(this.mjFkc[i]);
                if (viewLgHUyS != null) {
                    if (this.qdMbNW) {
                        viewLgHUyS.setVisibility(visibility);
                    }
                    if (this.Dt && elevation > 0.0f) {
                        viewLgHUyS.setTranslationZ(viewLgHUyS.getTranslationZ() + elevation);
                    }
                }
            }
        }
    }

    @Override // android.view.View
    public void setElevation(float f) {
        super.setElevation(f);
        wA();
    }

    @Override // android.view.View
    public void setVisibility(int i) {
        super.setVisibility(i);
        wA();
    }

    @Override // androidx.constraintlayout.widget.AZxh
    public void xJ(AttributeSet attributeSet) throws IllegalAccessException, Resources.NotFoundException, IllegalArgumentException {
        super.xJ(attributeSet);
        if (attributeSet != null) {
            TypedArray typedArrayObtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, V4.dGDT);
            int indexCount = typedArrayObtainStyledAttributes.getIndexCount();
            for (int i = 0; i < indexCount; i++) {
                int index = typedArrayObtainStyledAttributes.getIndex(i);
                if (index == V4.NV) {
                    this.qdMbNW = true;
                } else if (index == V4.oaI) {
                    this.Dt = true;
                }
            }
        }
    }
}
