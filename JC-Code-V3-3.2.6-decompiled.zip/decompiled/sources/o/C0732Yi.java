package o;

/* renamed from: o.Yi, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0732Yi extends Vx implements Ly {
    public /* synthetic */ C0732Yi(AbstractC0709Xi abstractC0709Xi) {
        super(C0755Zi.zbb);
    }
}
