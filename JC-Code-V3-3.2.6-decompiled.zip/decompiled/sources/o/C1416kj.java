package o;

/* renamed from: o.kj, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C1416kj extends Vx implements Ly {
    public /* synthetic */ C1416kj(AbstractC1356jj abstractC1356jj) {
        super(C1476lj.zbb);
    }
}
