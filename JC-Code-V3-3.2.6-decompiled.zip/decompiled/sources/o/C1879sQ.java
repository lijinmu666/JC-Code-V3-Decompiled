package o;

import o.C0797aQ;

/* renamed from: o.sQ, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C1879sQ implements R2 {
    public static final C0797aQ AZxh;
    public static final C0797aQ Dt;
    public static final C0797aQ ETF;
    public static final C0797aQ JHa;
    public static final C0797aQ KLFTb;
    public static final C0797aQ MiMN;
    public static final C0797aQ VA;
    public static final C0797aQ YoKzxo;
    public static final C0797aQ ZfxDd;
    public static final C0797aQ lgHUyS;
    public static final C1879sQ mjFkc = new C1879sQ();
    public static final C0797aQ qdMbNW;
    public static final C0797aQ rkYL;
    public static final C0797aQ wA;
    public static final C0797aQ xJ;

    static {
        C0797aQ.AZxh aZxhMjFkc = C0797aQ.mjFkc("appId");
        C1389kF c1389kF = new C1389kF();
        c1389kF.mjFkc(1);
        AZxh = aZxhMjFkc.AZxh(c1389kF.AZxh()).mjFkc();
        C0797aQ.AZxh aZxhMjFkc2 = C0797aQ.mjFkc("appVersion");
        C1389kF c1389kF2 = new C1389kF();
        c1389kF2.mjFkc(2);
        wA = aZxhMjFkc2.AZxh(c1389kF2.AZxh()).mjFkc();
        C0797aQ.AZxh aZxhMjFkc3 = C0797aQ.mjFkc("firebaseProjectId");
        C1389kF c1389kF3 = new C1389kF();
        c1389kF3.mjFkc(3);
        ZfxDd = aZxhMjFkc3.AZxh(c1389kF3.AZxh()).mjFkc();
        C0797aQ.AZxh aZxhMjFkc4 = C0797aQ.mjFkc("mlSdkVersion");
        C1389kF c1389kF4 = new C1389kF();
        c1389kF4.mjFkc(4);
        KLFTb = aZxhMjFkc4.AZxh(c1389kF4.AZxh()).mjFkc();
        C0797aQ.AZxh aZxhMjFkc5 = C0797aQ.mjFkc("tfliteSchemaVersion");
        C1389kF c1389kF5 = new C1389kF();
        c1389kF5.mjFkc(5);
        JHa = aZxhMjFkc5.AZxh(c1389kF5.AZxh()).mjFkc();
        C0797aQ.AZxh aZxhMjFkc6 = C0797aQ.mjFkc("gcmSenderId");
        C1389kF c1389kF6 = new C1389kF();
        c1389kF6.mjFkc(6);
        xJ = aZxhMjFkc6.AZxh(c1389kF6.AZxh()).mjFkc();
        C0797aQ.AZxh aZxhMjFkc7 = C0797aQ.mjFkc("apiKey");
        C1389kF c1389kF7 = new C1389kF();
        c1389kF7.mjFkc(7);
        lgHUyS = aZxhMjFkc7.AZxh(c1389kF7.AZxh()).mjFkc();
        C0797aQ.AZxh aZxhMjFkc8 = C0797aQ.mjFkc("languages");
        C1389kF c1389kF8 = new C1389kF();
        c1389kF8.mjFkc(8);
        qdMbNW = aZxhMjFkc8.AZxh(c1389kF8.AZxh()).mjFkc();
        C0797aQ.AZxh aZxhMjFkc9 = C0797aQ.mjFkc("mlSdkInstanceId");
        C1389kF c1389kF9 = new C1389kF();
        c1389kF9.mjFkc(9);
        Dt = aZxhMjFkc9.AZxh(c1389kF9.AZxh()).mjFkc();
        C0797aQ.AZxh aZxhMjFkc10 = C0797aQ.mjFkc("isClearcutClient");
        C1389kF c1389kF10 = new C1389kF();
        c1389kF10.mjFkc(10);
        ETF = aZxhMjFkc10.AZxh(c1389kF10.AZxh()).mjFkc();
        C0797aQ.AZxh aZxhMjFkc11 = C0797aQ.mjFkc("isStandaloneMlkit");
        C1389kF c1389kF11 = new C1389kF();
        c1389kF11.mjFkc(11);
        VA = aZxhMjFkc11.AZxh(c1389kF11.AZxh()).mjFkc();
        C0797aQ.AZxh aZxhMjFkc12 = C0797aQ.mjFkc("isJsonLogging");
        C1389kF c1389kF12 = new C1389kF();
        c1389kF12.mjFkc(12);
        MiMN = aZxhMjFkc12.AZxh(c1389kF12.AZxh()).mjFkc();
        C0797aQ.AZxh aZxhMjFkc13 = C0797aQ.mjFkc("buildLevel");
        C1389kF c1389kF13 = new C1389kF();
        c1389kF13.mjFkc(13);
        YoKzxo = aZxhMjFkc13.AZxh(c1389kF13.AZxh()).mjFkc();
        C0797aQ.AZxh aZxhMjFkc14 = C0797aQ.mjFkc("optionalModuleVersion");
        C1389kF c1389kF14 = new C1389kF();
        c1389kF14.mjFkc(14);
        rkYL = aZxhMjFkc14.AZxh(c1389kF14.AZxh()).mjFkc();
    }

    @Override // o.mYYU
    public final /* bridge */ /* synthetic */ void mjFkc(Object obj, Object obj2) {
        C1105fV c1105fV = (C1105fV) obj;
        S2 s2 = (S2) obj2;
        s2.wA(AZxh, c1105fV.xJ());
        s2.wA(wA, c1105fV.lgHUyS());
        s2.wA(ZfxDd, null);
        s2.wA(KLFTb, c1105fV.Dt());
        s2.wA(JHa, c1105fV.ETF());
        s2.wA(xJ, null);
        s2.wA(lgHUyS, null);
        s2.wA(qdMbNW, c1105fV.mjFkc());
        s2.wA(Dt, c1105fV.qdMbNW());
        s2.wA(ETF, c1105fV.AZxh());
        s2.wA(VA, c1105fV.ZfxDd());
        s2.wA(MiMN, c1105fV.wA());
        s2.wA(YoKzxo, c1105fV.KLFTb());
        s2.wA(rkYL, c1105fV.JHa());
    }
}
