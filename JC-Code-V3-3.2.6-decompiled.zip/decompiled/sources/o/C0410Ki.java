package o;

import org.conscrypt.BuildConfig;

/* renamed from: o.Ki, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0410Ki extends AbstractC1010dy implements Ly {
    private static final C0410Ki zbb;
    private int zbd;
    private String zbe = BuildConfig.FLAVOR;
    private AbstractC2272yx zbf = AbstractC2272yx.AZxh;

    static {
        C0410Ki c0410Ki = new C0410Ki();
        zbb = c0410Ki;
        AbstractC1010dy.YoKzxo(C0410Ki.class, c0410Ki);
    }

    @Override // o.AbstractC1010dy
    public final Object IEE(int i, Object obj, Object obj2) {
        int i2 = i - 1;
        if (i2 == 0) {
            return (byte) 1;
        }
        if (i2 == 2) {
            return AbstractC1010dy.ETF(zbb, "\u0001\u0002\u0000\u0001\u0001\u0002\u0002\u0000\u0000\u0000\u0001ဈ\u0000\u0002ည\u0001", new Object[]{"zbd", "zbe", "zbf"});
        }
        if (i2 == 3) {
            return new C0410Ki();
        }
        AbstractC0340Hi abstractC0340Hi = null;
        if (i2 == 4) {
            return new C0387Ji(abstractC0340Hi);
        }
        if (i2 != 5) {
            return null;
        }
        return zbb;
    }
}
