package o;

/* loaded from: classes.dex */
public abstract class NBXYLM {
    public static int AZxh() {
        return C2282z6.wA;
    }

    public static String mjFkc() {
        return "com.google.android.datatransport.events";
    }

    public static YxdwU wA() {
        return YxdwU.mjFkc;
    }
}
