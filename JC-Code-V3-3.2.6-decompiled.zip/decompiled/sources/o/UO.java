package o;

import o.C0797aQ;

/* loaded from: classes.dex */
public final class UO implements R2 {
    public static final UO mjFkc = new UO();

    static {
        C0797aQ.AZxh aZxhMjFkc = C0797aQ.mjFkc("detectorMode");
        C1389kF c1389kF = new C1389kF();
        c1389kF.mjFkc(1);
        aZxhMjFkc.AZxh(c1389kF.AZxh()).mjFkc();
        C0797aQ.AZxh aZxhMjFkc2 = C0797aQ.mjFkc("personDetectionMode");
        C1389kF c1389kF2 = new C1389kF();
        c1389kF2.mjFkc(2);
        aZxhMjFkc2.AZxh(c1389kF2.AZxh()).mjFkc();
        C0797aQ.AZxh aZxhMjFkc3 = C0797aQ.mjFkc("landmarkDetectionMode");
        C1389kF c1389kF3 = new C1389kF();
        c1389kF3.mjFkc(3);
        aZxhMjFkc3.AZxh(c1389kF3.AZxh()).mjFkc();
        C0797aQ.AZxh aZxhMjFkc4 = C0797aQ.mjFkc("preferredHardwareConfigs");
        C1389kF c1389kF4 = new C1389kF();
        c1389kF4.mjFkc(4);
        aZxhMjFkc4.AZxh(c1389kF4.AZxh()).mjFkc();
        C0797aQ.AZxh aZxhMjFkc5 = C0797aQ.mjFkc("runConfig");
        C1389kF c1389kF5 = new C1389kF();
        c1389kF5.mjFkc(5);
        aZxhMjFkc5.AZxh(c1389kF5.AZxh()).mjFkc();
    }

    @Override // o.mYYU
    public final /* bridge */ /* synthetic */ void mjFkc(Object obj, Object obj2) {
        AbstractC2102w7.mjFkc(obj);
        throw null;
    }
}
