package o;

import java.io.Serializable;
import java.util.AbstractMap;
import java.util.AbstractSet;
import java.util.Comparator;
import java.util.ConcurrentModificationException;
import java.util.Iterator;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Set;

/* loaded from: classes.dex */
public final class Z0 extends AbstractMap implements Serializable {
    public static final Comparator lgHUyS = new mjFkc();
    public KLFTb AZxh;
    public AZxh JHa;
    public final KLFTb KLFTb;
    public int ZfxDd;
    public Comparator mjFkc;
    public int wA;
    public wA xJ;

    public class AZxh extends AbstractSet {

        public class mjFkc extends ZfxDd {
            public mjFkc() {
                super();
            }

            @Override // java.util.Iterator
            /* renamed from: wA, reason: merged with bridge method [inline-methods] */
            public Map.Entry next() {
                return AZxh();
            }
        }

        public AZxh() {
        }

        @Override // java.util.AbstractCollection, java.util.Collection, java.util.Set
        public void clear() {
            Z0.this.clear();
        }

        @Override // java.util.AbstractCollection, java.util.Collection, java.util.Set
        public boolean contains(Object obj) {
            return (obj instanceof Map.Entry) && Z0.this.wA((Map.Entry) obj) != null;
        }

        @Override // java.util.AbstractCollection, java.util.Collection, java.lang.Iterable, java.util.Set
        public Iterator iterator() {
            return new mjFkc();
        }

        @Override // java.util.AbstractCollection, java.util.Collection, java.util.Set
        public boolean remove(Object obj) {
            KLFTb kLFTbWA;
            if (!(obj instanceof Map.Entry) || (kLFTbWA = Z0.this.wA((Map.Entry) obj)) == null) {
                return false;
            }
            Z0.this.JHa(kLFTbWA, true);
            return true;
        }

        @Override // java.util.AbstractCollection, java.util.Collection, java.util.Set
        public int size() {
            return Z0.this.wA;
        }
    }

    public abstract class ZfxDd implements Iterator {
        public KLFTb AZxh = null;
        public KLFTb mjFkc;
        public int wA;

        public ZfxDd() {
            this.mjFkc = Z0.this.KLFTb.ZfxDd;
            this.wA = Z0.this.ZfxDd;
        }

        public final KLFTb AZxh() {
            KLFTb kLFTb = this.mjFkc;
            Z0 z0 = Z0.this;
            if (kLFTb == z0.KLFTb) {
                throw new NoSuchElementException();
            }
            if (z0.ZfxDd != this.wA) {
                throw new ConcurrentModificationException();
            }
            this.mjFkc = kLFTb.ZfxDd;
            this.AZxh = kLFTb;
            return kLFTb;
        }

        @Override // java.util.Iterator
        public final boolean hasNext() {
            return this.mjFkc != Z0.this.KLFTb;
        }

        @Override // java.util.Iterator
        public final void remove() {
            KLFTb kLFTb = this.AZxh;
            if (kLFTb == null) {
                throw new IllegalStateException();
            }
            Z0.this.JHa(kLFTb, true);
            this.AZxh = null;
            this.wA = Z0.this.ZfxDd;
        }
    }

    public class mjFkc implements Comparator {
        @Override // java.util.Comparator
        /* renamed from: mjFkc, reason: merged with bridge method [inline-methods] */
        public int compare(Comparable comparable, Comparable comparable2) {
            return comparable.compareTo(comparable2);
        }
    }

    public final class wA extends AbstractSet {

        public class mjFkc extends ZfxDd {
            public mjFkc() {
                super();
            }

            @Override // java.util.Iterator
            public Object next() {
                return AZxh().JHa;
            }
        }

        public wA() {
        }

        @Override // java.util.AbstractCollection, java.util.Collection, java.util.Set
        public void clear() {
            Z0.this.clear();
        }

        @Override // java.util.AbstractCollection, java.util.Collection, java.util.Set
        public boolean contains(Object obj) {
            return Z0.this.containsKey(obj);
        }

        @Override // java.util.AbstractCollection, java.util.Collection, java.lang.Iterable, java.util.Set
        public Iterator iterator() {
            return new mjFkc();
        }

        @Override // java.util.AbstractCollection, java.util.Collection, java.util.Set
        public boolean remove(Object obj) {
            return Z0.this.xJ(obj) != null;
        }

        @Override // java.util.AbstractCollection, java.util.Collection, java.util.Set
        public int size() {
            return Z0.this.wA;
        }
    }

    public Z0() {
        this(lgHUyS);
    }

    public KLFTb AZxh(Object obj, boolean z) {
        int iCompareTo;
        KLFTb kLFTb;
        Comparator comparator = this.mjFkc;
        KLFTb kLFTb2 = this.AZxh;
        if (kLFTb2 != null) {
            Comparable comparable = comparator == lgHUyS ? (Comparable) obj : null;
            while (true) {
                iCompareTo = comparable != null ? comparable.compareTo(kLFTb2.JHa) : comparator.compare(obj, kLFTb2.JHa);
                if (iCompareTo == 0) {
                    return kLFTb2;
                }
                KLFTb kLFTb3 = iCompareTo < 0 ? kLFTb2.AZxh : kLFTb2.wA;
                if (kLFTb3 == null) {
                    break;
                }
                kLFTb2 = kLFTb3;
            }
        } else {
            iCompareTo = 0;
        }
        if (!z) {
            return null;
        }
        KLFTb kLFTb4 = this.KLFTb;
        if (kLFTb2 != null) {
            kLFTb = new KLFTb(kLFTb2, obj, kLFTb4, kLFTb4.KLFTb);
            if (iCompareTo < 0) {
                kLFTb2.AZxh = kLFTb;
            } else {
                kLFTb2.wA = kLFTb;
            }
            KLFTb(kLFTb2, true);
        } else {
            if (comparator == lgHUyS && !(obj instanceof Comparable)) {
                throw new ClassCastException(obj.getClass().getName() + " is not Comparable");
            }
            kLFTb = new KLFTb(kLFTb2, obj, kLFTb4, kLFTb4.KLFTb);
            this.AZxh = kLFTb;
        }
        this.wA++;
        this.ZfxDd++;
        return kLFTb;
    }

    public final void Dt(KLFTb kLFTb) {
        KLFTb kLFTb2 = kLFTb.AZxh;
        KLFTb kLFTb3 = kLFTb.wA;
        KLFTb kLFTb4 = kLFTb2.AZxh;
        KLFTb kLFTb5 = kLFTb2.wA;
        kLFTb.AZxh = kLFTb5;
        if (kLFTb5 != null) {
            kLFTb5.mjFkc = kLFTb;
        }
        lgHUyS(kLFTb, kLFTb2);
        kLFTb2.wA = kLFTb;
        kLFTb.mjFkc = kLFTb2;
        int iMax = Math.max(kLFTb3 != null ? kLFTb3.lgHUyS : 0, kLFTb5 != null ? kLFTb5.lgHUyS : 0) + 1;
        kLFTb.lgHUyS = iMax;
        kLFTb2.lgHUyS = Math.max(iMax, kLFTb4 != null ? kLFTb4.lgHUyS : 0) + 1;
    }

    public void JHa(KLFTb kLFTb, boolean z) {
        int i;
        if (z) {
            KLFTb kLFTb2 = kLFTb.KLFTb;
            kLFTb2.ZfxDd = kLFTb.ZfxDd;
            kLFTb.ZfxDd.KLFTb = kLFTb2;
        }
        KLFTb kLFTb3 = kLFTb.AZxh;
        KLFTb kLFTb4 = kLFTb.wA;
        KLFTb kLFTb5 = kLFTb.mjFkc;
        int i2 = 0;
        if (kLFTb3 == null || kLFTb4 == null) {
            if (kLFTb3 != null) {
                lgHUyS(kLFTb, kLFTb3);
                kLFTb.AZxh = null;
            } else if (kLFTb4 != null) {
                lgHUyS(kLFTb, kLFTb4);
                kLFTb.wA = null;
            } else {
                lgHUyS(kLFTb, null);
            }
            KLFTb(kLFTb5, false);
            this.wA--;
            this.ZfxDd++;
            return;
        }
        KLFTb kLFTbAZxh = kLFTb3.lgHUyS > kLFTb4.lgHUyS ? kLFTb3.AZxh() : kLFTb4.mjFkc();
        JHa(kLFTbAZxh, false);
        KLFTb kLFTb6 = kLFTb.AZxh;
        if (kLFTb6 != null) {
            i = kLFTb6.lgHUyS;
            kLFTbAZxh.AZxh = kLFTb6;
            kLFTb6.mjFkc = kLFTbAZxh;
            kLFTb.AZxh = null;
        } else {
            i = 0;
        }
        KLFTb kLFTb7 = kLFTb.wA;
        if (kLFTb7 != null) {
            i2 = kLFTb7.lgHUyS;
            kLFTbAZxh.wA = kLFTb7;
            kLFTb7.mjFkc = kLFTbAZxh;
            kLFTb.wA = null;
        }
        kLFTbAZxh.lgHUyS = Math.max(i, i2) + 1;
        lgHUyS(kLFTb, kLFTbAZxh);
    }

    public final void KLFTb(KLFTb kLFTb, boolean z) {
        while (kLFTb != null) {
            KLFTb kLFTb2 = kLFTb.AZxh;
            KLFTb kLFTb3 = kLFTb.wA;
            int i = kLFTb2 != null ? kLFTb2.lgHUyS : 0;
            int i2 = kLFTb3 != null ? kLFTb3.lgHUyS : 0;
            int i3 = i - i2;
            if (i3 == -2) {
                KLFTb kLFTb4 = kLFTb3.AZxh;
                KLFTb kLFTb5 = kLFTb3.wA;
                int i4 = (kLFTb4 != null ? kLFTb4.lgHUyS : 0) - (kLFTb5 != null ? kLFTb5.lgHUyS : 0);
                if (i4 == -1 || (i4 == 0 && !z)) {
                    qdMbNW(kLFTb);
                } else {
                    Dt(kLFTb3);
                    qdMbNW(kLFTb);
                }
                if (z) {
                    return;
                }
            } else if (i3 == 2) {
                KLFTb kLFTb6 = kLFTb2.AZxh;
                KLFTb kLFTb7 = kLFTb2.wA;
                int i5 = (kLFTb6 != null ? kLFTb6.lgHUyS : 0) - (kLFTb7 != null ? kLFTb7.lgHUyS : 0);
                if (i5 == 1 || (i5 == 0 && !z)) {
                    Dt(kLFTb);
                } else {
                    qdMbNW(kLFTb2);
                    Dt(kLFTb);
                }
                if (z) {
                    return;
                }
            } else if (i3 == 0) {
                kLFTb.lgHUyS = i + 1;
                if (z) {
                    return;
                }
            } else {
                kLFTb.lgHUyS = Math.max(i, i2) + 1;
                if (!z) {
                    return;
                }
            }
            kLFTb = kLFTb.mjFkc;
        }
    }

    public KLFTb ZfxDd(Object obj) {
        if (obj == null) {
            return null;
        }
        try {
            return AZxh(obj, false);
        } catch (ClassCastException unused) {
            return null;
        }
    }

    @Override // java.util.AbstractMap, java.util.Map
    public void clear() {
        this.AZxh = null;
        this.wA = 0;
        this.ZfxDd++;
        KLFTb kLFTb = this.KLFTb;
        kLFTb.KLFTb = kLFTb;
        kLFTb.ZfxDd = kLFTb;
    }

    @Override // java.util.AbstractMap, java.util.Map
    public boolean containsKey(Object obj) {
        return ZfxDd(obj) != null;
    }

    @Override // java.util.AbstractMap, java.util.Map
    public Set entrySet() {
        AZxh aZxh = this.JHa;
        if (aZxh != null) {
            return aZxh;
        }
        AZxh aZxh2 = new AZxh();
        this.JHa = aZxh2;
        return aZxh2;
    }

    @Override // java.util.AbstractMap, java.util.Map
    public Object get(Object obj) {
        KLFTb kLFTbZfxDd = ZfxDd(obj);
        if (kLFTbZfxDd != null) {
            return kLFTbZfxDd.xJ;
        }
        return null;
    }

    @Override // java.util.AbstractMap, java.util.Map
    public Set keySet() {
        wA wAVar = this.xJ;
        if (wAVar != null) {
            return wAVar;
        }
        wA wAVar2 = new wA();
        this.xJ = wAVar2;
        return wAVar2;
    }

    public final void lgHUyS(KLFTb kLFTb, KLFTb kLFTb2) {
        KLFTb kLFTb3 = kLFTb.mjFkc;
        kLFTb.mjFkc = null;
        if (kLFTb2 != null) {
            kLFTb2.mjFkc = kLFTb3;
        }
        if (kLFTb3 == null) {
            this.AZxh = kLFTb2;
        } else if (kLFTb3.AZxh == kLFTb) {
            kLFTb3.AZxh = kLFTb2;
        } else {
            kLFTb3.wA = kLFTb2;
        }
    }

    public final boolean mjFkc(Object obj, Object obj2) {
        return obj == obj2 || (obj != null && obj.equals(obj2));
    }

    @Override // java.util.AbstractMap, java.util.Map
    public Object put(Object obj, Object obj2) {
        if (obj == null) {
            throw new NullPointerException("key == null");
        }
        KLFTb kLFTbAZxh = AZxh(obj, true);
        Object obj3 = kLFTbAZxh.xJ;
        kLFTbAZxh.xJ = obj2;
        return obj3;
    }

    public final void qdMbNW(KLFTb kLFTb) {
        KLFTb kLFTb2 = kLFTb.AZxh;
        KLFTb kLFTb3 = kLFTb.wA;
        KLFTb kLFTb4 = kLFTb3.AZxh;
        KLFTb kLFTb5 = kLFTb3.wA;
        kLFTb.wA = kLFTb4;
        if (kLFTb4 != null) {
            kLFTb4.mjFkc = kLFTb;
        }
        lgHUyS(kLFTb, kLFTb3);
        kLFTb3.AZxh = kLFTb;
        kLFTb.mjFkc = kLFTb3;
        int iMax = Math.max(kLFTb2 != null ? kLFTb2.lgHUyS : 0, kLFTb4 != null ? kLFTb4.lgHUyS : 0) + 1;
        kLFTb.lgHUyS = iMax;
        kLFTb3.lgHUyS = Math.max(iMax, kLFTb5 != null ? kLFTb5.lgHUyS : 0) + 1;
    }

    @Override // java.util.AbstractMap, java.util.Map
    public Object remove(Object obj) {
        KLFTb kLFTbXJ = xJ(obj);
        if (kLFTbXJ != null) {
            return kLFTbXJ.xJ;
        }
        return null;
    }

    @Override // java.util.AbstractMap, java.util.Map
    public int size() {
        return this.wA;
    }

    public KLFTb wA(Map.Entry entry) {
        KLFTb kLFTbZfxDd = ZfxDd(entry.getKey());
        if (kLFTbZfxDd == null || !mjFkc(kLFTbZfxDd.xJ, entry.getValue())) {
            return null;
        }
        return kLFTbZfxDd;
    }

    public KLFTb xJ(Object obj) {
        KLFTb kLFTbZfxDd = ZfxDd(obj);
        if (kLFTbZfxDd != null) {
            JHa(kLFTbZfxDd, true);
        }
        return kLFTbZfxDd;
    }

    public Z0(Comparator comparator) {
        this.wA = 0;
        this.ZfxDd = 0;
        this.KLFTb = new KLFTb();
        this.mjFkc = comparator == null ? lgHUyS : comparator;
    }

    public static final class KLFTb implements Map.Entry {
        public KLFTb AZxh;
        public final Object JHa;
        public KLFTb KLFTb;
        public KLFTb ZfxDd;
        public int lgHUyS;
        public KLFTb mjFkc;
        public KLFTb wA;
        public Object xJ;

        public KLFTb() {
            this.JHa = null;
            this.KLFTb = this;
            this.ZfxDd = this;
        }

        public KLFTb AZxh() {
            KLFTb kLFTb = this.wA;
            while (true) {
                KLFTb kLFTb2 = kLFTb;
                KLFTb kLFTb3 = this;
                this = kLFTb2;
                if (this == null) {
                    return kLFTb3;
                }
                kLFTb = this.wA;
            }
        }

        @Override // java.util.Map.Entry
        public boolean equals(Object obj) {
            if (!(obj instanceof Map.Entry)) {
                return false;
            }
            Map.Entry entry = (Map.Entry) obj;
            Object obj2 = this.JHa;
            if (obj2 == null) {
                if (entry.getKey() != null) {
                    return false;
                }
            } else if (!obj2.equals(entry.getKey())) {
                return false;
            }
            Object obj3 = this.xJ;
            if (obj3 == null) {
                if (entry.getValue() != null) {
                    return false;
                }
            } else if (!obj3.equals(entry.getValue())) {
                return false;
            }
            return true;
        }

        @Override // java.util.Map.Entry
        public Object getKey() {
            return this.JHa;
        }

        @Override // java.util.Map.Entry
        public Object getValue() {
            return this.xJ;
        }

        @Override // java.util.Map.Entry
        public int hashCode() {
            Object obj = this.JHa;
            int iHashCode = obj == null ? 0 : obj.hashCode();
            Object obj2 = this.xJ;
            return iHashCode ^ (obj2 != null ? obj2.hashCode() : 0);
        }

        public KLFTb mjFkc() {
            KLFTb kLFTb = this.AZxh;
            while (true) {
                KLFTb kLFTb2 = kLFTb;
                KLFTb kLFTb3 = this;
                this = kLFTb2;
                if (this == null) {
                    return kLFTb3;
                }
                kLFTb = this.AZxh;
            }
        }

        @Override // java.util.Map.Entry
        public Object setValue(Object obj) {
            Object obj2 = this.xJ;
            this.xJ = obj;
            return obj2;
        }

        public String toString() {
            return this.JHa + "=" + this.xJ;
        }

        public KLFTb(KLFTb kLFTb, Object obj, KLFTb kLFTb2, KLFTb kLFTb3) {
            this.mjFkc = kLFTb;
            this.JHa = obj;
            this.lgHUyS = 1;
            this.ZfxDd = kLFTb2;
            this.KLFTb = kLFTb3;
            kLFTb3.ZfxDd = this;
            kLFTb2.KLFTb = this;
        }
    }
}
