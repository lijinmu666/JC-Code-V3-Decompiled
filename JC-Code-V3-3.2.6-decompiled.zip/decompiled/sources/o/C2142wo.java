package o;

/* renamed from: o.wo, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C2142wo extends AbstractC1010dy implements Ly {
    private static final C2142wo zbb;
    private int zbd;
    private C1658ol zbe;
    private C0182Al zbf;
    private C1601no zbg;
    private boolean zbh;
    private byte zbi = 2;

    static {
        C2142wo c2142wo = new C2142wo();
        zbb = c2142wo;
        AbstractC1010dy.YoKzxo(C2142wo.class, c2142wo);
    }

    @Override // o.AbstractC1010dy
    public final Object IEE(int i, Object obj, Object obj2) {
        int i2 = i - 1;
        if (i2 == 0) {
            return Byte.valueOf(this.zbi);
        }
        if (i2 == 2) {
            return AbstractC1010dy.ETF(zbb, "\u0001\u0004\u0000\u0001\u0001\u0004\u0004\u0000\u0000\u0001\u0001ဉ\u0000\u0002ဇ\u0003\u0003ᐉ\u0002\u0004ဉ\u0001", new Object[]{"zbd", "zbe", "zbh", "zbg", "zbf"});
        }
        if (i2 == 3) {
            return new C2142wo();
        }
        AbstractC1901so abstractC1901so = null;
        if (i2 == 4) {
            return new C2021uo(abstractC1901so);
        }
        if (i2 == 5) {
            return zbb;
        }
        this.zbi = obj == null ? (byte) 0 : (byte) 1;
        return null;
    }
}
