package o;

/* renamed from: o.ej, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C1056ej extends Vx implements Ly {
    public /* synthetic */ C1056ej(AbstractC0996dj abstractC0996dj) {
        super(C1117fj.zbb);
    }
}
