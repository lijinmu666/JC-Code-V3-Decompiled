package o;

import java.util.ConcurrentModificationException;
import java.util.Iterator;
import java.util.NoSuchElementException;

/* loaded from: classes.dex */
public abstract class TC implements Iterator {
    public int AZxh;
    public final /* synthetic */ C1687pD ZfxDd;
    public int mjFkc;
    public int wA = -1;

    public /* synthetic */ TC(C1687pD c1687pD, RC rc) {
        this.ZfxDd = c1687pD;
        this.mjFkc = c1687pD.KLFTb;
        this.AZxh = c1687pD.lgHUyS();
    }

    public abstract Object AZxh(int i);

    @Override // java.util.Iterator
    public final boolean hasNext() {
        return this.AZxh >= 0;
    }

    @Override // java.util.Iterator
    public final Object next() {
        wA();
        if (!hasNext()) {
            throw new NoSuchElementException();
        }
        int i = this.AZxh;
        this.wA = i;
        Object objAZxh = AZxh(i);
        this.AZxh = this.ZfxDd.qdMbNW(this.AZxh);
        return objAZxh;
    }

    @Override // java.util.Iterator
    public final void remove() {
        wA();
        XW.ZfxDd(this.wA >= 0, "no calls to next() since the last call to remove()");
        this.mjFkc += 32;
        int i = this.wA;
        C1687pD c1687pD = this.ZfxDd;
        c1687pD.remove(C1687pD.Dt(c1687pD, i));
        this.AZxh--;
        this.wA = -1;
    }

    public final void wA() {
        if (this.ZfxDd.KLFTb != this.mjFkc) {
            throw new ConcurrentModificationException();
        }
    }
}
