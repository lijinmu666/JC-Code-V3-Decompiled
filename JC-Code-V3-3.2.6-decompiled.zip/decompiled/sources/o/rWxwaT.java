package o;

import com.google.android.datatransport.runtime.scheduling.jobscheduling.AlarmManagerSchedulerBroadcastReceiver;

/* loaded from: classes.dex */
public final /* synthetic */ class rWxwaT implements Runnable {
    public static final rWxwaT mjFkc = new rWxwaT();

    public static Runnable mjFkc() {
        return mjFkc;
    }

    @Override // java.lang.Runnable
    public void run() {
        AlarmManagerSchedulerBroadcastReceiver.mjFkc();
    }
}
