package o;

/* renamed from: o.Vo, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0669Vo extends AbstractC1010dy implements Ly {
    private static final C0669Vo zbb;
    private int zbd;
    private C0693Wp zbe;
    private C1967tu zbf;
    private C0320Gl zbg;
    private C0485Np zbh;
    private C1243hp zbi;
    private C0881bp zbj;
    private C0347Hp zbk;
    private byte zbl = 2;

    static {
        C0669Vo c0669Vo = new C0669Vo();
        zbb = c0669Vo;
        AbstractC1010dy.YoKzxo(C0669Vo.class, c0669Vo);
    }

    @Override // o.AbstractC1010dy
    public final Object IEE(int i, Object obj, Object obj2) {
        int i2 = i - 1;
        if (i2 == 0) {
            return Byte.valueOf(this.zbl);
        }
        if (i2 == 2) {
            return AbstractC1010dy.ETF(zbb, "\u0001\u0007\u0000\u0001\u0001\u0007\u0007\u0000\u0000\u0001\u0001ဉ\u0000\u0002ဉ\u0001\u0003ᐉ\u0002\u0004ဉ\u0003\u0005ဉ\u0004\u0006ဉ\u0005\u0007ဉ\u0006", new Object[]{"zbd", "zbe", "zbf", "zbg", "zbh", "zbi", "zbj", "zbk"});
        }
        if (i2 == 3) {
            return new C0669Vo();
        }
        AbstractC0577Ro abstractC0577Ro = null;
        if (i2 == 4) {
            return new C0623To(abstractC0577Ro);
        }
        if (i2 == 5) {
            return zbb;
        }
        this.zbl = obj == null ? (byte) 0 : (byte) 1;
        return null;
    }
}
