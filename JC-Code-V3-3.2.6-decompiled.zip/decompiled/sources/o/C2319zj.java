package o;

/* renamed from: o.zj, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C2319zj extends AbstractC1010dy implements Ly {
    private static final C2319zj zbb;
    private InterfaceC1431ky zbd = AbstractC1010dy.lB();

    static {
        C2319zj c2319zj = new C2319zj();
        zbb = c2319zj;
        AbstractC1010dy.YoKzxo(C2319zj.class, c2319zj);
    }

    @Override // o.AbstractC1010dy
    public final Object IEE(int i, Object obj, Object obj2) {
        int i2 = i - 1;
        if (i2 == 0) {
            return (byte) 1;
        }
        if (i2 == 2) {
            return AbstractC1010dy.ETF(zbb, "\u0000\u0001\u0000\u0000\u0001\u0001\u0001\u0000\u0001\u0000\u0001%", new Object[]{"zbd"});
        }
        if (i2 == 3) {
            return new C2319zj();
        }
        AbstractC2197xj abstractC2197xj = null;
        if (i2 == 4) {
            return new C2258yj(abstractC2197xj);
        }
        if (i2 != 5) {
            return null;
        }
        return zbb;
    }
}
