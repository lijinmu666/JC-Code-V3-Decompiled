package o;

/* renamed from: o.lx, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C1490lx {
    public long AZxh;
    public int KLFTb;
    public final Kx ZfxDd;
    public int mjFkc;
    public Object wA;

    public C1490lx(Kx kx) {
        kx.getClass();
        this.ZfxDd = kx;
    }
}
