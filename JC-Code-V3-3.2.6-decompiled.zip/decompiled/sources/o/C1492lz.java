package o;

/* renamed from: o.lz, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C1492lz extends AbstractC1372jz {
    @Override // o.AbstractC1372jz
    public final void AZxh(Object obj) {
        ((AbstractC1010dy) obj).zbc.lgHUyS();
    }

    @Override // o.AbstractC1372jz
    public final /* bridge */ /* synthetic */ Object mjFkc(Object obj) {
        AbstractC1010dy abstractC1010dy = (AbstractC1010dy) obj;
        C1432kz c1432kz = abstractC1010dy.zbc;
        if (c1432kz != C1432kz.wA()) {
            return c1432kz;
        }
        C1432kz c1432kzJHa = C1432kz.JHa();
        abstractC1010dy.zbc = c1432kzJHa;
        return c1432kzJHa;
    }
}
