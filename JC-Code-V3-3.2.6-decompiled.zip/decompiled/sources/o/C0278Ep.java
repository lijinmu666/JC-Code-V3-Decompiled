package o;

/* renamed from: o.Ep, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0278Ep extends AbstractC1010dy implements Ly {
    private static final C0278Ep zbb;
    private int zbd;
    private float zbe = 0.3f;

    static {
        C0278Ep c0278Ep = new C0278Ep();
        zbb = c0278Ep;
        AbstractC1010dy.YoKzxo(C0278Ep.class, c0278Ep);
    }

    @Override // o.AbstractC1010dy
    public final Object IEE(int i, Object obj, Object obj2) {
        int i2 = i - 1;
        if (i2 == 0) {
            return (byte) 1;
        }
        if (i2 == 2) {
            return AbstractC1010dy.ETF(zbb, "\u0001\u0001\u0000\u0001\u0001\u0001\u0001\u0000\u0000\u0000\u0001ခ\u0000", new Object[]{"zbd", "zbe"});
        }
        if (i2 == 3) {
            return new C0278Ep();
        }
        AbstractC2325zp abstractC2325zp = null;
        if (i2 == 4) {
            return new C0209Bp(abstractC2325zp);
        }
        if (i2 != 5) {
            return null;
        }
        return zbb;
    }
}
