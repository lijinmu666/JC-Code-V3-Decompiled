package o;

/* loaded from: classes.dex */
public abstract class peCqC extends Sx implements W0, InterfaceC1347ja, InterfaceC1560n6 {
}
