package o;

import android.graphics.Paint;

/* renamed from: o.p3, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC1677p3 {
    public static final ThreadLocal mjFkc = new ThreadLocal();

    /* renamed from: o.p3$mjFkc */
    public static class mjFkc {
        public static boolean mjFkc(Paint paint, String str) {
            return paint.hasGlyph(str);
        }
    }

    public static boolean mjFkc(Paint paint, String str) {
        return mjFkc.mjFkc(paint, str);
    }
}
