package o;

import android.graphics.Rect;
import android.transition.Transition;
import android.transition.TransitionManager;
import android.transition.TransitionSet;
import android.view.View;
import android.view.ViewGroup;
import androidx.fragment.app.Fragment;
import java.util.ArrayList;
import java.util.List;

/* renamed from: o.zo, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public class C2324zo extends KbpP {

    /* renamed from: o.zo$AZxh */
    public class AZxh implements Transition.TransitionListener {
        public final /* synthetic */ ArrayList AZxh;
        public final /* synthetic */ View mjFkc;

        public AZxh(View view, ArrayList arrayList) {
            this.mjFkc = view;
            this.AZxh = arrayList;
        }

        @Override // android.transition.Transition.TransitionListener
        public void onTransitionCancel(Transition transition) {
        }

        @Override // android.transition.Transition.TransitionListener
        public void onTransitionEnd(Transition transition) {
            transition.removeListener(this);
            this.mjFkc.setVisibility(8);
            int size = this.AZxh.size();
            for (int i = 0; i < size; i++) {
                ((View) this.AZxh.get(i)).setVisibility(0);
            }
        }

        @Override // android.transition.Transition.TransitionListener
        public void onTransitionPause(Transition transition) {
        }

        @Override // android.transition.Transition.TransitionListener
        public void onTransitionResume(Transition transition) {
        }

        @Override // android.transition.Transition.TransitionListener
        public void onTransitionStart(Transition transition) {
            transition.removeListener(this);
            transition.addListener(this);
        }
    }

    /* renamed from: o.zo$KLFTb */
    public class KLFTb extends Transition.EpicenterCallback {
        public final /* synthetic */ Rect mjFkc;

        public KLFTb(Rect rect) {
            this.mjFkc = rect;
        }

        @Override // android.transition.Transition.EpicenterCallback
        public Rect onGetEpicenter(Transition transition) {
            Rect rect = this.mjFkc;
            if (rect == null || rect.isEmpty()) {
                return null;
            }
            return this.mjFkc;
        }
    }

    /* renamed from: o.zo$ZfxDd */
    public class ZfxDd implements Transition.TransitionListener {
        public final /* synthetic */ Runnable mjFkc;

        public ZfxDd(Runnable runnable) {
            this.mjFkc = runnable;
        }

        @Override // android.transition.Transition.TransitionListener
        public void onTransitionCancel(Transition transition) {
        }

        @Override // android.transition.Transition.TransitionListener
        public void onTransitionEnd(Transition transition) {
            this.mjFkc.run();
        }

        @Override // android.transition.Transition.TransitionListener
        public void onTransitionPause(Transition transition) {
        }

        @Override // android.transition.Transition.TransitionListener
        public void onTransitionResume(Transition transition) {
        }

        @Override // android.transition.Transition.TransitionListener
        public void onTransitionStart(Transition transition) {
        }
    }

    /* renamed from: o.zo$mjFkc */
    public class mjFkc extends Transition.EpicenterCallback {
        public final /* synthetic */ Rect mjFkc;

        public mjFkc(Rect rect) {
            this.mjFkc = rect;
        }

        @Override // android.transition.Transition.EpicenterCallback
        public Rect onGetEpicenter(Transition transition) {
            return this.mjFkc;
        }
    }

    /* renamed from: o.zo$wA */
    public class wA implements Transition.TransitionListener {
        public final /* synthetic */ ArrayList AZxh;
        public final /* synthetic */ ArrayList JHa;
        public final /* synthetic */ Object KLFTb;
        public final /* synthetic */ ArrayList ZfxDd;
        public final /* synthetic */ Object mjFkc;
        public final /* synthetic */ Object wA;

        public wA(Object obj, ArrayList arrayList, Object obj2, ArrayList arrayList2, Object obj3, ArrayList arrayList3) {
            this.mjFkc = obj;
            this.AZxh = arrayList;
            this.wA = obj2;
            this.ZfxDd = arrayList2;
            this.KLFTb = obj3;
            this.JHa = arrayList3;
        }

        @Override // android.transition.Transition.TransitionListener
        public void onTransitionCancel(Transition transition) {
        }

        @Override // android.transition.Transition.TransitionListener
        public void onTransitionEnd(Transition transition) {
            transition.removeListener(this);
        }

        @Override // android.transition.Transition.TransitionListener
        public void onTransitionPause(Transition transition) {
        }

        @Override // android.transition.Transition.TransitionListener
        public void onTransitionResume(Transition transition) {
        }

        @Override // android.transition.Transition.TransitionListener
        public void onTransitionStart(Transition transition) {
            Object obj = this.mjFkc;
            if (obj != null) {
                C2324zo.this.huTpC(obj, this.AZxh, null);
            }
            Object obj2 = this.wA;
            if (obj2 != null) {
                C2324zo.this.huTpC(obj2, this.ZfxDd, null);
            }
            Object obj3 = this.KLFTb;
            if (obj3 != null) {
                C2324zo.this.huTpC(obj3, this.JHa, null);
            }
        }
    }

    public static boolean Ucbh(Transition transition) {
        return (KbpP.qdMbNW(transition.getTargetIds()) && KbpP.qdMbNW(transition.getTargetNames()) && KbpP.qdMbNW(transition.getTargetTypes())) ? false : true;
    }

    @Override // o.KbpP
    public void AZxh(Object obj, ArrayList arrayList) {
        Transition transition = (Transition) obj;
        if (transition == null) {
            return;
        }
        int i = 0;
        if (transition instanceof TransitionSet) {
            TransitionSet transitionSet = (TransitionSet) transition;
            int transitionCount = transitionSet.getTransitionCount();
            while (i < transitionCount) {
                AZxh(transitionSet.getTransitionAt(i), arrayList);
                i++;
            }
            return;
        }
        if (Ucbh(transition) || !KbpP.qdMbNW(transition.getTargets())) {
            return;
        }
        int size = arrayList.size();
        while (i < size) {
            transition.addTarget((View) arrayList.get(i));
            i++;
        }
    }

    @Override // o.KbpP
    public Object Dt(Object obj, Object obj2, Object obj3) {
        Transition ordering = (Transition) obj;
        Transition transition = (Transition) obj2;
        Transition transition2 = (Transition) obj3;
        if (ordering != null && transition != null) {
            ordering = new TransitionSet().addTransition(ordering).addTransition(transition).setOrdering(1);
        } else if (ordering == null) {
            ordering = transition != null ? transition : null;
        }
        if (transition2 == null) {
            return ordering;
        }
        TransitionSet transitionSet = new TransitionSet();
        if (ordering != null) {
            transitionSet.addTransition(ordering);
        }
        transitionSet.addTransition(transition2);
        return transitionSet;
    }

    @Override // o.KbpP
    public Object ETF(Object obj, Object obj2, Object obj3) {
        TransitionSet transitionSet = new TransitionSet();
        if (obj != null) {
            transitionSet.addTransition((Transition) obj);
        }
        if (obj2 != null) {
            transitionSet.addTransition((Transition) obj2);
        }
        if (obj3 != null) {
            transitionSet.addTransition((Transition) obj3);
        }
        return transitionSet;
    }

    @Override // o.KbpP
    public Object JHa(Object obj) {
        if (obj != null) {
            return ((Transition) obj).clone();
        }
        return null;
    }

    @Override // o.KbpP
    public boolean KLFTb(Object obj) {
        return obj instanceof Transition;
    }

    @Override // o.KbpP
    public void MiMN(Object obj, View view, ArrayList arrayList) {
        ((Transition) obj).addListener(new AZxh(view, arrayList));
    }

    @Override // o.KbpP
    public void Pq(Object obj, View view, ArrayList arrayList) {
        TransitionSet transitionSet = (TransitionSet) obj;
        List<View> targets = transitionSet.getTargets();
        targets.clear();
        int size = arrayList.size();
        for (int i = 0; i < size; i++) {
            KbpP.ZfxDd(targets, (View) arrayList.get(i));
        }
        targets.add(view);
        arrayList.add(view);
        AZxh(transitionSet, arrayList);
    }

    @Override // o.KbpP
    public void YoKzxo(Object obj, Object obj2, ArrayList arrayList, Object obj3, ArrayList arrayList2, Object obj4, ArrayList arrayList3) {
        ((Transition) obj).addListener(new wA(obj2, arrayList, obj3, arrayList2, obj4, arrayList3));
    }

    @Override // o.KbpP
    public void diqgf(Object obj, ArrayList arrayList, ArrayList arrayList2) {
        TransitionSet transitionSet = (TransitionSet) obj;
        if (transitionSet != null) {
            transitionSet.getTargets().clear();
            transitionSet.getTargets().addAll(arrayList2);
            huTpC(transitionSet, arrayList, arrayList2);
        }
    }

    @Override // o.KbpP
    public Object eyqo(Object obj) {
        if (obj == null) {
            return null;
        }
        TransitionSet transitionSet = new TransitionSet();
        transitionSet.addTransition((Transition) obj);
        return transitionSet;
    }

    @Override // o.KbpP
    public void fehf(Fragment fragment, Object obj, BxruE bxruE, Runnable runnable) {
        ((Transition) obj).addListener(new ZfxDd(runnable));
    }

    public void huTpC(Object obj, ArrayList arrayList, ArrayList arrayList2) {
        List<View> targets;
        Transition transition = (Transition) obj;
        int i = 0;
        if (transition instanceof TransitionSet) {
            TransitionSet transitionSet = (TransitionSet) transition;
            int transitionCount = transitionSet.getTransitionCount();
            while (i < transitionCount) {
                huTpC(transitionSet.getTransitionAt(i), arrayList, arrayList2);
                i++;
            }
            return;
        }
        if (Ucbh(transition) || (targets = transition.getTargets()) == null || targets.size() != arrayList.size() || !targets.containsAll(arrayList)) {
            return;
        }
        int size = arrayList2 == null ? 0 : arrayList2.size();
        while (i < size) {
            transition.addTarget((View) arrayList2.get(i));
            i++;
        }
        for (int size2 = arrayList.size() - 1; size2 >= 0; size2--) {
            transition.removeTarget((View) arrayList.get(size2));
        }
    }

    @Override // o.KbpP
    public void mjFkc(Object obj, View view) {
        if (obj != null) {
            ((Transition) obj).addTarget(view);
        }
    }

    @Override // o.KbpP
    public void qGY(Object obj, View view) {
        if (view != null) {
            Rect rect = new Rect();
            lgHUyS(view, rect);
            ((Transition) obj).setEpicenterCallback(new mjFkc(rect));
        }
    }

    @Override // o.KbpP
    public void rkYL(Object obj, Rect rect) {
        if (obj != null) {
            ((Transition) obj).setEpicenterCallback(new KLFTb(rect));
        }
    }

    @Override // o.KbpP
    public void wA(ViewGroup viewGroup, Object obj) {
        TransitionManager.beginDelayedTransition(viewGroup, (Transition) obj);
    }
}
