package o;

/* renamed from: o.cC, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public @interface InterfaceC0904cC {
    int zza();

    YB zzb() default YB.DEFAULT;
}
