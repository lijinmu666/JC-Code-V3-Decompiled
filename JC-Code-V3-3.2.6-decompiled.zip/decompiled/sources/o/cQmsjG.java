package o;

import android.graphics.RectF;

/* loaded from: classes.dex */
public interface cQmsjG {
    float mjFkc(RectF rectF);
}
