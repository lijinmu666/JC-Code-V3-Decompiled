package o;

import android.os.Bundle;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.wA;

/* loaded from: classes.dex */
public class BEUaYa implements InterfaceC1560n6, InterfaceC1347ja {
    public final C1288ia AZxh;
    public final Fragment mjFkc;
    public androidx.lifecycle.JHa wA = null;
    public C1500m6 ZfxDd = null;

    public BEUaYa(Fragment fragment, C1288ia c1288ia) {
        this.mjFkc = fragment;
        this.AZxh = c1288ia;
    }

    public void AZxh(wA.mjFkc mjfkc) {
        this.wA.lgHUyS(mjfkc);
    }

    @Override // o.W0
    public androidx.lifecycle.wA JHa() {
        ZfxDd();
        return this.wA;
    }

    public boolean KLFTb() {
        return this.wA != null;
    }

    public void ZfxDd() {
        if (this.wA == null) {
            this.wA = new androidx.lifecycle.JHa(this);
            this.ZfxDd = C1500m6.mjFkc(this);
        }
    }

    public void lgHUyS(Bundle bundle) {
        this.ZfxDd.KLFTb(bundle);
    }

    @Override // o.InterfaceC1560n6
    public androidx.savedstate.mjFkc mjFkc() {
        ZfxDd();
        return this.ZfxDd.AZxh();
    }

    @Override // o.InterfaceC1347ja
    public C1288ia wA() {
        ZfxDd();
        return this.AZxh;
    }

    public void xJ(Bundle bundle) {
        this.ZfxDd.ZfxDd(bundle);
    }
}
