package o;

import org.conscrypt.BuildConfig;

/* renamed from: o.tt, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C1966tt extends AbstractC1010dy implements Ly {
    private static final C1966tt zbb;
    private int zbd;
    private C1726pt zbk;
    private int zbm;
    private int zbn;
    private C1248hu zbo;
    private C1367ju zbp;
    private C0282Et zbs;
    private int zbt;
    private byte zbw = 2;
    private String zbe = BuildConfig.FLAVOR;
    private String zbf = BuildConfig.FLAVOR;
    private InterfaceC1491ly zbg = AbstractC1010dy.wJVbdd();
    private InterfaceC1491ly zbh = AbstractC1010dy.wJVbdd();
    private InterfaceC1491ly zbi = AbstractC1010dy.wJVbdd();
    private InterfaceC1491ly zbj = AbstractC1010dy.wJVbdd();
    private InterfaceC1491ly zbl = AbstractC1010dy.wJVbdd();
    private InterfaceC1491ly zbq = AbstractC1010dy.wJVbdd();
    private String zbr = BuildConfig.FLAVOR;
    private InterfaceC1491ly zbu = AbstractC1010dy.wJVbdd();
    private InterfaceC1491ly zbv = AbstractC1010dy.wJVbdd();

    static {
        C1966tt c1966tt = new C1966tt();
        zbb = c1966tt;
        AbstractC1010dy.YoKzxo(C1966tt.class, c1966tt);
    }

    @Override // o.AbstractC1010dy
    public final Object IEE(int i, Object obj, Object obj2) {
        int i2 = i - 1;
        if (i2 == 0) {
            return Byte.valueOf(this.zbw);
        }
        if (i2 == 2) {
            return AbstractC1010dy.ETF(zbb, "\u0000\u0012\u0000\u0001\u0001ϭ\u0012\u0000\b\u0003\u0001Ȉ\u0002Ȉ\u0003Ț\u0004Ț\u0005Ț\u0006Ț\u0007ᐉ\u0000\b\u001b\t\u0004\n\u0004\u000bᐉ\u0001\fᐉ\u0002\r\u001b\u000eȈ\u000fဉ\u0003\u0010\u0004\u0011ȚϭȚ", new Object[]{"zbd", "zbe", "zbf", "zbg", "zbh", "zbi", "zbj", "zbk", "zbl", C1430kx.class, "zbm", "zbn", "zbo", "zbp", "zbq", C2268yt.class, "zbr", "zbs", "zbt", "zbu", "zbv"});
        }
        if (i2 == 3) {
            return new C1966tt();
        }
        AbstractC1786qt abstractC1786qt = null;
        if (i2 == 4) {
            return new C1906st(abstractC1786qt);
        }
        if (i2 == 5) {
            return zbb;
        }
        this.zbw = obj == null ? (byte) 0 : (byte) 1;
        return null;
    }
}
