package o;

/* renamed from: o.jn, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C1360jn extends AbstractC1010dy implements Ly {
    private static final C1360jn zbb;
    private int zbd;
    private C1597nk zbe;
    private C0671Vq zbf;
    private float zbi;
    private Cz zbm;
    private String zbg = "en";
    private int zbh = -1;
    private InterfaceC1491ly zbj = AbstractC1010dy.wJVbdd();
    private InterfaceC1491ly zbk = AbstractC1010dy.wJVbdd();
    private int zbl = -1;

    static {
        C1360jn c1360jn = new C1360jn();
        zbb = c1360jn;
        AbstractC1010dy.YoKzxo(C1360jn.class, c1360jn);
    }

    @Override // o.AbstractC1010dy
    public final Object IEE(int i, Object obj, Object obj2) {
        int i2 = i - 1;
        if (i2 == 0) {
            return (byte) 1;
        }
        if (i2 == 2) {
            return AbstractC1010dy.ETF(zbb, "\u0004\t\u0000\u0001\u0001\t\t\u0000\u0002\u0000\u0001ဉ\u0001\u0002ဈ\u0002\u0003င\u0003\u0004ခ\u0004\u0005\u001a\u0006\u001a\u0007င\u0005\bဉ\u0006\tဉ\u0000", new Object[]{"zbd", "zbf", "zbg", "zbh", "zbi", "zbj", "zbk", "zbl", "zbm", "zbe"});
        }
        if (i2 == 3) {
            return new C1360jn();
        }
        AbstractC1121fn abstractC1121fn = null;
        if (i2 == 4) {
            return new C1241hn(abstractC1121fn);
        }
        if (i2 != 5) {
            return null;
        }
        return zbb;
    }
}
