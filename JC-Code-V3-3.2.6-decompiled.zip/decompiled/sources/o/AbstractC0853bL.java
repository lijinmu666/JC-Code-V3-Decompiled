package o;

import androidx.fragment.app.Fragment;

/* renamed from: o.bL, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC0853bL {
    public static final W6 mjFkc = new W6();

    public static boolean AZxh(ClassLoader classLoader, String str) {
        try {
            return Fragment.class.isAssignableFrom(wA(classLoader, str));
        } catch (ClassNotFoundException unused) {
            return false;
        }
    }

    public static Class wA(ClassLoader classLoader, String str) throws ClassNotFoundException {
        W6 w6 = mjFkc;
        W6 w62 = (W6) w6.get(classLoader);
        if (w62 == null) {
            w62 = new W6();
            w6.put(classLoader, w62);
        }
        Class cls = (Class) w62.get(str);
        if (cls != null) {
            return cls;
        }
        Class<?> cls2 = Class.forName(str, false, classLoader);
        w62.put(str, cls2);
        return cls2;
    }

    public abstract Fragment mjFkc(ClassLoader classLoader, String str);
}
