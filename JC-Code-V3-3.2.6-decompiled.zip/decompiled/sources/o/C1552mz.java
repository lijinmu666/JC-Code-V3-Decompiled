package o;

import android.graphics.Rect;
import android.text.method.TransformationMethod;
import android.view.View;

/* renamed from: o.mz, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public class C1552mz implements TransformationMethod {
    public final TransformationMethod mjFkc;

    public C1552mz(TransformationMethod transformationMethod) {
        this.mjFkc = transformationMethod;
    }

    @Override // android.text.method.TransformationMethod
    public CharSequence getTransformation(CharSequence charSequence, View view) {
        if (view.isInEditMode()) {
            return charSequence;
        }
        TransformationMethod transformationMethod = this.mjFkc;
        if (transformationMethod != null) {
            charSequence = transformationMethod.getTransformation(charSequence, view);
        }
        return (charSequence == null || androidx.emoji2.text.wA.AZxh().ZfxDd() != 1) ? charSequence : androidx.emoji2.text.wA.AZxh().rkYL(charSequence);
    }

    public TransformationMethod mjFkc() {
        return this.mjFkc;
    }

    @Override // android.text.method.TransformationMethod
    public void onFocusChanged(View view, CharSequence charSequence, boolean z, int i, Rect rect) {
        TransformationMethod transformationMethod = this.mjFkc;
        if (transformationMethod != null) {
            transformationMethod.onFocusChanged(view, charSequence, z, i, rect);
        }
    }
}
