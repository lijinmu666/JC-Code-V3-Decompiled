package o;

/* renamed from: o.of, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C1652of extends AbstractC1010dy implements Ly {
    private static final C1652of zbb;
    private byte zbe = 2;
    private InterfaceC1491ly zbd = AbstractC1010dy.wJVbdd();

    static {
        C1652of c1652of = new C1652of();
        zbb = c1652of;
        AbstractC1010dy.YoKzxo(C1652of.class, c1652of);
    }

    @Override // o.AbstractC1010dy
    public final Object IEE(int i, Object obj, Object obj2) {
        int i2 = i - 1;
        if (i2 == 0) {
            return Byte.valueOf(this.zbe);
        }
        if (i2 == 2) {
            return AbstractC1010dy.ETF(zbb, "\u0001\u0001\u0000\u0000\u0001\u0001\u0001\u0000\u0001\u0001\u0001Л", new Object[]{"zbd", C1472lf.class});
        }
        if (i2 == 3) {
            return new C1652of();
        }
        AbstractC1532mf abstractC1532mf = null;
        if (i2 == 4) {
            return new C1592nf(abstractC1532mf);
        }
        if (i2 == 5) {
            return zbb;
        }
        this.zbe = obj == null ? (byte) 0 : (byte) 1;
        return null;
    }
}
