package o;

/* renamed from: o.Sa, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract /* synthetic */ class AbstractC0586Sa {
}
