package o;

/* renamed from: o.yD, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC2228yD {
}
