package o;

/* renamed from: o.gs, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C1186gs extends AbstractC1010dy implements Ly {
    private static final C1186gs zbb;
    private byte zbe = 2;
    private InterfaceC1491ly zbd = AbstractC1010dy.wJVbdd();

    static {
        C1186gs c1186gs = new C1186gs();
        zbb = c1186gs;
        AbstractC1010dy.YoKzxo(C1186gs.class, c1186gs);
    }

    @Override // o.AbstractC1010dy
    public final Object IEE(int i, Object obj, Object obj2) {
        int i2 = i - 1;
        if (i2 == 0) {
            return Byte.valueOf(this.zbe);
        }
        if (i2 == 2) {
            return AbstractC1010dy.ETF(zbb, "\u0001\u0001\u0000\u0000\u0001\u0001\u0001\u0000\u0001\u0001\u0001Л", new Object[]{"zbd", C1004ds.class});
        }
        if (i2 == 3) {
            return new C1186gs();
        }
        AbstractC1065es abstractC1065es = null;
        if (i2 == 4) {
            return new C1126fs(abstractC1065es);
        }
        if (i2 == 5) {
            return zbb;
        }
        this.zbe = obj == null ? (byte) 0 : (byte) 1;
        return null;
    }
}
