package o;

/* renamed from: o.bg, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0872bg extends Zx implements Ly {
    private static final C0872bg zbd;
    private byte zbf = 2;
    private InterfaceC1491ly zbe = AbstractC1010dy.wJVbdd();

    static {
        C0872bg c0872bg = new C0872bg();
        zbd = c0872bg;
        AbstractC1010dy.YoKzxo(C0872bg.class, c0872bg);
    }

    public static C0872bg CqaNbM() {
        return zbd;
    }

    @Override // o.AbstractC1010dy
    public final Object IEE(int i, Object obj, Object obj2) {
        int i2 = i - 1;
        if (i2 == 0) {
            return Byte.valueOf(this.zbf);
        }
        if (i2 == 2) {
            return AbstractC1010dy.ETF(zbd, "\u0001\u0001\u0000\u0000\u0003\u0003\u0001\u0000\u0001\u0000\u0003\u001b", new Object[]{"zbe", C0811ag.class});
        }
        if (i2 == 3) {
            return new C0872bg();
        }
        AbstractC0521Pf abstractC0521Pf = null;
        if (i2 == 4) {
            return new C0729Yf(abstractC0521Pf);
        }
        if (i2 == 5) {
            return zbd;
        }
        this.zbf = obj == null ? (byte) 0 : (byte) 1;
        return null;
    }
}
