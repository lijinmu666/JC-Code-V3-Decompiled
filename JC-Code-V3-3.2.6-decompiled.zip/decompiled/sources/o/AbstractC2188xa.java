package o;

/* renamed from: o.xa, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC2188xa extends AbstractC2128wa {
}
