package o;

import android.os.IInterface;

/* loaded from: classes.dex */
public interface GN extends IInterface {
    C1215hK ETF(F f, C2002uS c2002uS);
}
