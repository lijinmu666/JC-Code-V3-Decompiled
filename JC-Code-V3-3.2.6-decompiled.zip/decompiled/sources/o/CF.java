package o;

import android.os.Parcel;
import android.os.Parcelable;

/* loaded from: classes.dex */
public final class CF extends ETF {
    public static final Parcelable.Creator<CF> CREATOR = new JG();
    public int AZxh;
    public int KLFTb;
    public long ZfxDd;
    public int mjFkc;
    public int wA;

    public CF(int i, int i2, int i3, long j, int i4) {
        this.mjFkc = i;
        this.AZxh = i2;
        this.wA = i3;
        this.ZfxDd = j;
        this.KLFTb = i4;
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i) {
        int iMjFkc = AbstractC1380k6.mjFkc(parcel);
        AbstractC1380k6.xJ(parcel, 2, this.mjFkc);
        AbstractC1380k6.xJ(parcel, 3, this.AZxh);
        AbstractC1380k6.xJ(parcel, 4, this.wA);
        AbstractC1380k6.qdMbNW(parcel, 5, this.ZfxDd);
        AbstractC1380k6.xJ(parcel, 6, this.KLFTb);
        AbstractC1380k6.AZxh(parcel, iMjFkc);
    }
}
