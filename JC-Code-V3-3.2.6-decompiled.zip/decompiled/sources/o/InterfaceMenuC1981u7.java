package o;

import android.view.Menu;

/* renamed from: o.u7, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public interface InterfaceMenuC1981u7 extends Menu {
}
