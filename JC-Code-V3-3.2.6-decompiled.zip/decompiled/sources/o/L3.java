package o;

/* loaded from: classes.dex */
public enum L3 {
    DEFAULT,
    VERY_LOW,
    HIGHEST
}
