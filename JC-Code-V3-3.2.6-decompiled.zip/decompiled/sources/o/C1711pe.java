package o;

/* renamed from: o.pe, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C1711pe extends Vx implements Ly {
    public /* synthetic */ C1711pe(AbstractC0727Yd abstractC0727Yd) {
        super(C1891se.zbb);
    }
}
