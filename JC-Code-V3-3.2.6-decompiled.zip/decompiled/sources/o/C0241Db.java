package o;

import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import java.util.Locale;

/* renamed from: o.Db, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public class C0241Db extends RecyclerView.lgHUyS {
    public final com.google.android.material.datepicker.AZxh ZfxDd;

    /* renamed from: o.Db$mjFkc */
    public static class mjFkc extends RecyclerView.mByQ {
        public final TextView eyqo;

        public mjFkc(TextView textView) {
            super(textView);
            this.eyqo = textView;
        }
    }

    public C0241Db(com.google.android.material.datepicker.AZxh aZxh) {
        this.ZfxDd = aZxh;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.lgHUyS
    /* renamed from: Gd, reason: merged with bridge method [inline-methods] */
    public mjFkc VA(ViewGroup viewGroup, int i) {
        return new mjFkc((TextView) LayoutInflater.from(viewGroup.getContext()).inflate(G4.fehf, viewGroup, false));
    }

    public int Ucbh(int i) {
        return this.ZfxDd.IyS().xJ().wA + i;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.lgHUyS
    public int ZfxDd() {
        return this.ZfxDd.IyS().lgHUyS();
    }

    public int eyqo(int i) {
        return i - this.ZfxDd.IyS().xJ().wA;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.lgHUyS
    /* renamed from: huTpC, reason: merged with bridge method [inline-methods] */
    public void Dt(mjFkc mjfkc, int i) {
        int iUcbh = Ucbh(i);
        mjfkc.eyqo.setText(String.format(Locale.getDefault(), "%d", Integer.valueOf(iUcbh)));
        TextView textView = mjfkc.eyqo;
        textView.setContentDescription(AbstractC2309zZ.KLFTb(textView.getContext(), iUcbh));
        uxlM uxlmTAfC = this.ZfxDd.tAfC();
        if (E9.JHa().get(1) == iUcbh) {
            C0675Vu c0675Vu = uxlmTAfC.JHa;
        } else {
            C0675Vu c0675Vu2 = uxlmTAfC.ZfxDd;
        }
        this.ZfxDd.dGDT();
        throw null;
    }
}
