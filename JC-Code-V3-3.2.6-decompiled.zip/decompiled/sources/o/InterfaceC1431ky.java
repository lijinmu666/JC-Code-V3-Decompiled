package o;

/* renamed from: o.ky, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public interface InterfaceC1431ky extends InterfaceC1491ly {
}
