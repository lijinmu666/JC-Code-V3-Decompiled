package o;

import android.app.PendingIntent;
import android.os.Parcel;
import android.os.Parcelable;

/* renamed from: o.oD, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C1627oD implements Parcelable.Creator {
    @Override // android.os.Parcelable.Creator
    public final /* bridge */ /* synthetic */ Object createFromParcel(Parcel parcel) {
        int iIEE = AbstractC1319j6.IEE(parcel);
        PendingIntent pendingIntent = null;
        int iYoKzxo = 0;
        int iYoKzxo2 = 0;
        String strZfxDd = null;
        while (parcel.dataPosition() < iIEE) {
            int iVA = AbstractC1319j6.VA(parcel);
            int iQdMbNW = AbstractC1319j6.qdMbNW(iVA);
            if (iQdMbNW == 1) {
                iYoKzxo = AbstractC1319j6.YoKzxo(parcel, iVA);
            } else if (iQdMbNW == 2) {
                iYoKzxo2 = AbstractC1319j6.YoKzxo(parcel, iVA);
            } else if (iQdMbNW == 3) {
                pendingIntent = (PendingIntent) AbstractC1319j6.wA(parcel, iVA, PendingIntent.CREATOR);
            } else if (iQdMbNW != 4) {
                AbstractC1319j6.fehf(parcel, iVA);
            } else {
                strZfxDd = AbstractC1319j6.ZfxDd(parcel, iVA);
            }
        }
        AbstractC1319j6.lgHUyS(parcel, iIEE);
        return new eEOGOh(iYoKzxo, iYoKzxo2, pendingIntent, strZfxDd);
    }

    @Override // android.os.Parcelable.Creator
    public final /* synthetic */ Object[] newArray(int i) {
        return new eEOGOh[i];
    }
}
