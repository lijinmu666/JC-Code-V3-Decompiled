package o;

import o.InterfaceC2283z7;

/* renamed from: o.vb, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final /* synthetic */ class C2069vb implements InterfaceC2283z7.mjFkc {
    public final C2129wb mjFkc;

    public C2069vb(C2129wb c2129wb) {
        this.mjFkc = c2129wb;
    }

    public static InterfaceC2283z7.mjFkc AZxh(C2129wb c2129wb) {
        return new C2069vb(c2129wb);
    }

    @Override // o.InterfaceC2283z7.mjFkc
    public Object mjFkc() {
        return C2129wb.AZxh(this.mjFkc);
    }
}
