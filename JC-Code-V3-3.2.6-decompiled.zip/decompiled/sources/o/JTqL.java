package o;

import android.content.ContentProviderClient;
import android.content.ContentUris;
import android.content.Context;
import android.content.pm.PackageManager;
import android.content.pm.ProviderInfo;
import android.content.pm.Signature;
import android.content.res.Resources;
import android.database.Cursor;
import android.net.Uri;
import android.os.CancellationSignal;
import android.os.RemoteException;
import android.util.Log;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import o.Tz;

/* loaded from: classes.dex */
public abstract class JTqL {
    public static final Comparator mjFkc = new Comparator() { // from class: o.MoUZ
        @Override // java.util.Comparator
        public final int compare(Object obj, Object obj2) {
            return JTqL.xJ((byte[]) obj, (byte[]) obj2);
        }
    };

    public static class AZxh implements mjFkc {
        public final ContentProviderClient mjFkc;

        public AZxh(Context context, Uri uri) {
            this.mjFkc = context.getContentResolver().acquireUnstableContentProviderClient(uri);
        }

        @Override // o.JTqL.mjFkc
        public Cursor AZxh(Uri uri, String[] strArr, String str, String[] strArr2, String str2, CancellationSignal cancellationSignal) {
            ContentProviderClient contentProviderClient = this.mjFkc;
            if (contentProviderClient == null) {
                return null;
            }
            try {
                return contentProviderClient.query(uri, strArr, str, strArr2, str2, cancellationSignal);
            } catch (RemoteException e) {
                Log.w("FontsProvider", "Unable to query the content provider", e);
                return null;
            }
        }

        @Override // o.JTqL.mjFkc
        public void close() {
            ContentProviderClient contentProviderClient = this.mjFkc;
            if (contentProviderClient != null) {
                contentProviderClient.close();
            }
        }
    }

    public interface mjFkc {
        static mjFkc mjFkc(Context context, Uri uri) {
            return new AZxh(context, uri);
        }

        Cursor AZxh(Uri uri, String[] strArr, String str, String[] strArr2, String str2, CancellationSignal cancellationSignal);

        void close();
    }

    public static List AZxh(Signature[] signatureArr) {
        ArrayList arrayList = new ArrayList();
        for (Signature signature : signatureArr) {
            arrayList.add(signature.toByteArray());
        }
        return arrayList;
    }

    public static ProviderInfo JHa(PackageManager packageManager, avDfWJ avdfwj, Resources resources) throws PackageManager.NameNotFoundException {
        String strKLFTb = avdfwj.KLFTb();
        ProviderInfo providerInfoResolveContentProvider = packageManager.resolveContentProvider(strKLFTb, 0);
        if (providerInfoResolveContentProvider == null) {
            throw new PackageManager.NameNotFoundException("No package found for authority: " + strKLFTb);
        }
        if (!providerInfoResolveContentProvider.packageName.equals(avdfwj.JHa())) {
            throw new PackageManager.NameNotFoundException("Found content provider " + strKLFTb + ", but package was not " + avdfwj.JHa());
        }
        List listAZxh = AZxh(packageManager.getPackageInfo(providerInfoResolveContentProvider.packageName, 64).signatures);
        Collections.sort(listAZxh, mjFkc);
        List listZfxDd = ZfxDd(avdfwj, resources);
        for (int i = 0; i < listZfxDd.size(); i++) {
            ArrayList arrayList = new ArrayList((Collection) listZfxDd.get(i));
            Collections.sort(arrayList, mjFkc);
            if (wA(listAZxh, arrayList)) {
                return providerInfoResolveContentProvider;
            }
        }
        return null;
    }

    public static Tz.mjFkc KLFTb(Context context, avDfWJ avdfwj, CancellationSignal cancellationSignal) throws PackageManager.NameNotFoundException {
        ProviderInfo providerInfoJHa = JHa(context.getPackageManager(), avdfwj, context.getResources());
        return providerInfoJHa == null ? Tz.mjFkc.mjFkc(1, null) : Tz.mjFkc.mjFkc(0, lgHUyS(context, avdfwj, providerInfoJHa.authority, cancellationSignal));
    }

    public static List ZfxDd(avDfWJ avdfwj, Resources resources) {
        return avdfwj.AZxh() != null ? avdfwj.AZxh() : IRE.wA(resources, avdfwj.wA());
    }

    /* JADX WARN: Removed duplicated region for block: B:29:0x00d1  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static Tz.AZxh[] lgHUyS(Context context, avDfWJ avdfwj, String str, CancellationSignal cancellationSignal) {
        ArrayList arrayList;
        Uri uriWithAppendedId;
        boolean z;
        ArrayList arrayList2 = new ArrayList();
        Uri uriBuild = new Uri.Builder().scheme("content").authority(str).build();
        Uri uriBuild2 = new Uri.Builder().scheme("content").authority(str).appendPath("file").build();
        mjFkc mjFkc2 = mjFkc.mjFkc(context, uriBuild);
        Cursor cursorAZxh = null;
        try {
            cursorAZxh = mjFkc2.AZxh(uriBuild, new String[]{"_id", "file_id", "font_ttc_index", "font_variation_settings", "font_weight", "font_italic", "result_code"}, "query = ?", new String[]{avdfwj.xJ()}, null, cancellationSignal);
            if (cursorAZxh != null && cursorAZxh.getCount() > 0) {
                int columnIndex = cursorAZxh.getColumnIndex("result_code");
                ArrayList arrayList3 = new ArrayList();
                int columnIndex2 = cursorAZxh.getColumnIndex("_id");
                int columnIndex3 = cursorAZxh.getColumnIndex("file_id");
                int columnIndex4 = cursorAZxh.getColumnIndex("font_ttc_index");
                int columnIndex5 = cursorAZxh.getColumnIndex("font_weight");
                int columnIndex6 = cursorAZxh.getColumnIndex("font_italic");
                while (cursorAZxh.moveToNext()) {
                    int i = columnIndex != -1 ? cursorAZxh.getInt(columnIndex) : 0;
                    int i2 = columnIndex4 != -1 ? cursorAZxh.getInt(columnIndex4) : 0;
                    if (columnIndex3 == -1) {
                        arrayList = arrayList3;
                        uriWithAppendedId = ContentUris.withAppendedId(uriBuild, cursorAZxh.getLong(columnIndex2));
                    } else {
                        arrayList = arrayList3;
                        uriWithAppendedId = ContentUris.withAppendedId(uriBuild2, cursorAZxh.getLong(columnIndex3));
                    }
                    int i3 = columnIndex5 != -1 ? cursorAZxh.getInt(columnIndex5) : 400;
                    if (columnIndex6 != -1) {
                        z = true;
                        if (cursorAZxh.getInt(columnIndex6) != 1) {
                            z = false;
                        }
                    }
                    Tz.AZxh aZxhMjFkc = Tz.AZxh.mjFkc(uriWithAppendedId, i2, i3, z, i);
                    arrayList3 = arrayList;
                    arrayList3.add(aZxhMjFkc);
                }
                arrayList2 = arrayList3;
            }
            if (cursorAZxh != null) {
                cursorAZxh.close();
            }
            mjFkc2.close();
            return (Tz.AZxh[]) arrayList2.toArray(new Tz.AZxh[0]);
        } catch (Throwable th) {
            if (cursorAZxh != null) {
                cursorAZxh.close();
            }
            mjFkc2.close();
            throw th;
        }
    }

    public static boolean wA(List list, List list2) {
        if (list.size() != list2.size()) {
            return false;
        }
        for (int i = 0; i < list.size(); i++) {
            if (!Arrays.equals((byte[]) list.get(i), (byte[]) list2.get(i))) {
                return false;
            }
        }
        return true;
    }

    public static /* synthetic */ int xJ(byte[] bArr, byte[] bArr2) {
        if (bArr.length != bArr2.length) {
            return bArr.length - bArr2.length;
        }
        for (int i = 0; i < bArr.length; i++) {
            byte b = bArr[i];
            byte b2 = bArr2[i];
            if (b != b2) {
                return b - b2;
            }
        }
        return 0;
    }
}
