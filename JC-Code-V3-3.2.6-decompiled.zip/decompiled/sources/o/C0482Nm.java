package o;

/* renamed from: o.Nm, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0482Nm implements InterfaceC1252hy {
    public static final InterfaceC1252hy mjFkc = new C0482Nm();

    @Override // o.InterfaceC1252hy
    public final boolean mjFkc(int i) {
        return i == 0 || i == 1 || i == 2 || i == 3;
    }
}
