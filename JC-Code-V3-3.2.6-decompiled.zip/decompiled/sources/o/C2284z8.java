package o;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import java.lang.ref.WeakReference;

/* renamed from: o.z8, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public class C2284z8 extends AbstractC2100w5 {
    public final WeakReference AZxh;

    public C2284z8(Context context, Resources resources) {
        super(resources);
        this.AZxh = new WeakReference(context);
    }

    @Override // android.content.res.Resources
    public Drawable getDrawable(int i) {
        Drawable drawableMjFkc = mjFkc(i);
        Context context = (Context) this.AZxh.get();
        if (drawableMjFkc != null && context != null) {
            C1858s5.xJ().Ucbh(context, i, drawableMjFkc);
        }
        return drawableMjFkc;
    }
}
