package o;

/* renamed from: o.Ov, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0514Ov extends AbstractC1010dy implements Ly {
    private static final C0514Ov zbb;
    private InterfaceC1491ly zbd = AbstractC1010dy.wJVbdd();
    private int zbe;

    static {
        C0514Ov c0514Ov = new C0514Ov();
        zbb = c0514Ov;
        AbstractC1010dy.YoKzxo(C0514Ov.class, c0514Ov);
    }

    @Override // o.AbstractC1010dy
    public final Object IEE(int i, Object obj, Object obj2) {
        int i2 = i - 1;
        if (i2 == 0) {
            return (byte) 1;
        }
        if (i2 == 2) {
            return AbstractC1010dy.ETF(zbb, "\u0004\u0002\u0000\u0000\u0001\u0002\u0002\u0000\u0001\u0000\u0001\u001b\u0002\f", new Object[]{"zbd", C1188gu.class, "zbe"});
        }
        if (i2 == 3) {
            return new C0514Ov();
        }
        AbstractC0399Ju abstractC0399Ju = null;
        if (i2 == 4) {
            return new C1548mv(abstractC0399Ju);
        }
        if (i2 != 5) {
            return null;
        }
        return zbb;
    }
}
