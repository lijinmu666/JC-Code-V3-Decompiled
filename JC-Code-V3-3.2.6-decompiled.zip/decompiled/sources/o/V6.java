package o;

import o.aqHPIZ;

/* loaded from: classes.dex */
public final class V6 implements aqHPIZ.ZfxDd {
    public static final V6 ETF = new V6(false, false, null, false, null, null, false, null, null, null);
    public final boolean AZxh = false;
    public final boolean wA = false;
    public final String ZfxDd = null;
    public final boolean KLFTb = false;
    public final boolean lgHUyS = false;
    public final String JHa = null;
    public final String xJ = null;
    public final Long qdMbNW = null;
    public final Long Dt = null;

    public /* synthetic */ V6(boolean z, boolean z2, String str, boolean z3, String str2, String str3, boolean z4, Long l, Long l2, AbstractC0703Xc abstractC0703Xc) {
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof V6)) {
            return false;
        }
        boolean z = ((V6) obj).AZxh;
        return U2.mjFkc(null, null) && U2.mjFkc(null, null) && U2.mjFkc(null, null) && U2.mjFkc(null, null) && U2.mjFkc(null, null);
    }

    public final int hashCode() {
        Boolean bool = Boolean.FALSE;
        return U2.AZxh(bool, bool, null, bool, bool, null, null, null, null);
    }
}
