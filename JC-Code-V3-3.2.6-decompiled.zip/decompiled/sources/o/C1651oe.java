package o;

import org.conscrypt.BuildConfig;

/* renamed from: o.oe, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C1651oe extends Zx implements Ly {
    private static final C1651oe zbd;
    private int zbe;
    private Object zbg;
    private int zbi;
    private int zbj;
    private int zbk;
    private int zbf = 0;
    private byte zbl = 2;
    private String zbh = BuildConfig.FLAVOR;

    static {
        C1651oe c1651oe = new C1651oe();
        zbd = c1651oe;
        AbstractC1010dy.YoKzxo(C1651oe.class, c1651oe);
    }

    @Override // o.AbstractC1010dy
    public final Object IEE(int i, Object obj, Object obj2) {
        int i2 = i - 1;
        if (i2 == 0) {
            return Byte.valueOf(this.zbl);
        }
        if (i2 == 2) {
            return AbstractC1010dy.ETF(zbd, "\u0001\u0007\u0001\u0001\u0001\b\u0007\u0000\u0000\u0000\u0001ဈ\u0000\u0002င\u0001\u0003င\u0002\u0004င\u0003\u0006=\u0000\u0007=\u0000\b6\u0000", new Object[]{"zbg", "zbf", "zbe", "zbh", "zbi", "zbj", "zbk"});
        }
        if (i2 == 3) {
            return new C1651oe();
        }
        AbstractC0727Yd abstractC0727Yd = null;
        if (i2 == 4) {
            return new C1591ne(abstractC0727Yd);
        }
        if (i2 == 5) {
            return zbd;
        }
        this.zbl = obj == null ? (byte) 0 : (byte) 1;
        return null;
    }
}
