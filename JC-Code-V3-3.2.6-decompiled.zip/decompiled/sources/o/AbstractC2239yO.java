package o;

/* renamed from: o.yO, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC2239yO {
}
