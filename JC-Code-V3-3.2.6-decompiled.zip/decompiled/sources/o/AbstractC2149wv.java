package o;

import org.conscrypt.BuildConfig;

/* renamed from: o.wv, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC2149wv {
    public static final Dy mjFkc = Dy.ZfxDd(EnumC2093vz.ETF, BuildConfig.FLAVOR, EnumC2093vz.MiMN, C2331zv.Ne());
}
