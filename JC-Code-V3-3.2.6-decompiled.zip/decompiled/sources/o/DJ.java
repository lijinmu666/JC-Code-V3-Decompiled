package o;

import o.C0797aQ;

/* loaded from: classes.dex */
public final class DJ implements R2 {
    public static final C0797aQ AZxh;
    public static final C0797aQ JHa;
    public static final C0797aQ KLFTb;
    public static final C0797aQ ZfxDd;
    public static final C0797aQ lgHUyS;
    public static final DJ mjFkc = new DJ();
    public static final C0797aQ qdMbNW;
    public static final C0797aQ wA;
    public static final C0797aQ xJ;

    static {
        C0797aQ.AZxh aZxhMjFkc = C0797aQ.mjFkc("inferenceCommonLogEvent");
        OB ob = new OB();
        ob.mjFkc(1);
        AZxh = aZxhMjFkc.AZxh(ob.AZxh()).mjFkc();
        C0797aQ.AZxh aZxhMjFkc2 = C0797aQ.mjFkc("options");
        OB ob2 = new OB();
        ob2.mjFkc(2);
        wA = aZxhMjFkc2.AZxh(ob2.AZxh()).mjFkc();
        C0797aQ.AZxh aZxhMjFkc3 = C0797aQ.mjFkc("inputLength");
        OB ob3 = new OB();
        ob3.mjFkc(3);
        ZfxDd = aZxhMjFkc3.AZxh(ob3.AZxh()).mjFkc();
        C0797aQ.AZxh aZxhMjFkc4 = C0797aQ.mjFkc("outputLength");
        OB ob4 = new OB();
        ob4.mjFkc(4);
        KLFTb = aZxhMjFkc4.AZxh(ob4.AZxh()).mjFkc();
        C0797aQ.AZxh aZxhMjFkc5 = C0797aQ.mjFkc("loadDictionaryErrorCode");
        OB ob5 = new OB();
        ob5.mjFkc(5);
        JHa = aZxhMjFkc5.AZxh(ob5.AZxh()).mjFkc();
        C0797aQ.AZxh aZxhMjFkc6 = C0797aQ.mjFkc("translateResultStatusCode");
        OB ob6 = new OB();
        ob6.mjFkc(6);
        xJ = aZxhMjFkc6.AZxh(ob6.AZxh()).mjFkc();
        C0797aQ.AZxh aZxhMjFkc7 = C0797aQ.mjFkc("status");
        OB ob7 = new OB();
        ob7.mjFkc(7);
        lgHUyS = aZxhMjFkc7.AZxh(ob7.AZxh()).mjFkc();
        C0797aQ.AZxh aZxhMjFkc8 = C0797aQ.mjFkc("downloadHttpResponseCode");
        OB ob8 = new OB();
        ob8.mjFkc(8);
        qdMbNW = aZxhMjFkc8.AZxh(ob8.AZxh()).mjFkc();
    }

    @Override // o.mYYU
    public final /* bridge */ /* synthetic */ void mjFkc(Object obj, Object obj2) {
        AbstractC2102w7.mjFkc(obj);
        throw null;
    }
}
