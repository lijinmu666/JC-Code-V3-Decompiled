package o;

import android.content.Context;
import android.database.ContentObserver;
import android.database.Cursor;
import android.database.DataSetObserver;
import android.os.Handler;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Filter;
import android.widget.Filterable;
import o.QfniOH;

/* loaded from: classes.dex */
public abstract class HL extends BaseAdapter implements Filterable, QfniOH.mjFkc {
    public boolean AZxh;
    public mjFkc JHa;
    public int KLFTb;
    public Context ZfxDd;
    public QfniOH lgHUyS;
    public boolean mjFkc;
    public Cursor wA;
    public DataSetObserver xJ;

    public class AZxh extends DataSetObserver {
        public AZxh() {
        }

        @Override // android.database.DataSetObserver
        public void onChanged() {
            HL hl = HL.this;
            hl.mjFkc = true;
            hl.notifyDataSetChanged();
        }

        @Override // android.database.DataSetObserver
        public void onInvalidated() {
            HL hl = HL.this;
            hl.mjFkc = false;
            hl.notifyDataSetInvalidated();
        }
    }

    public class mjFkc extends ContentObserver {
        public mjFkc() {
            super(new Handler());
        }

        @Override // android.database.ContentObserver
        public boolean deliverSelfNotifications() {
            return true;
        }

        @Override // android.database.ContentObserver
        public void onChange(boolean z) {
            HL.this.qdMbNW();
        }
    }

    public HL(Context context, Cursor cursor, boolean z) {
        JHa(context, cursor, z ? 1 : 2);
    }

    @Override // o.QfniOH.mjFkc
    public Cursor AZxh() {
        return this.wA;
    }

    public Cursor Dt(Cursor cursor) {
        Cursor cursor2 = this.wA;
        if (cursor == cursor2) {
            return null;
        }
        if (cursor2 != null) {
            mjFkc mjfkc = this.JHa;
            if (mjfkc != null) {
                cursor2.unregisterContentObserver(mjfkc);
            }
            DataSetObserver dataSetObserver = this.xJ;
            if (dataSetObserver != null) {
                cursor2.unregisterDataSetObserver(dataSetObserver);
            }
        }
        this.wA = cursor;
        if (cursor != null) {
            mjFkc mjfkc2 = this.JHa;
            if (mjfkc2 != null) {
                cursor.registerContentObserver(mjfkc2);
            }
            DataSetObserver dataSetObserver2 = this.xJ;
            if (dataSetObserver2 != null) {
                cursor.registerDataSetObserver(dataSetObserver2);
            }
            this.KLFTb = cursor.getColumnIndexOrThrow("_id");
            this.mjFkc = true;
            notifyDataSetChanged();
        } else {
            this.KLFTb = -1;
            this.mjFkc = false;
            notifyDataSetInvalidated();
        }
        return cursor2;
    }

    public void JHa(Context context, Cursor cursor, int i) {
        if ((i & 1) == 1) {
            i |= 2;
            this.AZxh = true;
        } else {
            this.AZxh = false;
        }
        boolean z = cursor != null;
        this.wA = cursor;
        this.mjFkc = z;
        this.ZfxDd = context;
        this.KLFTb = z ? cursor.getColumnIndexOrThrow("_id") : -1;
        if ((i & 2) == 2) {
            this.JHa = new mjFkc();
            this.xJ = new AZxh();
        } else {
            this.JHa = null;
            this.xJ = null;
        }
        if (z) {
            mjFkc mjfkc = this.JHa;
            if (mjfkc != null) {
                cursor.registerContentObserver(mjfkc);
            }
            DataSetObserver dataSetObserver = this.xJ;
            if (dataSetObserver != null) {
                cursor.registerDataSetObserver(dataSetObserver);
            }
        }
    }

    public abstract void KLFTb(View view, Context context, Cursor cursor);

    @Override // android.widget.Adapter
    public int getCount() {
        Cursor cursor;
        if (!this.mjFkc || (cursor = this.wA) == null) {
            return 0;
        }
        return cursor.getCount();
    }

    @Override // android.widget.BaseAdapter, android.widget.SpinnerAdapter
    public View getDropDownView(int i, View view, ViewGroup viewGroup) {
        if (!this.mjFkc) {
            return null;
        }
        this.wA.moveToPosition(i);
        if (view == null) {
            view = xJ(this.ZfxDd, this.wA, viewGroup);
        }
        KLFTb(view, this.ZfxDd, this.wA);
        return view;
    }

    @Override // android.widget.Filterable
    public Filter getFilter() {
        if (this.lgHUyS == null) {
            this.lgHUyS = new QfniOH(this);
        }
        return this.lgHUyS;
    }

    @Override // android.widget.Adapter
    public Object getItem(int i) {
        Cursor cursor;
        if (!this.mjFkc || (cursor = this.wA) == null) {
            return null;
        }
        cursor.moveToPosition(i);
        return this.wA;
    }

    @Override // android.widget.Adapter
    public long getItemId(int i) {
        Cursor cursor;
        if (this.mjFkc && (cursor = this.wA) != null && cursor.moveToPosition(i)) {
            return this.wA.getLong(this.KLFTb);
        }
        return 0L;
    }

    @Override // android.widget.Adapter
    public View getView(int i, View view, ViewGroup viewGroup) {
        if (!this.mjFkc) {
            throw new IllegalStateException("this should only be called when the cursor is valid");
        }
        if (this.wA.moveToPosition(i)) {
            if (view == null) {
                view = lgHUyS(this.ZfxDd, this.wA, viewGroup);
            }
            KLFTb(view, this.ZfxDd, this.wA);
            return view;
        }
        throw new IllegalStateException("couldn't move cursor to position " + i);
    }

    public abstract View lgHUyS(Context context, Cursor cursor, ViewGroup viewGroup);

    @Override // o.QfniOH.mjFkc
    public void mjFkc(Cursor cursor) {
        Cursor cursorDt = Dt(cursor);
        if (cursorDt != null) {
            cursorDt.close();
        }
    }

    public void qdMbNW() {
        Cursor cursor;
        if (!this.AZxh || (cursor = this.wA) == null || cursor.isClosed()) {
            return;
        }
        this.mjFkc = this.wA.requery();
    }

    @Override // o.QfniOH.mjFkc
    public abstract CharSequence wA(Cursor cursor);

    public abstract View xJ(Context context, Cursor cursor, ViewGroup viewGroup);
}
