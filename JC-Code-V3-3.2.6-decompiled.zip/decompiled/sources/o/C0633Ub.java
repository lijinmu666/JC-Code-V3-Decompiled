package o;

import com.google.android.gms.common.api.Status;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.WeakHashMap;

/* renamed from: o.Ub, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0633Ub {
    public final Map mjFkc = Collections.synchronizedMap(new WeakHashMap());
    public final Map AZxh = Collections.synchronizedMap(new WeakHashMap());

    public final void AZxh(D7 d7, boolean z) {
        this.AZxh.put(d7, Boolean.valueOf(z));
        d7.mjFkc().AZxh(new C0587Sb(this, d7));
    }

    public final void JHa(boolean z, Status status) {
        HashMap map;
        HashMap map2;
        synchronized (this.mjFkc) {
            map = new HashMap(this.mjFkc);
        }
        synchronized (this.AZxh) {
            map2 = new HashMap(this.AZxh);
        }
        for (Map.Entry entry : map.entrySet()) {
            if (z || ((Boolean) entry.getValue()).booleanValue()) {
                AbstractC2102w7.mjFkc(entry.getKey());
                throw null;
            }
        }
        for (Map.Entry entry2 : map2.entrySet()) {
            if (z || ((Boolean) entry2.getValue()).booleanValue()) {
                ((D7) entry2.getKey()).ZfxDd(new WrLQs(status));
            }
        }
    }

    public final boolean KLFTb() {
        return (this.mjFkc.isEmpty() && this.AZxh.isEmpty()) ? false : true;
    }

    public final void ZfxDd() {
        JHa(false, C1194h.qGY);
    }

    public final void wA(int i, String str) {
        StringBuilder sb = new StringBuilder("The connection to Google Play services was lost");
        if (i == 1) {
            sb.append(" due to service disconnection.");
        } else if (i == 3) {
            sb.append(" due to dead object exception.");
        }
        if (str != null) {
            sb.append(" Last reason for disconnect: ");
            sb.append(str);
        }
        JHa(true, new Status(20, sb.toString()));
    }
}
