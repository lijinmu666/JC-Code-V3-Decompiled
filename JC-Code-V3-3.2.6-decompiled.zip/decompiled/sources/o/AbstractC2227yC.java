package o;

/* renamed from: o.yC, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC2227yC {
}
