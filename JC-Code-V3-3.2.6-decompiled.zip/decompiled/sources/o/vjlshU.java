package o;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.drawable.Drawable;

/* loaded from: classes.dex */
public abstract class vjlshU {
    public static Drawable AZxh(Context context, int i) {
        return C1858s5.xJ().qdMbNW(context, i);
    }

    public static ColorStateList mjFkc(Context context, int i) {
        return ofHOBL.AZxh(context, i);
    }
}
