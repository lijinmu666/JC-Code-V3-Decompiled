package o;

import java.util.concurrent.Executor;

/* loaded from: classes.dex */
public final class zabxk implements qpjZLY {
    public final Z3 AZxh;
    public final Z3 KLFTb;
    public final Z3 ZfxDd;
    public final Z3 mjFkc;
    public final Z3 wA;

    public zabxk(Z3 z3, Z3 z32, Z3 z33, Z3 z34, Z3 z35) {
        this.mjFkc = z3;
        this.AZxh = z32;
        this.wA = z33;
        this.ZfxDd = z34;
        this.KLFTb = z35;
    }

    public static zabxk mjFkc(Z3 z3, Z3 z32, Z3 z33, Z3 z34, Z3 z35) {
        return new zabxk(z3, z32, z33, z34, z35);
    }

    public static nTET wA(Executor executor, tAfC tafc, InterfaceC2250yb interfaceC2250yb, wfQA wfqa, InterfaceC2283z7 interfaceC2283z7) {
        return new nTET(executor, tafc, interfaceC2250yb, wfqa, interfaceC2283z7);
    }

    @Override // o.Z3
    /* renamed from: AZxh, reason: merged with bridge method [inline-methods] */
    public nTET get() {
        return wA((Executor) this.mjFkc.get(), (tAfC) this.AZxh.get(), (InterfaceC2250yb) this.wA.get(), (wfQA) this.ZfxDd.get(), (InterfaceC2283z7) this.KLFTb.get());
    }
}
