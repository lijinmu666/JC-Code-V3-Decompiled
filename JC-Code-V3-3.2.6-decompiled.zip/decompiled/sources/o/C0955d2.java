package o;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/* renamed from: o.d2, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0955d2 extends A7 {
    public static C0955d2 lgHUyS(ByteBuffer byteBuffer) {
        return qdMbNW(byteBuffer, new C0955d2());
    }

    public static C0955d2 qdMbNW(ByteBuffer byteBuffer, C0955d2 c0955d2) {
        byteBuffer.order(ByteOrder.LITTLE_ENDIAN);
        return c0955d2.JHa(byteBuffer.getInt(byteBuffer.position()) + byteBuffer.position(), byteBuffer);
    }

    public C0894c2 Dt(C0894c2 c0894c2, int i) {
        int iAZxh = AZxh(6);
        if (iAZxh != 0) {
            return c0894c2.JHa(mjFkc(ZfxDd(iAZxh) + (i * 4)), this.AZxh);
        }
        return null;
    }

    public int ETF() {
        int iAZxh = AZxh(6);
        if (iAZxh != 0) {
            return KLFTb(iAZxh);
        }
        return 0;
    }

    public C0955d2 JHa(int i, ByteBuffer byteBuffer) {
        xJ(i, byteBuffer);
        return this;
    }

    public int VA() {
        int iAZxh = AZxh(4);
        if (iAZxh != 0) {
            return this.AZxh.getInt(iAZxh + this.mjFkc);
        }
        return 0;
    }

    public void xJ(int i, ByteBuffer byteBuffer) {
        wA(i, byteBuffer);
    }
}
