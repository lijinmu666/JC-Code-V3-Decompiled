package o;

import android.text.PrecomputedText;
import android.text.Spannable;
import android.text.TextDirectionHeuristic;
import android.text.TextPaint;
import android.text.TextUtils;

/* loaded from: classes.dex */
public abstract class G3 implements Spannable {

    public static final class mjFkc {
        public final TextDirectionHeuristic AZxh;
        public final PrecomputedText.Params KLFTb;
        public final int ZfxDd;
        public final TextPaint mjFkc;
        public final int wA;

        public mjFkc(PrecomputedText.Params params) {
            this.mjFkc = params.getTextPaint();
            this.AZxh = params.getTextDirection();
            this.wA = params.getBreakStrategy();
            this.ZfxDd = params.getHyphenationFrequency();
            this.KLFTb = params;
        }

        public int AZxh() {
            return this.wA;
        }

        public TextPaint KLFTb() {
            return this.mjFkc;
        }

        public TextDirectionHeuristic ZfxDd() {
            return this.AZxh;
        }

        public boolean equals(Object obj) {
            if (obj == this) {
                return true;
            }
            if (!(obj instanceof mjFkc)) {
                return false;
            }
            mjFkc mjfkc = (mjFkc) obj;
            return mjFkc(mjfkc) && this.AZxh == mjfkc.ZfxDd();
        }

        public int hashCode() {
            return V2.AZxh(Float.valueOf(this.mjFkc.getTextSize()), Float.valueOf(this.mjFkc.getTextScaleX()), Float.valueOf(this.mjFkc.getTextSkewX()), Float.valueOf(this.mjFkc.getLetterSpacing()), Integer.valueOf(this.mjFkc.getFlags()), this.mjFkc.getTextLocales(), this.mjFkc.getTypeface(), Boolean.valueOf(this.mjFkc.isElegantTextHeight()), this.AZxh, Integer.valueOf(this.wA), Integer.valueOf(this.ZfxDd));
        }

        public boolean mjFkc(mjFkc mjfkc) {
            if (this.wA == mjfkc.AZxh() && this.ZfxDd == mjfkc.wA() && this.mjFkc.getTextSize() == mjfkc.KLFTb().getTextSize() && this.mjFkc.getTextScaleX() == mjfkc.KLFTb().getTextScaleX() && this.mjFkc.getTextSkewX() == mjfkc.KLFTb().getTextSkewX() && this.mjFkc.getLetterSpacing() == mjfkc.KLFTb().getLetterSpacing() && TextUtils.equals(this.mjFkc.getFontFeatureSettings(), mjfkc.KLFTb().getFontFeatureSettings()) && this.mjFkc.getFlags() == mjfkc.KLFTb().getFlags() && this.mjFkc.getTextLocales().equals(mjfkc.KLFTb().getTextLocales())) {
                return this.mjFkc.getTypeface() == null ? mjfkc.KLFTb().getTypeface() == null : this.mjFkc.getTypeface().equals(mjfkc.KLFTb().getTypeface());
            }
            return false;
        }

        public String toString() {
            StringBuilder sb = new StringBuilder("{");
            sb.append("textSize=" + this.mjFkc.getTextSize());
            sb.append(", textScaleX=" + this.mjFkc.getTextScaleX());
            sb.append(", textSkewX=" + this.mjFkc.getTextSkewX());
            sb.append(", letterSpacing=" + this.mjFkc.getLetterSpacing());
            sb.append(", elegantTextHeight=" + this.mjFkc.isElegantTextHeight());
            sb.append(", textLocale=" + this.mjFkc.getTextLocales());
            sb.append(", typeface=" + this.mjFkc.getTypeface());
            sb.append(", variationSettings=" + this.mjFkc.getFontVariationSettings());
            sb.append(", textDir=" + this.AZxh);
            sb.append(", breakStrategy=" + this.wA);
            sb.append(", hyphenationFrequency=" + this.ZfxDd);
            sb.append("}");
            return sb.toString();
        }

        public int wA() {
            return this.ZfxDd;
        }
    }
}
