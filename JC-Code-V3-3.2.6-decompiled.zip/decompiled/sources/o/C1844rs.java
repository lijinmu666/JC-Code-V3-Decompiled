package o;

/* renamed from: o.rs, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C1844rs implements InterfaceC1252hy {
    public static final InterfaceC1252hy mjFkc = new C1844rs();

    @Override // o.InterfaceC1252hy
    public final boolean mjFkc(int i) {
        return i == 0 || i == 1;
    }
}
