package o;

import android.R;
import android.content.res.ColorStateList;

/* loaded from: classes.dex */
public abstract class C5 {
    public static final boolean mjFkc = true;
    public static final int[] AZxh = {R.attr.state_pressed};
    public static final int[] wA = {R.attr.state_hovered, R.attr.state_focused};
    public static final int[] ZfxDd = {R.attr.state_focused};
    public static final int[] KLFTb = {R.attr.state_hovered};
    public static final int[] JHa = {R.attr.state_selected, R.attr.state_pressed};
    public static final int[] xJ = {R.attr.state_selected, R.attr.state_hovered, R.attr.state_focused};
    public static final int[] lgHUyS = {R.attr.state_selected, R.attr.state_focused};
    public static final int[] qdMbNW = {R.attr.state_selected, R.attr.state_hovered};
    public static final int[] Dt = {R.attr.state_selected};
    public static final int[] ETF = {R.attr.state_enabled, R.attr.state_pressed};
    public static final String VA = C5.class.getSimpleName();

    public static boolean AZxh(int[] iArr) {
        boolean z = false;
        boolean z2 = false;
        for (int i : iArr) {
            if (i == 16842910) {
                z = true;
            } else if (i == 16842908 || i == 16842919 || i == 16843623) {
                z2 = true;
            }
        }
        return z && z2;
    }

    public static ColorStateList mjFkc(ColorStateList colorStateList) {
        return colorStateList != null ? colorStateList : ColorStateList.valueOf(0);
    }
}
