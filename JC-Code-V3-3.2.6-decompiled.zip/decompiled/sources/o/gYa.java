package o;

import java.lang.reflect.Array;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

/* loaded from: classes.dex */
public final class gYa implements Collection, Set {
    public static int Dt;
    public static int lgHUyS;
    public static Object[] qdMbNW;
    public static Object[] xJ;
    public Object[] AZxh;
    public AbstractC2277z1 ZfxDd;
    public int[] mjFkc;
    public int wA;
    public static final int[] KLFTb = new int[0];
    public static final Object[] JHa = new Object[0];

    public class mjFkc extends AbstractC2277z1 {
        public mjFkc() {
        }

        @Override // o.AbstractC2277z1
        public Object AZxh(int i, int i2) {
            return gYa.this.AZxh[i];
        }

        @Override // o.AbstractC2277z1
        public int JHa(Object obj) {
            return gYa.this.indexOf(obj);
        }

        @Override // o.AbstractC2277z1
        public int KLFTb(Object obj) {
            return gYa.this.indexOf(obj);
        }

        @Override // o.AbstractC2277z1
        public int ZfxDd() {
            return gYa.this.wA;
        }

        @Override // o.AbstractC2277z1
        public void lgHUyS(int i) {
            gYa.this.Dt(i);
        }

        @Override // o.AbstractC2277z1
        public void mjFkc() {
            gYa.this.clear();
        }

        @Override // o.AbstractC2277z1
        public Object qdMbNW(int i, Object obj) {
            throw new UnsupportedOperationException("not a map");
        }

        @Override // o.AbstractC2277z1
        public Map wA() {
            throw new UnsupportedOperationException("not a map");
        }

        @Override // o.AbstractC2277z1
        public void xJ(Object obj, Object obj2) {
            gYa.this.add(obj);
        }
    }

    public gYa() {
        this(0);
    }

    public static void JHa(int[] iArr, Object[] objArr, int i) {
        if (iArr.length == 8) {
            synchronized (gYa.class) {
                try {
                    if (Dt < 10) {
                        objArr[0] = qdMbNW;
                        objArr[1] = iArr;
                        for (int i2 = i - 1; i2 >= 2; i2--) {
                            objArr[i2] = null;
                        }
                        qdMbNW = objArr;
                        Dt++;
                    }
                } finally {
                }
            }
            return;
        }
        if (iArr.length == 4) {
            synchronized (gYa.class) {
                try {
                    if (lgHUyS < 10) {
                        objArr[0] = xJ;
                        objArr[1] = iArr;
                        for (int i3 = i - 1; i3 >= 2; i3--) {
                            objArr[i3] = null;
                        }
                        xJ = objArr;
                        lgHUyS++;
                    }
                } finally {
                }
            }
        }
    }

    public Object Dt(int i) {
        Object[] objArr = this.AZxh;
        Object obj = objArr[i];
        int i2 = this.wA;
        if (i2 <= 1) {
            JHa(this.mjFkc, objArr, i2);
            this.mjFkc = KLFTb;
            this.AZxh = JHa;
            this.wA = 0;
        } else {
            int[] iArr = this.mjFkc;
            if (iArr.length <= 8 || i2 >= iArr.length / 3) {
                int i3 = i2 - 1;
                this.wA = i3;
                if (i < i3) {
                    int i4 = i + 1;
                    System.arraycopy(iArr, i4, iArr, i, i3 - i);
                    Object[] objArr2 = this.AZxh;
                    System.arraycopy(objArr2, i4, objArr2, i, this.wA - i);
                }
                this.AZxh[this.wA] = null;
            } else {
                mjFkc(i2 > 8 ? i2 + (i2 >> 1) : 8);
                this.wA--;
                if (i > 0) {
                    System.arraycopy(iArr, 0, this.mjFkc, 0, i);
                    System.arraycopy(objArr, 0, this.AZxh, 0, i);
                }
                int i5 = this.wA;
                if (i < i5) {
                    int i6 = i + 1;
                    System.arraycopy(iArr, i6, this.mjFkc, i, i5 - i);
                    System.arraycopy(objArr, i6, this.AZxh, i, this.wA - i);
                }
            }
        }
        return obj;
    }

    public Object ETF(int i) {
        return this.AZxh[i];
    }

    public void ZfxDd(int i) {
        int[] iArr = this.mjFkc;
        if (iArr.length < i) {
            Object[] objArr = this.AZxh;
            mjFkc(i);
            int i2 = this.wA;
            if (i2 > 0) {
                System.arraycopy(iArr, 0, this.mjFkc, 0, i2);
                System.arraycopy(objArr, 0, this.AZxh, 0, this.wA);
            }
            JHa(iArr, objArr, this.wA);
        }
    }

    @Override // java.util.Collection, java.util.Set
    public boolean add(Object obj) {
        int i;
        int iLgHUyS;
        if (obj == null) {
            iLgHUyS = qdMbNW();
            i = 0;
        } else {
            int iHashCode = obj.hashCode();
            i = iHashCode;
            iLgHUyS = lgHUyS(obj, iHashCode);
        }
        if (iLgHUyS >= 0) {
            return false;
        }
        int i2 = ~iLgHUyS;
        int i3 = this.wA;
        int[] iArr = this.mjFkc;
        if (i3 >= iArr.length) {
            int i4 = 8;
            if (i3 >= 8) {
                i4 = (i3 >> 1) + i3;
            } else if (i3 < 4) {
                i4 = 4;
            }
            Object[] objArr = this.AZxh;
            mjFkc(i4);
            int[] iArr2 = this.mjFkc;
            if (iArr2.length > 0) {
                System.arraycopy(iArr, 0, iArr2, 0, iArr.length);
                System.arraycopy(objArr, 0, this.AZxh, 0, objArr.length);
            }
            JHa(iArr, objArr, this.wA);
        }
        int i5 = this.wA;
        if (i2 < i5) {
            int[] iArr3 = this.mjFkc;
            int i6 = i2 + 1;
            System.arraycopy(iArr3, i2, iArr3, i6, i5 - i2);
            Object[] objArr2 = this.AZxh;
            System.arraycopy(objArr2, i2, objArr2, i6, this.wA - i2);
        }
        this.mjFkc[i2] = i;
        this.AZxh[i2] = obj;
        this.wA++;
        return true;
    }

    @Override // java.util.Collection, java.util.Set
    public boolean addAll(Collection collection) {
        ZfxDd(this.wA + collection.size());
        Iterator it = collection.iterator();
        boolean zAdd = false;
        while (it.hasNext()) {
            zAdd |= add(it.next());
        }
        return zAdd;
    }

    @Override // java.util.Collection, java.util.Set
    public void clear() {
        int i = this.wA;
        if (i != 0) {
            JHa(this.mjFkc, this.AZxh, i);
            this.mjFkc = KLFTb;
            this.AZxh = JHa;
            this.wA = 0;
        }
    }

    @Override // java.util.Collection, java.util.Set
    public boolean contains(Object obj) {
        return indexOf(obj) >= 0;
    }

    @Override // java.util.Collection, java.util.Set
    public boolean containsAll(Collection collection) {
        Iterator it = collection.iterator();
        while (it.hasNext()) {
            if (!contains(it.next())) {
                return false;
            }
        }
        return true;
    }

    @Override // java.util.Collection, java.util.Set
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof Set) {
            Set set = (Set) obj;
            if (size() != set.size()) {
                return false;
            }
            for (int i = 0; i < this.wA; i++) {
                try {
                    if (!set.contains(ETF(i))) {
                        return false;
                    }
                } catch (ClassCastException | NullPointerException unused) {
                }
            }
            return true;
        }
        return false;
    }

    @Override // java.util.Collection, java.util.Set
    public int hashCode() {
        int[] iArr = this.mjFkc;
        int i = this.wA;
        int i2 = 0;
        for (int i3 = 0; i3 < i; i3++) {
            i2 += iArr[i3];
        }
        return i2;
    }

    public int indexOf(Object obj) {
        return obj == null ? qdMbNW() : lgHUyS(obj, obj.hashCode());
    }

    @Override // java.util.Collection, java.util.Set
    public boolean isEmpty() {
        return this.wA <= 0;
    }

    @Override // java.util.Collection, java.lang.Iterable, java.util.Set
    public Iterator iterator() {
        return xJ().MiMN().iterator();
    }

    public final int lgHUyS(Object obj, int i) {
        int i2 = this.wA;
        if (i2 == 0) {
            return -1;
        }
        int iMjFkc = MlqoT.mjFkc(this.mjFkc, i2, i);
        if (iMjFkc < 0 || obj.equals(this.AZxh[iMjFkc])) {
            return iMjFkc;
        }
        int i3 = iMjFkc + 1;
        while (i3 < i2 && this.mjFkc[i3] == i) {
            if (obj.equals(this.AZxh[i3])) {
                return i3;
            }
            i3++;
        }
        for (int i4 = iMjFkc - 1; i4 >= 0 && this.mjFkc[i4] == i; i4--) {
            if (obj.equals(this.AZxh[i4])) {
                return i4;
            }
        }
        return ~i3;
    }

    public final void mjFkc(int i) {
        if (i == 8) {
            synchronized (gYa.class) {
                try {
                    Object[] objArr = qdMbNW;
                    if (objArr != null) {
                        this.AZxh = objArr;
                        qdMbNW = (Object[]) objArr[0];
                        this.mjFkc = (int[]) objArr[1];
                        objArr[1] = null;
                        objArr[0] = null;
                        Dt--;
                        return;
                    }
                } finally {
                }
            }
        } else if (i == 4) {
            synchronized (gYa.class) {
                try {
                    Object[] objArr2 = xJ;
                    if (objArr2 != null) {
                        this.AZxh = objArr2;
                        xJ = (Object[]) objArr2[0];
                        this.mjFkc = (int[]) objArr2[1];
                        objArr2[1] = null;
                        objArr2[0] = null;
                        lgHUyS--;
                        return;
                    }
                } finally {
                }
            }
        }
        this.mjFkc = new int[i];
        this.AZxh = new Object[i];
    }

    public final int qdMbNW() {
        int i = this.wA;
        if (i == 0) {
            return -1;
        }
        int iMjFkc = MlqoT.mjFkc(this.mjFkc, i, 0);
        if (iMjFkc < 0 || this.AZxh[iMjFkc] == null) {
            return iMjFkc;
        }
        int i2 = iMjFkc + 1;
        while (i2 < i && this.mjFkc[i2] == 0) {
            if (this.AZxh[i2] == null) {
                return i2;
            }
            i2++;
        }
        for (int i3 = iMjFkc - 1; i3 >= 0 && this.mjFkc[i3] == 0; i3--) {
            if (this.AZxh[i3] == null) {
                return i3;
            }
        }
        return ~i2;
    }

    @Override // java.util.Collection, java.util.Set
    public boolean remove(Object obj) {
        int iIndexOf = indexOf(obj);
        if (iIndexOf < 0) {
            return false;
        }
        Dt(iIndexOf);
        return true;
    }

    @Override // java.util.Collection, java.util.Set
    public boolean removeAll(Collection collection) {
        Iterator it = collection.iterator();
        boolean zRemove = false;
        while (it.hasNext()) {
            zRemove |= remove(it.next());
        }
        return zRemove;
    }

    @Override // java.util.Collection, java.util.Set
    public boolean retainAll(Collection collection) {
        boolean z = false;
        for (int i = this.wA - 1; i >= 0; i--) {
            if (!collection.contains(this.AZxh[i])) {
                Dt(i);
                z = true;
            }
        }
        return z;
    }

    @Override // java.util.Collection, java.util.Set
    public int size() {
        return this.wA;
    }

    @Override // java.util.Collection, java.util.Set
    public Object[] toArray() {
        int i = this.wA;
        Object[] objArr = new Object[i];
        System.arraycopy(this.AZxh, 0, objArr, 0, i);
        return objArr;
    }

    public String toString() {
        if (isEmpty()) {
            return "{}";
        }
        StringBuilder sb = new StringBuilder(this.wA * 14);
        sb.append('{');
        for (int i = 0; i < this.wA; i++) {
            if (i > 0) {
                sb.append(", ");
            }
            Object objETF = ETF(i);
            if (objETF != this) {
                sb.append(objETF);
            } else {
                sb.append("(this Set)");
            }
        }
        sb.append('}');
        return sb.toString();
    }

    public final AbstractC2277z1 xJ() {
        if (this.ZfxDd == null) {
            this.ZfxDd = new mjFkc();
        }
        return this.ZfxDd;
    }

    public gYa(int i) {
        if (i == 0) {
            this.mjFkc = KLFTb;
            this.AZxh = JHa;
        } else {
            mjFkc(i);
        }
        this.wA = 0;
    }

    @Override // java.util.Collection, java.util.Set
    public Object[] toArray(Object[] objArr) {
        if (objArr.length < this.wA) {
            objArr = (Object[]) Array.newInstance(objArr.getClass().getComponentType(), this.wA);
        }
        System.arraycopy(this.AZxh, 0, objArr, 0, this.wA);
        int length = objArr.length;
        int i = this.wA;
        if (length > i) {
            objArr[i] = null;
        }
        return objArr;
    }
}
