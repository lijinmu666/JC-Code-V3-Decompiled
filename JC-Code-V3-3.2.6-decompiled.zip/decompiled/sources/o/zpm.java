package o;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.TimeInterpolator;
import android.animation.ValueAnimator;
import android.graphics.drawable.Drawable;
import android.text.Editable;
import android.view.MotionEvent;
import android.view.View;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityManager;
import android.widget.AutoCompleteTextView;
import android.widget.EditText;
import android.widget.Spinner;
import kotlin.jvm.internal.LongCompanionObject;
import o.rkYL;

/* loaded from: classes.dex */
public class zpm extends CBhInx {
    public static final boolean Pq = true;
    public final View.OnFocusChangeListener Dt;
    public final rkYL.mjFkc ETF;
    public ValueAnimator IEE;
    public final int JHa;
    public final int KLFTb;
    public boolean MiMN;
    public boolean VA;
    public boolean YoKzxo;
    public ValueAnimator fehf;
    public AutoCompleteTextView lgHUyS;
    public AccessibilityManager qGY;
    public final View.OnClickListener qdMbNW;
    public long rkYL;
    public final TimeInterpolator xJ;

    public class mjFkc extends AnimatorListenerAdapter {
        public mjFkc() {
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationEnd(Animator animator) {
            zpm.this.IEE();
            zpm.this.IEE.start();
        }
    }

    public zpm(com.google.android.material.textfield.mjFkc mjfkc) {
        super(mjfkc);
        this.qdMbNW = new View.OnClickListener() { // from class: o.gcD
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.mjFkc.KLMXS(view);
            }
        };
        this.Dt = new View.OnFocusChangeListener() { // from class: o.ilrRDI
            @Override // android.view.View.OnFocusChangeListener
            public final void onFocusChange(View view, boolean z) {
                this.mjFkc.zvd(view, z);
            }
        };
        this.ETF = new rkYL.mjFkc() { // from class: o.PX
            @Override // o.rkYL.mjFkc
            public final void onTouchExplorationStateChanged(boolean z) {
                this.mjFkc.cMLeY(z);
            }
        };
        this.rkYL = LongCompanionObject.MAX_VALUE;
        this.JHa = AbstractC2217y2.JHa(mjfkc.getContext(), AbstractC1199h4.HGpJ, 67);
        this.KLFTb = AbstractC2217y2.JHa(mjfkc.getContext(), AbstractC1199h4.HGpJ, 50);
        this.xJ = AbstractC2217y2.xJ(mjfkc.getContext(), AbstractC1199h4.lB, NPj.mjFkc);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void KLMXS(View view) {
        oCFDzJ();
    }

    private void OjSQV() {
        this.IEE = mByQ(this.JHa, 0.0f, 1.0f);
        ValueAnimator valueAnimatorMByQ = mByQ(this.KLFTb, 1.0f, 0.0f);
        this.fehf = valueAnimatorMByQ;
        valueAnimatorMByQ.addListener(new mjFkc());
    }

    public static AutoCompleteTextView wJVbdd(EditText editText) {
        if (editText instanceof AutoCompleteTextView) {
            return (AutoCompleteTextView) editText;
        }
        throw new RuntimeException("EditText needs to be an AutoCompleteTextView if an Exposed Dropdown Menu is being used.");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void zvd(View view, boolean z) {
        this.VA = z;
        IEE();
        if (z) {
            return;
        }
        NPj(false);
        this.MiMN = false;
    }

    public final /* synthetic */ void CqaNbM() {
        boolean zIsPopupShowing = this.lgHUyS.isPopupShowing();
        NPj(zIsPopupShowing);
        this.MiMN = zIsPopupShowing;
    }

    @Override // o.CBhInx
    public boolean Dt() {
        return true;
    }

    @Override // o.CBhInx
    public boolean ETF() {
        return this.VA;
    }

    @Override // o.CBhInx
    public View.OnClickListener JHa() {
        return this.qdMbNW;
    }

    @Override // o.CBhInx
    public View.OnFocusChangeListener KLFTb() {
        return this.Dt;
    }

    @Override // o.CBhInx
    public boolean MiMN() {
        return this.YoKzxo;
    }

    public final void NPj(boolean z) {
        if (this.YoKzxo != z) {
            this.YoKzxo = z;
            this.IEE.cancel();
            this.fehf.start();
        }
    }

    public final boolean Ne() {
        long jCurrentTimeMillis = System.currentTimeMillis() - this.rkYL;
        return jCurrentTimeMillis < 0 || jCurrentTimeMillis > 300;
    }

    @Override // o.CBhInx
    public void Pq() {
        OjSQV();
        this.qGY = (AccessibilityManager) this.wA.getSystemService("accessibility");
    }

    @Override // o.CBhInx
    public boolean VA() {
        return true;
    }

    public final /* synthetic */ void Vnb() {
        aqHPIZ();
        NPj(false);
    }

    @Override // o.CBhInx
    public void YoKzxo(EditText editText) {
        this.lgHUyS = wJVbdd(editText);
        vadzgd();
        this.mjFkc.setErrorIconDrawable((Drawable) null);
        if (!rtBEoQ.mjFkc(editText) && this.qGY.isTouchExplorationEnabled()) {
            T9.NKyg(this.ZfxDd, 2);
        }
        this.mjFkc.setEndIconVisible(true);
    }

    @Override // o.CBhInx
    public int ZfxDd() {
        return Pq ? AbstractC1797r4.ZfxDd : AbstractC1797r4.KLFTb;
    }

    public final void aqHPIZ() {
        this.MiMN = true;
        this.rkYL = System.currentTimeMillis();
    }

    public final /* synthetic */ void cMLeY(boolean z) {
        AutoCompleteTextView autoCompleteTextView = this.lgHUyS;
        if (autoCompleteTextView == null || rtBEoQ.mjFkc(autoCompleteTextView)) {
            return;
        }
        T9.NKyg(this.ZfxDd, z ? 2 : 1);
    }

    @Override // o.CBhInx
    public boolean diqgf() {
        return true;
    }

    @Override // o.CBhInx
    public void eyqo() {
        AutoCompleteTextView autoCompleteTextView = this.lgHUyS;
        if (autoCompleteTextView != null) {
            autoCompleteTextView.setOnTouchListener(null);
            if (Pq) {
                this.lgHUyS.setOnDismissListener(null);
            }
        }
    }

    @Override // o.CBhInx
    public rkYL.mjFkc lgHUyS() {
        return this.ETF;
    }

    public final ValueAnimator mByQ(int i, float... fArr) {
        ValueAnimator valueAnimatorOfFloat = ValueAnimator.ofFloat(fArr);
        valueAnimatorOfFloat.setInterpolator(this.xJ);
        valueAnimatorOfFloat.setDuration(i);
        valueAnimatorOfFloat.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() { // from class: o.boLb
            @Override // android.animation.ValueAnimator.AnimatorUpdateListener
            public final void onAnimationUpdate(ValueAnimator valueAnimator) {
                this.mjFkc.xrEuO(valueAnimator);
            }
        });
        return valueAnimatorOfFloat;
    }

    @Override // o.CBhInx
    public void mjFkc(Editable editable) {
        if (this.qGY.isTouchExplorationEnabled() && rtBEoQ.mjFkc(this.lgHUyS) && !this.ZfxDd.hasFocus()) {
            this.lgHUyS.dismissDropDown();
        }
        this.lgHUyS.post(new Runnable() { // from class: o.FoO
            @Override // java.lang.Runnable
            public final void run() {
                this.mjFkc.CqaNbM();
            }
        });
    }

    public final void oCFDzJ() {
        if (this.lgHUyS == null) {
            return;
        }
        if (Ne()) {
            this.MiMN = false;
        }
        if (this.MiMN) {
            this.MiMN = false;
            return;
        }
        if (Pq) {
            NPj(!this.YoKzxo);
        } else {
            this.YoKzxo = !this.YoKzxo;
            IEE();
        }
        if (!this.YoKzxo) {
            this.lgHUyS.dismissDropDown();
        } else {
            this.lgHUyS.requestFocus();
            this.lgHUyS.showDropDown();
        }
    }

    @Override // o.CBhInx
    public void qGY(View view, AccessibilityEvent accessibilityEvent) {
        if (!this.qGY.isEnabled() || rtBEoQ.mjFkc(this.lgHUyS)) {
            return;
        }
        boolean z = accessibilityEvent.getEventType() == 32768 && this.YoKzxo && !this.lgHUyS.isPopupShowing();
        if (accessibilityEvent.getEventType() == 1 || z) {
            oCFDzJ();
            aqHPIZ();
        }
    }

    @Override // o.CBhInx
    public boolean qdMbNW(int i) {
        return i != 0;
    }

    public final /* synthetic */ boolean rWxwaT(View view, MotionEvent motionEvent) {
        if (motionEvent.getAction() == 1) {
            if (Ne()) {
                this.MiMN = false;
            }
            oCFDzJ();
            aqHPIZ();
        }
        return false;
    }

    @Override // o.CBhInx
    public void rkYL(View view, Ucbh ucbh) {
        if (!rtBEoQ.mjFkc(this.lgHUyS)) {
            ucbh.bbzow(Spinner.class.getName());
        }
        if (ucbh.vadzgd()) {
            ucbh.xROA(null);
        }
    }

    public final void vadzgd() {
        this.lgHUyS.setOnTouchListener(new View.OnTouchListener() { // from class: o.gq
            @Override // android.view.View.OnTouchListener
            public final boolean onTouch(View view, MotionEvent motionEvent) {
                return this.mjFkc.rWxwaT(view, motionEvent);
            }
        });
        if (Pq) {
            this.lgHUyS.setOnDismissListener(new AutoCompleteTextView.OnDismissListener() { // from class: o.jCFSyK
                @Override // android.widget.AutoCompleteTextView.OnDismissListener
                public final void onDismiss() {
                    this.mjFkc.Vnb();
                }
            });
        }
        this.lgHUyS.setThreshold(0);
    }

    @Override // o.CBhInx
    public int wA() {
        return N4.xJ;
    }

    public final /* synthetic */ void xrEuO(ValueAnimator valueAnimator) {
        this.ZfxDd.setAlpha(((Float) valueAnimator.getAnimatedValue()).floatValue());
    }
}
