package o;

import o.C0255Dp;
import org.bouncycastle.asn1.x509.DisplayText;

/* loaded from: classes.dex */
public abstract class YxdwU {
    public static final YxdwU mjFkc = mjFkc().JHa(10485760).ZfxDd(DisplayText.DISPLAY_TEXT_MAXIMUM_SIZE).AZxh(10000).wA(604800000).KLFTb(81920).mjFkc();

    public static abstract class mjFkc {
        public abstract mjFkc AZxh(int i);

        public abstract mjFkc JHa(long j);

        public abstract mjFkc KLFTb(int i);

        public abstract mjFkc ZfxDd(int i);

        public abstract YxdwU mjFkc();

        public abstract mjFkc wA(long j);
    }

    public static mjFkc mjFkc() {
        return new C0255Dp.AZxh();
    }

    public abstract int AZxh();

    public abstract long JHa();

    public abstract int KLFTb();

    public abstract int ZfxDd();

    public abstract long wA();
}
