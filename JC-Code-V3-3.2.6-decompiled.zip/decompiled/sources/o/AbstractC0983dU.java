package o;

/* renamed from: o.dU, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC0983dU {
    public static void mjFkc() {
        AbstractC0862bU.ZfxDd();
        C1344jV.AZxh();
    }
}
