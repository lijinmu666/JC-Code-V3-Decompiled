package o;

/* loaded from: classes.dex */
public interface ZGL {
    void mjFkc(jxC jxc);
}
