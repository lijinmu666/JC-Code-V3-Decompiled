package o;

import java.util.concurrent.Callable;
import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

/* renamed from: o.n2, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC1556n2 {
    public final G7 mjFkc;
    public final AtomicInteger AZxh = new AtomicInteger(0);
    public final AtomicBoolean wA = new AtomicBoolean(false);

    public AbstractC1556n2(G7 g7) {
        this.mjFkc = g7;
    }

    public abstract void AZxh();

    public B7 JHa(Executor executor) {
        I3.qdMbNW(this.AZxh.get() > 0);
        final D7 d7 = new D7();
        this.mjFkc.mjFkc(executor, new Runnable() { // from class: o.RO
            @Override // java.lang.Runnable
            public final void run() {
                this.mjFkc.lgHUyS(d7);
            }
        });
        return d7.mjFkc();
    }

    public void KLFTb(Executor executor) {
        JHa(executor);
    }

    public abstract void ZfxDd();

    public final /* synthetic */ void lgHUyS(D7 d7) {
        int iDecrementAndGet = this.AZxh.decrementAndGet();
        I3.qdMbNW(iDecrementAndGet >= 0);
        if (iDecrementAndGet == 0) {
            ZfxDd();
            this.wA.set(false);
        }
        AbstractC0983dU.mjFkc();
        d7.wA(null);
    }

    public B7 mjFkc(final Executor executor, final Callable callable, final AbstractC0631Tw abstractC0631Tw) {
        I3.qdMbNW(this.AZxh.get() > 0);
        if (abstractC0631Tw.mjFkc()) {
            return I7.mjFkc();
        }
        final QyqF qyqF = new QyqF();
        final D7 d7 = new D7(qyqF.AZxh());
        this.mjFkc.mjFkc(new Executor() { // from class: o.cQ
            @Override // java.util.concurrent.Executor
            public final void execute(Runnable runnable) {
                try {
                    executor.execute(runnable);
                } catch (RuntimeException e) {
                    if (abstractC0631Tw.mjFkc()) {
                        qyqF.mjFkc();
                    } else {
                        d7.AZxh(e);
                    }
                    throw e;
                }
            }
        }, new Runnable() { // from class: o.jR
            @Override // java.lang.Runnable
            public final void run() throws Exception {
                this.mjFkc.xJ(abstractC0631Tw, qyqF, callable, d7);
            }
        });
        return d7.mjFkc();
    }

    public void wA() {
        this.AZxh.incrementAndGet();
    }

    public final /* synthetic */ void xJ(AbstractC0631Tw abstractC0631Tw, QyqF qyqF, Callable callable, D7 d7) throws Exception {
        try {
            if (abstractC0631Tw.mjFkc()) {
                qyqF.mjFkc();
                return;
            }
            try {
                if (!this.wA.get()) {
                    AZxh();
                    this.wA.set(true);
                }
                if (abstractC0631Tw.mjFkc()) {
                    qyqF.mjFkc();
                    return;
                }
                Object objCall = callable.call();
                if (abstractC0631Tw.mjFkc()) {
                    qyqF.mjFkc();
                } else {
                    d7.wA(objCall);
                }
            } catch (RuntimeException e) {
                throw new C1376k2("Internal error has occurred when executing ML Kit tasks", 13, e);
            }
        } catch (Exception e2) {
            if (abstractC0631Tw.mjFkc()) {
                qyqF.mjFkc();
            } else {
                d7.AZxh(e2);
            }
        }
    }
}
