package o;

/* renamed from: o.y4, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC2219y4 {
    public static int AZxh = 2131231110;
    public static int mjFkc = 2131230904;
    public static int wA = 2131231197;
}
