package o;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Matrix;
import android.graphics.Outline;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Region;
import android.graphics.drawable.Drawable;
import android.os.Looper;
import android.util.AttributeSet;
import android.util.Log;
import java.util.BitSet;
import o.I6;
import o.J6;
import o.K6;

/* loaded from: classes.dex */
public class O1 extends Drawable implements L6 {
    public static final String Gd = "O1";
    public static final Paint HGpJ;
    public final K6.xJ[] AZxh;
    public final RectF Dt;
    public final Region ETF;
    public final J6 IEE;
    public final Matrix JHa;
    public boolean KLFTb;
    public I6 MiMN;
    public PorterDuffColorFilter Pq;
    public final RectF Ucbh;
    public final Region VA;
    public final Paint YoKzxo;
    public final BitSet ZfxDd;
    public PorterDuffColorFilter diqgf;
    public int eyqo;
    public final J6.AZxh fehf;
    public boolean huTpC;
    public final Path lgHUyS;
    public wA mjFkc;
    public final H6 qGY;
    public final RectF qdMbNW;
    public final Paint rkYL;
    public final K6.xJ[] wA;
    public final Path xJ;

    public class AZxh implements I6.wA {
        public final /* synthetic */ float mjFkc;

        public AZxh(float f) {
            this.mjFkc = f;
        }

        @Override // o.I6.wA
        public cQmsjG mjFkc(cQmsjG cqmsjg) {
            return cqmsjg instanceof C1200h5 ? cqmsjg : new KLMXS(this.mjFkc, cqmsjg);
        }
    }

    public class mjFkc implements J6.AZxh {
        public mjFkc() {
        }

        @Override // o.J6.AZxh
        public void AZxh(K6 k6, Matrix matrix, int i) {
            O1.this.ZfxDd.set(i, k6.KLFTb());
            O1.this.AZxh[i] = k6.JHa(matrix);
        }

        @Override // o.J6.AZxh
        public void mjFkc(K6 k6, Matrix matrix, int i) {
            O1.this.ZfxDd.set(i + 4, k6.KLFTb());
            O1.this.wA[i] = k6.JHa(matrix);
        }
    }

    static {
        Paint paint = new Paint(1);
        HGpJ = paint;
        paint.setColor(-1);
        paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_OUT));
    }

    public O1() {
        this(new I6());
    }

    public static O1 MiMN(Context context, float f) {
        int iWA = L1.wA(context, AbstractC1199h4.lgHUyS, O1.class.getSimpleName());
        O1 o1 = new O1();
        o1.cMLeY(context);
        o1.uHVRx(ColorStateList.valueOf(iWA));
        o1.GMIER(f);
        return o1;
    }

    public static int oCFDzJ(int i, int i2) {
        return (i * (i2 + (i2 >>> 7))) >>> 8;
    }

    public final void ANMGZc() {
        float fCqaNbM = CqaNbM();
        this.mjFkc.IEE = (int) Math.ceil(0.75f * fCqaNbM);
        this.mjFkc.Pq = (int) Math.ceil(fCqaNbM * 0.25f);
        jm();
        rWxwaT();
    }

    public int BAnRFn() {
        wA wAVar = this.mjFkc;
        return (int) (wAVar.Pq * Math.cos(Math.toRadians(wAVar.diqgf)));
    }

    public float CqaNbM() {
        return huTpC() + Ne();
    }

    public final PorterDuffColorFilter Dt(ColorStateList colorStateList, PorterDuff.Mode mode, boolean z) {
        int colorForState = colorStateList.getColorForState(getState(), 0);
        if (z) {
            colorForState = VA(colorForState);
        }
        this.eyqo = colorForState;
        return new PorterDuffColorFilter(colorForState, mode);
    }

    public final PorterDuffColorFilter ETF(ColorStateList colorStateList, PorterDuff.Mode mode, Paint paint, boolean z) {
        return (colorStateList == null || mode == null) ? JHa(paint, z) : Dt(colorStateList, mode, z);
    }

    public void GMIER(float f) {
        wA wAVar = this.mjFkc;
        if (wAVar.rkYL != f) {
            wAVar.rkYL = f;
            ANMGZc();
        }
    }

    public ColorStateList Gd() {
        return this.mjFkc.ZfxDd;
    }

    public float HGpJ() {
        return this.mjFkc.ETF;
    }

    public void IEE(Canvas canvas) {
        fehf(canvas, this.rkYL, this.lgHUyS, this.MiMN, Ucbh());
    }

    public void JBhc(float f) {
        this.mjFkc.VA = f;
        invalidateSelf();
    }

    public final PorterDuffColorFilter JHa(Paint paint, boolean z) {
        if (!z) {
            return null;
        }
        int color = paint.getColor();
        int iVA = VA(color);
        this.eyqo = iVA;
        if (iVA != color) {
            return new PorterDuffColorFilter(iVA, PorterDuff.Mode.SRC_IN);
        }
        return null;
    }

    public void JYgkl(int i, int i2, int i3, int i4) {
        wA wAVar = this.mjFkc;
        if (wAVar.qdMbNW == null) {
            wAVar.qdMbNW = new Rect();
        }
        this.mjFkc.qdMbNW.set(i, i2, i3, i4);
        invalidateSelf();
    }

    public void JYn(float f) {
        wA wAVar = this.mjFkc;
        if (wAVar.ETF != f) {
            wAVar.ETF = f;
            this.KLFTb = true;
            invalidateSelf();
        }
    }

    public void JrJO(float f) {
        wA wAVar = this.mjFkc;
        if (wAVar.YoKzxo != f) {
            wAVar.YoKzxo = f;
            ANMGZc();
        }
    }

    public final boolean KLMXS() {
        Paint.Style style = this.mjFkc.Ucbh;
        return style == Paint.Style.FILL_AND_STROKE || style == Paint.Style.FILL;
    }

    public void KRTLGT(cQmsjG cqmsjg) {
        setShapeAppearanceModel(this.mjFkc.mjFkc.Gd(cqmsjg));
    }

    public boolean NPj() {
        return this.mjFkc.mjFkc.eyqo(eyqo());
    }

    public float Ne() {
        return this.mjFkc.qGY;
    }

    public float OjSQV() {
        return this.mjFkc.mjFkc.diqgf().mjFkc(eyqo());
    }

    public float Pq() {
        return this.mjFkc.mjFkc.Dt().mjFkc(eyqo());
    }

    public void SwgkN(ColorStateList colorStateList) {
        wA wAVar = this.mjFkc;
        if (wAVar.KLFTb != colorStateList) {
            wAVar.KLFTb = colorStateList;
            onStateChange(getState());
        }
    }

    public final RectF Ucbh() {
        this.Dt.set(eyqo());
        float fWJVbdd = wJVbdd();
        this.Dt.inset(fWJVbdd, fWJVbdd);
        return this.Dt;
    }

    public int VA(int i) {
        float fCqaNbM = CqaNbM() + vI();
        uube uubeVar = this.mjFkc.AZxh;
        return uubeVar != null ? uubeVar.wA(i, fCqaNbM) : i;
    }

    public final boolean Vdz(int[] iArr) {
        boolean z;
        int color;
        int colorForState;
        int color2;
        int colorForState2;
        if (this.mjFkc.ZfxDd == null || color2 == (colorForState2 = this.mjFkc.ZfxDd.getColorForState(iArr, (color2 = this.YoKzxo.getColor())))) {
            z = false;
        } else {
            this.YoKzxo.setColor(colorForState2);
            z = true;
        }
        if (this.mjFkc.KLFTb == null || color == (colorForState = this.mjFkc.KLFTb.getColorForState(iArr, (color = this.rkYL.getColor())))) {
            return z;
        }
        this.rkYL.setColor(colorForState);
        return true;
    }

    public boolean Vnb() {
        uube uubeVar = this.mjFkc.AZxh;
        return uubeVar != null && uubeVar.ZfxDd();
    }

    public int VocHEe() {
        wA wAVar = this.mjFkc;
        return (int) (wAVar.Pq * Math.sin(Math.toRadians(wAVar.diqgf)));
    }

    public void WGXroI(int i) {
        this.qGY.ZfxDd(i);
        this.mjFkc.eyqo = false;
        rWxwaT();
    }

    public boolean WrLQs() {
        if (NPj()) {
            return false;
        }
        this.xJ.isConvex();
        return false;
    }

    public void XV(float f, int i) {
        JBhc(f);
        SwgkN(ColorStateList.valueOf(i));
    }

    public final void YoKzxo(Canvas canvas) {
        if (this.ZfxDd.cardinality() > 0) {
            Log.w(Gd, "Compatibility shadow requested but can't be drawn for all operations in this shape.");
        }
        if (this.mjFkc.Pq != 0) {
            canvas.drawPath(this.xJ, this.qGY.wA());
        }
        for (int i = 0; i < 4; i++) {
            this.AZxh[i].AZxh(this.qGY, this.mjFkc.IEE, canvas);
            this.wA[i].AZxh(this.qGY, this.mjFkc.IEE, canvas);
        }
        if (this.huTpC) {
            int iVocHEe = VocHEe();
            int iBAnRFn = BAnRFn();
            canvas.translate(-iVocHEe, -iBAnRFn);
            canvas.drawPath(this.xJ, HGpJ);
            canvas.translate(iVocHEe, iBAnRFn);
        }
    }

    public final void aqHPIZ(Canvas canvas) {
        canvas.translate(VocHEe(), BAnRFn());
    }

    public void bbzow(float f, ColorStateList colorStateList) {
        JBhc(f);
        SwgkN(colorStateList);
    }

    public void cMLeY(Context context) {
        this.mjFkc.AZxh = new uube(context);
        ANMGZc();
    }

    public float diqgf() {
        return this.mjFkc.mjFkc.VA().mjFkc(eyqo());
    }

    @Override // android.graphics.drawable.Drawable
    public void draw(Canvas canvas) {
        this.YoKzxo.setColorFilter(this.Pq);
        int alpha = this.YoKzxo.getAlpha();
        this.YoKzxo.setAlpha(oCFDzJ(alpha, this.mjFkc.MiMN));
        this.rkYL.setColorFilter(this.diqgf);
        this.rkYL.setStrokeWidth(this.mjFkc.VA);
        int alpha2 = this.rkYL.getAlpha();
        this.rkYL.setAlpha(oCFDzJ(alpha2, this.mjFkc.MiMN));
        if (this.KLFTb) {
            qdMbNW();
            xJ(eyqo(), this.xJ);
            this.KLFTb = false;
        }
        vadzgd(canvas);
        if (KLMXS()) {
            rkYL(canvas);
        }
        if (zvd()) {
            IEE(canvas);
        }
        this.YoKzxo.setAlpha(alpha);
        this.rkYL.setAlpha(alpha2);
    }

    public RectF eyqo() {
        this.qdMbNW.set(getBounds());
        return this.qdMbNW;
    }

    public final void fehf(Canvas canvas, Paint paint, Path path, I6 i6, RectF rectF) {
        if (!i6.eyqo(rectF)) {
            canvas.drawPath(path, paint);
        } else {
            float fMjFkc = i6.diqgf().mjFkc(rectF) * this.mjFkc.ETF;
            canvas.drawRoundRect(rectF, fMjFkc, fMjFkc, paint);
        }
    }

    @Override // android.graphics.drawable.Drawable
    public int getAlpha() {
        return this.mjFkc.MiMN;
    }

    @Override // android.graphics.drawable.Drawable
    public Drawable.ConstantState getConstantState() {
        return this.mjFkc;
    }

    @Override // android.graphics.drawable.Drawable
    public int getOpacity() {
        return -3;
    }

    @Override // android.graphics.drawable.Drawable
    public void getOutline(Outline outline) {
        if (this.mjFkc.fehf == 2) {
            return;
        }
        if (NPj()) {
            outline.setRoundRect(getBounds(), mByQ() * this.mjFkc.ETF);
        } else {
            xJ(eyqo(), this.xJ);
            GmK.mjFkc(outline, this.xJ);
        }
    }

    @Override // android.graphics.drawable.Drawable
    public boolean getPadding(Rect rect) {
        Rect rect2 = this.mjFkc.qdMbNW;
        if (rect2 == null) {
            return super.getPadding(rect);
        }
        rect.set(rect2);
        return true;
    }

    @Override // android.graphics.drawable.Drawable
    public Region getTransparentRegion() {
        this.ETF.set(getBounds());
        xJ(eyqo(), this.xJ);
        this.VA.setPath(this.xJ, this.ETF);
        this.ETF.op(this.VA, Region.Op.DIFFERENCE);
        return this.ETF;
    }

    public float huTpC() {
        return this.mjFkc.rkYL;
    }

    @Override // android.graphics.drawable.Drawable
    public void invalidateSelf() {
        this.KLFTb = true;
        super.invalidateSelf();
    }

    @Override // android.graphics.drawable.Drawable
    public boolean isStateful() {
        ColorStateList colorStateList;
        ColorStateList colorStateList2;
        ColorStateList colorStateList3;
        ColorStateList colorStateList4;
        return super.isStateful() || ((colorStateList = this.mjFkc.xJ) != null && colorStateList.isStateful()) || (((colorStateList2 = this.mjFkc.JHa) != null && colorStateList2.isStateful()) || (((colorStateList3 = this.mjFkc.KLFTb) != null && colorStateList3.isStateful()) || ((colorStateList4 = this.mjFkc.ZfxDd) != null && colorStateList4.isStateful())));
    }

    public final boolean jm() {
        PorterDuffColorFilter porterDuffColorFilter = this.Pq;
        PorterDuffColorFilter porterDuffColorFilter2 = this.diqgf;
        wA wAVar = this.mjFkc;
        this.Pq = ETF(wAVar.xJ, wAVar.lgHUyS, this.YoKzxo, true);
        wA wAVar2 = this.mjFkc;
        this.diqgf = ETF(wAVar2.JHa, wAVar2.lgHUyS, this.rkYL, false);
        wA wAVar3 = this.mjFkc;
        if (wAVar3.eyqo) {
            this.qGY.ZfxDd(wAVar3.xJ.getColorForState(getState(), 0));
        }
        return (V2.mjFkc(porterDuffColorFilter, this.Pq) && V2.mjFkc(porterDuffColorFilter2, this.diqgf)) ? false : true;
    }

    public I6 lB() {
        return this.mjFkc.mjFkc;
    }

    public final void lgHUyS(RectF rectF, Path path) {
        J6 j6 = this.IEE;
        wA wAVar = this.mjFkc;
        j6.KLFTb(wAVar.mjFkc, wAVar.ETF, rectF, this.fehf, path);
    }

    public float mByQ() {
        return this.mjFkc.mjFkc.IEE().mjFkc(eyqo());
    }

    @Override // android.graphics.drawable.Drawable
    public Drawable mutate() {
        this.mjFkc = new wA(this.mjFkc);
        return this;
    }

    public void nxI(boolean z) {
        this.huTpC = z;
    }

    @Override // android.graphics.drawable.Drawable
    public void onBoundsChange(Rect rect) {
        this.KLFTb = true;
        super.onBoundsChange(rect);
    }

    @Override // android.graphics.drawable.Drawable, o.C0779a8.AZxh
    public boolean onStateChange(int[] iArr) {
        boolean z = Vdz(iArr) || jm();
        if (z) {
            invalidateSelf();
        }
        return z;
    }

    public void qGY(Canvas canvas, Paint paint, Path path, RectF rectF) {
        fehf(canvas, paint, path, this.mjFkc.mjFkc, rectF);
    }

    public final void qdMbNW() {
        I6 i6HGpJ = lB().HGpJ(new AZxh(-wJVbdd()));
        this.MiMN = i6HGpJ;
        this.IEE.ZfxDd(i6HGpJ, this.mjFkc.ETF, Ucbh(), this.lgHUyS);
    }

    public final void rWxwaT() {
        super.invalidateSelf();
    }

    public final void rkYL(Canvas canvas) {
        fehf(canvas, this.YoKzxo, this.xJ, this.mjFkc.mjFkc, eyqo());
    }

    @Override // android.graphics.drawable.Drawable
    public void setAlpha(int i) {
        wA wAVar = this.mjFkc;
        if (wAVar.MiMN != i) {
            wAVar.MiMN = i;
            rWxwaT();
        }
    }

    @Override // android.graphics.drawable.Drawable
    public void setColorFilter(ColorFilter colorFilter) {
        this.mjFkc.wA = colorFilter;
        rWxwaT();
    }

    @Override // o.L6
    public void setShapeAppearanceModel(I6 i6) {
        this.mjFkc.mjFkc = i6;
        invalidateSelf();
    }

    @Override // android.graphics.drawable.Drawable
    public void setTint(int i) {
        setTintList(ColorStateList.valueOf(i));
    }

    @Override // android.graphics.drawable.Drawable
    public void setTintList(ColorStateList colorStateList) {
        this.mjFkc.xJ = colorStateList;
        jm();
        rWxwaT();
    }

    @Override // android.graphics.drawable.Drawable
    public void setTintMode(PorterDuff.Mode mode) {
        wA wAVar = this.mjFkc;
        if (wAVar.lgHUyS != mode) {
            wAVar.lgHUyS = mode;
            jm();
            rWxwaT();
        }
    }

    public void uHVRx(ColorStateList colorStateList) {
        wA wAVar = this.mjFkc;
        if (wAVar.ZfxDd != colorStateList) {
            wAVar.ZfxDd = colorStateList;
            onStateChange(getState());
        }
    }

    public float vI() {
        return this.mjFkc.YoKzxo;
    }

    public final void vadzgd(Canvas canvas) {
        if (xrEuO()) {
            canvas.save();
            aqHPIZ(canvas);
            if (!this.huTpC) {
                YoKzxo(canvas);
                canvas.restore();
                return;
            }
            int iWidth = (int) (this.Ucbh.width() - getBounds().width());
            int iHeight = (int) (this.Ucbh.height() - getBounds().height());
            if (iWidth < 0 || iHeight < 0) {
                throw new IllegalStateException("Invalid shadow bounds. Check that the treatments result in a valid path.");
            }
            Bitmap bitmapCreateBitmap = Bitmap.createBitmap(((int) this.Ucbh.width()) + (this.mjFkc.IEE * 2) + iWidth, ((int) this.Ucbh.height()) + (this.mjFkc.IEE * 2) + iHeight, Bitmap.Config.ARGB_8888);
            Canvas canvas2 = new Canvas(bitmapCreateBitmap);
            float f = (getBounds().left - this.mjFkc.IEE) - iWidth;
            float f2 = (getBounds().top - this.mjFkc.IEE) - iHeight;
            canvas2.translate(-f, -f2);
            YoKzxo(canvas2);
            canvas.drawBitmap(bitmapCreateBitmap, f, f2, (Paint) null);
            bitmapCreateBitmap.recycle();
            canvas.restore();
        }
    }

    public final float wJVbdd() {
        if (zvd()) {
            return this.rkYL.getStrokeWidth() / 2.0f;
        }
        return 0.0f;
    }

    public final void xJ(RectF rectF, Path path) {
        lgHUyS(rectF, path);
        if (this.mjFkc.Dt != 1.0f) {
            this.JHa.reset();
            Matrix matrix = this.JHa;
            float f = this.mjFkc.Dt;
            matrix.setScale(f, f, rectF.width() / 2.0f, rectF.height() / 2.0f);
            path.transform(this.JHa);
        }
        path.computeBounds(this.Ucbh, true);
    }

    public final boolean xrEuO() {
        wA wAVar = this.mjFkc;
        int i = wAVar.fehf;
        return i != 1 && wAVar.IEE > 0 && (i == 2 || WrLQs());
    }

    public final boolean zvd() {
        Paint.Style style = this.mjFkc.Ucbh;
        return (style == Paint.Style.FILL_AND_STROKE || style == Paint.Style.STROKE) && this.rkYL.getStrokeWidth() > 0.0f;
    }

    public O1(Context context, AttributeSet attributeSet, int i, int i2) {
        this(I6.KLFTb(context, attributeSet, i, i2).MiMN());
    }

    public O1(I6 i6) {
        this(new wA(i6, null));
    }

    public O1(wA wAVar) {
        J6 j6;
        this.AZxh = new K6.xJ[4];
        this.wA = new K6.xJ[4];
        this.ZfxDd = new BitSet(8);
        this.JHa = new Matrix();
        this.xJ = new Path();
        this.lgHUyS = new Path();
        this.qdMbNW = new RectF();
        this.Dt = new RectF();
        this.ETF = new Region();
        this.VA = new Region();
        Paint paint = new Paint(1);
        this.YoKzxo = paint;
        Paint paint2 = new Paint(1);
        this.rkYL = paint2;
        this.qGY = new H6();
        if (Looper.getMainLooper().getThread() == Thread.currentThread()) {
            j6 = J6.ETF();
        } else {
            j6 = new J6();
        }
        this.IEE = j6;
        this.Ucbh = new RectF();
        this.huTpC = true;
        this.mjFkc = wAVar;
        paint2.setStyle(Paint.Style.STROKE);
        paint.setStyle(Paint.Style.FILL);
        jm();
        Vdz(getState());
        this.fehf = new mjFkc();
    }

    public static class wA extends Drawable.ConstantState {
        public uube AZxh;
        public float Dt;
        public float ETF;
        public int IEE;
        public ColorStateList JHa;
        public ColorStateList KLFTb;
        public int MiMN;
        public int Pq;
        public Paint.Style Ucbh;
        public float VA;
        public float YoKzxo;
        public ColorStateList ZfxDd;
        public int diqgf;
        public boolean eyqo;
        public int fehf;
        public PorterDuff.Mode lgHUyS;
        public I6 mjFkc;
        public float qGY;
        public Rect qdMbNW;
        public float rkYL;
        public ColorFilter wA;
        public ColorStateList xJ;

        public wA(I6 i6, uube uubeVar) {
            this.ZfxDd = null;
            this.KLFTb = null;
            this.JHa = null;
            this.xJ = null;
            this.lgHUyS = PorterDuff.Mode.SRC_IN;
            this.qdMbNW = null;
            this.Dt = 1.0f;
            this.ETF = 1.0f;
            this.MiMN = 255;
            this.YoKzxo = 0.0f;
            this.rkYL = 0.0f;
            this.qGY = 0.0f;
            this.fehf = 0;
            this.IEE = 0;
            this.Pq = 0;
            this.diqgf = 0;
            this.eyqo = false;
            this.Ucbh = Paint.Style.FILL_AND_STROKE;
            this.mjFkc = i6;
            this.AZxh = uubeVar;
        }

        @Override // android.graphics.drawable.Drawable.ConstantState
        public int getChangingConfigurations() {
            return 0;
        }

        @Override // android.graphics.drawable.Drawable.ConstantState
        public Drawable newDrawable() {
            O1 o1 = new O1(this);
            o1.KLFTb = true;
            return o1;
        }

        public wA(wA wAVar) {
            this.ZfxDd = null;
            this.KLFTb = null;
            this.JHa = null;
            this.xJ = null;
            this.lgHUyS = PorterDuff.Mode.SRC_IN;
            this.qdMbNW = null;
            this.Dt = 1.0f;
            this.ETF = 1.0f;
            this.MiMN = 255;
            this.YoKzxo = 0.0f;
            this.rkYL = 0.0f;
            this.qGY = 0.0f;
            this.fehf = 0;
            this.IEE = 0;
            this.Pq = 0;
            this.diqgf = 0;
            this.eyqo = false;
            this.Ucbh = Paint.Style.FILL_AND_STROKE;
            this.mjFkc = wAVar.mjFkc;
            this.AZxh = wAVar.AZxh;
            this.VA = wAVar.VA;
            this.wA = wAVar.wA;
            this.ZfxDd = wAVar.ZfxDd;
            this.KLFTb = wAVar.KLFTb;
            this.lgHUyS = wAVar.lgHUyS;
            this.xJ = wAVar.xJ;
            this.MiMN = wAVar.MiMN;
            this.Dt = wAVar.Dt;
            this.Pq = wAVar.Pq;
            this.fehf = wAVar.fehf;
            this.eyqo = wAVar.eyqo;
            this.ETF = wAVar.ETF;
            this.YoKzxo = wAVar.YoKzxo;
            this.rkYL = wAVar.rkYL;
            this.qGY = wAVar.qGY;
            this.IEE = wAVar.IEE;
            this.diqgf = wAVar.diqgf;
            this.JHa = wAVar.JHa;
            this.Ucbh = wAVar.Ucbh;
            if (wAVar.qdMbNW != null) {
                this.qdMbNW = new Rect(wAVar.qdMbNW);
            }
        }
    }
}
