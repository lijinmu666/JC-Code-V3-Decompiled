package o;

/* renamed from: o.k2, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public class C1376k2 extends Exception {
    public final int mjFkc;

    public C1376k2(String str, int i) {
        super(I3.JHa(str, "Provided message must not be empty."));
        this.mjFkc = i;
    }

    public int mjFkc() {
        return this.mjFkc;
    }

    public C1376k2(String str, int i, Throwable th) {
        super(I3.JHa(str, "Provided message must not be empty."), th);
        this.mjFkc = i;
    }
}
