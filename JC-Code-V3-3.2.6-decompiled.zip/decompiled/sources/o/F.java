package o;

import android.os.IBinder;
import android.os.IInterface;

/* loaded from: classes.dex */
public interface F extends IInterface {

    public static abstract class mjFkc extends AbstractBinderC1387kD implements F {
        public mjFkc() {
            super("com.google.android.gms.dynamic.IObjectWrapper");
        }

        public static F KLFTb(IBinder iBinder) {
            if (iBinder == null) {
                return null;
            }
            IInterface iInterfaceQueryLocalInterface = iBinder.queryLocalInterface("com.google.android.gms.dynamic.IObjectWrapper");
            return iInterfaceQueryLocalInterface instanceof F ? (F) iInterfaceQueryLocalInterface : new C1268iD(iBinder);
        }
    }
}
