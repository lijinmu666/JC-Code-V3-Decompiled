package o;

/* renamed from: o.oo, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C1661oo implements InterfaceC1252hy {
    public static final InterfaceC1252hy mjFkc = new C1661oo();

    @Override // o.InterfaceC1252hy
    public final boolean mjFkc(int i) {
        switch (i) {
            case 0:
            case 1:
            case 2:
            case 3:
            case 4:
            case 5:
            case 6:
                return true;
            default:
                return false;
        }
    }
}
