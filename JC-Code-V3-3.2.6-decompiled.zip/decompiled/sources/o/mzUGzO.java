package o;

import android.graphics.Typeface;

/* loaded from: classes.dex */
public final class mzUGzO extends X7 {
    public final mjFkc AZxh;
    public final Typeface mjFkc;
    public boolean wA;

    public interface mjFkc {
        void mjFkc(Typeface typeface);
    }

    public mzUGzO(mjFkc mjfkc, Typeface typeface) {
        this.mjFkc = typeface;
        this.AZxh = mjfkc;
    }

    @Override // o.X7
    public void AZxh(Typeface typeface, boolean z) {
        ZfxDd(typeface);
    }

    public final void ZfxDd(Typeface typeface) {
        if (this.wA) {
            return;
        }
        this.AZxh.mjFkc(typeface);
    }

    @Override // o.X7
    public void mjFkc(int i) {
        ZfxDd(this.mjFkc);
    }

    public void wA() {
        this.wA = true;
    }
}
