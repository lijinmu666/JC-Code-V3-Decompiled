package o;

/* renamed from: o.Pl, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0527Pl implements InterfaceC1252hy {
    public static final InterfaceC1252hy mjFkc = new C0527Pl();

    @Override // o.InterfaceC1252hy
    public final boolean mjFkc(int i) {
        return i == 0 || i == 1 || i == 2;
    }
}
