package o;

import o.C0797aQ;

/* renamed from: o.zO, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C2300zO implements R2 {
    public static final C2300zO mjFkc = new C2300zO();

    static {
        C0797aQ.AZxh aZxhMjFkc = C0797aQ.mjFkc("identifiedLanguages");
        C1389kF c1389kF = new C1389kF();
        c1389kF.mjFkc(1);
        aZxhMjFkc.AZxh(c1389kF.AZxh()).mjFkc();
    }

    @Override // o.mYYU
    public final /* bridge */ /* synthetic */ void mjFkc(Object obj, Object obj2) {
        AbstractC2102w7.mjFkc(obj);
        throw null;
    }
}
