package o;

import o.aqHPIZ;

/* loaded from: classes.dex */
public final class JYn {
    public final aqHPIZ AZxh;
    public final String ZfxDd;
    public final int mjFkc;
    public final aqHPIZ.ZfxDd wA;

    public JYn(aqHPIZ aqhpiz, aqHPIZ.ZfxDd zfxDd, String str) {
        this.AZxh = aqhpiz;
        this.wA = zfxDd;
        this.ZfxDd = str;
        this.mjFkc = U2.AZxh(aqhpiz, zfxDd, str);
    }

    public static JYn mjFkc(aqHPIZ aqhpiz, aqHPIZ.ZfxDd zfxDd, String str) {
        return new JYn(aqhpiz, zfxDd, str);
    }

    public final String AZxh() {
        return this.AZxh.AZxh();
    }

    public final boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof JYn)) {
            return false;
        }
        JYn jYn = (JYn) obj;
        return U2.mjFkc(this.AZxh, jYn.AZxh) && U2.mjFkc(this.wA, jYn.wA) && U2.mjFkc(this.ZfxDd, jYn.ZfxDd);
    }

    public final int hashCode() {
        return this.mjFkc;
    }
}
