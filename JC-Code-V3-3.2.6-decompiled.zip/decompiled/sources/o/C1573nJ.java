package o;

import o.C0797aQ;

/* renamed from: o.nJ, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C1573nJ implements R2 {
    public static final C0797aQ AZxh;
    public static final C0797aQ ZfxDd;
    public static final C1573nJ mjFkc = new C1573nJ();
    public static final C0797aQ wA;

    static {
        C0797aQ.AZxh aZxhMjFkc = C0797aQ.mjFkc("inferenceCommonLogEvent");
        OB ob = new OB();
        ob.mjFkc(1);
        AZxh = aZxhMjFkc.AZxh(ob.AZxh()).mjFkc();
        C0797aQ.AZxh aZxhMjFkc2 = C0797aQ.mjFkc("imageInfo");
        OB ob2 = new OB();
        ob2.mjFkc(2);
        wA = aZxhMjFkc2.AZxh(ob2.AZxh()).mjFkc();
        C0797aQ.AZxh aZxhMjFkc3 = C0797aQ.mjFkc("detectorOptions");
        OB ob3 = new OB();
        ob3.mjFkc(3);
        ZfxDd = aZxhMjFkc3.AZxh(ob3.AZxh()).mjFkc();
    }

    @Override // o.mYYU
    public final /* bridge */ /* synthetic */ void mjFkc(Object obj, Object obj2) {
        AbstractC2102w7.mjFkc(obj);
        throw null;
    }
}
