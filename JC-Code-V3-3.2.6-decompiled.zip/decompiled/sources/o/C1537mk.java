package o;

/* renamed from: o.mk, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C1537mk extends Vx implements Ly {
    public /* synthetic */ C1537mk(AbstractC1477lk abstractC1477lk) {
        super(C1597nk.zbb);
    }
}
