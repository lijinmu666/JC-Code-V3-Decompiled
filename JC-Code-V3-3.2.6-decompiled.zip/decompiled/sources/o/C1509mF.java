package o;

import java.io.OutputStream;

/* renamed from: o.mF, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C1509mF extends OutputStream {
    public long mjFkc = 0;

    public final long ZfxDd() {
        return this.mjFkc;
    }

    @Override // java.io.OutputStream
    public final void write(int i) {
        this.mjFkc++;
    }

    @Override // java.io.OutputStream
    public final void write(byte[] bArr) {
        this.mjFkc += bArr.length;
    }

    @Override // java.io.OutputStream
    public final void write(byte[] bArr, int i, int i2) {
        int length;
        int i3;
        if (i >= 0 && i <= (length = bArr.length) && i2 >= 0 && (i3 = i + i2) <= length && i3 >= 0) {
            this.mjFkc += i2;
            return;
        }
        throw new IndexOutOfBoundsException();
    }
}
