package o;

import kotlin.jvm.internal.Intrinsics;

/* loaded from: classes.dex */
public class E3 extends C3 {
    public final Object wA;

    public E3(int i) {
        super(i);
        this.wA = new Object();
    }

    @Override // o.C3, o.A3
    public Object AZxh() {
        Object objAZxh;
        synchronized (this.wA) {
            objAZxh = super.AZxh();
        }
        return objAZxh;
    }

    @Override // o.C3, o.A3
    public boolean mjFkc(Object instance) {
        boolean zMjFkc;
        Intrinsics.checkNotNullParameter(instance, "instance");
        synchronized (this.wA) {
            zMjFkc = super.mjFkc(instance);
        }
        return zMjFkc;
    }
}
