package o;

/* loaded from: classes.dex */
public final class Yz extends Vx implements Ly {
    public /* synthetic */ Yz(AbstractC2274yz abstractC2274yz) {
        super(Zz.zbb);
    }
}
