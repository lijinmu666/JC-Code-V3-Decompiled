package o;

/* renamed from: o.Gh, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0316Gh extends Vx implements Ly {
    public /* synthetic */ C0316Gh(AbstractC0293Fh abstractC0293Fh) {
        super(C0339Hh.zbb);
    }
}
