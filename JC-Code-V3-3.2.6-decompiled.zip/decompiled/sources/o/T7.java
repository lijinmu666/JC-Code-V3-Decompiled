package o;

import android.os.Bundle;
import o.aqHPIZ;

/* loaded from: classes.dex */
public class T7 implements aqHPIZ.ZfxDd {
    public static final T7 wA = mjFkc().mjFkc();
    public final String AZxh;

    public static class mjFkc {
        public String mjFkc;

        public /* synthetic */ mjFkc(AbstractC0564Rb abstractC0564Rb) {
        }

        public mjFkc AZxh(String str) {
            this.mjFkc = str;
            return this;
        }

        public T7 mjFkc() {
            return new T7(this.mjFkc, null);
        }
    }

    public /* synthetic */ T7(String str, AbstractC0610Tb abstractC0610Tb) {
        this.AZxh = str;
    }

    public static mjFkc mjFkc() {
        return new mjFkc(null);
    }

    public final Bundle AZxh() {
        Bundle bundle = new Bundle();
        String str = this.AZxh;
        if (str != null) {
            bundle.putString("api", str);
        }
        return bundle;
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (obj instanceof T7) {
            return U2.mjFkc(this.AZxh, ((T7) obj).AZxh);
        }
        return false;
    }

    public final int hashCode() {
        return U2.AZxh(this.AZxh);
    }
}
