package o;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import o.gtr;
import org.conscrypt.BuildConfig;

/* loaded from: classes.dex */
public abstract class HPA {

    public static abstract class mjFkc {
        public final mjFkc AZxh(String str, long j) {
            KLFTb().put(str, String.valueOf(j));
            return this;
        }

        public abstract mjFkc Dt(String str);

        public abstract mjFkc ETF(long j);

        public abstract mjFkc JHa(Map map);

        public abstract Map KLFTb();

        public abstract HPA ZfxDd();

        public abstract mjFkc lgHUyS(ZxmHEb zxmHEb);

        public final mjFkc mjFkc(String str, int i) {
            KLFTb().put(str, String.valueOf(i));
            return this;
        }

        public abstract mjFkc qdMbNW(long j);

        public final mjFkc wA(String str, String str2) {
            KLFTb().put(str, str2);
            return this;
        }

        public abstract mjFkc xJ(Integer num);
    }

    public static mjFkc mjFkc() {
        return new gtr.AZxh().JHa(new HashMap());
    }

    public final String AZxh(String str) {
        String str2 = (String) wA().get(str);
        return str2 == null ? BuildConfig.FLAVOR : str2;
    }

    public abstract String Dt();

    public abstract long ETF();

    public abstract long JHa();

    public abstract ZxmHEb KLFTb();

    public mjFkc VA() {
        return new gtr.AZxh().Dt(Dt()).xJ(ZfxDd()).lgHUyS(KLFTb()).qdMbNW(JHa()).ETF(ETF()).JHa(new HashMap(wA()));
    }

    public abstract Integer ZfxDd();

    public final long lgHUyS(String str) {
        String str2 = (String) wA().get(str);
        if (str2 == null) {
            return 0L;
        }
        return Long.valueOf(str2).longValue();
    }

    public final Map qdMbNW() {
        return Collections.unmodifiableMap(wA());
    }

    public abstract Map wA();

    public final int xJ(String str) {
        String str2 = (String) wA().get(str);
        if (str2 == null) {
            return 0;
        }
        return Integer.valueOf(str2).intValue();
    }
}
