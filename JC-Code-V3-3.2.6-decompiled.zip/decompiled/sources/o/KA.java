package o;

/* loaded from: classes.dex */
public final class KA extends Vx implements Ly {
    public /* synthetic */ KA(AbstractC2274yz abstractC2274yz) {
        super(LA.zbb);
    }
}
