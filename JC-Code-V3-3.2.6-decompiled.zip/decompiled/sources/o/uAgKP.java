package o;

import java.util.Map;

/* loaded from: classes.dex */
public final /* synthetic */ class uAgKP implements Runnable {
    public final Map.Entry mjFkc;

    public uAgKP(Map.Entry entry, CO co) {
        this.mjFkc = entry;
    }

    public static Runnable mjFkc(Map.Entry entry, CO co) {
        return new uAgKP(entry, co);
    }

    @Override // java.lang.Runnable
    public void run() {
        UmFn.wA(this.mjFkc, null);
    }
}
