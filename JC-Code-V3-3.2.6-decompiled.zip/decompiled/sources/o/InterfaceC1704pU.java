package o;

/* renamed from: o.pU, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public interface InterfaceC1704pU {
}
