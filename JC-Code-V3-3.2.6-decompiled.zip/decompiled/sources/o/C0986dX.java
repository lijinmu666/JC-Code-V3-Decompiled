package o;

/* renamed from: o.dX, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0986dX extends FT {
    public static final FT JHa = new C0986dX(null, new Object[0], 0);
    public final transient int KLFTb;
    public final transient Object[] ZfxDd;

    public C0986dX(Object obj, Object[] objArr, int i) {
        this.ZfxDd = objArr;
        this.KLFTb = i;
    }

    public static C0986dX xJ(int i, Object[] objArr, ZS zs) {
        Object obj = objArr[0];
        obj.getClass();
        Object obj2 = objArr[1];
        obj2.getClass();
        AbstractC1695pL.mjFkc(obj, obj2);
        return new C0986dX(null, objArr, 1);
    }

    @Override // o.FT
    public final AbstractC1823rU KLFTb() {
        return new WW(this, new C0804aX(this.ZfxDd, 0, this.KLFTb));
    }

    @Override // o.FT
    public final AbstractC1823rU ZfxDd() {
        return new QW(this, this.ZfxDd, 0, this.KLFTb);
    }

    /* JADX WARN: Removed duplicated region for block: B:4:0x0007  */
    @Override // o.FT, java.util.Map
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final Object get(Object obj) {
        Object obj2;
        Object[] objArr = this.ZfxDd;
        int i = this.KLFTb;
        if (obj != null && i == 1) {
            Object obj3 = objArr[0];
            obj3.getClass();
            if (obj3.equals(obj)) {
                obj2 = objArr[1];
                obj2.getClass();
            } else {
                obj2 = null;
            }
        }
        if (obj2 == null) {
            return null;
        }
        return obj2;
    }

    @Override // o.FT
    public final OO mjFkc() {
        return new C0804aX(this.ZfxDd, 1, this.KLFTb);
    }

    @Override // java.util.Map
    public final int size() {
        return this.KLFTb;
    }
}
