package o;

import android.graphics.RectF;
import java.util.Arrays;

/* loaded from: classes.dex */
public final class KLMXS implements cQmsjG {
    public final float AZxh;
    public final cQmsjG mjFkc;

    public KLMXS(float f, cQmsjG cqmsjg) {
        while (cqmsjg instanceof KLMXS) {
            cqmsjg = ((KLMXS) cqmsjg).mjFkc;
            f += ((KLMXS) cqmsjg).AZxh;
        }
        this.mjFkc = cqmsjg;
        this.AZxh = f;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof KLMXS)) {
            return false;
        }
        KLMXS klmxs = (KLMXS) obj;
        return this.mjFkc.equals(klmxs.mjFkc) && this.AZxh == klmxs.AZxh;
    }

    public int hashCode() {
        return Arrays.hashCode(new Object[]{this.mjFkc, Float.valueOf(this.AZxh)});
    }

    @Override // o.cQmsjG
    public float mjFkc(RectF rectF) {
        return Math.max(0.0f, this.mjFkc.mjFkc(rectF) + this.AZxh);
    }
}
