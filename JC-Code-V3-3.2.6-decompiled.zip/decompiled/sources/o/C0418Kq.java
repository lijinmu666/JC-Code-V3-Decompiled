package o;

/* renamed from: o.Kq, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0418Kq extends Vx implements Ly {
    public /* synthetic */ C0418Kq(AbstractC0395Jq abstractC0395Jq) {
        super(C0441Lq.zbb);
    }
}
