package o;

/* renamed from: o.sZ, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC1886sZ {
}
