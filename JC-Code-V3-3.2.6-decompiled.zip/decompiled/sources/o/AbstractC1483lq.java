package o;

/* renamed from: o.lq, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC1483lq {
}
