.class Lcafe/cryptography/curve25519/AffineNielsPoint$NafLookupTable;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcafe/cryptography/curve25519/AffineNielsPoint;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "NafLookupTable"
.end annotation


# instance fields
.field private final table:[Lcafe/cryptography/curve25519/AffineNielsPoint;


# direct methods
.method public constructor <init>([Lcafe/cryptography/curve25519/AffineNielsPoint;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcafe/cryptography/curve25519/AffineNielsPoint$NafLookupTable;->table:[Lcafe/cryptography/curve25519/AffineNielsPoint;

    return-void
.end method


# virtual methods
.method public select(I)Lcafe/cryptography/curve25519/AffineNielsPoint;
    .locals 1

    rem-int/lit8 v0, p1, 0x2

    if-eqz v0, :cond_0

    const/16 v0, 0x10

    if-ge p1, v0, :cond_0

    iget-object p0, p0, Lcafe/cryptography/curve25519/AffineNielsPoint$NafLookupTable;->table:[Lcafe/cryptography/curve25519/AffineNielsPoint;

    div-int/lit8 p1, p1, 0x2

    aget-object p0, p0, p1

    return-object p0

    :cond_0
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string p1, "invalid x"

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0
.end method
