.class public final Lcafe/cryptography/curve25519/Constants;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field static final AFFINE_ODD_MULTIPLES_OF_BASEPOINT:Lcafe/cryptography/curve25519/AffineNielsPoint$NafLookupTable;

.field static final BASEPOINT_ORDER:Lcafe/cryptography/curve25519/Scalar;

.field static final D_MINUS_ONE_SQ:Lcafe/cryptography/curve25519/FieldElement;

.field public static final ED25519_BASEPOINT:Lcafe/cryptography/curve25519/EdwardsPoint;

.field public static final ED25519_BASEPOINT_TABLE:Lcafe/cryptography/curve25519/EdwardsBasepointTable;

.field static final EDWARDS_2D:Lcafe/cryptography/curve25519/FieldElement;

.field static final EDWARDS_D:Lcafe/cryptography/curve25519/FieldElement;

.field static final INVSQRT_A_MINUS_D:Lcafe/cryptography/curve25519/FieldElement;

.field static final L:Lcafe/cryptography/curve25519/UnpackedScalar;

.field static final LFACTOR:I = 0x12547e1b

.field static final NEG_EDWARDS_D:Lcafe/cryptography/curve25519/FieldElement;

.field static final ONE_MINUS_D_SQ:Lcafe/cryptography/curve25519/FieldElement;

.field static final R:Lcafe/cryptography/curve25519/UnpackedScalar;

.field public static final RISTRETTO_GENERATOR:Lcafe/cryptography/curve25519/RistrettoElement;

.field public static final RISTRETTO_GENERATOR_TABLE:Lcafe/cryptography/curve25519/RistrettoGeneratorTable;

.field static final RR:Lcafe/cryptography/curve25519/UnpackedScalar;

.field static final SQRT_AD_MINUS_ONE:Lcafe/cryptography/curve25519/FieldElement;

.field static final SQRT_M1:Lcafe/cryptography/curve25519/FieldElement;


# direct methods
.method static constructor <clinit>()V
    .locals 6

    new-instance v0, Lcafe/cryptography/curve25519/Scalar;

    const/16 v1, 0x20

    new-array v1, v1, [B

    fill-array-data v1, :array_0

    invoke-direct {v0, v1}, Lcafe/cryptography/curve25519/Scalar;-><init>([B)V

    sput-object v0, Lcafe/cryptography/curve25519/Constants;->BASEPOINT_ORDER:Lcafe/cryptography/curve25519/Scalar;

    invoke-virtual {v0}, Lcafe/cryptography/curve25519/Scalar;->toByteArray()[B

    move-result-object v0

    invoke-static {v0}, Lcafe/cryptography/curve25519/UnpackedScalar;->fromByteArray([B)Lcafe/cryptography/curve25519/UnpackedScalar;

    move-result-object v0

    sput-object v0, Lcafe/cryptography/curve25519/Constants;->L:Lcafe/cryptography/curve25519/UnpackedScalar;

    new-instance v0, Lcafe/cryptography/curve25519/UnpackedScalar;

    const/16 v1, 0x9

    new-array v2, v1, [I

    fill-array-data v2, :array_1

    invoke-direct {v0, v2}, Lcafe/cryptography/curve25519/UnpackedScalar;-><init>([I)V

    sput-object v0, Lcafe/cryptography/curve25519/Constants;->R:Lcafe/cryptography/curve25519/UnpackedScalar;

    new-instance v0, Lcafe/cryptography/curve25519/UnpackedScalar;

    new-array v1, v1, [I

    fill-array-data v1, :array_2

    invoke-direct {v0, v1}, Lcafe/cryptography/curve25519/UnpackedScalar;-><init>([I)V

    sput-object v0, Lcafe/cryptography/curve25519/Constants;->RR:Lcafe/cryptography/curve25519/UnpackedScalar;

    new-instance v0, Lcafe/cryptography/curve25519/FieldElement;

    const/16 v1, 0xa

    new-array v2, v1, [I

    fill-array-data v2, :array_3

    invoke-direct {v0, v2}, Lcafe/cryptography/curve25519/FieldElement;-><init>([I)V

    sput-object v0, Lcafe/cryptography/curve25519/Constants;->EDWARDS_D:Lcafe/cryptography/curve25519/FieldElement;

    invoke-virtual {v0}, Lcafe/cryptography/curve25519/FieldElement;->negate()Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v2

    sput-object v2, Lcafe/cryptography/curve25519/Constants;->NEG_EDWARDS_D:Lcafe/cryptography/curve25519/FieldElement;

    new-instance v2, Lcafe/cryptography/curve25519/FieldElement;

    new-array v3, v1, [I

    fill-array-data v3, :array_4

    invoke-direct {v2, v3}, Lcafe/cryptography/curve25519/FieldElement;-><init>([I)V

    sput-object v2, Lcafe/cryptography/curve25519/Constants;->EDWARDS_2D:Lcafe/cryptography/curve25519/FieldElement;

    sget-object v2, Lcafe/cryptography/curve25519/FieldElement;->ONE:Lcafe/cryptography/curve25519/FieldElement;

    invoke-virtual {v0}, Lcafe/cryptography/curve25519/FieldElement;->square()Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v3

    invoke-virtual {v2, v3}, Lcafe/cryptography/curve25519/FieldElement;->subtract(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v3

    sput-object v3, Lcafe/cryptography/curve25519/Constants;->ONE_MINUS_D_SQ:Lcafe/cryptography/curve25519/FieldElement;

    invoke-virtual {v0, v2}, Lcafe/cryptography/curve25519/FieldElement;->subtract(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v0

    invoke-virtual {v0}, Lcafe/cryptography/curve25519/FieldElement;->square()Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v0

    sput-object v0, Lcafe/cryptography/curve25519/Constants;->D_MINUS_ONE_SQ:Lcafe/cryptography/curve25519/FieldElement;

    new-instance v0, Lcafe/cryptography/curve25519/FieldElement;

    new-array v2, v1, [I

    fill-array-data v2, :array_5

    invoke-direct {v0, v2}, Lcafe/cryptography/curve25519/FieldElement;-><init>([I)V

    sput-object v0, Lcafe/cryptography/curve25519/Constants;->SQRT_AD_MINUS_ONE:Lcafe/cryptography/curve25519/FieldElement;

    new-instance v0, Lcafe/cryptography/curve25519/FieldElement;

    new-array v2, v1, [I

    fill-array-data v2, :array_6

    invoke-direct {v0, v2}, Lcafe/cryptography/curve25519/FieldElement;-><init>([I)V

    sput-object v0, Lcafe/cryptography/curve25519/Constants;->INVSQRT_A_MINUS_D:Lcafe/cryptography/curve25519/FieldElement;

    new-instance v0, Lcafe/cryptography/curve25519/FieldElement;

    new-array v2, v1, [I

    fill-array-data v2, :array_7

    invoke-direct {v0, v2}, Lcafe/cryptography/curve25519/FieldElement;-><init>([I)V

    sput-object v0, Lcafe/cryptography/curve25519/Constants;->SQRT_M1:Lcafe/cryptography/curve25519/FieldElement;

    new-instance v0, Lcafe/cryptography/curve25519/EdwardsPoint;

    new-instance v2, Lcafe/cryptography/curve25519/FieldElement;

    new-array v3, v1, [I

    fill-array-data v3, :array_8

    invoke-direct {v2, v3}, Lcafe/cryptography/curve25519/FieldElement;-><init>([I)V

    new-instance v3, Lcafe/cryptography/curve25519/FieldElement;

    new-array v4, v1, [I

    fill-array-data v4, :array_9

    invoke-direct {v3, v4}, Lcafe/cryptography/curve25519/FieldElement;-><init>([I)V

    new-instance v4, Lcafe/cryptography/curve25519/FieldElement;

    new-array v5, v1, [I

    fill-array-data v5, :array_a

    invoke-direct {v4, v5}, Lcafe/cryptography/curve25519/FieldElement;-><init>([I)V

    new-instance v5, Lcafe/cryptography/curve25519/FieldElement;

    new-array v1, v1, [I

    fill-array-data v1, :array_b

    invoke-direct {v5, v1}, Lcafe/cryptography/curve25519/FieldElement;-><init>([I)V

    invoke-direct {v0, v2, v3, v4, v5}, Lcafe/cryptography/curve25519/EdwardsPoint;-><init>(Lcafe/cryptography/curve25519/FieldElement;Lcafe/cryptography/curve25519/FieldElement;Lcafe/cryptography/curve25519/FieldElement;Lcafe/cryptography/curve25519/FieldElement;)V

    sput-object v0, Lcafe/cryptography/curve25519/Constants;->ED25519_BASEPOINT:Lcafe/cryptography/curve25519/EdwardsPoint;

    new-instance v1, Lcafe/cryptography/curve25519/EdwardsBasepointTable;

    invoke-direct {v1, v0}, Lcafe/cryptography/curve25519/EdwardsBasepointTable;-><init>(Lcafe/cryptography/curve25519/EdwardsPoint;)V

    sput-object v1, Lcafe/cryptography/curve25519/Constants;->ED25519_BASEPOINT_TABLE:Lcafe/cryptography/curve25519/EdwardsBasepointTable;

    invoke-static {v0}, Lcafe/cryptography/curve25519/AffineNielsPoint;->buildNafLookupTable(Lcafe/cryptography/curve25519/EdwardsPoint;)Lcafe/cryptography/curve25519/AffineNielsPoint$NafLookupTable;

    move-result-object v1

    sput-object v1, Lcafe/cryptography/curve25519/Constants;->AFFINE_ODD_MULTIPLES_OF_BASEPOINT:Lcafe/cryptography/curve25519/AffineNielsPoint$NafLookupTable;

    new-instance v1, Lcafe/cryptography/curve25519/RistrettoElement;

    invoke-direct {v1, v0}, Lcafe/cryptography/curve25519/RistrettoElement;-><init>(Lcafe/cryptography/curve25519/EdwardsPoint;)V

    sput-object v1, Lcafe/cryptography/curve25519/Constants;->RISTRETTO_GENERATOR:Lcafe/cryptography/curve25519/RistrettoElement;

    new-instance v0, Lcafe/cryptography/curve25519/RistrettoGeneratorTable;

    invoke-direct {v0, v1}, Lcafe/cryptography/curve25519/RistrettoGeneratorTable;-><init>(Lcafe/cryptography/curve25519/RistrettoElement;)V

    sput-object v0, Lcafe/cryptography/curve25519/Constants;->RISTRETTO_GENERATOR_TABLE:Lcafe/cryptography/curve25519/RistrettoGeneratorTable;

    return-void

    nop

    :array_0
    .array-data 1
        -0x13t
        -0x2dt
        -0xbt
        0x5ct
        0x1at
        0x63t
        0x12t
        0x58t
        -0x2at
        -0x64t
        -0x9t
        -0x5et
        -0x22t
        -0x7t
        -0x22t
        0x14t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x10t
    .end array-data

    :array_1
    .array-data 4
        0x114df9ed
        0x1a617303
        0xf7c098c
        0x16793167
        0x1ffd656e
        0x1fffffff
        0x1fffffff
        0x1fffffff
        0xfffff
    .end array-data

    :array_2
    .array-data 4
        0xb5f9d12
        0x1e141b17
        0x158d7f3d
        0x143f3757
        0x1972d781
        0x42feb7c
        0x1ceec73d
        0x1e184d1e
        0x5046d
    .end array-data

    :array_3
    .array-data 4
        -0xa6874a
        0xd37285
        -0xea9143
        0x6a0a0f
        0x1c029
        -0x861768
        -0x5fc344
        -0x318e67
        -0x11d4900
        -0xb7f24c
    .end array-data

    :array_4
    .array-data 4
        -0x14d0ea7
        -0x591af6
        -0x1d52285
        0xd4141e
        0x38052
        0xf3d130
        -0xbf8689
        -0x631cce
        0x1c56e00
        0x901b67
    .end array-data

    :array_5
    .array-data 4
        0x17b2e1b
        -0x257ee
        -0x168502d
        0x60dbc3
        -0x14189c8
        -0xa2e02
        -0x1819b67
        -0xea7e18
        -0xd47cb
        0xdda4c7
    .end array-data

    :array_6
    .array-data 4
        0x5d40fd
        0x3f6aa0
        -0x1a82cc7
        0xbad20c
        -0x18b43a8
        0x1d841
        0x13dc8ff
        -0x6bbd28
        0x5cfb00
        -0x1e4ddc
    .end array-data

    :array_7
    .array-data 4
        -0x1f15f50
        -0x79362d
        0x8f189e
        0x35697f
        0xbd0c60
        -0x42859
        -0x17fb361
        -0x1e9a96
        0x4fc1e
        0xae0c92
    .end array-data

    :array_8
    .array-data 4
        -0xda2ae6
        -0x74a7dc
        0xf6592b
        -0xfb56d3
        0x1a4b31e
        -0x2923a4
        -0x18ee701
        0x7fd815
        0x13cd6e5
        0x85a4db
    .end array-data

    :array_9
    .array-data 4
        -0x1999995
        -0x666666
        0xcccccd
        -0xcccccd
        0x199999a
        0x666666
        -0xcccccd
        0xcccccd
        -0x199999a
        -0x666666
    .end array-data

    :array_a
    .array-data 4
        0x1
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_b
    .array-data 4
        0x1b7ddb6
        -0x5d5317
        -0x1a15244
        0x3ba8b
        0x83c27e
        0xabe37d
        0x1274732
        0xccacdd
        0xfd78b7
        -0x61e284
    .end array-data
.end method

.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
