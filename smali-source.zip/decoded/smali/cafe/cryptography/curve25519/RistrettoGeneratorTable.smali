.class public Lcafe/cryptography/curve25519/RistrettoGeneratorTable;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field final table:Lcafe/cryptography/curve25519/EdwardsBasepointTable;


# direct methods
.method public constructor <init>(Lcafe/cryptography/curve25519/RistrettoElement;)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Lcafe/cryptography/curve25519/EdwardsBasepointTable;

    iget-object p1, p1, Lcafe/cryptography/curve25519/RistrettoElement;->repr:Lcafe/cryptography/curve25519/EdwardsPoint;

    invoke-direct {v0, p1}, Lcafe/cryptography/curve25519/EdwardsBasepointTable;-><init>(Lcafe/cryptography/curve25519/EdwardsPoint;)V

    iput-object v0, p0, Lcafe/cryptography/curve25519/RistrettoGeneratorTable;->table:Lcafe/cryptography/curve25519/EdwardsBasepointTable;

    return-void
.end method


# virtual methods
.method public multiply(Lcafe/cryptography/curve25519/Scalar;)Lcafe/cryptography/curve25519/RistrettoElement;
    .locals 1

    new-instance v0, Lcafe/cryptography/curve25519/RistrettoElement;

    iget-object p0, p0, Lcafe/cryptography/curve25519/RistrettoGeneratorTable;->table:Lcafe/cryptography/curve25519/EdwardsBasepointTable;

    invoke-virtual {p0, p1}, Lcafe/cryptography/curve25519/EdwardsBasepointTable;->multiply(Lcafe/cryptography/curve25519/Scalar;)Lcafe/cryptography/curve25519/EdwardsPoint;

    move-result-object p0

    invoke-direct {v0, p0}, Lcafe/cryptography/curve25519/RistrettoElement;-><init>(Lcafe/cryptography/curve25519/EdwardsPoint;)V

    return-object v0
.end method
