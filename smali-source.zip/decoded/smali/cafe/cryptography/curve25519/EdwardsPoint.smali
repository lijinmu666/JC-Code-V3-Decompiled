.class public Lcafe/cryptography/curve25519/EdwardsPoint;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/io/Serializable;


# static fields
.field public static final IDENTITY:Lcafe/cryptography/curve25519/EdwardsPoint;

.field private static final serialVersionUID:J = 0x1L


# instance fields
.field transient T:Lcafe/cryptography/curve25519/FieldElement;

.field transient X:Lcafe/cryptography/curve25519/FieldElement;

.field transient Y:Lcafe/cryptography/curve25519/FieldElement;

.field transient Z:Lcafe/cryptography/curve25519/FieldElement;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    new-instance v0, Lcafe/cryptography/curve25519/EdwardsPoint;

    sget-object v1, Lcafe/cryptography/curve25519/FieldElement;->ZERO:Lcafe/cryptography/curve25519/FieldElement;

    sget-object v2, Lcafe/cryptography/curve25519/FieldElement;->ONE:Lcafe/cryptography/curve25519/FieldElement;

    invoke-direct {v0, v1, v2, v2, v1}, Lcafe/cryptography/curve25519/EdwardsPoint;-><init>(Lcafe/cryptography/curve25519/FieldElement;Lcafe/cryptography/curve25519/FieldElement;Lcafe/cryptography/curve25519/FieldElement;Lcafe/cryptography/curve25519/FieldElement;)V

    sput-object v0, Lcafe/cryptography/curve25519/EdwardsPoint;->IDENTITY:Lcafe/cryptography/curve25519/EdwardsPoint;

    return-void
.end method

.method public constructor <init>(Lcafe/cryptography/curve25519/FieldElement;Lcafe/cryptography/curve25519/FieldElement;Lcafe/cryptography/curve25519/FieldElement;Lcafe/cryptography/curve25519/FieldElement;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcafe/cryptography/curve25519/EdwardsPoint;->X:Lcafe/cryptography/curve25519/FieldElement;

    iput-object p2, p0, Lcafe/cryptography/curve25519/EdwardsPoint;->Y:Lcafe/cryptography/curve25519/FieldElement;

    iput-object p3, p0, Lcafe/cryptography/curve25519/EdwardsPoint;->Z:Lcafe/cryptography/curve25519/FieldElement;

    iput-object p4, p0, Lcafe/cryptography/curve25519/EdwardsPoint;->T:Lcafe/cryptography/curve25519/FieldElement;

    return-void
.end method

.method private readObject(Ljava/io/ObjectInputStream;)V
    .locals 1

    const/16 v0, 0x20

    new-array v0, v0, [B

    invoke-virtual {p1, v0}, Ljava/io/ObjectInputStream;->readFully([B)V

    :try_start_0
    new-instance p1, Lcafe/cryptography/curve25519/CompressedEdwardsY;

    invoke-direct {p1, v0}, Lcafe/cryptography/curve25519/CompressedEdwardsY;-><init>([B)V

    invoke-virtual {p1}, Lcafe/cryptography/curve25519/CompressedEdwardsY;->decompress()Lcafe/cryptography/curve25519/EdwardsPoint;

    move-result-object p1

    iget-object v0, p1, Lcafe/cryptography/curve25519/EdwardsPoint;->X:Lcafe/cryptography/curve25519/FieldElement;

    iput-object v0, p0, Lcafe/cryptography/curve25519/EdwardsPoint;->X:Lcafe/cryptography/curve25519/FieldElement;

    iget-object v0, p1, Lcafe/cryptography/curve25519/EdwardsPoint;->Y:Lcafe/cryptography/curve25519/FieldElement;

    iput-object v0, p0, Lcafe/cryptography/curve25519/EdwardsPoint;->Y:Lcafe/cryptography/curve25519/FieldElement;

    iget-object v0, p1, Lcafe/cryptography/curve25519/EdwardsPoint;->Z:Lcafe/cryptography/curve25519/FieldElement;

    iput-object v0, p0, Lcafe/cryptography/curve25519/EdwardsPoint;->Z:Lcafe/cryptography/curve25519/FieldElement;

    iget-object p1, p1, Lcafe/cryptography/curve25519/EdwardsPoint;->T:Lcafe/cryptography/curve25519/FieldElement;

    iput-object p1, p0, Lcafe/cryptography/curve25519/EdwardsPoint;->T:Lcafe/cryptography/curve25519/FieldElement;
    :try_end_0
    .catch Lcafe/cryptography/curve25519/InvalidEncodingException; {:try_start_0 .. :try_end_0} :catch_0

    return-void

    :catch_0
    move-exception p0

    new-instance p1, Ljava/io/InvalidObjectException;

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p0

    invoke-direct {p1, p0}, Ljava/io/InvalidObjectException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method private readObjectNoData()V
    .locals 1

    new-instance p0, Ljava/io/InvalidObjectException;

    const-string v0, "Cannot deserialize EdwardsPoint from no data"

    invoke-direct {p0, v0}, Ljava/io/InvalidObjectException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public static vartimeDoubleScalarMultiplyBasepoint(Lcafe/cryptography/curve25519/Scalar;Lcafe/cryptography/curve25519/EdwardsPoint;Lcafe/cryptography/curve25519/Scalar;)Lcafe/cryptography/curve25519/EdwardsPoint;
    .locals 4

    invoke-virtual {p0}, Lcafe/cryptography/curve25519/Scalar;->nonAdjacentForm()[B

    move-result-object p0

    invoke-virtual {p2}, Lcafe/cryptography/curve25519/Scalar;->nonAdjacentForm()[B

    move-result-object p2

    invoke-static {p1}, Lcafe/cryptography/curve25519/ProjectiveNielsPoint;->buildNafLookupTable(Lcafe/cryptography/curve25519/EdwardsPoint;)Lcafe/cryptography/curve25519/ProjectiveNielsPoint$NafLookupTable;

    move-result-object p1

    sget-object v0, Lcafe/cryptography/curve25519/Constants;->AFFINE_ODD_MULTIPLES_OF_BASEPOINT:Lcafe/cryptography/curve25519/AffineNielsPoint$NafLookupTable;

    const/16 v1, 0xff

    :goto_0
    if-ltz v1, :cond_1

    aget-byte v2, p0, v1

    if-nez v2, :cond_1

    aget-byte v2, p2, v1

    if-eqz v2, :cond_0

    goto :goto_1

    :cond_0
    add-int/lit8 v1, v1, -0x1

    goto :goto_0

    :cond_1
    :goto_1
    sget-object v2, Lcafe/cryptography/curve25519/EdwardsPoint;->IDENTITY:Lcafe/cryptography/curve25519/EdwardsPoint;

    invoke-virtual {v2}, Lcafe/cryptography/curve25519/EdwardsPoint;->toProjective()Lcafe/cryptography/curve25519/ProjectivePoint;

    move-result-object v2

    :goto_2
    if-ltz v1, :cond_6

    invoke-virtual {v2}, Lcafe/cryptography/curve25519/ProjectivePoint;->dbl()Lcafe/cryptography/curve25519/CompletedPoint;

    move-result-object v2

    aget-byte v3, p0, v1

    if-lez v3, :cond_2

    invoke-virtual {v2}, Lcafe/cryptography/curve25519/CompletedPoint;->toExtended()Lcafe/cryptography/curve25519/EdwardsPoint;

    move-result-object v2

    aget-byte v3, p0, v1

    invoke-virtual {p1, v3}, Lcafe/cryptography/curve25519/ProjectiveNielsPoint$NafLookupTable;->select(I)Lcafe/cryptography/curve25519/ProjectiveNielsPoint;

    move-result-object v3

    invoke-virtual {v2, v3}, Lcafe/cryptography/curve25519/EdwardsPoint;->add(Lcafe/cryptography/curve25519/ProjectiveNielsPoint;)Lcafe/cryptography/curve25519/CompletedPoint;

    move-result-object v2

    goto :goto_3

    :cond_2
    if-gez v3, :cond_3

    invoke-virtual {v2}, Lcafe/cryptography/curve25519/CompletedPoint;->toExtended()Lcafe/cryptography/curve25519/EdwardsPoint;

    move-result-object v2

    aget-byte v3, p0, v1

    neg-int v3, v3

    invoke-virtual {p1, v3}, Lcafe/cryptography/curve25519/ProjectiveNielsPoint$NafLookupTable;->select(I)Lcafe/cryptography/curve25519/ProjectiveNielsPoint;

    move-result-object v3

    invoke-virtual {v2, v3}, Lcafe/cryptography/curve25519/EdwardsPoint;->subtract(Lcafe/cryptography/curve25519/ProjectiveNielsPoint;)Lcafe/cryptography/curve25519/CompletedPoint;

    move-result-object v2

    :cond_3
    :goto_3
    aget-byte v3, p2, v1

    if-lez v3, :cond_4

    invoke-virtual {v2}, Lcafe/cryptography/curve25519/CompletedPoint;->toExtended()Lcafe/cryptography/curve25519/EdwardsPoint;

    move-result-object v2

    aget-byte v3, p2, v1

    invoke-virtual {v0, v3}, Lcafe/cryptography/curve25519/AffineNielsPoint$NafLookupTable;->select(I)Lcafe/cryptography/curve25519/AffineNielsPoint;

    move-result-object v3

    invoke-virtual {v2, v3}, Lcafe/cryptography/curve25519/EdwardsPoint;->add(Lcafe/cryptography/curve25519/AffineNielsPoint;)Lcafe/cryptography/curve25519/CompletedPoint;

    move-result-object v2

    goto :goto_4

    :cond_4
    if-gez v3, :cond_5

    invoke-virtual {v2}, Lcafe/cryptography/curve25519/CompletedPoint;->toExtended()Lcafe/cryptography/curve25519/EdwardsPoint;

    move-result-object v2

    aget-byte v3, p2, v1

    neg-int v3, v3

    invoke-virtual {v0, v3}, Lcafe/cryptography/curve25519/AffineNielsPoint$NafLookupTable;->select(I)Lcafe/cryptography/curve25519/AffineNielsPoint;

    move-result-object v3

    invoke-virtual {v2, v3}, Lcafe/cryptography/curve25519/EdwardsPoint;->subtract(Lcafe/cryptography/curve25519/AffineNielsPoint;)Lcafe/cryptography/curve25519/CompletedPoint;

    move-result-object v2

    :cond_5
    :goto_4
    invoke-virtual {v2}, Lcafe/cryptography/curve25519/CompletedPoint;->toProjective()Lcafe/cryptography/curve25519/ProjectivePoint;

    move-result-object v2

    add-int/lit8 v1, v1, -0x1

    goto :goto_2

    :cond_6
    invoke-virtual {v2}, Lcafe/cryptography/curve25519/ProjectivePoint;->toExtended()Lcafe/cryptography/curve25519/EdwardsPoint;

    move-result-object p0

    return-object p0
.end method

.method private writeObject(Ljava/io/ObjectOutputStream;)V
    .locals 0

    invoke-virtual {p0}, Lcafe/cryptography/curve25519/EdwardsPoint;->compress()Lcafe/cryptography/curve25519/CompressedEdwardsY;

    move-result-object p0

    invoke-virtual {p0}, Lcafe/cryptography/curve25519/CompressedEdwardsY;->toByteArray()[B

    move-result-object p0

    invoke-virtual {p1, p0}, Ljava/io/ObjectOutputStream;->write([B)V

    return-void
.end method


# virtual methods
.method public add(Lcafe/cryptography/curve25519/AffineNielsPoint;)Lcafe/cryptography/curve25519/CompletedPoint;
    .locals 4

    .line 10
    iget-object v0, p0, Lcafe/cryptography/curve25519/EdwardsPoint;->Y:Lcafe/cryptography/curve25519/FieldElement;

    iget-object v1, p0, Lcafe/cryptography/curve25519/EdwardsPoint;->X:Lcafe/cryptography/curve25519/FieldElement;

    invoke-virtual {v0, v1}, Lcafe/cryptography/curve25519/FieldElement;->add(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v0

    .line 11
    iget-object v1, p0, Lcafe/cryptography/curve25519/EdwardsPoint;->Y:Lcafe/cryptography/curve25519/FieldElement;

    iget-object v2, p0, Lcafe/cryptography/curve25519/EdwardsPoint;->X:Lcafe/cryptography/curve25519/FieldElement;

    invoke-virtual {v1, v2}, Lcafe/cryptography/curve25519/FieldElement;->subtract(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v1

    .line 12
    iget-object v2, p1, Lcafe/cryptography/curve25519/AffineNielsPoint;->yPlusx:Lcafe/cryptography/curve25519/FieldElement;

    invoke-virtual {v0, v2}, Lcafe/cryptography/curve25519/FieldElement;->multiply(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v0

    .line 13
    iget-object v2, p1, Lcafe/cryptography/curve25519/AffineNielsPoint;->yMinusx:Lcafe/cryptography/curve25519/FieldElement;

    invoke-virtual {v1, v2}, Lcafe/cryptography/curve25519/FieldElement;->multiply(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v1

    .line 14
    iget-object v2, p0, Lcafe/cryptography/curve25519/EdwardsPoint;->T:Lcafe/cryptography/curve25519/FieldElement;

    iget-object p1, p1, Lcafe/cryptography/curve25519/AffineNielsPoint;->xy2D:Lcafe/cryptography/curve25519/FieldElement;

    invoke-virtual {v2, p1}, Lcafe/cryptography/curve25519/FieldElement;->multiply(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object p1

    .line 15
    iget-object p0, p0, Lcafe/cryptography/curve25519/EdwardsPoint;->Z:Lcafe/cryptography/curve25519/FieldElement;

    invoke-virtual {p0, p0}, Lcafe/cryptography/curve25519/FieldElement;->add(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object p0

    .line 16
    new-instance v2, Lcafe/cryptography/curve25519/CompletedPoint;

    invoke-virtual {v0, v1}, Lcafe/cryptography/curve25519/FieldElement;->subtract(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v3

    invoke-virtual {v0, v1}, Lcafe/cryptography/curve25519/FieldElement;->add(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v0

    invoke-virtual {p0, p1}, Lcafe/cryptography/curve25519/FieldElement;->add(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v1

    invoke-virtual {p0, p1}, Lcafe/cryptography/curve25519/FieldElement;->subtract(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object p0

    invoke-direct {v2, v3, v0, v1, p0}, Lcafe/cryptography/curve25519/CompletedPoint;-><init>(Lcafe/cryptography/curve25519/FieldElement;Lcafe/cryptography/curve25519/FieldElement;Lcafe/cryptography/curve25519/FieldElement;Lcafe/cryptography/curve25519/FieldElement;)V

    return-object v2
.end method

.method public add(Lcafe/cryptography/curve25519/ProjectiveNielsPoint;)Lcafe/cryptography/curve25519/CompletedPoint;
    .locals 4

    .line 2
    iget-object v0, p0, Lcafe/cryptography/curve25519/EdwardsPoint;->Y:Lcafe/cryptography/curve25519/FieldElement;

    iget-object v1, p0, Lcafe/cryptography/curve25519/EdwardsPoint;->X:Lcafe/cryptography/curve25519/FieldElement;

    invoke-virtual {v0, v1}, Lcafe/cryptography/curve25519/FieldElement;->add(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v0

    .line 3
    iget-object v1, p0, Lcafe/cryptography/curve25519/EdwardsPoint;->Y:Lcafe/cryptography/curve25519/FieldElement;

    iget-object v2, p0, Lcafe/cryptography/curve25519/EdwardsPoint;->X:Lcafe/cryptography/curve25519/FieldElement;

    invoke-virtual {v1, v2}, Lcafe/cryptography/curve25519/FieldElement;->subtract(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v1

    .line 4
    iget-object v2, p1, Lcafe/cryptography/curve25519/ProjectiveNielsPoint;->YPlusX:Lcafe/cryptography/curve25519/FieldElement;

    invoke-virtual {v0, v2}, Lcafe/cryptography/curve25519/FieldElement;->multiply(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v0

    .line 5
    iget-object v2, p1, Lcafe/cryptography/curve25519/ProjectiveNielsPoint;->YMinusX:Lcafe/cryptography/curve25519/FieldElement;

    invoke-virtual {v1, v2}, Lcafe/cryptography/curve25519/FieldElement;->multiply(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v1

    .line 6
    iget-object v2, p0, Lcafe/cryptography/curve25519/EdwardsPoint;->T:Lcafe/cryptography/curve25519/FieldElement;

    iget-object v3, p1, Lcafe/cryptography/curve25519/ProjectiveNielsPoint;->T2D:Lcafe/cryptography/curve25519/FieldElement;

    invoke-virtual {v2, v3}, Lcafe/cryptography/curve25519/FieldElement;->multiply(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v2

    .line 7
    iget-object p0, p0, Lcafe/cryptography/curve25519/EdwardsPoint;->Z:Lcafe/cryptography/curve25519/FieldElement;

    iget-object p1, p1, Lcafe/cryptography/curve25519/ProjectiveNielsPoint;->Z:Lcafe/cryptography/curve25519/FieldElement;

    invoke-virtual {p0, p1}, Lcafe/cryptography/curve25519/FieldElement;->multiply(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object p0

    .line 8
    invoke-virtual {p0, p0}, Lcafe/cryptography/curve25519/FieldElement;->add(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object p0

    .line 9
    new-instance p1, Lcafe/cryptography/curve25519/CompletedPoint;

    invoke-virtual {v0, v1}, Lcafe/cryptography/curve25519/FieldElement;->subtract(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v3

    invoke-virtual {v0, v1}, Lcafe/cryptography/curve25519/FieldElement;->add(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v0

    invoke-virtual {p0, v2}, Lcafe/cryptography/curve25519/FieldElement;->add(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v1

    invoke-virtual {p0, v2}, Lcafe/cryptography/curve25519/FieldElement;->subtract(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object p0

    invoke-direct {p1, v3, v0, v1, p0}, Lcafe/cryptography/curve25519/CompletedPoint;-><init>(Lcafe/cryptography/curve25519/FieldElement;Lcafe/cryptography/curve25519/FieldElement;Lcafe/cryptography/curve25519/FieldElement;Lcafe/cryptography/curve25519/FieldElement;)V

    return-object p1
.end method

.method public add(Lcafe/cryptography/curve25519/EdwardsPoint;)Lcafe/cryptography/curve25519/EdwardsPoint;
    .locals 0

    .line 1
    invoke-virtual {p1}, Lcafe/cryptography/curve25519/EdwardsPoint;->toProjectiveNiels()Lcafe/cryptography/curve25519/ProjectiveNielsPoint;

    move-result-object p1

    invoke-virtual {p0, p1}, Lcafe/cryptography/curve25519/EdwardsPoint;->add(Lcafe/cryptography/curve25519/ProjectiveNielsPoint;)Lcafe/cryptography/curve25519/CompletedPoint;

    move-result-object p0

    invoke-virtual {p0}, Lcafe/cryptography/curve25519/CompletedPoint;->toExtended()Lcafe/cryptography/curve25519/EdwardsPoint;

    move-result-object p0

    return-object p0
.end method

.method public compress()Lcafe/cryptography/curve25519/CompressedEdwardsY;
    .locals 3

    iget-object v0, p0, Lcafe/cryptography/curve25519/EdwardsPoint;->Z:Lcafe/cryptography/curve25519/FieldElement;

    invoke-virtual {v0}, Lcafe/cryptography/curve25519/FieldElement;->invert()Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v0

    iget-object v1, p0, Lcafe/cryptography/curve25519/EdwardsPoint;->X:Lcafe/cryptography/curve25519/FieldElement;

    invoke-virtual {v1, v0}, Lcafe/cryptography/curve25519/FieldElement;->multiply(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v1

    iget-object p0, p0, Lcafe/cryptography/curve25519/EdwardsPoint;->Y:Lcafe/cryptography/curve25519/FieldElement;

    invoke-virtual {p0, v0}, Lcafe/cryptography/curve25519/FieldElement;->multiply(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object p0

    invoke-virtual {p0}, Lcafe/cryptography/curve25519/FieldElement;->toByteArray()[B

    move-result-object p0

    const/16 v0, 0x1f

    aget-byte v2, p0, v0

    invoke-virtual {v1}, Lcafe/cryptography/curve25519/FieldElement;->isNegative()I

    move-result v1

    shl-int/lit8 v1, v1, 0x7

    or-int/2addr v1, v2

    int-to-byte v1, v1

    aput-byte v1, p0, v0

    new-instance v0, Lcafe/cryptography/curve25519/CompressedEdwardsY;

    invoke-direct {v0, p0}, Lcafe/cryptography/curve25519/CompressedEdwardsY;-><init>([B)V

    return-object v0
.end method

.method public ctEquals(Lcafe/cryptography/curve25519/EdwardsPoint;)I
    .locals 0

    invoke-virtual {p0}, Lcafe/cryptography/curve25519/EdwardsPoint;->compress()Lcafe/cryptography/curve25519/CompressedEdwardsY;

    move-result-object p0

    invoke-virtual {p1}, Lcafe/cryptography/curve25519/EdwardsPoint;->compress()Lcafe/cryptography/curve25519/CompressedEdwardsY;

    move-result-object p1

    invoke-virtual {p0, p1}, Lcafe/cryptography/curve25519/CompressedEdwardsY;->ctEquals(Lcafe/cryptography/curve25519/CompressedEdwardsY;)I

    move-result p0

    return p0
.end method

.method public ctSelect(Lcafe/cryptography/curve25519/EdwardsPoint;I)Lcafe/cryptography/curve25519/EdwardsPoint;
    .locals 5

    new-instance v0, Lcafe/cryptography/curve25519/EdwardsPoint;

    iget-object v1, p0, Lcafe/cryptography/curve25519/EdwardsPoint;->X:Lcafe/cryptography/curve25519/FieldElement;

    iget-object v2, p1, Lcafe/cryptography/curve25519/EdwardsPoint;->X:Lcafe/cryptography/curve25519/FieldElement;

    invoke-virtual {v1, v2, p2}, Lcafe/cryptography/curve25519/FieldElement;->ctSelect(Lcafe/cryptography/curve25519/FieldElement;I)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v1

    iget-object v2, p0, Lcafe/cryptography/curve25519/EdwardsPoint;->Y:Lcafe/cryptography/curve25519/FieldElement;

    iget-object v3, p1, Lcafe/cryptography/curve25519/EdwardsPoint;->Y:Lcafe/cryptography/curve25519/FieldElement;

    invoke-virtual {v2, v3, p2}, Lcafe/cryptography/curve25519/FieldElement;->ctSelect(Lcafe/cryptography/curve25519/FieldElement;I)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v2

    iget-object v3, p0, Lcafe/cryptography/curve25519/EdwardsPoint;->Z:Lcafe/cryptography/curve25519/FieldElement;

    iget-object v4, p1, Lcafe/cryptography/curve25519/EdwardsPoint;->Z:Lcafe/cryptography/curve25519/FieldElement;

    invoke-virtual {v3, v4, p2}, Lcafe/cryptography/curve25519/FieldElement;->ctSelect(Lcafe/cryptography/curve25519/FieldElement;I)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v3

    iget-object p0, p0, Lcafe/cryptography/curve25519/EdwardsPoint;->T:Lcafe/cryptography/curve25519/FieldElement;

    iget-object p1, p1, Lcafe/cryptography/curve25519/EdwardsPoint;->T:Lcafe/cryptography/curve25519/FieldElement;

    invoke-virtual {p0, p1, p2}, Lcafe/cryptography/curve25519/FieldElement;->ctSelect(Lcafe/cryptography/curve25519/FieldElement;I)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object p0

    invoke-direct {v0, v1, v2, v3, p0}, Lcafe/cryptography/curve25519/EdwardsPoint;-><init>(Lcafe/cryptography/curve25519/FieldElement;Lcafe/cryptography/curve25519/FieldElement;Lcafe/cryptography/curve25519/FieldElement;Lcafe/cryptography/curve25519/FieldElement;)V

    return-object v0
.end method

.method public dbl()Lcafe/cryptography/curve25519/EdwardsPoint;
    .locals 0

    invoke-virtual {p0}, Lcafe/cryptography/curve25519/EdwardsPoint;->toProjective()Lcafe/cryptography/curve25519/ProjectivePoint;

    move-result-object p0

    invoke-virtual {p0}, Lcafe/cryptography/curve25519/ProjectivePoint;->dbl()Lcafe/cryptography/curve25519/CompletedPoint;

    move-result-object p0

    invoke-virtual {p0}, Lcafe/cryptography/curve25519/CompletedPoint;->toExtended()Lcafe/cryptography/curve25519/EdwardsPoint;

    move-result-object p0

    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 2

    instance-of v0, p1, Lcafe/cryptography/curve25519/EdwardsPoint;

    const/4 v1, 0x0

    if-nez v0, :cond_0

    return v1

    :cond_0
    check-cast p1, Lcafe/cryptography/curve25519/EdwardsPoint;

    invoke-virtual {p0, p1}, Lcafe/cryptography/curve25519/EdwardsPoint;->ctEquals(Lcafe/cryptography/curve25519/EdwardsPoint;)I

    move-result p0

    const/4 p1, 0x1

    if-ne p0, p1, :cond_1

    move v1, p1

    :cond_1
    return v1
.end method

.method public hashCode()I
    .locals 0

    invoke-virtual {p0}, Lcafe/cryptography/curve25519/EdwardsPoint;->compress()Lcafe/cryptography/curve25519/CompressedEdwardsY;

    move-result-object p0

    invoke-virtual {p0}, Lcafe/cryptography/curve25519/CompressedEdwardsY;->hashCode()I

    move-result p0

    return p0
.end method

.method public isIdentity()Z
    .locals 1

    sget-object v0, Lcafe/cryptography/curve25519/EdwardsPoint;->IDENTITY:Lcafe/cryptography/curve25519/EdwardsPoint;

    invoke-virtual {p0, v0}, Lcafe/cryptography/curve25519/EdwardsPoint;->ctEquals(Lcafe/cryptography/curve25519/EdwardsPoint;)I

    move-result p0

    const/4 v0, 0x1

    if-ne p0, v0, :cond_0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public isSmallOrder()Z
    .locals 0

    invoke-virtual {p0}, Lcafe/cryptography/curve25519/EdwardsPoint;->multiplyByCofactor()Lcafe/cryptography/curve25519/EdwardsPoint;

    move-result-object p0

    invoke-virtual {p0}, Lcafe/cryptography/curve25519/EdwardsPoint;->isIdentity()Z

    move-result p0

    return p0
.end method

.method public isTorsionFree()Z
    .locals 1

    sget-object v0, Lcafe/cryptography/curve25519/Constants;->BASEPOINT_ORDER:Lcafe/cryptography/curve25519/Scalar;

    invoke-virtual {p0, v0}, Lcafe/cryptography/curve25519/EdwardsPoint;->multiply(Lcafe/cryptography/curve25519/Scalar;)Lcafe/cryptography/curve25519/EdwardsPoint;

    move-result-object p0

    invoke-virtual {p0}, Lcafe/cryptography/curve25519/EdwardsPoint;->isIdentity()Z

    move-result p0

    return p0
.end method

.method public multiply(Lcafe/cryptography/curve25519/Scalar;)Lcafe/cryptography/curve25519/EdwardsPoint;
    .locals 3

    invoke-static {p0}, Lcafe/cryptography/curve25519/ProjectiveNielsPoint;->buildLookupTable(Lcafe/cryptography/curve25519/EdwardsPoint;)Lcafe/cryptography/curve25519/ProjectiveNielsPoint$LookupTable;

    move-result-object p0

    invoke-virtual {p1}, Lcafe/cryptography/curve25519/Scalar;->toRadix16()[B

    move-result-object p1

    sget-object v0, Lcafe/cryptography/curve25519/EdwardsPoint;->IDENTITY:Lcafe/cryptography/curve25519/EdwardsPoint;

    const/16 v1, 0x3f

    :goto_0
    if-ltz v1, :cond_0

    const/4 v2, 0x4

    invoke-virtual {v0, v2}, Lcafe/cryptography/curve25519/EdwardsPoint;->multiplyByPow2(I)Lcafe/cryptography/curve25519/EdwardsPoint;

    move-result-object v0

    aget-byte v2, p1, v1

    invoke-virtual {p0, v2}, Lcafe/cryptography/curve25519/ProjectiveNielsPoint$LookupTable;->select(I)Lcafe/cryptography/curve25519/ProjectiveNielsPoint;

    move-result-object v2

    invoke-virtual {v0, v2}, Lcafe/cryptography/curve25519/EdwardsPoint;->add(Lcafe/cryptography/curve25519/ProjectiveNielsPoint;)Lcafe/cryptography/curve25519/CompletedPoint;

    move-result-object v0

    invoke-virtual {v0}, Lcafe/cryptography/curve25519/CompletedPoint;->toExtended()Lcafe/cryptography/curve25519/EdwardsPoint;

    move-result-object v0

    add-int/lit8 v1, v1, -0x1

    goto :goto_0

    :cond_0
    return-object v0
.end method

.method public multiplyByCofactor()Lcafe/cryptography/curve25519/EdwardsPoint;
    .locals 1

    const/4 v0, 0x3

    invoke-virtual {p0, v0}, Lcafe/cryptography/curve25519/EdwardsPoint;->multiplyByPow2(I)Lcafe/cryptography/curve25519/EdwardsPoint;

    move-result-object p0

    return-object p0
.end method

.method public multiplyByPow2(I)Lcafe/cryptography/curve25519/EdwardsPoint;
    .locals 2

    if-lez p1, :cond_1

    invoke-virtual {p0}, Lcafe/cryptography/curve25519/EdwardsPoint;->toProjective()Lcafe/cryptography/curve25519/ProjectivePoint;

    move-result-object p0

    const/4 v0, 0x0

    :goto_0
    add-int/lit8 v1, p1, -0x1

    if-ge v0, v1, :cond_0

    invoke-virtual {p0}, Lcafe/cryptography/curve25519/ProjectivePoint;->dbl()Lcafe/cryptography/curve25519/CompletedPoint;

    move-result-object p0

    invoke-virtual {p0}, Lcafe/cryptography/curve25519/CompletedPoint;->toProjective()Lcafe/cryptography/curve25519/ProjectivePoint;

    move-result-object p0

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_0
    invoke-virtual {p0}, Lcafe/cryptography/curve25519/ProjectivePoint;->dbl()Lcafe/cryptography/curve25519/CompletedPoint;

    move-result-object p0

    invoke-virtual {p0}, Lcafe/cryptography/curve25519/CompletedPoint;->toExtended()Lcafe/cryptography/curve25519/EdwardsPoint;

    move-result-object p0

    return-object p0

    :cond_1
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string p1, "Exponent must be positive and non-zero"

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public negate()Lcafe/cryptography/curve25519/EdwardsPoint;
    .locals 4

    new-instance v0, Lcafe/cryptography/curve25519/EdwardsPoint;

    iget-object v1, p0, Lcafe/cryptography/curve25519/EdwardsPoint;->X:Lcafe/cryptography/curve25519/FieldElement;

    invoke-virtual {v1}, Lcafe/cryptography/curve25519/FieldElement;->negate()Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v1

    iget-object v2, p0, Lcafe/cryptography/curve25519/EdwardsPoint;->Y:Lcafe/cryptography/curve25519/FieldElement;

    iget-object v3, p0, Lcafe/cryptography/curve25519/EdwardsPoint;->Z:Lcafe/cryptography/curve25519/FieldElement;

    iget-object p0, p0, Lcafe/cryptography/curve25519/EdwardsPoint;->T:Lcafe/cryptography/curve25519/FieldElement;

    invoke-virtual {p0}, Lcafe/cryptography/curve25519/FieldElement;->negate()Lcafe/cryptography/curve25519/FieldElement;

    move-result-object p0

    invoke-direct {v0, v1, v2, v3, p0}, Lcafe/cryptography/curve25519/EdwardsPoint;-><init>(Lcafe/cryptography/curve25519/FieldElement;Lcafe/cryptography/curve25519/FieldElement;Lcafe/cryptography/curve25519/FieldElement;Lcafe/cryptography/curve25519/FieldElement;)V

    return-object v0
.end method

.method public printInternalRepresentation()Ljava/lang/String;
    .locals 3

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "EdwardsPoint(\n"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "    X: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lcafe/cryptography/curve25519/EdwardsPoint;->X:Lcafe/cryptography/curve25519/FieldElement;

    invoke-virtual {v1}, Lcafe/cryptography/curve25519/FieldElement;->printInternalRepresentation()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, ",\n"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, "    Y: "

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v0, p0, Lcafe/cryptography/curve25519/EdwardsPoint;->Y:Lcafe/cryptography/curve25519/FieldElement;

    invoke-virtual {v0}, Lcafe/cryptography/curve25519/FieldElement;->printInternalRepresentation()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, "    Z: "

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v0, p0, Lcafe/cryptography/curve25519/EdwardsPoint;->Z:Lcafe/cryptography/curve25519/FieldElement;

    invoke-virtual {v0}, Lcafe/cryptography/curve25519/FieldElement;->printInternalRepresentation()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, "    T: "

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object p0, p0, Lcafe/cryptography/curve25519/EdwardsPoint;->T:Lcafe/cryptography/curve25519/FieldElement;

    invoke-virtual {p0}, Lcafe/cryptography/curve25519/FieldElement;->printInternalRepresentation()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p0, ")"

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public subtract(Lcafe/cryptography/curve25519/AffineNielsPoint;)Lcafe/cryptography/curve25519/CompletedPoint;
    .locals 4

    .line 10
    iget-object v0, p0, Lcafe/cryptography/curve25519/EdwardsPoint;->Y:Lcafe/cryptography/curve25519/FieldElement;

    iget-object v1, p0, Lcafe/cryptography/curve25519/EdwardsPoint;->X:Lcafe/cryptography/curve25519/FieldElement;

    invoke-virtual {v0, v1}, Lcafe/cryptography/curve25519/FieldElement;->add(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v0

    .line 11
    iget-object v1, p0, Lcafe/cryptography/curve25519/EdwardsPoint;->Y:Lcafe/cryptography/curve25519/FieldElement;

    iget-object v2, p0, Lcafe/cryptography/curve25519/EdwardsPoint;->X:Lcafe/cryptography/curve25519/FieldElement;

    invoke-virtual {v1, v2}, Lcafe/cryptography/curve25519/FieldElement;->subtract(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v1

    .line 12
    iget-object v2, p1, Lcafe/cryptography/curve25519/AffineNielsPoint;->yMinusx:Lcafe/cryptography/curve25519/FieldElement;

    invoke-virtual {v0, v2}, Lcafe/cryptography/curve25519/FieldElement;->multiply(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v0

    .line 13
    iget-object v2, p1, Lcafe/cryptography/curve25519/AffineNielsPoint;->yPlusx:Lcafe/cryptography/curve25519/FieldElement;

    invoke-virtual {v1, v2}, Lcafe/cryptography/curve25519/FieldElement;->multiply(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v1

    .line 14
    iget-object v2, p0, Lcafe/cryptography/curve25519/EdwardsPoint;->T:Lcafe/cryptography/curve25519/FieldElement;

    iget-object p1, p1, Lcafe/cryptography/curve25519/AffineNielsPoint;->xy2D:Lcafe/cryptography/curve25519/FieldElement;

    invoke-virtual {v2, p1}, Lcafe/cryptography/curve25519/FieldElement;->multiply(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object p1

    .line 15
    iget-object p0, p0, Lcafe/cryptography/curve25519/EdwardsPoint;->Z:Lcafe/cryptography/curve25519/FieldElement;

    invoke-virtual {p0, p0}, Lcafe/cryptography/curve25519/FieldElement;->add(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object p0

    .line 16
    new-instance v2, Lcafe/cryptography/curve25519/CompletedPoint;

    invoke-virtual {v0, v1}, Lcafe/cryptography/curve25519/FieldElement;->subtract(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v3

    invoke-virtual {v0, v1}, Lcafe/cryptography/curve25519/FieldElement;->add(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v0

    invoke-virtual {p0, p1}, Lcafe/cryptography/curve25519/FieldElement;->subtract(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v1

    invoke-virtual {p0, p1}, Lcafe/cryptography/curve25519/FieldElement;->add(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object p0

    invoke-direct {v2, v3, v0, v1, p0}, Lcafe/cryptography/curve25519/CompletedPoint;-><init>(Lcafe/cryptography/curve25519/FieldElement;Lcafe/cryptography/curve25519/FieldElement;Lcafe/cryptography/curve25519/FieldElement;Lcafe/cryptography/curve25519/FieldElement;)V

    return-object v2
.end method

.method public subtract(Lcafe/cryptography/curve25519/ProjectiveNielsPoint;)Lcafe/cryptography/curve25519/CompletedPoint;
    .locals 4

    .line 2
    iget-object v0, p0, Lcafe/cryptography/curve25519/EdwardsPoint;->Y:Lcafe/cryptography/curve25519/FieldElement;

    iget-object v1, p0, Lcafe/cryptography/curve25519/EdwardsPoint;->X:Lcafe/cryptography/curve25519/FieldElement;

    invoke-virtual {v0, v1}, Lcafe/cryptography/curve25519/FieldElement;->add(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v0

    .line 3
    iget-object v1, p0, Lcafe/cryptography/curve25519/EdwardsPoint;->Y:Lcafe/cryptography/curve25519/FieldElement;

    iget-object v2, p0, Lcafe/cryptography/curve25519/EdwardsPoint;->X:Lcafe/cryptography/curve25519/FieldElement;

    invoke-virtual {v1, v2}, Lcafe/cryptography/curve25519/FieldElement;->subtract(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v1

    .line 4
    iget-object v2, p1, Lcafe/cryptography/curve25519/ProjectiveNielsPoint;->YMinusX:Lcafe/cryptography/curve25519/FieldElement;

    invoke-virtual {v0, v2}, Lcafe/cryptography/curve25519/FieldElement;->multiply(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v0

    .line 5
    iget-object v2, p1, Lcafe/cryptography/curve25519/ProjectiveNielsPoint;->YPlusX:Lcafe/cryptography/curve25519/FieldElement;

    invoke-virtual {v1, v2}, Lcafe/cryptography/curve25519/FieldElement;->multiply(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v1

    .line 6
    iget-object v2, p0, Lcafe/cryptography/curve25519/EdwardsPoint;->T:Lcafe/cryptography/curve25519/FieldElement;

    iget-object v3, p1, Lcafe/cryptography/curve25519/ProjectiveNielsPoint;->T2D:Lcafe/cryptography/curve25519/FieldElement;

    invoke-virtual {v2, v3}, Lcafe/cryptography/curve25519/FieldElement;->multiply(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v2

    .line 7
    iget-object p0, p0, Lcafe/cryptography/curve25519/EdwardsPoint;->Z:Lcafe/cryptography/curve25519/FieldElement;

    iget-object p1, p1, Lcafe/cryptography/curve25519/ProjectiveNielsPoint;->Z:Lcafe/cryptography/curve25519/FieldElement;

    invoke-virtual {p0, p1}, Lcafe/cryptography/curve25519/FieldElement;->multiply(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object p0

    .line 8
    invoke-virtual {p0, p0}, Lcafe/cryptography/curve25519/FieldElement;->add(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object p0

    .line 9
    new-instance p1, Lcafe/cryptography/curve25519/CompletedPoint;

    invoke-virtual {v0, v1}, Lcafe/cryptography/curve25519/FieldElement;->subtract(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v3

    invoke-virtual {v0, v1}, Lcafe/cryptography/curve25519/FieldElement;->add(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v0

    invoke-virtual {p0, v2}, Lcafe/cryptography/curve25519/FieldElement;->subtract(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v1

    invoke-virtual {p0, v2}, Lcafe/cryptography/curve25519/FieldElement;->add(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object p0

    invoke-direct {p1, v3, v0, v1, p0}, Lcafe/cryptography/curve25519/CompletedPoint;-><init>(Lcafe/cryptography/curve25519/FieldElement;Lcafe/cryptography/curve25519/FieldElement;Lcafe/cryptography/curve25519/FieldElement;Lcafe/cryptography/curve25519/FieldElement;)V

    return-object p1
.end method

.method public subtract(Lcafe/cryptography/curve25519/EdwardsPoint;)Lcafe/cryptography/curve25519/EdwardsPoint;
    .locals 0

    .line 1
    invoke-virtual {p1}, Lcafe/cryptography/curve25519/EdwardsPoint;->toProjectiveNiels()Lcafe/cryptography/curve25519/ProjectiveNielsPoint;

    move-result-object p1

    invoke-virtual {p0, p1}, Lcafe/cryptography/curve25519/EdwardsPoint;->subtract(Lcafe/cryptography/curve25519/ProjectiveNielsPoint;)Lcafe/cryptography/curve25519/CompletedPoint;

    move-result-object p0

    invoke-virtual {p0}, Lcafe/cryptography/curve25519/CompletedPoint;->toExtended()Lcafe/cryptography/curve25519/EdwardsPoint;

    move-result-object p0

    return-object p0
.end method

.method public toAffineNiels()Lcafe/cryptography/curve25519/AffineNielsPoint;
    .locals 4

    iget-object v0, p0, Lcafe/cryptography/curve25519/EdwardsPoint;->Z:Lcafe/cryptography/curve25519/FieldElement;

    invoke-virtual {v0}, Lcafe/cryptography/curve25519/FieldElement;->invert()Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v0

    iget-object v1, p0, Lcafe/cryptography/curve25519/EdwardsPoint;->X:Lcafe/cryptography/curve25519/FieldElement;

    invoke-virtual {v1, v0}, Lcafe/cryptography/curve25519/FieldElement;->multiply(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v1

    iget-object p0, p0, Lcafe/cryptography/curve25519/EdwardsPoint;->Y:Lcafe/cryptography/curve25519/FieldElement;

    invoke-virtual {p0, v0}, Lcafe/cryptography/curve25519/FieldElement;->multiply(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object p0

    invoke-virtual {v1, p0}, Lcafe/cryptography/curve25519/FieldElement;->multiply(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v0

    sget-object v2, Lcafe/cryptography/curve25519/Constants;->EDWARDS_2D:Lcafe/cryptography/curve25519/FieldElement;

    invoke-virtual {v0, v2}, Lcafe/cryptography/curve25519/FieldElement;->multiply(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v0

    new-instance v2, Lcafe/cryptography/curve25519/AffineNielsPoint;

    invoke-virtual {p0, v1}, Lcafe/cryptography/curve25519/FieldElement;->add(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v3

    invoke-virtual {p0, v1}, Lcafe/cryptography/curve25519/FieldElement;->subtract(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object p0

    invoke-direct {v2, v3, p0, v0}, Lcafe/cryptography/curve25519/AffineNielsPoint;-><init>(Lcafe/cryptography/curve25519/FieldElement;Lcafe/cryptography/curve25519/FieldElement;Lcafe/cryptography/curve25519/FieldElement;)V

    return-object v2
.end method

.method public toProjective()Lcafe/cryptography/curve25519/ProjectivePoint;
    .locals 3

    new-instance v0, Lcafe/cryptography/curve25519/ProjectivePoint;

    iget-object v1, p0, Lcafe/cryptography/curve25519/EdwardsPoint;->X:Lcafe/cryptography/curve25519/FieldElement;

    iget-object v2, p0, Lcafe/cryptography/curve25519/EdwardsPoint;->Y:Lcafe/cryptography/curve25519/FieldElement;

    iget-object p0, p0, Lcafe/cryptography/curve25519/EdwardsPoint;->Z:Lcafe/cryptography/curve25519/FieldElement;

    invoke-direct {v0, v1, v2, p0}, Lcafe/cryptography/curve25519/ProjectivePoint;-><init>(Lcafe/cryptography/curve25519/FieldElement;Lcafe/cryptography/curve25519/FieldElement;Lcafe/cryptography/curve25519/FieldElement;)V

    return-object v0
.end method

.method public toProjectiveNiels()Lcafe/cryptography/curve25519/ProjectiveNielsPoint;
    .locals 5

    new-instance v0, Lcafe/cryptography/curve25519/ProjectiveNielsPoint;

    iget-object v1, p0, Lcafe/cryptography/curve25519/EdwardsPoint;->Y:Lcafe/cryptography/curve25519/FieldElement;

    iget-object v2, p0, Lcafe/cryptography/curve25519/EdwardsPoint;->X:Lcafe/cryptography/curve25519/FieldElement;

    invoke-virtual {v1, v2}, Lcafe/cryptography/curve25519/FieldElement;->add(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v1

    iget-object v2, p0, Lcafe/cryptography/curve25519/EdwardsPoint;->Y:Lcafe/cryptography/curve25519/FieldElement;

    iget-object v3, p0, Lcafe/cryptography/curve25519/EdwardsPoint;->X:Lcafe/cryptography/curve25519/FieldElement;

    invoke-virtual {v2, v3}, Lcafe/cryptography/curve25519/FieldElement;->subtract(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v2

    iget-object v3, p0, Lcafe/cryptography/curve25519/EdwardsPoint;->Z:Lcafe/cryptography/curve25519/FieldElement;

    iget-object p0, p0, Lcafe/cryptography/curve25519/EdwardsPoint;->T:Lcafe/cryptography/curve25519/FieldElement;

    sget-object v4, Lcafe/cryptography/curve25519/Constants;->EDWARDS_2D:Lcafe/cryptography/curve25519/FieldElement;

    invoke-virtual {p0, v4}, Lcafe/cryptography/curve25519/FieldElement;->multiply(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object p0

    invoke-direct {v0, v1, v2, v3, p0}, Lcafe/cryptography/curve25519/ProjectiveNielsPoint;-><init>(Lcafe/cryptography/curve25519/FieldElement;Lcafe/cryptography/curve25519/FieldElement;Lcafe/cryptography/curve25519/FieldElement;Lcafe/cryptography/curve25519/FieldElement;)V

    return-object v0
.end method
