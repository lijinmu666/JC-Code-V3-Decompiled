.class public Lcafe/cryptography/curve25519/CompressedRistretto;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/io/Serializable;


# static fields
.field private static final serialVersionUID:J = 0x1L


# instance fields
.field private transient data:[B


# direct methods
.method public constructor <init>([B)V
    .locals 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    array-length v0, p1

    const/16 v1, 0x20

    if-ne v0, v1, :cond_0

    iput-object p1, p0, Lcafe/cryptography/curve25519/CompressedRistretto;->data:[B

    return-void

    :cond_0
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string p1, "Invalid CompressedRistretto encoding"

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method private readObject(Ljava/io/ObjectInputStream;)V
    .locals 1

    const/16 v0, 0x20

    new-array v0, v0, [B

    invoke-virtual {p1, v0}, Ljava/io/ObjectInputStream;->readFully([B)V

    iput-object v0, p0, Lcafe/cryptography/curve25519/CompressedRistretto;->data:[B

    return-void
.end method

.method private readObjectNoData()V
    .locals 1

    new-instance p0, Ljava/io/InvalidObjectException;

    const-string v0, "Cannot deserialize CompressedRistretto from no data"

    invoke-direct {p0, v0}, Ljava/io/InvalidObjectException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method private writeObject(Ljava/io/ObjectOutputStream;)V
    .locals 0

    invoke-virtual {p0}, Lcafe/cryptography/curve25519/CompressedRistretto;->toByteArray()[B

    move-result-object p0

    invoke-virtual {p1, p0}, Ljava/io/ObjectOutputStream;->write([B)V

    return-void
.end method


# virtual methods
.method public ctEquals(Lcafe/cryptography/curve25519/CompressedRistretto;)I
    .locals 0

    iget-object p0, p0, Lcafe/cryptography/curve25519/CompressedRistretto;->data:[B

    iget-object p1, p1, Lcafe/cryptography/curve25519/CompressedRistretto;->data:[B

    invoke-static {p0, p1}, Lcafe/cryptography/subtle/ConstantTime;->equal([B[B)I

    move-result p0

    return p0
.end method

.method public decompress()Lcafe/cryptography/curve25519/RistrettoElement;
    .locals 8

    iget-object v0, p0, Lcafe/cryptography/curve25519/CompressedRistretto;->data:[B

    invoke-static {v0}, Lcafe/cryptography/curve25519/FieldElement;->fromByteArray([B)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v0

    invoke-virtual {v0}, Lcafe/cryptography/curve25519/FieldElement;->toByteArray()[B

    move-result-object v1

    iget-object p0, p0, Lcafe/cryptography/curve25519/CompressedRistretto;->data:[B

    invoke-static {p0, v1}, Lcafe/cryptography/subtle/ConstantTime;->equal([B[B)I

    move-result p0

    const-string v1, "Invalid ristretto255 encoding"

    if-eqz p0, :cond_1

    invoke-virtual {v0}, Lcafe/cryptography/curve25519/FieldElement;->isNegative()I

    move-result p0

    const/4 v2, 0x1

    if-eq p0, v2, :cond_1

    invoke-virtual {v0}, Lcafe/cryptography/curve25519/FieldElement;->square()Lcafe/cryptography/curve25519/FieldElement;

    move-result-object p0

    sget-object v3, Lcafe/cryptography/curve25519/FieldElement;->ONE:Lcafe/cryptography/curve25519/FieldElement;

    invoke-virtual {v3, p0}, Lcafe/cryptography/curve25519/FieldElement;->subtract(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v4

    invoke-virtual {v3, p0}, Lcafe/cryptography/curve25519/FieldElement;->add(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object p0

    invoke-virtual {p0}, Lcafe/cryptography/curve25519/FieldElement;->square()Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v5

    sget-object v6, Lcafe/cryptography/curve25519/Constants;->NEG_EDWARDS_D:Lcafe/cryptography/curve25519/FieldElement;

    invoke-virtual {v4}, Lcafe/cryptography/curve25519/FieldElement;->square()Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v7

    invoke-virtual {v6, v7}, Lcafe/cryptography/curve25519/FieldElement;->multiply(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v6

    invoke-virtual {v6, v5}, Lcafe/cryptography/curve25519/FieldElement;->subtract(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v6

    invoke-virtual {v6, v5}, Lcafe/cryptography/curve25519/FieldElement;->multiply(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v5

    invoke-static {v3, v5}, Lcafe/cryptography/curve25519/FieldElement;->sqrtRatioM1(Lcafe/cryptography/curve25519/FieldElement;Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement$SqrtRatioM1Result;

    move-result-object v5

    iget-object v7, v5, Lcafe/cryptography/curve25519/FieldElement$SqrtRatioM1Result;->result:Lcafe/cryptography/curve25519/FieldElement;

    invoke-virtual {v7, p0}, Lcafe/cryptography/curve25519/FieldElement;->multiply(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object p0

    iget-object v7, v5, Lcafe/cryptography/curve25519/FieldElement$SqrtRatioM1Result;->result:Lcafe/cryptography/curve25519/FieldElement;

    invoke-virtual {v7, p0}, Lcafe/cryptography/curve25519/FieldElement;->multiply(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v7

    invoke-virtual {v7, v6}, Lcafe/cryptography/curve25519/FieldElement;->multiply(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v6

    invoke-virtual {v0, v0}, Lcafe/cryptography/curve25519/FieldElement;->add(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v0

    invoke-virtual {v0, p0}, Lcafe/cryptography/curve25519/FieldElement;->multiply(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object p0

    invoke-virtual {p0}, Lcafe/cryptography/curve25519/FieldElement;->ctAbs()Lcafe/cryptography/curve25519/FieldElement;

    move-result-object p0

    invoke-virtual {v4, v6}, Lcafe/cryptography/curve25519/FieldElement;->multiply(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v0

    invoke-virtual {p0, v0}, Lcafe/cryptography/curve25519/FieldElement;->multiply(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v4

    iget v5, v5, Lcafe/cryptography/curve25519/FieldElement$SqrtRatioM1Result;->wasSquare:I

    if-eqz v5, :cond_0

    invoke-virtual {v4}, Lcafe/cryptography/curve25519/FieldElement;->isNegative()I

    move-result v5

    if-eq v5, v2, :cond_0

    invoke-virtual {v0}, Lcafe/cryptography/curve25519/FieldElement;->isZero()I

    move-result v5

    if-eq v5, v2, :cond_0

    new-instance v1, Lcafe/cryptography/curve25519/RistrettoElement;

    new-instance v2, Lcafe/cryptography/curve25519/EdwardsPoint;

    invoke-direct {v2, p0, v0, v3, v4}, Lcafe/cryptography/curve25519/EdwardsPoint;-><init>(Lcafe/cryptography/curve25519/FieldElement;Lcafe/cryptography/curve25519/FieldElement;Lcafe/cryptography/curve25519/FieldElement;Lcafe/cryptography/curve25519/FieldElement;)V

    invoke-direct {v1, v2}, Lcafe/cryptography/curve25519/RistrettoElement;-><init>(Lcafe/cryptography/curve25519/EdwardsPoint;)V

    return-object v1

    :cond_0
    new-instance p0, Lcafe/cryptography/curve25519/InvalidEncodingException;

    invoke-direct {p0, v1}, Lcafe/cryptography/curve25519/InvalidEncodingException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_1
    new-instance p0, Lcafe/cryptography/curve25519/InvalidEncodingException;

    invoke-direct {p0, v1}, Lcafe/cryptography/curve25519/InvalidEncodingException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 2

    instance-of v0, p1, Lcafe/cryptography/curve25519/CompressedRistretto;

    const/4 v1, 0x0

    if-nez v0, :cond_0

    return v1

    :cond_0
    check-cast p1, Lcafe/cryptography/curve25519/CompressedRistretto;

    invoke-virtual {p0, p1}, Lcafe/cryptography/curve25519/CompressedRistretto;->ctEquals(Lcafe/cryptography/curve25519/CompressedRistretto;)I

    move-result p0

    const/4 p1, 0x1

    if-ne p0, p1, :cond_1

    move v1, p1

    :cond_1
    return v1
.end method

.method public hashCode()I
    .locals 0

    iget-object p0, p0, Lcafe/cryptography/curve25519/CompressedRistretto;->data:[B

    invoke-static {p0}, Ljava/util/Arrays;->hashCode([B)I

    move-result p0

    return p0
.end method

.method public toByteArray()[B
    .locals 0

    iget-object p0, p0, Lcafe/cryptography/curve25519/CompressedRistretto;->data:[B

    return-object p0
.end method
