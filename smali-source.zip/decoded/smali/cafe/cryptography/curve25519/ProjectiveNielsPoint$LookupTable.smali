.class Lcafe/cryptography/curve25519/ProjectiveNielsPoint$LookupTable;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcafe/cryptography/curve25519/ProjectiveNielsPoint;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "LookupTable"
.end annotation


# instance fields
.field private final table:[Lcafe/cryptography/curve25519/ProjectiveNielsPoint;


# direct methods
.method public constructor <init>([Lcafe/cryptography/curve25519/ProjectiveNielsPoint;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcafe/cryptography/curve25519/ProjectiveNielsPoint$LookupTable;->table:[Lcafe/cryptography/curve25519/ProjectiveNielsPoint;

    return-void
.end method


# virtual methods
.method public select(I)Lcafe/cryptography/curve25519/ProjectiveNielsPoint;
    .locals 5

    const/4 v0, -0x8

    if-lt p1, v0, :cond_1

    const/16 v0, 0x8

    if-gt p1, v0, :cond_1

    invoke-static {p1}, Lcafe/cryptography/subtle/ConstantTime;->isNegative(I)I

    move-result v0

    neg-int v1, v0

    and-int/2addr v1, p1

    const/4 v2, 0x1

    shl-int/2addr v1, v2

    sub-int/2addr p1, v1

    sget-object v1, Lcafe/cryptography/curve25519/ProjectiveNielsPoint;->IDENTITY:Lcafe/cryptography/curve25519/ProjectiveNielsPoint;

    :goto_0
    const/16 v3, 0x9

    if-ge v2, v3, :cond_0

    iget-object v3, p0, Lcafe/cryptography/curve25519/ProjectiveNielsPoint$LookupTable;->table:[Lcafe/cryptography/curve25519/ProjectiveNielsPoint;

    add-int/lit8 v4, v2, -0x1

    aget-object v3, v3, v4

    invoke-static {p1, v2}, Lcafe/cryptography/subtle/ConstantTime;->equal(II)I

    move-result v4

    invoke-virtual {v1, v3, v4}, Lcafe/cryptography/curve25519/ProjectiveNielsPoint;->ctSelect(Lcafe/cryptography/curve25519/ProjectiveNielsPoint;I)Lcafe/cryptography/curve25519/ProjectiveNielsPoint;

    move-result-object v1

    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_0
    invoke-virtual {v1}, Lcafe/cryptography/curve25519/ProjectiveNielsPoint;->negate()Lcafe/cryptography/curve25519/ProjectiveNielsPoint;

    move-result-object p0

    invoke-virtual {v1, p0, v0}, Lcafe/cryptography/curve25519/ProjectiveNielsPoint;->ctSelect(Lcafe/cryptography/curve25519/ProjectiveNielsPoint;I)Lcafe/cryptography/curve25519/ProjectiveNielsPoint;

    move-result-object p0

    return-object p0

    :cond_1
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string p1, "x is not in range -8 <= x <= 8"

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0
.end method
