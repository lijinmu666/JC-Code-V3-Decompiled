.class Lcafe/cryptography/curve25519/AffineNielsPoint;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcafe/cryptography/curve25519/AffineNielsPoint$NafLookupTable;,
        Lcafe/cryptography/curve25519/AffineNielsPoint$LookupTable;
    }
.end annotation


# static fields
.field static final IDENTITY:Lcafe/cryptography/curve25519/AffineNielsPoint;


# instance fields
.field final xy2D:Lcafe/cryptography/curve25519/FieldElement;

.field final yMinusx:Lcafe/cryptography/curve25519/FieldElement;

.field final yPlusx:Lcafe/cryptography/curve25519/FieldElement;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    new-instance v0, Lcafe/cryptography/curve25519/AffineNielsPoint;

    sget-object v1, Lcafe/cryptography/curve25519/FieldElement;->ONE:Lcafe/cryptography/curve25519/FieldElement;

    sget-object v2, Lcafe/cryptography/curve25519/FieldElement;->ZERO:Lcafe/cryptography/curve25519/FieldElement;

    invoke-direct {v0, v1, v1, v2}, Lcafe/cryptography/curve25519/AffineNielsPoint;-><init>(Lcafe/cryptography/curve25519/FieldElement;Lcafe/cryptography/curve25519/FieldElement;Lcafe/cryptography/curve25519/FieldElement;)V

    sput-object v0, Lcafe/cryptography/curve25519/AffineNielsPoint;->IDENTITY:Lcafe/cryptography/curve25519/AffineNielsPoint;

    return-void
.end method

.method public constructor <init>(Lcafe/cryptography/curve25519/FieldElement;Lcafe/cryptography/curve25519/FieldElement;Lcafe/cryptography/curve25519/FieldElement;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcafe/cryptography/curve25519/AffineNielsPoint;->yPlusx:Lcafe/cryptography/curve25519/FieldElement;

    iput-object p2, p0, Lcafe/cryptography/curve25519/AffineNielsPoint;->yMinusx:Lcafe/cryptography/curve25519/FieldElement;

    iput-object p3, p0, Lcafe/cryptography/curve25519/AffineNielsPoint;->xy2D:Lcafe/cryptography/curve25519/FieldElement;

    return-void
.end method

.method public static buildLookupTable(Lcafe/cryptography/curve25519/EdwardsPoint;)Lcafe/cryptography/curve25519/AffineNielsPoint$LookupTable;
    .locals 3

    const/16 v0, 0x8

    new-array v0, v0, [Lcafe/cryptography/curve25519/AffineNielsPoint;

    invoke-virtual {p0}, Lcafe/cryptography/curve25519/EdwardsPoint;->toAffineNiels()Lcafe/cryptography/curve25519/AffineNielsPoint;

    move-result-object v1

    const/4 v2, 0x0

    aput-object v1, v0, v2

    :goto_0
    const/4 v1, 0x7

    if-ge v2, v1, :cond_0

    add-int/lit8 v1, v2, 0x1

    aget-object v2, v0, v2

    invoke-virtual {p0, v2}, Lcafe/cryptography/curve25519/EdwardsPoint;->add(Lcafe/cryptography/curve25519/AffineNielsPoint;)Lcafe/cryptography/curve25519/CompletedPoint;

    move-result-object v2

    invoke-virtual {v2}, Lcafe/cryptography/curve25519/CompletedPoint;->toExtended()Lcafe/cryptography/curve25519/EdwardsPoint;

    move-result-object v2

    invoke-virtual {v2}, Lcafe/cryptography/curve25519/EdwardsPoint;->toAffineNiels()Lcafe/cryptography/curve25519/AffineNielsPoint;

    move-result-object v2

    aput-object v2, v0, v1

    move v2, v1

    goto :goto_0

    :cond_0
    new-instance p0, Lcafe/cryptography/curve25519/AffineNielsPoint$LookupTable;

    invoke-direct {p0, v0}, Lcafe/cryptography/curve25519/AffineNielsPoint$LookupTable;-><init>([Lcafe/cryptography/curve25519/AffineNielsPoint;)V

    return-object p0
.end method

.method public static buildNafLookupTable(Lcafe/cryptography/curve25519/EdwardsPoint;)Lcafe/cryptography/curve25519/AffineNielsPoint$NafLookupTable;
    .locals 3

    const/16 v0, 0x8

    new-array v0, v0, [Lcafe/cryptography/curve25519/AffineNielsPoint;

    invoke-virtual {p0}, Lcafe/cryptography/curve25519/EdwardsPoint;->toAffineNiels()Lcafe/cryptography/curve25519/AffineNielsPoint;

    move-result-object v1

    const/4 v2, 0x0

    aput-object v1, v0, v2

    invoke-virtual {p0}, Lcafe/cryptography/curve25519/EdwardsPoint;->dbl()Lcafe/cryptography/curve25519/EdwardsPoint;

    move-result-object p0

    :goto_0
    const/4 v1, 0x7

    if-ge v2, v1, :cond_0

    add-int/lit8 v1, v2, 0x1

    aget-object v2, v0, v2

    invoke-virtual {p0, v2}, Lcafe/cryptography/curve25519/EdwardsPoint;->add(Lcafe/cryptography/curve25519/AffineNielsPoint;)Lcafe/cryptography/curve25519/CompletedPoint;

    move-result-object v2

    invoke-virtual {v2}, Lcafe/cryptography/curve25519/CompletedPoint;->toExtended()Lcafe/cryptography/curve25519/EdwardsPoint;

    move-result-object v2

    invoke-virtual {v2}, Lcafe/cryptography/curve25519/EdwardsPoint;->toAffineNiels()Lcafe/cryptography/curve25519/AffineNielsPoint;

    move-result-object v2

    aput-object v2, v0, v1

    move v2, v1

    goto :goto_0

    :cond_0
    new-instance p0, Lcafe/cryptography/curve25519/AffineNielsPoint$NafLookupTable;

    invoke-direct {p0, v0}, Lcafe/cryptography/curve25519/AffineNielsPoint$NafLookupTable;-><init>([Lcafe/cryptography/curve25519/AffineNielsPoint;)V

    return-object p0
.end method


# virtual methods
.method public ctSelect(Lcafe/cryptography/curve25519/AffineNielsPoint;I)Lcafe/cryptography/curve25519/AffineNielsPoint;
    .locals 4

    new-instance v0, Lcafe/cryptography/curve25519/AffineNielsPoint;

    iget-object v1, p0, Lcafe/cryptography/curve25519/AffineNielsPoint;->yPlusx:Lcafe/cryptography/curve25519/FieldElement;

    iget-object v2, p1, Lcafe/cryptography/curve25519/AffineNielsPoint;->yPlusx:Lcafe/cryptography/curve25519/FieldElement;

    invoke-virtual {v1, v2, p2}, Lcafe/cryptography/curve25519/FieldElement;->ctSelect(Lcafe/cryptography/curve25519/FieldElement;I)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v1

    iget-object v2, p0, Lcafe/cryptography/curve25519/AffineNielsPoint;->yMinusx:Lcafe/cryptography/curve25519/FieldElement;

    iget-object v3, p1, Lcafe/cryptography/curve25519/AffineNielsPoint;->yMinusx:Lcafe/cryptography/curve25519/FieldElement;

    invoke-virtual {v2, v3, p2}, Lcafe/cryptography/curve25519/FieldElement;->ctSelect(Lcafe/cryptography/curve25519/FieldElement;I)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v2

    iget-object p0, p0, Lcafe/cryptography/curve25519/AffineNielsPoint;->xy2D:Lcafe/cryptography/curve25519/FieldElement;

    iget-object p1, p1, Lcafe/cryptography/curve25519/AffineNielsPoint;->xy2D:Lcafe/cryptography/curve25519/FieldElement;

    invoke-virtual {p0, p1, p2}, Lcafe/cryptography/curve25519/FieldElement;->ctSelect(Lcafe/cryptography/curve25519/FieldElement;I)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object p0

    invoke-direct {v0, v1, v2, p0}, Lcafe/cryptography/curve25519/AffineNielsPoint;-><init>(Lcafe/cryptography/curve25519/FieldElement;Lcafe/cryptography/curve25519/FieldElement;Lcafe/cryptography/curve25519/FieldElement;)V

    return-object v0
.end method

.method public negate()Lcafe/cryptography/curve25519/AffineNielsPoint;
    .locals 3

    new-instance v0, Lcafe/cryptography/curve25519/AffineNielsPoint;

    iget-object v1, p0, Lcafe/cryptography/curve25519/AffineNielsPoint;->yMinusx:Lcafe/cryptography/curve25519/FieldElement;

    iget-object v2, p0, Lcafe/cryptography/curve25519/AffineNielsPoint;->yPlusx:Lcafe/cryptography/curve25519/FieldElement;

    iget-object p0, p0, Lcafe/cryptography/curve25519/AffineNielsPoint;->xy2D:Lcafe/cryptography/curve25519/FieldElement;

    invoke-virtual {p0}, Lcafe/cryptography/curve25519/FieldElement;->negate()Lcafe/cryptography/curve25519/FieldElement;

    move-result-object p0

    invoke-direct {v0, v1, v2, p0}, Lcafe/cryptography/curve25519/AffineNielsPoint;-><init>(Lcafe/cryptography/curve25519/FieldElement;Lcafe/cryptography/curve25519/FieldElement;Lcafe/cryptography/curve25519/FieldElement;)V

    return-object v0
.end method
