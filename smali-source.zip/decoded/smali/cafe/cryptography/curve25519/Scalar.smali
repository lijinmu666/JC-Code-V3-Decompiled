.class public Lcafe/cryptography/curve25519/Scalar;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/io/Serializable;


# static fields
.field public static final ONE:Lcafe/cryptography/curve25519/Scalar;

.field public static final ZERO:Lcafe/cryptography/curve25519/Scalar;

.field private static final serialVersionUID:J = 0x1L


# instance fields
.field private transient s:[B


# direct methods
.method static constructor <clinit>()V
    .locals 3

    new-instance v0, Lcafe/cryptography/curve25519/Scalar;

    const/16 v1, 0x20

    new-array v2, v1, [B

    fill-array-data v2, :array_0

    invoke-direct {v0, v2}, Lcafe/cryptography/curve25519/Scalar;-><init>([B)V

    sput-object v0, Lcafe/cryptography/curve25519/Scalar;->ZERO:Lcafe/cryptography/curve25519/Scalar;

    new-instance v0, Lcafe/cryptography/curve25519/Scalar;

    new-array v1, v1, [B

    fill-array-data v1, :array_1

    invoke-direct {v0, v1}, Lcafe/cryptography/curve25519/Scalar;-><init>([B)V

    sput-object v0, Lcafe/cryptography/curve25519/Scalar;->ONE:Lcafe/cryptography/curve25519/Scalar;

    return-void

    nop

    :array_0
    .array-data 1
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
    .end array-data

    :array_1
    .array-data 1
        0x1t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
    .end array-data
.end method

.method public constructor <init>([B)V
    .locals 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    array-length v0, p1

    const/16 v1, 0x20

    if-ne v0, v1, :cond_0

    const/16 v0, 0x1f

    aget-byte v0, p1, v0

    shr-int/lit8 v0, v0, 0x7

    and-int/lit8 v0, v0, 0x1

    if-nez v0, :cond_0

    array-length v0, p1

    invoke-static {p1, v0}, Ljava/util/Arrays;->copyOf([BI)[B

    move-result-object p1

    iput-object p1, p0, Lcafe/cryptography/curve25519/Scalar;->s:[B

    return-void

    :cond_0
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string p1, "Invalid scalar representation"

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public static fromBits([B)Lcafe/cryptography/curve25519/Scalar;
    .locals 2

    const/16 v0, 0x1f

    aget-byte v1, p0, v0

    and-int/lit8 v1, v1, 0x7f

    int-to-byte v1, v1

    aput-byte v1, p0, v0

    new-instance v0, Lcafe/cryptography/curve25519/Scalar;

    invoke-direct {v0, p0}, Lcafe/cryptography/curve25519/Scalar;-><init>([B)V

    return-object v0
.end method

.method public static fromBytesModOrder([B)Lcafe/cryptography/curve25519/Scalar;
    .locals 2

    array-length v0, p0

    const/16 v1, 0x20

    if-ne v0, v1, :cond_0

    invoke-static {p0}, Lcafe/cryptography/curve25519/Scalar;->reduce([B)Lcafe/cryptography/curve25519/Scalar;

    move-result-object p0

    return-object p0

    :cond_0
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string v0, "Input must by 32 bytes"

    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public static fromBytesModOrderWide([B)Lcafe/cryptography/curve25519/Scalar;
    .locals 77

    move-object/from16 v0, p0

    const/16 v4, 0x15

    const/4 v5, 0x3

    const/16 v6, 0x12

    const/4 v7, 0x6

    const/16 v8, 0xf

    const/4 v9, 0x1

    const/16 v10, 0xd

    const/4 v11, 0x4

    const/16 v12, 0xa

    const/4 v13, 0x7

    const/4 v14, 0x5

    const/4 v15, 0x2

    const/4 v1, 0x0

    const/16 v16, 0x11

    const/16 v17, 0x9

    const/16 v18, 0xe

    const/16 v19, 0x13

    const/16 v20, 0xb

    const/16 v21, 0x10

    array-length v2, v0

    const/16 v3, 0x40

    if-ne v2, v3, :cond_0

    invoke-static {v0, v1}, Lcafe/cryptography/curve25519/FieldElement;->load_3([BI)I

    move-result v2

    const v3, 0x1fffff

    and-int/2addr v2, v3

    int-to-long v1, v2

    invoke-static {v0, v15}, Lcafe/cryptography/curve25519/FieldElement;->load_4([BI)J

    move-result-wide v23

    shr-long v23, v23, v14

    const-wide/32 v25, 0x1fffff

    and-long v23, v23, v25

    invoke-static {v0, v14}, Lcafe/cryptography/curve25519/FieldElement;->load_3([BI)I

    move-result v27

    shr-int/lit8 v27, v27, 0x2

    and-int v15, v27, v3

    int-to-long v14, v15

    invoke-static {v0, v13}, Lcafe/cryptography/curve25519/FieldElement;->load_4([BI)J

    move-result-wide v29

    shr-long v29, v29, v13

    and-long v29, v29, v25

    invoke-static {v0, v12}, Lcafe/cryptography/curve25519/FieldElement;->load_4([BI)J

    move-result-wide v31

    shr-long v31, v31, v11

    and-long v31, v31, v25

    invoke-static {v0, v10}, Lcafe/cryptography/curve25519/FieldElement;->load_3([BI)I

    move-result v33

    shr-int/lit8 v33, v33, 0x1

    and-int v10, v33, v3

    int-to-long v9, v10

    invoke-static {v0, v8}, Lcafe/cryptography/curve25519/FieldElement;->load_4([BI)J

    move-result-wide v34

    shr-long v34, v34, v7

    and-long v34, v34, v25

    invoke-static {v0, v6}, Lcafe/cryptography/curve25519/FieldElement;->load_3([BI)I

    move-result v36

    shr-int/lit8 v36, v36, 0x3

    and-int v6, v36, v3

    move-wide/from16 v37, v9

    int-to-long v8, v6

    invoke-static {v0, v4}, Lcafe/cryptography/curve25519/FieldElement;->load_3([BI)I

    move-result v6

    and-int/2addr v6, v3

    int-to-long v4, v6

    const/16 v6, 0x17

    invoke-static {v0, v6}, Lcafe/cryptography/curve25519/FieldElement;->load_4([BI)J

    move-result-wide v40

    const/4 v6, 0x5

    shr-long v40, v40, v6

    and-long v40, v40, v25

    const/16 v6, 0x1a

    invoke-static {v0, v6}, Lcafe/cryptography/curve25519/FieldElement;->load_3([BI)I

    move-result v42

    const/4 v6, 0x2

    shr-int/lit8 v42, v42, 0x2

    and-int v6, v42, v3

    move-wide/from16 v43, v8

    int-to-long v7, v6

    const/16 v6, 0x1c

    invoke-static {v0, v6}, Lcafe/cryptography/curve25519/FieldElement;->load_4([BI)J

    move-result-wide v45

    shr-long v45, v45, v13

    and-long v45, v45, v25

    const/16 v6, 0x1f

    invoke-static {v0, v6}, Lcafe/cryptography/curve25519/FieldElement;->load_4([BI)J

    move-result-wide v47

    shr-long v47, v47, v11

    and-long v47, v47, v25

    const/16 v6, 0x22

    invoke-static {v0, v6}, Lcafe/cryptography/curve25519/FieldElement;->load_3([BI)I

    move-result v6

    const/4 v9, 0x1

    shr-int/2addr v6, v9

    and-int/2addr v6, v3

    int-to-long v10, v6

    const/16 v6, 0x24

    invoke-static {v0, v6}, Lcafe/cryptography/curve25519/FieldElement;->load_4([BI)J

    move-result-wide v49

    const/4 v6, 0x6

    shr-long v49, v49, v6

    and-long v49, v49, v25

    const/16 v6, 0x27

    invoke-static {v0, v6}, Lcafe/cryptography/curve25519/FieldElement;->load_3([BI)I

    move-result v6

    const/16 v39, 0x3

    shr-int/lit8 v6, v6, 0x3

    and-int/2addr v6, v3

    move-wide/from16 v51, v10

    int-to-long v9, v6

    const/16 v6, 0x2a

    invoke-static {v0, v6}, Lcafe/cryptography/curve25519/FieldElement;->load_3([BI)I

    move-result v6

    and-int/2addr v6, v3

    int-to-long v12, v6

    const/16 v6, 0x2c

    invoke-static {v0, v6}, Lcafe/cryptography/curve25519/FieldElement;->load_4([BI)J

    move-result-wide v53

    const/4 v6, 0x5

    shr-long v53, v53, v6

    and-long v53, v53, v25

    const/16 v6, 0x2f

    invoke-static {v0, v6}, Lcafe/cryptography/curve25519/FieldElement;->load_3([BI)I

    move-result v6

    const/16 v28, 0x2

    shr-int/lit8 v6, v6, 0x2

    and-int/2addr v6, v3

    move-wide/from16 v55, v12

    int-to-long v11, v6

    const/16 v6, 0x31

    invoke-static {v0, v6}, Lcafe/cryptography/curve25519/FieldElement;->load_4([BI)J

    move-result-wide v57

    const/4 v6, 0x7

    shr-long v57, v57, v6

    and-long v57, v57, v25

    const/16 v6, 0x34

    invoke-static {v0, v6}, Lcafe/cryptography/curve25519/FieldElement;->load_4([BI)J

    move-result-wide v59

    const/4 v6, 0x4

    shr-long v59, v59, v6

    and-long v59, v59, v25

    const/16 v13, 0x37

    invoke-static {v0, v13}, Lcafe/cryptography/curve25519/FieldElement;->load_3([BI)I

    move-result v13

    const/16 v33, 0x1

    shr-int/lit8 v13, v13, 0x1

    and-int/2addr v3, v13

    move-wide/from16 v61, v7

    int-to-long v6, v3

    const/16 v3, 0x39

    invoke-static {v0, v3}, Lcafe/cryptography/curve25519/FieldElement;->load_4([BI)J

    move-result-wide v63

    const/4 v3, 0x6

    shr-long v63, v63, v3

    and-long v25, v63, v25

    const/16 v3, 0x3c

    invoke-static {v0, v3}, Lcafe/cryptography/curve25519/FieldElement;->load_4([BI)J

    move-result-wide v63

    const/4 v0, 0x3

    shr-long v63, v63, v0

    const-wide/32 v65, 0xa2c13

    mul-long v67, v63, v65

    add-long v45, v45, v67

    const-wide/32 v67, 0x72d18

    mul-long v69, v63, v67

    add-long v47, v47, v69

    const-wide/32 v69, 0x9fb67

    mul-long v71, v63, v69

    add-long v51, v51, v71

    const-wide/32 v71, 0xf39ad

    mul-long v73, v63, v71

    sub-long v49, v49, v73

    const-wide/32 v73, 0x215d1

    mul-long v75, v63, v73

    add-long v9, v9, v75

    const-wide/32 v75, 0xa6f7d

    mul-long v63, v63, v75

    sub-long v55, v55, v63

    mul-long v63, v25, v65

    add-long v61, v61, v63

    mul-long v63, v25, v67

    add-long v45, v45, v63

    mul-long v63, v25, v69

    add-long v47, v47, v63

    mul-long v63, v25, v71

    sub-long v51, v51, v63

    mul-long v63, v25, v73

    add-long v49, v49, v63

    mul-long v25, v25, v75

    sub-long v9, v9, v25

    mul-long v25, v6, v65

    add-long v40, v40, v25

    mul-long v25, v6, v67

    add-long v61, v61, v25

    mul-long v25, v6, v69

    add-long v45, v45, v25

    mul-long v25, v6, v71

    sub-long v47, v47, v25

    mul-long v25, v6, v73

    add-long v51, v51, v25

    mul-long v6, v6, v75

    sub-long v49, v49, v6

    mul-long v6, v59, v65

    add-long/2addr v4, v6

    mul-long v6, v59, v67

    add-long v40, v40, v6

    mul-long v6, v59, v69

    add-long v61, v61, v6

    mul-long v6, v59, v71

    sub-long v45, v45, v6

    mul-long v6, v59, v73

    add-long v47, v47, v6

    mul-long v59, v59, v75

    sub-long v51, v51, v59

    mul-long v6, v57, v65

    add-long v6, v43, v6

    mul-long v25, v57, v67

    add-long v4, v4, v25

    mul-long v25, v57, v69

    add-long v40, v40, v25

    mul-long v25, v57, v71

    sub-long v61, v61, v25

    mul-long v25, v57, v73

    add-long v45, v45, v25

    mul-long v57, v57, v75

    sub-long v47, v47, v57

    mul-long v25, v11, v65

    add-long v34, v34, v25

    mul-long v25, v11, v67

    add-long v6, v6, v25

    mul-long v25, v11, v69

    add-long v4, v4, v25

    mul-long v25, v11, v71

    sub-long v40, v40, v25

    mul-long v25, v11, v73

    add-long v61, v61, v25

    mul-long v11, v11, v75

    sub-long v45, v45, v11

    const-wide/32 v11, 0x100000

    add-long v25, v34, v11

    const/16 v0, 0x15

    shr-long v25, v25, v0

    add-long v6, v6, v25

    shl-long v25, v25, v0

    sub-long v34, v34, v25

    add-long v25, v4, v11

    shr-long v25, v25, v0

    add-long v40, v40, v25

    shl-long v25, v25, v0

    sub-long v4, v4, v25

    add-long v25, v61, v11

    shr-long v25, v25, v0

    add-long v45, v45, v25

    shl-long v25, v25, v0

    sub-long v61, v61, v25

    add-long v25, v47, v11

    shr-long v25, v25, v0

    add-long v51, v51, v25

    shl-long v25, v25, v0

    sub-long v47, v47, v25

    add-long v25, v49, v11

    shr-long v25, v25, v0

    add-long v8, v9, v25

    shl-long v25, v25, v0

    sub-long v49, v49, v25

    add-long v25, v55, v11

    shr-long v25, v25, v0

    add-long v53, v53, v25

    shl-long v25, v25, v0

    sub-long v55, v55, v25

    add-long v25, v6, v11

    shr-long v25, v25, v0

    add-long v4, v4, v25

    shl-long v25, v25, v0

    sub-long v6, v6, v25

    add-long v25, v40, v11

    shr-long v25, v25, v0

    add-long v61, v61, v25

    shl-long v25, v25, v0

    sub-long v40, v40, v25

    add-long v25, v45, v11

    shr-long v25, v25, v0

    add-long v47, v47, v25

    shl-long v25, v25, v0

    sub-long v45, v45, v25

    add-long v25, v51, v11

    shr-long v25, v25, v0

    add-long v49, v49, v25

    shl-long v25, v25, v0

    sub-long v51, v51, v25

    add-long v25, v8, v11

    shr-long v25, v25, v0

    add-long v55, v55, v25

    shl-long v25, v25, v0

    sub-long v8, v8, v25

    mul-long v25, v53, v65

    add-long v25, v37, v25

    mul-long v37, v53, v67

    add-long v34, v34, v37

    mul-long v37, v53, v69

    add-long v6, v6, v37

    mul-long v37, v53, v71

    sub-long v4, v4, v37

    mul-long v37, v53, v73

    add-long v40, v40, v37

    mul-long v53, v53, v75

    sub-long v61, v61, v53

    mul-long v37, v55, v65

    add-long v31, v31, v37

    mul-long v37, v55, v67

    add-long v25, v25, v37

    mul-long v37, v55, v69

    add-long v34, v34, v37

    mul-long v37, v55, v71

    sub-long v6, v6, v37

    mul-long v37, v55, v73

    add-long v4, v4, v37

    mul-long v55, v55, v75

    sub-long v40, v40, v55

    mul-long v37, v8, v65

    add-long v29, v29, v37

    mul-long v37, v8, v67

    add-long v31, v31, v37

    mul-long v37, v8, v69

    add-long v25, v25, v37

    mul-long v37, v8, v71

    sub-long v34, v34, v37

    mul-long v37, v8, v73

    add-long v6, v6, v37

    mul-long v8, v8, v75

    sub-long/2addr v4, v8

    mul-long v8, v49, v65

    add-long/2addr v14, v8

    mul-long v8, v49, v67

    add-long v29, v29, v8

    mul-long v8, v49, v69

    add-long v31, v31, v8

    mul-long v8, v49, v71

    sub-long v25, v25, v8

    mul-long v8, v49, v73

    add-long v34, v34, v8

    mul-long v49, v49, v75

    sub-long v6, v6, v49

    mul-long v8, v51, v65

    add-long v23, v23, v8

    mul-long v8, v51, v67

    add-long/2addr v14, v8

    mul-long v8, v51, v69

    add-long v29, v29, v8

    mul-long v8, v51, v71

    sub-long v31, v31, v8

    mul-long v8, v51, v73

    add-long v25, v25, v8

    mul-long v51, v51, v75

    sub-long v34, v34, v51

    mul-long v8, v47, v65

    add-long/2addr v1, v8

    mul-long v8, v47, v67

    add-long v23, v23, v8

    mul-long v8, v47, v69

    add-long/2addr v14, v8

    mul-long v8, v47, v71

    sub-long v29, v29, v8

    mul-long v8, v47, v73

    add-long v31, v31, v8

    mul-long v47, v47, v75

    sub-long v25, v25, v47

    add-long v8, v1, v11

    const/16 v0, 0x15

    shr-long/2addr v8, v0

    add-long v23, v23, v8

    shl-long/2addr v8, v0

    sub-long/2addr v1, v8

    add-long v8, v14, v11

    shr-long/2addr v8, v0

    add-long v29, v29, v8

    shl-long/2addr v8, v0

    sub-long/2addr v14, v8

    add-long v8, v31, v11

    shr-long/2addr v8, v0

    add-long v25, v25, v8

    shl-long/2addr v8, v0

    sub-long v31, v31, v8

    add-long v8, v34, v11

    shr-long/2addr v8, v0

    add-long/2addr v6, v8

    shl-long/2addr v8, v0

    sub-long v34, v34, v8

    add-long v8, v4, v11

    shr-long/2addr v8, v0

    add-long v40, v40, v8

    shl-long/2addr v8, v0

    sub-long/2addr v4, v8

    add-long v8, v61, v11

    shr-long/2addr v8, v0

    add-long v45, v45, v8

    shl-long/2addr v8, v0

    sub-long v61, v61, v8

    add-long v8, v23, v11

    shr-long/2addr v8, v0

    add-long/2addr v14, v8

    shl-long/2addr v8, v0

    sub-long v23, v23, v8

    add-long v8, v29, v11

    shr-long/2addr v8, v0

    add-long v31, v31, v8

    shl-long/2addr v8, v0

    sub-long v29, v29, v8

    add-long v8, v25, v11

    shr-long/2addr v8, v0

    add-long v34, v34, v8

    shl-long/2addr v8, v0

    sub-long v25, v25, v8

    add-long v8, v6, v11

    shr-long/2addr v8, v0

    add-long/2addr v4, v8

    shl-long/2addr v8, v0

    sub-long/2addr v6, v8

    add-long v8, v40, v11

    shr-long/2addr v8, v0

    add-long v61, v61, v8

    shl-long/2addr v8, v0

    sub-long v40, v40, v8

    add-long v11, v45, v11

    shr-long v8, v11, v0

    shl-long v11, v8, v0

    sub-long v45, v45, v11

    mul-long v11, v8, v65

    add-long/2addr v1, v11

    mul-long v11, v8, v67

    add-long v23, v23, v11

    mul-long v11, v8, v69

    add-long/2addr v14, v11

    mul-long v11, v8, v71

    sub-long v29, v29, v11

    mul-long v11, v8, v73

    add-long v31, v31, v11

    mul-long v8, v8, v75

    sub-long v25, v25, v8

    const/16 v0, 0x15

    shr-long v8, v1, v0

    add-long v23, v23, v8

    shl-long/2addr v8, v0

    sub-long/2addr v1, v8

    shr-long v8, v23, v0

    add-long/2addr v14, v8

    shl-long/2addr v8, v0

    sub-long v23, v23, v8

    shr-long v8, v14, v0

    add-long v29, v29, v8

    shl-long/2addr v8, v0

    sub-long/2addr v14, v8

    shr-long v8, v29, v0

    add-long v31, v31, v8

    shl-long/2addr v8, v0

    sub-long v29, v29, v8

    shr-long v8, v31, v0

    add-long v25, v25, v8

    shl-long/2addr v8, v0

    sub-long v31, v31, v8

    shr-long v8, v25, v0

    add-long v34, v34, v8

    shl-long/2addr v8, v0

    sub-long v25, v25, v8

    shr-long v8, v34, v0

    add-long/2addr v6, v8

    shl-long/2addr v8, v0

    sub-long v34, v34, v8

    shr-long v8, v6, v0

    add-long/2addr v4, v8

    shl-long/2addr v8, v0

    sub-long/2addr v6, v8

    shr-long v8, v4, v0

    add-long v40, v40, v8

    shl-long/2addr v8, v0

    sub-long/2addr v4, v8

    shr-long v8, v40, v0

    add-long v61, v61, v8

    shl-long/2addr v8, v0

    sub-long v40, v40, v8

    shr-long v8, v61, v0

    add-long v45, v45, v8

    shl-long/2addr v8, v0

    sub-long v61, v61, v8

    shr-long v8, v45, v0

    shl-long v11, v8, v0

    sub-long v45, v45, v11

    mul-long v65, v65, v8

    add-long v1, v1, v65

    mul-long v67, v67, v8

    add-long v23, v23, v67

    mul-long v69, v69, v8

    add-long v14, v14, v69

    mul-long v71, v71, v8

    sub-long v29, v29, v71

    mul-long v73, v73, v8

    add-long v31, v31, v73

    mul-long v8, v8, v75

    sub-long v25, v25, v8

    const/16 v0, 0x15

    shr-long v8, v1, v0

    add-long v23, v23, v8

    shl-long/2addr v8, v0

    sub-long/2addr v1, v8

    shr-long v8, v23, v0

    add-long/2addr v14, v8

    shl-long/2addr v8, v0

    sub-long v23, v23, v8

    shr-long v8, v14, v0

    add-long v29, v29, v8

    shl-long/2addr v8, v0

    sub-long/2addr v14, v8

    shr-long v8, v29, v0

    add-long v31, v31, v8

    shl-long/2addr v8, v0

    sub-long v29, v29, v8

    shr-long v8, v31, v0

    add-long v25, v25, v8

    shl-long/2addr v8, v0

    sub-long v31, v31, v8

    shr-long v8, v25, v0

    add-long v34, v34, v8

    shl-long/2addr v8, v0

    sub-long v25, v25, v8

    shr-long v8, v34, v0

    add-long/2addr v6, v8

    shl-long/2addr v8, v0

    sub-long v34, v34, v8

    shr-long v8, v6, v0

    add-long/2addr v4, v8

    shl-long/2addr v8, v0

    sub-long/2addr v6, v8

    shr-long v8, v4, v0

    add-long v40, v40, v8

    shl-long/2addr v8, v0

    sub-long/2addr v4, v8

    shr-long v8, v40, v0

    add-long v61, v61, v8

    shl-long/2addr v8, v0

    sub-long v40, v40, v8

    shr-long v8, v61, v0

    add-long v45, v45, v8

    shl-long/2addr v8, v0

    sub-long v61, v61, v8

    long-to-int v0, v1

    int-to-byte v0, v0

    const/16 v3, 0x8

    shr-long v8, v1, v3

    long-to-int v8, v8

    int-to-byte v8, v8

    shr-long v1, v1, v21

    const/4 v9, 0x5

    shl-long v11, v23, v9

    or-long/2addr v1, v11

    long-to-int v1, v1

    int-to-byte v1, v1

    const/4 v2, 0x3

    shr-long v11, v23, v2

    long-to-int v2, v11

    int-to-byte v2, v2

    shr-long v11, v23, v20

    long-to-int v9, v11

    int-to-byte v12, v9

    shr-long v23, v23, v19

    const/4 v9, 0x2

    shl-long v37, v14, v9

    or-long v10, v23, v37

    long-to-int v9, v10

    int-to-byte v10, v9

    move-wide/from16 v23, v4

    const/4 v9, 0x6

    shr-long v3, v14, v9

    long-to-int v3, v3

    int-to-byte v3, v3

    shr-long v4, v14, v18

    const/4 v9, 0x7

    shl-long v13, v29, v9

    or-long/2addr v4, v13

    long-to-int v4, v4

    int-to-byte v4, v4

    const/4 v5, 0x1

    shr-long v13, v29, v5

    long-to-int v5, v13

    int-to-byte v5, v5

    shr-long v13, v29, v17

    long-to-int v9, v13

    int-to-byte v13, v9

    shr-long v14, v29, v16

    const/4 v9, 0x4

    shl-long v29, v31, v9

    or-long v14, v14, v29

    long-to-int v11, v14

    int-to-byte v14, v11

    move/from16 v29, v14

    shr-long v14, v31, v9

    long-to-int v11, v14

    int-to-byte v14, v11

    const/16 v11, 0xc

    move v15, v10

    shr-long v9, v31, v11

    long-to-int v9, v9

    int-to-byte v9, v9

    const/16 v10, 0x14

    shr-long v10, v31, v10

    const/16 v30, 0x1

    shl-long v31, v25, v30

    or-long v10, v10, v31

    long-to-int v10, v10

    int-to-byte v10, v10

    move/from16 v30, v9

    move/from16 v31, v10

    const/4 v11, 0x7

    shr-long v9, v25, v11

    long-to-int v9, v9

    int-to-byte v9, v9

    const/16 v10, 0xf

    shr-long v25, v25, v10

    const/4 v10, 0x6

    shl-long v37, v34, v10

    or-long v10, v25, v37

    long-to-int v10, v10

    int-to-byte v10, v10

    move/from16 v25, v9

    move/from16 v26, v10

    const/4 v11, 0x2

    shr-long v9, v34, v11

    long-to-int v9, v9

    int-to-byte v9, v9

    move/from16 v32, v13

    move/from16 v37, v14

    const/16 v10, 0xa

    shr-long v13, v34, v10

    long-to-int v10, v13

    int-to-byte v10, v10

    const/16 v13, 0x12

    shr-long v34, v34, v13

    const/4 v13, 0x3

    shl-long v43, v6, v13

    or-long v13, v34, v43

    long-to-int v13, v13

    int-to-byte v13, v13

    move/from16 v34, v12

    const/4 v14, 0x5

    shr-long v11, v6, v14

    long-to-int v11, v11

    int-to-byte v11, v11

    const/16 v12, 0xd

    shr-long/2addr v6, v12

    long-to-int v6, v6

    int-to-byte v6, v6

    move v12, v6

    move-wide/from16 v6, v23

    long-to-int v14, v6

    int-to-byte v14, v14

    move/from16 v24, v11

    move/from16 p0, v12

    const/16 v23, 0x8

    shr-long v11, v6, v23

    long-to-int v11, v11

    int-to-byte v11, v11

    shr-long v6, v6, v21

    const/4 v12, 0x5

    shl-long v43, v40, v12

    or-long v6, v6, v43

    long-to-int v6, v6

    int-to-byte v6, v6

    move/from16 v23, v11

    const/4 v7, 0x3

    shr-long v11, v40, v7

    long-to-int v7, v11

    int-to-byte v7, v7

    shr-long v11, v40, v20

    long-to-int v11, v11

    int-to-byte v11, v11

    shr-long v40, v40, v19

    const/4 v12, 0x2

    shl-long v43, v61, v12

    move/from16 v35, v11

    or-long v11, v40, v43

    long-to-int v11, v11

    int-to-byte v11, v11

    move/from16 v38, v6

    move/from16 v40, v7

    const/4 v12, 0x6

    shr-long v6, v61, v12

    long-to-int v6, v6

    int-to-byte v6, v6

    shr-long v43, v61, v18

    const/4 v7, 0x7

    shl-long v47, v45, v7

    move v12, v6

    or-long v6, v43, v47

    long-to-int v6, v6

    int-to-byte v6, v6

    move/from16 v41, v11

    move/from16 v43, v12

    const/4 v7, 0x1

    shr-long v11, v45, v7

    long-to-int v7, v11

    int-to-byte v7, v7

    shr-long v11, v45, v17

    long-to-int v11, v11

    int-to-byte v11, v11

    move/from16 v44, v11

    shr-long v11, v45, v16

    long-to-int v11, v11

    int-to-byte v11, v11

    const/16 v12, 0x20

    new-array v12, v12, [B

    const/16 v22, 0x0

    aput-byte v0, v12, v22

    const/4 v0, 0x1

    aput-byte v8, v12, v0

    const/4 v0, 0x2

    aput-byte v1, v12, v0

    const/4 v0, 0x3

    aput-byte v2, v12, v0

    const/4 v0, 0x4

    aput-byte v34, v12, v0

    const/4 v0, 0x5

    aput-byte v15, v12, v0

    const/4 v0, 0x6

    aput-byte v3, v12, v0

    const/4 v0, 0x7

    aput-byte v4, v12, v0

    const/16 v0, 0x8

    aput-byte v5, v12, v0

    aput-byte v32, v12, v17

    const/16 v0, 0xa

    aput-byte v29, v12, v0

    aput-byte v37, v12, v20

    const/16 v0, 0xc

    aput-byte v30, v12, v0

    const/16 v0, 0xd

    aput-byte v31, v12, v0

    aput-byte v25, v12, v18

    const/16 v0, 0xf

    aput-byte v26, v12, v0

    aput-byte v9, v12, v21

    aput-byte v10, v12, v16

    const/16 v0, 0x12

    aput-byte v13, v12, v0

    aput-byte v24, v12, v19

    const/16 v0, 0x14

    aput-byte p0, v12, v0

    const/16 v0, 0x15

    aput-byte v14, v12, v0

    const/16 v0, 0x16

    aput-byte v23, v12, v0

    const/16 v0, 0x17

    aput-byte v38, v12, v0

    const/16 v0, 0x18

    aput-byte v40, v12, v0

    const/16 v0, 0x19

    aput-byte v35, v12, v0

    const/16 v0, 0x1a

    aput-byte v41, v12, v0

    const/16 v0, 0x1b

    aput-byte v43, v12, v0

    const/16 v0, 0x1c

    aput-byte v6, v12, v0

    const/16 v0, 0x1d

    aput-byte v7, v12, v0

    const/16 v0, 0x1e

    aput-byte v44, v12, v0

    const/16 v0, 0x1f

    aput-byte v11, v12, v0

    new-instance v0, Lcafe/cryptography/curve25519/Scalar;

    invoke-direct {v0, v12}, Lcafe/cryptography/curve25519/Scalar;-><init>([B)V

    return-object v0

    :cond_0
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v1, "Input must by 64 bytes"

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public static fromCanonicalBytes([B)Lcafe/cryptography/curve25519/Scalar;
    .locals 1

    new-instance v0, Lcafe/cryptography/curve25519/Scalar;

    invoke-direct {v0, p0}, Lcafe/cryptography/curve25519/Scalar;-><init>([B)V

    invoke-virtual {v0}, Lcafe/cryptography/curve25519/Scalar;->isCanonical()Z

    move-result p0

    if-eqz p0, :cond_0

    return-object v0

    :cond_0
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string v0, "Non-canonical scalar representation"

    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method private readObject(Ljava/io/ObjectInputStream;)V
    .locals 1

    const/16 v0, 0x20

    new-array v0, v0, [B

    invoke-virtual {p1, v0}, Ljava/io/ObjectInputStream;->readFully([B)V

    const/16 p1, 0x1f

    aget-byte p1, v0, p1

    shr-int/lit8 p1, p1, 0x7

    and-int/lit8 p1, p1, 0x1

    if-nez p1, :cond_0

    iput-object v0, p0, Lcafe/cryptography/curve25519/Scalar;->s:[B

    return-void

    :cond_0
    new-instance p0, Ljava/io/InvalidObjectException;

    const-string p1, "Invalid scalar representation"

    invoke-direct {p0, p1}, Ljava/io/InvalidObjectException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method private readObjectNoData()V
    .locals 1

    new-instance p0, Ljava/io/InvalidObjectException;

    const-string v0, "Cannot deserialize Scalar from no data"

    invoke-direct {p0, v0}, Ljava/io/InvalidObjectException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public static reduce([B)Lcafe/cryptography/curve25519/Scalar;
    .locals 1

    .line 2
    invoke-static {p0}, Lcafe/cryptography/curve25519/UnpackedScalar;->fromByteArray([B)Lcafe/cryptography/curve25519/UnpackedScalar;

    move-result-object p0

    sget-object v0, Lcafe/cryptography/curve25519/Constants;->R:Lcafe/cryptography/curve25519/UnpackedScalar;

    invoke-virtual {p0, v0}, Lcafe/cryptography/curve25519/UnpackedScalar;->mulInternal(Lcafe/cryptography/curve25519/UnpackedScalar;)[J

    move-result-object p0

    .line 3
    new-instance v0, Lcafe/cryptography/curve25519/Scalar;

    invoke-static {p0}, Lcafe/cryptography/curve25519/UnpackedScalar;->montgomeryReduce([J)Lcafe/cryptography/curve25519/UnpackedScalar;

    move-result-object p0

    invoke-virtual {p0}, Lcafe/cryptography/curve25519/UnpackedScalar;->toByteArray()[B

    move-result-object p0

    invoke-direct {v0, p0}, Lcafe/cryptography/curve25519/Scalar;-><init>([B)V

    return-object v0
.end method

.method private writeObject(Ljava/io/ObjectOutputStream;)V
    .locals 0

    invoke-virtual {p0}, Lcafe/cryptography/curve25519/Scalar;->toByteArray()[B

    move-result-object p0

    invoke-virtual {p1, p0}, Ljava/io/ObjectOutputStream;->write([B)V

    return-void
.end method


# virtual methods
.method public add(Lcafe/cryptography/curve25519/Scalar;)Lcafe/cryptography/curve25519/Scalar;
    .locals 1

    new-instance v0, Lcafe/cryptography/curve25519/Scalar;

    iget-object p0, p0, Lcafe/cryptography/curve25519/Scalar;->s:[B

    invoke-static {p0}, Lcafe/cryptography/curve25519/UnpackedScalar;->fromByteArray([B)Lcafe/cryptography/curve25519/UnpackedScalar;

    move-result-object p0

    iget-object p1, p1, Lcafe/cryptography/curve25519/Scalar;->s:[B

    invoke-static {p1}, Lcafe/cryptography/curve25519/UnpackedScalar;->fromByteArray([B)Lcafe/cryptography/curve25519/UnpackedScalar;

    move-result-object p1

    invoke-virtual {p0, p1}, Lcafe/cryptography/curve25519/UnpackedScalar;->add(Lcafe/cryptography/curve25519/UnpackedScalar;)Lcafe/cryptography/curve25519/UnpackedScalar;

    move-result-object p0

    invoke-virtual {p0}, Lcafe/cryptography/curve25519/UnpackedScalar;->toByteArray()[B

    move-result-object p0

    invoke-direct {v0, p0}, Lcafe/cryptography/curve25519/Scalar;-><init>([B)V

    return-object v0
.end method

.method public ctEquals(Lcafe/cryptography/curve25519/Scalar;)I
    .locals 0

    iget-object p0, p0, Lcafe/cryptography/curve25519/Scalar;->s:[B

    iget-object p1, p1, Lcafe/cryptography/curve25519/Scalar;->s:[B

    invoke-static {p0, p1}, Lcafe/cryptography/subtle/ConstantTime;->equal([B[B)I

    move-result p0

    return p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 2

    instance-of v0, p1, Lcafe/cryptography/curve25519/Scalar;

    const/4 v1, 0x0

    if-nez v0, :cond_0

    return v1

    :cond_0
    check-cast p1, Lcafe/cryptography/curve25519/Scalar;

    invoke-virtual {p0, p1}, Lcafe/cryptography/curve25519/Scalar;->ctEquals(Lcafe/cryptography/curve25519/Scalar;)I

    move-result p0

    const/4 p1, 0x1

    if-ne p0, p1, :cond_1

    move v1, p1

    :cond_1
    return v1
.end method

.method public hashCode()I
    .locals 0

    iget-object p0, p0, Lcafe/cryptography/curve25519/Scalar;->s:[B

    invoke-static {p0}, Ljava/util/Arrays;->hashCode([B)I

    move-result p0

    return p0
.end method

.method public isCanonical()Z
    .locals 1

    iget-object v0, p0, Lcafe/cryptography/curve25519/Scalar;->s:[B

    invoke-static {v0}, Lcafe/cryptography/curve25519/Scalar;->reduce([B)Lcafe/cryptography/curve25519/Scalar;

    move-result-object v0

    invoke-virtual {p0, v0}, Lcafe/cryptography/curve25519/Scalar;->ctEquals(Lcafe/cryptography/curve25519/Scalar;)I

    move-result p0

    const/4 v0, 0x1

    if-ne p0, v0, :cond_0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public multiply(Lcafe/cryptography/curve25519/Scalar;)Lcafe/cryptography/curve25519/Scalar;
    .locals 1

    sget-object v0, Lcafe/cryptography/curve25519/Scalar;->ZERO:Lcafe/cryptography/curve25519/Scalar;

    invoke-virtual {p0, p1, v0}, Lcafe/cryptography/curve25519/Scalar;->multiplyAndAdd(Lcafe/cryptography/curve25519/Scalar;Lcafe/cryptography/curve25519/Scalar;)Lcafe/cryptography/curve25519/Scalar;

    move-result-object p0

    return-object p0
.end method

.method public multiplyAndAdd(Lcafe/cryptography/curve25519/Scalar;Lcafe/cryptography/curve25519/Scalar;)Lcafe/cryptography/curve25519/Scalar;
    .locals 83

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v2, p2

    iget-object v3, v0, Lcafe/cryptography/curve25519/Scalar;->s:[B

    const/4 v4, 0x0

    invoke-static {v3, v4}, Lcafe/cryptography/curve25519/FieldElement;->load_3([BI)I

    move-result v3

    const v5, 0x1fffff

    and-int/2addr v3, v5

    int-to-long v6, v3

    iget-object v3, v0, Lcafe/cryptography/curve25519/Scalar;->s:[B

    const/4 v8, 0x2

    invoke-static {v3, v8}, Lcafe/cryptography/curve25519/FieldElement;->load_4([BI)J

    move-result-wide v9

    const/4 v3, 0x5

    shr-long/2addr v9, v3

    const-wide/32 v11, 0x1fffff

    and-long/2addr v9, v11

    iget-object v13, v0, Lcafe/cryptography/curve25519/Scalar;->s:[B

    invoke-static {v13, v3}, Lcafe/cryptography/curve25519/FieldElement;->load_3([BI)I

    move-result v13

    shr-int/2addr v13, v8

    and-int/2addr v13, v5

    int-to-long v13, v13

    iget-object v15, v0, Lcafe/cryptography/curve25519/Scalar;->s:[B

    const/4 v4, 0x7

    invoke-static {v15, v4}, Lcafe/cryptography/curve25519/FieldElement;->load_4([BI)J

    move-result-wide v16

    shr-long v16, v16, v4

    and-long v16, v16, v11

    iget-object v15, v0, Lcafe/cryptography/curve25519/Scalar;->s:[B

    const/16 v4, 0xa

    invoke-static {v15, v4}, Lcafe/cryptography/curve25519/FieldElement;->load_4([BI)J

    move-result-wide v18

    const/4 v15, 0x4

    shr-long v18, v18, v15

    and-long v18, v18, v11

    iget-object v15, v0, Lcafe/cryptography/curve25519/Scalar;->s:[B

    const/16 v4, 0xd

    invoke-static {v15, v4}, Lcafe/cryptography/curve25519/FieldElement;->load_3([BI)I

    move-result v15

    const/16 v21, 0x1

    shr-int/lit8 v15, v15, 0x1

    and-int/2addr v15, v5

    move-wide/from16 v23, v9

    int-to-long v8, v15

    iget-object v10, v0, Lcafe/cryptography/curve25519/Scalar;->s:[B

    const/16 v15, 0xf

    invoke-static {v10, v15}, Lcafe/cryptography/curve25519/FieldElement;->load_4([BI)J

    move-result-wide v25

    const/4 v10, 0x6

    shr-long v25, v25, v10

    and-long v25, v25, v11

    iget-object v10, v0, Lcafe/cryptography/curve25519/Scalar;->s:[B

    const/16 v15, 0x12

    invoke-static {v10, v15}, Lcafe/cryptography/curve25519/FieldElement;->load_3([BI)I

    move-result v10

    const/16 v27, 0x3

    shr-int/lit8 v10, v10, 0x3

    and-int/2addr v10, v5

    int-to-long v11, v10

    iget-object v10, v0, Lcafe/cryptography/curve25519/Scalar;->s:[B

    const/16 v15, 0x15

    invoke-static {v10, v15}, Lcafe/cryptography/curve25519/FieldElement;->load_3([BI)I

    move-result v10

    and-int/2addr v10, v5

    int-to-long v4, v10

    iget-object v10, v0, Lcafe/cryptography/curve25519/Scalar;->s:[B

    const/16 v15, 0x17

    invoke-static {v10, v15}, Lcafe/cryptography/curve25519/FieldElement;->load_4([BI)J

    move-result-wide v32

    shr-long v32, v32, v3

    const-wide/32 v28, 0x1fffff

    and-long v32, v32, v28

    iget-object v10, v0, Lcafe/cryptography/curve25519/Scalar;->s:[B

    const/16 v15, 0x1a

    invoke-static {v10, v15}, Lcafe/cryptography/curve25519/FieldElement;->load_3([BI)I

    move-result v10

    const/16 v22, 0x2

    shr-int/lit8 v10, v10, 0x2

    const v30, 0x1fffff

    and-int v10, v10, v30

    move-wide/from16 v34, v4

    int-to-long v3, v10

    iget-object v0, v0, Lcafe/cryptography/curve25519/Scalar;->s:[B

    const/16 v5, 0x1c

    invoke-static {v0, v5}, Lcafe/cryptography/curve25519/FieldElement;->load_4([BI)J

    move-result-wide v36

    const/4 v0, 0x7

    shr-long v36, v36, v0

    iget-object v0, v1, Lcafe/cryptography/curve25519/Scalar;->s:[B

    const/4 v10, 0x0

    invoke-static {v0, v10}, Lcafe/cryptography/curve25519/FieldElement;->load_3([BI)I

    move-result v0

    and-int v0, v0, v30

    move-wide/from16 v38, v6

    int-to-long v5, v0

    iget-object v0, v1, Lcafe/cryptography/curve25519/Scalar;->s:[B

    const/4 v7, 0x2

    invoke-static {v0, v7}, Lcafe/cryptography/curve25519/FieldElement;->load_4([BI)J

    move-result-wide v40

    const/4 v0, 0x5

    shr-long v40, v40, v0

    const-wide/32 v28, 0x1fffff

    and-long v40, v40, v28

    iget-object v10, v1, Lcafe/cryptography/curve25519/Scalar;->s:[B

    invoke-static {v10, v0}, Lcafe/cryptography/curve25519/FieldElement;->load_3([BI)I

    move-result v10

    shr-int/lit8 v0, v10, 0x2

    and-int v0, v0, v30

    move-wide/from16 v42, v3

    int-to-long v3, v0

    iget-object v0, v1, Lcafe/cryptography/curve25519/Scalar;->s:[B

    const/4 v7, 0x7

    invoke-static {v0, v7}, Lcafe/cryptography/curve25519/FieldElement;->load_4([BI)J

    move-result-wide v44

    shr-long v44, v44, v7

    and-long v44, v44, v28

    iget-object v0, v1, Lcafe/cryptography/curve25519/Scalar;->s:[B

    const/16 v7, 0xa

    invoke-static {v0, v7}, Lcafe/cryptography/curve25519/FieldElement;->load_4([BI)J

    move-result-wide v46

    const/4 v0, 0x4

    shr-long v46, v46, v0

    and-long v46, v46, v28

    iget-object v0, v1, Lcafe/cryptography/curve25519/Scalar;->s:[B

    const/16 v7, 0xd

    invoke-static {v0, v7}, Lcafe/cryptography/curve25519/FieldElement;->load_3([BI)I

    move-result v0

    shr-int/lit8 v0, v0, 0x1

    const v7, 0x1fffff

    and-int/2addr v0, v7

    move-wide/from16 v48, v8

    int-to-long v7, v0

    iget-object v0, v1, Lcafe/cryptography/curve25519/Scalar;->s:[B

    const/16 v9, 0xf

    invoke-static {v0, v9}, Lcafe/cryptography/curve25519/FieldElement;->load_4([BI)J

    move-result-wide v50

    const/4 v0, 0x6

    shr-long v9, v50, v0

    and-long v9, v9, v28

    iget-object v0, v1, Lcafe/cryptography/curve25519/Scalar;->s:[B

    const/16 v15, 0x12

    invoke-static {v0, v15}, Lcafe/cryptography/curve25519/FieldElement;->load_3([BI)I

    move-result v0

    shr-int/lit8 v0, v0, 0x3

    const v15, 0x1fffff

    and-int/2addr v0, v15

    move-wide/from16 v51, v11

    int-to-long v11, v0

    iget-object v0, v1, Lcafe/cryptography/curve25519/Scalar;->s:[B

    move-wide/from16 v53, v11

    const/16 v11, 0x15

    invoke-static {v0, v11}, Lcafe/cryptography/curve25519/FieldElement;->load_3([BI)I

    move-result v0

    and-int/2addr v0, v15

    int-to-long v11, v0

    iget-object v0, v1, Lcafe/cryptography/curve25519/Scalar;->s:[B

    const/16 v15, 0x17

    invoke-static {v0, v15}, Lcafe/cryptography/curve25519/FieldElement;->load_4([BI)J

    move-result-wide v55

    const/4 v0, 0x5

    shr-long v55, v55, v0

    const-wide/32 v28, 0x1fffff

    and-long v55, v55, v28

    iget-object v0, v1, Lcafe/cryptography/curve25519/Scalar;->s:[B

    const/16 v15, 0x1a

    invoke-static {v0, v15}, Lcafe/cryptography/curve25519/FieldElement;->load_3([BI)I

    move-result v0

    const/4 v15, 0x2

    shr-int/2addr v0, v15

    const v30, 0x1fffff

    and-int v0, v0, v30

    move-wide/from16 v57, v11

    int-to-long v11, v0

    iget-object v0, v1, Lcafe/cryptography/curve25519/Scalar;->s:[B

    const/16 v1, 0x1c

    invoke-static {v0, v1}, Lcafe/cryptography/curve25519/FieldElement;->load_4([BI)J

    move-result-wide v59

    const/4 v0, 0x7

    shr-long v59, v59, v0

    iget-object v0, v2, Lcafe/cryptography/curve25519/Scalar;->s:[B

    const/4 v1, 0x0

    invoke-static {v0, v1}, Lcafe/cryptography/curve25519/FieldElement;->load_3([BI)I

    move-result v0

    and-int v0, v0, v30

    int-to-long v0, v0

    move-wide/from16 v61, v11

    iget-object v11, v2, Lcafe/cryptography/curve25519/Scalar;->s:[B

    invoke-static {v11, v15}, Lcafe/cryptography/curve25519/FieldElement;->load_4([BI)J

    move-result-wide v11

    const/4 v15, 0x5

    shr-long/2addr v11, v15

    const-wide/32 v28, 0x1fffff

    and-long v11, v11, v28

    move-wide/from16 v63, v9

    iget-object v9, v2, Lcafe/cryptography/curve25519/Scalar;->s:[B

    invoke-static {v9, v15}, Lcafe/cryptography/curve25519/FieldElement;->load_3([BI)I

    move-result v9

    const/4 v10, 0x2

    shr-int/2addr v9, v10

    and-int v9, v9, v30

    int-to-long v9, v9

    iget-object v15, v2, Lcafe/cryptography/curve25519/Scalar;->s:[B

    move-wide/from16 v65, v7

    const/4 v7, 0x7

    invoke-static {v15, v7}, Lcafe/cryptography/curve25519/FieldElement;->load_4([BI)J

    move-result-wide v67

    shr-long v67, v67, v7

    and-long v7, v67, v28

    iget-object v15, v2, Lcafe/cryptography/curve25519/Scalar;->s:[B

    move-wide/from16 v67, v7

    const/16 v7, 0xa

    invoke-static {v15, v7}, Lcafe/cryptography/curve25519/FieldElement;->load_4([BI)J

    move-result-wide v69

    const/4 v7, 0x4

    shr-long v69, v69, v7

    and-long v7, v69, v28

    iget-object v15, v2, Lcafe/cryptography/curve25519/Scalar;->s:[B

    move-wide/from16 v69, v7

    const/16 v7, 0xd

    invoke-static {v15, v7}, Lcafe/cryptography/curve25519/FieldElement;->load_3([BI)I

    move-result v8

    shr-int/lit8 v7, v8, 0x1

    const v8, 0x1fffff

    and-int/2addr v7, v8

    move-wide/from16 v71, v9

    int-to-long v8, v7

    iget-object v7, v2, Lcafe/cryptography/curve25519/Scalar;->s:[B

    const/16 v10, 0xf

    invoke-static {v7, v10}, Lcafe/cryptography/curve25519/FieldElement;->load_4([BI)J

    move-result-wide v73

    const/4 v7, 0x6

    shr-long v73, v73, v7

    and-long v73, v73, v28

    iget-object v7, v2, Lcafe/cryptography/curve25519/Scalar;->s:[B

    const/16 v10, 0x12

    invoke-static {v7, v10}, Lcafe/cryptography/curve25519/FieldElement;->load_3([BI)I

    move-result v7

    shr-int/lit8 v7, v7, 0x3

    const v10, 0x1fffff

    and-int/2addr v7, v10

    move-wide/from16 v75, v11

    int-to-long v10, v7

    iget-object v7, v2, Lcafe/cryptography/curve25519/Scalar;->s:[B

    const/16 v12, 0x15

    invoke-static {v7, v12}, Lcafe/cryptography/curve25519/FieldElement;->load_3([BI)I

    move-result v7

    const v12, 0x1fffff

    and-int/2addr v7, v12

    move-wide/from16 v77, v13

    int-to-long v12, v7

    iget-object v7, v2, Lcafe/cryptography/curve25519/Scalar;->s:[B

    const/16 v14, 0x17

    invoke-static {v7, v14}, Lcafe/cryptography/curve25519/FieldElement;->load_4([BI)J

    move-result-wide v79

    const/4 v7, 0x5

    shr-long v14, v79, v7

    const-wide/32 v28, 0x1fffff

    and-long v14, v14, v28

    iget-object v7, v2, Lcafe/cryptography/curve25519/Scalar;->s:[B

    move-wide/from16 v28, v14

    const/16 v14, 0x1a

    invoke-static {v7, v14}, Lcafe/cryptography/curve25519/FieldElement;->load_3([BI)I

    move-result v7

    const/4 v14, 0x2

    shr-int/2addr v7, v14

    const v14, 0x1fffff

    and-int/2addr v7, v14

    int-to-long v14, v7

    iget-object v2, v2, Lcafe/cryptography/curve25519/Scalar;->s:[B

    const/16 v7, 0x1c

    invoke-static {v2, v7}, Lcafe/cryptography/curve25519/FieldElement;->load_4([BI)J

    move-result-wide v79

    const/4 v2, 0x7

    shr-long v79, v79, v2

    mul-long v81, v38, v5

    add-long v0, v0, v81

    mul-long v81, v38, v40

    add-long v75, v75, v81

    mul-long v81, v23, v5

    add-long v75, v75, v81

    mul-long v81, v38, v3

    add-long v71, v71, v81

    mul-long v81, v23, v40

    add-long v71, v71, v81

    mul-long v81, v77, v5

    add-long v71, v71, v81

    mul-long v81, v38, v44

    add-long v67, v67, v81

    mul-long v81, v23, v3

    add-long v67, v67, v81

    mul-long v81, v77, v40

    add-long v67, v67, v81

    mul-long v81, v16, v5

    add-long v67, v67, v81

    mul-long v81, v38, v46

    add-long v69, v69, v81

    mul-long v81, v23, v44

    add-long v69, v69, v81

    mul-long v81, v77, v3

    add-long v69, v69, v81

    mul-long v81, v16, v40

    add-long v69, v69, v81

    mul-long v81, v18, v5

    add-long v69, v69, v81

    mul-long v81, v38, v65

    add-long v8, v8, v81

    mul-long v81, v23, v46

    add-long v8, v8, v81

    mul-long v81, v77, v44

    add-long v8, v8, v81

    mul-long v81, v16, v3

    add-long v8, v8, v81

    mul-long v81, v18, v40

    add-long v8, v8, v81

    mul-long v81, v48, v5

    add-long v8, v8, v81

    mul-long v81, v38, v63

    add-long v73, v73, v81

    mul-long v81, v23, v65

    add-long v73, v73, v81

    mul-long v81, v77, v46

    add-long v73, v73, v81

    mul-long v81, v16, v44

    add-long v73, v73, v81

    mul-long v81, v18, v3

    add-long v73, v73, v81

    mul-long v81, v48, v40

    add-long v73, v73, v81

    mul-long v81, v25, v5

    add-long v73, v73, v81

    mul-long v81, v38, v53

    add-long v10, v10, v81

    mul-long v81, v23, v63

    add-long v10, v10, v81

    mul-long v81, v77, v65

    add-long v10, v10, v81

    mul-long v81, v16, v46

    add-long v10, v10, v81

    mul-long v81, v18, v44

    add-long v10, v10, v81

    mul-long v81, v48, v3

    add-long v10, v10, v81

    mul-long v81, v25, v40

    add-long v10, v10, v81

    mul-long v81, v51, v5

    add-long v10, v10, v81

    mul-long v81, v38, v57

    add-long v12, v12, v81

    mul-long v81, v23, v53

    add-long v12, v12, v81

    mul-long v81, v77, v63

    add-long v12, v12, v81

    mul-long v81, v16, v65

    add-long v12, v12, v81

    mul-long v81, v18, v46

    add-long v12, v12, v81

    mul-long v81, v48, v44

    add-long v12, v12, v81

    mul-long v81, v25, v3

    add-long v12, v12, v81

    mul-long v81, v51, v40

    add-long v12, v12, v81

    mul-long v81, v34, v5

    add-long v12, v12, v81

    mul-long v81, v38, v55

    add-long v28, v28, v81

    mul-long v81, v23, v57

    add-long v28, v28, v81

    mul-long v81, v77, v53

    add-long v28, v28, v81

    mul-long v81, v16, v63

    add-long v28, v28, v81

    mul-long v81, v18, v65

    add-long v28, v28, v81

    mul-long v81, v48, v46

    add-long v28, v28, v81

    mul-long v81, v25, v44

    add-long v28, v28, v81

    mul-long v81, v51, v3

    add-long v28, v28, v81

    mul-long v81, v34, v40

    add-long v28, v28, v81

    mul-long v81, v32, v5

    add-long v28, v28, v81

    mul-long v81, v38, v61

    add-long v14, v14, v81

    mul-long v81, v23, v55

    add-long v14, v14, v81

    mul-long v81, v77, v57

    add-long v14, v14, v81

    mul-long v81, v16, v53

    add-long v14, v14, v81

    mul-long v81, v18, v63

    add-long v14, v14, v81

    mul-long v81, v48, v65

    add-long v14, v14, v81

    mul-long v81, v25, v46

    add-long v14, v14, v81

    mul-long v81, v51, v44

    add-long v14, v14, v81

    mul-long v81, v34, v3

    add-long v14, v14, v81

    mul-long v81, v32, v40

    add-long v14, v14, v81

    mul-long v81, v42, v5

    add-long v14, v14, v81

    mul-long v38, v38, v59

    add-long v79, v79, v38

    mul-long v38, v23, v61

    add-long v79, v79, v38

    mul-long v38, v77, v55

    add-long v79, v79, v38

    mul-long v38, v16, v57

    add-long v79, v79, v38

    mul-long v38, v18, v53

    add-long v79, v79, v38

    mul-long v38, v48, v63

    add-long v79, v79, v38

    mul-long v38, v25, v65

    add-long v79, v79, v38

    mul-long v38, v51, v46

    add-long v79, v79, v38

    mul-long v38, v34, v44

    add-long v79, v79, v38

    mul-long v38, v32, v3

    add-long v79, v79, v38

    mul-long v38, v42, v40

    add-long v79, v79, v38

    mul-long v5, v5, v36

    add-long v79, v79, v5

    mul-long v5, v23, v59

    mul-long v23, v77, v61

    add-long v5, v5, v23

    mul-long v23, v16, v55

    add-long v5, v5, v23

    mul-long v23, v18, v57

    add-long v5, v5, v23

    mul-long v23, v48, v53

    add-long v5, v5, v23

    mul-long v23, v25, v63

    add-long v5, v5, v23

    mul-long v23, v51, v65

    add-long v5, v5, v23

    mul-long v23, v34, v46

    add-long v5, v5, v23

    mul-long v23, v32, v44

    add-long v5, v5, v23

    mul-long v23, v42, v3

    add-long v5, v5, v23

    mul-long v40, v40, v36

    add-long v5, v5, v40

    mul-long v23, v77, v59

    mul-long v38, v16, v61

    add-long v23, v23, v38

    mul-long v38, v18, v55

    add-long v23, v23, v38

    mul-long v38, v48, v57

    add-long v23, v23, v38

    mul-long v38, v25, v53

    add-long v23, v23, v38

    mul-long v38, v51, v63

    add-long v23, v23, v38

    mul-long v38, v34, v65

    add-long v23, v23, v38

    mul-long v38, v32, v46

    add-long v23, v23, v38

    mul-long v38, v42, v44

    add-long v23, v23, v38

    mul-long v3, v3, v36

    add-long v23, v23, v3

    mul-long v16, v16, v59

    mul-long v2, v18, v61

    add-long v16, v16, v2

    mul-long v2, v48, v55

    add-long v16, v16, v2

    mul-long v2, v25, v57

    add-long v16, v16, v2

    mul-long v2, v51, v53

    add-long v16, v16, v2

    mul-long v2, v34, v63

    add-long v16, v16, v2

    mul-long v2, v32, v65

    add-long v16, v16, v2

    mul-long v3, v42, v46

    add-long v16, v16, v3

    mul-long v44, v44, v36

    add-long v16, v16, v44

    mul-long v18, v18, v59

    mul-long v2, v48, v61

    add-long v18, v18, v2

    mul-long v2, v25, v55

    add-long v18, v18, v2

    mul-long v2, v51, v57

    add-long v18, v18, v2

    mul-long v2, v34, v53

    add-long v18, v18, v2

    mul-long v2, v32, v63

    add-long v18, v18, v2

    mul-long v3, v42, v65

    add-long v18, v18, v3

    mul-long v46, v46, v36

    add-long v18, v18, v46

    mul-long v2, v48, v59

    mul-long v38, v25, v61

    add-long v2, v2, v38

    mul-long v38, v51, v55

    add-long v2, v2, v38

    mul-long v38, v34, v57

    add-long v2, v2, v38

    mul-long v38, v32, v53

    add-long v2, v2, v38

    mul-long v38, v42, v63

    add-long v2, v2, v38

    mul-long v38, v36, v65

    add-long v2, v2, v38

    mul-long v25, v25, v59

    mul-long v38, v51, v61

    add-long v25, v25, v38

    mul-long v38, v34, v55

    add-long v25, v25, v38

    mul-long v38, v32, v57

    add-long v25, v25, v38

    mul-long v38, v42, v53

    add-long v25, v25, v38

    mul-long v38, v36, v63

    add-long v25, v25, v38

    mul-long v38, v51, v59

    mul-long v40, v34, v61

    add-long v38, v38, v40

    mul-long v40, v32, v55

    add-long v38, v38, v40

    mul-long v40, v42, v57

    add-long v38, v38, v40

    mul-long v40, v36, v53

    add-long v38, v38, v40

    mul-long v34, v34, v59

    mul-long v40, v32, v61

    add-long v34, v34, v40

    mul-long v40, v42, v55

    add-long v34, v34, v40

    mul-long v40, v36, v57

    add-long v34, v34, v40

    mul-long v32, v32, v59

    mul-long v40, v42, v61

    add-long v32, v32, v40

    mul-long v55, v55, v36

    add-long v32, v32, v55

    mul-long v40, v42, v59

    mul-long v42, v36, v61

    add-long v40, v40, v42

    mul-long v36, v36, v59

    const-wide/32 v42, 0x100000

    add-long v44, v0, v42

    const/16 v4, 0x15

    shr-long v44, v44, v4

    add-long v75, v75, v44

    shl-long v44, v44, v4

    sub-long v0, v0, v44

    add-long v44, v71, v42

    shr-long v44, v44, v4

    add-long v67, v67, v44

    shl-long v44, v44, v4

    sub-long v71, v71, v44

    add-long v44, v69, v42

    shr-long v44, v44, v4

    add-long v8, v8, v44

    shl-long v44, v44, v4

    sub-long v69, v69, v44

    add-long v44, v73, v42

    shr-long v44, v44, v4

    add-long v10, v10, v44

    shl-long v44, v44, v4

    sub-long v73, v73, v44

    add-long v44, v12, v42

    shr-long v44, v44, v4

    add-long v28, v28, v44

    shl-long v44, v44, v4

    sub-long v12, v12, v44

    add-long v44, v14, v42

    shr-long v44, v44, v4

    add-long v79, v79, v44

    shl-long v44, v44, v4

    sub-long v14, v14, v44

    add-long v44, v5, v42

    shr-long v44, v44, v4

    add-long v23, v23, v44

    shl-long v44, v44, v4

    sub-long v5, v5, v44

    add-long v44, v16, v42

    shr-long v44, v44, v4

    add-long v18, v18, v44

    shl-long v44, v44, v4

    sub-long v16, v16, v44

    add-long v44, v2, v42

    shr-long v44, v44, v4

    add-long v25, v25, v44

    shl-long v44, v44, v4

    sub-long v2, v2, v44

    add-long v44, v38, v42

    shr-long v44, v44, v4

    add-long v34, v34, v44

    shl-long v44, v44, v4

    sub-long v38, v38, v44

    add-long v44, v32, v42

    shr-long v44, v44, v4

    add-long v40, v40, v44

    shl-long v44, v44, v4

    sub-long v32, v32, v44

    add-long v44, v36, v42

    shr-long v44, v44, v4

    shl-long v46, v44, v4

    sub-long v36, v36, v46

    add-long v46, v75, v42

    shr-long v46, v46, v4

    add-long v71, v71, v46

    shl-long v46, v46, v4

    sub-long v75, v75, v46

    add-long v46, v67, v42

    shr-long v46, v46, v4

    add-long v69, v69, v46

    shl-long v46, v46, v4

    sub-long v67, v67, v46

    add-long v46, v8, v42

    shr-long v46, v46, v4

    add-long v73, v73, v46

    shl-long v46, v46, v4

    sub-long v8, v8, v46

    add-long v46, v10, v42

    shr-long v46, v46, v4

    add-long v12, v12, v46

    shl-long v46, v46, v4

    sub-long v10, v10, v46

    add-long v46, v28, v42

    shr-long v46, v46, v4

    add-long v14, v14, v46

    shl-long v46, v46, v4

    sub-long v28, v28, v46

    add-long v46, v79, v42

    shr-long v46, v46, v4

    add-long v5, v5, v46

    shl-long v46, v46, v4

    sub-long v79, v79, v46

    add-long v46, v23, v42

    shr-long v46, v46, v4

    add-long v16, v16, v46

    shl-long v46, v46, v4

    sub-long v23, v23, v46

    add-long v46, v18, v42

    shr-long v46, v46, v4

    add-long v2, v2, v46

    shl-long v46, v46, v4

    sub-long v18, v18, v46

    add-long v46, v25, v42

    shr-long v46, v46, v4

    add-long v38, v38, v46

    shl-long v46, v46, v4

    sub-long v25, v25, v46

    add-long v46, v34, v42

    shr-long v46, v46, v4

    add-long v32, v32, v46

    shl-long v46, v46, v4

    sub-long v34, v34, v46

    add-long v46, v40, v42

    shr-long v46, v46, v4

    add-long v36, v36, v46

    shl-long v46, v46, v4

    sub-long v40, v40, v46

    const-wide/32 v46, 0xa2c13

    mul-long v48, v44, v46

    add-long v79, v79, v48

    const-wide/32 v48, 0x72d18

    mul-long v51, v44, v48

    add-long v5, v5, v51

    const-wide/32 v51, 0x9fb67

    mul-long v53, v44, v51

    add-long v23, v23, v53

    const-wide/32 v53, 0xf39ad

    mul-long v55, v44, v53

    sub-long v16, v16, v55

    const-wide/32 v55, 0x215d1

    mul-long v57, v44, v55

    add-long v18, v18, v57

    const-wide/32 v57, 0xa6f7d

    mul-long v44, v44, v57

    sub-long v2, v2, v44

    mul-long v44, v36, v46

    add-long v14, v14, v44

    mul-long v44, v36, v48

    add-long v79, v79, v44

    mul-long v44, v36, v51

    add-long v5, v5, v44

    mul-long v44, v36, v53

    sub-long v23, v23, v44

    mul-long v44, v36, v55

    add-long v16, v16, v44

    mul-long v36, v36, v57

    sub-long v18, v18, v36

    mul-long v36, v40, v46

    add-long v28, v28, v36

    mul-long v36, v40, v48

    add-long v14, v14, v36

    mul-long v36, v40, v51

    add-long v79, v79, v36

    mul-long v36, v40, v53

    sub-long v5, v5, v36

    mul-long v36, v40, v55

    add-long v23, v23, v36

    mul-long v40, v40, v57

    sub-long v16, v16, v40

    mul-long v36, v32, v46

    add-long v12, v12, v36

    mul-long v36, v32, v48

    add-long v28, v28, v36

    mul-long v36, v32, v51

    add-long v14, v14, v36

    mul-long v36, v32, v53

    sub-long v79, v79, v36

    mul-long v36, v32, v55

    add-long v5, v5, v36

    mul-long v32, v32, v57

    sub-long v23, v23, v32

    mul-long v32, v34, v46

    add-long v10, v10, v32

    mul-long v32, v34, v48

    add-long v12, v12, v32

    mul-long v32, v34, v51

    add-long v28, v28, v32

    mul-long v32, v34, v53

    sub-long v14, v14, v32

    mul-long v32, v34, v55

    add-long v79, v79, v32

    mul-long v34, v34, v57

    sub-long v5, v5, v34

    mul-long v32, v38, v46

    add-long v73, v73, v32

    mul-long v32, v38, v48

    add-long v10, v10, v32

    mul-long v32, v38, v51

    add-long v12, v12, v32

    mul-long v32, v38, v53

    sub-long v28, v28, v32

    mul-long v32, v38, v55

    add-long v14, v14, v32

    mul-long v38, v38, v57

    sub-long v79, v79, v38

    add-long v32, v73, v42

    const/16 v4, 0x15

    shr-long v31, v32, v4

    add-long v10, v10, v31

    shl-long v31, v31, v4

    sub-long v73, v73, v31

    add-long v31, v12, v42

    shr-long v31, v31, v4

    add-long v28, v28, v31

    shl-long v31, v31, v4

    sub-long v12, v12, v31

    add-long v31, v14, v42

    shr-long v31, v31, v4

    add-long v79, v79, v31

    shl-long v31, v31, v4

    sub-long v14, v14, v31

    add-long v31, v5, v42

    shr-long v31, v31, v4

    add-long v23, v23, v31

    shl-long v31, v31, v4

    sub-long v5, v5, v31

    add-long v31, v16, v42

    shr-long v31, v31, v4

    add-long v18, v18, v31

    shl-long v31, v31, v4

    sub-long v16, v16, v31

    add-long v31, v2, v42

    shr-long v31, v31, v4

    add-long v25, v25, v31

    shl-long v31, v31, v4

    sub-long v2, v2, v31

    add-long v31, v10, v42

    shr-long v31, v31, v4

    add-long v12, v12, v31

    shl-long v31, v31, v4

    sub-long v10, v10, v31

    add-long v31, v28, v42

    shr-long v31, v31, v4

    add-long v14, v14, v31

    shl-long v31, v31, v4

    sub-long v28, v28, v31

    add-long v31, v79, v42

    shr-long v31, v31, v4

    add-long v5, v5, v31

    shl-long v31, v31, v4

    sub-long v79, v79, v31

    add-long v31, v23, v42

    shr-long v31, v31, v4

    add-long v16, v16, v31

    shl-long v31, v31, v4

    sub-long v23, v23, v31

    add-long v31, v18, v42

    shr-long v31, v31, v4

    add-long v2, v2, v31

    shl-long v32, v31, v4

    sub-long v18, v18, v32

    mul-long v32, v25, v46

    add-long v8, v8, v32

    mul-long v32, v25, v48

    add-long v73, v73, v32

    mul-long v32, v25, v51

    add-long v10, v10, v32

    mul-long v32, v25, v53

    sub-long v12, v12, v32

    mul-long v32, v25, v55

    add-long v28, v28, v32

    mul-long v25, v25, v57

    sub-long v14, v14, v25

    mul-long v25, v2, v46

    add-long v69, v69, v25

    mul-long v25, v2, v48

    add-long v8, v8, v25

    mul-long v25, v2, v51

    add-long v73, v73, v25

    mul-long v25, v2, v53

    sub-long v10, v10, v25

    mul-long v25, v2, v55

    add-long v12, v12, v25

    mul-long v2, v2, v57

    sub-long v28, v28, v2

    mul-long v2, v18, v46

    add-long v67, v67, v2

    mul-long v2, v18, v48

    add-long v69, v69, v2

    mul-long v2, v18, v51

    add-long/2addr v8, v2

    mul-long v2, v18, v53

    sub-long v73, v73, v2

    mul-long v2, v18, v55

    add-long/2addr v10, v2

    mul-long v18, v18, v57

    sub-long v12, v12, v18

    mul-long v2, v16, v46

    add-long v71, v71, v2

    mul-long v2, v16, v48

    add-long v67, v67, v2

    mul-long v2, v16, v51

    add-long v69, v69, v2

    mul-long v2, v16, v53

    sub-long/2addr v8, v2

    mul-long v2, v16, v55

    add-long v73, v73, v2

    mul-long v16, v16, v57

    sub-long v10, v10, v16

    mul-long v2, v23, v46

    add-long v75, v75, v2

    mul-long v2, v23, v48

    add-long v71, v71, v2

    mul-long v2, v23, v51

    add-long v67, v67, v2

    mul-long v2, v23, v53

    sub-long v69, v69, v2

    mul-long v2, v23, v55

    add-long/2addr v8, v2

    mul-long v23, v23, v57

    sub-long v73, v73, v23

    mul-long v2, v5, v46

    add-long/2addr v0, v2

    mul-long v2, v5, v48

    add-long v75, v75, v2

    mul-long v2, v5, v51

    add-long v71, v71, v2

    mul-long v2, v5, v53

    sub-long v67, v67, v2

    mul-long v2, v5, v55

    add-long v69, v69, v2

    mul-long v5, v5, v57

    sub-long/2addr v8, v5

    add-long v2, v0, v42

    const/16 v4, 0x15

    shr-long/2addr v2, v4

    add-long v75, v75, v2

    shl-long/2addr v2, v4

    sub-long/2addr v0, v2

    add-long v2, v71, v42

    shr-long/2addr v2, v4

    add-long v67, v67, v2

    shl-long/2addr v2, v4

    sub-long v71, v71, v2

    add-long v2, v69, v42

    shr-long/2addr v2, v4

    add-long/2addr v8, v2

    shl-long/2addr v2, v4

    sub-long v69, v69, v2

    add-long v2, v73, v42

    shr-long/2addr v2, v4

    add-long/2addr v10, v2

    shl-long/2addr v2, v4

    sub-long v73, v73, v2

    add-long v2, v12, v42

    shr-long/2addr v2, v4

    add-long v28, v28, v2

    shl-long/2addr v2, v4

    sub-long/2addr v12, v2

    add-long v2, v14, v42

    shr-long/2addr v2, v4

    add-long v79, v79, v2

    shl-long/2addr v2, v4

    sub-long/2addr v14, v2

    add-long v2, v75, v42

    shr-long/2addr v2, v4

    add-long v71, v71, v2

    shl-long/2addr v2, v4

    sub-long v75, v75, v2

    add-long v2, v67, v42

    shr-long/2addr v2, v4

    add-long v69, v69, v2

    shl-long/2addr v2, v4

    sub-long v67, v67, v2

    add-long v2, v8, v42

    shr-long/2addr v2, v4

    add-long v73, v73, v2

    shl-long/2addr v2, v4

    sub-long/2addr v8, v2

    add-long v2, v10, v42

    shr-long/2addr v2, v4

    add-long/2addr v12, v2

    shl-long/2addr v2, v4

    sub-long/2addr v10, v2

    add-long v2, v28, v42

    shr-long/2addr v2, v4

    add-long/2addr v14, v2

    shl-long/2addr v2, v4

    sub-long v28, v28, v2

    add-long v42, v79, v42

    shr-long v2, v42, v4

    shl-long v5, v2, v4

    sub-long v79, v79, v5

    mul-long v4, v2, v46

    add-long/2addr v0, v4

    mul-long v4, v2, v48

    add-long v75, v75, v4

    mul-long v4, v2, v51

    add-long v71, v71, v4

    mul-long v4, v2, v53

    sub-long v67, v67, v4

    mul-long v4, v2, v55

    add-long v69, v69, v4

    mul-long v2, v2, v57

    sub-long/2addr v8, v2

    const/16 v2, 0x15

    shr-long v3, v0, v2

    add-long v75, v75, v3

    shl-long/2addr v3, v2

    sub-long/2addr v0, v3

    shr-long v3, v75, v2

    add-long v71, v71, v3

    shl-long/2addr v3, v2

    sub-long v75, v75, v3

    shr-long v3, v71, v2

    add-long v67, v67, v3

    shl-long/2addr v3, v2

    sub-long v71, v71, v3

    shr-long v3, v67, v2

    add-long v69, v69, v3

    shl-long/2addr v3, v2

    sub-long v67, v67, v3

    shr-long v3, v69, v2

    add-long/2addr v8, v3

    shl-long/2addr v3, v2

    sub-long v69, v69, v3

    shr-long v3, v8, v2

    add-long v73, v73, v3

    shl-long/2addr v3, v2

    sub-long/2addr v8, v3

    shr-long v3, v73, v2

    add-long/2addr v10, v3

    shl-long/2addr v3, v2

    sub-long v73, v73, v3

    shr-long v3, v10, v2

    add-long/2addr v12, v3

    shl-long/2addr v3, v2

    sub-long/2addr v10, v3

    shr-long v3, v12, v2

    add-long v28, v28, v3

    shl-long/2addr v3, v2

    sub-long/2addr v12, v3

    shr-long v3, v28, v2

    add-long/2addr v14, v3

    shl-long/2addr v3, v2

    sub-long v28, v28, v3

    shr-long v3, v14, v2

    add-long v79, v79, v3

    shl-long/2addr v3, v2

    sub-long/2addr v14, v3

    shr-long v3, v79, v2

    shl-long v5, v3, v2

    sub-long v79, v79, v5

    mul-long v46, v46, v3

    add-long v0, v0, v46

    mul-long v48, v48, v3

    add-long v75, v75, v48

    mul-long v51, v51, v3

    add-long v71, v71, v51

    mul-long v53, v53, v3

    sub-long v67, v67, v53

    mul-long v55, v55, v3

    add-long v69, v69, v55

    mul-long v3, v3, v57

    sub-long/2addr v8, v3

    const/16 v2, 0x15

    shr-long v3, v0, v2

    add-long v75, v75, v3

    shl-long/2addr v3, v2

    sub-long/2addr v0, v3

    shr-long v3, v75, v2

    add-long v71, v71, v3

    shl-long/2addr v3, v2

    sub-long v75, v75, v3

    shr-long v3, v71, v2

    add-long v67, v67, v3

    shl-long/2addr v3, v2

    sub-long v71, v71, v3

    shr-long v3, v67, v2

    add-long v69, v69, v3

    shl-long/2addr v3, v2

    sub-long v67, v67, v3

    shr-long v3, v69, v2

    add-long/2addr v8, v3

    shl-long/2addr v3, v2

    sub-long v69, v69, v3

    shr-long v3, v8, v2

    add-long v73, v73, v3

    shl-long/2addr v3, v2

    sub-long/2addr v8, v3

    shr-long v3, v73, v2

    add-long/2addr v10, v3

    shl-long/2addr v3, v2

    sub-long v73, v73, v3

    shr-long v3, v10, v2

    add-long/2addr v12, v3

    shl-long/2addr v3, v2

    sub-long/2addr v10, v3

    shr-long v3, v12, v2

    add-long v28, v28, v3

    shl-long/2addr v3, v2

    sub-long/2addr v12, v3

    shr-long v3, v28, v2

    add-long/2addr v14, v3

    shl-long/2addr v3, v2

    sub-long v28, v28, v3

    shr-long v3, v14, v2

    add-long v79, v79, v3

    shl-long v2, v3, v2

    sub-long/2addr v14, v2

    long-to-int v2, v0

    int-to-byte v2, v2

    const/16 v3, 0x8

    shr-long v4, v0, v3

    long-to-int v4, v4

    int-to-byte v4, v4

    const/16 v5, 0x10

    shr-long/2addr v0, v5

    const/4 v6, 0x5

    shl-long v16, v75, v6

    or-long v0, v0, v16

    long-to-int v0, v0

    int-to-byte v0, v0

    shr-long v6, v75, v27

    long-to-int v1, v6

    int-to-byte v1, v1

    const/16 v6, 0xb

    move v7, v4

    shr-long v3, v75, v6

    long-to-int v3, v3

    int-to-byte v3, v3

    const/16 v4, 0x13

    shr-long v16, v75, v4

    const/16 v18, 0x2

    shl-long v23, v71, v18

    move/from16 v18, v7

    or-long v6, v16, v23

    long-to-int v6, v6

    int-to-byte v6, v6

    const/4 v7, 0x6

    shr-long v4, v71, v7

    long-to-int v4, v4

    int-to-byte v4, v4

    const/16 v5, 0xe

    shr-long v23, v71, v5

    const/4 v7, 0x7

    shl-long v25, v67, v7

    move v7, v6

    or-long v5, v23, v25

    long-to-int v5, v5

    int-to-byte v5, v5

    move/from16 v23, v5

    shr-long v5, v67, v21

    long-to-int v5, v5

    int-to-byte v5, v5

    const/16 v6, 0x9

    move/from16 v24, v4

    move/from16 v25, v5

    shr-long v4, v67, v6

    long-to-int v4, v4

    int-to-byte v4, v4

    const/16 v5, 0x11

    shr-long v31, v67, v5

    const/16 v20, 0x4

    shl-long v34, v69, v20

    or-long v5, v31, v34

    long-to-int v5, v5

    int-to-byte v5, v5

    move/from16 v31, v5

    shr-long v5, v69, v20

    long-to-int v5, v5

    int-to-byte v5, v5

    const/16 v6, 0xc

    move/from16 v32, v5

    shr-long v5, v69, v6

    long-to-int v5, v5

    int-to-byte v5, v5

    const/16 v6, 0x14

    shr-long v34, v69, v6

    shl-long v36, v8, v21

    move/from16 v33, v5

    or-long v5, v34, v36

    long-to-int v5, v5

    int-to-byte v5, v5

    move/from16 v34, v4

    move/from16 v35, v5

    const/4 v6, 0x7

    shr-long v4, v8, v6

    long-to-int v4, v4

    int-to-byte v4, v4

    const/16 v5, 0xf

    shr-long/2addr v8, v5

    const/4 v5, 0x6

    shl-long v36, v73, v5

    or-long v5, v8, v36

    long-to-int v5, v5

    int-to-byte v5, v5

    const/4 v6, 0x2

    shr-long v8, v73, v6

    long-to-int v6, v8

    int-to-byte v6, v6

    move v9, v5

    move/from16 v36, v6

    const/16 v8, 0xa

    shr-long v5, v73, v8

    long-to-int v5, v5

    int-to-byte v5, v5

    const/16 v6, 0x12

    shr-long v37, v73, v6

    shl-long v39, v10, v27

    move v8, v5

    or-long v5, v37, v39

    long-to-int v5, v5

    int-to-byte v5, v5

    move/from16 v38, v8

    move/from16 v37, v9

    const/4 v6, 0x5

    shr-long v8, v10, v6

    long-to-int v6, v8

    int-to-byte v6, v6

    const/16 v8, 0xd

    shr-long v9, v10, v8

    long-to-int v8, v9

    int-to-byte v8, v8

    long-to-int v9, v12

    int-to-byte v9, v9

    move v11, v8

    move/from16 v39, v9

    const/16 v10, 0x8

    shr-long v8, v12, v10

    long-to-int v8, v8

    int-to-byte v8, v8

    const/16 v9, 0x10

    shr-long/2addr v12, v9

    const/4 v9, 0x5

    shl-long v40, v28, v9

    or-long v9, v12, v40

    long-to-int v9, v9

    int-to-byte v9, v9

    shr-long v12, v28, v27

    long-to-int v10, v12

    int-to-byte v10, v10

    move v13, v9

    move/from16 v40, v10

    const/16 v12, 0xb

    shr-long v9, v28, v12

    long-to-int v9, v9

    int-to-byte v9, v9

    const/16 v10, 0x13

    shr-long v28, v28, v10

    const/4 v10, 0x2

    shl-long v41, v14, v10

    move v12, v9

    or-long v9, v28, v41

    long-to-int v9, v9

    int-to-byte v9, v9

    move/from16 v29, v12

    move/from16 v28, v13

    const/4 v10, 0x6

    shr-long v12, v14, v10

    long-to-int v10, v12

    int-to-byte v10, v10

    const/16 v12, 0xe

    shr-long v13, v14, v12

    const/4 v12, 0x7

    shl-long v41, v79, v12

    or-long v12, v13, v41

    long-to-int v12, v12

    int-to-byte v12, v12

    shr-long v13, v79, v21

    long-to-int v13, v13

    int-to-byte v13, v13

    move v15, v12

    move/from16 v41, v13

    const/16 v14, 0x9

    shr-long v12, v79, v14

    long-to-int v12, v12

    int-to-byte v12, v12

    move/from16 v42, v15

    const/16 v13, 0x11

    shr-long v14, v79, v13

    long-to-int v13, v14

    int-to-byte v13, v13

    const/16 v14, 0x20

    new-array v14, v14, [B

    const/4 v15, 0x0

    aput-byte v2, v14, v15

    aput-byte v18, v14, v21

    const/4 v2, 0x2

    aput-byte v0, v14, v2

    aput-byte v1, v14, v27

    const/4 v0, 0x4

    aput-byte v3, v14, v0

    const/4 v0, 0x5

    aput-byte v7, v14, v0

    const/4 v0, 0x6

    aput-byte v24, v14, v0

    const/4 v0, 0x7

    aput-byte v23, v14, v0

    const/16 v0, 0x8

    aput-byte v25, v14, v0

    const/16 v0, 0x9

    aput-byte v34, v14, v0

    const/16 v0, 0xa

    aput-byte v31, v14, v0

    const/16 v0, 0xb

    aput-byte v32, v14, v0

    const/16 v0, 0xc

    aput-byte v33, v14, v0

    const/16 v0, 0xd

    aput-byte v35, v14, v0

    const/16 v0, 0xe

    aput-byte v4, v14, v0

    const/16 v0, 0xf

    aput-byte v37, v14, v0

    const/16 v0, 0x10

    aput-byte v36, v14, v0

    const/16 v0, 0x11

    aput-byte v38, v14, v0

    const/16 v0, 0x12

    aput-byte v5, v14, v0

    const/16 v0, 0x13

    aput-byte v6, v14, v0

    const/16 v0, 0x14

    aput-byte v11, v14, v0

    const/16 v0, 0x15

    aput-byte v39, v14, v0

    const/16 v0, 0x16

    aput-byte v8, v14, v0

    const/16 v0, 0x17

    aput-byte v28, v14, v0

    const/16 v0, 0x18

    aput-byte v40, v14, v0

    const/16 v0, 0x19

    aput-byte v29, v14, v0

    const/16 v0, 0x1a

    aput-byte v9, v14, v0

    const/16 v0, 0x1b

    aput-byte v10, v14, v0

    const/16 v0, 0x1c

    aput-byte v42, v14, v0

    const/16 v0, 0x1d

    aput-byte v41, v14, v0

    const/16 v0, 0x1e

    aput-byte v12, v14, v0

    const/16 v0, 0x1f

    aput-byte v13, v14, v0

    new-instance v0, Lcafe/cryptography/curve25519/Scalar;

    invoke-direct {v0, v14}, Lcafe/cryptography/curve25519/Scalar;-><init>([B)V

    return-object v0
.end method

.method public nonAdjacentForm()[B
    .locals 10

    const/16 v0, 0x100

    new-array v1, v0, [B

    const/4 v2, 0x0

    move v3, v2

    :goto_0
    const/4 v4, 0x1

    if-ge v3, v0, :cond_0

    iget-object v5, p0, Lcafe/cryptography/curve25519/Scalar;->s:[B

    shr-int/lit8 v6, v3, 0x3

    aget-byte v5, v5, v6

    and-int/lit8 v6, v3, 0x7

    shr-int/2addr v5, v6

    and-int/2addr v4, v5

    int-to-byte v4, v4

    aput-byte v4, v1, v3

    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    :cond_0
    move p0, v2

    :goto_1
    if-ge p0, v0, :cond_5

    aget-byte v3, v1, p0

    if-eqz v3, :cond_4

    move v3, v4

    :goto_2
    const/4 v5, 0x6

    if-gt v3, v5, :cond_4

    add-int v5, p0, v3

    if-ge v5, v0, :cond_4

    aget-byte v6, v1, v5

    if-eqz v6, :cond_3

    aget-byte v7, v1, p0

    shl-int v8, v6, v3

    add-int/2addr v8, v7

    const/16 v9, 0xf

    if-gt v8, v9, :cond_1

    shl-int/2addr v6, v3

    add-int/2addr v7, v6

    int-to-byte v6, v7

    aput-byte v6, v1, p0

    aput-byte v2, v1, v5

    goto :goto_4

    :cond_1
    shl-int v8, v6, v3

    sub-int v8, v7, v8

    const/16 v9, -0xf

    if-lt v8, v9, :cond_4

    shl-int/2addr v6, v3

    sub-int/2addr v7, v6

    int-to-byte v6, v7

    aput-byte v6, v1, p0

    :goto_3
    if-ge v5, v0, :cond_3

    aget-byte v6, v1, v5

    if-nez v6, :cond_2

    aput-byte v4, v1, v5

    goto :goto_4

    :cond_2
    aput-byte v2, v1, v5

    add-int/lit8 v5, v5, 0x1

    goto :goto_3

    :cond_3
    :goto_4
    add-int/lit8 v3, v3, 0x1

    goto :goto_2

    :cond_4
    add-int/lit8 p0, p0, 0x1

    goto :goto_1

    :cond_5
    return-object v1
.end method

.method public reduce()Lcafe/cryptography/curve25519/Scalar;
    .locals 0

    .line 1
    iget-object p0, p0, Lcafe/cryptography/curve25519/Scalar;->s:[B

    invoke-static {p0}, Lcafe/cryptography/curve25519/Scalar;->reduce([B)Lcafe/cryptography/curve25519/Scalar;

    move-result-object p0

    return-object p0
.end method

.method public subtract(Lcafe/cryptography/curve25519/Scalar;)Lcafe/cryptography/curve25519/Scalar;
    .locals 1

    new-instance v0, Lcafe/cryptography/curve25519/Scalar;

    iget-object p0, p0, Lcafe/cryptography/curve25519/Scalar;->s:[B

    invoke-static {p0}, Lcafe/cryptography/curve25519/UnpackedScalar;->fromByteArray([B)Lcafe/cryptography/curve25519/UnpackedScalar;

    move-result-object p0

    iget-object p1, p1, Lcafe/cryptography/curve25519/Scalar;->s:[B

    invoke-static {p1}, Lcafe/cryptography/curve25519/UnpackedScalar;->fromByteArray([B)Lcafe/cryptography/curve25519/UnpackedScalar;

    move-result-object p1

    invoke-virtual {p0, p1}, Lcafe/cryptography/curve25519/UnpackedScalar;->subtract(Lcafe/cryptography/curve25519/UnpackedScalar;)Lcafe/cryptography/curve25519/UnpackedScalar;

    move-result-object p0

    invoke-virtual {p0}, Lcafe/cryptography/curve25519/UnpackedScalar;->toByteArray()[B

    move-result-object p0

    invoke-direct {v0, p0}, Lcafe/cryptography/curve25519/Scalar;-><init>([B)V

    return-object v0
.end method

.method public toByteArray()[B
    .locals 1

    iget-object p0, p0, Lcafe/cryptography/curve25519/Scalar;->s:[B

    array-length v0, p0

    invoke-static {p0, v0}, Ljava/util/Arrays;->copyOf([BI)[B

    move-result-object p0

    return-object p0
.end method

.method public toRadix16()[B
    .locals 6

    const/16 v0, 0x40

    new-array v0, v0, [B

    const/4 v1, 0x0

    move v2, v1

    :goto_0
    const/16 v3, 0x20

    if-ge v2, v3, :cond_0

    mul-int/lit8 v3, v2, 0x2

    iget-object v4, p0, Lcafe/cryptography/curve25519/Scalar;->s:[B

    aget-byte v5, v4, v2

    and-int/lit8 v5, v5, 0xf

    int-to-byte v5, v5

    aput-byte v5, v0, v3

    add-int/lit8 v3, v3, 0x1

    aget-byte v4, v4, v2

    shr-int/lit8 v4, v4, 0x4

    and-int/lit8 v4, v4, 0xf

    int-to-byte v4, v4

    aput-byte v4, v0, v3

    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_0
    move p0, v1

    :goto_1
    const/16 v2, 0x3f

    if-ge v1, v2, :cond_1

    aget-byte v2, v0, v1

    add-int/2addr v2, p0

    int-to-byte p0, v2

    aput-byte p0, v0, v1

    add-int/lit8 v2, p0, 0x8

    shr-int/lit8 v2, v2, 0x4

    shl-int/lit8 v3, v2, 0x4

    sub-int/2addr p0, v3

    int-to-byte p0, p0

    aput-byte p0, v0, v1

    add-int/lit8 v1, v1, 0x1

    move p0, v2

    goto :goto_1

    :cond_1
    aget-byte v1, v0, v2

    add-int/2addr v1, p0

    int-to-byte p0, v1

    aput-byte p0, v0, v2

    return-object v0
.end method

.method public toString()Ljava/lang/String;
    .locals 2

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "Scalar("

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object p0, p0, Lcafe/cryptography/curve25519/Scalar;->s:[B

    invoke-static {p0}, Lcafe/cryptography/curve25519/StrUtils;->bytesToHex([B)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p0, ")"

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
