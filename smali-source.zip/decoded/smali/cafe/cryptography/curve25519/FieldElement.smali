.class Lcafe/cryptography/curve25519/FieldElement;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcafe/cryptography/curve25519/FieldElement$SqrtRatioM1Result;
    }
.end annotation


# static fields
.field public static final MINUS_ONE:Lcafe/cryptography/curve25519/FieldElement;

.field public static final ONE:Lcafe/cryptography/curve25519/FieldElement;

.field public static final ZERO:Lcafe/cryptography/curve25519/FieldElement;

.field private static final ZERO_BYTES:[B


# instance fields
.field private final t:[I


# direct methods
.method static constructor <clinit>()V
    .locals 3

    new-instance v0, Lcafe/cryptography/curve25519/FieldElement;

    const/16 v1, 0xa

    new-array v2, v1, [I

    fill-array-data v2, :array_0

    invoke-direct {v0, v2}, Lcafe/cryptography/curve25519/FieldElement;-><init>([I)V

    sput-object v0, Lcafe/cryptography/curve25519/FieldElement;->ZERO:Lcafe/cryptography/curve25519/FieldElement;

    new-instance v2, Lcafe/cryptography/curve25519/FieldElement;

    new-array v1, v1, [I

    fill-array-data v1, :array_1

    invoke-direct {v2, v1}, Lcafe/cryptography/curve25519/FieldElement;-><init>([I)V

    sput-object v2, Lcafe/cryptography/curve25519/FieldElement;->ONE:Lcafe/cryptography/curve25519/FieldElement;

    invoke-virtual {v0, v2}, Lcafe/cryptography/curve25519/FieldElement;->subtract(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v0

    sput-object v0, Lcafe/cryptography/curve25519/FieldElement;->MINUS_ONE:Lcafe/cryptography/curve25519/FieldElement;

    const/16 v0, 0x20

    new-array v0, v0, [B

    sput-object v0, Lcafe/cryptography/curve25519/FieldElement;->ZERO_BYTES:[B

    return-void

    nop

    :array_0
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_1
    .array-data 4
        0x1
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data
.end method

.method public constructor <init>([I)V
    .locals 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    array-length v0, p1

    const/16 v1, 0xa

    if-ne v0, v1, :cond_0

    iput-object p1, p0, Lcafe/cryptography/curve25519/FieldElement;->t:[I

    return-void

    :cond_0
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string p1, "Invalid radix-2^25.5 representation"

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public static fromByteArray([B)Lcafe/cryptography/curve25519/FieldElement;
    .locals 35

    move-object/from16 v0, p0

    const/4 v1, 0x0

    invoke-static {v0, v1}, Lcafe/cryptography/curve25519/FieldElement;->load_4([BI)J

    move-result-wide v1

    const/4 v3, 0x4

    invoke-static {v0, v3}, Lcafe/cryptography/curve25519/FieldElement;->load_3([BI)I

    move-result v4

    shl-int/lit8 v4, v4, 0x6

    int-to-long v4, v4

    const/4 v6, 0x7

    invoke-static {v0, v6}, Lcafe/cryptography/curve25519/FieldElement;->load_3([BI)I

    move-result v7

    shl-int/lit8 v7, v7, 0x5

    int-to-long v7, v7

    const/16 v9, 0xa

    invoke-static {v0, v9}, Lcafe/cryptography/curve25519/FieldElement;->load_3([BI)I

    move-result v9

    shl-int/lit8 v9, v9, 0x3

    int-to-long v9, v9

    const/16 v11, 0xd

    invoke-static {v0, v11}, Lcafe/cryptography/curve25519/FieldElement;->load_3([BI)I

    move-result v11

    shl-int/lit8 v11, v11, 0x2

    int-to-long v11, v11

    const/16 v13, 0x10

    invoke-static {v0, v13}, Lcafe/cryptography/curve25519/FieldElement;->load_4([BI)J

    move-result-wide v13

    const/16 v15, 0x14

    invoke-static {v0, v15}, Lcafe/cryptography/curve25519/FieldElement;->load_3([BI)I

    move-result v15

    shl-int/lit8 v6, v15, 0x7

    move-wide/from16 v16, v4

    int-to-long v3, v6

    const/16 v5, 0x17

    invoke-static {v0, v5}, Lcafe/cryptography/curve25519/FieldElement;->load_3([BI)I

    move-result v5

    shl-int/lit8 v5, v5, 0x5

    int-to-long v5, v5

    const/16 v15, 0x1a

    invoke-static {v0, v15}, Lcafe/cryptography/curve25519/FieldElement;->load_3([BI)I

    move-result v19

    const/16 v18, 0x4

    shl-int/lit8 v15, v19, 0x4

    move-wide/from16 v18, v5

    int-to-long v5, v15

    const/16 v15, 0x1d

    invoke-static {v0, v15}, Lcafe/cryptography/curve25519/FieldElement;->load_3([BI)I

    move-result v0

    const v15, 0x7fffff

    and-int/2addr v0, v15

    shl-int/lit8 v0, v0, 0x2

    move-wide/from16 v21, v5

    int-to-long v5, v0

    const-wide/32 v23, 0x1000000

    add-long v25, v5, v23

    const/16 v0, 0x19

    shr-long v25, v25, v0

    const-wide/16 v27, 0x13

    mul-long v27, v27, v25

    add-long v1, v1, v27

    shl-long v25, v25, v0

    sub-long v5, v5, v25

    add-long v25, v16, v23

    shr-long v25, v25, v0

    add-long v7, v7, v25

    shl-long v25, v25, v0

    sub-long v15, v16, v25

    add-long v25, v9, v23

    shr-long v25, v25, v0

    add-long v11, v11, v25

    shl-long v25, v25, v0

    sub-long v9, v9, v25

    add-long v25, v13, v23

    shr-long v25, v25, v0

    add-long v3, v3, v25

    shl-long v25, v25, v0

    sub-long v13, v13, v25

    add-long v23, v18, v23

    shr-long v23, v23, v0

    add-long v21, v21, v23

    shl-long v23, v23, v0

    sub-long v17, v18, v23

    const-wide/32 v23, 0x2000000

    add-long v25, v1, v23

    const/16 v0, 0x1a

    shr-long v19, v25, v0

    move-wide/from16 v25, v5

    add-long v5, v15, v19

    shl-long v15, v19, v0

    sub-long/2addr v1, v15

    add-long v15, v7, v23

    shr-long/2addr v15, v0

    add-long/2addr v9, v15

    shl-long/2addr v15, v0

    sub-long/2addr v7, v15

    add-long v15, v11, v23

    shr-long/2addr v15, v0

    add-long/2addr v13, v15

    shl-long/2addr v15, v0

    sub-long/2addr v11, v15

    add-long v15, v3, v23

    shr-long/2addr v15, v0

    move-wide/from16 v19, v13

    add-long v13, v17, v15

    shl-long/2addr v15, v0

    sub-long/2addr v3, v15

    add-long v23, v21, v23

    shr-long v15, v23, v0

    move-wide/from16 v17, v13

    add-long v13, v25, v15

    shl-long/2addr v15, v0

    move-wide/from16 v23, v13

    sub-long v13, v21, v15

    long-to-int v0, v1

    long-to-int v1, v5

    long-to-int v2, v7

    long-to-int v5, v9

    long-to-int v6, v11

    move-wide/from16 v7, v19

    long-to-int v7, v7

    long-to-int v3, v3

    move-wide/from16 v8, v17

    long-to-int v4, v8

    long-to-int v8, v13

    move-wide/from16 v9, v23

    long-to-int v9, v9

    move/from16 v25, v0

    move/from16 v26, v1

    move/from16 v27, v2

    move/from16 v28, v5

    move/from16 v29, v6

    move/from16 v30, v7

    move/from16 v31, v3

    move/from16 v32, v4

    move/from16 v33, v8

    move/from16 v34, v9

    filled-new-array/range {v25 .. v34}, [I

    move-result-object v0

    new-instance v1, Lcafe/cryptography/curve25519/FieldElement;

    invoke-direct {v1, v0}, Lcafe/cryptography/curve25519/FieldElement;-><init>([I)V

    return-object v1
.end method

.method public static load_3([BI)I
    .locals 2

    add-int/lit8 v0, p1, 0x1

    aget-byte v1, p0, p1

    and-int/lit16 v1, v1, 0xff

    add-int/lit8 p1, p1, 0x2

    aget-byte v0, p0, v0

    and-int/lit16 v0, v0, 0xff

    shl-int/lit8 v0, v0, 0x8

    or-int/2addr v0, v1

    aget-byte p0, p0, p1

    and-int/lit16 p0, p0, 0xff

    shl-int/lit8 p0, p0, 0x10

    or-int/2addr p0, v0

    return p0
.end method

.method public static load_4([BI)J
    .locals 3

    add-int/lit8 v0, p1, 0x1

    aget-byte v1, p0, p1

    and-int/lit16 v1, v1, 0xff

    add-int/lit8 v2, p1, 0x2

    aget-byte v0, p0, v0

    and-int/lit16 v0, v0, 0xff

    shl-int/lit8 v0, v0, 0x8

    or-int/2addr v0, v1

    add-int/lit8 p1, p1, 0x3

    aget-byte v1, p0, v2

    and-int/lit16 v1, v1, 0xff

    shl-int/lit8 v1, v1, 0x10

    or-int/2addr v0, v1

    aget-byte p0, p0, p1

    shl-int/lit8 p0, p0, 0x18

    or-int/2addr p0, v0

    int-to-long p0, p0

    const-wide v0, 0xffffffffL

    and-long/2addr p0, v0

    return-wide p0
.end method

.method public static sqrtRatioM1(Lcafe/cryptography/curve25519/FieldElement;Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement$SqrtRatioM1Result;
    .locals 4

    invoke-virtual {p1}, Lcafe/cryptography/curve25519/FieldElement;->square()Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v0

    invoke-virtual {v0, p1}, Lcafe/cryptography/curve25519/FieldElement;->multiply(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v0

    invoke-virtual {v0}, Lcafe/cryptography/curve25519/FieldElement;->square()Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v1

    invoke-virtual {v1, p1}, Lcafe/cryptography/curve25519/FieldElement;->multiply(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v1

    invoke-virtual {p0, v0}, Lcafe/cryptography/curve25519/FieldElement;->multiply(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v0

    invoke-virtual {p0, v1}, Lcafe/cryptography/curve25519/FieldElement;->multiply(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v1

    invoke-virtual {v1}, Lcafe/cryptography/curve25519/FieldElement;->powP58()Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcafe/cryptography/curve25519/FieldElement;->multiply(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v0

    invoke-virtual {v0}, Lcafe/cryptography/curve25519/FieldElement;->square()Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v1

    invoke-virtual {p1, v1}, Lcafe/cryptography/curve25519/FieldElement;->multiply(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object p1

    invoke-virtual {p0}, Lcafe/cryptography/curve25519/FieldElement;->negate()Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v1

    invoke-virtual {p1, p0}, Lcafe/cryptography/curve25519/FieldElement;->ctEquals(Lcafe/cryptography/curve25519/FieldElement;)I

    move-result p0

    invoke-virtual {p1, v1}, Lcafe/cryptography/curve25519/FieldElement;->ctEquals(Lcafe/cryptography/curve25519/FieldElement;)I

    move-result v2

    sget-object v3, Lcafe/cryptography/curve25519/Constants;->SQRT_M1:Lcafe/cryptography/curve25519/FieldElement;

    invoke-virtual {v1, v3}, Lcafe/cryptography/curve25519/FieldElement;->multiply(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v1

    invoke-virtual {p1, v1}, Lcafe/cryptography/curve25519/FieldElement;->ctEquals(Lcafe/cryptography/curve25519/FieldElement;)I

    move-result p1

    invoke-virtual {v0, v3}, Lcafe/cryptography/curve25519/FieldElement;->multiply(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v1

    or-int/2addr p1, v2

    invoke-virtual {v0, v1, p1}, Lcafe/cryptography/curve25519/FieldElement;->ctSelect(Lcafe/cryptography/curve25519/FieldElement;I)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object p1

    invoke-virtual {p1}, Lcafe/cryptography/curve25519/FieldElement;->ctAbs()Lcafe/cryptography/curve25519/FieldElement;

    move-result-object p1

    new-instance v0, Lcafe/cryptography/curve25519/FieldElement$SqrtRatioM1Result;

    or-int/2addr p0, v2

    invoke-direct {v0, p0, p1}, Lcafe/cryptography/curve25519/FieldElement$SqrtRatioM1Result;-><init>(ILcafe/cryptography/curve25519/FieldElement;)V

    return-object v0
.end method


# virtual methods
.method public add(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;
    .locals 5

    iget-object p1, p1, Lcafe/cryptography/curve25519/FieldElement;->t:[I

    const/16 v0, 0xa

    new-array v1, v0, [I

    const/4 v2, 0x0

    :goto_0
    if-ge v2, v0, :cond_0

    iget-object v3, p0, Lcafe/cryptography/curve25519/FieldElement;->t:[I

    aget v3, v3, v2

    aget v4, p1, v2

    add-int/2addr v3, v4

    aput v3, v1, v2

    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_0
    new-instance p0, Lcafe/cryptography/curve25519/FieldElement;

    invoke-direct {p0, v1}, Lcafe/cryptography/curve25519/FieldElement;-><init>([I)V

    return-object p0
.end method

.method public ctAbs()Lcafe/cryptography/curve25519/FieldElement;
    .locals 2

    invoke-virtual {p0}, Lcafe/cryptography/curve25519/FieldElement;->negate()Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v0

    invoke-virtual {p0}, Lcafe/cryptography/curve25519/FieldElement;->isNegative()I

    move-result v1

    invoke-virtual {p0, v0, v1}, Lcafe/cryptography/curve25519/FieldElement;->ctSelect(Lcafe/cryptography/curve25519/FieldElement;I)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object p0

    return-object p0
.end method

.method public ctEquals(Lcafe/cryptography/curve25519/FieldElement;)I
    .locals 0

    invoke-virtual {p0}, Lcafe/cryptography/curve25519/FieldElement;->toByteArray()[B

    move-result-object p0

    invoke-virtual {p1}, Lcafe/cryptography/curve25519/FieldElement;->toByteArray()[B

    move-result-object p1

    invoke-static {p0, p1}, Lcafe/cryptography/subtle/ConstantTime;->equal([B[B)I

    move-result p0

    return p0
.end method

.method public ctSelect(Lcafe/cryptography/curve25519/FieldElement;I)Lcafe/cryptography/curve25519/FieldElement;
    .locals 6

    neg-int p2, p2

    const/16 v0, 0xa

    new-array v1, v0, [I

    const/4 v2, 0x0

    :goto_0
    if-ge v2, v0, :cond_0

    iget-object v3, p0, Lcafe/cryptography/curve25519/FieldElement;->t:[I

    aget v4, v3, v2

    aput v4, v1, v2

    aget v3, v3, v2

    iget-object v5, p1, Lcafe/cryptography/curve25519/FieldElement;->t:[I

    aget v5, v5, v2

    xor-int/2addr v3, v5

    and-int/2addr v3, p2

    xor-int/2addr v3, v4

    aput v3, v1, v2

    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_0
    new-instance p0, Lcafe/cryptography/curve25519/FieldElement;

    invoke-direct {p0, v1}, Lcafe/cryptography/curve25519/FieldElement;-><init>([I)V

    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 2

    instance-of v0, p1, Lcafe/cryptography/curve25519/FieldElement;

    const/4 v1, 0x0

    if-nez v0, :cond_0

    return v1

    :cond_0
    check-cast p1, Lcafe/cryptography/curve25519/FieldElement;

    invoke-virtual {p0, p1}, Lcafe/cryptography/curve25519/FieldElement;->ctEquals(Lcafe/cryptography/curve25519/FieldElement;)I

    move-result p0

    const/4 p1, 0x1

    if-ne p0, p1, :cond_1

    move v1, p1

    :cond_1
    return v1
.end method

.method public hashCode()I
    .locals 0

    invoke-virtual {p0}, Lcafe/cryptography/curve25519/FieldElement;->toByteArray()[B

    move-result-object p0

    invoke-static {p0}, Ljava/util/Arrays;->hashCode([B)I

    move-result p0

    return p0
.end method

.method public invert()Lcafe/cryptography/curve25519/FieldElement;
    .locals 8

    invoke-virtual {p0}, Lcafe/cryptography/curve25519/FieldElement;->square()Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v0

    invoke-virtual {v0}, Lcafe/cryptography/curve25519/FieldElement;->square()Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v1

    invoke-virtual {v1}, Lcafe/cryptography/curve25519/FieldElement;->square()Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v1

    invoke-virtual {p0, v1}, Lcafe/cryptography/curve25519/FieldElement;->multiply(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object p0

    invoke-virtual {v0, p0}, Lcafe/cryptography/curve25519/FieldElement;->multiply(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v0

    invoke-virtual {v0}, Lcafe/cryptography/curve25519/FieldElement;->square()Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v1

    invoke-virtual {p0, v1}, Lcafe/cryptography/curve25519/FieldElement;->multiply(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object p0

    invoke-virtual {p0}, Lcafe/cryptography/curve25519/FieldElement;->square()Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v1

    const/4 v2, 0x1

    move v3, v2

    :goto_0
    const/4 v4, 0x5

    if-ge v3, v4, :cond_0

    invoke-virtual {v1}, Lcafe/cryptography/curve25519/FieldElement;->square()Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v1

    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    :cond_0
    invoke-virtual {v1, p0}, Lcafe/cryptography/curve25519/FieldElement;->multiply(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object p0

    invoke-virtual {p0}, Lcafe/cryptography/curve25519/FieldElement;->square()Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v1

    move v3, v2

    :goto_1
    const/16 v5, 0xa

    if-ge v3, v5, :cond_1

    invoke-virtual {v1}, Lcafe/cryptography/curve25519/FieldElement;->square()Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v1

    add-int/lit8 v3, v3, 0x1

    goto :goto_1

    :cond_1
    invoke-virtual {v1, p0}, Lcafe/cryptography/curve25519/FieldElement;->multiply(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v1

    invoke-virtual {v1}, Lcafe/cryptography/curve25519/FieldElement;->square()Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v3

    move v6, v2

    :goto_2
    const/16 v7, 0x14

    if-ge v6, v7, :cond_2

    invoke-virtual {v3}, Lcafe/cryptography/curve25519/FieldElement;->square()Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v3

    add-int/lit8 v6, v6, 0x1

    goto :goto_2

    :cond_2
    invoke-virtual {v3, v1}, Lcafe/cryptography/curve25519/FieldElement;->multiply(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v1

    invoke-virtual {v1}, Lcafe/cryptography/curve25519/FieldElement;->square()Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v1

    move v3, v2

    :goto_3
    if-ge v3, v5, :cond_3

    invoke-virtual {v1}, Lcafe/cryptography/curve25519/FieldElement;->square()Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v1

    add-int/lit8 v3, v3, 0x1

    goto :goto_3

    :cond_3
    invoke-virtual {v1, p0}, Lcafe/cryptography/curve25519/FieldElement;->multiply(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object p0

    invoke-virtual {p0}, Lcafe/cryptography/curve25519/FieldElement;->square()Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v1

    move v3, v2

    :goto_4
    const/16 v5, 0x32

    if-ge v3, v5, :cond_4

    invoke-virtual {v1}, Lcafe/cryptography/curve25519/FieldElement;->square()Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v1

    add-int/lit8 v3, v3, 0x1

    goto :goto_4

    :cond_4
    invoke-virtual {v1, p0}, Lcafe/cryptography/curve25519/FieldElement;->multiply(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v1

    invoke-virtual {v1}, Lcafe/cryptography/curve25519/FieldElement;->square()Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v3

    move v6, v2

    :goto_5
    const/16 v7, 0x64

    if-ge v6, v7, :cond_5

    invoke-virtual {v3}, Lcafe/cryptography/curve25519/FieldElement;->square()Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v3

    add-int/lit8 v6, v6, 0x1

    goto :goto_5

    :cond_5
    invoke-virtual {v3, v1}, Lcafe/cryptography/curve25519/FieldElement;->multiply(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v1

    invoke-virtual {v1}, Lcafe/cryptography/curve25519/FieldElement;->square()Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v1

    move v3, v2

    :goto_6
    if-ge v3, v5, :cond_6

    invoke-virtual {v1}, Lcafe/cryptography/curve25519/FieldElement;->square()Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v1

    add-int/lit8 v3, v3, 0x1

    goto :goto_6

    :cond_6
    invoke-virtual {v1, p0}, Lcafe/cryptography/curve25519/FieldElement;->multiply(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object p0

    invoke-virtual {p0}, Lcafe/cryptography/curve25519/FieldElement;->square()Lcafe/cryptography/curve25519/FieldElement;

    move-result-object p0

    :goto_7
    if-ge v2, v4, :cond_7

    invoke-virtual {p0}, Lcafe/cryptography/curve25519/FieldElement;->square()Lcafe/cryptography/curve25519/FieldElement;

    move-result-object p0

    add-int/lit8 v2, v2, 0x1

    goto :goto_7

    :cond_7
    invoke-virtual {p0, v0}, Lcafe/cryptography/curve25519/FieldElement;->multiply(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object p0

    return-object p0
.end method

.method public isNegative()I
    .locals 1

    invoke-virtual {p0}, Lcafe/cryptography/curve25519/FieldElement;->toByteArray()[B

    move-result-object p0

    const/4 v0, 0x0

    aget-byte p0, p0, v0

    and-int/lit8 p0, p0, 0x1

    return p0
.end method

.method public isZero()I
    .locals 1

    invoke-virtual {p0}, Lcafe/cryptography/curve25519/FieldElement;->toByteArray()[B

    move-result-object p0

    sget-object v0, Lcafe/cryptography/curve25519/FieldElement;->ZERO_BYTES:[B

    invoke-static {p0, v0}, Lcafe/cryptography/subtle/ConstantTime;->equal([B[B)I

    move-result p0

    return p0
.end method

.method public multiply(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;
    .locals 209

    move-object/from16 v0, p1

    iget-object v0, v0, Lcafe/cryptography/curve25519/FieldElement;->t:[I

    const/4 v1, 0x1

    aget v2, v0, v1

    mul-int/lit8 v3, v2, 0x13

    const/4 v4, 0x2

    aget v5, v0, v4

    mul-int/lit8 v6, v5, 0x13

    const/4 v7, 0x3

    aget v8, v0, v7

    mul-int/lit8 v9, v8, 0x13

    const/4 v10, 0x4

    aget v11, v0, v10

    mul-int/lit8 v12, v11, 0x13

    const/4 v13, 0x5

    aget v14, v0, v13

    mul-int/lit8 v15, v14, 0x13

    const/16 v16, 0x6

    aget v10, v0, v16

    mul-int/lit8 v4, v10, 0x13

    const/16 v18, 0x7

    aget v13, v0, v18

    mul-int/lit8 v7, v13, 0x13

    const/16 v21, 0x8

    aget v1, v0, v21

    move/from16 v23, v3

    mul-int/lit8 v3, v1, 0x13

    const/16 v24, 0x9

    move/from16 v25, v6

    aget v6, v0, v24

    move/from16 v26, v9

    mul-int/lit8 v9, v6, 0x13

    move/from16 v27, v12

    move-object/from16 v12, p0

    iget-object v12, v12, Lcafe/cryptography/curve25519/FieldElement;->t:[I

    move/from16 v28, v15

    const/16 v22, 0x1

    aget v15, v12, v22

    move/from16 v22, v4

    mul-int/lit8 v4, v15, 0x2

    move/from16 v29, v7

    const/16 v20, 0x3

    aget v7, v12, v20

    move/from16 v20, v3

    mul-int/lit8 v3, v7, 0x2

    move/from16 p0, v3

    const/16 v19, 0x5

    aget v3, v12, v19

    move/from16 v19, v7

    mul-int/lit8 v7, v3, 0x2

    move/from16 v30, v7

    aget v7, v12, v18

    move/from16 v18, v3

    mul-int/lit8 v3, v7, 0x2

    move/from16 v31, v3

    aget v3, v12, v24

    move/from16 v24, v7

    mul-int/lit8 v7, v3, 0x2

    const/16 v32, 0x0

    move/from16 v33, v7

    aget v7, v12, v32

    move/from16 v35, v3

    move/from16 v34, v4

    int-to-long v3, v7

    aget v0, v0, v32

    move-object/from16 v36, v12

    move/from16 v32, v13

    int-to-long v12, v0

    mul-long/2addr v3, v12

    int-to-long v12, v7

    move-wide/from16 v37, v3

    int-to-long v3, v2

    mul-long/2addr v12, v3

    int-to-long v3, v7

    move-wide/from16 v39, v12

    int-to-long v12, v5

    mul-long/2addr v3, v12

    int-to-long v12, v7

    move-wide/from16 v41, v3

    int-to-long v3, v8

    mul-long/2addr v12, v3

    int-to-long v3, v7

    move-wide/from16 v43, v12

    int-to-long v12, v11

    mul-long/2addr v3, v12

    int-to-long v12, v7

    move-wide/from16 v45, v3

    int-to-long v3, v14

    mul-long/2addr v12, v3

    int-to-long v3, v7

    move-wide/from16 v47, v12

    int-to-long v12, v10

    mul-long/2addr v3, v12

    int-to-long v12, v7

    move-wide/from16 v49, v3

    move v4, v10

    move/from16 v3, v32

    move/from16 v32, v9

    int-to-long v9, v3

    mul-long/2addr v12, v9

    int-to-long v9, v7

    move-wide/from16 v51, v12

    int-to-long v12, v1

    mul-long/2addr v9, v12

    int-to-long v12, v7

    int-to-long v6, v6

    mul-long/2addr v12, v6

    int-to-long v6, v15

    move-wide/from16 v53, v12

    int-to-long v12, v0

    mul-long/2addr v6, v12

    move/from16 v12, v34

    int-to-long v12, v12

    move-wide/from16 v55, v9

    int-to-long v9, v2

    mul-long/2addr v9, v12

    move-wide/from16 v57, v9

    int-to-long v9, v15

    move-wide/from16 v59, v6

    int-to-long v6, v5

    mul-long/2addr v9, v6

    int-to-long v6, v8

    mul-long/2addr v6, v12

    move-wide/from16 v61, v6

    int-to-long v6, v15

    move-wide/from16 v63, v9

    int-to-long v9, v11

    mul-long/2addr v6, v9

    int-to-long v9, v14

    mul-long/2addr v9, v12

    move-wide/from16 v65, v9

    int-to-long v9, v15

    move-wide/from16 v67, v6

    int-to-long v6, v4

    mul-long/2addr v9, v6

    int-to-long v6, v3

    mul-long/2addr v6, v12

    move-wide/from16 v69, v6

    int-to-long v6, v15

    move-wide/from16 v71, v9

    int-to-long v9, v1

    mul-long/2addr v6, v9

    move/from16 v1, v32

    int-to-long v9, v1

    mul-long/2addr v12, v9

    const/4 v1, 0x2

    aget v1, v36, v1

    move-wide/from16 v73, v6

    int-to-long v6, v1

    move-wide/from16 v75, v12

    int-to-long v12, v0

    mul-long/2addr v6, v12

    int-to-long v12, v1

    move-wide/from16 v77, v6

    int-to-long v6, v2

    mul-long/2addr v12, v6

    int-to-long v6, v1

    move-wide/from16 v79, v12

    int-to-long v12, v5

    mul-long/2addr v6, v12

    int-to-long v12, v1

    move-wide/from16 v81, v6

    int-to-long v6, v8

    mul-long/2addr v12, v6

    int-to-long v6, v1

    move-wide/from16 v83, v12

    int-to-long v12, v11

    mul-long/2addr v6, v12

    int-to-long v12, v1

    move-wide/from16 v85, v6

    int-to-long v6, v14

    mul-long/2addr v12, v6

    int-to-long v6, v1

    move-wide/from16 v87, v12

    int-to-long v12, v4

    mul-long/2addr v6, v12

    int-to-long v12, v1

    move-wide/from16 v89, v6

    int-to-long v6, v3

    mul-long/2addr v12, v6

    int-to-long v6, v1

    move-wide/from16 v91, v12

    move/from16 v3, v20

    int-to-long v12, v3

    mul-long/2addr v6, v12

    move-wide/from16 v93, v6

    int-to-long v6, v1

    mul-long/2addr v6, v9

    move/from16 v1, v19

    move-wide/from16 v19, v6

    int-to-long v6, v1

    move-wide/from16 v95, v9

    int-to-long v9, v0

    mul-long/2addr v6, v9

    move/from16 v3, p0

    int-to-long v9, v3

    move-wide/from16 v97, v6

    int-to-long v6, v2

    mul-long/2addr v6, v9

    move-wide/from16 v99, v6

    int-to-long v6, v1

    move v15, v2

    int-to-long v2, v5

    mul-long/2addr v6, v2

    int-to-long v2, v8

    mul-long/2addr v2, v9

    move-wide/from16 v101, v2

    int-to-long v2, v1

    move-wide/from16 v103, v6

    int-to-long v6, v11

    mul-long/2addr v2, v6

    int-to-long v6, v14

    mul-long/2addr v6, v9

    move-wide/from16 v105, v6

    int-to-long v6, v1

    move-wide/from16 v107, v2

    int-to-long v2, v4

    mul-long/2addr v6, v2

    move/from16 v2, v29

    int-to-long v2, v2

    mul-long v109, v9, v2

    move-wide/from16 v111, v6

    int-to-long v6, v1

    mul-long/2addr v6, v12

    mul-long v9, v9, v95

    const/4 v1, 0x4

    aget v1, v36, v1

    move-wide/from16 p0, v9

    int-to-long v9, v1

    move-wide/from16 v113, v6

    int-to-long v6, v0

    mul-long/2addr v9, v6

    int-to-long v6, v1

    move-wide/from16 v115, v9

    move v4, v15

    int-to-long v9, v4

    mul-long/2addr v6, v9

    int-to-long v9, v1

    move-wide/from16 v117, v6

    int-to-long v6, v5

    mul-long/2addr v9, v6

    int-to-long v6, v1

    move-wide/from16 v119, v9

    int-to-long v9, v8

    mul-long/2addr v6, v9

    int-to-long v9, v1

    move-wide/from16 v121, v6

    int-to-long v6, v11

    mul-long/2addr v9, v6

    int-to-long v6, v1

    int-to-long v14, v14

    mul-long/2addr v6, v14

    int-to-long v14, v1

    move-wide/from16 v123, v6

    move/from16 v6, v22

    int-to-long v6, v6

    mul-long/2addr v14, v6

    move-wide/from16 v125, v9

    int-to-long v9, v1

    mul-long/2addr v9, v2

    move-wide/from16 v127, v9

    int-to-long v9, v1

    mul-long/2addr v9, v12

    move-wide/from16 v129, v9

    int-to-long v9, v1

    mul-long v9, v9, v95

    move/from16 v1, v18

    move-wide/from16 v17, v9

    int-to-long v9, v1

    move-wide/from16 v131, v14

    int-to-long v14, v0

    mul-long/2addr v9, v14

    move/from16 v14, v30

    int-to-long v14, v14

    move-wide/from16 v29, v9

    int-to-long v9, v4

    mul-long/2addr v9, v14

    move-wide/from16 v133, v9

    int-to-long v9, v1

    move-wide/from16 v135, v12

    int-to-long v12, v5

    mul-long/2addr v9, v12

    int-to-long v12, v8

    mul-long/2addr v12, v14

    move-wide/from16 v137, v12

    int-to-long v12, v1

    move-wide/from16 v139, v9

    int-to-long v9, v11

    mul-long/2addr v12, v9

    move/from16 v9, v28

    int-to-long v9, v9

    mul-long v141, v14, v9

    move-wide/from16 v143, v12

    int-to-long v11, v1

    mul-long/2addr v11, v6

    mul-long v145, v14, v2

    move-wide/from16 v147, v11

    int-to-long v11, v1

    mul-long v11, v11, v135

    mul-long v14, v14, v95

    aget v1, v36, v16

    move-wide/from16 v149, v14

    int-to-long v13, v1

    move-wide v15, v11

    int-to-long v11, v0

    mul-long/2addr v13, v11

    int-to-long v11, v1

    move-wide/from16 v151, v13

    int-to-long v13, v4

    mul-long/2addr v11, v13

    int-to-long v13, v1

    move-wide/from16 v153, v11

    int-to-long v11, v5

    mul-long/2addr v13, v11

    int-to-long v11, v1

    move-wide/from16 v155, v13

    int-to-long v13, v8

    mul-long/2addr v11, v13

    int-to-long v13, v1

    move/from16 v8, v27

    move-wide/from16 v27, v11

    int-to-long v11, v8

    mul-long/2addr v13, v11

    move-wide/from16 v157, v13

    int-to-long v13, v1

    mul-long/2addr v13, v9

    move-wide/from16 v159, v13

    int-to-long v13, v1

    mul-long/2addr v13, v6

    move-wide/from16 v161, v13

    int-to-long v13, v1

    mul-long/2addr v13, v2

    move-wide/from16 v163, v13

    int-to-long v13, v1

    mul-long v13, v13, v135

    move-wide/from16 v165, v13

    int-to-long v13, v1

    mul-long v13, v13, v95

    move-wide/from16 v167, v13

    move/from16 v1, v24

    int-to-long v13, v1

    move-wide/from16 v169, v2

    int-to-long v2, v0

    mul-long/2addr v13, v2

    move/from16 v2, v31

    int-to-long v2, v2

    move-wide/from16 v31, v13

    int-to-long v13, v4

    mul-long/2addr v13, v2

    move-wide/from16 v171, v13

    int-to-long v13, v1

    move v8, v4

    int-to-long v4, v5

    mul-long/2addr v13, v4

    move/from16 v4, v26

    int-to-long v4, v4

    mul-long v173, v2, v4

    move-wide/from16 v175, v13

    int-to-long v13, v1

    mul-long/2addr v13, v11

    mul-long v177, v2, v9

    move-wide/from16 v179, v13

    int-to-long v13, v1

    mul-long/2addr v13, v6

    mul-long v181, v2, v169

    move-wide/from16 v183, v13

    int-to-long v13, v1

    mul-long v13, v13, v135

    mul-long v2, v2, v95

    aget v1, v36, v21

    move-wide/from16 v21, v2

    int-to-long v2, v1

    move-wide/from16 v185, v13

    int-to-long v13, v0

    mul-long/2addr v2, v13

    int-to-long v13, v1

    move-wide/from16 v187, v2

    int-to-long v2, v8

    mul-long/2addr v13, v2

    int-to-long v2, v1

    move/from16 v8, v25

    move-wide/from16 v24, v13

    int-to-long v13, v8

    mul-long/2addr v2, v13

    move-wide/from16 v189, v2

    int-to-long v2, v1

    mul-long/2addr v2, v4

    move-wide/from16 v191, v2

    int-to-long v2, v1

    mul-long/2addr v2, v11

    move-wide/from16 v193, v2

    int-to-long v2, v1

    mul-long/2addr v2, v9

    move-wide/from16 v195, v2

    int-to-long v2, v1

    mul-long/2addr v2, v6

    move-wide/from16 v197, v2

    int-to-long v2, v1

    mul-long v2, v2, v169

    move-wide/from16 v199, v2

    int-to-long v2, v1

    mul-long v2, v2, v135

    move-wide/from16 v201, v2

    int-to-long v1, v1

    mul-long v1, v1, v95

    move/from16 v3, v35

    move-wide/from16 v34, v1

    int-to-long v1, v3

    move-wide/from16 v203, v6

    int-to-long v6, v0

    mul-long/2addr v1, v6

    move/from16 v0, v33

    int-to-long v6, v0

    move-wide/from16 v205, v1

    move/from16 v0, v23

    int-to-long v0, v0

    mul-long/2addr v0, v6

    move-wide/from16 v207, v0

    int-to-long v0, v3

    mul-long/2addr v0, v13

    mul-long/2addr v4, v6

    int-to-long v13, v3

    mul-long/2addr v13, v11

    mul-long/2addr v9, v6

    int-to-long v11, v3

    mul-long v11, v11, v203

    mul-long v169, v169, v6

    int-to-long v2, v3

    mul-long v2, v2, v135

    mul-long v6, v6, v95

    add-long v36, v37, v75

    add-long v36, v36, v93

    add-long v36, v36, v109

    add-long v36, v36, v131

    add-long v36, v36, v141

    add-long v36, v36, v157

    add-long v36, v36, v173

    add-long v36, v36, v189

    add-long v36, v36, v207

    add-long v38, v39, v59

    add-long v38, v38, v19

    add-long v38, v38, v113

    add-long v38, v38, v127

    add-long v38, v38, v147

    add-long v38, v38, v159

    add-long v38, v38, v179

    add-long v38, v38, v191

    add-long v38, v38, v0

    add-long v0, v41, v57

    add-long v0, v0, v77

    move-wide/from16 v19, p0

    add-long v0, v0, v19

    add-long v0, v0, v129

    add-long v0, v0, v145

    add-long v0, v0, v161

    add-long v0, v0, v177

    add-long v0, v0, v193

    add-long/2addr v0, v4

    add-long v4, v43, v63

    add-long v4, v4, v79

    add-long v4, v4, v97

    add-long v4, v4, v17

    add-long/2addr v4, v15

    add-long v4, v4, v163

    add-long v4, v4, v183

    add-long v4, v4, v195

    add-long/2addr v4, v13

    add-long v13, v45, v61

    add-long v13, v13, v81

    add-long v13, v13, v99

    add-long v13, v13, v115

    add-long v13, v13, v149

    add-long v13, v13, v165

    add-long v13, v13, v181

    add-long v13, v13, v197

    add-long/2addr v13, v9

    add-long v8, v47, v67

    add-long v8, v8, v83

    add-long v8, v8, v103

    add-long v8, v8, v117

    add-long v8, v8, v29

    add-long v8, v8, v167

    add-long v8, v8, v185

    add-long v8, v8, v199

    add-long/2addr v8, v11

    add-long v10, v49, v65

    add-long v10, v10, v85

    add-long v10, v10, v101

    add-long v10, v10, v119

    add-long v10, v10, v133

    add-long v10, v10, v151

    add-long v10, v10, v21

    add-long v10, v10, v201

    add-long v10, v10, v169

    add-long v15, v51, v71

    add-long v15, v15, v87

    add-long v15, v15, v107

    add-long v15, v15, v121

    add-long v15, v15, v139

    add-long v15, v15, v153

    add-long v15, v15, v31

    add-long v15, v15, v34

    add-long/2addr v15, v2

    add-long v2, v55, v69

    add-long v2, v2, v89

    add-long v2, v2, v105

    add-long v2, v2, v125

    add-long v2, v2, v137

    add-long v2, v2, v155

    add-long v2, v2, v171

    add-long v2, v2, v187

    add-long/2addr v2, v6

    add-long v6, v53, v73

    add-long v6, v6, v91

    add-long v6, v6, v111

    add-long v6, v6, v123

    add-long v6, v6, v143

    add-long v6, v6, v27

    add-long v6, v6, v175

    add-long v6, v6, v24

    add-long v6, v6, v205

    const-wide/32 v17, 0x2000000

    add-long v19, v36, v17

    const/16 v12, 0x1a

    shr-long v19, v19, v12

    add-long v38, v38, v19

    shl-long v19, v19, v12

    sub-long v36, v36, v19

    add-long v19, v13, v17

    shr-long v19, v19, v12

    add-long v8, v8, v19

    shl-long v19, v19, v12

    sub-long v13, v13, v19

    const-wide/32 v19, 0x1000000

    add-long v21, v38, v19

    const/16 v23, 0x19

    shr-long v21, v21, v23

    add-long v0, v0, v21

    shl-long v21, v21, v23

    sub-long v38, v38, v21

    add-long v21, v8, v19

    shr-long v21, v21, v23

    add-long v10, v10, v21

    shl-long v21, v21, v23

    sub-long v8, v8, v21

    add-long v21, v0, v17

    shr-long v21, v21, v12

    add-long v4, v4, v21

    shl-long v21, v21, v12

    sub-long v0, v0, v21

    add-long v21, v10, v17

    shr-long v21, v21, v12

    add-long v15, v15, v21

    shl-long v21, v21, v12

    sub-long v10, v10, v21

    add-long v21, v4, v19

    shr-long v21, v21, v23

    add-long v13, v13, v21

    shl-long v21, v21, v23

    sub-long v4, v4, v21

    add-long v21, v15, v19

    shr-long v21, v21, v23

    add-long v2, v2, v21

    shl-long v21, v21, v23

    move-wide/from16 p0, v10

    sub-long v10, v15, v21

    add-long v15, v13, v17

    shr-long/2addr v15, v12

    add-long/2addr v8, v15

    shl-long/2addr v15, v12

    sub-long/2addr v13, v15

    add-long v15, v2, v17

    shr-long/2addr v15, v12

    add-long/2addr v6, v15

    shl-long/2addr v15, v12

    sub-long/2addr v2, v15

    add-long v19, v6, v19

    shr-long v15, v19, v23

    const-wide/16 v19, 0x13

    mul-long v19, v19, v15

    add-long v36, v36, v19

    shl-long v15, v15, v23

    sub-long/2addr v6, v15

    add-long v17, v36, v17

    shr-long v15, v17, v12

    move-wide/from16 v17, v6

    add-long v6, v38, v15

    shl-long/2addr v15, v12

    move-wide/from16 v19, v2

    sub-long v2, v36, v15

    long-to-int v2, v2

    long-to-int v3, v6

    long-to-int v0, v0

    long-to-int v1, v4

    long-to-int v4, v13

    long-to-int v5, v8

    move-wide/from16 v6, p0

    long-to-int v6, v6

    long-to-int v7, v10

    move-wide/from16 v8, v19

    long-to-int v8, v8

    move-wide/from16 v9, v17

    long-to-int v9, v9

    move/from16 v21, v2

    move/from16 v22, v3

    move/from16 v23, v0

    move/from16 v24, v1

    move/from16 v25, v4

    move/from16 v26, v5

    move/from16 v27, v6

    move/from16 v28, v7

    move/from16 v29, v8

    move/from16 v30, v9

    filled-new-array/range {v21 .. v30}, [I

    move-result-object v0

    new-instance v1, Lcafe/cryptography/curve25519/FieldElement;

    invoke-direct {v1, v0}, Lcafe/cryptography/curve25519/FieldElement;-><init>([I)V

    return-object v1
.end method

.method public negate()Lcafe/cryptography/curve25519/FieldElement;
    .locals 4

    const/16 v0, 0xa

    new-array v1, v0, [I

    const/4 v2, 0x0

    :goto_0
    if-ge v2, v0, :cond_0

    iget-object v3, p0, Lcafe/cryptography/curve25519/FieldElement;->t:[I

    aget v3, v3, v2

    neg-int v3, v3

    aput v3, v1, v2

    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_0
    new-instance p0, Lcafe/cryptography/curve25519/FieldElement;

    invoke-direct {p0, v1}, Lcafe/cryptography/curve25519/FieldElement;-><init>([I)V

    return-object p0
.end method

.method public powP58()Lcafe/cryptography/curve25519/FieldElement;
    .locals 7

    invoke-virtual {p0}, Lcafe/cryptography/curve25519/FieldElement;->square()Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v0

    invoke-virtual {v0}, Lcafe/cryptography/curve25519/FieldElement;->square()Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v1

    invoke-virtual {v1}, Lcafe/cryptography/curve25519/FieldElement;->square()Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v1

    invoke-virtual {p0, v1}, Lcafe/cryptography/curve25519/FieldElement;->multiply(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcafe/cryptography/curve25519/FieldElement;->multiply(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v0

    invoke-virtual {v0}, Lcafe/cryptography/curve25519/FieldElement;->square()Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v0

    invoke-virtual {v1, v0}, Lcafe/cryptography/curve25519/FieldElement;->multiply(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v0

    invoke-virtual {v0}, Lcafe/cryptography/curve25519/FieldElement;->square()Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v1

    const/4 v2, 0x1

    move v3, v2

    :goto_0
    const/4 v4, 0x5

    if-ge v3, v4, :cond_0

    invoke-virtual {v1}, Lcafe/cryptography/curve25519/FieldElement;->square()Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v1

    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    :cond_0
    invoke-virtual {v1, v0}, Lcafe/cryptography/curve25519/FieldElement;->multiply(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v0

    invoke-virtual {v0}, Lcafe/cryptography/curve25519/FieldElement;->square()Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v1

    move v3, v2

    :goto_1
    const/16 v4, 0xa

    if-ge v3, v4, :cond_1

    invoke-virtual {v1}, Lcafe/cryptography/curve25519/FieldElement;->square()Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v1

    add-int/lit8 v3, v3, 0x1

    goto :goto_1

    :cond_1
    invoke-virtual {v1, v0}, Lcafe/cryptography/curve25519/FieldElement;->multiply(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v1

    invoke-virtual {v1}, Lcafe/cryptography/curve25519/FieldElement;->square()Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v3

    move v5, v2

    :goto_2
    const/16 v6, 0x14

    if-ge v5, v6, :cond_2

    invoke-virtual {v3}, Lcafe/cryptography/curve25519/FieldElement;->square()Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v3

    add-int/lit8 v5, v5, 0x1

    goto :goto_2

    :cond_2
    invoke-virtual {v3, v1}, Lcafe/cryptography/curve25519/FieldElement;->multiply(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v1

    invoke-virtual {v1}, Lcafe/cryptography/curve25519/FieldElement;->square()Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v1

    move v3, v2

    :goto_3
    if-ge v3, v4, :cond_3

    invoke-virtual {v1}, Lcafe/cryptography/curve25519/FieldElement;->square()Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v1

    add-int/lit8 v3, v3, 0x1

    goto :goto_3

    :cond_3
    invoke-virtual {v1, v0}, Lcafe/cryptography/curve25519/FieldElement;->multiply(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v0

    invoke-virtual {v0}, Lcafe/cryptography/curve25519/FieldElement;->square()Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v1

    move v3, v2

    :goto_4
    const/16 v4, 0x32

    if-ge v3, v4, :cond_4

    invoke-virtual {v1}, Lcafe/cryptography/curve25519/FieldElement;->square()Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v1

    add-int/lit8 v3, v3, 0x1

    goto :goto_4

    :cond_4
    invoke-virtual {v1, v0}, Lcafe/cryptography/curve25519/FieldElement;->multiply(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v1

    invoke-virtual {v1}, Lcafe/cryptography/curve25519/FieldElement;->square()Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v3

    move v5, v2

    :goto_5
    const/16 v6, 0x64

    if-ge v5, v6, :cond_5

    invoke-virtual {v3}, Lcafe/cryptography/curve25519/FieldElement;->square()Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v3

    add-int/lit8 v5, v5, 0x1

    goto :goto_5

    :cond_5
    invoke-virtual {v3, v1}, Lcafe/cryptography/curve25519/FieldElement;->multiply(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v1

    invoke-virtual {v1}, Lcafe/cryptography/curve25519/FieldElement;->square()Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v1

    :goto_6
    if-ge v2, v4, :cond_6

    invoke-virtual {v1}, Lcafe/cryptography/curve25519/FieldElement;->square()Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v1

    add-int/lit8 v2, v2, 0x1

    goto :goto_6

    :cond_6
    invoke-virtual {v1, v0}, Lcafe/cryptography/curve25519/FieldElement;->multiply(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v0

    invoke-virtual {v0}, Lcafe/cryptography/curve25519/FieldElement;->square()Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v0

    invoke-virtual {v0}, Lcafe/cryptography/curve25519/FieldElement;->square()Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v0

    invoke-virtual {p0, v0}, Lcafe/cryptography/curve25519/FieldElement;->multiply(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object p0

    return-object p0
.end method

.method public printInternalRepresentation()Ljava/lang/String;
    .locals 3

    const-string v0, "FieldElement(["

    const/4 v1, 0x0

    :goto_0
    iget-object v2, p0, Lcafe/cryptography/curve25519/FieldElement;->t:[I

    array-length v2, v2

    if-ge v1, v2, :cond_1

    if-lez v1, :cond_0

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, ", "

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    :cond_0
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v0, p0, Lcafe/cryptography/curve25519/FieldElement;->t:[I

    aget v0, v0, v1

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_1
    new-instance p0, Ljava/lang/StringBuilder;

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, "])"

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public square()Lcafe/cryptography/curve25519/FieldElement;
    .locals 115

    move-object/from16 v0, p0

    iget-object v0, v0, Lcafe/cryptography/curve25519/FieldElement;->t:[I

    const/4 v1, 0x0

    aget v1, v0, v1

    const/4 v2, 0x1

    aget v2, v0, v2

    const/4 v3, 0x2

    aget v3, v0, v3

    const/4 v4, 0x3

    aget v4, v0, v4

    const/4 v5, 0x4

    aget v5, v0, v5

    const/4 v6, 0x5

    aget v6, v0, v6

    const/4 v7, 0x6

    aget v7, v0, v7

    const/4 v8, 0x7

    aget v8, v0, v8

    const/16 v9, 0x8

    aget v9, v0, v9

    const/16 v10, 0x9

    aget v0, v0, v10

    mul-int/lit8 v10, v1, 0x2

    mul-int/lit8 v11, v2, 0x2

    mul-int/lit8 v12, v3, 0x2

    mul-int/lit8 v13, v4, 0x2

    mul-int/lit8 v14, v5, 0x2

    mul-int/lit8 v15, v6, 0x2

    move/from16 p0, v14

    mul-int/lit8 v14, v7, 0x2

    move/from16 v16, v14

    mul-int/lit8 v14, v8, 0x2

    move/from16 v17, v12

    mul-int/lit8 v12, v6, 0x26

    move/from16 v18, v12

    mul-int/lit8 v12, v7, 0x13

    move/from16 v19, v12

    mul-int/lit8 v12, v8, 0x26

    move/from16 v20, v12

    mul-int/lit8 v12, v9, 0x13

    move/from16 v21, v12

    mul-int/lit8 v12, v0, 0x26

    move/from16 v23, v14

    move/from16 v22, v15

    int-to-long v14, v1

    mul-long/2addr v14, v14

    move-wide/from16 v24, v14

    int-to-long v14, v10

    int-to-long v1, v2

    mul-long v26, v14, v1

    move/from16 v28, v12

    move v10, v13

    int-to-long v12, v3

    mul-long v29, v14, v12

    int-to-long v3, v4

    mul-long v31, v14, v3

    move-wide/from16 v33, v3

    int-to-long v3, v5

    mul-long v35, v14, v3

    int-to-long v5, v6

    mul-long v37, v14, v5

    move-wide/from16 v39, v5

    int-to-long v5, v7

    mul-long v41, v14, v5

    int-to-long v7, v8

    mul-long v43, v14, v7

    move-wide/from16 v45, v7

    int-to-long v7, v9

    mul-long v47, v14, v7

    move-wide/from16 v49, v7

    int-to-long v7, v0

    mul-long/2addr v14, v7

    move-wide/from16 v51, v14

    int-to-long v14, v11

    mul-long/2addr v1, v14

    mul-long v53, v14, v12

    int-to-long v9, v10

    mul-long v55, v14, v9

    mul-long v57, v14, v3

    move-wide/from16 v59, v1

    move/from16 v0, v22

    int-to-long v0, v0

    mul-long v61, v14, v0

    mul-long v63, v14, v5

    move/from16 v2, v23

    move-wide/from16 v22, v7

    int-to-long v7, v2

    mul-long v65, v14, v7

    mul-long v67, v14, v49

    move-wide/from16 v69, v7

    move/from16 v2, v28

    int-to-long v7, v2

    mul-long/2addr v14, v7

    mul-long v71, v12, v12

    move-wide/from16 v73, v14

    move/from16 v2, v17

    int-to-long v14, v2

    mul-long v75, v14, v33

    mul-long v77, v14, v3

    mul-long v79, v14, v39

    mul-long v81, v14, v5

    mul-long v83, v14, v45

    move-wide/from16 v85, v5

    move/from16 v2, v21

    int-to-long v5, v2

    mul-long/2addr v14, v5

    mul-long/2addr v12, v7

    mul-long v33, v33, v9

    mul-long v87, v9, v3

    mul-long v89, v9, v0

    mul-long v91, v9, v85

    move/from16 v2, v20

    move-wide/from16 v20, v12

    int-to-long v11, v2

    mul-long v93, v9, v11

    mul-long v95, v9, v5

    mul-long/2addr v9, v7

    mul-long v97, v3, v3

    move/from16 v2, p0

    move-wide/from16 v99, v9

    int-to-long v9, v2

    mul-long v101, v9, v39

    move-wide/from16 v103, v14

    move/from16 v2, v19

    int-to-long v13, v2

    mul-long v105, v9, v13

    mul-long v107, v3, v11

    mul-long/2addr v9, v5

    mul-long/2addr v3, v7

    move/from16 v2, v18

    move-wide/from16 v17, v3

    int-to-long v2, v2

    mul-long v2, v2, v39

    mul-long v39, v0, v13

    mul-long v109, v0, v11

    mul-long v111, v0, v5

    mul-long/2addr v0, v7

    mul-long v13, v13, v85

    mul-long v113, v85, v11

    move/from16 v4, v16

    move-wide v15, v0

    int-to-long v0, v4

    mul-long/2addr v0, v5

    mul-long v85, v85, v7

    mul-long v11, v11, v45

    mul-long v45, v69, v5

    mul-long v69, v69, v7

    mul-long v4, v49, v5

    mul-long v49, v49, v7

    mul-long v7, v7, v22

    add-long v22, v24, v73

    add-long v22, v22, v103

    add-long v22, v22, v93

    add-long v22, v22, v105

    add-long v22, v22, v2

    add-long v26, v26, v20

    add-long v26, v26, v95

    add-long v26, v26, v107

    add-long v26, v26, v39

    add-long v29, v29, v59

    add-long v29, v29, v99

    add-long v29, v29, v9

    add-long v29, v29, v109

    add-long v29, v29, v13

    add-long v31, v31, v53

    add-long v31, v31, v17

    add-long v31, v31, v111

    add-long v31, v31, v113

    add-long v35, v35, v55

    add-long v35, v35, v71

    add-long v35, v35, v15

    add-long v35, v35, v0

    add-long v35, v35, v11

    add-long v37, v37, v57

    add-long v37, v37, v75

    add-long v37, v37, v85

    add-long v37, v37, v45

    add-long v41, v41, v61

    add-long v41, v41, v77

    add-long v41, v41, v33

    add-long v41, v41, v69

    add-long v41, v41, v4

    add-long v43, v43, v63

    add-long v43, v43, v79

    add-long v43, v43, v87

    add-long v43, v43, v49

    add-long v47, v47, v65

    add-long v47, v47, v81

    add-long v47, v47, v89

    add-long v47, v47, v97

    add-long v47, v47, v7

    add-long v14, v51, v67

    add-long v14, v14, v83

    add-long v14, v14, v91

    add-long v14, v14, v101

    const-wide/32 v0, 0x2000000

    add-long v2, v22, v0

    const/16 v4, 0x1a

    shr-long/2addr v2, v4

    add-long v26, v26, v2

    shl-long/2addr v2, v4

    sub-long v22, v22, v2

    add-long v2, v35, v0

    shr-long/2addr v2, v4

    add-long v37, v37, v2

    shl-long/2addr v2, v4

    sub-long v35, v35, v2

    const-wide/32 v2, 0x1000000

    add-long v5, v26, v2

    const/16 v7, 0x19

    shr-long/2addr v5, v7

    add-long v29, v29, v5

    shl-long/2addr v5, v7

    sub-long v26, v26, v5

    add-long v5, v37, v2

    shr-long/2addr v5, v7

    add-long v41, v41, v5

    shl-long/2addr v5, v7

    sub-long v37, v37, v5

    add-long v5, v29, v0

    shr-long/2addr v5, v4

    add-long v31, v31, v5

    shl-long/2addr v5, v4

    sub-long v5, v29, v5

    add-long v8, v41, v0

    shr-long/2addr v8, v4

    add-long v43, v43, v8

    shl-long/2addr v8, v4

    sub-long v8, v41, v8

    add-long v10, v31, v2

    shr-long/2addr v10, v7

    add-long v35, v35, v10

    shl-long/2addr v10, v7

    sub-long v10, v31, v10

    add-long v12, v43, v2

    shr-long/2addr v12, v7

    add-long v47, v47, v12

    shl-long/2addr v12, v7

    sub-long v12, v43, v12

    add-long v16, v35, v0

    shr-long v16, v16, v4

    move-wide/from16 v18, v8

    add-long v7, v37, v16

    shl-long v16, v16, v4

    sub-long v2, v35, v16

    add-long v16, v47, v0

    shr-long v16, v16, v4

    add-long v14, v14, v16

    shl-long v16, v16, v4

    move-wide/from16 v24, v5

    sub-long v4, v47, v16

    const-wide/32 v16, 0x1000000

    add-long v16, v14, v16

    const/16 v6, 0x19

    shr-long v16, v16, v6

    const-wide/16 v20, 0x13

    mul-long v20, v20, v16

    add-long v22, v22, v20

    shl-long v16, v16, v6

    sub-long v14, v14, v16

    add-long v0, v22, v0

    const/16 v6, 0x1a

    shr-long/2addr v0, v6

    move-wide/from16 v16, v14

    add-long v14, v26, v0

    shl-long/2addr v0, v6

    sub-long v0, v22, v0

    long-to-int v0, v0

    long-to-int v1, v14

    move-wide/from16 v14, v24

    long-to-int v6, v14

    long-to-int v9, v10

    long-to-int v2, v2

    long-to-int v3, v7

    move-wide/from16 v7, v18

    long-to-int v7, v7

    long-to-int v8, v12

    long-to-int v4, v4

    move-wide/from16 v14, v16

    long-to-int v5, v14

    move/from16 v26, v0

    move/from16 v27, v1

    move/from16 v28, v6

    move/from16 v29, v9

    move/from16 v30, v2

    move/from16 v31, v3

    move/from16 v32, v7

    move/from16 v33, v8

    move/from16 v34, v4

    move/from16 v35, v5

    filled-new-array/range {v26 .. v35}, [I

    move-result-object v0

    new-instance v1, Lcafe/cryptography/curve25519/FieldElement;

    invoke-direct {v1, v0}, Lcafe/cryptography/curve25519/FieldElement;-><init>([I)V

    return-object v1
.end method

.method public squareAndDouble()Lcafe/cryptography/curve25519/FieldElement;
    .locals 115

    move-object/from16 v0, p0

    iget-object v0, v0, Lcafe/cryptography/curve25519/FieldElement;->t:[I

    const/4 v1, 0x0

    aget v1, v0, v1

    const/4 v2, 0x1

    aget v2, v0, v2

    const/4 v3, 0x2

    aget v3, v0, v3

    const/4 v4, 0x3

    aget v4, v0, v4

    const/4 v5, 0x4

    aget v5, v0, v5

    const/4 v6, 0x5

    aget v6, v0, v6

    const/4 v7, 0x6

    aget v7, v0, v7

    const/4 v8, 0x7

    aget v8, v0, v8

    const/16 v9, 0x8

    aget v9, v0, v9

    const/16 v10, 0x9

    aget v0, v0, v10

    mul-int/lit8 v10, v1, 0x2

    mul-int/lit8 v11, v2, 0x2

    mul-int/lit8 v12, v3, 0x2

    mul-int/lit8 v13, v4, 0x2

    mul-int/lit8 v14, v5, 0x2

    mul-int/lit8 v15, v6, 0x2

    move/from16 p0, v14

    mul-int/lit8 v14, v7, 0x2

    move/from16 v16, v14

    mul-int/lit8 v14, v8, 0x2

    move/from16 v17, v12

    mul-int/lit8 v12, v6, 0x26

    move/from16 v18, v12

    mul-int/lit8 v12, v7, 0x13

    move/from16 v19, v12

    mul-int/lit8 v12, v8, 0x26

    move/from16 v20, v12

    mul-int/lit8 v12, v9, 0x13

    move/from16 v21, v12

    mul-int/lit8 v12, v0, 0x26

    move/from16 v23, v14

    move/from16 v22, v15

    int-to-long v14, v1

    mul-long/2addr v14, v14

    move-wide/from16 v24, v14

    int-to-long v14, v10

    int-to-long v1, v2

    mul-long v26, v14, v1

    move/from16 v28, v12

    move v10, v13

    int-to-long v12, v3

    mul-long v29, v14, v12

    int-to-long v3, v4

    mul-long v31, v14, v3

    move-wide/from16 v33, v3

    int-to-long v3, v5

    mul-long v35, v14, v3

    int-to-long v5, v6

    mul-long v37, v14, v5

    move-wide/from16 v39, v5

    int-to-long v5, v7

    mul-long v41, v14, v5

    int-to-long v7, v8

    mul-long v43, v14, v7

    move-wide/from16 v45, v7

    int-to-long v7, v9

    mul-long v47, v14, v7

    move-wide/from16 v49, v7

    int-to-long v7, v0

    mul-long/2addr v14, v7

    move-wide/from16 v51, v14

    int-to-long v14, v11

    mul-long/2addr v1, v14

    mul-long v53, v14, v12

    int-to-long v9, v10

    mul-long v55, v14, v9

    mul-long v57, v14, v3

    move-wide/from16 v59, v1

    move/from16 v0, v22

    int-to-long v0, v0

    mul-long v61, v14, v0

    mul-long v63, v14, v5

    move/from16 v2, v23

    move-wide/from16 v22, v7

    int-to-long v7, v2

    mul-long v65, v14, v7

    mul-long v67, v14, v49

    move-wide/from16 v69, v7

    move/from16 v2, v28

    int-to-long v7, v2

    mul-long/2addr v14, v7

    mul-long v71, v12, v12

    move-wide/from16 v73, v14

    move/from16 v2, v17

    int-to-long v14, v2

    mul-long v75, v14, v33

    mul-long v77, v14, v3

    mul-long v79, v14, v39

    mul-long v81, v14, v5

    mul-long v83, v14, v45

    move-wide/from16 v85, v5

    move/from16 v2, v21

    int-to-long v5, v2

    mul-long/2addr v14, v5

    mul-long/2addr v12, v7

    mul-long v33, v33, v9

    mul-long v87, v9, v3

    mul-long v89, v9, v0

    mul-long v91, v9, v85

    move/from16 v2, v20

    move-wide/from16 v20, v12

    int-to-long v11, v2

    mul-long v93, v9, v11

    mul-long v95, v9, v5

    mul-long/2addr v9, v7

    mul-long v97, v3, v3

    move/from16 v2, p0

    move-wide/from16 v99, v9

    int-to-long v9, v2

    mul-long v101, v9, v39

    move-wide/from16 v103, v14

    move/from16 v2, v19

    int-to-long v13, v2

    mul-long v105, v9, v13

    mul-long v107, v3, v11

    mul-long/2addr v9, v5

    mul-long/2addr v3, v7

    move/from16 v2, v18

    move-wide/from16 v17, v3

    int-to-long v2, v2

    mul-long v2, v2, v39

    mul-long v39, v0, v13

    mul-long v109, v0, v11

    mul-long v111, v0, v5

    mul-long/2addr v0, v7

    mul-long v13, v13, v85

    mul-long v113, v85, v11

    move/from16 v4, v16

    move-wide v15, v0

    int-to-long v0, v4

    mul-long/2addr v0, v5

    mul-long v85, v85, v7

    mul-long v11, v11, v45

    mul-long v45, v69, v5

    mul-long v69, v69, v7

    mul-long v4, v49, v5

    mul-long v49, v49, v7

    mul-long v7, v7, v22

    add-long v22, v24, v73

    add-long v22, v22, v103

    add-long v22, v22, v93

    add-long v22, v22, v105

    add-long v22, v22, v2

    add-long v26, v26, v20

    add-long v26, v26, v95

    add-long v26, v26, v107

    add-long v26, v26, v39

    add-long v29, v29, v59

    add-long v29, v29, v99

    add-long v29, v29, v9

    add-long v29, v29, v109

    add-long v29, v29, v13

    add-long v31, v31, v53

    add-long v31, v31, v17

    add-long v31, v31, v111

    add-long v31, v31, v113

    add-long v35, v35, v55

    add-long v35, v35, v71

    add-long v35, v35, v15

    add-long v35, v35, v0

    add-long v35, v35, v11

    add-long v37, v37, v57

    add-long v37, v37, v75

    add-long v37, v37, v85

    add-long v37, v37, v45

    add-long v41, v41, v61

    add-long v41, v41, v77

    add-long v41, v41, v33

    add-long v41, v41, v69

    add-long v41, v41, v4

    add-long v43, v43, v63

    add-long v43, v43, v79

    add-long v43, v43, v87

    add-long v43, v43, v49

    add-long v47, v47, v65

    add-long v47, v47, v81

    add-long v47, v47, v89

    add-long v47, v47, v97

    add-long v47, v47, v7

    add-long v14, v51, v67

    add-long v14, v14, v83

    add-long v14, v14, v91

    add-long v14, v14, v101

    add-long v22, v22, v22

    add-long v26, v26, v26

    add-long v29, v29, v29

    add-long v31, v31, v31

    add-long v35, v35, v35

    add-long v37, v37, v37

    add-long v41, v41, v41

    add-long v43, v43, v43

    add-long v47, v47, v47

    add-long/2addr v14, v14

    const-wide/32 v0, 0x2000000

    add-long v2, v22, v0

    const/16 v4, 0x1a

    shr-long/2addr v2, v4

    add-long v26, v26, v2

    shl-long/2addr v2, v4

    sub-long v22, v22, v2

    add-long v2, v35, v0

    shr-long/2addr v2, v4

    add-long v37, v37, v2

    shl-long/2addr v2, v4

    sub-long v35, v35, v2

    const-wide/32 v2, 0x1000000

    add-long v5, v26, v2

    const/16 v7, 0x19

    shr-long/2addr v5, v7

    add-long v29, v29, v5

    shl-long/2addr v5, v7

    sub-long v26, v26, v5

    add-long v5, v37, v2

    shr-long/2addr v5, v7

    add-long v41, v41, v5

    shl-long/2addr v5, v7

    sub-long v37, v37, v5

    add-long v5, v29, v0

    shr-long/2addr v5, v4

    add-long v31, v31, v5

    shl-long/2addr v5, v4

    sub-long v5, v29, v5

    add-long v8, v41, v0

    shr-long/2addr v8, v4

    add-long v43, v43, v8

    shl-long/2addr v8, v4

    sub-long v8, v41, v8

    add-long v10, v31, v2

    shr-long/2addr v10, v7

    add-long v35, v35, v10

    shl-long/2addr v10, v7

    sub-long v10, v31, v10

    add-long v12, v43, v2

    shr-long/2addr v12, v7

    add-long v47, v47, v12

    shl-long/2addr v12, v7

    sub-long v12, v43, v12

    add-long v16, v35, v0

    shr-long v16, v16, v4

    move-wide/from16 v18, v8

    add-long v7, v37, v16

    shl-long v16, v16, v4

    sub-long v2, v35, v16

    add-long v16, v47, v0

    shr-long v16, v16, v4

    add-long v14, v14, v16

    shl-long v16, v16, v4

    move-wide/from16 v24, v5

    sub-long v4, v47, v16

    const-wide/32 v16, 0x1000000

    add-long v16, v14, v16

    const/16 v6, 0x19

    shr-long v16, v16, v6

    const-wide/16 v20, 0x13

    mul-long v20, v20, v16

    add-long v22, v22, v20

    shl-long v16, v16, v6

    sub-long v14, v14, v16

    add-long v0, v22, v0

    const/16 v6, 0x1a

    shr-long/2addr v0, v6

    move-wide/from16 v16, v14

    add-long v14, v26, v0

    shl-long/2addr v0, v6

    sub-long v0, v22, v0

    long-to-int v0, v0

    long-to-int v1, v14

    move-wide/from16 v14, v24

    long-to-int v6, v14

    long-to-int v9, v10

    long-to-int v2, v2

    long-to-int v3, v7

    move-wide/from16 v7, v18

    long-to-int v7, v7

    long-to-int v8, v12

    long-to-int v4, v4

    move-wide/from16 v14, v16

    long-to-int v5, v14

    move/from16 v26, v0

    move/from16 v27, v1

    move/from16 v28, v6

    move/from16 v29, v9

    move/from16 v30, v2

    move/from16 v31, v3

    move/from16 v32, v7

    move/from16 v33, v8

    move/from16 v34, v4

    move/from16 v35, v5

    filled-new-array/range {v26 .. v35}, [I

    move-result-object v0

    new-instance v1, Lcafe/cryptography/curve25519/FieldElement;

    invoke-direct {v1, v0}, Lcafe/cryptography/curve25519/FieldElement;-><init>([I)V

    return-object v1
.end method

.method public subtract(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;
    .locals 5

    iget-object p1, p1, Lcafe/cryptography/curve25519/FieldElement;->t:[I

    const/16 v0, 0xa

    new-array v1, v0, [I

    const/4 v2, 0x0

    :goto_0
    if-ge v2, v0, :cond_0

    iget-object v3, p0, Lcafe/cryptography/curve25519/FieldElement;->t:[I

    aget v3, v3, v2

    aget v4, p1, v2

    sub-int/2addr v3, v4

    aput v3, v1, v2

    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_0
    new-instance p0, Lcafe/cryptography/curve25519/FieldElement;

    invoke-direct {p0, v1}, Lcafe/cryptography/curve25519/FieldElement;-><init>([I)V

    return-object p0
.end method

.method public toByteArray()[B
    .locals 55

    move-object/from16 v0, p0

    iget-object v0, v0, Lcafe/cryptography/curve25519/FieldElement;->t:[I

    const/4 v1, 0x0

    aget v2, v0, v1

    const/4 v3, 0x1

    aget v4, v0, v3

    const/4 v5, 0x2

    aget v6, v0, v5

    const/4 v7, 0x3

    aget v8, v0, v7

    const/4 v9, 0x4

    aget v10, v0, v9

    const/4 v11, 0x5

    aget v12, v0, v11

    const/4 v13, 0x6

    aget v14, v0, v13

    const/4 v15, 0x7

    aget v16, v0, v15

    const/16 v17, 0x8

    aget v18, v0, v17

    const/16 v19, 0x9

    aget v0, v0, v19

    const/16 v20, 0x13

    mul-int/lit8 v21, v0, 0x13

    const/high16 v22, 0x1000000

    add-int v21, v21, v22

    const/16 v22, 0x19

    shr-int/lit8 v21, v21, 0x19

    add-int v21, v2, v21

    const/16 v23, 0x1a

    shr-int/lit8 v21, v21, 0x1a

    add-int v21, v4, v21

    shr-int/lit8 v21, v21, 0x19

    add-int v21, v6, v21

    shr-int/lit8 v21, v21, 0x1a

    add-int v21, v8, v21

    shr-int/lit8 v21, v21, 0x19

    add-int v21, v10, v21

    shr-int/lit8 v21, v21, 0x1a

    add-int v21, v12, v21

    shr-int/lit8 v21, v21, 0x19

    add-int v21, v14, v21

    shr-int/lit8 v21, v21, 0x1a

    add-int v21, v16, v21

    shr-int/lit8 v21, v21, 0x19

    add-int v21, v18, v21

    shr-int/lit8 v21, v21, 0x1a

    add-int v21, v0, v21

    shr-int/lit8 v21, v21, 0x19

    mul-int/lit8 v21, v21, 0x13

    add-int v2, v2, v21

    shr-int/lit8 v21, v2, 0x1a

    add-int v4, v4, v21

    shl-int/lit8 v21, v21, 0x1a

    sub-int v2, v2, v21

    shr-int/lit8 v21, v4, 0x19

    add-int v6, v6, v21

    shl-int/lit8 v21, v21, 0x19

    sub-int v4, v4, v21

    shr-int/lit8 v21, v6, 0x1a

    add-int v8, v8, v21

    shl-int/lit8 v21, v21, 0x1a

    sub-int v6, v6, v21

    shr-int/lit8 v21, v8, 0x19

    add-int v10, v10, v21

    shl-int/lit8 v21, v21, 0x19

    sub-int v8, v8, v21

    shr-int/lit8 v21, v10, 0x1a

    add-int v12, v12, v21

    shl-int/lit8 v21, v21, 0x1a

    sub-int v10, v10, v21

    shr-int/lit8 v21, v12, 0x19

    add-int v14, v14, v21

    shl-int/lit8 v21, v21, 0x19

    sub-int v12, v12, v21

    shr-int/lit8 v21, v14, 0x1a

    add-int v16, v16, v21

    shl-int/lit8 v21, v21, 0x1a

    sub-int v14, v14, v21

    shr-int/lit8 v21, v16, 0x19

    add-int v18, v18, v21

    shl-int/lit8 v21, v21, 0x19

    sub-int v16, v16, v21

    shr-int/lit8 v21, v18, 0x1a

    add-int v0, v0, v21

    shl-int/lit8 v21, v21, 0x1a

    sub-int v18, v18, v21

    shr-int/lit8 v21, v0, 0x19

    shl-int/lit8 v21, v21, 0x19

    sub-int v0, v0, v21

    int-to-byte v1, v2

    shr-int/lit8 v9, v2, 0x8

    int-to-byte v9, v9

    const/16 v24, 0x10

    shr-int/lit8 v15, v2, 0x10

    int-to-byte v15, v15

    const/16 v26, 0x18

    shr-int/lit8 v2, v2, 0x18

    shl-int/lit8 v27, v4, 0x2

    or-int v2, v2, v27

    int-to-byte v2, v2

    shr-int/lit8 v3, v4, 0x6

    int-to-byte v3, v3

    const/16 v28, 0xe

    shr-int/lit8 v5, v4, 0xe

    int-to-byte v5, v5

    const/16 v30, 0x16

    shr-int/lit8 v4, v4, 0x16

    shl-int/lit8 v31, v6, 0x3

    or-int v4, v4, v31

    int-to-byte v4, v4

    shr-int/lit8 v13, v6, 0x5

    int-to-byte v13, v13

    const/16 v32, 0xd

    shr-int/lit8 v7, v6, 0xd

    int-to-byte v7, v7

    const/16 v34, 0x15

    shr-int/lit8 v6, v6, 0x15

    shl-int/lit8 v35, v8, 0x5

    or-int v6, v6, v35

    int-to-byte v6, v6

    const/16 v33, 0x3

    shr-int/lit8 v11, v8, 0x3

    int-to-byte v11, v11

    const/16 v36, 0xb

    move/from16 v37, v11

    shr-int/lit8 v11, v8, 0xb

    int-to-byte v11, v11

    shr-int/lit8 v8, v8, 0x13

    const/16 v31, 0x6

    shl-int/lit8 v38, v10, 0x6

    or-int v8, v8, v38

    int-to-byte v8, v8

    move/from16 v38, v8

    const/16 v29, 0x2

    shr-int/lit8 v8, v10, 0x2

    int-to-byte v8, v8

    const/16 v39, 0xa

    move/from16 v40, v8

    shr-int/lit8 v8, v10, 0xa

    int-to-byte v8, v8

    const/16 v41, 0x12

    shr-int/lit8 v10, v10, 0x12

    int-to-byte v10, v10

    move/from16 v42, v10

    int-to-byte v10, v12

    move/from16 v43, v10

    shr-int/lit8 v10, v12, 0x8

    int-to-byte v10, v10

    move/from16 v44, v10

    shr-int/lit8 v10, v12, 0x10

    int-to-byte v10, v10

    shr-int/lit8 v12, v12, 0x18

    const/16 v27, 0x1

    shl-int/lit8 v45, v14, 0x1

    or-int v12, v12, v45

    int-to-byte v12, v12

    move/from16 v45, v12

    const/16 v25, 0x7

    shr-int/lit8 v12, v14, 0x7

    int-to-byte v12, v12

    move/from16 v46, v12

    shr-int/lit8 v12, v14, 0xf

    int-to-byte v12, v12

    shr-int/lit8 v14, v14, 0x17

    const/16 v33, 0x3

    shl-int/lit8 v47, v16, 0x3

    or-int v14, v14, v47

    int-to-byte v14, v14

    move/from16 v47, v14

    const/16 v35, 0x5

    shr-int/lit8 v14, v16, 0x5

    int-to-byte v14, v14

    move/from16 v48, v14

    shr-int/lit8 v14, v16, 0xd

    int-to-byte v14, v14

    shr-int/lit8 v16, v16, 0x15

    const/16 v21, 0x4

    shl-int/lit8 v49, v18, 0x4

    move/from16 v50, v14

    or-int v14, v16, v49

    int-to-byte v14, v14

    move/from16 v16, v14

    shr-int/lit8 v14, v18, 0x4

    int-to-byte v14, v14

    move/from16 v49, v14

    shr-int/lit8 v14, v18, 0xc

    int-to-byte v14, v14

    shr-int/lit8 v18, v18, 0x14

    const/16 v31, 0x6

    shl-int/lit8 v51, v0, 0x6

    move/from16 v52, v14

    or-int v14, v18, v51

    int-to-byte v14, v14

    move/from16 v29, v14

    const/16 v18, 0x2

    shr-int/lit8 v14, v0, 0x2

    int-to-byte v14, v14

    move/from16 v51, v14

    shr-int/lit8 v14, v0, 0xa

    int-to-byte v14, v14

    shr-int/lit8 v0, v0, 0x12

    int-to-byte v0, v0

    move/from16 v53, v0

    const/16 v0, 0x20

    new-array v0, v0, [B

    const/16 v54, 0x0

    aput-byte v1, v0, v54

    const/4 v1, 0x1

    aput-byte v9, v0, v1

    aput-byte v15, v0, v18

    const/4 v1, 0x3

    aput-byte v2, v0, v1

    const/4 v1, 0x4

    aput-byte v3, v0, v1

    const/4 v1, 0x5

    aput-byte v5, v0, v1

    const/4 v1, 0x6

    aput-byte v4, v0, v1

    const/4 v1, 0x7

    aput-byte v13, v0, v1

    aput-byte v7, v0, v17

    aput-byte v6, v0, v19

    aput-byte v37, v0, v39

    aput-byte v11, v0, v36

    const/16 v1, 0xc

    aput-byte v38, v0, v1

    aput-byte v40, v0, v32

    aput-byte v8, v0, v28

    const/16 v1, 0xf

    aput-byte v42, v0, v1

    aput-byte v43, v0, v24

    const/16 v1, 0x11

    aput-byte v44, v0, v1

    aput-byte v10, v0, v41

    aput-byte v45, v0, v20

    const/16 v1, 0x14

    aput-byte v46, v0, v1

    aput-byte v12, v0, v34

    aput-byte v47, v0, v30

    const/16 v1, 0x17

    aput-byte v48, v0, v1

    aput-byte v50, v0, v26

    aput-byte v16, v0, v22

    aput-byte v49, v0, v23

    const/16 v1, 0x1b

    aput-byte v52, v0, v1

    const/16 v1, 0x1c

    aput-byte v29, v0, v1

    const/16 v1, 0x1d

    aput-byte v51, v0, v1

    const/16 v1, 0x1e

    aput-byte v14, v0, v1

    const/16 v1, 0x1f

    aput-byte v53, v0, v1

    return-object v0
.end method
