.class Lcafe/cryptography/curve25519/CompletedPoint;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field final T:Lcafe/cryptography/curve25519/FieldElement;

.field final X:Lcafe/cryptography/curve25519/FieldElement;

.field final Y:Lcafe/cryptography/curve25519/FieldElement;

.field final Z:Lcafe/cryptography/curve25519/FieldElement;


# direct methods
.method public constructor <init>(Lcafe/cryptography/curve25519/FieldElement;Lcafe/cryptography/curve25519/FieldElement;Lcafe/cryptography/curve25519/FieldElement;Lcafe/cryptography/curve25519/FieldElement;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcafe/cryptography/curve25519/CompletedPoint;->X:Lcafe/cryptography/curve25519/FieldElement;

    iput-object p2, p0, Lcafe/cryptography/curve25519/CompletedPoint;->Y:Lcafe/cryptography/curve25519/FieldElement;

    iput-object p3, p0, Lcafe/cryptography/curve25519/CompletedPoint;->Z:Lcafe/cryptography/curve25519/FieldElement;

    iput-object p4, p0, Lcafe/cryptography/curve25519/CompletedPoint;->T:Lcafe/cryptography/curve25519/FieldElement;

    return-void
.end method


# virtual methods
.method public toExtended()Lcafe/cryptography/curve25519/EdwardsPoint;
    .locals 5

    new-instance v0, Lcafe/cryptography/curve25519/EdwardsPoint;

    iget-object v1, p0, Lcafe/cryptography/curve25519/CompletedPoint;->X:Lcafe/cryptography/curve25519/FieldElement;

    iget-object v2, p0, Lcafe/cryptography/curve25519/CompletedPoint;->T:Lcafe/cryptography/curve25519/FieldElement;

    invoke-virtual {v1, v2}, Lcafe/cryptography/curve25519/FieldElement;->multiply(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v1

    iget-object v2, p0, Lcafe/cryptography/curve25519/CompletedPoint;->Y:Lcafe/cryptography/curve25519/FieldElement;

    iget-object v3, p0, Lcafe/cryptography/curve25519/CompletedPoint;->Z:Lcafe/cryptography/curve25519/FieldElement;

    invoke-virtual {v2, v3}, Lcafe/cryptography/curve25519/FieldElement;->multiply(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v2

    iget-object v3, p0, Lcafe/cryptography/curve25519/CompletedPoint;->Z:Lcafe/cryptography/curve25519/FieldElement;

    iget-object v4, p0, Lcafe/cryptography/curve25519/CompletedPoint;->T:Lcafe/cryptography/curve25519/FieldElement;

    invoke-virtual {v3, v4}, Lcafe/cryptography/curve25519/FieldElement;->multiply(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v3

    iget-object v4, p0, Lcafe/cryptography/curve25519/CompletedPoint;->X:Lcafe/cryptography/curve25519/FieldElement;

    iget-object p0, p0, Lcafe/cryptography/curve25519/CompletedPoint;->Y:Lcafe/cryptography/curve25519/FieldElement;

    invoke-virtual {v4, p0}, Lcafe/cryptography/curve25519/FieldElement;->multiply(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object p0

    invoke-direct {v0, v1, v2, v3, p0}, Lcafe/cryptography/curve25519/EdwardsPoint;-><init>(Lcafe/cryptography/curve25519/FieldElement;Lcafe/cryptography/curve25519/FieldElement;Lcafe/cryptography/curve25519/FieldElement;Lcafe/cryptography/curve25519/FieldElement;)V

    return-object v0
.end method

.method public toProjective()Lcafe/cryptography/curve25519/ProjectivePoint;
    .locals 4

    new-instance v0, Lcafe/cryptography/curve25519/ProjectivePoint;

    iget-object v1, p0, Lcafe/cryptography/curve25519/CompletedPoint;->X:Lcafe/cryptography/curve25519/FieldElement;

    iget-object v2, p0, Lcafe/cryptography/curve25519/CompletedPoint;->T:Lcafe/cryptography/curve25519/FieldElement;

    invoke-virtual {v1, v2}, Lcafe/cryptography/curve25519/FieldElement;->multiply(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v1

    iget-object v2, p0, Lcafe/cryptography/curve25519/CompletedPoint;->Y:Lcafe/cryptography/curve25519/FieldElement;

    iget-object v3, p0, Lcafe/cryptography/curve25519/CompletedPoint;->Z:Lcafe/cryptography/curve25519/FieldElement;

    invoke-virtual {v2, v3}, Lcafe/cryptography/curve25519/FieldElement;->multiply(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v2

    iget-object v3, p0, Lcafe/cryptography/curve25519/CompletedPoint;->Z:Lcafe/cryptography/curve25519/FieldElement;

    iget-object p0, p0, Lcafe/cryptography/curve25519/CompletedPoint;->T:Lcafe/cryptography/curve25519/FieldElement;

    invoke-virtual {v3, p0}, Lcafe/cryptography/curve25519/FieldElement;->multiply(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object p0

    invoke-direct {v0, v1, v2, p0}, Lcafe/cryptography/curve25519/ProjectivePoint;-><init>(Lcafe/cryptography/curve25519/FieldElement;Lcafe/cryptography/curve25519/FieldElement;Lcafe/cryptography/curve25519/FieldElement;)V

    return-object v0
.end method
