.class public Lcafe/cryptography/curve25519/EdwardsBasepointTable;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field final tables:[Lcafe/cryptography/curve25519/AffineNielsPoint$LookupTable;


# direct methods
.method public constructor <init>(Lcafe/cryptography/curve25519/EdwardsPoint;)V
    .locals 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/16 v0, 0x20

    new-array v1, v0, [Lcafe/cryptography/curve25519/AffineNielsPoint$LookupTable;

    iput-object v1, p0, Lcafe/cryptography/curve25519/EdwardsBasepointTable;->tables:[Lcafe/cryptography/curve25519/AffineNielsPoint$LookupTable;

    const/4 v1, 0x0

    :goto_0
    if-ge v1, v0, :cond_0

    iget-object v2, p0, Lcafe/cryptography/curve25519/EdwardsBasepointTable;->tables:[Lcafe/cryptography/curve25519/AffineNielsPoint$LookupTable;

    invoke-static {p1}, Lcafe/cryptography/curve25519/AffineNielsPoint;->buildLookupTable(Lcafe/cryptography/curve25519/EdwardsPoint;)Lcafe/cryptography/curve25519/AffineNielsPoint$LookupTable;

    move-result-object v3

    aput-object v3, v2, v1

    const/16 v2, 0x8

    invoke-virtual {p1, v2}, Lcafe/cryptography/curve25519/EdwardsPoint;->multiplyByPow2(I)Lcafe/cryptography/curve25519/EdwardsPoint;

    move-result-object p1

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_0
    return-void
.end method


# virtual methods
.method public multiply(Lcafe/cryptography/curve25519/Scalar;)Lcafe/cryptography/curve25519/EdwardsPoint;
    .locals 5

    invoke-virtual {p1}, Lcafe/cryptography/curve25519/Scalar;->toRadix16()[B

    move-result-object p1

    sget-object v0, Lcafe/cryptography/curve25519/EdwardsPoint;->IDENTITY:Lcafe/cryptography/curve25519/EdwardsPoint;

    const/4 v1, 0x1

    :goto_0
    const/16 v2, 0x40

    if-ge v1, v2, :cond_0

    iget-object v2, p0, Lcafe/cryptography/curve25519/EdwardsBasepointTable;->tables:[Lcafe/cryptography/curve25519/AffineNielsPoint$LookupTable;

    div-int/lit8 v3, v1, 0x2

    aget-object v2, v2, v3

    aget-byte v3, p1, v1

    invoke-virtual {v2, v3}, Lcafe/cryptography/curve25519/AffineNielsPoint$LookupTable;->select(I)Lcafe/cryptography/curve25519/AffineNielsPoint;

    move-result-object v2

    invoke-virtual {v0, v2}, Lcafe/cryptography/curve25519/EdwardsPoint;->add(Lcafe/cryptography/curve25519/AffineNielsPoint;)Lcafe/cryptography/curve25519/CompletedPoint;

    move-result-object v0

    invoke-virtual {v0}, Lcafe/cryptography/curve25519/CompletedPoint;->toExtended()Lcafe/cryptography/curve25519/EdwardsPoint;

    move-result-object v0

    add-int/lit8 v1, v1, 0x2

    goto :goto_0

    :cond_0
    const/4 v1, 0x4

    invoke-virtual {v0, v1}, Lcafe/cryptography/curve25519/EdwardsPoint;->multiplyByPow2(I)Lcafe/cryptography/curve25519/EdwardsPoint;

    move-result-object v0

    const/4 v1, 0x0

    :goto_1
    if-ge v1, v2, :cond_1

    iget-object v3, p0, Lcafe/cryptography/curve25519/EdwardsBasepointTable;->tables:[Lcafe/cryptography/curve25519/AffineNielsPoint$LookupTable;

    div-int/lit8 v4, v1, 0x2

    aget-object v3, v3, v4

    aget-byte v4, p1, v1

    invoke-virtual {v3, v4}, Lcafe/cryptography/curve25519/AffineNielsPoint$LookupTable;->select(I)Lcafe/cryptography/curve25519/AffineNielsPoint;

    move-result-object v3

    invoke-virtual {v0, v3}, Lcafe/cryptography/curve25519/EdwardsPoint;->add(Lcafe/cryptography/curve25519/AffineNielsPoint;)Lcafe/cryptography/curve25519/CompletedPoint;

    move-result-object v0

    invoke-virtual {v0}, Lcafe/cryptography/curve25519/CompletedPoint;->toExtended()Lcafe/cryptography/curve25519/EdwardsPoint;

    move-result-object v0

    add-int/lit8 v1, v1, 0x2

    goto :goto_1

    :cond_1
    return-object v0
.end method
