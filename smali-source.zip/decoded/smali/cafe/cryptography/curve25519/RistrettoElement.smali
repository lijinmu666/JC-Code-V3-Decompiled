.class public Lcafe/cryptography/curve25519/RistrettoElement;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/io/Serializable;


# static fields
.field public static final IDENTITY:Lcafe/cryptography/curve25519/RistrettoElement;

.field private static final serialVersionUID:J = 0x1L


# instance fields
.field transient repr:Lcafe/cryptography/curve25519/EdwardsPoint;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    new-instance v0, Lcafe/cryptography/curve25519/RistrettoElement;

    sget-object v1, Lcafe/cryptography/curve25519/EdwardsPoint;->IDENTITY:Lcafe/cryptography/curve25519/EdwardsPoint;

    invoke-direct {v0, v1}, Lcafe/cryptography/curve25519/RistrettoElement;-><init>(Lcafe/cryptography/curve25519/EdwardsPoint;)V

    sput-object v0, Lcafe/cryptography/curve25519/RistrettoElement;->IDENTITY:Lcafe/cryptography/curve25519/RistrettoElement;

    return-void
.end method

.method public constructor <init>(Lcafe/cryptography/curve25519/EdwardsPoint;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcafe/cryptography/curve25519/RistrettoElement;->repr:Lcafe/cryptography/curve25519/EdwardsPoint;

    return-void
.end method

.method public static fromUniformBytes([B)Lcafe/cryptography/curve25519/RistrettoElement;
    .locals 3

    const/4 v0, 0x0

    const/16 v1, 0x20

    invoke-static {p0, v0, v1}, Ljava/util/Arrays;->copyOfRange([BII)[B

    move-result-object v0

    invoke-static {v0}, Lcafe/cryptography/curve25519/FieldElement;->fromByteArray([B)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v0

    const/16 v2, 0x40

    invoke-static {p0, v1, v2}, Ljava/util/Arrays;->copyOfRange([BII)[B

    move-result-object p0

    invoke-static {p0}, Lcafe/cryptography/curve25519/FieldElement;->fromByteArray([B)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object p0

    invoke-static {v0}, Lcafe/cryptography/curve25519/RistrettoElement;->map(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/RistrettoElement;

    move-result-object v0

    invoke-static {p0}, Lcafe/cryptography/curve25519/RistrettoElement;->map(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/RistrettoElement;

    move-result-object p0

    invoke-virtual {v0, p0}, Lcafe/cryptography/curve25519/RistrettoElement;->add(Lcafe/cryptography/curve25519/RistrettoElement;)Lcafe/cryptography/curve25519/RistrettoElement;

    move-result-object p0

    return-object p0
.end method

.method public static map(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/RistrettoElement;
    .locals 7

    invoke-virtual {p0}, Lcafe/cryptography/curve25519/FieldElement;->square()Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v0

    sget-object v1, Lcafe/cryptography/curve25519/Constants;->SQRT_M1:Lcafe/cryptography/curve25519/FieldElement;

    invoke-virtual {v0, v1}, Lcafe/cryptography/curve25519/FieldElement;->multiply(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v0

    sget-object v1, Lcafe/cryptography/curve25519/FieldElement;->ONE:Lcafe/cryptography/curve25519/FieldElement;

    invoke-virtual {v0, v1}, Lcafe/cryptography/curve25519/FieldElement;->add(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v2

    sget-object v3, Lcafe/cryptography/curve25519/Constants;->ONE_MINUS_D_SQ:Lcafe/cryptography/curve25519/FieldElement;

    invoke-virtual {v2, v3}, Lcafe/cryptography/curve25519/FieldElement;->multiply(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v2

    sget-object v3, Lcafe/cryptography/curve25519/FieldElement;->MINUS_ONE:Lcafe/cryptography/curve25519/FieldElement;

    sget-object v4, Lcafe/cryptography/curve25519/Constants;->EDWARDS_D:Lcafe/cryptography/curve25519/FieldElement;

    invoke-virtual {v0, v4}, Lcafe/cryptography/curve25519/FieldElement;->multiply(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v5

    invoke-virtual {v3, v5}, Lcafe/cryptography/curve25519/FieldElement;->subtract(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v5

    invoke-virtual {v0, v4}, Lcafe/cryptography/curve25519/FieldElement;->add(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v4

    invoke-virtual {v5, v4}, Lcafe/cryptography/curve25519/FieldElement;->multiply(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v4

    invoke-static {v2, v4}, Lcafe/cryptography/curve25519/FieldElement;->sqrtRatioM1(Lcafe/cryptography/curve25519/FieldElement;Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement$SqrtRatioM1Result;

    move-result-object v2

    iget-object v5, v2, Lcafe/cryptography/curve25519/FieldElement$SqrtRatioM1Result;->result:Lcafe/cryptography/curve25519/FieldElement;

    invoke-virtual {v5, p0}, Lcafe/cryptography/curve25519/FieldElement;->multiply(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object p0

    invoke-virtual {p0}, Lcafe/cryptography/curve25519/FieldElement;->ctAbs()Lcafe/cryptography/curve25519/FieldElement;

    move-result-object p0

    invoke-virtual {p0}, Lcafe/cryptography/curve25519/FieldElement;->negate()Lcafe/cryptography/curve25519/FieldElement;

    move-result-object p0

    iget v6, v2, Lcafe/cryptography/curve25519/FieldElement$SqrtRatioM1Result;->wasSquare:I

    invoke-virtual {p0, v5, v6}, Lcafe/cryptography/curve25519/FieldElement;->ctSelect(Lcafe/cryptography/curve25519/FieldElement;I)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object p0

    iget v2, v2, Lcafe/cryptography/curve25519/FieldElement$SqrtRatioM1Result;->wasSquare:I

    invoke-virtual {v0, v3, v2}, Lcafe/cryptography/curve25519/FieldElement;->ctSelect(Lcafe/cryptography/curve25519/FieldElement;I)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v2

    invoke-virtual {v0, v1}, Lcafe/cryptography/curve25519/FieldElement;->subtract(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v0

    invoke-virtual {v2, v0}, Lcafe/cryptography/curve25519/FieldElement;->multiply(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v0

    sget-object v2, Lcafe/cryptography/curve25519/Constants;->D_MINUS_ONE_SQ:Lcafe/cryptography/curve25519/FieldElement;

    invoke-virtual {v0, v2}, Lcafe/cryptography/curve25519/FieldElement;->multiply(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v0

    invoke-virtual {v0, v4}, Lcafe/cryptography/curve25519/FieldElement;->subtract(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v0

    invoke-virtual {p0}, Lcafe/cryptography/curve25519/FieldElement;->square()Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v2

    invoke-virtual {p0, p0}, Lcafe/cryptography/curve25519/FieldElement;->add(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object p0

    invoke-virtual {p0, v4}, Lcafe/cryptography/curve25519/FieldElement;->multiply(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object p0

    sget-object v3, Lcafe/cryptography/curve25519/Constants;->SQRT_AD_MINUS_ONE:Lcafe/cryptography/curve25519/FieldElement;

    invoke-virtual {v0, v3}, Lcafe/cryptography/curve25519/FieldElement;->multiply(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v0

    invoke-virtual {v1, v2}, Lcafe/cryptography/curve25519/FieldElement;->subtract(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v3

    invoke-virtual {v1, v2}, Lcafe/cryptography/curve25519/FieldElement;->add(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v1

    new-instance v2, Lcafe/cryptography/curve25519/RistrettoElement;

    new-instance v4, Lcafe/cryptography/curve25519/EdwardsPoint;

    invoke-virtual {p0, v1}, Lcafe/cryptography/curve25519/FieldElement;->multiply(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v5

    invoke-virtual {v3, v0}, Lcafe/cryptography/curve25519/FieldElement;->multiply(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v6

    invoke-virtual {v0, v1}, Lcafe/cryptography/curve25519/FieldElement;->multiply(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v0

    invoke-virtual {p0, v3}, Lcafe/cryptography/curve25519/FieldElement;->multiply(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object p0

    invoke-direct {v4, v5, v6, v0, p0}, Lcafe/cryptography/curve25519/EdwardsPoint;-><init>(Lcafe/cryptography/curve25519/FieldElement;Lcafe/cryptography/curve25519/FieldElement;Lcafe/cryptography/curve25519/FieldElement;Lcafe/cryptography/curve25519/FieldElement;)V

    invoke-direct {v2, v4}, Lcafe/cryptography/curve25519/RistrettoElement;-><init>(Lcafe/cryptography/curve25519/EdwardsPoint;)V

    return-object v2
.end method

.method private readObject(Ljava/io/ObjectInputStream;)V
    .locals 1

    const/16 v0, 0x20

    new-array v0, v0, [B

    invoke-virtual {p1, v0}, Ljava/io/ObjectInputStream;->readFully([B)V

    :try_start_0
    new-instance p1, Lcafe/cryptography/curve25519/CompressedRistretto;

    invoke-direct {p1, v0}, Lcafe/cryptography/curve25519/CompressedRistretto;-><init>([B)V

    invoke-virtual {p1}, Lcafe/cryptography/curve25519/CompressedRistretto;->decompress()Lcafe/cryptography/curve25519/RistrettoElement;

    move-result-object p1

    iget-object p1, p1, Lcafe/cryptography/curve25519/RistrettoElement;->repr:Lcafe/cryptography/curve25519/EdwardsPoint;

    iput-object p1, p0, Lcafe/cryptography/curve25519/RistrettoElement;->repr:Lcafe/cryptography/curve25519/EdwardsPoint;
    :try_end_0
    .catch Lcafe/cryptography/curve25519/InvalidEncodingException; {:try_start_0 .. :try_end_0} :catch_0

    return-void

    :catch_0
    move-exception p0

    new-instance p1, Ljava/io/InvalidObjectException;

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p0

    invoke-direct {p1, p0}, Ljava/io/InvalidObjectException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method private readObjectNoData()V
    .locals 1

    new-instance p0, Ljava/io/InvalidObjectException;

    const-string v0, "Cannot deserialize RistrettoElement from no data"

    invoke-direct {p0, v0}, Ljava/io/InvalidObjectException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method private writeObject(Ljava/io/ObjectOutputStream;)V
    .locals 0

    invoke-virtual {p0}, Lcafe/cryptography/curve25519/RistrettoElement;->compress()Lcafe/cryptography/curve25519/CompressedRistretto;

    move-result-object p0

    invoke-virtual {p0}, Lcafe/cryptography/curve25519/CompressedRistretto;->toByteArray()[B

    move-result-object p0

    invoke-virtual {p1, p0}, Ljava/io/ObjectOutputStream;->write([B)V

    return-void
.end method


# virtual methods
.method public add(Lcafe/cryptography/curve25519/RistrettoElement;)Lcafe/cryptography/curve25519/RistrettoElement;
    .locals 1

    new-instance v0, Lcafe/cryptography/curve25519/RistrettoElement;

    iget-object p0, p0, Lcafe/cryptography/curve25519/RistrettoElement;->repr:Lcafe/cryptography/curve25519/EdwardsPoint;

    iget-object p1, p1, Lcafe/cryptography/curve25519/RistrettoElement;->repr:Lcafe/cryptography/curve25519/EdwardsPoint;

    invoke-virtual {p0, p1}, Lcafe/cryptography/curve25519/EdwardsPoint;->add(Lcafe/cryptography/curve25519/EdwardsPoint;)Lcafe/cryptography/curve25519/EdwardsPoint;

    move-result-object p0

    invoke-direct {v0, p0}, Lcafe/cryptography/curve25519/RistrettoElement;-><init>(Lcafe/cryptography/curve25519/EdwardsPoint;)V

    return-object v0
.end method

.method public compress()Lcafe/cryptography/curve25519/CompressedRistretto;
    .locals 7

    iget-object v0, p0, Lcafe/cryptography/curve25519/RistrettoElement;->repr:Lcafe/cryptography/curve25519/EdwardsPoint;

    iget-object v1, v0, Lcafe/cryptography/curve25519/EdwardsPoint;->Z:Lcafe/cryptography/curve25519/FieldElement;

    iget-object v0, v0, Lcafe/cryptography/curve25519/EdwardsPoint;->Y:Lcafe/cryptography/curve25519/FieldElement;

    invoke-virtual {v1, v0}, Lcafe/cryptography/curve25519/FieldElement;->add(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v0

    iget-object v1, p0, Lcafe/cryptography/curve25519/RistrettoElement;->repr:Lcafe/cryptography/curve25519/EdwardsPoint;

    iget-object v2, v1, Lcafe/cryptography/curve25519/EdwardsPoint;->Z:Lcafe/cryptography/curve25519/FieldElement;

    iget-object v1, v1, Lcafe/cryptography/curve25519/EdwardsPoint;->Y:Lcafe/cryptography/curve25519/FieldElement;

    invoke-virtual {v2, v1}, Lcafe/cryptography/curve25519/FieldElement;->subtract(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcafe/cryptography/curve25519/FieldElement;->multiply(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v0

    iget-object v1, p0, Lcafe/cryptography/curve25519/RistrettoElement;->repr:Lcafe/cryptography/curve25519/EdwardsPoint;

    iget-object v2, v1, Lcafe/cryptography/curve25519/EdwardsPoint;->X:Lcafe/cryptography/curve25519/FieldElement;

    iget-object v1, v1, Lcafe/cryptography/curve25519/EdwardsPoint;->Y:Lcafe/cryptography/curve25519/FieldElement;

    invoke-virtual {v2, v1}, Lcafe/cryptography/curve25519/FieldElement;->multiply(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v1

    sget-object v2, Lcafe/cryptography/curve25519/FieldElement;->ONE:Lcafe/cryptography/curve25519/FieldElement;

    invoke-virtual {v1}, Lcafe/cryptography/curve25519/FieldElement;->square()Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v3

    invoke-virtual {v0, v3}, Lcafe/cryptography/curve25519/FieldElement;->multiply(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v3

    invoke-static {v2, v3}, Lcafe/cryptography/curve25519/FieldElement;->sqrtRatioM1(Lcafe/cryptography/curve25519/FieldElement;Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement$SqrtRatioM1Result;

    move-result-object v2

    iget-object v3, v2, Lcafe/cryptography/curve25519/FieldElement$SqrtRatioM1Result;->result:Lcafe/cryptography/curve25519/FieldElement;

    invoke-virtual {v3, v0}, Lcafe/cryptography/curve25519/FieldElement;->multiply(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v0

    iget-object v2, v2, Lcafe/cryptography/curve25519/FieldElement$SqrtRatioM1Result;->result:Lcafe/cryptography/curve25519/FieldElement;

    invoke-virtual {v2, v1}, Lcafe/cryptography/curve25519/FieldElement;->multiply(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcafe/cryptography/curve25519/FieldElement;->multiply(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v2

    iget-object v3, p0, Lcafe/cryptography/curve25519/RistrettoElement;->repr:Lcafe/cryptography/curve25519/EdwardsPoint;

    iget-object v3, v3, Lcafe/cryptography/curve25519/EdwardsPoint;->T:Lcafe/cryptography/curve25519/FieldElement;

    invoke-virtual {v2, v3}, Lcafe/cryptography/curve25519/FieldElement;->multiply(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v2

    iget-object v3, p0, Lcafe/cryptography/curve25519/RistrettoElement;->repr:Lcafe/cryptography/curve25519/EdwardsPoint;

    iget-object v3, v3, Lcafe/cryptography/curve25519/EdwardsPoint;->X:Lcafe/cryptography/curve25519/FieldElement;

    sget-object v4, Lcafe/cryptography/curve25519/Constants;->SQRT_M1:Lcafe/cryptography/curve25519/FieldElement;

    invoke-virtual {v3, v4}, Lcafe/cryptography/curve25519/FieldElement;->multiply(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v3

    iget-object v5, p0, Lcafe/cryptography/curve25519/RistrettoElement;->repr:Lcafe/cryptography/curve25519/EdwardsPoint;

    iget-object v5, v5, Lcafe/cryptography/curve25519/EdwardsPoint;->Y:Lcafe/cryptography/curve25519/FieldElement;

    invoke-virtual {v5, v4}, Lcafe/cryptography/curve25519/FieldElement;->multiply(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v4

    sget-object v5, Lcafe/cryptography/curve25519/Constants;->INVSQRT_A_MINUS_D:Lcafe/cryptography/curve25519/FieldElement;

    invoke-virtual {v0, v5}, Lcafe/cryptography/curve25519/FieldElement;->multiply(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v0

    iget-object v5, p0, Lcafe/cryptography/curve25519/RistrettoElement;->repr:Lcafe/cryptography/curve25519/EdwardsPoint;

    iget-object v5, v5, Lcafe/cryptography/curve25519/EdwardsPoint;->T:Lcafe/cryptography/curve25519/FieldElement;

    invoke-virtual {v5, v2}, Lcafe/cryptography/curve25519/FieldElement;->multiply(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v5

    invoke-virtual {v5}, Lcafe/cryptography/curve25519/FieldElement;->isNegative()I

    move-result v5

    iget-object v6, p0, Lcafe/cryptography/curve25519/RistrettoElement;->repr:Lcafe/cryptography/curve25519/EdwardsPoint;

    iget-object v6, v6, Lcafe/cryptography/curve25519/EdwardsPoint;->X:Lcafe/cryptography/curve25519/FieldElement;

    invoke-virtual {v6, v4, v5}, Lcafe/cryptography/curve25519/FieldElement;->ctSelect(Lcafe/cryptography/curve25519/FieldElement;I)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v4

    iget-object v6, p0, Lcafe/cryptography/curve25519/RistrettoElement;->repr:Lcafe/cryptography/curve25519/EdwardsPoint;

    iget-object v6, v6, Lcafe/cryptography/curve25519/EdwardsPoint;->Y:Lcafe/cryptography/curve25519/FieldElement;

    invoke-virtual {v6, v3, v5}, Lcafe/cryptography/curve25519/FieldElement;->ctSelect(Lcafe/cryptography/curve25519/FieldElement;I)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v3

    iget-object p0, p0, Lcafe/cryptography/curve25519/RistrettoElement;->repr:Lcafe/cryptography/curve25519/EdwardsPoint;

    iget-object p0, p0, Lcafe/cryptography/curve25519/EdwardsPoint;->Z:Lcafe/cryptography/curve25519/FieldElement;

    invoke-virtual {v1, v0, v5}, Lcafe/cryptography/curve25519/FieldElement;->ctSelect(Lcafe/cryptography/curve25519/FieldElement;I)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v0

    invoke-virtual {v3}, Lcafe/cryptography/curve25519/FieldElement;->negate()Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v1

    invoke-virtual {v4, v2}, Lcafe/cryptography/curve25519/FieldElement;->multiply(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v2

    invoke-virtual {v2}, Lcafe/cryptography/curve25519/FieldElement;->isNegative()I

    move-result v2

    invoke-virtual {v3, v1, v2}, Lcafe/cryptography/curve25519/FieldElement;->ctSelect(Lcafe/cryptography/curve25519/FieldElement;I)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v1

    invoke-virtual {p0, v1}, Lcafe/cryptography/curve25519/FieldElement;->subtract(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object p0

    invoke-virtual {v0, p0}, Lcafe/cryptography/curve25519/FieldElement;->multiply(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object p0

    invoke-virtual {p0}, Lcafe/cryptography/curve25519/FieldElement;->isNegative()I

    move-result v0

    invoke-virtual {p0}, Lcafe/cryptography/curve25519/FieldElement;->negate()Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v1

    invoke-virtual {p0, v1, v0}, Lcafe/cryptography/curve25519/FieldElement;->ctSelect(Lcafe/cryptography/curve25519/FieldElement;I)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object p0

    new-instance v0, Lcafe/cryptography/curve25519/CompressedRistretto;

    invoke-virtual {p0}, Lcafe/cryptography/curve25519/FieldElement;->toByteArray()[B

    move-result-object p0

    invoke-direct {v0, p0}, Lcafe/cryptography/curve25519/CompressedRistretto;-><init>([B)V

    return-object v0
.end method

.method public ctEquals(Lcafe/cryptography/curve25519/RistrettoElement;)I
    .locals 4

    iget-object v0, p0, Lcafe/cryptography/curve25519/RistrettoElement;->repr:Lcafe/cryptography/curve25519/EdwardsPoint;

    iget-object v0, v0, Lcafe/cryptography/curve25519/EdwardsPoint;->X:Lcafe/cryptography/curve25519/FieldElement;

    iget-object v1, p1, Lcafe/cryptography/curve25519/RistrettoElement;->repr:Lcafe/cryptography/curve25519/EdwardsPoint;

    iget-object v1, v1, Lcafe/cryptography/curve25519/EdwardsPoint;->Y:Lcafe/cryptography/curve25519/FieldElement;

    invoke-virtual {v0, v1}, Lcafe/cryptography/curve25519/FieldElement;->multiply(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v0

    iget-object v1, p0, Lcafe/cryptography/curve25519/RistrettoElement;->repr:Lcafe/cryptography/curve25519/EdwardsPoint;

    iget-object v1, v1, Lcafe/cryptography/curve25519/EdwardsPoint;->Y:Lcafe/cryptography/curve25519/FieldElement;

    iget-object v2, p1, Lcafe/cryptography/curve25519/RistrettoElement;->repr:Lcafe/cryptography/curve25519/EdwardsPoint;

    iget-object v2, v2, Lcafe/cryptography/curve25519/EdwardsPoint;->X:Lcafe/cryptography/curve25519/FieldElement;

    invoke-virtual {v1, v2}, Lcafe/cryptography/curve25519/FieldElement;->multiply(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v1

    iget-object v2, p0, Lcafe/cryptography/curve25519/RistrettoElement;->repr:Lcafe/cryptography/curve25519/EdwardsPoint;

    iget-object v2, v2, Lcafe/cryptography/curve25519/EdwardsPoint;->Y:Lcafe/cryptography/curve25519/FieldElement;

    iget-object v3, p1, Lcafe/cryptography/curve25519/RistrettoElement;->repr:Lcafe/cryptography/curve25519/EdwardsPoint;

    iget-object v3, v3, Lcafe/cryptography/curve25519/EdwardsPoint;->Y:Lcafe/cryptography/curve25519/FieldElement;

    invoke-virtual {v2, v3}, Lcafe/cryptography/curve25519/FieldElement;->multiply(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v2

    iget-object p0, p0, Lcafe/cryptography/curve25519/RistrettoElement;->repr:Lcafe/cryptography/curve25519/EdwardsPoint;

    iget-object p0, p0, Lcafe/cryptography/curve25519/EdwardsPoint;->X:Lcafe/cryptography/curve25519/FieldElement;

    iget-object p1, p1, Lcafe/cryptography/curve25519/RistrettoElement;->repr:Lcafe/cryptography/curve25519/EdwardsPoint;

    iget-object p1, p1, Lcafe/cryptography/curve25519/EdwardsPoint;->X:Lcafe/cryptography/curve25519/FieldElement;

    invoke-virtual {p0, p1}, Lcafe/cryptography/curve25519/FieldElement;->multiply(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object p0

    invoke-virtual {v0, v1}, Lcafe/cryptography/curve25519/FieldElement;->ctEquals(Lcafe/cryptography/curve25519/FieldElement;)I

    move-result p1

    invoke-virtual {v2, p0}, Lcafe/cryptography/curve25519/FieldElement;->ctEquals(Lcafe/cryptography/curve25519/FieldElement;)I

    move-result p0

    or-int/2addr p0, p1

    return p0
.end method

.method public ctSelect(Lcafe/cryptography/curve25519/RistrettoElement;I)Lcafe/cryptography/curve25519/RistrettoElement;
    .locals 1

    new-instance v0, Lcafe/cryptography/curve25519/RistrettoElement;

    iget-object p0, p0, Lcafe/cryptography/curve25519/RistrettoElement;->repr:Lcafe/cryptography/curve25519/EdwardsPoint;

    iget-object p1, p1, Lcafe/cryptography/curve25519/RistrettoElement;->repr:Lcafe/cryptography/curve25519/EdwardsPoint;

    invoke-virtual {p0, p1, p2}, Lcafe/cryptography/curve25519/EdwardsPoint;->ctSelect(Lcafe/cryptography/curve25519/EdwardsPoint;I)Lcafe/cryptography/curve25519/EdwardsPoint;

    move-result-object p0

    invoke-direct {v0, p0}, Lcafe/cryptography/curve25519/RistrettoElement;-><init>(Lcafe/cryptography/curve25519/EdwardsPoint;)V

    return-object v0
.end method

.method public dbl()Lcafe/cryptography/curve25519/RistrettoElement;
    .locals 1

    new-instance v0, Lcafe/cryptography/curve25519/RistrettoElement;

    iget-object p0, p0, Lcafe/cryptography/curve25519/RistrettoElement;->repr:Lcafe/cryptography/curve25519/EdwardsPoint;

    invoke-virtual {p0}, Lcafe/cryptography/curve25519/EdwardsPoint;->dbl()Lcafe/cryptography/curve25519/EdwardsPoint;

    move-result-object p0

    invoke-direct {v0, p0}, Lcafe/cryptography/curve25519/RistrettoElement;-><init>(Lcafe/cryptography/curve25519/EdwardsPoint;)V

    return-object v0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 2

    instance-of v0, p1, Lcafe/cryptography/curve25519/RistrettoElement;

    const/4 v1, 0x0

    if-nez v0, :cond_0

    return v1

    :cond_0
    check-cast p1, Lcafe/cryptography/curve25519/RistrettoElement;

    invoke-virtual {p0, p1}, Lcafe/cryptography/curve25519/RistrettoElement;->ctEquals(Lcafe/cryptography/curve25519/RistrettoElement;)I

    move-result p0

    const/4 p1, 0x1

    if-ne p0, p1, :cond_1

    move v1, p1

    :cond_1
    return v1
.end method

.method public hashCode()I
    .locals 0

    invoke-virtual {p0}, Lcafe/cryptography/curve25519/RistrettoElement;->compress()Lcafe/cryptography/curve25519/CompressedRistretto;

    move-result-object p0

    invoke-virtual {p0}, Lcafe/cryptography/curve25519/CompressedRistretto;->hashCode()I

    move-result p0

    return p0
.end method

.method public multiply(Lcafe/cryptography/curve25519/Scalar;)Lcafe/cryptography/curve25519/RistrettoElement;
    .locals 1

    new-instance v0, Lcafe/cryptography/curve25519/RistrettoElement;

    iget-object p0, p0, Lcafe/cryptography/curve25519/RistrettoElement;->repr:Lcafe/cryptography/curve25519/EdwardsPoint;

    invoke-virtual {p0, p1}, Lcafe/cryptography/curve25519/EdwardsPoint;->multiply(Lcafe/cryptography/curve25519/Scalar;)Lcafe/cryptography/curve25519/EdwardsPoint;

    move-result-object p0

    invoke-direct {v0, p0}, Lcafe/cryptography/curve25519/RistrettoElement;-><init>(Lcafe/cryptography/curve25519/EdwardsPoint;)V

    return-object v0
.end method

.method public negate()Lcafe/cryptography/curve25519/RistrettoElement;
    .locals 1

    new-instance v0, Lcafe/cryptography/curve25519/RistrettoElement;

    iget-object p0, p0, Lcafe/cryptography/curve25519/RistrettoElement;->repr:Lcafe/cryptography/curve25519/EdwardsPoint;

    invoke-virtual {p0}, Lcafe/cryptography/curve25519/EdwardsPoint;->negate()Lcafe/cryptography/curve25519/EdwardsPoint;

    move-result-object p0

    invoke-direct {v0, p0}, Lcafe/cryptography/curve25519/RistrettoElement;-><init>(Lcafe/cryptography/curve25519/EdwardsPoint;)V

    return-object v0
.end method

.method public printInternalRepresentation()Ljava/lang/String;
    .locals 2

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "RistrettoElement("

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object p0, p0, Lcafe/cryptography/curve25519/RistrettoElement;->repr:Lcafe/cryptography/curve25519/EdwardsPoint;

    invoke-virtual {p0}, Lcafe/cryptography/curve25519/EdwardsPoint;->printInternalRepresentation()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p0, ")"

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public subtract(Lcafe/cryptography/curve25519/RistrettoElement;)Lcafe/cryptography/curve25519/RistrettoElement;
    .locals 1

    new-instance v0, Lcafe/cryptography/curve25519/RistrettoElement;

    iget-object p0, p0, Lcafe/cryptography/curve25519/RistrettoElement;->repr:Lcafe/cryptography/curve25519/EdwardsPoint;

    iget-object p1, p1, Lcafe/cryptography/curve25519/RistrettoElement;->repr:Lcafe/cryptography/curve25519/EdwardsPoint;

    invoke-virtual {p0, p1}, Lcafe/cryptography/curve25519/EdwardsPoint;->subtract(Lcafe/cryptography/curve25519/EdwardsPoint;)Lcafe/cryptography/curve25519/EdwardsPoint;

    move-result-object p0

    invoke-direct {v0, p0}, Lcafe/cryptography/curve25519/RistrettoElement;-><init>(Lcafe/cryptography/curve25519/EdwardsPoint;)V

    return-object v0
.end method
