.class Lcafe/cryptography/curve25519/ProjectivePoint;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field final X:Lcafe/cryptography/curve25519/FieldElement;

.field final Y:Lcafe/cryptography/curve25519/FieldElement;

.field final Z:Lcafe/cryptography/curve25519/FieldElement;


# direct methods
.method public constructor <init>(Lcafe/cryptography/curve25519/FieldElement;Lcafe/cryptography/curve25519/FieldElement;Lcafe/cryptography/curve25519/FieldElement;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcafe/cryptography/curve25519/ProjectivePoint;->X:Lcafe/cryptography/curve25519/FieldElement;

    iput-object p2, p0, Lcafe/cryptography/curve25519/ProjectivePoint;->Y:Lcafe/cryptography/curve25519/FieldElement;

    iput-object p3, p0, Lcafe/cryptography/curve25519/ProjectivePoint;->Z:Lcafe/cryptography/curve25519/FieldElement;

    return-void
.end method


# virtual methods
.method public dbl()Lcafe/cryptography/curve25519/CompletedPoint;
    .locals 4

    iget-object v0, p0, Lcafe/cryptography/curve25519/ProjectivePoint;->X:Lcafe/cryptography/curve25519/FieldElement;

    invoke-virtual {v0}, Lcafe/cryptography/curve25519/FieldElement;->square()Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v0

    iget-object v1, p0, Lcafe/cryptography/curve25519/ProjectivePoint;->Y:Lcafe/cryptography/curve25519/FieldElement;

    invoke-virtual {v1}, Lcafe/cryptography/curve25519/FieldElement;->square()Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v1

    iget-object v2, p0, Lcafe/cryptography/curve25519/ProjectivePoint;->Z:Lcafe/cryptography/curve25519/FieldElement;

    invoke-virtual {v2}, Lcafe/cryptography/curve25519/FieldElement;->squareAndDouble()Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v2

    iget-object v3, p0, Lcafe/cryptography/curve25519/ProjectivePoint;->X:Lcafe/cryptography/curve25519/FieldElement;

    iget-object p0, p0, Lcafe/cryptography/curve25519/ProjectivePoint;->Y:Lcafe/cryptography/curve25519/FieldElement;

    invoke-virtual {v3, p0}, Lcafe/cryptography/curve25519/FieldElement;->add(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object p0

    invoke-virtual {p0}, Lcafe/cryptography/curve25519/FieldElement;->square()Lcafe/cryptography/curve25519/FieldElement;

    move-result-object p0

    invoke-virtual {v1, v0}, Lcafe/cryptography/curve25519/FieldElement;->add(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v3

    invoke-virtual {v1, v0}, Lcafe/cryptography/curve25519/FieldElement;->subtract(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v0

    new-instance v1, Lcafe/cryptography/curve25519/CompletedPoint;

    invoke-virtual {p0, v3}, Lcafe/cryptography/curve25519/FieldElement;->subtract(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object p0

    invoke-virtual {v2, v0}, Lcafe/cryptography/curve25519/FieldElement;->subtract(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v2

    invoke-direct {v1, p0, v3, v0, v2}, Lcafe/cryptography/curve25519/CompletedPoint;-><init>(Lcafe/cryptography/curve25519/FieldElement;Lcafe/cryptography/curve25519/FieldElement;Lcafe/cryptography/curve25519/FieldElement;Lcafe/cryptography/curve25519/FieldElement;)V

    return-object v1
.end method

.method public toExtended()Lcafe/cryptography/curve25519/EdwardsPoint;
    .locals 5

    new-instance v0, Lcafe/cryptography/curve25519/EdwardsPoint;

    iget-object v1, p0, Lcafe/cryptography/curve25519/ProjectivePoint;->X:Lcafe/cryptography/curve25519/FieldElement;

    iget-object v2, p0, Lcafe/cryptography/curve25519/ProjectivePoint;->Z:Lcafe/cryptography/curve25519/FieldElement;

    invoke-virtual {v1, v2}, Lcafe/cryptography/curve25519/FieldElement;->multiply(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v1

    iget-object v2, p0, Lcafe/cryptography/curve25519/ProjectivePoint;->Y:Lcafe/cryptography/curve25519/FieldElement;

    iget-object v3, p0, Lcafe/cryptography/curve25519/ProjectivePoint;->Z:Lcafe/cryptography/curve25519/FieldElement;

    invoke-virtual {v2, v3}, Lcafe/cryptography/curve25519/FieldElement;->multiply(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v2

    iget-object v3, p0, Lcafe/cryptography/curve25519/ProjectivePoint;->Z:Lcafe/cryptography/curve25519/FieldElement;

    invoke-virtual {v3}, Lcafe/cryptography/curve25519/FieldElement;->square()Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v3

    iget-object v4, p0, Lcafe/cryptography/curve25519/ProjectivePoint;->X:Lcafe/cryptography/curve25519/FieldElement;

    iget-object p0, p0, Lcafe/cryptography/curve25519/ProjectivePoint;->Y:Lcafe/cryptography/curve25519/FieldElement;

    invoke-virtual {v4, p0}, Lcafe/cryptography/curve25519/FieldElement;->multiply(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object p0

    invoke-direct {v0, v1, v2, v3, p0}, Lcafe/cryptography/curve25519/EdwardsPoint;-><init>(Lcafe/cryptography/curve25519/FieldElement;Lcafe/cryptography/curve25519/FieldElement;Lcafe/cryptography/curve25519/FieldElement;Lcafe/cryptography/curve25519/FieldElement;)V

    return-object v0
.end method
