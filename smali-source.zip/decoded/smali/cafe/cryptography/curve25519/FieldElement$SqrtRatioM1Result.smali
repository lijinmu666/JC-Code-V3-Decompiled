.class Lcafe/cryptography/curve25519/FieldElement$SqrtRatioM1Result;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcafe/cryptography/curve25519/FieldElement;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "SqrtRatioM1Result"
.end annotation


# instance fields
.field result:Lcafe/cryptography/curve25519/FieldElement;

.field wasSquare:I


# direct methods
.method public constructor <init>(ILcafe/cryptography/curve25519/FieldElement;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, Lcafe/cryptography/curve25519/FieldElement$SqrtRatioM1Result;->wasSquare:I

    iput-object p2, p0, Lcafe/cryptography/curve25519/FieldElement$SqrtRatioM1Result;->result:Lcafe/cryptography/curve25519/FieldElement;

    return-void
.end method
