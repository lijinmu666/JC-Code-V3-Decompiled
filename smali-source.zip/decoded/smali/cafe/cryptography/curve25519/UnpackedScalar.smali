.class Lcafe/cryptography/curve25519/UnpackedScalar;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field static final MASK_24_BITS:I = 0xffffff

.field static final MASK_29_BITS:I = 0x1fffffff

.field static final ZERO:Lcafe/cryptography/curve25519/UnpackedScalar;


# instance fields
.field final s:[I


# direct methods
.method static constructor <clinit>()V
    .locals 2

    new-instance v0, Lcafe/cryptography/curve25519/UnpackedScalar;

    const/16 v1, 0x9

    new-array v1, v1, [I

    fill-array-data v1, :array_0

    invoke-direct {v0, v1}, Lcafe/cryptography/curve25519/UnpackedScalar;-><init>([I)V

    sput-object v0, Lcafe/cryptography/curve25519/UnpackedScalar;->ZERO:Lcafe/cryptography/curve25519/UnpackedScalar;

    return-void

    nop

    :array_0
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data
.end method

.method public constructor <init>([I)V
    .locals 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    array-length v0, p1

    const/16 v1, 0x9

    if-ne v0, v1, :cond_0

    iput-object p1, p0, Lcafe/cryptography/curve25519/UnpackedScalar;->s:[I

    return-void

    :cond_0
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string p1, "Invalid radix-2^29 representation"

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public static fromByteArray([B)Lcafe/cryptography/curve25519/UnpackedScalar;
    .locals 14

    array-length v0, p0

    const/16 v1, 0x20

    if-ne v0, v1, :cond_2

    const/16 v0, 0x8

    new-array v1, v0, [I

    const/4 v2, 0x0

    move v3, v2

    :goto_0
    const/4 v4, 0x4

    if-ge v3, v0, :cond_1

    move v5, v2

    :goto_1
    if-ge v5, v4, :cond_0

    aget v6, v1, v3

    mul-int/lit8 v7, v3, 0x4

    add-int/2addr v7, v5

    aget-byte v7, p0, v7

    and-int/lit16 v7, v7, 0xff

    mul-int/lit8 v8, v5, 0x8

    shl-int/2addr v7, v8

    or-int/2addr v6, v7

    aput v6, v1, v3

    add-int/lit8 v5, v5, 0x1

    goto :goto_1

    :cond_0
    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    :cond_1
    aget p0, v1, v2

    const v2, 0x1fffffff

    and-int v5, p0, v2

    ushr-int/lit8 p0, p0, 0x1d

    const/4 v3, 0x1

    aget v3, v1, v3

    shl-int/lit8 v6, v3, 0x3

    or-int/2addr p0, v6

    and-int v6, p0, v2

    ushr-int/lit8 p0, v3, 0x1a

    const/4 v3, 0x2

    aget v3, v1, v3

    shl-int/lit8 v7, v3, 0x6

    or-int/2addr p0, v7

    and-int v7, p0, v2

    ushr-int/lit8 p0, v3, 0x17

    const/4 v3, 0x3

    aget v3, v1, v3

    shl-int/lit8 v8, v3, 0x9

    or-int/2addr p0, v8

    and-int v8, p0, v2

    ushr-int/lit8 p0, v3, 0x14

    aget v3, v1, v4

    shl-int/lit8 v4, v3, 0xc

    or-int/2addr p0, v4

    and-int v9, p0, v2

    ushr-int/lit8 p0, v3, 0x11

    const/4 v3, 0x5

    aget v3, v1, v3

    shl-int/lit8 v4, v3, 0xf

    or-int/2addr p0, v4

    and-int v10, p0, v2

    ushr-int/lit8 p0, v3, 0xe

    const/4 v3, 0x6

    aget v3, v1, v3

    shl-int/lit8 v4, v3, 0x12

    or-int/2addr p0, v4

    and-int v11, p0, v2

    ushr-int/lit8 p0, v3, 0xb

    const/4 v3, 0x7

    aget v1, v1, v3

    shl-int/lit8 v3, v1, 0x15

    or-int/2addr p0, v3

    and-int v12, p0, v2

    ushr-int/lit8 p0, v1, 0x8

    const v0, 0xffffff

    and-int v13, p0, v0

    filled-new-array/range {v5 .. v13}, [I

    move-result-object p0

    new-instance v0, Lcafe/cryptography/curve25519/UnpackedScalar;

    invoke-direct {v0, p0}, Lcafe/cryptography/curve25519/UnpackedScalar;-><init>([I)V

    return-object v0

    :cond_2
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string v0, "Input must by 32 bytes"

    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public static m(II)J
    .locals 2

    int-to-long v0, p0

    int-to-long p0, p1

    mul-long/2addr v0, p0

    return-wide v0
.end method

.method public static montgomeryReduce([J)Lcafe/cryptography/curve25519/UnpackedScalar;
    .locals 31

    sget-object v0, Lcafe/cryptography/curve25519/Constants;->L:Lcafe/cryptography/curve25519/UnpackedScalar;

    iget-object v1, v0, Lcafe/cryptography/curve25519/UnpackedScalar;->s:[I

    const/4 v2, 0x0

    aget-wide v3, p0, v2

    const-wide/32 v5, 0x12547e1b

    mul-long v7, v3, v5

    const-wide/32 v9, 0x1fffffff

    and-long/2addr v7, v9

    long-to-int v7, v7

    aget v8, v1, v2

    invoke-static {v7, v8}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v11

    add-long/2addr v3, v11

    const/16 v8, 0x1d

    ushr-long/2addr v3, v8

    const/4 v11, 0x1

    aget-wide v12, p0, v11

    add-long/2addr v3, v12

    aget v12, v1, v11

    invoke-static {v7, v12}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v12

    add-long/2addr v3, v12

    mul-long v12, v3, v5

    and-long/2addr v12, v9

    long-to-int v12, v12

    aget v13, v1, v2

    invoke-static {v12, v13}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v13

    add-long/2addr v3, v13

    ushr-long/2addr v3, v8

    const/4 v13, 0x2

    aget-wide v14, p0, v13

    add-long/2addr v3, v14

    aget v14, v1, v13

    invoke-static {v7, v14}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v14

    add-long/2addr v3, v14

    aget v14, v1, v11

    invoke-static {v12, v14}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v14

    add-long/2addr v3, v14

    mul-long v14, v3, v5

    and-long/2addr v14, v9

    long-to-int v14, v14

    aget v15, v1, v2

    invoke-static {v14, v15}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v15

    add-long/2addr v3, v15

    ushr-long/2addr v3, v8

    const/4 v15, 0x3

    aget-wide v16, p0, v15

    add-long v3, v3, v16

    aget v8, v1, v15

    invoke-static {v7, v8}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v17

    add-long v3, v3, v17

    aget v8, v1, v13

    invoke-static {v12, v8}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v17

    add-long v3, v3, v17

    aget v8, v1, v11

    invoke-static {v14, v8}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v17

    add-long v3, v3, v17

    mul-long v17, v3, v5

    and-long v5, v17, v9

    long-to-int v5, v5

    aget v6, v1, v2

    invoke-static {v5, v6}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v17

    add-long v3, v3, v17

    const/16 v6, 0x1d

    ushr-long/2addr v3, v6

    const/4 v6, 0x4

    aget-wide v17, p0, v6

    add-long v3, v3, v17

    aget v8, v1, v6

    invoke-static {v7, v8}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v17

    add-long v3, v3, v17

    aget v8, v1, v15

    invoke-static {v12, v8}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v17

    add-long v3, v3, v17

    aget v8, v1, v13

    invoke-static {v14, v8}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v17

    add-long v3, v3, v17

    aget v8, v1, v11

    invoke-static {v5, v8}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v17

    add-long v3, v3, v17

    const-wide/32 v17, 0x12547e1b

    mul-long v21, v3, v17

    move/from16 v17, v14

    and-long v13, v21, v9

    long-to-int v13, v13

    aget v14, v1, v2

    invoke-static {v13, v14}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v21

    add-long v3, v3, v21

    const/16 v14, 0x1d

    ushr-long/2addr v3, v14

    const/4 v14, 0x5

    aget-wide v21, p0, v14

    add-long v3, v3, v21

    aget v14, v1, v6

    invoke-static {v12, v14}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v21

    add-long v3, v3, v21

    aget v14, v1, v15

    move/from16 v8, v17

    invoke-static {v8, v14}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v21

    add-long v3, v3, v21

    const/4 v14, 0x2

    aget v15, v1, v14

    invoke-static {v5, v15}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v21

    add-long v3, v3, v21

    aget v15, v1, v11

    invoke-static {v13, v15}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v21

    add-long v3, v3, v21

    const-wide/32 v18, 0x12547e1b

    mul-long v21, v3, v18

    and-long v14, v21, v9

    long-to-int v14, v14

    aget v15, v1, v2

    invoke-static {v14, v15}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v21

    add-long v3, v3, v21

    const/16 v15, 0x1d

    ushr-long/2addr v3, v15

    const/4 v15, 0x6

    aget-wide v21, p0, v15

    add-long v3, v3, v21

    aget v15, v1, v6

    invoke-static {v8, v15}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v21

    add-long v3, v3, v21

    const/4 v15, 0x3

    aget v6, v1, v15

    invoke-static {v5, v6}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v22

    add-long v3, v3, v22

    const/4 v6, 0x2

    aget v15, v1, v6

    invoke-static {v13, v15}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v22

    add-long v3, v3, v22

    aget v15, v1, v11

    invoke-static {v14, v15}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v22

    add-long v3, v3, v22

    const-wide/32 v18, 0x12547e1b

    mul-long v22, v3, v18

    move v15, v7

    and-long v6, v22, v9

    long-to-int v6, v6

    aget v7, v1, v2

    invoke-static {v6, v7}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v22

    add-long v3, v3, v22

    const/16 v7, 0x1d

    ushr-long/2addr v3, v7

    const/4 v7, 0x7

    aget-wide v22, p0, v7

    add-long v3, v3, v22

    const/4 v7, 0x4

    aget v2, v1, v7

    invoke-static {v5, v2}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v23

    add-long v3, v3, v23

    const/4 v2, 0x3

    aget v7, v1, v2

    invoke-static {v13, v7}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v23

    add-long v3, v3, v23

    const/4 v2, 0x2

    aget v7, v1, v2

    invoke-static {v14, v7}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v23

    add-long v3, v3, v23

    aget v7, v1, v11

    invoke-static {v6, v7}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v23

    add-long v3, v3, v23

    const-wide/32 v18, 0x12547e1b

    mul-long v23, v3, v18

    move/from16 v18, v12

    and-long v11, v23, v9

    long-to-int v11, v11

    const/4 v12, 0x0

    aget v2, v1, v12

    invoke-static {v11, v2}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v24

    add-long v3, v3, v24

    const/16 v2, 0x1d

    ushr-long/2addr v3, v2

    const/16 v2, 0x8

    aget-wide v24, p0, v2

    add-long v3, v3, v24

    aget v12, v1, v2

    invoke-static {v15, v12}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v24

    add-long v3, v3, v24

    const/4 v12, 0x4

    aget v15, v1, v12

    invoke-static {v13, v15}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v24

    add-long v3, v3, v24

    const/4 v12, 0x3

    aget v15, v1, v12

    invoke-static {v14, v15}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v24

    add-long v3, v3, v24

    const/4 v12, 0x2

    aget v15, v1, v12

    invoke-static {v6, v15}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v23

    add-long v3, v3, v23

    const/4 v7, 0x1

    aget v15, v1, v7

    invoke-static {v11, v15}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v23

    add-long v3, v3, v23

    const-wide/32 v19, 0x12547e1b

    mul-long v19, v19, v3

    move v15, v13

    and-long v12, v19, v9

    long-to-int v12, v12

    const/4 v13, 0x0

    aget v13, v1, v13

    invoke-static {v12, v13}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v19

    add-long v3, v3, v19

    const/16 v13, 0x1d

    ushr-long/2addr v3, v13

    const/16 v13, 0x9

    aget-wide v19, p0, v13

    add-long v3, v3, v19

    aget v13, v1, v2

    move/from16 v7, v18

    invoke-static {v7, v13}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v24

    add-long v3, v3, v24

    const/4 v7, 0x4

    aget v13, v1, v7

    invoke-static {v14, v13}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v24

    add-long v3, v3, v24

    const/4 v7, 0x3

    aget v13, v1, v7

    invoke-static {v6, v13}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v24

    add-long v3, v3, v24

    const/4 v7, 0x2

    aget v13, v1, v7

    invoke-static {v11, v13}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v22

    add-long v3, v3, v22

    const/4 v13, 0x1

    aget v13, v1, v13

    invoke-static {v12, v13}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v18

    add-long v3, v3, v18

    move v13, v8

    and-long v7, v3, v9

    long-to-int v7, v7

    const/16 v8, 0x1d

    ushr-long/2addr v3, v8

    const/16 v8, 0xa

    aget-wide v19, p0, v8

    add-long v3, v3, v19

    aget v8, v1, v2

    invoke-static {v13, v8}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v19

    add-long v3, v3, v19

    const/4 v8, 0x4

    aget v13, v1, v8

    invoke-static {v6, v13}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v19

    add-long v3, v3, v19

    const/4 v8, 0x3

    aget v13, v1, v8

    invoke-static {v11, v13}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v19

    add-long v3, v3, v19

    const/4 v8, 0x2

    aget v8, v1, v8

    invoke-static {v12, v8}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v18

    add-long v3, v3, v18

    move v13, v7

    and-long v7, v3, v9

    long-to-int v7, v7

    const/16 v8, 0x1d

    ushr-long/2addr v3, v8

    const/16 v8, 0xb

    aget-wide v18, p0, v8

    add-long v3, v3, v18

    aget v8, v1, v2

    invoke-static {v5, v8}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v18

    add-long v3, v3, v18

    const/4 v5, 0x4

    aget v8, v1, v5

    invoke-static {v11, v8}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v18

    add-long v3, v3, v18

    const/4 v5, 0x3

    aget v5, v1, v5

    invoke-static {v12, v5}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v17

    add-long v3, v3, v17

    move v5, v7

    and-long v7, v3, v9

    long-to-int v7, v7

    const/16 v8, 0x1d

    ushr-long/2addr v3, v8

    const/16 v8, 0xc

    aget-wide v17, p0, v8

    add-long v3, v3, v17

    aget v8, v1, v2

    invoke-static {v15, v8}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v17

    add-long v3, v3, v17

    const/4 v8, 0x4

    aget v8, v1, v8

    invoke-static {v12, v8}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v17

    add-long v3, v3, v17

    move v15, v7

    and-long v7, v3, v9

    long-to-int v7, v7

    const/16 v8, 0x1d

    ushr-long/2addr v3, v8

    const/16 v16, 0xd

    aget-wide v16, p0, v16

    add-long v3, v3, v16

    aget v8, v1, v2

    invoke-static {v14, v8}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v17

    add-long v3, v3, v17

    move v14, v7

    and-long v7, v3, v9

    long-to-int v7, v7

    const/16 v8, 0x1d

    ushr-long/2addr v3, v8

    const/16 v16, 0xe

    aget-wide v16, p0, v16

    add-long v3, v3, v16

    aget v8, v1, v2

    invoke-static {v6, v8}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v17

    add-long v3, v3, v17

    move v8, v7

    and-long v6, v3, v9

    long-to-int v6, v6

    const/16 v7, 0x1d

    ushr-long/2addr v3, v7

    const/16 v16, 0xf

    aget-wide v16, p0, v16

    add-long v3, v3, v16

    aget v7, v1, v2

    invoke-static {v11, v7}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v17

    add-long v3, v3, v17

    move v11, v6

    and-long v6, v3, v9

    long-to-int v6, v6

    const/16 v7, 0x1d

    ushr-long/2addr v3, v7

    const/16 v16, 0x10

    aget-wide v16, p0, v16

    add-long v3, v3, v16

    aget v1, v1, v2

    invoke-static {v12, v1}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v1

    add-long/2addr v3, v1

    and-long v1, v3, v9

    long-to-int v1, v1

    ushr-long v2, v3, v7

    long-to-int v2, v2

    move/from16 v22, v13

    move/from16 v23, v5

    move/from16 v24, v15

    move/from16 v25, v14

    move/from16 v26, v8

    move/from16 v27, v11

    move/from16 v28, v6

    move/from16 v29, v1

    move/from16 v30, v2

    filled-new-array/range {v22 .. v30}, [I

    move-result-object v1

    new-instance v2, Lcafe/cryptography/curve25519/UnpackedScalar;

    invoke-direct {v2, v1}, Lcafe/cryptography/curve25519/UnpackedScalar;-><init>([I)V

    invoke-virtual {v2, v0}, Lcafe/cryptography/curve25519/UnpackedScalar;->subtract(Lcafe/cryptography/curve25519/UnpackedScalar;)Lcafe/cryptography/curve25519/UnpackedScalar;

    move-result-object v0

    return-object v0
.end method


# virtual methods
.method public add(Lcafe/cryptography/curve25519/UnpackedScalar;)Lcafe/cryptography/curve25519/UnpackedScalar;
    .locals 6

    const/16 v0, 0x9

    new-array v1, v0, [I

    const/4 v2, 0x0

    move v3, v2

    :goto_0
    if-ge v2, v0, :cond_0

    iget-object v4, p0, Lcafe/cryptography/curve25519/UnpackedScalar;->s:[I

    aget v4, v4, v2

    iget-object v5, p1, Lcafe/cryptography/curve25519/UnpackedScalar;->s:[I

    aget v5, v5, v2

    add-int/2addr v4, v5

    shr-int/lit8 v3, v3, 0x1d

    add-int/2addr v3, v4

    const v4, 0x1fffffff

    and-int/2addr v4, v3

    aput v4, v1, v2

    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_0
    new-instance p0, Lcafe/cryptography/curve25519/UnpackedScalar;

    invoke-direct {p0, v1}, Lcafe/cryptography/curve25519/UnpackedScalar;-><init>([I)V

    sget-object p1, Lcafe/cryptography/curve25519/Constants;->L:Lcafe/cryptography/curve25519/UnpackedScalar;

    invoke-virtual {p0, p1}, Lcafe/cryptography/curve25519/UnpackedScalar;->subtract(Lcafe/cryptography/curve25519/UnpackedScalar;)Lcafe/cryptography/curve25519/UnpackedScalar;

    move-result-object p0

    return-object p0
.end method

.method public mulInternal(Lcafe/cryptography/curve25519/UnpackedScalar;)[J
    .locals 27

    move-object/from16 v0, p0

    iget-object v0, v0, Lcafe/cryptography/curve25519/UnpackedScalar;->s:[I

    move-object/from16 v1, p1

    iget-object v1, v1, Lcafe/cryptography/curve25519/UnpackedScalar;->s:[I

    const/16 v2, 0x11

    new-array v2, v2, [J

    const/4 v3, 0x0

    aget v4, v0, v3

    aget v5, v1, v3

    invoke-static {v4, v5}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v4

    aput-wide v4, v2, v3

    aget v4, v0, v3

    const/4 v5, 0x1

    aget v6, v1, v5

    invoke-static {v4, v6}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v6

    aget v4, v0, v5

    aget v8, v1, v3

    invoke-static {v4, v8}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v8

    add-long/2addr v6, v8

    aput-wide v6, v2, v5

    aget v4, v0, v3

    const/4 v6, 0x2

    aget v7, v1, v6

    invoke-static {v4, v7}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v7

    aget v4, v0, v5

    aget v9, v1, v5

    invoke-static {v4, v9}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v9

    add-long/2addr v7, v9

    aget v4, v0, v6

    aget v9, v1, v3

    invoke-static {v4, v9}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v9

    add-long/2addr v7, v9

    aput-wide v7, v2, v6

    aget v4, v0, v3

    const/4 v7, 0x3

    aget v8, v1, v7

    invoke-static {v4, v8}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v8

    aget v4, v0, v5

    aget v10, v1, v6

    invoke-static {v4, v10}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v10

    add-long/2addr v8, v10

    aget v4, v0, v6

    aget v10, v1, v5

    invoke-static {v4, v10}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v10

    add-long/2addr v8, v10

    aget v4, v0, v7

    aget v10, v1, v3

    invoke-static {v4, v10}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v10

    add-long/2addr v8, v10

    aput-wide v8, v2, v7

    aget v4, v0, v3

    const/4 v8, 0x4

    aget v9, v1, v8

    invoke-static {v4, v9}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v9

    aget v4, v0, v5

    aget v11, v1, v7

    invoke-static {v4, v11}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v11

    add-long/2addr v9, v11

    aget v4, v0, v6

    aget v11, v1, v6

    invoke-static {v4, v11}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v11

    add-long/2addr v9, v11

    aget v4, v0, v7

    aget v11, v1, v5

    invoke-static {v4, v11}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v11

    add-long/2addr v9, v11

    aget v4, v0, v8

    aget v11, v1, v3

    invoke-static {v4, v11}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v11

    add-long/2addr v9, v11

    aput-wide v9, v2, v8

    aget v4, v0, v5

    aget v9, v1, v8

    invoke-static {v4, v9}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v9

    aget v4, v0, v6

    aget v11, v1, v7

    invoke-static {v4, v11}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v11

    add-long/2addr v9, v11

    aget v4, v0, v7

    aget v11, v1, v6

    invoke-static {v4, v11}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v11

    add-long/2addr v9, v11

    aget v4, v0, v8

    aget v11, v1, v5

    invoke-static {v4, v11}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v11

    add-long/2addr v9, v11

    const/4 v4, 0x5

    aput-wide v9, v2, v4

    aget v9, v0, v6

    aget v10, v1, v8

    invoke-static {v9, v10}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v9

    aget v11, v0, v7

    aget v12, v1, v7

    invoke-static {v11, v12}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v11

    add-long/2addr v9, v11

    aget v11, v0, v8

    aget v12, v1, v6

    invoke-static {v11, v12}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v11

    add-long/2addr v9, v11

    const/4 v11, 0x6

    aput-wide v9, v2, v11

    aget v9, v0, v7

    aget v10, v1, v8

    invoke-static {v9, v10}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v9

    aget v12, v0, v8

    aget v13, v1, v7

    invoke-static {v12, v13}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v12

    add-long/2addr v9, v12

    const/4 v12, 0x7

    aput-wide v9, v2, v12

    aget v9, v0, v8

    aget v10, v1, v8

    invoke-static {v9, v10}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v9

    aget-wide v13, v2, v7

    sub-long/2addr v9, v13

    const/16 v13, 0x8

    aput-wide v9, v2, v13

    aget-wide v9, v2, v4

    aget v14, v0, v4

    aget v15, v1, v4

    invoke-static {v14, v15}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v14

    sub-long/2addr v9, v14

    const/16 v14, 0xa

    aput-wide v9, v2, v14

    aget-wide v9, v2, v11

    aget v15, v0, v4

    aget v7, v1, v11

    invoke-static {v15, v7}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v15

    aget v7, v0, v11

    aget v8, v1, v4

    invoke-static {v7, v8}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v7

    add-long/2addr v15, v7

    sub-long/2addr v9, v15

    const/16 v7, 0xb

    aput-wide v9, v2, v7

    aget-wide v8, v2, v12

    aget v10, v0, v4

    aget v15, v1, v12

    invoke-static {v10, v15}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v15

    aget v10, v0, v11

    aget v6, v1, v11

    invoke-static {v10, v6}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v18

    add-long v15, v15, v18

    aget v6, v0, v12

    aget v10, v1, v4

    invoke-static {v6, v10}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v18

    add-long v15, v15, v18

    sub-long/2addr v8, v15

    const/16 v6, 0xc

    aput-wide v8, v2, v6

    aget v8, v0, v4

    aget v9, v1, v13

    invoke-static {v8, v9}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v8

    aget v10, v0, v11

    aget v15, v1, v12

    invoke-static {v10, v15}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v15

    add-long/2addr v8, v15

    aget v10, v0, v12

    aget v15, v1, v11

    invoke-static {v10, v15}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v15

    add-long/2addr v8, v15

    aget v10, v0, v13

    aget v15, v1, v4

    invoke-static {v10, v15}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v15

    add-long/2addr v8, v15

    const/16 v10, 0xd

    aput-wide v8, v2, v10

    aget v8, v0, v11

    aget v9, v1, v13

    invoke-static {v8, v9}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v8

    aget v15, v0, v12

    aget v10, v1, v12

    invoke-static {v15, v10}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v18

    add-long v8, v8, v18

    aget v10, v0, v13

    aget v15, v1, v11

    invoke-static {v10, v15}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v18

    add-long v8, v8, v18

    const/16 v10, 0xe

    aput-wide v8, v2, v10

    aget v8, v0, v12

    aget v9, v1, v13

    invoke-static {v8, v9}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v8

    aget v15, v0, v13

    aget v10, v1, v12

    invoke-static {v15, v10}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v19

    add-long v8, v8, v19

    const/16 v10, 0xf

    aput-wide v8, v2, v10

    aget v8, v0, v13

    aget v9, v1, v13

    invoke-static {v8, v9}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v8

    const/16 v15, 0x10

    aput-wide v8, v2, v15

    aget-wide v19, v2, v14

    aget-wide v21, v2, v3

    sub-long v21, v19, v21

    aput-wide v21, v2, v4

    aget-wide v21, v2, v7

    aget-wide v23, v2, v5

    sub-long v23, v21, v23

    aput-wide v23, v2, v11

    aget-wide v23, v2, v6

    const/4 v15, 0x2

    aget-wide v25, v2, v15

    sub-long v23, v23, v25

    aput-wide v23, v2, v12

    aget-wide v23, v2, v13

    const/16 v15, 0xd

    aget-wide v15, v2, v15

    sub-long v23, v23, v15

    aput-wide v23, v2, v13

    const/16 v15, 0xe

    aget-wide v15, v2, v15

    const/16 v18, 0x4

    aget-wide v23, v2, v18

    add-long v15, v15, v23

    const/16 v18, 0x9

    aput-wide v15, v2, v18

    aget-wide v15, v2, v10

    add-long v15, v15, v19

    aput-wide v15, v2, v14

    add-long v8, v8, v21

    aput-wide v8, v2, v7

    aget v8, v0, v3

    aget v9, v0, v4

    add-int/2addr v8, v9

    aget v9, v0, v5

    aget v10, v0, v11

    add-int/2addr v9, v10

    const/4 v10, 0x2

    aget v15, v0, v10

    aget v10, v0, v12

    add-int/2addr v15, v10

    const/4 v10, 0x3

    aget v16, v0, v10

    aget v10, v0, v13

    add-int v10, v16, v10

    aget v3, v1, v3

    aget v16, v1, v4

    add-int v3, v3, v16

    aget v5, v1, v5

    aget v16, v1, v11

    add-int v5, v5, v16

    const/16 v16, 0x2

    aget v16, v1, v16

    aget v17, v1, v12

    add-int v6, v16, v17

    const/16 v16, 0x3

    aget v16, v1, v16

    aget v17, v1, v13

    add-int v7, v16, v17

    invoke-static {v8, v3}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v16

    aget-wide v20, v2, v4

    add-long v16, v16, v20

    aput-wide v16, v2, v4

    invoke-static {v8, v5}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v16

    invoke-static {v9, v3}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v20

    add-long v16, v16, v20

    aget-wide v20, v2, v11

    add-long v16, v16, v20

    aput-wide v16, v2, v11

    invoke-static {v8, v6}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v16

    invoke-static {v9, v5}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v20

    add-long v16, v16, v20

    invoke-static {v15, v3}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v20

    add-long v16, v16, v20

    aget-wide v20, v2, v12

    add-long v16, v16, v20

    aput-wide v16, v2, v12

    invoke-static {v8, v7}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v11

    invoke-static {v9, v6}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v16

    add-long v11, v11, v16

    invoke-static {v15, v5}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v16

    add-long v11, v11, v16

    invoke-static {v10, v3}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v16

    add-long v11, v11, v16

    aget-wide v16, v2, v13

    add-long v11, v11, v16

    aput-wide v11, v2, v13

    const/4 v4, 0x4

    aget v11, v1, v4

    invoke-static {v8, v11}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v11

    invoke-static {v9, v7}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v16

    add-long v11, v11, v16

    invoke-static {v15, v6}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v16

    add-long v11, v11, v16

    invoke-static {v10, v5}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v16

    add-long v11, v11, v16

    aget v8, v0, v4

    invoke-static {v8, v3}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v16

    add-long v11, v11, v16

    aget-wide v16, v2, v18

    sub-long v11, v11, v16

    aput-wide v11, v2, v18

    aget v3, v1, v4

    invoke-static {v9, v3}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v8

    invoke-static {v15, v7}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v11

    add-long/2addr v8, v11

    invoke-static {v10, v6}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v11

    add-long/2addr v8, v11

    aget v3, v0, v4

    invoke-static {v3, v5}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v11

    add-long/2addr v8, v11

    aget-wide v11, v2, v14

    sub-long/2addr v8, v11

    aput-wide v8, v2, v14

    aget v3, v1, v4

    invoke-static {v15, v3}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v8

    invoke-static {v10, v7}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v11

    add-long/2addr v8, v11

    aget v3, v0, v4

    invoke-static {v3, v6}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v5

    add-long/2addr v8, v5

    const/16 v3, 0xb

    aget-wide v5, v2, v3

    sub-long/2addr v8, v5

    aput-wide v8, v2, v3

    aget v1, v1, v4

    invoke-static {v10, v1}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v5

    aget v0, v0, v4

    invoke-static {v0, v7}, Lcafe/cryptography/curve25519/UnpackedScalar;->m(II)J

    move-result-wide v0

    add-long/2addr v5, v0

    const/16 v0, 0xc

    aget-wide v3, v2, v0

    sub-long/2addr v5, v3

    aput-wide v5, v2, v0

    return-object v2
.end method

.method public multiply(Lcafe/cryptography/curve25519/UnpackedScalar;)Lcafe/cryptography/curve25519/UnpackedScalar;
    .locals 0

    invoke-virtual {p0, p1}, Lcafe/cryptography/curve25519/UnpackedScalar;->mulInternal(Lcafe/cryptography/curve25519/UnpackedScalar;)[J

    move-result-object p0

    invoke-static {p0}, Lcafe/cryptography/curve25519/UnpackedScalar;->montgomeryReduce([J)Lcafe/cryptography/curve25519/UnpackedScalar;

    move-result-object p0

    sget-object p1, Lcafe/cryptography/curve25519/Constants;->RR:Lcafe/cryptography/curve25519/UnpackedScalar;

    invoke-virtual {p0, p1}, Lcafe/cryptography/curve25519/UnpackedScalar;->mulInternal(Lcafe/cryptography/curve25519/UnpackedScalar;)[J

    move-result-object p0

    invoke-static {p0}, Lcafe/cryptography/curve25519/UnpackedScalar;->montgomeryReduce([J)Lcafe/cryptography/curve25519/UnpackedScalar;

    move-result-object p0

    return-object p0
.end method

.method public subtract(Lcafe/cryptography/curve25519/UnpackedScalar;)Lcafe/cryptography/curve25519/UnpackedScalar;
    .locals 8

    const/16 v0, 0x9

    new-array v1, v0, [I

    const/4 v2, 0x0

    move v3, v2

    move v4, v3

    :goto_0
    const v5, 0x1fffffff

    if-ge v3, v0, :cond_0

    iget-object v6, p0, Lcafe/cryptography/curve25519/UnpackedScalar;->s:[I

    aget v6, v6, v3

    iget-object v7, p1, Lcafe/cryptography/curve25519/UnpackedScalar;->s:[I

    aget v7, v7, v3

    ushr-int/lit8 v4, v4, 0x1f

    add-int/2addr v7, v4

    sub-int v4, v6, v7

    and-int/2addr v5, v4

    aput v5, v1, v3

    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    :cond_0
    ushr-int/lit8 p0, v4, 0x1f

    xor-int/lit8 p0, p0, 0x1

    add-int/lit8 p0, p0, -0x1

    move p1, v2

    :goto_1
    if-ge v2, v0, :cond_1

    ushr-int/lit8 p1, p1, 0x1d

    aget v3, v1, v2

    add-int/2addr p1, v3

    sget-object v3, Lcafe/cryptography/curve25519/Constants;->L:Lcafe/cryptography/curve25519/UnpackedScalar;

    iget-object v3, v3, Lcafe/cryptography/curve25519/UnpackedScalar;->s:[I

    aget v3, v3, v2

    and-int/2addr v3, p0

    add-int/2addr p1, v3

    and-int v3, p1, v5

    aput v3, v1, v2

    add-int/lit8 v2, v2, 0x1

    goto :goto_1

    :cond_1
    new-instance p0, Lcafe/cryptography/curve25519/UnpackedScalar;

    invoke-direct {p0, v1}, Lcafe/cryptography/curve25519/UnpackedScalar;-><init>([I)V

    return-object p0
.end method

.method public toByteArray()[B
    .locals 53

    move-object/from16 v0, p0

    iget-object v0, v0, Lcafe/cryptography/curve25519/UnpackedScalar;->s:[I

    const/4 v1, 0x0

    aget v2, v0, v1

    int-to-byte v3, v2

    const/16 v4, 0x8

    ushr-int/lit8 v5, v2, 0x8

    int-to-byte v5, v5

    const/16 v6, 0x10

    ushr-int/lit8 v7, v2, 0x10

    int-to-byte v7, v7

    const/16 v8, 0x18

    ushr-int/2addr v2, v8

    const/4 v9, 0x1

    aget v10, v0, v9

    const/4 v11, 0x5

    shl-int/lit8 v12, v10, 0x5

    or-int/2addr v2, v12

    int-to-byte v2, v2

    const/4 v12, 0x3

    ushr-int/lit8 v13, v10, 0x3

    int-to-byte v13, v13

    const/16 v14, 0xb

    ushr-int/lit8 v15, v10, 0xb

    int-to-byte v15, v15

    const/16 v16, 0x13

    ushr-int/lit8 v8, v10, 0x13

    int-to-byte v8, v8

    const/16 v17, 0x1b

    ushr-int/lit8 v10, v10, 0x1b

    const/16 v18, 0x2

    aget v19, v0, v18

    shl-int/lit8 v20, v19, 0x2

    or-int v10, v10, v20

    int-to-byte v10, v10

    const/16 v20, 0x6

    ushr-int/lit8 v14, v19, 0x6

    int-to-byte v14, v14

    const/16 v21, 0xe

    ushr-int/lit8 v1, v19, 0xe

    int-to-byte v1, v1

    const/16 v23, 0x16

    ushr-int/lit8 v19, v19, 0x16

    aget v24, v0, v12

    const/16 v25, 0x7

    shl-int/lit8 v26, v24, 0x7

    or-int v6, v19, v26

    int-to-byte v6, v6

    ushr-int/lit8 v4, v24, 0x1

    int-to-byte v4, v4

    const/16 v26, 0x9

    ushr-int/lit8 v12, v24, 0x9

    int-to-byte v12, v12

    const/16 v29, 0x11

    ushr-int/lit8 v9, v24, 0x11

    int-to-byte v9, v9

    const/16 v31, 0x19

    ushr-int/lit8 v24, v24, 0x19

    const/16 v32, 0x4

    aget v33, v0, v32

    shl-int/lit8 v34, v33, 0x4

    or-int v11, v24, v34

    int-to-byte v11, v11

    move/from16 v24, v11

    ushr-int/lit8 v11, v33, 0x4

    int-to-byte v11, v11

    const/16 v34, 0xc

    move/from16 v36, v11

    ushr-int/lit8 v11, v33, 0xc

    int-to-byte v11, v11

    const/16 v37, 0x14

    move/from16 v38, v11

    ushr-int/lit8 v11, v33, 0x14

    int-to-byte v11, v11

    const/16 v39, 0x1c

    ushr-int/lit8 v33, v33, 0x1c

    const/16 v35, 0x5

    aget v40, v0, v35

    const/16 v30, 0x1

    shl-int/lit8 v41, v40, 0x1

    move/from16 v42, v11

    or-int v11, v33, v41

    int-to-byte v11, v11

    move/from16 v33, v11

    ushr-int/lit8 v11, v40, 0x7

    int-to-byte v11, v11

    move/from16 v41, v11

    ushr-int/lit8 v11, v40, 0xf

    int-to-byte v11, v11

    ushr-int/lit8 v40, v40, 0x17

    aget v43, v0, v20

    shl-int/lit8 v44, v43, 0x6

    move/from16 v45, v11

    or-int v11, v40, v44

    int-to-byte v11, v11

    move/from16 v40, v11

    ushr-int/lit8 v11, v43, 0x2

    int-to-byte v11, v11

    move/from16 v44, v11

    ushr-int/lit8 v11, v43, 0xa

    int-to-byte v11, v11

    move/from16 v46, v11

    ushr-int/lit8 v11, v43, 0x12

    int-to-byte v11, v11

    ushr-int/lit8 v43, v43, 0x1a

    aget v47, v0, v25

    const/16 v28, 0x3

    shl-int/lit8 v48, v47, 0x3

    move/from16 v49, v11

    or-int v11, v43, v48

    int-to-byte v11, v11

    move/from16 v43, v11

    const/16 v35, 0x5

    ushr-int/lit8 v11, v47, 0x5

    int-to-byte v11, v11

    move/from16 v48, v11

    ushr-int/lit8 v11, v47, 0xd

    int-to-byte v11, v11

    move/from16 v50, v11

    ushr-int/lit8 v11, v47, 0x15

    int-to-byte v11, v11

    const/16 v19, 0x8

    aget v0, v0, v19

    move/from16 v47, v11

    int-to-byte v11, v0

    move/from16 v51, v11

    ushr-int/lit8 v11, v0, 0x8

    int-to-byte v11, v11

    const/16 v27, 0x10

    ushr-int/lit8 v0, v0, 0x10

    int-to-byte v0, v0

    move/from16 v52, v0

    const/16 v0, 0x20

    new-array v0, v0, [B

    const/16 v22, 0x0

    aput-byte v3, v0, v22

    const/4 v3, 0x1

    aput-byte v5, v0, v3

    aput-byte v7, v0, v18

    const/4 v3, 0x3

    aput-byte v2, v0, v3

    aput-byte v13, v0, v32

    const/4 v2, 0x5

    aput-byte v15, v0, v2

    aput-byte v8, v0, v20

    aput-byte v10, v0, v25

    const/16 v2, 0x8

    aput-byte v14, v0, v2

    aput-byte v1, v0, v26

    const/16 v1, 0xa

    aput-byte v6, v0, v1

    const/16 v1, 0xb

    aput-byte v4, v0, v1

    aput-byte v12, v0, v34

    const/16 v1, 0xd

    aput-byte v9, v0, v1

    aput-byte v24, v0, v21

    const/16 v1, 0xf

    aput-byte v36, v0, v1

    const/16 v1, 0x10

    aput-byte v38, v0, v1

    aput-byte v42, v0, v29

    const/16 v1, 0x12

    aput-byte v33, v0, v1

    aput-byte v41, v0, v16

    aput-byte v45, v0, v37

    const/16 v1, 0x15

    aput-byte v40, v0, v1

    aput-byte v44, v0, v23

    const/16 v1, 0x17

    aput-byte v46, v0, v1

    const/16 v1, 0x18

    aput-byte v49, v0, v1

    aput-byte v43, v0, v31

    const/16 v1, 0x1a

    aput-byte v48, v0, v1

    aput-byte v50, v0, v17

    aput-byte v47, v0, v39

    const/16 v1, 0x1d

    aput-byte v51, v0, v1

    const/16 v1, 0x1e

    aput-byte v11, v0, v1

    const/16 v1, 0x1f

    aput-byte v52, v0, v1

    return-object v0
.end method
