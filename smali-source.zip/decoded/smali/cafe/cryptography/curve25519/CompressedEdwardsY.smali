.class public Lcafe/cryptography/curve25519/CompressedEdwardsY;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/io/Serializable;


# static fields
.field private static final serialVersionUID:J = 0x1L


# instance fields
.field private transient data:[B


# direct methods
.method public constructor <init>([B)V
    .locals 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    array-length v0, p1

    const/16 v1, 0x20

    if-ne v0, v1, :cond_0

    iput-object p1, p0, Lcafe/cryptography/curve25519/CompressedEdwardsY;->data:[B

    return-void

    :cond_0
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string p1, "Invalid CompressedEdwardsY encoding"

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method private readObject(Ljava/io/ObjectInputStream;)V
    .locals 1

    const/16 v0, 0x20

    new-array v0, v0, [B

    invoke-virtual {p1, v0}, Ljava/io/ObjectInputStream;->readFully([B)V

    iput-object v0, p0, Lcafe/cryptography/curve25519/CompressedEdwardsY;->data:[B

    return-void
.end method

.method private readObjectNoData()V
    .locals 1

    new-instance p0, Ljava/io/InvalidObjectException;

    const-string v0, "Cannot deserialize CompressedEdwardsY from no data"

    invoke-direct {p0, v0}, Ljava/io/InvalidObjectException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method private writeObject(Ljava/io/ObjectOutputStream;)V
    .locals 0

    invoke-virtual {p0}, Lcafe/cryptography/curve25519/CompressedEdwardsY;->toByteArray()[B

    move-result-object p0

    invoke-virtual {p1, p0}, Ljava/io/ObjectOutputStream;->write([B)V

    return-void
.end method


# virtual methods
.method public ctEquals(Lcafe/cryptography/curve25519/CompressedEdwardsY;)I
    .locals 0

    iget-object p0, p0, Lcafe/cryptography/curve25519/CompressedEdwardsY;->data:[B

    iget-object p1, p1, Lcafe/cryptography/curve25519/CompressedEdwardsY;->data:[B

    invoke-static {p0, p1}, Lcafe/cryptography/subtle/ConstantTime;->equal([B[B)I

    move-result p0

    return p0
.end method

.method public decompress()Lcafe/cryptography/curve25519/EdwardsPoint;
    .locals 6

    iget-object v0, p0, Lcafe/cryptography/curve25519/CompressedEdwardsY;->data:[B

    invoke-static {v0}, Lcafe/cryptography/curve25519/FieldElement;->fromByteArray([B)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v0

    invoke-virtual {v0}, Lcafe/cryptography/curve25519/FieldElement;->square()Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v1

    sget-object v2, Lcafe/cryptography/curve25519/FieldElement;->ONE:Lcafe/cryptography/curve25519/FieldElement;

    invoke-virtual {v1, v2}, Lcafe/cryptography/curve25519/FieldElement;->subtract(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v3

    sget-object v4, Lcafe/cryptography/curve25519/Constants;->EDWARDS_D:Lcafe/cryptography/curve25519/FieldElement;

    invoke-virtual {v1, v4}, Lcafe/cryptography/curve25519/FieldElement;->multiply(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v1

    invoke-virtual {v1, v2}, Lcafe/cryptography/curve25519/FieldElement;->add(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v1

    invoke-static {v3, v1}, Lcafe/cryptography/curve25519/FieldElement;->sqrtRatioM1(Lcafe/cryptography/curve25519/FieldElement;Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement$SqrtRatioM1Result;

    move-result-object v1

    iget v3, v1, Lcafe/cryptography/curve25519/FieldElement$SqrtRatioM1Result;->wasSquare:I

    const/4 v4, 0x1

    if-ne v3, v4, :cond_0

    iget-object v3, v1, Lcafe/cryptography/curve25519/FieldElement$SqrtRatioM1Result;->result:Lcafe/cryptography/curve25519/FieldElement;

    invoke-virtual {v3}, Lcafe/cryptography/curve25519/FieldElement;->negate()Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v3

    iget-object v1, v1, Lcafe/cryptography/curve25519/FieldElement$SqrtRatioM1Result;->result:Lcafe/cryptography/curve25519/FieldElement;

    invoke-virtual {v1}, Lcafe/cryptography/curve25519/FieldElement;->isNegative()I

    move-result v4

    iget-object p0, p0, Lcafe/cryptography/curve25519/CompressedEdwardsY;->data:[B

    const/16 v5, 0xff

    invoke-static {p0, v5}, Lcafe/cryptography/subtle/ConstantTime;->bit([BI)I

    move-result p0

    invoke-static {v4, p0}, Lcafe/cryptography/subtle/ConstantTime;->equal(II)I

    move-result p0

    invoke-virtual {v3, v1, p0}, Lcafe/cryptography/curve25519/FieldElement;->ctSelect(Lcafe/cryptography/curve25519/FieldElement;I)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object p0

    new-instance v1, Lcafe/cryptography/curve25519/EdwardsPoint;

    invoke-virtual {p0, v0}, Lcafe/cryptography/curve25519/FieldElement;->multiply(Lcafe/cryptography/curve25519/FieldElement;)Lcafe/cryptography/curve25519/FieldElement;

    move-result-object v3

    invoke-direct {v1, p0, v0, v2, v3}, Lcafe/cryptography/curve25519/EdwardsPoint;-><init>(Lcafe/cryptography/curve25519/FieldElement;Lcafe/cryptography/curve25519/FieldElement;Lcafe/cryptography/curve25519/FieldElement;Lcafe/cryptography/curve25519/FieldElement;)V

    return-object v1

    :cond_0
    new-instance p0, Lcafe/cryptography/curve25519/InvalidEncodingException;

    const-string v0, "not a valid EdwardsPoint"

    invoke-direct {p0, v0}, Lcafe/cryptography/curve25519/InvalidEncodingException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 2

    instance-of v0, p1, Lcafe/cryptography/curve25519/CompressedEdwardsY;

    const/4 v1, 0x0

    if-nez v0, :cond_0

    return v1

    :cond_0
    check-cast p1, Lcafe/cryptography/curve25519/CompressedEdwardsY;

    invoke-virtual {p0, p1}, Lcafe/cryptography/curve25519/CompressedEdwardsY;->ctEquals(Lcafe/cryptography/curve25519/CompressedEdwardsY;)I

    move-result p0

    const/4 p1, 0x1

    if-ne p0, p1, :cond_1

    move v1, p1

    :cond_1
    return v1
.end method

.method public hashCode()I
    .locals 0

    iget-object p0, p0, Lcafe/cryptography/curve25519/CompressedEdwardsY;->data:[B

    invoke-static {p0}, Ljava/util/Arrays;->hashCode([B)I

    move-result p0

    return p0
.end method

.method public toByteArray()[B
    .locals 0

    iget-object p0, p0, Lcafe/cryptography/curve25519/CompressedEdwardsY;->data:[B

    return-object p0
.end method
