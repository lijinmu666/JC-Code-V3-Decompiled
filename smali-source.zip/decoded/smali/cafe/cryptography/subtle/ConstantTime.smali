.class public final Lcafe/cryptography/subtle/ConstantTime;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static bit([BI)I
    .locals 1

    shr-int/lit8 v0, p1, 0x3

    aget-byte p0, p0, v0

    and-int/lit8 p1, p1, 0x7

    shr-int/2addr p0, p1

    and-int/lit8 p0, p0, 0x1

    return p0
.end method

.method public static equal(II)I
    .locals 2

    .line 1
    xor-int/2addr p0, p1

    const/4 p1, 0x0

    move v0, p1

    :goto_0
    const/16 v1, 0x8

    if-ge p1, v1, :cond_0

    shr-int v1, p0, p1

    or-int/2addr v0, v1

    add-int/lit8 p1, p1, 0x1

    goto :goto_0

    :cond_0
    xor-int/lit8 p0, v0, 0x1

    and-int/lit8 p0, p0, 0x1

    return p0
.end method

.method public static equal([B[B)I
    .locals 5

    .line 2
    array-length v0, p0

    array-length v1, p1

    const/4 v2, 0x0

    if-eq v0, v1, :cond_0

    return v2

    :cond_0
    move v0, v2

    move v1, v0

    .line 3
    :goto_0
    array-length v3, p0

    if-ge v0, v3, :cond_1

    .line 4
    aget-byte v3, p0, v0

    aget-byte v4, p1, v0

    xor-int/2addr v3, v4

    or-int/2addr v1, v3

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    .line 5
    :cond_1
    invoke-static {v1, v2}, Lcafe/cryptography/subtle/ConstantTime;->equal(II)I

    move-result p0

    return p0
.end method

.method public static isNegative(I)I
    .locals 0

    shr-int/lit8 p0, p0, 0x8

    and-int/lit8 p0, p0, 0x1

    return p0
.end method
