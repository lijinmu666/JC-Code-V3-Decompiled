.class public Lcafe/cryptography/ed25519/Ed25519Signature;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field final R:Lcafe/cryptography/curve25519/CompressedEdwardsY;

.field final S:Lcafe/cryptography/curve25519/Scalar;


# direct methods
.method public constructor <init>(Lcafe/cryptography/curve25519/CompressedEdwardsY;Lcafe/cryptography/curve25519/Scalar;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcafe/cryptography/ed25519/Ed25519Signature;->R:Lcafe/cryptography/curve25519/CompressedEdwardsY;

    iput-object p2, p0, Lcafe/cryptography/ed25519/Ed25519Signature;->S:Lcafe/cryptography/curve25519/Scalar;

    return-void
.end method

.method public static fromByteArray([B)Lcafe/cryptography/ed25519/Ed25519Signature;
    .locals 4

    array-length v0, p0

    const/16 v1, 0x40

    if-ne v0, v1, :cond_1

    new-instance v0, Lcafe/cryptography/curve25519/CompressedEdwardsY;

    const/4 v2, 0x0

    const/16 v3, 0x20

    invoke-static {p0, v2, v3}, Ljava/util/Arrays;->copyOfRange([BII)[B

    move-result-object v2

    invoke-direct {v0, v2}, Lcafe/cryptography/curve25519/CompressedEdwardsY;-><init>([B)V

    const/16 v2, 0x3f

    aget-byte v2, p0, v2

    and-int/lit16 v2, v2, 0xf0

    if-nez v2, :cond_0

    invoke-static {p0, v3, v1}, Ljava/util/Arrays;->copyOfRange([BII)[B

    move-result-object p0

    invoke-static {p0}, Lcafe/cryptography/curve25519/Scalar;->fromBits([B)Lcafe/cryptography/curve25519/Scalar;

    move-result-object p0

    goto :goto_0

    :cond_0
    invoke-static {p0, v3, v1}, Ljava/util/Arrays;->copyOfRange([BII)[B

    move-result-object p0

    invoke-static {p0}, Lcafe/cryptography/curve25519/Scalar;->fromCanonicalBytes([B)Lcafe/cryptography/curve25519/Scalar;

    move-result-object p0

    :goto_0
    new-instance v1, Lcafe/cryptography/ed25519/Ed25519Signature;

    invoke-direct {v1, v0, p0}, Lcafe/cryptography/ed25519/Ed25519Signature;-><init>(Lcafe/cryptography/curve25519/CompressedEdwardsY;Lcafe/cryptography/curve25519/Scalar;)V

    return-object v1

    :cond_1
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string v0, "signature length is wrong"

    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0
.end method


# virtual methods
.method public equals(Ljava/lang/Object;)Z
    .locals 3

    instance-of v0, p1, Lcafe/cryptography/ed25519/Ed25519Signature;

    const/4 v1, 0x0

    if-nez v0, :cond_0

    return v1

    :cond_0
    check-cast p1, Lcafe/cryptography/ed25519/Ed25519Signature;

    iget-object v0, p0, Lcafe/cryptography/ed25519/Ed25519Signature;->R:Lcafe/cryptography/curve25519/CompressedEdwardsY;

    iget-object v2, p1, Lcafe/cryptography/ed25519/Ed25519Signature;->R:Lcafe/cryptography/curve25519/CompressedEdwardsY;

    invoke-virtual {v0, v2}, Lcafe/cryptography/curve25519/CompressedEdwardsY;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1

    iget-object p0, p0, Lcafe/cryptography/ed25519/Ed25519Signature;->S:Lcafe/cryptography/curve25519/Scalar;

    iget-object p1, p1, Lcafe/cryptography/ed25519/Ed25519Signature;->S:Lcafe/cryptography/curve25519/Scalar;

    invoke-virtual {p0, p1}, Lcafe/cryptography/curve25519/Scalar;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_1

    const/4 v1, 0x1

    :cond_1
    return v1
.end method

.method public hashCode()I
    .locals 1

    iget-object v0, p0, Lcafe/cryptography/ed25519/Ed25519Signature;->R:Lcafe/cryptography/curve25519/CompressedEdwardsY;

    invoke-virtual {v0}, Lcafe/cryptography/curve25519/CompressedEdwardsY;->hashCode()I

    move-result v0

    iget-object p0, p0, Lcafe/cryptography/ed25519/Ed25519Signature;->S:Lcafe/cryptography/curve25519/Scalar;

    invoke-virtual {p0}, Lcafe/cryptography/curve25519/Scalar;->hashCode()I

    move-result p0

    xor-int/2addr p0, v0

    return p0
.end method

.method public toByteArray()[B
    .locals 4

    iget-object v0, p0, Lcafe/cryptography/ed25519/Ed25519Signature;->R:Lcafe/cryptography/curve25519/CompressedEdwardsY;

    invoke-virtual {v0}, Lcafe/cryptography/curve25519/CompressedEdwardsY;->toByteArray()[B

    move-result-object v0

    iget-object p0, p0, Lcafe/cryptography/ed25519/Ed25519Signature;->S:Lcafe/cryptography/curve25519/Scalar;

    invoke-virtual {p0}, Lcafe/cryptography/curve25519/Scalar;->toByteArray()[B

    move-result-object p0

    array-length v1, v0

    array-length v2, p0

    add-int/2addr v1, v2

    new-array v1, v1, [B

    array-length v2, v0

    const/4 v3, 0x0

    invoke-static {v0, v3, v1, v3, v2}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    array-length v0, v0

    array-length v2, p0

    invoke-static {p0, v3, v1, v0, v2}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    return-object v1
.end method
