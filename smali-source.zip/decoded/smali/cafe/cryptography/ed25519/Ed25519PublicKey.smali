.class public Lcafe/cryptography/ed25519/Ed25519PublicKey;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field private final A:Lcafe/cryptography/curve25519/EdwardsPoint;

.field private final Aenc:Lcafe/cryptography/curve25519/CompressedEdwardsY;


# direct methods
.method private constructor <init>(Lcafe/cryptography/curve25519/CompressedEdwardsY;)V
    .locals 0

    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    iput-object p1, p0, Lcafe/cryptography/ed25519/Ed25519PublicKey;->Aenc:Lcafe/cryptography/curve25519/CompressedEdwardsY;

    .line 6
    invoke-virtual {p1}, Lcafe/cryptography/curve25519/CompressedEdwardsY;->decompress()Lcafe/cryptography/curve25519/EdwardsPoint;

    move-result-object p1

    iput-object p1, p0, Lcafe/cryptography/ed25519/Ed25519PublicKey;->A:Lcafe/cryptography/curve25519/EdwardsPoint;

    return-void
.end method

.method public constructor <init>(Lcafe/cryptography/curve25519/EdwardsPoint;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    iput-object p1, p0, Lcafe/cryptography/ed25519/Ed25519PublicKey;->A:Lcafe/cryptography/curve25519/EdwardsPoint;

    .line 3
    invoke-virtual {p1}, Lcafe/cryptography/curve25519/EdwardsPoint;->compress()Lcafe/cryptography/curve25519/CompressedEdwardsY;

    move-result-object p1

    iput-object p1, p0, Lcafe/cryptography/ed25519/Ed25519PublicKey;->Aenc:Lcafe/cryptography/curve25519/CompressedEdwardsY;

    return-void
.end method

.method public static fromByteArray([B)Lcafe/cryptography/ed25519/Ed25519PublicKey;
    .locals 1

    new-instance v0, Lcafe/cryptography/curve25519/CompressedEdwardsY;

    invoke-direct {v0, p0}, Lcafe/cryptography/curve25519/CompressedEdwardsY;-><init>([B)V

    new-instance p0, Lcafe/cryptography/ed25519/Ed25519PublicKey;

    invoke-direct {p0, v0}, Lcafe/cryptography/ed25519/Ed25519PublicKey;-><init>(Lcafe/cryptography/curve25519/CompressedEdwardsY;)V

    return-object p0
.end method


# virtual methods
.method public equals(Ljava/lang/Object;)Z
    .locals 1

    instance-of v0, p1, Lcafe/cryptography/ed25519/Ed25519PublicKey;

    if-nez v0, :cond_0

    const/4 p0, 0x0

    return p0

    :cond_0
    check-cast p1, Lcafe/cryptography/ed25519/Ed25519PublicKey;

    iget-object p0, p0, Lcafe/cryptography/ed25519/Ed25519PublicKey;->Aenc:Lcafe/cryptography/curve25519/CompressedEdwardsY;

    iget-object p1, p1, Lcafe/cryptography/ed25519/Ed25519PublicKey;->Aenc:Lcafe/cryptography/curve25519/CompressedEdwardsY;

    invoke-virtual {p0, p1}, Lcafe/cryptography/curve25519/CompressedEdwardsY;->equals(Ljava/lang/Object;)Z

    move-result p0

    return p0
.end method

.method public hashCode()I
    .locals 0

    iget-object p0, p0, Lcafe/cryptography/ed25519/Ed25519PublicKey;->Aenc:Lcafe/cryptography/curve25519/CompressedEdwardsY;

    invoke-virtual {p0}, Lcafe/cryptography/curve25519/CompressedEdwardsY;->hashCode()I

    move-result p0

    return p0
.end method

.method public toByteArray()[B
    .locals 0

    iget-object p0, p0, Lcafe/cryptography/ed25519/Ed25519PublicKey;->Aenc:Lcafe/cryptography/curve25519/CompressedEdwardsY;

    invoke-virtual {p0}, Lcafe/cryptography/curve25519/CompressedEdwardsY;->toByteArray()[B

    move-result-object p0

    return-object p0
.end method

.method public verify([BIILcafe/cryptography/ed25519/Ed25519Signature;)Z
    .locals 2

    .line 2
    :try_start_0
    const-string v0, "SHA-512"

    invoke-static {v0}, Ljava/security/MessageDigest;->getInstance(Ljava/lang/String;)Ljava/security/MessageDigest;

    move-result-object v0
    :try_end_0
    .catch Ljava/security/NoSuchAlgorithmException; {:try_start_0 .. :try_end_0} :catch_0

    .line 3
    iget-object v1, p4, Lcafe/cryptography/ed25519/Ed25519Signature;->R:Lcafe/cryptography/curve25519/CompressedEdwardsY;

    invoke-virtual {v1}, Lcafe/cryptography/curve25519/CompressedEdwardsY;->toByteArray()[B

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/security/MessageDigest;->update([B)V

    .line 4
    iget-object v1, p0, Lcafe/cryptography/ed25519/Ed25519PublicKey;->Aenc:Lcafe/cryptography/curve25519/CompressedEdwardsY;

    invoke-virtual {v1}, Lcafe/cryptography/curve25519/CompressedEdwardsY;->toByteArray()[B

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/security/MessageDigest;->update([B)V

    .line 5
    invoke-virtual {v0, p1, p2, p3}, Ljava/security/MessageDigest;->update([BII)V

    .line 6
    invoke-virtual {v0}, Ljava/security/MessageDigest;->digest()[B

    move-result-object p1

    invoke-static {p1}, Lcafe/cryptography/curve25519/Scalar;->fromBytesModOrderWide([B)Lcafe/cryptography/curve25519/Scalar;

    move-result-object p1

    .line 7
    iget-object p0, p0, Lcafe/cryptography/ed25519/Ed25519PublicKey;->A:Lcafe/cryptography/curve25519/EdwardsPoint;

    invoke-virtual {p0}, Lcafe/cryptography/curve25519/EdwardsPoint;->negate()Lcafe/cryptography/curve25519/EdwardsPoint;

    move-result-object p0

    .line 8
    iget-object p2, p4, Lcafe/cryptography/ed25519/Ed25519Signature;->S:Lcafe/cryptography/curve25519/Scalar;

    invoke-static {p1, p0, p2}, Lcafe/cryptography/curve25519/EdwardsPoint;->vartimeDoubleScalarMultiplyBasepoint(Lcafe/cryptography/curve25519/Scalar;Lcafe/cryptography/curve25519/EdwardsPoint;Lcafe/cryptography/curve25519/Scalar;)Lcafe/cryptography/curve25519/EdwardsPoint;

    move-result-object p0

    .line 9
    invoke-virtual {p0}, Lcafe/cryptography/curve25519/EdwardsPoint;->compress()Lcafe/cryptography/curve25519/CompressedEdwardsY;

    move-result-object p0

    iget-object p1, p4, Lcafe/cryptography/ed25519/Ed25519Signature;->R:Lcafe/cryptography/curve25519/CompressedEdwardsY;

    invoke-virtual {p0, p1}, Lcafe/cryptography/curve25519/CompressedEdwardsY;->equals(Ljava/lang/Object;)Z

    move-result p0

    return p0

    :catch_0
    move-exception p0

    .line 10
    new-instance p1, Ljava/lang/RuntimeException;

    invoke-direct {p1, p0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/Throwable;)V

    throw p1
.end method

.method public verify([BLcafe/cryptography/ed25519/Ed25519Signature;)Z
    .locals 2

    .line 1
    array-length v0, p1

    const/4 v1, 0x0

    invoke-virtual {p0, p1, v1, v0, p2}, Lcafe/cryptography/ed25519/Ed25519PublicKey;->verify([BIILcafe/cryptography/ed25519/Ed25519Signature;)Z

    move-result p0

    return p0
.end method
