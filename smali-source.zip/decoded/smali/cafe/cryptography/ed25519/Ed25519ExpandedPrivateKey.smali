.class public Lcafe/cryptography/ed25519/Ed25519ExpandedPrivateKey;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field private final prefix:[B

.field private final s:Lcafe/cryptography/curve25519/Scalar;


# direct methods
.method public constructor <init>(Lcafe/cryptography/curve25519/Scalar;[B)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcafe/cryptography/ed25519/Ed25519ExpandedPrivateKey;->s:Lcafe/cryptography/curve25519/Scalar;

    iput-object p2, p0, Lcafe/cryptography/ed25519/Ed25519ExpandedPrivateKey;->prefix:[B

    return-void
.end method


# virtual methods
.method public derivePublic()Lcafe/cryptography/ed25519/Ed25519PublicKey;
    .locals 1

    sget-object v0, Lcafe/cryptography/curve25519/Constants;->ED25519_BASEPOINT_TABLE:Lcafe/cryptography/curve25519/EdwardsBasepointTable;

    iget-object p0, p0, Lcafe/cryptography/ed25519/Ed25519ExpandedPrivateKey;->s:Lcafe/cryptography/curve25519/Scalar;

    invoke-virtual {v0, p0}, Lcafe/cryptography/curve25519/EdwardsBasepointTable;->multiply(Lcafe/cryptography/curve25519/Scalar;)Lcafe/cryptography/curve25519/EdwardsPoint;

    move-result-object p0

    new-instance v0, Lcafe/cryptography/ed25519/Ed25519PublicKey;

    invoke-direct {v0, p0}, Lcafe/cryptography/ed25519/Ed25519PublicKey;-><init>(Lcafe/cryptography/curve25519/EdwardsPoint;)V

    return-object v0
.end method

.method public sign([BIILcafe/cryptography/ed25519/Ed25519PublicKey;)Lcafe/cryptography/ed25519/Ed25519Signature;
    .locals 4

    .line 2
    :try_start_0
    const-string v0, "SHA-512"

    invoke-static {v0}, Ljava/security/MessageDigest;->getInstance(Ljava/lang/String;)Ljava/security/MessageDigest;

    move-result-object v0
    :try_end_0
    .catch Ljava/security/NoSuchAlgorithmException; {:try_start_0 .. :try_end_0} :catch_0

    .line 3
    iget-object v1, p0, Lcafe/cryptography/ed25519/Ed25519ExpandedPrivateKey;->prefix:[B

    invoke-virtual {v0, v1}, Ljava/security/MessageDigest;->update([B)V

    .line 4
    invoke-virtual {v0, p1, p2, p3}, Ljava/security/MessageDigest;->update([BII)V

    .line 5
    invoke-virtual {v0}, Ljava/security/MessageDigest;->digest()[B

    move-result-object v1

    invoke-static {v1}, Lcafe/cryptography/curve25519/Scalar;->fromBytesModOrderWide([B)Lcafe/cryptography/curve25519/Scalar;

    move-result-object v1

    .line 6
    sget-object v2, Lcafe/cryptography/curve25519/Constants;->ED25519_BASEPOINT_TABLE:Lcafe/cryptography/curve25519/EdwardsBasepointTable;

    invoke-virtual {v2, v1}, Lcafe/cryptography/curve25519/EdwardsBasepointTable;->multiply(Lcafe/cryptography/curve25519/Scalar;)Lcafe/cryptography/curve25519/EdwardsPoint;

    move-result-object v2

    invoke-virtual {v2}, Lcafe/cryptography/curve25519/EdwardsPoint;->compress()Lcafe/cryptography/curve25519/CompressedEdwardsY;

    move-result-object v2

    .line 7
    invoke-virtual {v0}, Ljava/security/MessageDigest;->reset()V

    .line 8
    invoke-virtual {v2}, Lcafe/cryptography/curve25519/CompressedEdwardsY;->toByteArray()[B

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/security/MessageDigest;->update([B)V

    .line 9
    invoke-virtual {p4}, Lcafe/cryptography/ed25519/Ed25519PublicKey;->toByteArray()[B

    move-result-object p4

    invoke-virtual {v0, p4}, Ljava/security/MessageDigest;->update([B)V

    .line 10
    invoke-virtual {v0, p1, p2, p3}, Ljava/security/MessageDigest;->update([BII)V

    .line 11
    invoke-virtual {v0}, Ljava/security/MessageDigest;->digest()[B

    move-result-object p1

    invoke-static {p1}, Lcafe/cryptography/curve25519/Scalar;->fromBytesModOrderWide([B)Lcafe/cryptography/curve25519/Scalar;

    move-result-object p1

    .line 12
    iget-object p0, p0, Lcafe/cryptography/ed25519/Ed25519ExpandedPrivateKey;->s:Lcafe/cryptography/curve25519/Scalar;

    invoke-virtual {p1, p0}, Lcafe/cryptography/curve25519/Scalar;->multiply(Lcafe/cryptography/curve25519/Scalar;)Lcafe/cryptography/curve25519/Scalar;

    move-result-object p0

    invoke-virtual {v1, p0}, Lcafe/cryptography/curve25519/Scalar;->add(Lcafe/cryptography/curve25519/Scalar;)Lcafe/cryptography/curve25519/Scalar;

    move-result-object p0

    .line 13
    new-instance p1, Lcafe/cryptography/ed25519/Ed25519Signature;

    invoke-direct {p1, v2, p0}, Lcafe/cryptography/ed25519/Ed25519Signature;-><init>(Lcafe/cryptography/curve25519/CompressedEdwardsY;Lcafe/cryptography/curve25519/Scalar;)V

    return-object p1

    :catch_0
    move-exception p0

    .line 14
    new-instance p1, Ljava/lang/RuntimeException;

    invoke-direct {p1, p0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/Throwable;)V

    throw p1
.end method

.method public sign([BLcafe/cryptography/ed25519/Ed25519PublicKey;)Lcafe/cryptography/ed25519/Ed25519Signature;
    .locals 2

    .line 1
    array-length v0, p1

    const/4 v1, 0x0

    invoke-virtual {p0, p1, v1, v0, p2}, Lcafe/cryptography/ed25519/Ed25519ExpandedPrivateKey;->sign([BIILcafe/cryptography/ed25519/Ed25519PublicKey;)Lcafe/cryptography/ed25519/Ed25519Signature;

    move-result-object p0

    return-object p0
.end method
