.class public Lcafe/cryptography/ed25519/Ed25519PrivateKey;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field private final secret:[B


# direct methods
.method private constructor <init>([B)V
    .locals 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    array-length v0, p1

    const/16 v1, 0x20

    if-ne v0, v1, :cond_0

    array-length v0, p1

    invoke-static {p1, v0}, Ljava/util/Arrays;->copyOf([BI)[B

    move-result-object p1

    iput-object p1, p0, Lcafe/cryptography/ed25519/Ed25519PrivateKey;->secret:[B

    return-void

    :cond_0
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string p1, "Invalid private key"

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public static fromByteArray([B)Lcafe/cryptography/ed25519/Ed25519PrivateKey;
    .locals 1

    new-instance v0, Lcafe/cryptography/ed25519/Ed25519PrivateKey;

    invoke-direct {v0, p0}, Lcafe/cryptography/ed25519/Ed25519PrivateKey;-><init>([B)V

    return-object v0
.end method

.method public static generate(Ljava/security/SecureRandom;)Lcafe/cryptography/ed25519/Ed25519PrivateKey;
    .locals 1

    const/16 v0, 0x20

    new-array v0, v0, [B

    invoke-virtual {p0, v0}, Ljava/security/SecureRandom;->nextBytes([B)V

    new-instance p0, Lcafe/cryptography/ed25519/Ed25519PrivateKey;

    invoke-direct {p0, v0}, Lcafe/cryptography/ed25519/Ed25519PrivateKey;-><init>([B)V

    return-object p0
.end method


# virtual methods
.method public derivePublic()Lcafe/cryptography/ed25519/Ed25519PublicKey;
    .locals 0

    invoke-virtual {p0}, Lcafe/cryptography/ed25519/Ed25519PrivateKey;->expand()Lcafe/cryptography/ed25519/Ed25519ExpandedPrivateKey;

    move-result-object p0

    invoke-virtual {p0}, Lcafe/cryptography/ed25519/Ed25519ExpandedPrivateKey;->derivePublic()Lcafe/cryptography/ed25519/Ed25519PublicKey;

    move-result-object p0

    return-object p0
.end method

.method public expand()Lcafe/cryptography/ed25519/Ed25519ExpandedPrivateKey;
    .locals 4

    :try_start_0
    const-string v0, "SHA-512"

    invoke-static {v0}, Ljava/security/MessageDigest;->getInstance(Ljava/lang/String;)Ljava/security/MessageDigest;

    move-result-object v0
    :try_end_0
    .catch Ljava/security/NoSuchAlgorithmException; {:try_start_0 .. :try_end_0} :catch_0

    iget-object p0, p0, Lcafe/cryptography/ed25519/Ed25519PrivateKey;->secret:[B

    invoke-virtual {v0, p0}, Ljava/security/MessageDigest;->update([B)V

    invoke-virtual {v0}, Ljava/security/MessageDigest;->digest()[B

    move-result-object p0

    const/4 v0, 0x0

    const/16 v1, 0x20

    invoke-static {p0, v0, v1}, Ljava/util/Arrays;->copyOfRange([BII)[B

    move-result-object v2

    const/16 v3, 0x40

    invoke-static {p0, v1, v3}, Ljava/util/Arrays;->copyOfRange([BII)[B

    move-result-object p0

    aget-byte v1, v2, v0

    and-int/lit16 v1, v1, 0xf8

    int-to-byte v1, v1

    aput-byte v1, v2, v0

    const/16 v0, 0x1f

    aget-byte v1, v2, v0

    and-int/lit8 v1, v1, 0x3f

    int-to-byte v1, v1

    aput-byte v1, v2, v0

    or-int/2addr v1, v3

    int-to-byte v1, v1

    aput-byte v1, v2, v0

    invoke-static {v2}, Lcafe/cryptography/curve25519/Scalar;->fromBits([B)Lcafe/cryptography/curve25519/Scalar;

    move-result-object v0

    new-instance v1, Lcafe/cryptography/ed25519/Ed25519ExpandedPrivateKey;

    invoke-direct {v1, v0, p0}, Lcafe/cryptography/ed25519/Ed25519ExpandedPrivateKey;-><init>(Lcafe/cryptography/curve25519/Scalar;[B)V

    return-object v1

    :catch_0
    move-exception p0

    new-instance v0, Ljava/lang/RuntimeException;

    invoke-direct {v0, p0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/Throwable;)V

    throw v0
.end method

.method public toByteArray()[B
    .locals 1

    iget-object p0, p0, Lcafe/cryptography/ed25519/Ed25519PrivateKey;->secret:[B

    array-length v0, p0

    invoke-static {p0, v0}, Ljava/util/Arrays;->copyOf([BI)[B

    move-result-object p0

    return-object p0
.end method
