.class public final Lcom/flyfishxu/kadb/cert/AdbKeyPair;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000,\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\t\n\u0002\u0010\u0012\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0002\u0008\u0000\u0018\u00002\u00020\u0001B\u001f\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u00a2\u0006\u0004\u0008\u0008\u0010\tJ\u0015\u0010\u0010\u001a\u00020\u00112\u0006\u0010\u0012\u001a\u00020\u0013H\u0000\u00a2\u0006\u0002\u0008\u0014R\u0011\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\n\u0010\u000bR\u0011\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u000c\u0010\rR\u0011\u0010\u0006\u001a\u00020\u0007\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u000e\u0010\u000f\u00a8\u0006\u0015"
    }
    d2 = {
        "Lcom/flyfishxu/kadb/cert/AdbKeyPair;",
        "",
        "privateKey",
        "Ljava/security/PrivateKey;",
        "publicKey",
        "Ljava/security/PublicKey;",
        "certificate",
        "Ljava/security/cert/Certificate;",
        "<init>",
        "(Ljava/security/PrivateKey;Ljava/security/PublicKey;Ljava/security/cert/Certificate;)V",
        "getPrivateKey",
        "()Ljava/security/PrivateKey;",
        "getPublicKey",
        "()Ljava/security/PublicKey;",
        "getCertificate",
        "()Ljava/security/cert/Certificate;",
        "signPayload",
        "",
        "message",
        "Lcom/flyfishxu/kadb/core/AdbMessage;",
        "signPayload$com_github_IndiTheo_kadb",
        "com.github.IndiTheo:kadb"
    }
    k = 0x1
    mv = {
        0x2,
        0x4,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field private final certificate:Ljava/security/cert/Certificate;

.field private final privateKey:Ljava/security/PrivateKey;

.field private final publicKey:Ljava/security/PublicKey;


# direct methods
.method public constructor <init>(Ljava/security/PrivateKey;Ljava/security/PublicKey;Ljava/security/cert/Certificate;)V
    .locals 1

    const-string v0, "privateKey"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "publicKey"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "certificate"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/flyfishxu/kadb/cert/AdbKeyPair;->privateKey:Ljava/security/PrivateKey;

    iput-object p2, p0, Lcom/flyfishxu/kadb/cert/AdbKeyPair;->publicKey:Ljava/security/PublicKey;

    iput-object p3, p0, Lcom/flyfishxu/kadb/cert/AdbKeyPair;->certificate:Ljava/security/cert/Certificate;

    return-void
.end method


# virtual methods
.method public final getCertificate()Ljava/security/cert/Certificate;
    .locals 0

    iget-object p0, p0, Lcom/flyfishxu/kadb/cert/AdbKeyPair;->certificate:Ljava/security/cert/Certificate;

    return-object p0
.end method

.method public final getPrivateKey()Ljava/security/PrivateKey;
    .locals 0

    iget-object p0, p0, Lcom/flyfishxu/kadb/cert/AdbKeyPair;->privateKey:Ljava/security/PrivateKey;

    return-object p0
.end method

.method public final getPublicKey()Ljava/security/PublicKey;
    .locals 0

    iget-object p0, p0, Lcom/flyfishxu/kadb/cert/AdbKeyPair;->publicKey:Ljava/security/PublicKey;

    return-object p0
.end method

.method public final signPayload$com_github_IndiTheo_kadb(Lcom/flyfishxu/kadb/core/AdbMessage;)[B
    .locals 2

    const-string v0, "message"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "RSA/ECB/NoPadding"

    invoke-static {v0}, Ljavax/crypto/Cipher;->getInstance(Ljava/lang/String;)Ljavax/crypto/Cipher;

    move-result-object v0

    const/4 v1, 0x1

    iget-object p0, p0, Lcom/flyfishxu/kadb/cert/AdbKeyPair;->privateKey:Ljava/security/PrivateKey;

    invoke-virtual {v0, v1, p0}, Ljavax/crypto/Cipher;->init(ILjava/security/Key;)V

    sget-object p0, Lcom/flyfishxu/kadb/cert/AndroidPubkey;->INSTANCE:Lcom/flyfishxu/kadb/cert/AndroidPubkey;

    invoke-virtual {p0}, Lcom/flyfishxu/kadb/cert/AndroidPubkey;->getSIGNATURE_PADDING()[B

    move-result-object p0

    invoke-virtual {v0, p0}, Ljavax/crypto/Cipher;->update([B)[B

    invoke-virtual {p1}, Lcom/flyfishxu/kadb/core/AdbMessage;->getPayload()[B

    move-result-object p0

    const/4 v1, 0x0

    invoke-virtual {p1}, Lcom/flyfishxu/kadb/core/AdbMessage;->getPayloadLength()I

    move-result p1

    invoke-virtual {v0, p0, v1, p1}, Ljavax/crypto/Cipher;->doFinal([BII)[B

    move-result-object p0

    const-string p1, "doFinal(...)"

    invoke-static {p0, p1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    return-object p0
.end method
