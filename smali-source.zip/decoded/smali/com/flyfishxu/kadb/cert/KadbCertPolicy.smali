.class public final Lcom/flyfishxu/kadb/cert/KadbCertPolicy;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/flyfishxu/kadb/cert/KadbCertPolicy$Subject;
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000(\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0008\n\u0002\u0008\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0012\n\u0002\u0010\u000e\n\u0002\u0008\u0002\u0008\u0086\u0008\u0018\u00002\u00020\u0001:\u0001\u001cB/\u0012\u0008\u0008\u0002\u0010\u0002\u001a\u00020\u0003\u0012\u0008\u0008\u0002\u0010\u0004\u001a\u00020\u0003\u0012\u0008\u0008\u0002\u0010\u0005\u001a\u00020\u0006\u0012\u0008\u0008\u0002\u0010\u0007\u001a\u00020\u0008\u00a2\u0006\u0004\u0008\t\u0010\nJ\t\u0010\u0012\u001a\u00020\u0003H\u00c6\u0003J\t\u0010\u0013\u001a\u00020\u0003H\u00c6\u0003J\t\u0010\u0014\u001a\u00020\u0006H\u00c6\u0003J\t\u0010\u0015\u001a\u00020\u0008H\u00c6\u0003J1\u0010\u0016\u001a\u00020\u00002\u0008\u0008\u0002\u0010\u0002\u001a\u00020\u00032\u0008\u0008\u0002\u0010\u0004\u001a\u00020\u00032\u0008\u0008\u0002\u0010\u0005\u001a\u00020\u00062\u0008\u0008\u0002\u0010\u0007\u001a\u00020\u0008H\u00c6\u0001J\u0014\u0010\u0017\u001a\u00020\u00062\u0008\u0010\u0018\u001a\u0004\u0018\u00010\u0001H\u00d6\u0083\u0004J\n\u0010\u0019\u001a\u00020\u0003H\u00d6\u0081\u0004J\n\u0010\u001a\u001a\u00020\u001bH\u00d6\u0081\u0004R\u0011\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u000b\u0010\u000cR\u0011\u0010\u0004\u001a\u00020\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\r\u0010\u000cR\u0011\u0010\u0005\u001a\u00020\u0006\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u000e\u0010\u000fR\u0011\u0010\u0007\u001a\u00020\u0008\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0010\u0010\u0011\u00a8\u0006\u001d"
    }
    d2 = {
        "Lcom/flyfishxu/kadb/cert/KadbCertPolicy;",
        "",
        "keySizeBits",
        "",
        "certValidityDays",
        "autoHealInvalidPrivateKey",
        "",
        "subject",
        "Lcom/flyfishxu/kadb/cert/KadbCertPolicy$Subject;",
        "<init>",
        "(IIZLcom/flyfishxu/kadb/cert/KadbCertPolicy$Subject;)V",
        "getKeySizeBits",
        "()I",
        "getCertValidityDays",
        "getAutoHealInvalidPrivateKey",
        "()Z",
        "getSubject",
        "()Lcom/flyfishxu/kadb/cert/KadbCertPolicy$Subject;",
        "component1",
        "component2",
        "component3",
        "component4",
        "copy",
        "equals",
        "other",
        "hashCode",
        "toString",
        "",
        "Subject",
        "com.github.IndiTheo:kadb"
    }
    k = 0x1
    mv = {
        0x2,
        0x4,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field private final autoHealInvalidPrivateKey:Z

.field private final certValidityDays:I

.field private final keySizeBits:I

.field private final subject:Lcom/flyfishxu/kadb/cert/KadbCertPolicy$Subject;


# direct methods
.method public constructor <init>()V
    .locals 7

    .line 1
    const/16 v5, 0xf

    const/4 v6, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    move-object v0, p0

    invoke-direct/range {v0 .. v6}, Lcom/flyfishxu/kadb/cert/KadbCertPolicy;-><init>(IIZLcom/flyfishxu/kadb/cert/KadbCertPolicy$Subject;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    return-void
.end method

.method public constructor <init>(IIZLcom/flyfishxu/kadb/cert/KadbCertPolicy$Subject;)V
    .locals 1

    const-string v0, "subject"

    invoke-static {p4, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    iput p1, p0, Lcom/flyfishxu/kadb/cert/KadbCertPolicy;->keySizeBits:I

    .line 4
    iput p2, p0, Lcom/flyfishxu/kadb/cert/KadbCertPolicy;->certValidityDays:I

    .line 5
    iput-boolean p3, p0, Lcom/flyfishxu/kadb/cert/KadbCertPolicy;->autoHealInvalidPrivateKey:Z

    .line 6
    iput-object p4, p0, Lcom/flyfishxu/kadb/cert/KadbCertPolicy;->subject:Lcom/flyfishxu/kadb/cert/KadbCertPolicy$Subject;

    return-void
.end method

.method public synthetic constructor <init>(IIZLcom/flyfishxu/kadb/cert/KadbCertPolicy$Subject;ILkotlin/jvm/internal/DefaultConstructorMarker;)V
    .locals 9

    and-int/lit8 p6, p5, 0x1

    if-eqz p6, :cond_0

    const/16 p1, 0x800

    :cond_0
    and-int/lit8 p6, p5, 0x2

    if-eqz p6, :cond_1

    const/16 p2, 0xe42

    :cond_1
    and-int/lit8 p6, p5, 0x4

    if-eqz p6, :cond_2

    const/4 p3, 0x1

    :cond_2
    and-int/lit8 p5, p5, 0x8

    if-eqz p5, :cond_3

    .line 7
    new-instance p4, Lcom/flyfishxu/kadb/cert/KadbCertPolicy$Subject;

    const/16 v7, 0x3f

    const/4 v8, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    move-object v0, p4

    invoke-direct/range {v0 .. v8}, Lcom/flyfishxu/kadb/cert/KadbCertPolicy$Subject;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    .line 8
    :cond_3
    invoke-direct {p0, p1, p2, p3, p4}, Lcom/flyfishxu/kadb/cert/KadbCertPolicy;-><init>(IIZLcom/flyfishxu/kadb/cert/KadbCertPolicy$Subject;)V

    return-void
.end method

.method public static synthetic copy$default(Lcom/flyfishxu/kadb/cert/KadbCertPolicy;IIZLcom/flyfishxu/kadb/cert/KadbCertPolicy$Subject;ILjava/lang/Object;)Lcom/flyfishxu/kadb/cert/KadbCertPolicy;
    .locals 0

    and-int/lit8 p6, p5, 0x1

    if-eqz p6, :cond_0

    iget p1, p0, Lcom/flyfishxu/kadb/cert/KadbCertPolicy;->keySizeBits:I

    :cond_0
    and-int/lit8 p6, p5, 0x2

    if-eqz p6, :cond_1

    iget p2, p0, Lcom/flyfishxu/kadb/cert/KadbCertPolicy;->certValidityDays:I

    :cond_1
    and-int/lit8 p6, p5, 0x4

    if-eqz p6, :cond_2

    iget-boolean p3, p0, Lcom/flyfishxu/kadb/cert/KadbCertPolicy;->autoHealInvalidPrivateKey:Z

    :cond_2
    and-int/lit8 p5, p5, 0x8

    if-eqz p5, :cond_3

    iget-object p4, p0, Lcom/flyfishxu/kadb/cert/KadbCertPolicy;->subject:Lcom/flyfishxu/kadb/cert/KadbCertPolicy$Subject;

    :cond_3
    invoke-virtual {p0, p1, p2, p3, p4}, Lcom/flyfishxu/kadb/cert/KadbCertPolicy;->copy(IIZLcom/flyfishxu/kadb/cert/KadbCertPolicy$Subject;)Lcom/flyfishxu/kadb/cert/KadbCertPolicy;

    move-result-object p0

    return-object p0
.end method


# virtual methods
.method public final component1()I
    .locals 0

    iget p0, p0, Lcom/flyfishxu/kadb/cert/KadbCertPolicy;->keySizeBits:I

    return p0
.end method

.method public final component2()I
    .locals 0

    iget p0, p0, Lcom/flyfishxu/kadb/cert/KadbCertPolicy;->certValidityDays:I

    return p0
.end method

.method public final component3()Z
    .locals 0

    iget-boolean p0, p0, Lcom/flyfishxu/kadb/cert/KadbCertPolicy;->autoHealInvalidPrivateKey:Z

    return p0
.end method

.method public final component4()Lcom/flyfishxu/kadb/cert/KadbCertPolicy$Subject;
    .locals 0

    iget-object p0, p0, Lcom/flyfishxu/kadb/cert/KadbCertPolicy;->subject:Lcom/flyfishxu/kadb/cert/KadbCertPolicy$Subject;

    return-object p0
.end method

.method public final copy(IIZLcom/flyfishxu/kadb/cert/KadbCertPolicy$Subject;)Lcom/flyfishxu/kadb/cert/KadbCertPolicy;
    .locals 0

    const-string p0, "subject"

    invoke-static {p4, p0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance p0, Lcom/flyfishxu/kadb/cert/KadbCertPolicy;

    invoke-direct {p0, p1, p2, p3, p4}, Lcom/flyfishxu/kadb/cert/KadbCertPolicy;-><init>(IIZLcom/flyfishxu/kadb/cert/KadbCertPolicy$Subject;)V

    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    const/4 v0, 0x1

    if-ne p0, p1, :cond_0

    return v0

    :cond_0
    instance-of v1, p1, Lcom/flyfishxu/kadb/cert/KadbCertPolicy;

    const/4 v2, 0x0

    if-nez v1, :cond_1

    return v2

    :cond_1
    check-cast p1, Lcom/flyfishxu/kadb/cert/KadbCertPolicy;

    iget v1, p0, Lcom/flyfishxu/kadb/cert/KadbCertPolicy;->keySizeBits:I

    iget v3, p1, Lcom/flyfishxu/kadb/cert/KadbCertPolicy;->keySizeBits:I

    if-eq v1, v3, :cond_2

    return v2

    :cond_2
    iget v1, p0, Lcom/flyfishxu/kadb/cert/KadbCertPolicy;->certValidityDays:I

    iget v3, p1, Lcom/flyfishxu/kadb/cert/KadbCertPolicy;->certValidityDays:I

    if-eq v1, v3, :cond_3

    return v2

    :cond_3
    iget-boolean v1, p0, Lcom/flyfishxu/kadb/cert/KadbCertPolicy;->autoHealInvalidPrivateKey:Z

    iget-boolean v3, p1, Lcom/flyfishxu/kadb/cert/KadbCertPolicy;->autoHealInvalidPrivateKey:Z

    if-eq v1, v3, :cond_4

    return v2

    :cond_4
    iget-object p0, p0, Lcom/flyfishxu/kadb/cert/KadbCertPolicy;->subject:Lcom/flyfishxu/kadb/cert/KadbCertPolicy$Subject;

    iget-object p1, p1, Lcom/flyfishxu/kadb/cert/KadbCertPolicy;->subject:Lcom/flyfishxu/kadb/cert/KadbCertPolicy$Subject;

    invoke-static {p0, p1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_5

    return v2

    :cond_5
    return v0
.end method

.method public final getAutoHealInvalidPrivateKey()Z
    .locals 0

    iget-boolean p0, p0, Lcom/flyfishxu/kadb/cert/KadbCertPolicy;->autoHealInvalidPrivateKey:Z

    return p0
.end method

.method public final getCertValidityDays()I
    .locals 0

    iget p0, p0, Lcom/flyfishxu/kadb/cert/KadbCertPolicy;->certValidityDays:I

    return p0
.end method

.method public final getKeySizeBits()I
    .locals 0

    iget p0, p0, Lcom/flyfishxu/kadb/cert/KadbCertPolicy;->keySizeBits:I

    return p0
.end method

.method public final getSubject()Lcom/flyfishxu/kadb/cert/KadbCertPolicy$Subject;
    .locals 0

    iget-object p0, p0, Lcom/flyfishxu/kadb/cert/KadbCertPolicy;->subject:Lcom/flyfishxu/kadb/cert/KadbCertPolicy$Subject;

    return-object p0
.end method

.method public hashCode()I
    .locals 2

    iget v0, p0, Lcom/flyfishxu/kadb/cert/KadbCertPolicy;->keySizeBits:I

    invoke-static {v0}, Ljava/lang/Integer;->hashCode(I)I

    move-result v0

    mul-int/lit8 v0, v0, 0x1f

    iget v1, p0, Lcom/flyfishxu/kadb/cert/KadbCertPolicy;->certValidityDays:I

    invoke-static {v1}, Ljava/lang/Integer;->hashCode(I)I

    move-result v1

    add-int/2addr v0, v1

    mul-int/lit8 v0, v0, 0x1f

    iget-boolean v1, p0, Lcom/flyfishxu/kadb/cert/KadbCertPolicy;->autoHealInvalidPrivateKey:Z

    invoke-static {v1}, Ljava/lang/Boolean;->hashCode(Z)I

    move-result v1

    add-int/2addr v0, v1

    mul-int/lit8 v0, v0, 0x1f

    iget-object p0, p0, Lcom/flyfishxu/kadb/cert/KadbCertPolicy;->subject:Lcom/flyfishxu/kadb/cert/KadbCertPolicy$Subject;

    invoke-virtual {p0}, Lcom/flyfishxu/kadb/cert/KadbCertPolicy$Subject;->hashCode()I

    move-result p0

    add-int/2addr v0, p0

    return v0
.end method

.method public toString()Ljava/lang/String;
    .locals 5

    iget v0, p0, Lcom/flyfishxu/kadb/cert/KadbCertPolicy;->keySizeBits:I

    iget v1, p0, Lcom/flyfishxu/kadb/cert/KadbCertPolicy;->certValidityDays:I

    iget-boolean v2, p0, Lcom/flyfishxu/kadb/cert/KadbCertPolicy;->autoHealInvalidPrivateKey:Z

    iget-object p0, p0, Lcom/flyfishxu/kadb/cert/KadbCertPolicy;->subject:Lcom/flyfishxu/kadb/cert/KadbCertPolicy$Subject;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "KadbCertPolicy(keySizeBits="

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v0, ", certValidityDays="

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v0, ", autoHealInvalidPrivateKey="

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const-string v0, ", subject="

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p0, ")"

    invoke-virtual {v3, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
