.class public final Lcom/flyfishxu/kadb/cert/KadbCert$State$Ready;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/flyfishxu/kadb/cert/KadbCert$State;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/flyfishxu/kadb/cert/KadbCert$State;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Ready"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u00000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\n\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0008\n\u0000\n\u0002\u0010\u000e\n\u0000\u0008\u0086\u0008\u0018\u00002\u00020\u0001B\u0017\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\u0004\u0008\u0006\u0010\u0007J\t\u0010\u000c\u001a\u00020\u0003H\u00c6\u0003J\t\u0010\r\u001a\u00020\u0005H\u00c6\u0003J\u001d\u0010\u000e\u001a\u00020\u00002\u0008\u0008\u0002\u0010\u0002\u001a\u00020\u00032\u0008\u0008\u0002\u0010\u0004\u001a\u00020\u0005H\u00c6\u0001J\u0014\u0010\u000f\u001a\u00020\u00102\u0008\u0010\u0011\u001a\u0004\u0018\u00010\u0012H\u00d6\u0083\u0004J\n\u0010\u0013\u001a\u00020\u0014H\u00d6\u0081\u0004J\n\u0010\u0015\u001a\u00020\u0016H\u00d6\u0081\u0004R\u0011\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0008\u0010\tR\u0011\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\n\u0010\u000b\u00a8\u0006\u0017"
    }
    d2 = {
        "Lcom/flyfishxu/kadb/cert/KadbCert$State$Ready;",
        "Lcom/flyfishxu/kadb/cert/KadbCert$State;",
        "snapshot",
        "Lcom/flyfishxu/kadb/cert/KadbIdentitySnapshot;",
        "keySet",
        "Lcom/flyfishxu/kadb/cert/HostKeySet;",
        "<init>",
        "(Lcom/flyfishxu/kadb/cert/KadbIdentitySnapshot;Lcom/flyfishxu/kadb/cert/HostKeySet;)V",
        "getSnapshot",
        "()Lcom/flyfishxu/kadb/cert/KadbIdentitySnapshot;",
        "getKeySet",
        "()Lcom/flyfishxu/kadb/cert/HostKeySet;",
        "component1",
        "component2",
        "copy",
        "equals",
        "",
        "other",
        "",
        "hashCode",
        "",
        "toString",
        "",
        "com.github.IndiTheo:kadb"
    }
    k = 0x1
    mv = {
        0x2,
        0x4,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field private final keySet:Lcom/flyfishxu/kadb/cert/HostKeySet;

.field private final snapshot:Lcom/flyfishxu/kadb/cert/KadbIdentitySnapshot;


# direct methods
.method public constructor <init>(Lcom/flyfishxu/kadb/cert/KadbIdentitySnapshot;Lcom/flyfishxu/kadb/cert/HostKeySet;)V
    .locals 1

    const-string v0, "snapshot"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "keySet"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/flyfishxu/kadb/cert/KadbCert$State$Ready;->snapshot:Lcom/flyfishxu/kadb/cert/KadbIdentitySnapshot;

    iput-object p2, p0, Lcom/flyfishxu/kadb/cert/KadbCert$State$Ready;->keySet:Lcom/flyfishxu/kadb/cert/HostKeySet;

    return-void
.end method

.method public static synthetic copy$default(Lcom/flyfishxu/kadb/cert/KadbCert$State$Ready;Lcom/flyfishxu/kadb/cert/KadbIdentitySnapshot;Lcom/flyfishxu/kadb/cert/HostKeySet;ILjava/lang/Object;)Lcom/flyfishxu/kadb/cert/KadbCert$State$Ready;
    .locals 0

    and-int/lit8 p4, p3, 0x1

    if-eqz p4, :cond_0

    iget-object p1, p0, Lcom/flyfishxu/kadb/cert/KadbCert$State$Ready;->snapshot:Lcom/flyfishxu/kadb/cert/KadbIdentitySnapshot;

    :cond_0
    and-int/lit8 p3, p3, 0x2

    if-eqz p3, :cond_1

    iget-object p2, p0, Lcom/flyfishxu/kadb/cert/KadbCert$State$Ready;->keySet:Lcom/flyfishxu/kadb/cert/HostKeySet;

    :cond_1
    invoke-virtual {p0, p1, p2}, Lcom/flyfishxu/kadb/cert/KadbCert$State$Ready;->copy(Lcom/flyfishxu/kadb/cert/KadbIdentitySnapshot;Lcom/flyfishxu/kadb/cert/HostKeySet;)Lcom/flyfishxu/kadb/cert/KadbCert$State$Ready;

    move-result-object p0

    return-object p0
.end method


# virtual methods
.method public final component1()Lcom/flyfishxu/kadb/cert/KadbIdentitySnapshot;
    .locals 0

    iget-object p0, p0, Lcom/flyfishxu/kadb/cert/KadbCert$State$Ready;->snapshot:Lcom/flyfishxu/kadb/cert/KadbIdentitySnapshot;

    return-object p0
.end method

.method public final component2()Lcom/flyfishxu/kadb/cert/HostKeySet;
    .locals 0

    iget-object p0, p0, Lcom/flyfishxu/kadb/cert/KadbCert$State$Ready;->keySet:Lcom/flyfishxu/kadb/cert/HostKeySet;

    return-object p0
.end method

.method public final copy(Lcom/flyfishxu/kadb/cert/KadbIdentitySnapshot;Lcom/flyfishxu/kadb/cert/HostKeySet;)Lcom/flyfishxu/kadb/cert/KadbCert$State$Ready;
    .locals 0

    const-string p0, "snapshot"

    invoke-static {p1, p0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string p0, "keySet"

    invoke-static {p2, p0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance p0, Lcom/flyfishxu/kadb/cert/KadbCert$State$Ready;

    invoke-direct {p0, p1, p2}, Lcom/flyfishxu/kadb/cert/KadbCert$State$Ready;-><init>(Lcom/flyfishxu/kadb/cert/KadbIdentitySnapshot;Lcom/flyfishxu/kadb/cert/HostKeySet;)V

    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    const/4 v0, 0x1

    if-ne p0, p1, :cond_0

    return v0

    :cond_0
    instance-of v1, p1, Lcom/flyfishxu/kadb/cert/KadbCert$State$Ready;

    const/4 v2, 0x0

    if-nez v1, :cond_1

    return v2

    :cond_1
    check-cast p1, Lcom/flyfishxu/kadb/cert/KadbCert$State$Ready;

    iget-object v1, p0, Lcom/flyfishxu/kadb/cert/KadbCert$State$Ready;->snapshot:Lcom/flyfishxu/kadb/cert/KadbIdentitySnapshot;

    iget-object v3, p1, Lcom/flyfishxu/kadb/cert/KadbCert$State$Ready;->snapshot:Lcom/flyfishxu/kadb/cert/KadbIdentitySnapshot;

    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_2

    return v2

    :cond_2
    iget-object p0, p0, Lcom/flyfishxu/kadb/cert/KadbCert$State$Ready;->keySet:Lcom/flyfishxu/kadb/cert/HostKeySet;

    iget-object p1, p1, Lcom/flyfishxu/kadb/cert/KadbCert$State$Ready;->keySet:Lcom/flyfishxu/kadb/cert/HostKeySet;

    invoke-static {p0, p1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_3

    return v2

    :cond_3
    return v0
.end method

.method public final getKeySet()Lcom/flyfishxu/kadb/cert/HostKeySet;
    .locals 0

    iget-object p0, p0, Lcom/flyfishxu/kadb/cert/KadbCert$State$Ready;->keySet:Lcom/flyfishxu/kadb/cert/HostKeySet;

    return-object p0
.end method

.method public final getSnapshot()Lcom/flyfishxu/kadb/cert/KadbIdentitySnapshot;
    .locals 0

    iget-object p0, p0, Lcom/flyfishxu/kadb/cert/KadbCert$State$Ready;->snapshot:Lcom/flyfishxu/kadb/cert/KadbIdentitySnapshot;

    return-object p0
.end method

.method public hashCode()I
    .locals 1

    iget-object v0, p0, Lcom/flyfishxu/kadb/cert/KadbCert$State$Ready;->snapshot:Lcom/flyfishxu/kadb/cert/KadbIdentitySnapshot;

    invoke-virtual {v0}, Lcom/flyfishxu/kadb/cert/KadbIdentitySnapshot;->hashCode()I

    move-result v0

    mul-int/lit8 v0, v0, 0x1f

    iget-object p0, p0, Lcom/flyfishxu/kadb/cert/KadbCert$State$Ready;->keySet:Lcom/flyfishxu/kadb/cert/HostKeySet;

    invoke-virtual {p0}, Lcom/flyfishxu/kadb/cert/HostKeySet;->hashCode()I

    move-result p0

    add-int/2addr v0, p0

    return v0
.end method

.method public toString()Ljava/lang/String;
    .locals 3

    iget-object v0, p0, Lcom/flyfishxu/kadb/cert/KadbCert$State$Ready;->snapshot:Lcom/flyfishxu/kadb/cert/KadbIdentitySnapshot;

    iget-object p0, p0, Lcom/flyfishxu/kadb/cert/KadbCert$State$Ready;->keySet:Lcom/flyfishxu/kadb/cert/HostKeySet;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "Ready(snapshot="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v0, ", keySet="

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p0, ")"

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
