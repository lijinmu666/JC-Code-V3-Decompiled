.class public final Lcom/flyfishxu/kadb/cert/OkioFilePrivateKeyStore;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/flyfishxu/kadb/cert/KadbPrivateKeyStore;


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000&\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0010\u0012\n\u0000\n\u0002\u0010\u0002\n\u0002\u0008\u000c\u0018\u00002\u00020\u0001B\u0019\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0008\u0008\u0002\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\u0004\u0008\u0006\u0010\u0007J\n\u0010\u0008\u001a\u0004\u0018\u00010\tH\u0016J\u0010\u0010\n\u001a\u00020\u000b2\u0006\u0010\u000c\u001a\u00020\tH\u0016J\u0008\u0010\r\u001a\u00020\u000bH\u0016J\u0012\u0010\u000e\u001a\u0004\u0018\u00010\t2\u0006\u0010\u000f\u001a\u00020\u0003H\u0002J\u0018\u0010\u0010\u001a\u00020\u000b2\u0006\u0010\u000f\u001a\u00020\u00032\u0006\u0010\u0011\u001a\u00020\tH\u0002J\u0010\u0010\u0012\u001a\u00020\u000b2\u0006\u0010\u000f\u001a\u00020\u0003H\u0002J\u0018\u0010\u0013\u001a\u00020\u00032\u0006\u0010\u000f\u001a\u00020\u00032\u0006\u0010\u0011\u001a\u00020\tH\u0002J\u0018\u0010\u0014\u001a\u00020\u000b2\u0006\u0010\u0015\u001a\u00020\u00032\u0006\u0010\u000f\u001a\u00020\u0003H\u0002J\u0010\u0010\u0016\u001a\u00020\u000b2\u0006\u0010\u000f\u001a\u00020\u0003H\u0002R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u0017"
    }
    d2 = {
        "Lcom/flyfishxu/kadb/cert/OkioFilePrivateKeyStore;",
        "Lcom/flyfishxu/kadb/cert/KadbPrivateKeyStore;",
        "privateKeyPath",
        "Lokio/Path;",
        "fileSystem",
        "Lokio/FileSystem;",
        "<init>",
        "(Lokio/Path;Lokio/FileSystem;)V",
        "readPrivateKeyPem",
        "",
        "writePrivateKeyPemAtomic",
        "",
        "privateKeyPem",
        "clear",
        "readOrNull",
        "path",
        "writeAtomic",
        "payload",
        "deleteIfExists",
        "stageWrite",
        "commitStagedWrite",
        "tempPath",
        "cleanupTemp",
        "com.github.IndiTheo:kadb"
    }
    k = 0x1
    mv = {
        0x2,
        0x4,
        0x0
    }
    xi = 0x30
.end annotation

.annotation build Lkotlin/jvm/internal/SourceDebugExtension;
    value = {
        "SMAP\nOkioFilePrivateKeyStore.kt\nKotlin\n*S Kotlin\n*F\n+ 1 OkioFilePrivateKeyStore.kt\ncom/flyfishxu/kadb/cert/OkioFilePrivateKeyStore\n+ 2 Okio.kt\nokio/Okio__OkioKt\n+ 3 FileSystem.kt\nokio/FileSystem\n+ 4 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,70:1\n72#2:71\n58#2,4:73\n66#2,10:78\n62#2,3:88\n77#2,3:91\n58#2,4:97\n66#2,10:102\n62#2,18:112\n73#3:72\n74#3:77\n86#3:94\n191#3:95\n95#3:96\n96#3:101\n1#4:130\n*S KotlinDebug\n*F\n+ 1 OkioFilePrivateKeyStore.kt\ncom/flyfishxu/kadb/cert/OkioFilePrivateKeyStore\n*L\n27#1:71\n27#1:73,4\n27#1:78,10\n27#1:88,3\n27#1:91,3\n54#1:97,4\n54#1:102,10\n54#1:112,18\n27#1:72\n27#1:77\n54#1:94\n54#1:95\n54#1:96\n54#1:101\n*E\n"
    }
.end annotation


# instance fields
.field private final fileSystem:Lokio/FileSystem;

.field private final privateKeyPath:Lokio/Path;


# direct methods
.method public constructor <init>(Lokio/Path;Lokio/FileSystem;)V
    .locals 1

    const-string v0, "privateKeyPath"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "fileSystem"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    iput-object p1, p0, Lcom/flyfishxu/kadb/cert/OkioFilePrivateKeyStore;->privateKeyPath:Lokio/Path;

    .line 3
    iput-object p2, p0, Lcom/flyfishxu/kadb/cert/OkioFilePrivateKeyStore;->fileSystem:Lokio/FileSystem;

    return-void
.end method

.method public synthetic constructor <init>(Lokio/Path;Lokio/FileSystem;ILkotlin/jvm/internal/DefaultConstructorMarker;)V
    .locals 0

    and-int/lit8 p3, p3, 0x2

    if-eqz p3, :cond_0

    .line 4
    sget-object p2, Lokio/FileSystem;->SYSTEM:Lokio/FileSystem;

    .line 5
    :cond_0
    invoke-direct {p0, p1, p2}, Lcom/flyfishxu/kadb/cert/OkioFilePrivateKeyStore;-><init>(Lokio/Path;Lokio/FileSystem;)V

    return-void
.end method

.method private final cleanupTemp(Lokio/Path;)V
    .locals 1

    iget-object v0, p0, Lcom/flyfishxu/kadb/cert/OkioFilePrivateKeyStore;->fileSystem:Lokio/FileSystem;

    invoke-virtual {v0, p1}, Lokio/FileSystem;->exists(Lokio/Path;)Z

    move-result v0

    if-eqz v0, :cond_0

    :try_start_0
    sget-object v0, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    iget-object p0, p0, Lcom/flyfishxu/kadb/cert/OkioFilePrivateKeyStore;->fileSystem:Lokio/FileSystem;

    invoke-virtual {p0, p1}, Lokio/FileSystem;->delete(Lokio/Path;)V

    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    invoke-static {p0}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception p0

    sget-object p1, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    invoke-static {p0}, Lkotlin/ResultKt;->createFailure(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object p0

    invoke-static {p0}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    :cond_0
    :goto_0
    return-void
.end method

.method private final commitStagedWrite(Lokio/Path;Lokio/Path;)V
    .locals 0

    iget-object p0, p0, Lcom/flyfishxu/kadb/cert/OkioFilePrivateKeyStore;->fileSystem:Lokio/FileSystem;

    invoke-virtual {p0, p1, p2}, Lokio/FileSystem;->atomicMove(Lokio/Path;Lokio/Path;)V

    return-void
.end method

.method private final deleteIfExists(Lokio/Path;)V
    .locals 1

    iget-object v0, p0, Lcom/flyfishxu/kadb/cert/OkioFilePrivateKeyStore;->fileSystem:Lokio/FileSystem;

    invoke-virtual {v0, p1}, Lokio/FileSystem;->exists(Lokio/Path;)Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object p0, p0, Lcom/flyfishxu/kadb/cert/OkioFilePrivateKeyStore;->fileSystem:Lokio/FileSystem;

    invoke-virtual {p0, p1}, Lokio/FileSystem;->delete(Lokio/Path;)V

    :cond_0
    return-void
.end method

.method private final readOrNull(Lokio/Path;)[B
    .locals 3

    iget-object v0, p0, Lcom/flyfishxu/kadb/cert/OkioFilePrivateKeyStore;->fileSystem:Lokio/FileSystem;

    invoke-virtual {v0, p1}, Lokio/FileSystem;->exists(Lokio/Path;)Z

    move-result v0

    const/4 v1, 0x0

    if-nez v0, :cond_0

    return-object v1

    :cond_0
    iget-object p0, p0, Lcom/flyfishxu/kadb/cert/OkioFilePrivateKeyStore;->fileSystem:Lokio/FileSystem;

    invoke-virtual {p0, p1}, Lokio/FileSystem;->source(Lokio/Path;)Lokio/Source;

    move-result-object p0

    invoke-static {p0}, Lokio/Okio;->buffer(Lokio/Source;)Lokio/BufferedSource;

    move-result-object p0

    :try_start_0
    invoke-interface {p0}, Lokio/BufferedSource;->readByteArray()[B

    move-result-object p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    if-eqz p0, :cond_1

    :try_start_1
    invoke-interface {p0}, Ljava/io/Closeable;->close()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception v1

    :cond_1
    :goto_0
    move-object v2, v1

    move-object v1, p1

    move-object p1, v2

    goto :goto_1

    :catchall_1
    move-exception p1

    if-eqz p0, :cond_2

    :try_start_2
    invoke-interface {p0}, Ljava/io/Closeable;->close()V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_2

    goto :goto_1

    :catchall_2
    move-exception p0

    invoke-static {p1, p0}, Lkotlin/ExceptionsKt;->addSuppressed(Ljava/lang/Throwable;Ljava/lang/Throwable;)V

    :cond_2
    :goto_1
    if-nez p1, :cond_3

    return-object v1

    :cond_3
    throw p1
.end method

.method private final stageWrite(Lokio/Path;[B)Lokio/Path;
    .locals 4

    invoke-virtual {p1}, Lokio/Path;->parent()Lokio/Path;

    move-result-object v0

    if-eqz v0, :cond_0

    iget-object v1, p0, Lcom/flyfishxu/kadb/cert/OkioFilePrivateKeyStore;->fileSystem:Lokio/FileSystem;

    invoke-virtual {v1, v0}, Lokio/FileSystem;->exists(Lokio/Path;)Z

    move-result v1

    if-nez v1, :cond_0

    iget-object v1, p0, Lcom/flyfishxu/kadb/cert/OkioFilePrivateKeyStore;->fileSystem:Lokio/FileSystem;

    invoke-virtual {v1, v0}, Lokio/FileSystem;->createDirectories(Lokio/Path;)V

    :cond_0
    invoke-virtual {p1}, Lokio/Path;->name()Ljava/lang/String;

    move-result-object p1

    sget-object v1, Lkotlin/random/Random;->Default:Lkotlin/random/Random$Default;

    invoke-virtual {v1}, Lkotlin/random/Random$Default;->nextInt()I

    move-result v1

    invoke-static {v1}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v1

    const/16 v2, 0x10

    invoke-static {v1, v2}, Lkotlin/text/UStringsKt;->toString-V7xB4Y4(II)Ljava/lang/String;

    move-result-object v1

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p1, ".tmp-"

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v2, 0x0

    if-eqz v0, :cond_1

    const/4 v3, 0x2

    invoke-static {v0, p1, v2, v3, v1}, Lokio/Path;->resolve$default(Lokio/Path;Ljava/lang/String;ZILjava/lang/Object;)Lokio/Path;

    move-result-object v0

    if-nez v0, :cond_2

    :cond_1
    sget-object v0, Lokio/Path;->Companion:Lokio/Path$Companion;

    const/4 v3, 0x1

    invoke-static {v0, p1, v2, v3, v1}, Lokio/Path$Companion;->get$default(Lokio/Path$Companion;Ljava/lang/String;ZILjava/lang/Object;)Lokio/Path;

    move-result-object v0

    :cond_2
    iget-object p0, p0, Lcom/flyfishxu/kadb/cert/OkioFilePrivateKeyStore;->fileSystem:Lokio/FileSystem;

    invoke-virtual {p0, v0, v2}, Lokio/FileSystem;->sink(Lokio/Path;Z)Lokio/Sink;

    move-result-object p0

    invoke-static {p0}, Lokio/Okio;->buffer(Lokio/Sink;)Lokio/BufferedSink;

    move-result-object p0

    :try_start_0
    invoke-interface {p0, p2}, Lokio/BufferedSink;->write([B)Lokio/BufferedSink;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    if-eqz p0, :cond_3

    :try_start_1
    invoke-interface {p0}, Ljava/io/Closeable;->close()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception v1

    goto :goto_0

    :catchall_1
    move-exception v1

    if-eqz p0, :cond_3

    :try_start_2
    invoke-interface {p0}, Ljava/io/Closeable;->close()V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_2

    goto :goto_0

    :catchall_2
    move-exception p0

    invoke-static {v1, p0}, Lkotlin/ExceptionsKt;->addSuppressed(Ljava/lang/Throwable;Ljava/lang/Throwable;)V

    :cond_3
    :goto_0
    if-nez v1, :cond_4

    return-object v0

    :cond_4
    throw v1
.end method

.method private final writeAtomic(Lokio/Path;[B)V
    .locals 0

    invoke-direct {p0, p1, p2}, Lcom/flyfishxu/kadb/cert/OkioFilePrivateKeyStore;->stageWrite(Lokio/Path;[B)Lokio/Path;

    move-result-object p2

    :try_start_0
    invoke-direct {p0, p2, p1}, Lcom/flyfishxu/kadb/cert/OkioFilePrivateKeyStore;->commitStagedWrite(Lokio/Path;Lokio/Path;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    invoke-direct {p0, p2}, Lcom/flyfishxu/kadb/cert/OkioFilePrivateKeyStore;->cleanupTemp(Lokio/Path;)V

    return-void

    :catchall_0
    move-exception p1

    invoke-direct {p0, p2}, Lcom/flyfishxu/kadb/cert/OkioFilePrivateKeyStore;->cleanupTemp(Lokio/Path;)V

    throw p1
.end method


# virtual methods
.method public clear()V
    .locals 1

    iget-object v0, p0, Lcom/flyfishxu/kadb/cert/OkioFilePrivateKeyStore;->privateKeyPath:Lokio/Path;

    invoke-direct {p0, v0}, Lcom/flyfishxu/kadb/cert/OkioFilePrivateKeyStore;->deleteIfExists(Lokio/Path;)V

    return-void
.end method

.method public readPrivateKeyPem()[B
    .locals 1

    iget-object v0, p0, Lcom/flyfishxu/kadb/cert/OkioFilePrivateKeyStore;->privateKeyPath:Lokio/Path;

    invoke-direct {p0, v0}, Lcom/flyfishxu/kadb/cert/OkioFilePrivateKeyStore;->readOrNull(Lokio/Path;)[B

    move-result-object p0

    return-object p0
.end method

.method public writePrivateKeyPemAtomic([B)V
    .locals 1

    const-string v0, "privateKeyPem"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, Lcom/flyfishxu/kadb/cert/OkioFilePrivateKeyStore;->privateKeyPath:Lokio/Path;

    invoke-direct {p0, v0, p1}, Lcom/flyfishxu/kadb/cert/OkioFilePrivateKeyStore;->writeAtomic(Lokio/Path;[B)V

    return-void
.end method
