.class public final Lcom/flyfishxu/kadb/cert/CertUtilsKt;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u0014\n\u0000\n\u0002\u0010\u000e\n\u0002\u0008\u0004\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\"\u000e\u0010\u0000\u001a\u00020\u0001X\u0082T\u00a2\u0006\u0002\n\u0000\"\u000e\u0010\u0002\u001a\u00020\u0001X\u0082T\u00a2\u0006\u0002\n\u0000\"\u000e\u0010\u0003\u001a\u00020\u0001X\u0082T\u00a2\u0006\u0002\n\u0000\"\u000e\u0010\u0004\u001a\u00020\u0001X\u0082T\u00a2\u0006\u0002\n\u0000\"\u0016\u0010\u0005\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u00070\u0006X\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u0008"
    }
    d2 = {
        "KEY_BEGIN",
        "",
        "KEY_END",
        "CERT_BEGIN",
        "CERT_END",
        "providers",
        "",
        "Ljava/io/Serializable;",
        "com.github.IndiTheo:kadb"
    }
    k = 0x2
    mv = {
        0x2,
        0x4,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field private static final CERT_BEGIN:Ljava/lang/String; = "-----BEGIN CERTIFICATE-----"

.field private static final CERT_END:Ljava/lang/String; = "-----END CERTIFICATE-----"

.field private static final KEY_BEGIN:Ljava/lang/String; = "-----BEGIN PRIVATE KEY-----"

.field private static final KEY_END:Ljava/lang/String; = "-----END PRIVATE KEY-----"

.field private static final providers:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/io/Serializable;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 4

    new-instance v0, Lorg/bouncycastle/jce/provider/BouncyCastleProvider;

    invoke-direct {v0}, Lorg/bouncycastle/jce/provider/BouncyCastleProvider;-><init>()V

    const/4 v1, 0x3

    new-array v1, v1, [Ljava/io/Serializable;

    const/4 v2, 0x0

    const/4 v3, 0x0

    aput-object v2, v1, v3

    const/4 v2, 0x1

    aput-object v0, v1, v2

    const-string v0, "AndroidOpenSSL"

    const/4 v2, 0x2

    aput-object v0, v1, v2

    invoke-static {v1}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    sput-object v0, Lcom/flyfishxu/kadb/cert/CertUtilsKt;->providers:Ljava/util/List;

    return-void
.end method

.method public static final synthetic access$getProviders$p()Ljava/util/List;
    .locals 1

    sget-object v0, Lcom/flyfishxu/kadb/cert/CertUtilsKt;->providers:Ljava/util/List;

    return-object v0
.end method
