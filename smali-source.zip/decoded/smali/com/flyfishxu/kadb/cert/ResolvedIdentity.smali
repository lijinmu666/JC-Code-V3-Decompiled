.class public final Lcom/flyfishxu/kadb/cert/ResolvedIdentity;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u00002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0012\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\r\n\u0002\u0010\u000b\n\u0002\u0008\u0002\n\u0002\u0010\u0008\n\u0000\n\u0002\u0010\u000e\n\u0000\u0008\u0080\u0008\u0018\u00002\u00020\u0001B\u001f\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u00a2\u0006\u0004\u0008\u0008\u0010\tJ\t\u0010\u0010\u001a\u00020\u0003H\u00c6\u0003J\t\u0010\u0011\u001a\u00020\u0005H\u00c6\u0003J\t\u0010\u0012\u001a\u00020\u0007H\u00c6\u0003J\'\u0010\u0013\u001a\u00020\u00002\u0008\u0008\u0002\u0010\u0002\u001a\u00020\u00032\u0008\u0008\u0002\u0010\u0004\u001a\u00020\u00052\u0008\u0008\u0002\u0010\u0006\u001a\u00020\u0007H\u00c6\u0001J\u0014\u0010\u0014\u001a\u00020\u00152\u0008\u0010\u0016\u001a\u0004\u0018\u00010\u0001H\u00d6\u0083\u0004J\n\u0010\u0017\u001a\u00020\u0018H\u00d6\u0081\u0004J\n\u0010\u0019\u001a\u00020\u001aH\u00d6\u0081\u0004R\u0011\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\n\u0010\u000bR\u0011\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u000c\u0010\rR\u0011\u0010\u0006\u001a\u00020\u0007\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u000e\u0010\u000f\u00a8\u0006\u001b"
    }
    d2 = {
        "Lcom/flyfishxu/kadb/cert/ResolvedIdentity;",
        "",
        "privateKeyPem",
        "",
        "keyPair",
        "Lcom/flyfishxu/kadb/cert/AdbKeyPair;",
        "snapshot",
        "Lcom/flyfishxu/kadb/cert/KadbIdentitySnapshot;",
        "<init>",
        "([BLcom/flyfishxu/kadb/cert/AdbKeyPair;Lcom/flyfishxu/kadb/cert/KadbIdentitySnapshot;)V",
        "getPrivateKeyPem",
        "()[B",
        "getKeyPair",
        "()Lcom/flyfishxu/kadb/cert/AdbKeyPair;",
        "getSnapshot",
        "()Lcom/flyfishxu/kadb/cert/KadbIdentitySnapshot;",
        "component1",
        "component2",
        "component3",
        "copy",
        "equals",
        "",
        "other",
        "hashCode",
        "",
        "toString",
        "",
        "com.github.IndiTheo:kadb"
    }
    k = 0x1
    mv = {
        0x2,
        0x4,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field private final keyPair:Lcom/flyfishxu/kadb/cert/AdbKeyPair;

.field private final privateKeyPem:[B

.field private final snapshot:Lcom/flyfishxu/kadb/cert/KadbIdentitySnapshot;


# direct methods
.method public constructor <init>([BLcom/flyfishxu/kadb/cert/AdbKeyPair;Lcom/flyfishxu/kadb/cert/KadbIdentitySnapshot;)V
    .locals 1

    const-string v0, "privateKeyPem"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "keyPair"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "snapshot"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/flyfishxu/kadb/cert/ResolvedIdentity;->privateKeyPem:[B

    iput-object p2, p0, Lcom/flyfishxu/kadb/cert/ResolvedIdentity;->keyPair:Lcom/flyfishxu/kadb/cert/AdbKeyPair;

    iput-object p3, p0, Lcom/flyfishxu/kadb/cert/ResolvedIdentity;->snapshot:Lcom/flyfishxu/kadb/cert/KadbIdentitySnapshot;

    return-void
.end method

.method public static synthetic copy$default(Lcom/flyfishxu/kadb/cert/ResolvedIdentity;[BLcom/flyfishxu/kadb/cert/AdbKeyPair;Lcom/flyfishxu/kadb/cert/KadbIdentitySnapshot;ILjava/lang/Object;)Lcom/flyfishxu/kadb/cert/ResolvedIdentity;
    .locals 0

    and-int/lit8 p5, p4, 0x1

    if-eqz p5, :cond_0

    iget-object p1, p0, Lcom/flyfishxu/kadb/cert/ResolvedIdentity;->privateKeyPem:[B

    :cond_0
    and-int/lit8 p5, p4, 0x2

    if-eqz p5, :cond_1

    iget-object p2, p0, Lcom/flyfishxu/kadb/cert/ResolvedIdentity;->keyPair:Lcom/flyfishxu/kadb/cert/AdbKeyPair;

    :cond_1
    and-int/lit8 p4, p4, 0x4

    if-eqz p4, :cond_2

    iget-object p3, p0, Lcom/flyfishxu/kadb/cert/ResolvedIdentity;->snapshot:Lcom/flyfishxu/kadb/cert/KadbIdentitySnapshot;

    :cond_2
    invoke-virtual {p0, p1, p2, p3}, Lcom/flyfishxu/kadb/cert/ResolvedIdentity;->copy([BLcom/flyfishxu/kadb/cert/AdbKeyPair;Lcom/flyfishxu/kadb/cert/KadbIdentitySnapshot;)Lcom/flyfishxu/kadb/cert/ResolvedIdentity;

    move-result-object p0

    return-object p0
.end method


# virtual methods
.method public final component1()[B
    .locals 0

    iget-object p0, p0, Lcom/flyfishxu/kadb/cert/ResolvedIdentity;->privateKeyPem:[B

    return-object p0
.end method

.method public final component2()Lcom/flyfishxu/kadb/cert/AdbKeyPair;
    .locals 0

    iget-object p0, p0, Lcom/flyfishxu/kadb/cert/ResolvedIdentity;->keyPair:Lcom/flyfishxu/kadb/cert/AdbKeyPair;

    return-object p0
.end method

.method public final component3()Lcom/flyfishxu/kadb/cert/KadbIdentitySnapshot;
    .locals 0

    iget-object p0, p0, Lcom/flyfishxu/kadb/cert/ResolvedIdentity;->snapshot:Lcom/flyfishxu/kadb/cert/KadbIdentitySnapshot;

    return-object p0
.end method

.method public final copy([BLcom/flyfishxu/kadb/cert/AdbKeyPair;Lcom/flyfishxu/kadb/cert/KadbIdentitySnapshot;)Lcom/flyfishxu/kadb/cert/ResolvedIdentity;
    .locals 0

    const-string p0, "privateKeyPem"

    invoke-static {p1, p0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string p0, "keyPair"

    invoke-static {p2, p0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string p0, "snapshot"

    invoke-static {p3, p0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance p0, Lcom/flyfishxu/kadb/cert/ResolvedIdentity;

    invoke-direct {p0, p1, p2, p3}, Lcom/flyfishxu/kadb/cert/ResolvedIdentity;-><init>([BLcom/flyfishxu/kadb/cert/AdbKeyPair;Lcom/flyfishxu/kadb/cert/KadbIdentitySnapshot;)V

    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    const/4 v0, 0x1

    if-ne p0, p1, :cond_0

    return v0

    :cond_0
    instance-of v1, p1, Lcom/flyfishxu/kadb/cert/ResolvedIdentity;

    const/4 v2, 0x0

    if-nez v1, :cond_1

    return v2

    :cond_1
    check-cast p1, Lcom/flyfishxu/kadb/cert/ResolvedIdentity;

    iget-object v1, p0, Lcom/flyfishxu/kadb/cert/ResolvedIdentity;->privateKeyPem:[B

    iget-object v3, p1, Lcom/flyfishxu/kadb/cert/ResolvedIdentity;->privateKeyPem:[B

    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_2

    return v2

    :cond_2
    iget-object v1, p0, Lcom/flyfishxu/kadb/cert/ResolvedIdentity;->keyPair:Lcom/flyfishxu/kadb/cert/AdbKeyPair;

    iget-object v3, p1, Lcom/flyfishxu/kadb/cert/ResolvedIdentity;->keyPair:Lcom/flyfishxu/kadb/cert/AdbKeyPair;

    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_3

    return v2

    :cond_3
    iget-object p0, p0, Lcom/flyfishxu/kadb/cert/ResolvedIdentity;->snapshot:Lcom/flyfishxu/kadb/cert/KadbIdentitySnapshot;

    iget-object p1, p1, Lcom/flyfishxu/kadb/cert/ResolvedIdentity;->snapshot:Lcom/flyfishxu/kadb/cert/KadbIdentitySnapshot;

    invoke-static {p0, p1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_4

    return v2

    :cond_4
    return v0
.end method

.method public final getKeyPair()Lcom/flyfishxu/kadb/cert/AdbKeyPair;
    .locals 0

    iget-object p0, p0, Lcom/flyfishxu/kadb/cert/ResolvedIdentity;->keyPair:Lcom/flyfishxu/kadb/cert/AdbKeyPair;

    return-object p0
.end method

.method public final getPrivateKeyPem()[B
    .locals 0

    iget-object p0, p0, Lcom/flyfishxu/kadb/cert/ResolvedIdentity;->privateKeyPem:[B

    return-object p0
.end method

.method public final getSnapshot()Lcom/flyfishxu/kadb/cert/KadbIdentitySnapshot;
    .locals 0

    iget-object p0, p0, Lcom/flyfishxu/kadb/cert/ResolvedIdentity;->snapshot:Lcom/flyfishxu/kadb/cert/KadbIdentitySnapshot;

    return-object p0
.end method

.method public hashCode()I
    .locals 2

    iget-object v0, p0, Lcom/flyfishxu/kadb/cert/ResolvedIdentity;->privateKeyPem:[B

    invoke-static {v0}, Ljava/util/Arrays;->hashCode([B)I

    move-result v0

    mul-int/lit8 v0, v0, 0x1f

    iget-object v1, p0, Lcom/flyfishxu/kadb/cert/ResolvedIdentity;->keyPair:Lcom/flyfishxu/kadb/cert/AdbKeyPair;

    invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I

    move-result v1

    add-int/2addr v0, v1

    mul-int/lit8 v0, v0, 0x1f

    iget-object p0, p0, Lcom/flyfishxu/kadb/cert/ResolvedIdentity;->snapshot:Lcom/flyfishxu/kadb/cert/KadbIdentitySnapshot;

    invoke-virtual {p0}, Lcom/flyfishxu/kadb/cert/KadbIdentitySnapshot;->hashCode()I

    move-result p0

    add-int/2addr v0, p0

    return v0
.end method

.method public toString()Ljava/lang/String;
    .locals 4

    iget-object v0, p0, Lcom/flyfishxu/kadb/cert/ResolvedIdentity;->privateKeyPem:[B

    invoke-static {v0}, Ljava/util/Arrays;->toString([B)Ljava/lang/String;

    move-result-object v0

    iget-object v1, p0, Lcom/flyfishxu/kadb/cert/ResolvedIdentity;->keyPair:Lcom/flyfishxu/kadb/cert/AdbKeyPair;

    iget-object p0, p0, Lcom/flyfishxu/kadb/cert/ResolvedIdentity;->snapshot:Lcom/flyfishxu/kadb/cert/KadbIdentitySnapshot;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "ResolvedIdentity(privateKeyPem="

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, ", keyPair="

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v0, ", snapshot="

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p0, ")"

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
