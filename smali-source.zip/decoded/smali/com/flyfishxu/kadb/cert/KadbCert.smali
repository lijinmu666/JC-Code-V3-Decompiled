.class public final Lcom/flyfishxu/kadb/cert/KadbCert;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/flyfishxu/kadb/cert/KadbCert$State;
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000d\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0008\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0010\u0012\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\t\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0008\u0007\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0003\n\u0002\u0008\u0002\u0008\u00c6\u0002\u0018\u00002\u00020\u0001:\u00010B\t\u0008\u0002\u00a2\u0006\u0004\u0008\u0002\u0010\u0003J(\u0010\u000e\u001a\u00020\u000f2\u0006\u0010\u0005\u001a\u00020\u00062\u0008\u0008\u0002\u0010\u0007\u001a\u00020\u00082\u000e\u0008\u0002\u0010\t\u001a\u0008\u0012\u0004\u0012\u00020\u000b0\nJ\u0006\u0010\u0010\u001a\u00020\u0011J\u0006\u0010\u0012\u001a\u00020\u0011J\u001a\u0010\u0013\u001a\u00020\u00112\u0006\u0010\u0014\u001a\u00020\u000b2\n\u0008\u0002\u0010\u0015\u001a\u0004\u0018\u00010\u000bJ\u000e\u0010\u0016\u001a\u00020\u00112\u0006\u0010\u0014\u001a\u00020\u000bJ\u0008\u0010\u0017\u001a\u0004\u0018\u00010\u0011J\u0008\u0010\u0018\u001a\u0004\u0018\u00010\u000bJ\u0006\u0010\u0019\u001a\u00020\u000fJ\r\u0010\u001a\u001a\u00020\u001bH\u0000\u00a2\u0006\u0002\u0008\u001cJ\r\u0010\u001d\u001a\u00020\u001eH\u0000\u00a2\u0006\u0002\u0008\u001fJ\u0008\u0010 \u001a\u00020!H\u0002J\u0008\u0010\"\u001a\u00020!H\u0002J\u0008\u0010#\u001a\u00020!H\u0002J\u001a\u0010$\u001a\u00020%2\u0006\u0010\u0014\u001a\u00020\u000b2\u0008\u0010\u0015\u001a\u0004\u0018\u00010\u000bH\u0002J\u0010\u0010&\u001a\u00020\u000f2\u0006\u0010\u0014\u001a\u00020\u000bH\u0002J\n\u0010\'\u001a\u0004\u0018\u00010\u000bH\u0002J\u0010\u0010(\u001a\u00020\u000f2\u0006\u0010\u0014\u001a\u00020\u000bH\u0002J\u0010\u0010)\u001a\u00020\u001e2\u0006\u0010*\u001a\u00020\u001bH\u0002J\u0010\u0010+\u001a\u00020\u000f2\u0006\u0010\u0007\u001a\u00020\u0008H\u0002J\u0010\u0010,\u001a\u00020-2\u0006\u0010.\u001a\u00020/H\u0002R\u000e\u0010\u0004\u001a\u00020\u0001X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0006X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0008X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0014\u0010\t\u001a\u0008\u0012\u0004\u0012\u00020\u000b0\nX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000c\u001a\u00020\rX\u0082\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u00061"
    }
    d2 = {
        "Lcom/flyfishxu/kadb/cert/KadbCert;",
        "",
        "<init>",
        "()V",
        "lock",
        "store",
        "Lcom/flyfishxu/kadb/cert/KadbPrivateKeyStore;",
        "policy",
        "Lcom/flyfishxu/kadb/cert/KadbCertPolicy;",
        "additionalPrivateKeysPem",
        "",
        "",
        "state",
        "Lcom/flyfishxu/kadb/cert/KadbCert$State;",
        "configure",
        "",
        "ensureReady",
        "Lcom/flyfishxu/kadb/cert/KadbIdentitySnapshot;",
        "rotate",
        "importIdentity",
        "privateKeyPem",
        "certificatePem",
        "importPrivateKey",
        "exportIdentityOrNull",
        "exportPrivateKeyOrNull",
        "clear",
        "currentKeyPair",
        "Lcom/flyfishxu/kadb/cert/AdbKeyPair;",
        "currentKeyPair$com_github_IndiTheo_kadb",
        "currentKeySet",
        "Lcom/flyfishxu/kadb/cert/HostKeySet;",
        "currentKeySet$com_github_IndiTheo_kadb",
        "ensureReadyStateLocked",
        "Lcom/flyfishxu/kadb/cert/KadbCert$State$Ready;",
        "loadOrGenerateState",
        "regenerateAndPersistState",
        "resolveImportedIdentity",
        "Lcom/flyfishxu/kadb/cert/ResolvedIdentity;",
        "validatePrivateKeyOrThrow",
        "readPrivateKeyFromStoreOrThrow",
        "writePrivateKeyOrThrow",
        "resolveHostKeySet",
        "defaultKeyPair",
        "validatePolicy",
        "toKadbCertException",
        "Lcom/flyfishxu/kadb/cert/KadbCertException;",
        "error",
        "",
        "State",
        "com.github.IndiTheo:kadb"
    }
    k = 0x1
    mv = {
        0x2,
        0x4,
        0x0
    }
    xi = 0x30
.end annotation

.annotation build Lkotlin/jvm/internal/SourceDebugExtension;
    value = {
        "SMAP\nKadbCert.kt\nKotlin\n*S Kotlin\n*F\n+ 1 KadbCert.kt\ncom/flyfishxu/kadb/cert/KadbCert\n+ 2 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n+ 3 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,233:1\n777#2:234\n873#2,2:235\n1739#2:237\n1814#2,3:238\n1#3:241\n*S KotlinDebug\n*F\n+ 1 KadbCert.kt\ncom/flyfishxu/kadb/cert/KadbCert\n*L\n36#1:234\n36#1:235,2\n37#1:237\n37#1:238,3\n*E\n"
    }
.end annotation


# static fields
.field public static final INSTANCE:Lcom/flyfishxu/kadb/cert/KadbCert;

.field private static volatile additionalPrivateKeysPem:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "[B>;"
        }
    .end annotation
.end field

.field private static final lock:Ljava/lang/Object;

.field private static volatile policy:Lcom/flyfishxu/kadb/cert/KadbCertPolicy;

.field private static volatile state:Lcom/flyfishxu/kadb/cert/KadbCert$State;

.field private static volatile store:Lcom/flyfishxu/kadb/cert/KadbPrivateKeyStore;


# direct methods
.method static constructor <clinit>()V
    .locals 8

    new-instance v0, Lcom/flyfishxu/kadb/cert/KadbCert;

    invoke-direct {v0}, Lcom/flyfishxu/kadb/cert/KadbCert;-><init>()V

    sput-object v0, Lcom/flyfishxu/kadb/cert/KadbCert;->INSTANCE:Lcom/flyfishxu/kadb/cert/KadbCert;

    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Lcom/flyfishxu/kadb/cert/KadbCert;->lock:Ljava/lang/Object;

    new-instance v0, Lcom/flyfishxu/kadb/cert/InMemoryPrivateKeyStore;

    invoke-direct {v0}, Lcom/flyfishxu/kadb/cert/InMemoryPrivateKeyStore;-><init>()V

    sput-object v0, Lcom/flyfishxu/kadb/cert/KadbCert;->store:Lcom/flyfishxu/kadb/cert/KadbPrivateKeyStore;

    new-instance v0, Lcom/flyfishxu/kadb/cert/KadbCertPolicy;

    const/16 v6, 0xf

    const/4 v7, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    move-object v1, v0

    invoke-direct/range {v1 .. v7}, Lcom/flyfishxu/kadb/cert/KadbCertPolicy;-><init>(IIZLcom/flyfishxu/kadb/cert/KadbCertPolicy$Subject;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    sput-object v0, Lcom/flyfishxu/kadb/cert/KadbCert;->policy:Lcom/flyfishxu/kadb/cert/KadbCertPolicy;

    invoke-static {}, Lkotlin/collections/CollectionsKt;->emptyList()Ljava/util/List;

    move-result-object v0

    sput-object v0, Lcom/flyfishxu/kadb/cert/KadbCert;->additionalPrivateKeysPem:Ljava/util/List;

    sget-object v0, Lcom/flyfishxu/kadb/cert/KadbCert$State$Uninitialized;->INSTANCE:Lcom/flyfishxu/kadb/cert/KadbCert$State$Uninitialized;

    sput-object v0, Lcom/flyfishxu/kadb/cert/KadbCert;->state:Lcom/flyfishxu/kadb/cert/KadbCert$State;

    return-void
.end method

.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static synthetic configure$default(Lcom/flyfishxu/kadb/cert/KadbCert;Lcom/flyfishxu/kadb/cert/KadbPrivateKeyStore;Lcom/flyfishxu/kadb/cert/KadbCertPolicy;Ljava/util/List;ILjava/lang/Object;)V
    .locals 7

    and-int/lit8 p5, p4, 0x2

    if-eqz p5, :cond_0

    new-instance p2, Lcom/flyfishxu/kadb/cert/KadbCertPolicy;

    const/16 v5, 0xf

    const/4 v6, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    move-object v0, p2

    invoke-direct/range {v0 .. v6}, Lcom/flyfishxu/kadb/cert/KadbCertPolicy;-><init>(IIZLcom/flyfishxu/kadb/cert/KadbCertPolicy$Subject;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    :cond_0
    and-int/lit8 p4, p4, 0x4

    if-eqz p4, :cond_1

    invoke-static {}, Lkotlin/collections/CollectionsKt;->emptyList()Ljava/util/List;

    move-result-object p3

    :cond_1
    invoke-virtual {p0, p1, p2, p3}, Lcom/flyfishxu/kadb/cert/KadbCert;->configure(Lcom/flyfishxu/kadb/cert/KadbPrivateKeyStore;Lcom/flyfishxu/kadb/cert/KadbCertPolicy;Ljava/util/List;)V

    return-void
.end method

.method private final ensureReadyStateLocked()Lcom/flyfishxu/kadb/cert/KadbCert$State$Ready;
    .locals 2

    sget-object v0, Lcom/flyfishxu/kadb/cert/KadbCert;->state:Lcom/flyfishxu/kadb/cert/KadbCert$State;

    instance-of v1, v0, Lcom/flyfishxu/kadb/cert/KadbCert$State$Ready;

    if-eqz v1, :cond_0

    check-cast v0, Lcom/flyfishxu/kadb/cert/KadbCert$State$Ready;

    return-object v0

    :cond_0
    :try_start_0
    invoke-direct {p0}, Lcom/flyfishxu/kadb/cert/KadbCert;->loadOrGenerateState()Lcom/flyfishxu/kadb/cert/KadbCert$State$Ready;

    move-result-object v0

    sput-object v0, Lcom/flyfishxu/kadb/cert/KadbCert;->state:Lcom/flyfishxu/kadb/cert/KadbCert$State;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    return-object v0

    :catchall_0
    move-exception v0

    new-instance v1, Lcom/flyfishxu/kadb/cert/KadbCert$State$Broken;

    invoke-direct {v1, v0}, Lcom/flyfishxu/kadb/cert/KadbCert$State$Broken;-><init>(Ljava/lang/Throwable;)V

    sput-object v1, Lcom/flyfishxu/kadb/cert/KadbCert;->state:Lcom/flyfishxu/kadb/cert/KadbCert$State;

    invoke-direct {p0, v0}, Lcom/flyfishxu/kadb/cert/KadbCert;->toKadbCertException(Ljava/lang/Throwable;)Lcom/flyfishxu/kadb/cert/KadbCertException;

    move-result-object p0

    throw p0
.end method

.method public static synthetic importIdentity$default(Lcom/flyfishxu/kadb/cert/KadbCert;[B[BILjava/lang/Object;)Lcom/flyfishxu/kadb/cert/KadbIdentitySnapshot;
    .locals 0

    and-int/lit8 p3, p3, 0x2

    if-eqz p3, :cond_0

    const/4 p2, 0x0

    :cond_0
    invoke-virtual {p0, p1, p2}, Lcom/flyfishxu/kadb/cert/KadbCert;->importIdentity([B[B)Lcom/flyfishxu/kadb/cert/KadbIdentitySnapshot;

    move-result-object p0

    return-object p0
.end method

.method private final loadOrGenerateState()Lcom/flyfishxu/kadb/cert/KadbCert$State$Ready;
    .locals 3

    invoke-direct {p0}, Lcom/flyfishxu/kadb/cert/KadbCert;->readPrivateKeyFromStoreOrThrow()[B

    move-result-object v0

    if-eqz v0, :cond_2

    array-length v1, v0

    if-nez v1, :cond_0

    goto :goto_1

    :cond_0
    :try_start_0
    invoke-direct {p0, v0}, Lcom/flyfishxu/kadb/cert/KadbCert;->validatePrivateKeyOrThrow([B)V

    sget-object v1, Lcom/flyfishxu/kadb/cert/CertUtils;->INSTANCE:Lcom/flyfishxu/kadb/cert/CertUtils;

    sget-object v2, Lcom/flyfishxu/kadb/cert/KadbCert;->policy:Lcom/flyfishxu/kadb/cert/KadbCertPolicy;

    invoke-virtual {v1, v0, v2}, Lcom/flyfishxu/kadb/cert/CertUtils;->identityFromPrivateKey([BLcom/flyfishxu/kadb/cert/KadbCertPolicy;)Lcom/flyfishxu/kadb/cert/ResolvedIdentity;

    move-result-object v0

    new-instance v1, Lcom/flyfishxu/kadb/cert/KadbCert$State$Ready;

    invoke-virtual {v0}, Lcom/flyfishxu/kadb/cert/ResolvedIdentity;->getSnapshot()Lcom/flyfishxu/kadb/cert/KadbIdentitySnapshot;

    move-result-object v2

    invoke-virtual {v2}, Lcom/flyfishxu/kadb/cert/KadbIdentitySnapshot;->deepCopy$com_github_IndiTheo_kadb()Lcom/flyfishxu/kadb/cert/KadbIdentitySnapshot;

    move-result-object v2

    invoke-virtual {v0}, Lcom/flyfishxu/kadb/cert/ResolvedIdentity;->getKeyPair()Lcom/flyfishxu/kadb/cert/AdbKeyPair;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/flyfishxu/kadb/cert/KadbCert;->resolveHostKeySet(Lcom/flyfishxu/kadb/cert/AdbKeyPair;)Lcom/flyfishxu/kadb/cert/HostKeySet;

    move-result-object v0

    invoke-direct {v1, v2, v0}, Lcom/flyfishxu/kadb/cert/KadbCert$State$Ready;-><init>(Lcom/flyfishxu/kadb/cert/KadbIdentitySnapshot;Lcom/flyfishxu/kadb/cert/HostKeySet;)V
    :try_end_0
    .catch Lcom/flyfishxu/kadb/cert/KadbCertException$PrivateKeyParseFailed; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception v0

    sget-object v1, Lcom/flyfishxu/kadb/cert/KadbCert;->policy:Lcom/flyfishxu/kadb/cert/KadbCertPolicy;

    invoke-virtual {v1}, Lcom/flyfishxu/kadb/cert/KadbCertPolicy;->getAutoHealInvalidPrivateKey()Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-direct {p0}, Lcom/flyfishxu/kadb/cert/KadbCert;->regenerateAndPersistState()Lcom/flyfishxu/kadb/cert/KadbCert$State$Ready;

    move-result-object v1

    :goto_0
    return-object v1

    :cond_1
    throw v0

    :cond_2
    :goto_1
    invoke-direct {p0}, Lcom/flyfishxu/kadb/cert/KadbCert;->regenerateAndPersistState()Lcom/flyfishxu/kadb/cert/KadbCert$State$Ready;

    move-result-object p0

    return-object p0
.end method

.method private final readPrivateKeyFromStoreOrThrow()[B
    .locals 1

    :try_start_0
    sget-object p0, Lcom/flyfishxu/kadb/cert/KadbCert;->store:Lcom/flyfishxu/kadb/cert/KadbPrivateKeyStore;

    invoke-interface {p0}, Lcom/flyfishxu/kadb/cert/KadbPrivateKeyStore;->readPrivateKeyPem()[B

    move-result-object p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    return-object p0

    :catchall_0
    move-exception p0

    new-instance v0, Lcom/flyfishxu/kadb/cert/KadbCertException$StoreReadFailed;

    invoke-direct {v0, p0}, Lcom/flyfishxu/kadb/cert/KadbCertException$StoreReadFailed;-><init>(Ljava/lang/Throwable;)V

    throw v0
.end method

.method private final regenerateAndPersistState()Lcom/flyfishxu/kadb/cert/KadbCert$State$Ready;
    .locals 3

    sget-object v0, Lcom/flyfishxu/kadb/cert/CertUtils;->INSTANCE:Lcom/flyfishxu/kadb/cert/CertUtils;

    sget-object v1, Lcom/flyfishxu/kadb/cert/KadbCert;->policy:Lcom/flyfishxu/kadb/cert/KadbCertPolicy;

    invoke-virtual {v0, v1}, Lcom/flyfishxu/kadb/cert/CertUtils;->generateNewIdentity(Lcom/flyfishxu/kadb/cert/KadbCertPolicy;)Lcom/flyfishxu/kadb/cert/ResolvedIdentity;

    move-result-object v0

    invoke-virtual {v0}, Lcom/flyfishxu/kadb/cert/ResolvedIdentity;->getPrivateKeyPem()[B

    move-result-object v1

    invoke-direct {p0, v1}, Lcom/flyfishxu/kadb/cert/KadbCert;->writePrivateKeyOrThrow([B)V

    new-instance v1, Lcom/flyfishxu/kadb/cert/KadbCert$State$Ready;

    invoke-virtual {v0}, Lcom/flyfishxu/kadb/cert/ResolvedIdentity;->getSnapshot()Lcom/flyfishxu/kadb/cert/KadbIdentitySnapshot;

    move-result-object v2

    invoke-virtual {v2}, Lcom/flyfishxu/kadb/cert/KadbIdentitySnapshot;->deepCopy$com_github_IndiTheo_kadb()Lcom/flyfishxu/kadb/cert/KadbIdentitySnapshot;

    move-result-object v2

    invoke-virtual {v0}, Lcom/flyfishxu/kadb/cert/ResolvedIdentity;->getKeyPair()Lcom/flyfishxu/kadb/cert/AdbKeyPair;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/flyfishxu/kadb/cert/KadbCert;->resolveHostKeySet(Lcom/flyfishxu/kadb/cert/AdbKeyPair;)Lcom/flyfishxu/kadb/cert/HostKeySet;

    move-result-object p0

    invoke-direct {v1, v2, p0}, Lcom/flyfishxu/kadb/cert/KadbCert$State$Ready;-><init>(Lcom/flyfishxu/kadb/cert/KadbIdentitySnapshot;Lcom/flyfishxu/kadb/cert/HostKeySet;)V

    return-object v1
.end method

.method private final resolveHostKeySet(Lcom/flyfishxu/kadb/cert/AdbKeyPair;)Lcom/flyfishxu/kadb/cert/HostKeySet;
    .locals 5

    filled-new-array {p1}, [Lcom/flyfishxu/kadb/cert/AdbKeyPair;

    move-result-object p0

    invoke-static {p0}, Lkotlin/collections/CollectionsKt;->mutableListOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object p0

    sget-object v0, Lcom/flyfishxu/kadb/cert/CertUtils;->INSTANCE:Lcom/flyfishxu/kadb/cert/CertUtils;

    invoke-virtual {p1}, Lcom/flyfishxu/kadb/cert/AdbKeyPair;->getPublicKey()Ljava/security/PublicKey;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/flyfishxu/kadb/cert/CertUtils;->fingerprintSha256(Ljava/security/PublicKey;)Ljava/lang/String;

    move-result-object v0

    filled-new-array {v0}, [Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lkotlin/collections/SetsKt;->mutableSetOf([Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v0

    sget-object v1, Lcom/flyfishxu/kadb/cert/KadbCert;->additionalPrivateKeysPem:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_0
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_3

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, [B

    :try_start_0
    sget-object v3, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    sget-object v3, Lcom/flyfishxu/kadb/cert/CertUtils;->INSTANCE:Lcom/flyfishxu/kadb/cert/CertUtils;

    sget-object v4, Lcom/flyfishxu/kadb/cert/KadbCert;->policy:Lcom/flyfishxu/kadb/cert/KadbCertPolicy;

    invoke-virtual {v3, v2, v4}, Lcom/flyfishxu/kadb/cert/CertUtils;->identityFromPrivateKey([BLcom/flyfishxu/kadb/cert/KadbCertPolicy;)Lcom/flyfishxu/kadb/cert/ResolvedIdentity;

    move-result-object v2

    invoke-virtual {v2}, Lcom/flyfishxu/kadb/cert/ResolvedIdentity;->getKeyPair()Lcom/flyfishxu/kadb/cert/AdbKeyPair;

    move-result-object v2

    invoke-static {v2}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_1

    :catchall_0
    move-exception v2

    sget-object v3, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    invoke-static {v2}, Lkotlin/ResultKt;->createFailure(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object v2

    invoke-static {v2}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    :goto_1
    invoke-static {v2}, Lkotlin/Result;->isFailure-impl(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_1

    const/4 v2, 0x0

    :cond_1
    check-cast v2, Lcom/flyfishxu/kadb/cert/AdbKeyPair;

    if-nez v2, :cond_2

    goto :goto_0

    :cond_2
    sget-object v3, Lcom/flyfishxu/kadb/cert/CertUtils;->INSTANCE:Lcom/flyfishxu/kadb/cert/CertUtils;

    invoke-virtual {v2}, Lcom/flyfishxu/kadb/cert/AdbKeyPair;->getPublicKey()Ljava/security/PublicKey;

    move-result-object v4

    invoke-virtual {v3, v4}, Lcom/flyfishxu/kadb/cert/CertUtils;->fingerprintSha256(Ljava/security/PublicKey;)Ljava/lang/String;

    move-result-object v3

    invoke-interface {v0, v3}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_0

    invoke-interface {p0, v2}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_3
    new-instance v0, Lcom/flyfishxu/kadb/cert/HostKeySet;

    invoke-direct {v0, p1, p0}, Lcom/flyfishxu/kadb/cert/HostKeySet;-><init>(Lcom/flyfishxu/kadb/cert/AdbKeyPair;Ljava/util/List;)V

    return-object v0
.end method

.method private final resolveImportedIdentity([B[B)Lcom/flyfishxu/kadb/cert/ResolvedIdentity;
    .locals 2

    invoke-direct {p0, p1}, Lcom/flyfishxu/kadb/cert/KadbCert;->validatePrivateKeyOrThrow([B)V

    if-eqz p2, :cond_5

    array-length p0, p2

    if-nez p0, :cond_0

    goto :goto_3

    :cond_0
    :try_start_0
    sget-object p0, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    sget-object p0, Lcom/flyfishxu/kadb/cert/CertUtils;->INSTANCE:Lcom/flyfishxu/kadb/cert/CertUtils;

    invoke-virtual {p0, p1, p2}, Lcom/flyfishxu/kadb/cert/CertUtils;->identityFromPrivateKeyAndCertificate([B[B)Lcom/flyfishxu/kadb/cert/ResolvedIdentity;

    move-result-object p0

    invoke-static {p0}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception p0

    sget-object p2, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    invoke-static {p0}, Lkotlin/ResultKt;->createFailure(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object p0

    invoke-static {p0}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    :goto_0
    invoke-static {p0}, Lkotlin/Result;->isFailure-impl(Ljava/lang/Object;)Z

    move-result p2

    const/4 v0, 0x0

    if-eqz p2, :cond_1

    move-object p0, v0

    :cond_1
    check-cast p0, Lcom/flyfishxu/kadb/cert/ResolvedIdentity;

    if-eqz p0, :cond_4

    invoke-virtual {p0}, Lcom/flyfishxu/kadb/cert/ResolvedIdentity;->getKeyPair()Lcom/flyfishxu/kadb/cert/AdbKeyPair;

    move-result-object p2

    invoke-virtual {p2}, Lcom/flyfishxu/kadb/cert/AdbKeyPair;->getCertificate()Ljava/security/cert/Certificate;

    move-result-object p2

    instance-of v1, p2, Ljava/security/cert/X509Certificate;

    if-eqz v1, :cond_2

    move-object v0, p2

    check-cast v0, Ljava/security/cert/X509Certificate;

    :cond_2
    if-eqz v0, :cond_4

    :try_start_1
    sget-object p2, Lcom/flyfishxu/kadb/cert/CertUtils;->INSTANCE:Lcom/flyfishxu/kadb/cert/CertUtils;

    invoke-virtual {p2, v0}, Lcom/flyfishxu/kadb/cert/CertUtils;->validateCertificate(Ljava/security/cert/X509Certificate;)V

    sget-object p2, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    invoke-static {p2}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p2
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    goto :goto_1

    :catchall_1
    move-exception p2

    sget-object v0, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    invoke-static {p2}, Lkotlin/ResultKt;->createFailure(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object p2

    invoke-static {p2}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p2

    :goto_1
    invoke-static {p2}, Lkotlin/Result;->exceptionOrNull-impl(Ljava/lang/Object;)Ljava/lang/Throwable;

    move-result-object v0

    if-nez v0, :cond_3

    goto :goto_2

    :cond_3
    sget-object p2, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    :goto_2
    check-cast p2, Ljava/lang/Boolean;

    invoke-virtual {p2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p2

    if-eqz p2, :cond_4

    return-object p0

    :cond_4
    sget-object p0, Lcom/flyfishxu/kadb/cert/CertUtils;->INSTANCE:Lcom/flyfishxu/kadb/cert/CertUtils;

    sget-object p2, Lcom/flyfishxu/kadb/cert/KadbCert;->policy:Lcom/flyfishxu/kadb/cert/KadbCertPolicy;

    invoke-virtual {p0, p1, p2}, Lcom/flyfishxu/kadb/cert/CertUtils;->identityFromPrivateKey([BLcom/flyfishxu/kadb/cert/KadbCertPolicy;)Lcom/flyfishxu/kadb/cert/ResolvedIdentity;

    move-result-object p0

    return-object p0

    :cond_5
    :goto_3
    sget-object p0, Lcom/flyfishxu/kadb/cert/CertUtils;->INSTANCE:Lcom/flyfishxu/kadb/cert/CertUtils;

    sget-object p2, Lcom/flyfishxu/kadb/cert/KadbCert;->policy:Lcom/flyfishxu/kadb/cert/KadbCertPolicy;

    invoke-virtual {p0, p1, p2}, Lcom/flyfishxu/kadb/cert/CertUtils;->identityFromPrivateKey([BLcom/flyfishxu/kadb/cert/KadbCertPolicy;)Lcom/flyfishxu/kadb/cert/ResolvedIdentity;

    move-result-object p0

    return-object p0
.end method

.method private final toKadbCertException(Ljava/lang/Throwable;)Lcom/flyfishxu/kadb/cert/KadbCertException;
    .locals 1

    instance-of p0, p1, Lcom/flyfishxu/kadb/cert/KadbCertException;

    if-eqz p0, :cond_0

    check-cast p1, Lcom/flyfishxu/kadb/cert/KadbCertException;

    goto :goto_0

    :cond_0
    new-instance p0, Lcom/flyfishxu/kadb/cert/KadbCertException$PolicyViolation;

    const-string v0, "Unexpected KadbCert error"

    invoke-direct {p0, v0, p1}, Lcom/flyfishxu/kadb/cert/KadbCertException$PolicyViolation;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    move-object p1, p0

    :goto_0
    return-object p1
.end method

.method private final validatePolicy(Lcom/flyfishxu/kadb/cert/KadbCertPolicy;)V
    .locals 3

    invoke-virtual {p1}, Lcom/flyfishxu/kadb/cert/KadbCertPolicy;->getKeySizeBits()I

    move-result p0

    const/16 v0, 0x800

    const/4 v1, 0x2

    const/4 v2, 0x0

    if-ne p0, v0, :cond_1

    invoke-virtual {p1}, Lcom/flyfishxu/kadb/cert/KadbCertPolicy;->getCertValidityDays()I

    move-result p0

    if-lez p0, :cond_0

    return-void

    :cond_0
    new-instance p0, Lcom/flyfishxu/kadb/cert/KadbCertException$PolicyViolation;

    const-string p1, "Certificate validity must be greater than 0"

    invoke-direct {p0, p1, v2, v1, v2}, Lcom/flyfishxu/kadb/cert/KadbCertException$PolicyViolation;-><init>(Ljava/lang/String;Ljava/lang/Throwable;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    throw p0

    :cond_1
    new-instance p0, Lcom/flyfishxu/kadb/cert/KadbCertException$PolicyViolation;

    const-string p1, "Only RSA 2048 is supported"

    invoke-direct {p0, p1, v2, v1, v2}, Lcom/flyfishxu/kadb/cert/KadbCertException$PolicyViolation;-><init>(Ljava/lang/String;Ljava/lang/Throwable;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    throw p0
.end method

.method private final validatePrivateKeyOrThrow([B)V
    .locals 0

    :try_start_0
    sget-object p0, Lcom/flyfishxu/kadb/cert/CertUtils;->INSTANCE:Lcom/flyfishxu/kadb/cert/CertUtils;

    invoke-virtual {p0, p1}, Lcom/flyfishxu/kadb/cert/CertUtils;->parsePrivateKeyPem([B)Ljava/security/PrivateKey;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    return-void

    :catchall_0
    move-exception p0

    sget-object p1, Lcom/flyfishxu/kadb/cert/KadbCertException;->Companion:Lcom/flyfishxu/kadb/cert/KadbCertException$Companion;

    invoke-virtual {p1, p0}, Lcom/flyfishxu/kadb/cert/KadbCertException$Companion;->fromPrivateKeyParseError$com_github_IndiTheo_kadb(Ljava/lang/Throwable;)Lcom/flyfishxu/kadb/cert/KadbCertException;

    move-result-object p0

    throw p0
.end method

.method private final writePrivateKeyOrThrow([B)V
    .locals 0

    :try_start_0
    sget-object p0, Lcom/flyfishxu/kadb/cert/KadbCert;->store:Lcom/flyfishxu/kadb/cert/KadbPrivateKeyStore;

    invoke-interface {p0, p1}, Lcom/flyfishxu/kadb/cert/KadbPrivateKeyStore;->writePrivateKeyPemAtomic([B)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    return-void

    :catchall_0
    move-exception p0

    new-instance p1, Lcom/flyfishxu/kadb/cert/KadbCertException$StoreWriteFailed;

    invoke-direct {p1, p0}, Lcom/flyfishxu/kadb/cert/KadbCertException$StoreWriteFailed;-><init>(Ljava/lang/Throwable;)V

    throw p1
.end method


# virtual methods
.method public final clear()V
    .locals 2

    sget-object p0, Lcom/flyfishxu/kadb/cert/KadbCert;->lock:Ljava/lang/Object;

    monitor-enter p0

    :try_start_0
    sget-object v0, Lcom/flyfishxu/kadb/cert/KadbCert;->store:Lcom/flyfishxu/kadb/cert/KadbPrivateKeyStore;

    invoke-interface {v0}, Lcom/flyfishxu/kadb/cert/KadbPrivateKeyStore;->clear()V

    sget-object v0, Lcom/flyfishxu/kadb/cert/KadbCert$State$Uninitialized;->INSTANCE:Lcom/flyfishxu/kadb/cert/KadbCert$State$Uninitialized;

    sput-object v0, Lcom/flyfishxu/kadb/cert/KadbCert;->state:Lcom/flyfishxu/kadb/cert/KadbCert$State;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    :try_start_1
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    monitor-exit p0

    return-void

    :catchall_0
    move-exception v0

    goto :goto_0

    :catchall_1
    move-exception v0

    :try_start_2
    new-instance v1, Lcom/flyfishxu/kadb/cert/KadbCertException$StoreWriteFailed;

    invoke-direct {v1, v0}, Lcom/flyfishxu/kadb/cert/KadbCertException$StoreWriteFailed;-><init>(Ljava/lang/Throwable;)V

    throw v1
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    :goto_0
    monitor-exit p0

    throw v0
.end method

.method public final configure(Lcom/flyfishxu/kadb/cert/KadbPrivateKeyStore;Lcom/flyfishxu/kadb/cert/KadbCertPolicy;Ljava/util/List;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/flyfishxu/kadb/cert/KadbPrivateKeyStore;",
            "Lcom/flyfishxu/kadb/cert/KadbCertPolicy;",
            "Ljava/util/List<",
            "[B>;)V"
        }
    .end annotation

    const-string v0, "store"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "policy"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "additionalPrivateKeysPem"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0, p2}, Lcom/flyfishxu/kadb/cert/KadbCert;->validatePolicy(Lcom/flyfishxu/kadb/cert/KadbCertPolicy;)V

    sget-object p0, Lcom/flyfishxu/kadb/cert/KadbCert;->lock:Ljava/lang/Object;

    monitor-enter p0

    :try_start_0
    sput-object p1, Lcom/flyfishxu/kadb/cert/KadbCert;->store:Lcom/flyfishxu/kadb/cert/KadbPrivateKeyStore;

    sput-object p2, Lcom/flyfishxu/kadb/cert/KadbCert;->policy:Lcom/flyfishxu/kadb/cert/KadbCertPolicy;

    new-instance p1, Ljava/util/ArrayList;

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    invoke-interface {p3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p2

    :cond_0
    :goto_0
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    move-result p3

    if-eqz p3, :cond_2

    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p3

    move-object v0, p3

    check-cast v0, [B

    array-length v0, v0

    if-nez v0, :cond_1

    const/4 v0, 0x1

    goto :goto_1

    :cond_1
    const/4 v0, 0x0

    :goto_1
    if-nez v0, :cond_0

    invoke-interface {p1, p3}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :catchall_0
    move-exception p1

    goto :goto_3

    :cond_2
    new-instance p2, Ljava/util/ArrayList;

    const/16 p3, 0xa

    invoke-static {p1, p3}, Lkotlin/collections/CollectionsKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I

    move-result p3

    invoke-direct {p2, p3}, Ljava/util/ArrayList;-><init>(I)V

    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_2
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result p3

    if-eqz p3, :cond_3

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p3

    check-cast p3, [B

    array-length v0, p3

    invoke-static {p3, v0}, Ljava/util/Arrays;->copyOf([BI)[B

    move-result-object p3

    const-string v0, "copyOf(...)"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-interface {p2, p3}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_2

    :cond_3
    sput-object p2, Lcom/flyfishxu/kadb/cert/KadbCert;->additionalPrivateKeysPem:Ljava/util/List;

    sget-object p1, Lcom/flyfishxu/kadb/cert/KadbCert$State$Uninitialized;->INSTANCE:Lcom/flyfishxu/kadb/cert/KadbCert$State$Uninitialized;

    sput-object p1, Lcom/flyfishxu/kadb/cert/KadbCert;->state:Lcom/flyfishxu/kadb/cert/KadbCert$State;

    sget-object p1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit p0

    return-void

    :goto_3
    monitor-exit p0

    throw p1
.end method

.method public final currentKeyPair$com_github_IndiTheo_kadb()Lcom/flyfishxu/kadb/cert/AdbKeyPair;
    .locals 1

    sget-object p0, Lcom/flyfishxu/kadb/cert/KadbCert;->lock:Ljava/lang/Object;

    monitor-enter p0

    :try_start_0
    sget-object v0, Lcom/flyfishxu/kadb/cert/KadbCert;->INSTANCE:Lcom/flyfishxu/kadb/cert/KadbCert;

    invoke-direct {v0}, Lcom/flyfishxu/kadb/cert/KadbCert;->ensureReadyStateLocked()Lcom/flyfishxu/kadb/cert/KadbCert$State$Ready;

    move-result-object v0

    invoke-virtual {v0}, Lcom/flyfishxu/kadb/cert/KadbCert$State$Ready;->getKeySet()Lcom/flyfishxu/kadb/cert/HostKeySet;

    move-result-object v0

    invoke-virtual {v0}, Lcom/flyfishxu/kadb/cert/HostKeySet;->getDefaultKeyPair()Lcom/flyfishxu/kadb/cert/AdbKeyPair;

    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit p0

    return-object v0

    :catchall_0
    move-exception v0

    monitor-exit p0

    throw v0
.end method

.method public final currentKeySet$com_github_IndiTheo_kadb()Lcom/flyfishxu/kadb/cert/HostKeySet;
    .locals 1

    sget-object p0, Lcom/flyfishxu/kadb/cert/KadbCert;->lock:Ljava/lang/Object;

    monitor-enter p0

    :try_start_0
    sget-object v0, Lcom/flyfishxu/kadb/cert/KadbCert;->INSTANCE:Lcom/flyfishxu/kadb/cert/KadbCert;

    invoke-direct {v0}, Lcom/flyfishxu/kadb/cert/KadbCert;->ensureReadyStateLocked()Lcom/flyfishxu/kadb/cert/KadbCert$State$Ready;

    move-result-object v0

    invoke-virtual {v0}, Lcom/flyfishxu/kadb/cert/KadbCert$State$Ready;->getKeySet()Lcom/flyfishxu/kadb/cert/HostKeySet;

    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit p0

    return-object v0

    :catchall_0
    move-exception v0

    monitor-exit p0

    throw v0
.end method

.method public final ensureReady()Lcom/flyfishxu/kadb/cert/KadbIdentitySnapshot;
    .locals 1

    sget-object p0, Lcom/flyfishxu/kadb/cert/KadbCert;->lock:Ljava/lang/Object;

    monitor-enter p0

    :try_start_0
    sget-object v0, Lcom/flyfishxu/kadb/cert/KadbCert;->INSTANCE:Lcom/flyfishxu/kadb/cert/KadbCert;

    invoke-direct {v0}, Lcom/flyfishxu/kadb/cert/KadbCert;->ensureReadyStateLocked()Lcom/flyfishxu/kadb/cert/KadbCert$State$Ready;

    move-result-object v0

    invoke-virtual {v0}, Lcom/flyfishxu/kadb/cert/KadbCert$State$Ready;->getSnapshot()Lcom/flyfishxu/kadb/cert/KadbIdentitySnapshot;

    move-result-object v0

    invoke-virtual {v0}, Lcom/flyfishxu/kadb/cert/KadbIdentitySnapshot;->deepCopy$com_github_IndiTheo_kadb()Lcom/flyfishxu/kadb/cert/KadbIdentitySnapshot;

    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit p0

    return-object v0

    :catchall_0
    move-exception v0

    monitor-exit p0

    throw v0
.end method

.method public final exportIdentityOrNull()Lcom/flyfishxu/kadb/cert/KadbIdentitySnapshot;
    .locals 4

    sget-object p0, Lcom/flyfishxu/kadb/cert/KadbCert;->lock:Ljava/lang/Object;

    monitor-enter p0

    :try_start_0
    sget-object v0, Lcom/flyfishxu/kadb/cert/KadbCert;->state:Lcom/flyfishxu/kadb/cert/KadbCert$State;

    instance-of v1, v0, Lcom/flyfishxu/kadb/cert/KadbCert$State$Ready;

    if-eqz v1, :cond_0

    check-cast v0, Lcom/flyfishxu/kadb/cert/KadbCert$State$Ready;

    invoke-virtual {v0}, Lcom/flyfishxu/kadb/cert/KadbCert$State$Ready;->getSnapshot()Lcom/flyfishxu/kadb/cert/KadbIdentitySnapshot;

    move-result-object v0

    invoke-virtual {v0}, Lcom/flyfishxu/kadb/cert/KadbIdentitySnapshot;->deepCopy$com_github_IndiTheo_kadb()Lcom/flyfishxu/kadb/cert/KadbIdentitySnapshot;

    move-result-object v0

    goto :goto_0

    :catchall_0
    move-exception v0

    goto :goto_2

    :cond_0
    sget-object v0, Lcom/flyfishxu/kadb/cert/KadbCert;->INSTANCE:Lcom/flyfishxu/kadb/cert/KadbCert;

    invoke-direct {v0}, Lcom/flyfishxu/kadb/cert/KadbCert;->readPrivateKeyFromStoreOrThrow()[B

    move-result-object v1

    const/4 v2, 0x0

    if-nez v1, :cond_1

    goto :goto_1

    :cond_1
    array-length v3, v1

    if-nez v3, :cond_2

    goto :goto_1

    :cond_2
    invoke-direct {v0, v1}, Lcom/flyfishxu/kadb/cert/KadbCert;->validatePrivateKeyOrThrow([B)V

    sget-object v0, Lcom/flyfishxu/kadb/cert/CertUtils;->INSTANCE:Lcom/flyfishxu/kadb/cert/CertUtils;

    sget-object v2, Lcom/flyfishxu/kadb/cert/KadbCert;->policy:Lcom/flyfishxu/kadb/cert/KadbCertPolicy;

    invoke-virtual {v0, v1, v2}, Lcom/flyfishxu/kadb/cert/CertUtils;->identityFromPrivateKey([BLcom/flyfishxu/kadb/cert/KadbCertPolicy;)Lcom/flyfishxu/kadb/cert/ResolvedIdentity;

    move-result-object v0

    invoke-virtual {v0}, Lcom/flyfishxu/kadb/cert/ResolvedIdentity;->getSnapshot()Lcom/flyfishxu/kadb/cert/KadbIdentitySnapshot;

    move-result-object v0

    invoke-virtual {v0}, Lcom/flyfishxu/kadb/cert/KadbIdentitySnapshot;->deepCopy$com_github_IndiTheo_kadb()Lcom/flyfishxu/kadb/cert/KadbIdentitySnapshot;

    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :goto_0
    move-object v2, v0

    :goto_1
    monitor-exit p0

    return-object v2

    :goto_2
    monitor-exit p0

    throw v0
.end method

.method public final exportPrivateKeyOrNull()[B
    .locals 2

    sget-object p0, Lcom/flyfishxu/kadb/cert/KadbCert;->lock:Ljava/lang/Object;

    monitor-enter p0

    :try_start_0
    sget-object v0, Lcom/flyfishxu/kadb/cert/KadbCert;->state:Lcom/flyfishxu/kadb/cert/KadbCert$State;

    instance-of v1, v0, Lcom/flyfishxu/kadb/cert/KadbCert$State$Ready;

    if-eqz v1, :cond_0

    check-cast v0, Lcom/flyfishxu/kadb/cert/KadbCert$State$Ready;

    invoke-virtual {v0}, Lcom/flyfishxu/kadb/cert/KadbCert$State$Ready;->getSnapshot()Lcom/flyfishxu/kadb/cert/KadbIdentitySnapshot;

    move-result-object v0

    invoke-virtual {v0}, Lcom/flyfishxu/kadb/cert/KadbIdentitySnapshot;->getPrivateKeyPem()[B

    move-result-object v0

    array-length v1, v0

    invoke-static {v0, v1}, Ljava/util/Arrays;->copyOf([BI)[B

    move-result-object v0

    const-string v1, "copyOf(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    goto :goto_0

    :catchall_0
    move-exception v0

    goto :goto_1

    :cond_0
    sget-object v0, Lcom/flyfishxu/kadb/cert/KadbCert;->INSTANCE:Lcom/flyfishxu/kadb/cert/KadbCert;

    invoke-direct {v0}, Lcom/flyfishxu/kadb/cert/KadbCert;->readPrivateKeyFromStoreOrThrow()[B

    move-result-object v0

    if-eqz v0, :cond_1

    array-length v1, v0

    invoke-static {v0, v1}, Ljava/util/Arrays;->copyOf([BI)[B

    move-result-object v0

    const-string v1, "copyOf(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    :cond_1
    const/4 v0, 0x0

    :goto_0
    monitor-exit p0

    return-object v0

    :goto_1
    monitor-exit p0

    throw v0
.end method

.method public final importIdentity([B[B)Lcom/flyfishxu/kadb/cert/KadbIdentitySnapshot;
    .locals 3

    const-string p0, "privateKeyPem"

    invoke-static {p1, p0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object p0, Lcom/flyfishxu/kadb/cert/KadbCert;->lock:Ljava/lang/Object;

    monitor-enter p0

    :try_start_0
    sget-object v0, Lcom/flyfishxu/kadb/cert/KadbCert;->state:Lcom/flyfishxu/kadb/cert/KadbCert$State;

    instance-of v1, v0, Lcom/flyfishxu/kadb/cert/KadbCert$State$Ready;

    if-eqz v1, :cond_0

    check-cast v0, Lcom/flyfishxu/kadb/cert/KadbCert$State$Ready;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception p1

    goto :goto_2

    :cond_0
    const/4 v0, 0x0

    :goto_0
    :try_start_1
    sget-object v1, Lcom/flyfishxu/kadb/cert/KadbCert;->INSTANCE:Lcom/flyfishxu/kadb/cert/KadbCert;

    invoke-direct {v1, p1, p2}, Lcom/flyfishxu/kadb/cert/KadbCert;->resolveImportedIdentity([B[B)Lcom/flyfishxu/kadb/cert/ResolvedIdentity;

    move-result-object p1

    invoke-virtual {p1}, Lcom/flyfishxu/kadb/cert/ResolvedIdentity;->getPrivateKeyPem()[B

    move-result-object p2

    invoke-direct {v1, p2}, Lcom/flyfishxu/kadb/cert/KadbCert;->writePrivateKeyOrThrow([B)V

    new-instance p2, Lcom/flyfishxu/kadb/cert/KadbCert$State$Ready;

    invoke-virtual {p1}, Lcom/flyfishxu/kadb/cert/ResolvedIdentity;->getSnapshot()Lcom/flyfishxu/kadb/cert/KadbIdentitySnapshot;

    move-result-object v2

    invoke-virtual {v2}, Lcom/flyfishxu/kadb/cert/KadbIdentitySnapshot;->deepCopy$com_github_IndiTheo_kadb()Lcom/flyfishxu/kadb/cert/KadbIdentitySnapshot;

    move-result-object v2

    invoke-virtual {p1}, Lcom/flyfishxu/kadb/cert/ResolvedIdentity;->getKeyPair()Lcom/flyfishxu/kadb/cert/AdbKeyPair;

    move-result-object p1

    invoke-direct {v1, p1}, Lcom/flyfishxu/kadb/cert/KadbCert;->resolveHostKeySet(Lcom/flyfishxu/kadb/cert/AdbKeyPair;)Lcom/flyfishxu/kadb/cert/HostKeySet;

    move-result-object p1

    invoke-direct {p2, v2, p1}, Lcom/flyfishxu/kadb/cert/KadbCert$State$Ready;-><init>(Lcom/flyfishxu/kadb/cert/KadbIdentitySnapshot;Lcom/flyfishxu/kadb/cert/HostKeySet;)V

    sput-object p2, Lcom/flyfishxu/kadb/cert/KadbCert;->state:Lcom/flyfishxu/kadb/cert/KadbCert$State;

    invoke-virtual {p2}, Lcom/flyfishxu/kadb/cert/KadbCert$State$Ready;->getSnapshot()Lcom/flyfishxu/kadb/cert/KadbIdentitySnapshot;

    move-result-object p1

    invoke-virtual {p1}, Lcom/flyfishxu/kadb/cert/KadbIdentitySnapshot;->deepCopy$com_github_IndiTheo_kadb()Lcom/flyfishxu/kadb/cert/KadbIdentitySnapshot;

    move-result-object p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    monitor-exit p0

    return-object p1

    :catchall_1
    move-exception p1

    if-eqz v0, :cond_1

    goto :goto_1

    :cond_1
    :try_start_2
    new-instance v0, Lcom/flyfishxu/kadb/cert/KadbCert$State$Broken;

    invoke-direct {v0, p1}, Lcom/flyfishxu/kadb/cert/KadbCert$State$Broken;-><init>(Ljava/lang/Throwable;)V

    :goto_1
    sput-object v0, Lcom/flyfishxu/kadb/cert/KadbCert;->state:Lcom/flyfishxu/kadb/cert/KadbCert$State;

    sget-object p2, Lcom/flyfishxu/kadb/cert/KadbCert;->INSTANCE:Lcom/flyfishxu/kadb/cert/KadbCert;

    invoke-direct {p2, p1}, Lcom/flyfishxu/kadb/cert/KadbCert;->toKadbCertException(Ljava/lang/Throwable;)Lcom/flyfishxu/kadb/cert/KadbCertException;

    move-result-object p1

    throw p1
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    :goto_2
    monitor-exit p0

    throw p1
.end method

.method public final importPrivateKey([B)Lcom/flyfishxu/kadb/cert/KadbIdentitySnapshot;
    .locals 1

    const-string v0, "privateKeyPem"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v0, 0x0

    invoke-virtual {p0, p1, v0}, Lcom/flyfishxu/kadb/cert/KadbCert;->importIdentity([B[B)Lcom/flyfishxu/kadb/cert/KadbIdentitySnapshot;

    move-result-object p0

    return-object p0
.end method

.method public final rotate()Lcom/flyfishxu/kadb/cert/KadbIdentitySnapshot;
    .locals 5

    sget-object p0, Lcom/flyfishxu/kadb/cert/KadbCert;->lock:Ljava/lang/Object;

    monitor-enter p0

    :try_start_0
    sget-object v0, Lcom/flyfishxu/kadb/cert/KadbCert;->state:Lcom/flyfishxu/kadb/cert/KadbCert$State;

    instance-of v1, v0, Lcom/flyfishxu/kadb/cert/KadbCert$State$Ready;

    if-eqz v1, :cond_0

    check-cast v0, Lcom/flyfishxu/kadb/cert/KadbCert$State$Ready;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception v0

    goto :goto_2

    :cond_0
    const/4 v0, 0x0

    :goto_0
    :try_start_1
    sget-object v1, Lcom/flyfishxu/kadb/cert/CertUtils;->INSTANCE:Lcom/flyfishxu/kadb/cert/CertUtils;

    sget-object v2, Lcom/flyfishxu/kadb/cert/KadbCert;->policy:Lcom/flyfishxu/kadb/cert/KadbCertPolicy;

    invoke-virtual {v1, v2}, Lcom/flyfishxu/kadb/cert/CertUtils;->generateNewIdentity(Lcom/flyfishxu/kadb/cert/KadbCertPolicy;)Lcom/flyfishxu/kadb/cert/ResolvedIdentity;

    move-result-object v1

    sget-object v2, Lcom/flyfishxu/kadb/cert/KadbCert;->INSTANCE:Lcom/flyfishxu/kadb/cert/KadbCert;

    invoke-virtual {v1}, Lcom/flyfishxu/kadb/cert/ResolvedIdentity;->getPrivateKeyPem()[B

    move-result-object v3

    invoke-direct {v2, v3}, Lcom/flyfishxu/kadb/cert/KadbCert;->writePrivateKeyOrThrow([B)V

    new-instance v3, Lcom/flyfishxu/kadb/cert/KadbCert$State$Ready;

    invoke-virtual {v1}, Lcom/flyfishxu/kadb/cert/ResolvedIdentity;->getSnapshot()Lcom/flyfishxu/kadb/cert/KadbIdentitySnapshot;

    move-result-object v4

    invoke-virtual {v4}, Lcom/flyfishxu/kadb/cert/KadbIdentitySnapshot;->deepCopy$com_github_IndiTheo_kadb()Lcom/flyfishxu/kadb/cert/KadbIdentitySnapshot;

    move-result-object v4

    invoke-virtual {v1}, Lcom/flyfishxu/kadb/cert/ResolvedIdentity;->getKeyPair()Lcom/flyfishxu/kadb/cert/AdbKeyPair;

    move-result-object v1

    invoke-direct {v2, v1}, Lcom/flyfishxu/kadb/cert/KadbCert;->resolveHostKeySet(Lcom/flyfishxu/kadb/cert/AdbKeyPair;)Lcom/flyfishxu/kadb/cert/HostKeySet;

    move-result-object v1

    invoke-direct {v3, v4, v1}, Lcom/flyfishxu/kadb/cert/KadbCert$State$Ready;-><init>(Lcom/flyfishxu/kadb/cert/KadbIdentitySnapshot;Lcom/flyfishxu/kadb/cert/HostKeySet;)V

    sput-object v3, Lcom/flyfishxu/kadb/cert/KadbCert;->state:Lcom/flyfishxu/kadb/cert/KadbCert$State;

    invoke-virtual {v3}, Lcom/flyfishxu/kadb/cert/KadbCert$State$Ready;->getSnapshot()Lcom/flyfishxu/kadb/cert/KadbIdentitySnapshot;

    move-result-object v1

    invoke-virtual {v1}, Lcom/flyfishxu/kadb/cert/KadbIdentitySnapshot;->deepCopy$com_github_IndiTheo_kadb()Lcom/flyfishxu/kadb/cert/KadbIdentitySnapshot;

    move-result-object v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    monitor-exit p0

    return-object v0

    :catchall_1
    move-exception v1

    if-eqz v0, :cond_1

    goto :goto_1

    :cond_1
    :try_start_2
    new-instance v0, Lcom/flyfishxu/kadb/cert/KadbCert$State$Broken;

    invoke-direct {v0, v1}, Lcom/flyfishxu/kadb/cert/KadbCert$State$Broken;-><init>(Ljava/lang/Throwable;)V

    :goto_1
    sput-object v0, Lcom/flyfishxu/kadb/cert/KadbCert;->state:Lcom/flyfishxu/kadb/cert/KadbCert$State;

    sget-object v0, Lcom/flyfishxu/kadb/cert/KadbCert;->INSTANCE:Lcom/flyfishxu/kadb/cert/KadbCert;

    invoke-direct {v0, v1}, Lcom/flyfishxu/kadb/cert/KadbCert;->toKadbCertException(Ljava/lang/Throwable;)Lcom/flyfishxu/kadb/cert/KadbCertException;

    move-result-object v0

    throw v0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    :goto_2
    monitor-exit p0

    throw v0
.end method
