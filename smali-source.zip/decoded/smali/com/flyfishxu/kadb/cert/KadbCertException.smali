.class public abstract Lcom/flyfishxu/kadb/cert/KadbCertException;
.super Ljava/lang/RuntimeException;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/flyfishxu/kadb/cert/KadbCertException$Companion;,
        Lcom/flyfishxu/kadb/cert/KadbCertException$PolicyViolation;,
        Lcom/flyfishxu/kadb/cert/KadbCertException$PrivateKeyParseFailed;,
        Lcom/flyfishxu/kadb/cert/KadbCertException$StoreReadFailed;,
        Lcom/flyfishxu/kadb/cert/KadbCertException$StoreWriteFailed;
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000.\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u0003\n\u0002\u0008\u0007\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\u00086\u0018\u0000 \r2\u00060\u0001j\u0002`\u0002:\u0005\t\n\u000b\u000c\rB\u001d\u0008\u0004\u0012\u0006\u0010\u0003\u001a\u00020\u0004\u0012\n\u0008\u0002\u0010\u0005\u001a\u0004\u0018\u00010\u0006\u00a2\u0006\u0004\u0008\u0007\u0010\u0008\u0082\u0001\u0004\u000e\u000f\u0010\u0011\u00a8\u0006\u0012"
    }
    d2 = {
        "Lcom/flyfishxu/kadb/cert/KadbCertException;",
        "Ljava/lang/RuntimeException;",
        "Lkotlin/RuntimeException;",
        "message",
        "",
        "cause",
        "",
        "<init>",
        "(Ljava/lang/String;Ljava/lang/Throwable;)V",
        "PrivateKeyParseFailed",
        "StoreReadFailed",
        "StoreWriteFailed",
        "PolicyViolation",
        "Companion",
        "Lcom/flyfishxu/kadb/cert/KadbCertException$PolicyViolation;",
        "Lcom/flyfishxu/kadb/cert/KadbCertException$PrivateKeyParseFailed;",
        "Lcom/flyfishxu/kadb/cert/KadbCertException$StoreReadFailed;",
        "Lcom/flyfishxu/kadb/cert/KadbCertException$StoreWriteFailed;",
        "com.github.IndiTheo:kadb"
    }
    k = 0x1
    mv = {
        0x2,
        0x4,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final Companion:Lcom/flyfishxu/kadb/cert/KadbCertException$Companion;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    new-instance v0, Lcom/flyfishxu/kadb/cert/KadbCertException$Companion;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lcom/flyfishxu/kadb/cert/KadbCertException$Companion;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    sput-object v0, Lcom/flyfishxu/kadb/cert/KadbCertException;->Companion:Lcom/flyfishxu/kadb/cert/KadbCertException$Companion;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;Ljava/lang/Throwable;)V
    .locals 0

    .line 2
    invoke-direct {p0, p1, p2}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/String;Ljava/lang/Throwable;ILkotlin/jvm/internal/DefaultConstructorMarker;)V
    .locals 0

    and-int/lit8 p3, p3, 0x2

    const/4 p4, 0x0

    if-eqz p3, :cond_0

    move-object p2, p4

    .line 3
    :cond_0
    invoke-direct {p0, p1, p2, p4}, Lcom/flyfishxu/kadb/cert/KadbCertException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/String;Ljava/lang/Throwable;Lkotlin/jvm/internal/DefaultConstructorMarker;)V
    .locals 0

    .line 1
    invoke-direct {p0, p1, p2}, Lcom/flyfishxu/kadb/cert/KadbCertException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    return-void
.end method
