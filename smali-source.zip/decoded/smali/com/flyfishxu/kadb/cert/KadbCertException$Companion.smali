.class public final Lcom/flyfishxu/kadb/cert/KadbCertException$Companion;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/flyfishxu/kadb/cert/KadbCertException;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Companion"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u001a\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0003\n\u0002\u0008\u0002\u0008\u0086\u0003\u0018\u00002\u00020\u0001B\t\u0008\u0002\u00a2\u0006\u0004\u0008\u0002\u0010\u0003J\u0015\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u0007H\u0000\u00a2\u0006\u0002\u0008\u0008\u00a8\u0006\t"
    }
    d2 = {
        "Lcom/flyfishxu/kadb/cert/KadbCertException$Companion;",
        "",
        "<init>",
        "()V",
        "fromPrivateKeyParseError",
        "Lcom/flyfishxu/kadb/cert/KadbCertException;",
        "error",
        "",
        "fromPrivateKeyParseError$com_github_IndiTheo_kadb",
        "com.github.IndiTheo:kadb"
    }
    k = 0x1
    mv = {
        0x2,
        0x4,
        0x0
    }
    xi = 0x30
.end annotation


# direct methods
.method private constructor <init>()V
    .locals 0

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Lcom/flyfishxu/kadb/cert/KadbCertException$Companion;-><init>()V

    return-void
.end method


# virtual methods
.method public final fromPrivateKeyParseError$com_github_IndiTheo_kadb(Ljava/lang/Throwable;)Lcom/flyfishxu/kadb/cert/KadbCertException;
    .locals 0

    const-string p0, "error"

    invoke-static {p1, p0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    instance-of p0, p1, Lcom/flyfishxu/kadb/cert/KadbCertException;

    if-eqz p0, :cond_0

    check-cast p1, Lcom/flyfishxu/kadb/cert/KadbCertException;

    goto :goto_0

    :cond_0
    new-instance p0, Lcom/flyfishxu/kadb/cert/KadbCertException$PrivateKeyParseFailed;

    invoke-direct {p0, p1}, Lcom/flyfishxu/kadb/cert/KadbCertException$PrivateKeyParseFailed;-><init>(Ljava/lang/Throwable;)V

    move-object p1, p0

    :goto_0
    return-object p1
.end method
