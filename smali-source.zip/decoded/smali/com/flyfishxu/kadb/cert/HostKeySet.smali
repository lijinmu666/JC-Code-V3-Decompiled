.class public final Lcom/flyfishxu/kadb/cert/HostKeySet;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/flyfishxu/kadb/cert/HostKeySet$Companion;
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000.\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0008\n\n\u0002\u0010\u000b\n\u0002\u0008\u0002\n\u0002\u0010\u0008\n\u0000\n\u0002\u0010\u000e\n\u0002\u0008\u0002\u0008\u0080\u0008\u0018\u0000 \u00162\u00020\u0001:\u0001\u0016B\u001d\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u000c\u0010\u0004\u001a\u0008\u0012\u0004\u0012\u00020\u00030\u0005\u00a2\u0006\u0004\u0008\u0006\u0010\u0007J\t\u0010\u000c\u001a\u00020\u0003H\u00c6\u0003J\u000f\u0010\r\u001a\u0008\u0012\u0004\u0012\u00020\u00030\u0005H\u00c6\u0003J#\u0010\u000e\u001a\u00020\u00002\u0008\u0008\u0002\u0010\u0002\u001a\u00020\u00032\u000e\u0008\u0002\u0010\u0004\u001a\u0008\u0012\u0004\u0012\u00020\u00030\u0005H\u00c6\u0001J\u0014\u0010\u000f\u001a\u00020\u00102\u0008\u0010\u0011\u001a\u0004\u0018\u00010\u0001H\u00d6\u0083\u0004J\n\u0010\u0012\u001a\u00020\u0013H\u00d6\u0081\u0004J\n\u0010\u0014\u001a\u00020\u0015H\u00d6\u0081\u0004R\u0011\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0008\u0010\tR\u0017\u0010\u0004\u001a\u0008\u0012\u0004\u0012\u00020\u00030\u0005\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\n\u0010\u000b\u00a8\u0006\u0017"
    }
    d2 = {
        "Lcom/flyfishxu/kadb/cert/HostKeySet;",
        "",
        "defaultKeyPair",
        "Lcom/flyfishxu/kadb/cert/AdbKeyPair;",
        "keyPairs",
        "",
        "<init>",
        "(Lcom/flyfishxu/kadb/cert/AdbKeyPair;Ljava/util/List;)V",
        "getDefaultKeyPair",
        "()Lcom/flyfishxu/kadb/cert/AdbKeyPair;",
        "getKeyPairs",
        "()Ljava/util/List;",
        "component1",
        "component2",
        "copy",
        "equals",
        "",
        "other",
        "hashCode",
        "",
        "toString",
        "",
        "Companion",
        "com.github.IndiTheo:kadb"
    }
    k = 0x1
    mv = {
        0x2,
        0x4,
        0x0
    }
    xi = 0x30
.end annotation

.annotation build Lkotlin/jvm/internal/SourceDebugExtension;
    value = {
        "SMAP\nHostKeySet.kt\nKotlin\n*S Kotlin\n*F\n+ 1 HostKeySet.kt\ncom/flyfishxu/kadb/cert/HostKeySet\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,19:1\n1#2:20\n*E\n"
    }
.end annotation


# static fields
.field public static final Companion:Lcom/flyfishxu/kadb/cert/HostKeySet$Companion;


# instance fields
.field private final defaultKeyPair:Lcom/flyfishxu/kadb/cert/AdbKeyPair;

.field private final keyPairs:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/flyfishxu/kadb/cert/AdbKeyPair;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 2

    new-instance v0, Lcom/flyfishxu/kadb/cert/HostKeySet$Companion;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lcom/flyfishxu/kadb/cert/HostKeySet$Companion;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    sput-object v0, Lcom/flyfishxu/kadb/cert/HostKeySet;->Companion:Lcom/flyfishxu/kadb/cert/HostKeySet$Companion;

    return-void
.end method

.method public constructor <init>(Lcom/flyfishxu/kadb/cert/AdbKeyPair;Ljava/util/List;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/flyfishxu/kadb/cert/AdbKeyPair;",
            "Ljava/util/List<",
            "Lcom/flyfishxu/kadb/cert/AdbKeyPair;",
            ">;)V"
        }
    .end annotation

    const-string v0, "defaultKeyPair"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "keyPairs"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/flyfishxu/kadb/cert/HostKeySet;->defaultKeyPair:Lcom/flyfishxu/kadb/cert/AdbKeyPair;

    iput-object p2, p0, Lcom/flyfishxu/kadb/cert/HostKeySet;->keyPairs:Ljava/util/List;

    invoke-interface {p2}, Ljava/util/Collection;->isEmpty()Z

    move-result p0

    if-nez p0, :cond_1

    invoke-static {p2}, Lkotlin/collections/CollectionsKt;->first(Ljava/util/List;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, p1, :cond_0

    return-void

    :cond_0
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string p1, "Default key pair must be the first entry in key set"

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_1
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string p1, "HostKeySet must contain at least one key pair"

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public static synthetic copy$default(Lcom/flyfishxu/kadb/cert/HostKeySet;Lcom/flyfishxu/kadb/cert/AdbKeyPair;Ljava/util/List;ILjava/lang/Object;)Lcom/flyfishxu/kadb/cert/HostKeySet;
    .locals 0

    and-int/lit8 p4, p3, 0x1

    if-eqz p4, :cond_0

    iget-object p1, p0, Lcom/flyfishxu/kadb/cert/HostKeySet;->defaultKeyPair:Lcom/flyfishxu/kadb/cert/AdbKeyPair;

    :cond_0
    and-int/lit8 p3, p3, 0x2

    if-eqz p3, :cond_1

    iget-object p2, p0, Lcom/flyfishxu/kadb/cert/HostKeySet;->keyPairs:Ljava/util/List;

    :cond_1
    invoke-virtual {p0, p1, p2}, Lcom/flyfishxu/kadb/cert/HostKeySet;->copy(Lcom/flyfishxu/kadb/cert/AdbKeyPair;Ljava/util/List;)Lcom/flyfishxu/kadb/cert/HostKeySet;

    move-result-object p0

    return-object p0
.end method


# virtual methods
.method public final component1()Lcom/flyfishxu/kadb/cert/AdbKeyPair;
    .locals 0

    iget-object p0, p0, Lcom/flyfishxu/kadb/cert/HostKeySet;->defaultKeyPair:Lcom/flyfishxu/kadb/cert/AdbKeyPair;

    return-object p0
.end method

.method public final component2()Ljava/util/List;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/flyfishxu/kadb/cert/AdbKeyPair;",
            ">;"
        }
    .end annotation

    iget-object p0, p0, Lcom/flyfishxu/kadb/cert/HostKeySet;->keyPairs:Ljava/util/List;

    return-object p0
.end method

.method public final copy(Lcom/flyfishxu/kadb/cert/AdbKeyPair;Ljava/util/List;)Lcom/flyfishxu/kadb/cert/HostKeySet;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/flyfishxu/kadb/cert/AdbKeyPair;",
            "Ljava/util/List<",
            "Lcom/flyfishxu/kadb/cert/AdbKeyPair;",
            ">;)",
            "Lcom/flyfishxu/kadb/cert/HostKeySet;"
        }
    .end annotation

    const-string p0, "defaultKeyPair"

    invoke-static {p1, p0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string p0, "keyPairs"

    invoke-static {p2, p0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance p0, Lcom/flyfishxu/kadb/cert/HostKeySet;

    invoke-direct {p0, p1, p2}, Lcom/flyfishxu/kadb/cert/HostKeySet;-><init>(Lcom/flyfishxu/kadb/cert/AdbKeyPair;Ljava/util/List;)V

    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    const/4 v0, 0x1

    if-ne p0, p1, :cond_0

    return v0

    :cond_0
    instance-of v1, p1, Lcom/flyfishxu/kadb/cert/HostKeySet;

    const/4 v2, 0x0

    if-nez v1, :cond_1

    return v2

    :cond_1
    check-cast p1, Lcom/flyfishxu/kadb/cert/HostKeySet;

    iget-object v1, p0, Lcom/flyfishxu/kadb/cert/HostKeySet;->defaultKeyPair:Lcom/flyfishxu/kadb/cert/AdbKeyPair;

    iget-object v3, p1, Lcom/flyfishxu/kadb/cert/HostKeySet;->defaultKeyPair:Lcom/flyfishxu/kadb/cert/AdbKeyPair;

    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_2

    return v2

    :cond_2
    iget-object p0, p0, Lcom/flyfishxu/kadb/cert/HostKeySet;->keyPairs:Ljava/util/List;

    iget-object p1, p1, Lcom/flyfishxu/kadb/cert/HostKeySet;->keyPairs:Ljava/util/List;

    invoke-static {p0, p1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_3

    return v2

    :cond_3
    return v0
.end method

.method public final getDefaultKeyPair()Lcom/flyfishxu/kadb/cert/AdbKeyPair;
    .locals 0

    iget-object p0, p0, Lcom/flyfishxu/kadb/cert/HostKeySet;->defaultKeyPair:Lcom/flyfishxu/kadb/cert/AdbKeyPair;

    return-object p0
.end method

.method public final getKeyPairs()Ljava/util/List;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/flyfishxu/kadb/cert/AdbKeyPair;",
            ">;"
        }
    .end annotation

    iget-object p0, p0, Lcom/flyfishxu/kadb/cert/HostKeySet;->keyPairs:Ljava/util/List;

    return-object p0
.end method

.method public hashCode()I
    .locals 1

    iget-object v0, p0, Lcom/flyfishxu/kadb/cert/HostKeySet;->defaultKeyPair:Lcom/flyfishxu/kadb/cert/AdbKeyPair;

    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    mul-int/lit8 v0, v0, 0x1f

    iget-object p0, p0, Lcom/flyfishxu/kadb/cert/HostKeySet;->keyPairs:Ljava/util/List;

    invoke-virtual {p0}, Ljava/lang/Object;->hashCode()I

    move-result p0

    add-int/2addr v0, p0

    return v0
.end method

.method public toString()Ljava/lang/String;
    .locals 3

    iget-object v0, p0, Lcom/flyfishxu/kadb/cert/HostKeySet;->defaultKeyPair:Lcom/flyfishxu/kadb/cert/AdbKeyPair;

    iget-object p0, p0, Lcom/flyfishxu/kadb/cert/HostKeySet;->keyPairs:Ljava/util/List;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "HostKeySet(defaultKeyPair="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v0, ", keyPairs="

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p0, ")"

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
