.class final Lcom/flyfishxu/kadb/Kadb$newConnection$1;
.super Lkotlin/coroutines/jvm/internal/SuspendLambda;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/flyfishxu/kadb/Kadb;->newConnection()Lkotlin/Pair;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/coroutines/jvm/internal/SuspendLambda;",
        "Lkotlin/jvm/functions/Function2<",
        "Lkotlinx/coroutines/CoroutineScope;",
        "Lkotlin/coroutines/Continuation<",
        "-",
        "Lkotlin/Pair<",
        "+",
        "Lcom/flyfishxu/kadb/core/AdbConnection;",
        "+",
        "Lcom/flyfishxu/kadb/transport/TransportChannel;",
        ">;>;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u0012\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u000e\u0012\u0004\u0012\u00020\u0002\u0012\u0004\u0012\u00020\u00030\u0001*\u00020\u0004H\n"
    }
    d2 = {
        "<anonymous>",
        "Lkotlin/Pair;",
        "Lcom/flyfishxu/kadb/core/AdbConnection;",
        "Lcom/flyfishxu/kadb/transport/TransportChannel;",
        "Lkotlinx/coroutines/CoroutineScope;"
    }
    k = 0x3
    mv = {
        0x2,
        0x4,
        0x0
    }
    xi = 0x30
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.flyfishxu.kadb.Kadb$newConnection$1"
    f = "Kadb.kt"
    i = {}
    l = {
        0xdd
    }
    m = "invokeSuspend"
    n = {}
    nl = {
        0xe4
    }
    s = {}
    v = 0x2
.end annotation


# instance fields
.field label:I

.field final synthetic this$0:Lcom/flyfishxu/kadb/Kadb;


# direct methods
.method public constructor <init>(Lcom/flyfishxu/kadb/Kadb;Lkotlin/coroutines/Continuation;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/flyfishxu/kadb/Kadb;",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Lcom/flyfishxu/kadb/Kadb$newConnection$1;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, Lcom/flyfishxu/kadb/Kadb$newConnection$1;->this$0:Lcom/flyfishxu/kadb/Kadb;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p2}, Lkotlin/coroutines/jvm/internal/SuspendLambda;-><init>(ILkotlin/coroutines/Continuation;)V

    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "Lkotlin/coroutines/Continuation<",
            "*>;)",
            "Lkotlin/coroutines/Continuation<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    new-instance p1, Lcom/flyfishxu/kadb/Kadb$newConnection$1;

    iget-object p0, p0, Lcom/flyfishxu/kadb/Kadb$newConnection$1;->this$0:Lcom/flyfishxu/kadb/Kadb;

    invoke-direct {p1, p0, p2}, Lcom/flyfishxu/kadb/Kadb$newConnection$1;-><init>(Lcom/flyfishxu/kadb/Kadb;Lkotlin/coroutines/Continuation;)V

    return-object p1
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lkotlinx/coroutines/CoroutineScope;

    check-cast p2, Lkotlin/coroutines/Continuation;

    invoke-virtual {p0, p1, p2}, Lcom/flyfishxu/kadb/Kadb$newConnection$1;->invoke(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public final invoke(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/CoroutineScope;",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Lkotlin/Pair<",
            "Lcom/flyfishxu/kadb/core/AdbConnection;",
            "+",
            "Lcom/flyfishxu/kadb/transport/TransportChannel;",
            ">;>;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 2
    invoke-virtual {p0, p1, p2}, Lcom/flyfishxu/kadb/Kadb$newConnection$1;->create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;

    move-result-object p0

    check-cast p0, Lcom/flyfishxu/kadb/Kadb$newConnection$1;

    sget-object p1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    invoke-virtual {p0, p1}, Lcom/flyfishxu/kadb/Kadb$newConnection$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 9

    invoke-static {}, Lkotlin/coroutines/intrinsics/IntrinsicsKt;->getCOROUTINE_SUSPENDED()Ljava/lang/Object;

    move-result-object v0

    iget v1, p0, Lcom/flyfishxu/kadb/Kadb$newConnection$1;->label:I

    const/4 v2, 0x1

    if-eqz v1, :cond_1

    if-ne v1, v2, :cond_0

    invoke-static {p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    goto :goto_0

    :cond_0
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string p1, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_1
    invoke-static {p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    sget-object v1, Lcom/flyfishxu/kadb/core/AdbConnection;->Companion:Lcom/flyfishxu/kadb/core/AdbConnection$Companion;

    iget-object p1, p0, Lcom/flyfishxu/kadb/Kadb$newConnection$1;->this$0:Lcom/flyfishxu/kadb/Kadb;

    invoke-static {p1}, Lcom/flyfishxu/kadb/Kadb;->access$getHost$p(Lcom/flyfishxu/kadb/Kadb;)Ljava/lang/String;

    move-result-object p1

    iget-object v3, p0, Lcom/flyfishxu/kadb/Kadb$newConnection$1;->this$0:Lcom/flyfishxu/kadb/Kadb;

    invoke-static {v3}, Lcom/flyfishxu/kadb/Kadb;->access$getPort$p(Lcom/flyfishxu/kadb/Kadb;)I

    move-result v3

    sget-object v4, Lcom/flyfishxu/kadb/cert/CertUtils;->INSTANCE:Lcom/flyfishxu/kadb/cert/CertUtils;

    invoke-virtual {v4}, Lcom/flyfishxu/kadb/cert/CertUtils;->loadKeySet()Lcom/flyfishxu/kadb/cert/HostKeySet;

    move-result-object v4

    iget-object v5, p0, Lcom/flyfishxu/kadb/Kadb$newConnection$1;->this$0:Lcom/flyfishxu/kadb/Kadb;

    invoke-static {v5}, Lcom/flyfishxu/kadb/Kadb;->access$getOptions$p(Lcom/flyfishxu/kadb/Kadb;)Lcom/flyfishxu/kadb/KadbOptions;

    move-result-object v5

    iget-object v6, p0, Lcom/flyfishxu/kadb/Kadb$newConnection$1;->this$0:Lcom/flyfishxu/kadb/Kadb;

    invoke-static {v6}, Lcom/flyfishxu/kadb/Kadb;->access$getConnectTimeout$p(Lcom/flyfishxu/kadb/Kadb;)I

    move-result v6

    iget-object v7, p0, Lcom/flyfishxu/kadb/Kadb$newConnection$1;->this$0:Lcom/flyfishxu/kadb/Kadb;

    invoke-static {v7}, Lcom/flyfishxu/kadb/Kadb;->access$getSocketTimeout$p(Lcom/flyfishxu/kadb/Kadb;)I

    move-result v7

    iput v2, p0, Lcom/flyfishxu/kadb/Kadb$newConnection$1;->label:I

    move-object v2, p1

    move-object v8, p0

    invoke-virtual/range {v1 .. v8}, Lcom/flyfishxu/kadb/core/AdbConnection$Companion;->connect(Ljava/lang/String;ILcom/flyfishxu/kadb/cert/HostKeySet;Lcom/flyfishxu/kadb/KadbOptions;IILkotlin/coroutines/Continuation;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v0, :cond_2

    return-object v0

    :cond_2
    :goto_0
    return-object p1
.end method
