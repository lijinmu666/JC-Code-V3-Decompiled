.class public final Lcom/flyfishxu/kadb/core/AdbConnectionKt;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u000e\n\u0000\n\u0002\u0010\u0012\n\u0000\n\u0002\u0018\u0002\n\u0000\u001a\u0010\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u0003H\u0002\u00a8\u0006\u0004"
    }
    d2 = {
        "adbPublicKey",
        "",
        "keyPair",
        "Lcom/flyfishxu/kadb/cert/AdbKeyPair;",
        "com.github.IndiTheo:kadb"
    }
    k = 0x2
    mv = {
        0x2,
        0x4,
        0x0
    }
    xi = 0x30
.end annotation


# direct methods
.method public static final synthetic access$adbPublicKey(Lcom/flyfishxu/kadb/cert/AdbKeyPair;)[B
    .locals 0

    invoke-static {p0}, Lcom/flyfishxu/kadb/core/AdbConnectionKt;->adbPublicKey(Lcom/flyfishxu/kadb/cert/AdbKeyPair;)[B

    move-result-object p0

    return-object p0
.end method

.method private static final adbPublicKey(Lcom/flyfishxu/kadb/cert/AdbKeyPair;)[B
    .locals 2

    invoke-virtual {p0}, Lcom/flyfishxu/kadb/cert/AdbKeyPair;->getPublicKey()Ljava/security/PublicKey;

    move-result-object p0

    const-string v0, "null cannot be cast to non-null type java.security.interfaces.RSAPublicKey"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast p0, Ljava/security/interfaces/RSAPublicKey;

    const/4 v0, 0x0

    const/4 v1, 0x1

    invoke-static {v0, v1, v0}, Lcom/flyfishxu/kadb/cert/platform/DefaultDeviceName_androidKt;->defaultDeviceName$default(Ljava/lang/String;ILjava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    invoke-static {p0, v0}, Lcom/flyfishxu/kadb/cert/AndroidPubkey;->encodeWithName(Ljava/security/interfaces/RSAPublicKey;Ljava/lang/String;)[B

    move-result-object p0

    return-object p0
.end method
