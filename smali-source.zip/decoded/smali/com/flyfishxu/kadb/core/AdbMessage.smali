.class public final Lcom/flyfishxu/kadb/core/AdbMessage;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000*\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0008\n\u0002\u0008\u0006\n\u0002\u0010\u0012\n\u0002\u0008\u000c\n\u0002\u0010\u000e\n\u0002\u0008\u0005\n\u0002\u0018\u0002\n\u0002\u0008\u0004\u0008\u0000\u0018\u00002\u00020\u0001B?\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\u0006\u0010\u0005\u001a\u00020\u0003\u0012\u0006\u0010\u0006\u001a\u00020\u0003\u0012\u0006\u0010\u0007\u001a\u00020\u0003\u0012\u0006\u0010\u0008\u001a\u00020\u0003\u0012\u0006\u0010\t\u001a\u00020\n\u00a2\u0006\u0004\u0008\u000b\u0010\u000cJ\n\u0010\u0016\u001a\u00020\u0017H\u0096\u0080\u0004J\u0008\u0010\u0018\u001a\u00020\u0017H\u0002J\u0008\u0010\u0019\u001a\u00020\u0017H\u0002J\n\u0010\u001a\u001a\u0004\u0018\u00010\u0017H\u0002J\n\u0010\u001b\u001a\u0004\u0018\u00010\u0017H\u0002J\u0008\u0010\u001c\u001a\u00020\u001dH\u0002J\u0010\u0010\u001e\u001a\u00020\u00172\u0006\u0010\u001f\u001a\u00020\u0003H\u0002J\u0008\u0010 \u001a\u00020\u0017H\u0002R\u0011\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\r\u0010\u000eR\u0011\u0010\u0004\u001a\u00020\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u000f\u0010\u000eR\u0011\u0010\u0005\u001a\u00020\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0010\u0010\u000eR\u0011\u0010\u0006\u001a\u00020\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0011\u0010\u000eR\u0011\u0010\u0007\u001a\u00020\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0012\u0010\u000eR\u0011\u0010\u0008\u001a\u00020\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0013\u0010\u000eR\u0011\u0010\t\u001a\u00020\n\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0014\u0010\u0015\u00a8\u0006!"
    }
    d2 = {
        "Lcom/flyfishxu/kadb/core/AdbMessage;",
        "",
        "command",
        "",
        "arg0",
        "arg1",
        "payloadLength",
        "checksum",
        "magic",
        "payload",
        "",
        "<init>",
        "(IIIIII[B)V",
        "getCommand",
        "()I",
        "getArg0",
        "getArg1",
        "getPayloadLength",
        "getChecksum",
        "getMagic",
        "getPayload",
        "()[B",
        "toString",
        "",
        "payloadStr",
        "writePayloadStr",
        "shellPayloadStr",
        "syncPayloadStr",
        "getSource",
        "Lokio/BufferedSource;",
        "argStr",
        "arg",
        "commandStr",
        "com.github.IndiTheo:kadb"
    }
    k = 0x1
    mv = {
        0x2,
        0x4,
        0x0
    }
    xi = 0x30
.end annotation

.annotation build Lkotlin/jvm/internal/SourceDebugExtension;
    value = {
        "SMAP\nAdbMessage.kt\nKotlin\n*S Kotlin\n*F\n+ 1 AdbMessage.kt\ncom/flyfishxu/kadb/core/AdbMessage\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,91:1\n1#2:92\n*E\n"
    }
.end annotation


# instance fields
.field private final arg0:I

.field private final arg1:I

.field private final checksum:I

.field private final command:I

.field private final magic:I

.field private final payload:[B

.field private final payloadLength:I


# direct methods
.method public constructor <init>(IIIIII[B)V
    .locals 1

    const-string v0, "payload"

    invoke-static {p7, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, Lcom/flyfishxu/kadb/core/AdbMessage;->command:I

    iput p2, p0, Lcom/flyfishxu/kadb/core/AdbMessage;->arg0:I

    iput p3, p0, Lcom/flyfishxu/kadb/core/AdbMessage;->arg1:I

    iput p4, p0, Lcom/flyfishxu/kadb/core/AdbMessage;->payloadLength:I

    iput p5, p0, Lcom/flyfishxu/kadb/core/AdbMessage;->checksum:I

    iput p6, p0, Lcom/flyfishxu/kadb/core/AdbMessage;->magic:I

    iput-object p7, p0, Lcom/flyfishxu/kadb/core/AdbMessage;->payload:[B

    return-void
.end method

.method private final argStr(I)Ljava/lang/String;
    .locals 0

    sget-object p0, Lkotlin/jvm/internal/StringCompanionObject;->INSTANCE:Lkotlin/jvm/internal/StringCompanionObject;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    filled-new-array {p0}, [Ljava/lang/Object;

    move-result-object p0

    const/4 p1, 0x1

    invoke-static {p0, p1}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object p0

    const-string p1, "%X"

    invoke-static {p1, p0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    const-string p1, "format(...)"

    invoke-static {p0, p1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    return-object p0
.end method

.method private final commandStr()Ljava/lang/String;
    .locals 0

    iget p0, p0, Lcom/flyfishxu/kadb/core/AdbMessage;->command:I

    sparse-switch p0, :sswitch_data_0

    const-string p0, "????"

    goto :goto_0

    :sswitch_0
    const-string p0, "OKAY"

    goto :goto_0

    :sswitch_1
    const-string p0, "CNXN"

    goto :goto_0

    :sswitch_2
    const-string p0, "OPEN"

    goto :goto_0

    :sswitch_3
    const-string p0, "AUTH"

    goto :goto_0

    :sswitch_4
    const-string p0, "WRTE"

    goto :goto_0

    :sswitch_5
    const-string p0, "CLSE"

    :goto_0
    return-object p0

    :sswitch_data_0
    .sparse-switch
        0x45534c43 -> :sswitch_5
        0x45545257 -> :sswitch_4
        0x48545541 -> :sswitch_3
        0x4e45504f -> :sswitch_2
        0x4e584e43 -> :sswitch_1
        0x59414b4f -> :sswitch_0
    .end sparse-switch
.end method

.method private final getSource()Lokio/BufferedSource;
    .locals 3

    new-instance v0, Lokio/Buffer;

    invoke-direct {v0}, Lokio/Buffer;-><init>()V

    iget-object v1, p0, Lcom/flyfishxu/kadb/core/AdbMessage;->payload:[B

    const/4 v2, 0x0

    iget p0, p0, Lcom/flyfishxu/kadb/core/AdbMessage;->payloadLength:I

    invoke-virtual {v0, v1, v2, p0}, Lokio/Buffer;->write([BII)Lokio/Buffer;

    return-object v0
.end method

.method private final payloadStr()Ljava/lang/String;
    .locals 4

    iget v0, p0, Lcom/flyfishxu/kadb/core/AdbMessage;->payloadLength:I

    if-nez v0, :cond_0

    const-string p0, ""

    return-object p0

    :cond_0
    iget v1, p0, Lcom/flyfishxu/kadb/core/AdbMessage;->command:I

    const v2, 0x45545257

    if-eq v1, v2, :cond_4

    const v2, 0x48545541

    const-string v3, "]"

    if-eq v1, v2, :cond_2

    const v2, 0x4e45504f    # 8.2759366E8f

    if-eq v1, v2, :cond_1

    new-instance p0, Ljava/lang/StringBuilder;

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "payload["

    invoke-virtual {p0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {p0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    goto :goto_0

    :cond_1
    new-instance v1, Ljava/lang/String;

    iget-object p0, p0, Lcom/flyfishxu/kadb/core/AdbMessage;->payload:[B

    add-int/lit8 v0, v0, -0x1

    sget-object v2, Lkotlin/text/Charsets;->UTF_8:Ljava/nio/charset/Charset;

    const/4 v3, 0x0

    invoke-direct {v1, p0, v3, v0, v2}, Ljava/lang/String;-><init>([BIILjava/nio/charset/Charset;)V

    move-object p0, v1

    goto :goto_0

    :cond_2
    iget v1, p0, Lcom/flyfishxu/kadb/core/AdbMessage;->arg0:I

    const/4 v2, 0x3

    if-ne v1, v2, :cond_3

    new-instance v0, Ljava/lang/String;

    iget-object p0, p0, Lcom/flyfishxu/kadb/core/AdbMessage;->payload:[B

    sget-object v1, Lkotlin/text/Charsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-direct {v0, p0, v1}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V

    move-object p0, v0

    goto :goto_0

    :cond_3
    new-instance p0, Ljava/lang/StringBuilder;

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "auth["

    invoke-virtual {p0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {p0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    goto :goto_0

    :cond_4
    invoke-direct {p0}, Lcom/flyfishxu/kadb/core/AdbMessage;->writePayloadStr()Ljava/lang/String;

    move-result-object p0

    :goto_0
    return-object p0
.end method

.method private final shellPayloadStr()Ljava/lang/String;
    .locals 7

    invoke-direct {p0}, Lcom/flyfishxu/kadb/core/AdbMessage;->getSource()Lokio/BufferedSource;

    move-result-object v0

    invoke-interface {v0}, Lokio/BufferedSource;->getBuffer()Lokio/Buffer;

    move-result-object v1

    invoke-virtual {v1}, Lokio/Buffer;->size()J

    move-result-wide v1

    const-wide/16 v3, 0x5

    cmp-long v1, v1, v3

    const/4 v2, 0x0

    if-gez v1, :cond_0

    return-object v2

    :cond_0
    invoke-interface {v0}, Lokio/BufferedSource;->readByte()B

    move-result v1

    if-ltz v1, :cond_4

    const/4 v3, 0x3

    if-le v1, v3, :cond_1

    goto :goto_0

    :cond_1
    invoke-interface {v0}, Lokio/BufferedSource;->readIntLe()I

    move-result v4

    invoke-interface {v0}, Lokio/BufferedSource;->getBuffer()Lokio/Buffer;

    move-result-object v5

    invoke-virtual {v5}, Lokio/Buffer;->size()J

    move-result-wide v5

    long-to-int v5, v5

    if-eq v4, v5, :cond_2

    return-object v2

    :cond_2
    if-ne v1, v3, :cond_3

    invoke-interface {v0}, Lokio/BufferedSource;->readByte()B

    move-result p0

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "[shell] exit("

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p0, ")"

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_3
    new-instance v0, Ljava/lang/String;

    iget-object v1, p0, Lcom/flyfishxu/kadb/core/AdbMessage;->payload:[B

    iget p0, p0, Lcom/flyfishxu/kadb/core/AdbMessage;->payloadLength:I

    const/4 v2, 0x5

    sub-int/2addr p0, v2

    sget-object v3, Lkotlin/text/Charsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-direct {v0, v1, v2, p0, v3}, Ljava/lang/String;-><init>([BIILjava/nio/charset/Charset;)V

    new-instance p0, Ljava/lang/StringBuilder;

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "[shell] "

    invoke-virtual {p0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_4
    :goto_0
    return-object v2
.end method

.method private final syncPayloadStr()Ljava/lang/String;
    .locals 4

    invoke-direct {p0}, Lcom/flyfishxu/kadb/core/AdbMessage;->getSource()Lokio/BufferedSource;

    move-result-object p0

    invoke-interface {p0}, Lokio/BufferedSource;->getBuffer()Lokio/Buffer;

    move-result-object v0

    invoke-virtual {v0}, Lokio/Buffer;->size()J

    move-result-wide v0

    const-wide/16 v2, 0x8

    cmp-long v0, v0, v2

    const/4 v1, 0x0

    if-gez v0, :cond_0

    return-object v1

    :cond_0
    sget-object v0, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    const-string v2, "UTF_8"

    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-wide/16 v2, 0x4

    invoke-interface {p0, v2, v3, v0}, Lokio/BufferedSource;->readString(JLjava/nio/charset/Charset;)Ljava/lang/String;

    move-result-object v0

    invoke-static {}, Lcom/flyfishxu/kadb/stream/AdbSyncStreamKt;->getSYNC_IDS()Ljava/util/Set;

    move-result-object v2

    invoke-interface {v2, v0}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_1

    return-object v1

    :cond_1
    invoke-interface {p0}, Lokio/BufferedSource;->readIntLe()I

    move-result p0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "[sync] "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, "("

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p0, ")"

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method private final writePayloadStr()Ljava/lang/String;
    .locals 2

    invoke-direct {p0}, Lcom/flyfishxu/kadb/core/AdbMessage;->shellPayloadStr()Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_0

    return-object v0

    :cond_0
    invoke-direct {p0}, Lcom/flyfishxu/kadb/core/AdbMessage;->syncPayloadStr()Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_1

    return-object v0

    :cond_1
    iget p0, p0, Lcom/flyfishxu/kadb/core/AdbMessage;->payloadLength:I

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "payload["

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p0, "]"

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method


# virtual methods
.method public final getArg0()I
    .locals 0

    iget p0, p0, Lcom/flyfishxu/kadb/core/AdbMessage;->arg0:I

    return p0
.end method

.method public final getArg1()I
    .locals 0

    iget p0, p0, Lcom/flyfishxu/kadb/core/AdbMessage;->arg1:I

    return p0
.end method

.method public final getChecksum()I
    .locals 0

    iget p0, p0, Lcom/flyfishxu/kadb/core/AdbMessage;->checksum:I

    return p0
.end method

.method public final getCommand()I
    .locals 0

    iget p0, p0, Lcom/flyfishxu/kadb/core/AdbMessage;->command:I

    return p0
.end method

.method public final getMagic()I
    .locals 0

    iget p0, p0, Lcom/flyfishxu/kadb/core/AdbMessage;->magic:I

    return p0
.end method

.method public final getPayload()[B
    .locals 0

    iget-object p0, p0, Lcom/flyfishxu/kadb/core/AdbMessage;->payload:[B

    return-object p0
.end method

.method public final getPayloadLength()I
    .locals 0

    iget p0, p0, Lcom/flyfishxu/kadb/core/AdbMessage;->payloadLength:I

    return p0
.end method

.method public toString()Ljava/lang/String;
    .locals 4

    invoke-direct {p0}, Lcom/flyfishxu/kadb/core/AdbMessage;->commandStr()Ljava/lang/String;

    move-result-object v0

    iget v1, p0, Lcom/flyfishxu/kadb/core/AdbMessage;->arg0:I

    invoke-direct {p0, v1}, Lcom/flyfishxu/kadb/core/AdbMessage;->argStr(I)Ljava/lang/String;

    move-result-object v1

    iget v2, p0, Lcom/flyfishxu/kadb/core/AdbMessage;->arg1:I

    invoke-direct {p0, v2}, Lcom/flyfishxu/kadb/core/AdbMessage;->argStr(I)Ljava/lang/String;

    move-result-object v2

    invoke-direct {p0}, Lcom/flyfishxu/kadb/core/AdbMessage;->payloadStr()Ljava/lang/String;

    move-result-object p0

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, "["

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, ", "

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, "] "

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
