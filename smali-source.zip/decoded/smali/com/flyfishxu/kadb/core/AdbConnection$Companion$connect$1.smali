.class final Lcom/flyfishxu/kadb/core/AdbConnection$Companion$connect$1;
.super Lkotlin/coroutines/jvm/internal/ContinuationImpl;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/flyfishxu/kadb/core/AdbConnection$Companion;->connect(Ljava/lang/String;ILcom/flyfishxu/kadb/cert/HostKeySet;Lcom/flyfishxu/kadb/KadbOptions;IILkotlin/coroutines/Continuation;)Ljava/lang/Object;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation runtime Lkotlin/Metadata;
    k = 0x3
    mv = {
        0x2,
        0x4,
        0x0
    }
    xi = 0x30
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.flyfishxu.kadb.core.AdbConnection$Companion"
    f = "AdbConnection.kt"
    i = {
        0x0,
        0x0,
        0x0,
        0x0,
        0x0,
        0x0,
        0x0,
        0x0,
        0x0,
        0x1,
        0x1,
        0x1,
        0x1,
        0x1,
        0x1,
        0x1,
        0x1,
        0x1,
        0x1,
        0x1,
        0x1,
        0x1,
        0x1,
        0x1,
        0x1,
        0x1,
        0x1
    }
    l = {
        0x6f,
        0x8a
    }
    m = "connect"
    n = {
        "host",
        "hostKeySet",
        "options",
        "port",
        "connectTimeoutMs",
        "ioTimeoutMs",
        "connectTimeout",
        "ioTimeout",
        "authKeyIndex",
        "host",
        "hostKeySet",
        "options",
        "channel",
        "reader",
        "writer",
        "advertisedFeatures",
        "connectPayload",
        "message",
        "sslContext",
        "engine",
        "tlsChannel",
        "port",
        "connectTimeoutMs",
        "ioTimeoutMs",
        "connectTimeout",
        "ioTimeout",
        "authKeyIndex"
    }
    nl = {
        0x70,
        0x8b
    }
    s = {
        "L$0",
        "L$1",
        "L$2",
        "I$0",
        "I$1",
        "I$2",
        "J$0",
        "J$1",
        "I$3",
        "L$0",
        "L$1",
        "L$2",
        "L$3",
        "L$4",
        "L$5",
        "L$6",
        "L$7",
        "L$8",
        "L$9",
        "L$10",
        "L$11",
        "I$0",
        "I$1",
        "I$2",
        "J$0",
        "J$1",
        "I$3"
    }
    v = 0x2
.end annotation


# instance fields
.field I$0:I

.field I$1:I

.field I$2:I

.field I$3:I

.field J$0:J

.field J$1:J

.field L$0:Ljava/lang/Object;

.field L$1:Ljava/lang/Object;

.field L$10:Ljava/lang/Object;

.field L$11:Ljava/lang/Object;

.field L$2:Ljava/lang/Object;

.field L$3:Ljava/lang/Object;

.field L$4:Ljava/lang/Object;

.field L$5:Ljava/lang/Object;

.field L$6:Ljava/lang/Object;

.field L$7:Ljava/lang/Object;

.field L$8:Ljava/lang/Object;

.field L$9:Ljava/lang/Object;

.field label:I

.field synthetic result:Ljava/lang/Object;

.field final synthetic this$0:Lcom/flyfishxu/kadb/core/AdbConnection$Companion;


# direct methods
.method public constructor <init>(Lcom/flyfishxu/kadb/core/AdbConnection$Companion;Lkotlin/coroutines/Continuation;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/flyfishxu/kadb/core/AdbConnection$Companion;",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Lcom/flyfishxu/kadb/core/AdbConnection$Companion$connect$1;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, Lcom/flyfishxu/kadb/core/AdbConnection$Companion$connect$1;->this$0:Lcom/flyfishxu/kadb/core/AdbConnection$Companion;

    invoke-direct {p0, p2}, Lkotlin/coroutines/jvm/internal/ContinuationImpl;-><init>(Lkotlin/coroutines/Continuation;)V

    return-void
.end method


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 8

    iput-object p1, p0, Lcom/flyfishxu/kadb/core/AdbConnection$Companion$connect$1;->result:Ljava/lang/Object;

    iget p1, p0, Lcom/flyfishxu/kadb/core/AdbConnection$Companion$connect$1;->label:I

    const/high16 v0, -0x80000000

    or-int/2addr p1, v0

    iput p1, p0, Lcom/flyfishxu/kadb/core/AdbConnection$Companion$connect$1;->label:I

    iget-object v0, p0, Lcom/flyfishxu/kadb/core/AdbConnection$Companion$connect$1;->this$0:Lcom/flyfishxu/kadb/core/AdbConnection$Companion;

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    move-object v7, p0

    invoke-virtual/range {v0 .. v7}, Lcom/flyfishxu/kadb/core/AdbConnection$Companion;->connect(Ljava/lang/String;ILcom/flyfishxu/kadb/cert/HostKeySet;Lcom/flyfishxu/kadb/KadbOptions;IILkotlin/coroutines/Continuation;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method
