.class public final Lcom/flyfishxu/kadb/core/AdbConnection$Companion;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/flyfishxu/kadb/core/AdbConnection;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Companion"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/flyfishxu/kadb/core/AdbConnection$Companion$ConnectionString;
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000R\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u0008\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0004\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\u0008\u0002\u0008\u0086\u0003\u0018\u00002\u00020\u0001:\u0001\u001eB\t\u0008\u0002\u00a2\u0006\u0004\u0008\u0002\u0010\u0003JP\u0010\u0004\u001a\u000e\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020\u00070\u00052\u0006\u0010\u0008\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u000b2\u0006\u0010\u000c\u001a\u00020\r2\u0008\u0008\u0002\u0010\u000e\u001a\u00020\u000f2\u0008\u0008\u0002\u0010\u0010\u001a\u00020\u000b2\u0008\u0008\u0002\u0010\u0011\u001a\u00020\u000bH\u0086@\u00a2\u0006\u0002\u0010\u0012JP\u0010\u0004\u001a\u000e\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020\u00070\u00052\u0006\u0010\u0008\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u000b2\u0006\u0010\u0013\u001a\u00020\u00142\u0008\u0008\u0002\u0010\u000e\u001a\u00020\u000f2\u0008\u0008\u0002\u0010\u0010\u001a\u00020\u000b2\u0008\u0008\u0002\u0010\u0011\u001a\u00020\u000bH\u0086@\u00a2\u0006\u0002\u0010\u0015J\u0010\u0010\u0016\u001a\u00020\u00172\u0006\u0010\u0018\u001a\u00020\tH\u0002J\u0018\u0010\u0019\u001a\u00020\u000b2\u0006\u0010\u001a\u001a\u00020\u001b2\u0006\u0010\u001c\u001a\u00020\u001dH\u0002\u00a8\u0006\u001f"
    }
    d2 = {
        "Lcom/flyfishxu/kadb/core/AdbConnection$Companion;",
        "",
        "<init>",
        "()V",
        "connect",
        "Lkotlin/Pair;",
        "Lcom/flyfishxu/kadb/core/AdbConnection;",
        "Lcom/flyfishxu/kadb/transport/TransportChannel;",
        "host",
        "",
        "port",
        "",
        "hostKeySet",
        "Lcom/flyfishxu/kadb/cert/HostKeySet;",
        "options",
        "Lcom/flyfishxu/kadb/KadbOptions;",
        "connectTimeoutMs",
        "ioTimeoutMs",
        "(Ljava/lang/String;ILcom/flyfishxu/kadb/cert/HostKeySet;Lcom/flyfishxu/kadb/KadbOptions;IILkotlin/coroutines/Continuation;)Ljava/lang/Object;",
        "keyPair",
        "Lcom/flyfishxu/kadb/cert/AdbKeyPair;",
        "(Ljava/lang/String;ILcom/flyfishxu/kadb/cert/AdbKeyPair;Lcom/flyfishxu/kadb/KadbOptions;IILkotlin/coroutines/Continuation;)Ljava/lang/Object;",
        "parseConnectionString",
        "Lcom/flyfishxu/kadb/core/AdbConnection$Companion$ConnectionString;",
        "connectionString",
        "decodeOkayAckBytes",
        "message",
        "Lcom/flyfishxu/kadb/core/AdbMessage;",
        "delayedAckEnabled",
        "",
        "ConnectionString",
        "com.github.IndiTheo:kadb"
    }
    k = 0x1
    mv = {
        0x2,
        0x4,
        0x0
    }
    xi = 0x30
.end annotation

.annotation build Lkotlin/jvm/internal/SourceDebugExtension;
    value = {
        "SMAP\nAdbConnection.kt\nKotlin\n*S Kotlin\n*F\n+ 1 AdbConnection.kt\ncom/flyfishxu/kadb/core/AdbConnection$Companion\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,306:1\n1#2:307\n1739#3:308\n1814#3,3:309\n777#3:312\n873#3,2:313\n*S KotlinDebug\n*F\n+ 1 AdbConnection.kt\ncom/flyfishxu/kadb/core/AdbConnection$Companion\n*L\n267#1:308\n267#1:309,3\n268#1:312\n268#1:313,2\n*E\n"
    }
.end annotation


# direct methods
.method private constructor <init>()V
    .locals 0

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Lcom/flyfishxu/kadb/core/AdbConnection$Companion;-><init>()V

    return-void
.end method

.method public static final synthetic access$decodeOkayAckBytes(Lcom/flyfishxu/kadb/core/AdbConnection$Companion;Lcom/flyfishxu/kadb/core/AdbMessage;Z)I
    .locals 0

    invoke-direct {p0, p1, p2}, Lcom/flyfishxu/kadb/core/AdbConnection$Companion;->decodeOkayAckBytes(Lcom/flyfishxu/kadb/core/AdbMessage;Z)I

    move-result p0

    return p0
.end method

.method public static synthetic connect$default(Lcom/flyfishxu/kadb/core/AdbConnection$Companion;Ljava/lang/String;ILcom/flyfishxu/kadb/cert/AdbKeyPair;Lcom/flyfishxu/kadb/KadbOptions;IILkotlin/coroutines/Continuation;ILjava/lang/Object;)Ljava/lang/Object;
    .locals 11

    and-int/lit8 v0, p8, 0x8

    if-eqz v0, :cond_0

    .line 3
    new-instance v0, Lcom/flyfishxu/kadb/KadbOptions;

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-direct {v0, v2, v1, v2}, Lcom/flyfishxu/kadb/KadbOptions;-><init>(Lcom/flyfishxu/kadb/DelayedAckMode;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    move-object v7, v0

    goto :goto_0

    :cond_0
    move-object v7, p4

    :goto_0
    and-int/lit8 v0, p8, 0x10

    if-eqz v0, :cond_1

    const/16 v0, 0x2710

    move v8, v0

    goto :goto_1

    :cond_1
    move/from16 v8, p5

    :goto_1
    and-int/lit8 v0, p8, 0x20

    if-eqz v0, :cond_2

    const/4 v0, 0x0

    move v9, v0

    goto :goto_2

    :cond_2
    move/from16 v9, p6

    :goto_2
    move-object v3, p0

    move-object v4, p1

    move v5, p2

    move-object v6, p3

    move-object/from16 v10, p7

    .line 4
    invoke-virtual/range {v3 .. v10}, Lcom/flyfishxu/kadb/core/AdbConnection$Companion;->connect(Ljava/lang/String;ILcom/flyfishxu/kadb/cert/AdbKeyPair;Lcom/flyfishxu/kadb/KadbOptions;IILkotlin/coroutines/Continuation;)Ljava/lang/Object;

    move-result-object v0

    return-object v0
.end method

.method public static synthetic connect$default(Lcom/flyfishxu/kadb/core/AdbConnection$Companion;Ljava/lang/String;ILcom/flyfishxu/kadb/cert/HostKeySet;Lcom/flyfishxu/kadb/KadbOptions;IILkotlin/coroutines/Continuation;ILjava/lang/Object;)Ljava/lang/Object;
    .locals 11

    and-int/lit8 v0, p8, 0x8

    if-eqz v0, :cond_0

    .line 1
    new-instance v0, Lcom/flyfishxu/kadb/KadbOptions;

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-direct {v0, v2, v1, v2}, Lcom/flyfishxu/kadb/KadbOptions;-><init>(Lcom/flyfishxu/kadb/DelayedAckMode;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    move-object v7, v0

    goto :goto_0

    :cond_0
    move-object v7, p4

    :goto_0
    and-int/lit8 v0, p8, 0x10

    if-eqz v0, :cond_1

    const/16 v0, 0x2710

    move v8, v0

    goto :goto_1

    :cond_1
    move/from16 v8, p5

    :goto_1
    and-int/lit8 v0, p8, 0x20

    if-eqz v0, :cond_2

    const/4 v0, 0x0

    move v9, v0

    goto :goto_2

    :cond_2
    move/from16 v9, p6

    :goto_2
    move-object v3, p0

    move-object v4, p1

    move v5, p2

    move-object v6, p3

    move-object/from16 v10, p7

    .line 2
    invoke-virtual/range {v3 .. v10}, Lcom/flyfishxu/kadb/core/AdbConnection$Companion;->connect(Ljava/lang/String;ILcom/flyfishxu/kadb/cert/HostKeySet;Lcom/flyfishxu/kadb/KadbOptions;IILkotlin/coroutines/Continuation;)Ljava/lang/Object;

    move-result-object v0

    return-object v0
.end method

.method private final decodeOkayAckBytes(Lcom/flyfishxu/kadb/core/AdbMessage;Z)I
    .locals 1

    invoke-virtual {p1}, Lcom/flyfishxu/kadb/core/AdbMessage;->getCommand()I

    move-result p0

    const v0, 0x59414b4f

    if-ne p0, v0, :cond_4

    invoke-virtual {p1}, Lcom/flyfishxu/kadb/core/AdbMessage;->getPayloadLength()I

    move-result p0

    if-eqz p0, :cond_2

    const/4 v0, 0x4

    if-ne p0, v0, :cond_1

    if-eqz p2, :cond_0

    new-instance p0, Lokio/Buffer;

    invoke-direct {p0}, Lokio/Buffer;-><init>()V

    invoke-virtual {p1}, Lcom/flyfishxu/kadb/core/AdbMessage;->getPayload()[B

    move-result-object p1

    invoke-virtual {p0, p1}, Lokio/Buffer;->write([B)Lokio/Buffer;

    move-result-object p0

    invoke-virtual {p0}, Lokio/Buffer;->readIntLe()I

    move-result p0

    goto :goto_0

    :cond_0
    new-instance p0, Ljava/io/IOException;

    invoke-virtual {p1}, Lcom/flyfishxu/kadb/core/AdbMessage;->getPayloadLength()I

    move-result p1

    new-instance p2, Ljava/lang/StringBuilder;

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v0, "Unexpected OKAY payload for non-delayed-ack stream: "

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_1
    new-instance p0, Ljava/io/IOException;

    invoke-virtual {p1}, Lcom/flyfishxu/kadb/core/AdbMessage;->getPayloadLength()I

    move-result p1

    new-instance p2, Ljava/lang/StringBuilder;

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v0, "Invalid OKAY payload size: "

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_2
    if-nez p2, :cond_3

    const/4 p0, 0x0

    :goto_0
    return p0

    :cond_3
    new-instance p0, Ljava/io/IOException;

    invoke-virtual {p1}, Lcom/flyfishxu/kadb/core/AdbMessage;->getArg1()I

    move-result p1

    const/16 p2, 0x10

    invoke-static {p2}, Lkotlin/text/CharsKt;->checkRadix(I)I

    move-result p2

    invoke-static {p1, p2}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    move-result-object p1

    const-string p2, "toString(...)"

    invoke-static {p1, p2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance p2, Ljava/lang/StringBuilder;

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v0, "Delayed ACK stream missing OKAY payload for localId: "

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_4
    invoke-virtual {p1}, Lcom/flyfishxu/kadb/core/AdbMessage;->getCommand()I

    move-result p0

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const-string p2, "Expected OKAY message, got "

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    new-instance p1, Ljava/lang/IllegalArgumentException;

    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {p1, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method private final parseConnectionString(Ljava/lang/String;)Lcom/flyfishxu/kadb/core/AdbConnection$Companion$ConnectionString;
    .locals 10

    const-string p0, ":"

    filled-new-array {p0}, [Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x6

    const/4 v5, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    move-object v0, p1

    invoke-static/range {v0 .. v5}, Lkotlin/text/StringsKt;->split$default(Ljava/lang/CharSequence;[Ljava/lang/String;ZIILjava/lang/Object;)Ljava/util/List;

    move-result-object p0

    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result p1

    const/4 v0, 0x2

    if-gt p1, v0, :cond_0

    new-instance p0, Lcom/flyfishxu/kadb/core/AdbConnection$Companion$ConnectionString;

    invoke-static {}, Lkotlin/collections/SetsKt;->emptySet()Ljava/util/Set;

    move-result-object p1

    invoke-direct {p0, p1}, Lcom/flyfishxu/kadb/core/AdbConnection$Companion$ConnectionString;-><init>(Ljava/util/Set;)V

    return-object p0

    :cond_0
    invoke-static {}, Lkotlin/collections/SetsKt;->emptySet()Ljava/util/Set;

    move-result-object p1

    invoke-interface {p0, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p0

    move-object v0, p0

    check-cast v0, Ljava/lang/CharSequence;

    const-string p0, ";"

    filled-new-array {p0}, [Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x6

    const/4 v5, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-static/range {v0 .. v5}, Lkotlin/text/StringsKt;->split$default(Ljava/lang/CharSequence;[Ljava/lang/String;ZIILjava/lang/Object;)Ljava/util/List;

    move-result-object p0

    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :cond_1
    :goto_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_7

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    invoke-interface {v0}, Ljava/lang/CharSequence;->length()I

    move-result v1

    if-nez v1, :cond_2

    goto :goto_0

    :cond_2
    const/4 v5, 0x6

    const/4 v6, 0x0

    const/16 v2, 0x3d

    const/4 v3, 0x0

    const/4 v4, 0x0

    move-object v1, v0

    invoke-static/range {v1 .. v6}, Lkotlin/text/StringsKt;->indexOf$default(Ljava/lang/CharSequence;CIZILjava/lang/Object;)I

    move-result v1

    if-lez v1, :cond_1

    invoke-static {v0}, Lkotlin/text/StringsKt;->getLastIndex(Ljava/lang/CharSequence;)I

    move-result v2

    if-ne v1, v2, :cond_3

    goto :goto_0

    :cond_3
    const/4 v2, 0x0

    invoke-virtual {v0, v2, v1}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v2

    const-string v3, "substring(...)"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    add-int/lit8 v1, v1, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "features"

    invoke-static {v2, v0}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1

    const-string p1, ","

    filled-new-array {p1}, [Ljava/lang/String;

    move-result-object v5

    const/4 v8, 0x6

    const/4 v9, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-static/range {v4 .. v9}, Lkotlin/text/StringsKt;->split$default(Ljava/lang/CharSequence;[Ljava/lang/String;ZIILjava/lang/Object;)Ljava/util/List;

    move-result-object p1

    new-instance v0, Ljava/util/ArrayList;

    const/16 v1, 0xa

    invoke-static {p1, v1}, Lkotlin/collections/CollectionsKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I

    move-result v1

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_1
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_4

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    invoke-static {v1}, Lkotlin/text/StringsKt;->trim(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_1

    :cond_4
    new-instance p1, Ljava/util/ArrayList;

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_5
    :goto_2
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_6

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    move-object v2, v1

    check-cast v2, Ljava/lang/String;

    invoke-interface {v2}, Ljava/lang/CharSequence;->length()I

    move-result v2

    if-lez v2, :cond_5

    invoke-interface {p1, v1}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_2

    :cond_6
    invoke-static {p1}, Lkotlin/collections/CollectionsKt;->toSet(Ljava/lang/Iterable;)Ljava/util/Set;

    move-result-object p1

    goto/16 :goto_0

    :cond_7
    new-instance p0, Lcom/flyfishxu/kadb/core/AdbConnection$Companion$ConnectionString;

    invoke-direct {p0, p1}, Lcom/flyfishxu/kadb/core/AdbConnection$Companion$ConnectionString;-><init>(Ljava/util/Set;)V

    return-object p0
.end method


# virtual methods
.method public final connect(Ljava/lang/String;ILcom/flyfishxu/kadb/cert/AdbKeyPair;Lcom/flyfishxu/kadb/KadbOptions;IILkotlin/coroutines/Continuation;)Ljava/lang/Object;
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "I",
            "Lcom/flyfishxu/kadb/cert/AdbKeyPair;",
            "Lcom/flyfishxu/kadb/KadbOptions;",
            "II",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Lkotlin/Pair<",
            "Lcom/flyfishxu/kadb/core/AdbConnection;",
            "+",
            "Lcom/flyfishxu/kadb/transport/TransportChannel;",
            ">;>;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 49
    sget-object v0, Lcom/flyfishxu/kadb/cert/HostKeySet;->Companion:Lcom/flyfishxu/kadb/cert/HostKeySet$Companion;

    move-object v1, p3

    invoke-virtual {v0, p3}, Lcom/flyfishxu/kadb/cert/HostKeySet$Companion;->single(Lcom/flyfishxu/kadb/cert/AdbKeyPair;)Lcom/flyfishxu/kadb/cert/HostKeySet;

    move-result-object v4

    move-object v1, p0

    move-object v2, p1

    move v3, p2

    move-object v5, p4

    move v6, p5

    move v7, p6

    move-object/from16 v8, p7

    .line 50
    invoke-virtual/range {v1 .. v8}, Lcom/flyfishxu/kadb/core/AdbConnection$Companion;->connect(Ljava/lang/String;ILcom/flyfishxu/kadb/cert/HostKeySet;Lcom/flyfishxu/kadb/KadbOptions;IILkotlin/coroutines/Continuation;)Ljava/lang/Object;

    move-result-object v0

    return-object v0
.end method

.method public final connect(Ljava/lang/String;ILcom/flyfishxu/kadb/cert/HostKeySet;Lcom/flyfishxu/kadb/KadbOptions;IILkotlin/coroutines/Continuation;)Ljava/lang/Object;
    .locals 27
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "I",
            "Lcom/flyfishxu/kadb/cert/HostKeySet;",
            "Lcom/flyfishxu/kadb/KadbOptions;",
            "II",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Lkotlin/Pair<",
            "Lcom/flyfishxu/kadb/core/AdbConnection;",
            "+",
            "Lcom/flyfishxu/kadb/transport/TransportChannel;",
            ">;>;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    move-object/from16 v0, p0

    move/from16 v1, p5

    move/from16 v2, p6

    move-object/from16 v3, p7

    instance-of v4, v3, Lcom/flyfishxu/kadb/core/AdbConnection$Companion$connect$1;

    if-eqz v4, :cond_0

    move-object v4, v3

    check-cast v4, Lcom/flyfishxu/kadb/core/AdbConnection$Companion$connect$1;

    iget v5, v4, Lcom/flyfishxu/kadb/core/AdbConnection$Companion$connect$1;->label:I

    const/high16 v6, -0x80000000

    and-int v7, v5, v6

    if-eqz v7, :cond_0

    sub-int/2addr v5, v6

    iput v5, v4, Lcom/flyfishxu/kadb/core/AdbConnection$Companion$connect$1;->label:I

    goto :goto_0

    :cond_0
    new-instance v4, Lcom/flyfishxu/kadb/core/AdbConnection$Companion$connect$1;

    invoke-direct {v4, v0, v3}, Lcom/flyfishxu/kadb/core/AdbConnection$Companion$connect$1;-><init>(Lcom/flyfishxu/kadb/core/AdbConnection$Companion;Lkotlin/coroutines/Continuation;)V

    :goto_0
    iget-object v3, v4, Lcom/flyfishxu/kadb/core/AdbConnection$Companion$connect$1;->result:Ljava/lang/Object;

    invoke-static {}, Lkotlin/coroutines/intrinsics/IntrinsicsKt;->getCOROUTINE_SUSPENDED()Ljava/lang/Object;

    move-result-object v11

    .line 1
    iget v5, v4, Lcom/flyfishxu/kadb/core/AdbConnection$Companion$connect$1;->label:I

    const/4 v14, 0x2

    const/4 v15, 0x1

    if-eqz v5, :cond_3

    if-eq v5, v15, :cond_2

    if-ne v5, v14, :cond_1

    iget v1, v4, Lcom/flyfishxu/kadb/core/AdbConnection$Companion$connect$1;->I$3:I

    iget-wide v5, v4, Lcom/flyfishxu/kadb/core/AdbConnection$Companion$connect$1;->J$1:J

    iget-wide v7, v4, Lcom/flyfishxu/kadb/core/AdbConnection$Companion$connect$1;->J$0:J

    iget v2, v4, Lcom/flyfishxu/kadb/core/AdbConnection$Companion$connect$1;->I$2:I

    iget v9, v4, Lcom/flyfishxu/kadb/core/AdbConnection$Companion$connect$1;->I$1:I

    iget v10, v4, Lcom/flyfishxu/kadb/core/AdbConnection$Companion$connect$1;->I$0:I

    iget-object v12, v4, Lcom/flyfishxu/kadb/core/AdbConnection$Companion$connect$1;->L$11:Ljava/lang/Object;

    check-cast v12, Lcom/flyfishxu/kadb/transport/TlsNioChannel;

    iget-object v14, v4, Lcom/flyfishxu/kadb/core/AdbConnection$Companion$connect$1;->L$10:Ljava/lang/Object;

    check-cast v14, Ljavax/net/ssl/SSLEngine;

    iget-object v14, v4, Lcom/flyfishxu/kadb/core/AdbConnection$Companion$connect$1;->L$9:Ljava/lang/Object;

    check-cast v14, Ljavax/net/ssl/SSLContext;

    iget-object v14, v4, Lcom/flyfishxu/kadb/core/AdbConnection$Companion$connect$1;->L$8:Ljava/lang/Object;

    check-cast v14, Lkotlin/jvm/internal/Ref$ObjectRef;

    iget-object v15, v4, Lcom/flyfishxu/kadb/core/AdbConnection$Companion$connect$1;->L$7:Ljava/lang/Object;

    check-cast v15, [B

    iget-object v13, v4, Lcom/flyfishxu/kadb/core/AdbConnection$Companion$connect$1;->L$6:Ljava/lang/Object;

    check-cast v13, Ljava/util/Set;

    move/from16 p1, v1

    iget-object v1, v4, Lcom/flyfishxu/kadb/core/AdbConnection$Companion$connect$1;->L$5:Ljava/lang/Object;

    check-cast v1, Lcom/flyfishxu/kadb/core/AdbWriter;

    move-object/from16 p2, v1

    iget-object v1, v4, Lcom/flyfishxu/kadb/core/AdbConnection$Companion$connect$1;->L$4:Ljava/lang/Object;

    check-cast v1, Lcom/flyfishxu/kadb/core/AdbReader;

    move-object/from16 p3, v1

    iget-object v1, v4, Lcom/flyfishxu/kadb/core/AdbConnection$Companion$connect$1;->L$3:Ljava/lang/Object;

    check-cast v1, Lcom/flyfishxu/kadb/transport/TransportChannel;

    move-object/from16 p4, v1

    iget-object v1, v4, Lcom/flyfishxu/kadb/core/AdbConnection$Companion$connect$1;->L$2:Ljava/lang/Object;

    check-cast v1, Lcom/flyfishxu/kadb/KadbOptions;

    move-object/from16 p5, v1

    iget-object v1, v4, Lcom/flyfishxu/kadb/core/AdbConnection$Companion$connect$1;->L$1:Ljava/lang/Object;

    check-cast v1, Lcom/flyfishxu/kadb/cert/HostKeySet;

    move-object/from16 p6, v1

    iget-object v1, v4, Lcom/flyfishxu/kadb/core/AdbConnection$Companion$connect$1;->L$0:Ljava/lang/Object;

    check-cast v1, Ljava/lang/String;

    :try_start_0
    invoke-static {v3}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    move/from16 v18, p1

    move-object/from16 v3, p4

    move-object/from16 v24, v1

    move-wide/from16 v22, v7

    move v0, v10

    move-object v8, v12

    move-object/from16 v19, v15

    move-object/from16 v1, p3

    move-object/from16 v12, p5

    move-wide v6, v5

    move v10, v9

    move-object v9, v11

    move-object v11, v13

    move-object/from16 v13, p6

    move-object v5, v4

    move v4, v2

    move-object/from16 v2, p2

    goto/16 :goto_3

    :catchall_0
    move-exception v0

    move-object/from16 v2, p2

    move-object/from16 v15, p3

    move-object/from16 v1, p4

    goto/16 :goto_8

    :cond_1
    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v1, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_2
    iget v1, v4, Lcom/flyfishxu/kadb/core/AdbConnection$Companion$connect$1;->I$3:I

    iget-wide v5, v4, Lcom/flyfishxu/kadb/core/AdbConnection$Companion$connect$1;->J$1:J

    iget-wide v7, v4, Lcom/flyfishxu/kadb/core/AdbConnection$Companion$connect$1;->J$0:J

    iget v2, v4, Lcom/flyfishxu/kadb/core/AdbConnection$Companion$connect$1;->I$2:I

    iget v9, v4, Lcom/flyfishxu/kadb/core/AdbConnection$Companion$connect$1;->I$1:I

    iget v10, v4, Lcom/flyfishxu/kadb/core/AdbConnection$Companion$connect$1;->I$0:I

    iget-object v12, v4, Lcom/flyfishxu/kadb/core/AdbConnection$Companion$connect$1;->L$2:Ljava/lang/Object;

    check-cast v12, Lcom/flyfishxu/kadb/KadbOptions;

    iget-object v13, v4, Lcom/flyfishxu/kadb/core/AdbConnection$Companion$connect$1;->L$1:Ljava/lang/Object;

    check-cast v13, Lcom/flyfishxu/kadb/cert/HostKeySet;

    iget-object v14, v4, Lcom/flyfishxu/kadb/core/AdbConnection$Companion$connect$1;->L$0:Ljava/lang/Object;

    check-cast v14, Ljava/lang/String;

    invoke-static {v3}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    goto :goto_1

    :cond_3
    invoke-static {v3}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    int-to-long v12, v1

    int-to-long v14, v2

    .line 2
    sget-object v5, Lcom/flyfishxu/kadb/transport/TransportFactory;->INSTANCE:Lcom/flyfishxu/kadb/transport/TransportFactory;

    move-object/from16 v3, p1

    iput-object v3, v4, Lcom/flyfishxu/kadb/core/AdbConnection$Companion$connect$1;->L$0:Ljava/lang/Object;

    move-object/from16 v10, p3

    iput-object v10, v4, Lcom/flyfishxu/kadb/core/AdbConnection$Companion$connect$1;->L$1:Ljava/lang/Object;

    move-object/from16 v8, p4

    iput-object v8, v4, Lcom/flyfishxu/kadb/core/AdbConnection$Companion$connect$1;->L$2:Ljava/lang/Object;

    move/from16 v9, p2

    iput v9, v4, Lcom/flyfishxu/kadb/core/AdbConnection$Companion$connect$1;->I$0:I

    iput v1, v4, Lcom/flyfishxu/kadb/core/AdbConnection$Companion$connect$1;->I$1:I

    iput v2, v4, Lcom/flyfishxu/kadb/core/AdbConnection$Companion$connect$1;->I$2:I

    iput-wide v12, v4, Lcom/flyfishxu/kadb/core/AdbConnection$Companion$connect$1;->J$0:J

    iput-wide v14, v4, Lcom/flyfishxu/kadb/core/AdbConnection$Companion$connect$1;->J$1:J

    const/4 v6, 0x0

    iput v6, v4, Lcom/flyfishxu/kadb/core/AdbConnection$Companion$connect$1;->I$3:I

    const/4 v6, 0x1

    iput v6, v4, Lcom/flyfishxu/kadb/core/AdbConnection$Companion$connect$1;->label:I

    move-object/from16 v6, p1

    move/from16 v7, p2

    move-wide v8, v12

    move-object v10, v4

    invoke-virtual/range {v5 .. v10}, Lcom/flyfishxu/kadb/transport/TransportFactory;->connect(Ljava/lang/String;IJLkotlin/coroutines/Continuation;)Ljava/lang/Object;

    move-result-object v5

    if-ne v5, v11, :cond_4

    return-object v11

    :cond_4
    move/from16 v10, p2

    move v9, v1

    move-wide v7, v12

    const/4 v1, 0x0

    move-object/from16 v13, p3

    move-object/from16 v12, p4

    move-wide/from16 v25, v14

    move-object v14, v3

    move-object v3, v5

    move-wide/from16 v5, v25

    .line 3
    :goto_1
    check-cast v3, Lcom/flyfishxu/kadb/transport/TransportChannel;

    .line 4
    new-instance v15, Lcom/flyfishxu/kadb/core/AdbReader;

    move/from16 p1, v1

    invoke-static {v3, v5, v6}, Lcom/flyfishxu/kadb/transport/OkioAdaptersKt;->asOkioSource(Lcom/flyfishxu/kadb/transport/TransportChannel;J)Lokio/Source;

    move-result-object v1

    move/from16 p2, v2

    move-object/from16 v17, v4

    move-wide/from16 p3, v7

    const/4 v2, 0x0

    const/4 v4, 0x0

    const/4 v7, 0x2

    invoke-direct {v15, v1, v4, v7, v2}, Lcom/flyfishxu/kadb/core/AdbReader;-><init>(Lokio/Source;IILkotlin/jvm/internal/DefaultConstructorMarker;)V

    .line 5
    new-instance v1, Lcom/flyfishxu/kadb/core/AdbWriter;

    invoke-static {v3, v5, v6}, Lcom/flyfishxu/kadb/transport/OkioAdaptersKt;->asOkioSink(Lcom/flyfishxu/kadb/transport/TransportChannel;J)Lokio/Sink;

    move-result-object v2

    invoke-direct {v1, v2}, Lcom/flyfishxu/kadb/core/AdbWriter;-><init>(Lokio/Sink;)V

    .line 6
    :try_start_1
    sget-object v2, Lcom/flyfishxu/kadb/core/AdbProtocol;->INSTANCE:Lcom/flyfishxu/kadb/core/AdbProtocol;

    invoke-virtual {v12}, Lcom/flyfishxu/kadb/KadbOptions;->getDelayedAckMode()Lcom/flyfishxu/kadb/DelayedAckMode;

    move-result-object v4

    invoke-virtual {v2, v4}, Lcom/flyfishxu/kadb/core/AdbProtocol;->connectFeatures(Lcom/flyfishxu/kadb/DelayedAckMode;)Ljava/util/List;

    move-result-object v4

    invoke-static {v4}, Lkotlin/collections/CollectionsKt;->toSet(Ljava/lang/Iterable;)Ljava/util/Set;

    move-result-object v4

    .line 7
    invoke-static {v4}, Lkotlin/collections/CollectionsKt;->toList(Ljava/lang/Iterable;)Ljava/util/List;

    move-result-object v7

    .line 8
    invoke-virtual {v2, v7}, Lcom/flyfishxu/kadb/core/AdbProtocol;->connectPayload(Ljava/util/List;)[B

    move-result-object v2

    .line 9
    invoke-virtual {v1, v2}, Lcom/flyfishxu/kadb/core/AdbWriter;->writeConnect([B)V

    .line 10
    new-instance v7, Lkotlin/jvm/internal/Ref$ObjectRef;

    invoke-direct {v7}, Lkotlin/jvm/internal/Ref$ObjectRef;-><init>()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_8

    .line 11
    :try_start_2
    invoke-virtual {v15}, Lcom/flyfishxu/kadb/core/AdbReader;->readMessage()Lcom/flyfishxu/kadb/core/AdbMessage;

    move-result-object v8
    :try_end_2
    .catch Ljavax/net/ssl/SSLProtocolException; {:try_start_2 .. :try_end_2} :catch_0
    .catchall {:try_start_2 .. :try_end_2} :catchall_8

    .line 12
    :try_start_3
    iput-object v8, v7, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;

    move/from16 v18, p1

    move-object/from16 v19, v2

    move-wide/from16 v20, v5

    move-object v2, v7

    move v0, v10

    move-object/from16 v5, v17

    move v10, v9

    move-object/from16 v17, v11

    move-wide/from16 v8, p3

    move-object v11, v4

    move/from16 v4, p2

    .line 13
    :goto_2
    iget-object v6, v2, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;

    check-cast v6, Lcom/flyfishxu/kadb/core/AdbMessage;

    invoke-virtual {v6}, Lcom/flyfishxu/kadb/core/AdbMessage;->getCommand()I

    move-result v6

    const v7, 0x48545541

    if-eq v6, v7, :cond_9

    const v7, 0x4e584e43    # 9.072519E8f

    if-eq v6, v7, :cond_7

    const v7, 0x534c5453

    if-ne v6, v7, :cond_6

    const/high16 v6, 0x1000000

    .line 14
    invoke-virtual {v1, v6}, Lcom/flyfishxu/kadb/core/AdbWriter;->writeStls(I)V

    .line 15
    sget-object v6, Lcom/flyfishxu/kadb/pair/SslUtils;->INSTANCE:Lcom/flyfishxu/kadb/pair/SslUtils;

    invoke-virtual {v6, v13}, Lcom/flyfishxu/kadb/pair/SslUtils;->getSslContext(Lcom/flyfishxu/kadb/cert/HostKeySet;)Ljavax/net/ssl/SSLContext;

    move-result-object v7

    .line 16
    invoke-virtual {v6, v7, v14, v0}, Lcom/flyfishxu/kadb/pair/SslUtils;->newClientEngine(Ljavax/net/ssl/SSLContext;Ljava/lang/String;I)Ljavax/net/ssl/SSLEngine;

    move-result-object v6

    move-wide/from16 v22, v8

    .line 17
    new-instance v8, Lcom/flyfishxu/kadb/transport/TlsNioChannel;

    invoke-direct {v8, v3, v6}, Lcom/flyfishxu/kadb/transport/TlsNioChannel;-><init>(Lcom/flyfishxu/kadb/transport/TransportChannel;Ljavax/net/ssl/SSLEngine;)V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_8

    .line 18
    :try_start_4
    sget-object v9, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    iput-object v14, v5, Lcom/flyfishxu/kadb/core/AdbConnection$Companion$connect$1;->L$0:Ljava/lang/Object;

    iput-object v13, v5, Lcom/flyfishxu/kadb/core/AdbConnection$Companion$connect$1;->L$1:Ljava/lang/Object;

    move-object/from16 v24, v14

    invoke-static {v12}, Lkotlin/coroutines/jvm/internal/SpillingKt;->nullOutSpilledVariable(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v14

    iput-object v14, v5, Lcom/flyfishxu/kadb/core/AdbConnection$Companion$connect$1;->L$2:Ljava/lang/Object;

    iput-object v3, v5, Lcom/flyfishxu/kadb/core/AdbConnection$Companion$connect$1;->L$3:Ljava/lang/Object;

    iput-object v15, v5, Lcom/flyfishxu/kadb/core/AdbConnection$Companion$connect$1;->L$4:Ljava/lang/Object;

    iput-object v1, v5, Lcom/flyfishxu/kadb/core/AdbConnection$Companion$connect$1;->L$5:Ljava/lang/Object;

    iput-object v11, v5, Lcom/flyfishxu/kadb/core/AdbConnection$Companion$connect$1;->L$6:Ljava/lang/Object;

    invoke-static/range {v19 .. v19}, Lkotlin/coroutines/jvm/internal/SpillingKt;->nullOutSpilledVariable(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v14

    iput-object v14, v5, Lcom/flyfishxu/kadb/core/AdbConnection$Companion$connect$1;->L$7:Ljava/lang/Object;

    iput-object v2, v5, Lcom/flyfishxu/kadb/core/AdbConnection$Companion$connect$1;->L$8:Ljava/lang/Object;

    invoke-static {v7}, Lkotlin/coroutines/jvm/internal/SpillingKt;->nullOutSpilledVariable(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v7

    iput-object v7, v5, Lcom/flyfishxu/kadb/core/AdbConnection$Companion$connect$1;->L$9:Ljava/lang/Object;

    invoke-static {v6}, Lkotlin/coroutines/jvm/internal/SpillingKt;->nullOutSpilledVariable(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v6

    iput-object v6, v5, Lcom/flyfishxu/kadb/core/AdbConnection$Companion$connect$1;->L$10:Ljava/lang/Object;

    iput-object v8, v5, Lcom/flyfishxu/kadb/core/AdbConnection$Companion$connect$1;->L$11:Ljava/lang/Object;

    iput v0, v5, Lcom/flyfishxu/kadb/core/AdbConnection$Companion$connect$1;->I$0:I

    iput v10, v5, Lcom/flyfishxu/kadb/core/AdbConnection$Companion$connect$1;->I$1:I

    iput v4, v5, Lcom/flyfishxu/kadb/core/AdbConnection$Companion$connect$1;->I$2:I

    move-wide/from16 v6, v22

    iput-wide v6, v5, Lcom/flyfishxu/kadb/core/AdbConnection$Companion$connect$1;->J$0:J

    move-wide/from16 v22, v6

    move-wide/from16 v6, v20

    iput-wide v6, v5, Lcom/flyfishxu/kadb/core/AdbConnection$Companion$connect$1;->J$1:J

    move/from16 v14, v18

    iput v14, v5, Lcom/flyfishxu/kadb/core/AdbConnection$Companion$connect$1;->I$3:I

    move/from16 v18, v0

    const/4 v0, 0x2

    iput v0, v5, Lcom/flyfishxu/kadb/core/AdbConnection$Companion$connect$1;->label:I

    invoke-virtual {v8, v6, v7, v9, v5}, Lcom/flyfishxu/kadb/transport/TlsNioChannel;->handshake(JLjava/util/concurrent/TimeUnit;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    move-result-object v0
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_6

    move-object/from16 v9, v17

    if-ne v0, v9, :cond_5

    return-object v9

    :cond_5
    move/from16 v0, v18

    move/from16 v18, v14

    move-object v14, v2

    move-object v2, v1

    move-object v1, v15

    .line 19
    :goto_3
    :try_start_5
    invoke-virtual {v1}, Lcom/flyfishxu/kadb/core/AdbReader;->close()V

    .line 20
    invoke-virtual {v2}, Lcom/flyfishxu/kadb/core/AdbWriter;->close()V
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_5

    .line 21
    :try_start_6
    new-instance v15, Lcom/flyfishxu/kadb/core/AdbReader;

    invoke-static {v8, v6, v7}, Lcom/flyfishxu/kadb/transport/OkioAdaptersKt;->asOkioSource(Lcom/flyfishxu/kadb/transport/TransportChannel;J)Lokio/Source;

    move-result-object v3
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_4

    move/from16 p1, v0

    move-object/from16 p3, v1

    move/from16 p2, v4

    const/4 v0, 0x0

    const/4 v1, 0x2

    const/4 v4, 0x0

    :try_start_7
    invoke-direct {v15, v3, v4, v1, v0}, Lcom/flyfishxu/kadb/core/AdbReader;-><init>(Lokio/Source;IILkotlin/jvm/internal/DefaultConstructorMarker;)V
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_3

    .line 22
    :try_start_8
    new-instance v1, Lcom/flyfishxu/kadb/core/AdbWriter;

    invoke-static {v8, v6, v7}, Lcom/flyfishxu/kadb/transport/OkioAdaptersKt;->asOkioSink(Lcom/flyfishxu/kadb/transport/TransportChannel;J)Lokio/Sink;

    move-result-object v3

    invoke-direct {v1, v3}, Lcom/flyfishxu/kadb/core/AdbWriter;-><init>(Lokio/Sink;)V
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_2

    .line 23
    :try_start_9
    invoke-virtual {v15}, Lcom/flyfishxu/kadb/core/AdbReader;->readMessage()Lcom/flyfishxu/kadb/core/AdbMessage;

    move-result-object v2

    iput-object v2, v14, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;
    :try_end_9
    .catchall {:try_start_9 .. :try_end_9} :catchall_1

    move/from16 v0, p1

    move/from16 v4, p2

    move-wide/from16 v20, v6

    move-object v3, v8

    move-object/from16 v17, v9

    move-object v2, v14

    move-wide/from16 v8, v22

    move-object/from16 v14, v24

    goto/16 :goto_2

    :catchall_1
    move-exception v0

    :goto_4
    move-object v3, v8

    goto/16 :goto_a

    :catchall_2
    move-exception v0

    :goto_5
    move-object v1, v2

    goto :goto_4

    :catchall_3
    move-exception v0

    :goto_6
    move-object/from16 v15, p3

    goto :goto_5

    :catchall_4
    move-exception v0

    move-object/from16 p3, v1

    goto :goto_6

    :catchall_5
    move-exception v0

    move-object/from16 p3, v1

    move-object/from16 v15, p3

    :goto_7
    move-object v1, v2

    goto/16 :goto_a

    :catchall_6
    move-exception v0

    move-object v2, v1

    move-object v1, v3

    .line 24
    :goto_8
    :try_start_a
    sget-object v3, Lcom/flyfishxu/kadb/tls/TlsErrorMapper;->INSTANCE:Lcom/flyfishxu/kadb/tls/TlsErrorMapper;

    invoke-virtual {v3, v0}, Lcom/flyfishxu/kadb/tls/TlsErrorMapper;->map(Ljava/lang/Throwable;)Ljava/lang/Throwable;

    move-result-object v0

    throw v0
    :try_end_a
    .catchall {:try_start_a .. :try_end_a} :catchall_7

    :catchall_7
    move-exception v0

    move-object v3, v1

    goto :goto_7

    :catchall_8
    move-exception v0

    goto/16 :goto_a

    .line 25
    :cond_6
    :try_start_b
    new-instance v0, Ljava/io/IOException;

    iget-object v2, v2, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "Connection failed: "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v0, v2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0

    .line 26
    :cond_7
    new-instance v0, Ljava/lang/String;

    iget-object v4, v2, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;

    check-cast v4, Lcom/flyfishxu/kadb/core/AdbMessage;

    invoke-virtual {v4}, Lcom/flyfishxu/kadb/core/AdbMessage;->getPayload()[B

    move-result-object v4

    sget-object v5, Lkotlin/text/Charsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-direct {v0, v4, v5}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V

    move-object/from16 v8, p0

    invoke-direct {v8, v0}, Lcom/flyfishxu/kadb/core/AdbConnection$Companion;->parseConnectionString(Ljava/lang/String;)Lcom/flyfishxu/kadb/core/AdbConnection$Companion$ConnectionString;

    move-result-object v0

    .line 27
    invoke-virtual {v0}, Lcom/flyfishxu/kadb/core/AdbConnection$Companion$ConnectionString;->getFeatures()Ljava/util/Set;

    move-result-object v0

    invoke-static {v0, v11}, Lkotlin/collections/CollectionsKt;->intersect(Ljava/lang/Iterable;Ljava/lang/Iterable;)Ljava/util/Set;

    move-result-object v22

    .line 28
    iget-object v0, v2, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;

    check-cast v0, Lcom/flyfishxu/kadb/core/AdbMessage;

    invoke-virtual {v0}, Lcom/flyfishxu/kadb/core/AdbMessage;->getArg0()I

    move-result v0

    const v4, 0x1000001

    invoke-static {v0, v4}, Ljava/lang/Math;->min(II)I

    move-result v0

    .line 29
    invoke-virtual {v1, v0}, Lcom/flyfishxu/kadb/core/AdbWriter;->updateProtocolVersion(I)V

    .line 30
    iget-object v2, v2, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;

    check-cast v2, Lcom/flyfishxu/kadb/core/AdbMessage;

    invoke-virtual {v2}, Lcom/flyfishxu/kadb/core/AdbMessage;->getArg1()I

    move-result v2

    if-lez v2, :cond_8

    const/high16 v4, 0x100000

    .line 31
    invoke-static {v2, v4}, Ljava/lang/Math;->min(II)I

    move-result v2

    const/4 v5, 0x1

    .line 32
    invoke-static {v2, v5}, Lkotlin/ranges/RangesKt;->coerceAtLeast(II)I

    move-result v2

    .line 33
    invoke-static {v2, v4}, Lkotlin/ranges/RangesKt;->coerceAtMost(II)I

    move-result v2

    .line 34
    invoke-virtual {v15, v2}, Lcom/flyfishxu/kadb/core/AdbReader;->setInboundMaxPayloadSize(I)V

    .line 35
    new-instance v4, Lcom/flyfishxu/kadb/core/AdbConnection;

    move-object/from16 v18, v4

    move-object/from16 v19, v15

    move-object/from16 v20, v1

    move-object/from16 v21, v3

    move/from16 v23, v0

    move/from16 v24, v2

    invoke-direct/range {v18 .. v24}, Lcom/flyfishxu/kadb/core/AdbConnection;-><init>(Lcom/flyfishxu/kadb/core/AdbReader;Lcom/flyfishxu/kadb/core/AdbWriter;Ljava/io/Closeable;Ljava/util/Set;II)V

    .line 36
    invoke-static {v4, v3}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v0

    return-object v0

    .line 37
    :cond_8
    new-instance v0, Ljava/io/IOException;

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "Peer maxdata must be > 0: "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v0, v2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_9
    move/from16 v16, v0

    move-wide/from16 v22, v8

    move-object/from16 v24, v14

    move-object/from16 v9, v17

    move/from16 v14, v18

    move-wide/from16 v6, v20

    move-object/from16 v8, p0

    move/from16 v17, v4

    const/4 v4, 0x0

    .line 38
    iget-object v0, v2, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;

    check-cast v0, Lcom/flyfishxu/kadb/core/AdbMessage;

    invoke-virtual {v0}, Lcom/flyfishxu/kadb/core/AdbMessage;->getArg0()I

    move-result v0

    const/4 v4, 0x1

    if-ne v0, v4, :cond_b

    .line 39
    invoke-virtual {v13}, Lcom/flyfishxu/kadb/cert/HostKeySet;->getKeyPairs()Ljava/util/List;

    move-result-object v0

    invoke-static {v0, v14}, Lkotlin/collections/CollectionsKt;->getOrNull(Ljava/util/List;I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/flyfishxu/kadb/cert/AdbKeyPair;

    if-eqz v0, :cond_a

    add-int/lit8 v14, v14, 0x1

    .line 40
    iget-object v4, v2, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;

    check-cast v4, Lcom/flyfishxu/kadb/core/AdbMessage;

    invoke-virtual {v0, v4}, Lcom/flyfishxu/kadb/cert/AdbKeyPair;->signPayload$com_github_IndiTheo_kadb(Lcom/flyfishxu/kadb/core/AdbMessage;)[B

    move-result-object v0

    const/4 v4, 0x2

    invoke-virtual {v1, v4, v0}, Lcom/flyfishxu/kadb/core/AdbWriter;->writeAuth(I[B)V

    goto :goto_9

    :cond_a
    const/4 v4, 0x2

    .line 41
    invoke-virtual {v13}, Lcom/flyfishxu/kadb/cert/HostKeySet;->getDefaultKeyPair()Lcom/flyfishxu/kadb/cert/AdbKeyPair;

    move-result-object v0

    invoke-static {v0}, Lcom/flyfishxu/kadb/core/AdbConnectionKt;->access$adbPublicKey(Lcom/flyfishxu/kadb/cert/AdbKeyPair;)[B

    move-result-object v0

    const/4 v4, 0x3

    invoke-virtual {v1, v4, v0}, Lcom/flyfishxu/kadb/core/AdbWriter;->writeAuth(I[B)V

    .line 42
    :goto_9
    invoke-virtual {v15}, Lcom/flyfishxu/kadb/core/AdbReader;->readMessage()Lcom/flyfishxu/kadb/core/AdbMessage;

    move-result-object v0

    iput-object v0, v2, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;

    move-wide/from16 v20, v6

    move/from16 v18, v14

    move/from16 v0, v16

    move/from16 v4, v17

    move-object/from16 v14, v24

    move-object/from16 v17, v9

    move-wide/from16 v8, v22

    goto/16 :goto_2

    .line 43
    :cond_b
    iget-object v0, v2, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "Unsupported auth type: "

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    new-instance v2, Ljava/lang/IllegalStateException;

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v2, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v2

    :catch_0
    move-exception v0

    move-object v2, v0

    .line 44
    sget-object v0, Lcom/flyfishxu/kadb/tls/TlsErrorMapper;->INSTANCE:Lcom/flyfishxu/kadb/tls/TlsErrorMapper;

    invoke-virtual {v0, v2}, Lcom/flyfishxu/kadb/tls/TlsErrorMapper;->map(Ljava/lang/Throwable;)Ljava/lang/Throwable;

    move-result-object v0

    throw v0
    :try_end_b
    .catchall {:try_start_b .. :try_end_b} :catchall_8

    .line 45
    :goto_a
    :try_start_c
    invoke-virtual {v15}, Lcom/flyfishxu/kadb/core/AdbReader;->close()V
    :try_end_c
    .catchall {:try_start_c .. :try_end_c} :catchall_9

    .line 46
    :catchall_9
    :try_start_d
    invoke-virtual {v1}, Lcom/flyfishxu/kadb/core/AdbWriter;->close()V
    :try_end_d
    .catchall {:try_start_d .. :try_end_d} :catchall_a

    .line 47
    :catchall_a
    :try_start_e
    invoke-interface {v3}, Ljava/io/Closeable;->close()V
    :try_end_e
    .catchall {:try_start_e .. :try_end_e} :catchall_b

    .line 48
    :catchall_b
    throw v0
.end method
