.class public final Lcom/flyfishxu/kadb/core/AdbConnection;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/AutoCloseable;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/flyfishxu/kadb/core/AdbConnection$Companion;
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000Z\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\"\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u0008\n\u0002\u0008\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0007\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0003\u0008\u0000\u0018\u0000 $2\u00060\u0001j\u0002`\u0002:\u0001$BA\u0008\u0000\u0012\u0006\u0010\u0003\u001a\u00020\u0004\u0012\u0006\u0010\u0005\u001a\u00020\u0006\u0012\u0008\u0010\u0007\u001a\u0004\u0018\u00010\u0008\u0012\u000c\u0010\t\u001a\u0008\u0012\u0004\u0012\u00020\u000b0\n\u0012\u0006\u0010\u000c\u001a\u00020\r\u0012\u0006\u0010\u000e\u001a\u00020\r\u00a2\u0006\u0004\u0008\u000f\u0010\u0010J\u000e\u0010\u0017\u001a\u00020\u00182\u0006\u0010\u0019\u001a\u00020\u000bJ\u000e\u0010\u001a\u001a\u00020\u00162\u0006\u0010\u001b\u001a\u00020\u000bJ\u0013\u0010\u001c\u001a\u0008\u0012\u0004\u0012\u00020\u000b0\nH\u0000\u00a2\u0006\u0002\u0008\u001dJ\u0008\u0010\u001e\u001a\u00020\rH\u0002J\u0011\u0010\u001f\u001a\u00020 H\u0001b\u0002\u0008\"\u00a2\u0006\u0002\u0008!J\u0008\u0010#\u001a\u00020 H\u0016R\u000e\u0010\u0005\u001a\u00020\u0006X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0010\u0010\u0007\u001a\u0004\u0018\u00010\u0008X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0014\u0010\t\u001a\u0008\u0012\u0004\u0012\u00020\u000b0\nX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000c\u001a\u00020\rX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000e\u001a\u00020\rX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0011\u001a\u00020\u0012X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0013\u001a\u00020\u0014X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0015\u001a\u00020\u0016X\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006%"
    }
    d2 = {
        "Lcom/flyfishxu/kadb/core/AdbConnection;",
        "Ljava/lang/AutoCloseable;",
        "Lkotlin/AutoCloseable;",
        "adbReader",
        "Lcom/flyfishxu/kadb/core/AdbReader;",
        "adbWriter",
        "Lcom/flyfishxu/kadb/core/AdbWriter;",
        "closeable",
        "Ljava/io/Closeable;",
        "supportedFeatures",
        "",
        "",
        "version",
        "",
        "outboundMaxPayloadSize",
        "<init>",
        "(Lcom/flyfishxu/kadb/core/AdbReader;Lcom/flyfishxu/kadb/core/AdbWriter;Ljava/io/Closeable;Ljava/util/Set;II)V",
        "random",
        "Ljava/util/Random;",
        "messageQueue",
        "Lcom/flyfishxu/kadb/queue/AdbMessageQueue;",
        "delayedAckEnabled",
        "",
        "open",
        "Lcom/flyfishxu/kadb/stream/AdbStream;",
        "destination",
        "supportsFeature",
        "feature",
        "featureSnapshot",
        "featureSnapshot$com_github_IndiTheo_kadb",
        "newId",
        "ensureEmpty",
        "",
        "ensureEmpty$com_github_IndiTheo_kadb",
        "Lorg/jetbrains/annotations/TestOnly;",
        "close",
        "Companion",
        "com.github.IndiTheo:kadb"
    }
    k = 0x1
    mv = {
        0x2,
        0x4,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final Companion:Lcom/flyfishxu/kadb/core/AdbConnection$Companion;


# instance fields
.field private final adbWriter:Lcom/flyfishxu/kadb/core/AdbWriter;

.field private final closeable:Ljava/io/Closeable;

.field private final delayedAckEnabled:Z

.field private final messageQueue:Lcom/flyfishxu/kadb/queue/AdbMessageQueue;

.field private final outboundMaxPayloadSize:I

.field private final random:Ljava/util/Random;

.field private final supportedFeatures:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private final version:I


# direct methods
.method static constructor <clinit>()V
    .locals 2

    new-instance v0, Lcom/flyfishxu/kadb/core/AdbConnection$Companion;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lcom/flyfishxu/kadb/core/AdbConnection$Companion;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    sput-object v0, Lcom/flyfishxu/kadb/core/AdbConnection;->Companion:Lcom/flyfishxu/kadb/core/AdbConnection$Companion;

    return-void
.end method

.method public constructor <init>(Lcom/flyfishxu/kadb/core/AdbReader;Lcom/flyfishxu/kadb/core/AdbWriter;Ljava/io/Closeable;Ljava/util/Set;II)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/flyfishxu/kadb/core/AdbReader;",
            "Lcom/flyfishxu/kadb/core/AdbWriter;",
            "Ljava/io/Closeable;",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;II)V"
        }
    .end annotation

    const-string v0, "adbReader"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "adbWriter"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "supportedFeatures"

    invoke-static {p4, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p2, p0, Lcom/flyfishxu/kadb/core/AdbConnection;->adbWriter:Lcom/flyfishxu/kadb/core/AdbWriter;

    iput-object p3, p0, Lcom/flyfishxu/kadb/core/AdbConnection;->closeable:Ljava/io/Closeable;

    iput-object p4, p0, Lcom/flyfishxu/kadb/core/AdbConnection;->supportedFeatures:Ljava/util/Set;

    iput p5, p0, Lcom/flyfishxu/kadb/core/AdbConnection;->version:I

    iput p6, p0, Lcom/flyfishxu/kadb/core/AdbConnection;->outboundMaxPayloadSize:I

    new-instance p2, Ljava/util/Random;

    invoke-direct {p2}, Ljava/util/Random;-><init>()V

    iput-object p2, p0, Lcom/flyfishxu/kadb/core/AdbConnection;->random:Ljava/util/Random;

    new-instance p2, Lcom/flyfishxu/kadb/queue/AdbMessageQueue;

    invoke-direct {p2, p1}, Lcom/flyfishxu/kadb/queue/AdbMessageQueue;-><init>(Lcom/flyfishxu/kadb/core/AdbReader;)V

    iput-object p2, p0, Lcom/flyfishxu/kadb/core/AdbConnection;->messageQueue:Lcom/flyfishxu/kadb/queue/AdbMessageQueue;

    const-string p1, "delayed_ack"

    invoke-interface {p4, p1}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result p1

    iput-boolean p1, p0, Lcom/flyfishxu/kadb/core/AdbConnection;->delayedAckEnabled:Z

    return-void
.end method

.method private final newId()I
    .locals 1

    :cond_0
    iget-object v0, p0, Lcom/flyfishxu/kadb/core/AdbConnection;->random:Ljava/util/Random;

    invoke-virtual {v0}, Ljava/util/Random;->nextInt()I

    move-result v0

    if-eqz v0, :cond_0

    return v0
.end method


# virtual methods
.method public close()V
    .locals 1

    :try_start_0
    iget-object v0, p0, Lcom/flyfishxu/kadb/core/AdbConnection;->messageQueue:Lcom/flyfishxu/kadb/queue/AdbMessageQueue;

    invoke-virtual {v0}, Lcom/flyfishxu/kadb/queue/AdbMessageQueue;->close()V

    iget-object v0, p0, Lcom/flyfishxu/kadb/core/AdbConnection;->adbWriter:Lcom/flyfishxu/kadb/core/AdbWriter;

    invoke-virtual {v0}, Lcom/flyfishxu/kadb/core/AdbWriter;->close()V

    iget-object p0, p0, Lcom/flyfishxu/kadb/core/AdbConnection;->closeable:Ljava/io/Closeable;

    if-eqz p0, :cond_0

    invoke-interface {p0}, Ljava/io/Closeable;->close()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :catchall_0
    :cond_0
    return-void
.end method

.method public final ensureEmpty$com_github_IndiTheo_kadb()V
    .locals 0

    iget-object p0, p0, Lcom/flyfishxu/kadb/core/AdbConnection;->messageQueue:Lcom/flyfishxu/kadb/queue/AdbMessageQueue;

    invoke-virtual {p0}, Lcom/flyfishxu/kadb/queue/MessageQueue;->ensureEmpty()V

    return-void
.end method

.method public final featureSnapshot$com_github_IndiTheo_kadb()Ljava/util/Set;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    iget-object p0, p0, Lcom/flyfishxu/kadb/core/AdbConnection;->supportedFeatures:Ljava/util/Set;

    invoke-static {p0}, Lkotlin/collections/CollectionsKt;->toSet(Ljava/lang/Iterable;)Ljava/util/Set;

    move-result-object p0

    return-object p0
.end method

.method public final open(Ljava/lang/String;)Lcom/flyfishxu/kadb/stream/AdbStream;
    .locals 10

    const-string v0, "destination"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0}, Lcom/flyfishxu/kadb/core/AdbConnection;->newId()I

    move-result v0

    iget-object v1, p0, Lcom/flyfishxu/kadb/core/AdbConnection;->messageQueue:Lcom/flyfishxu/kadb/queue/AdbMessageQueue;

    invoke-virtual {v1, v0}, Lcom/flyfishxu/kadb/queue/MessageQueue;->startListening(I)V

    :try_start_0
    iget-boolean v1, p0, Lcom/flyfishxu/kadb/core/AdbConnection;->delayedAckEnabled:Z

    if-eqz v1, :cond_0

    const/high16 v1, 0x2000000

    goto :goto_0

    :cond_0
    const/4 v1, 0x0

    :goto_0
    iget-object v2, p0, Lcom/flyfishxu/kadb/core/AdbConnection;->adbWriter:Lcom/flyfishxu/kadb/core/AdbWriter;

    invoke-virtual {v2, v0, p1, v1}, Lcom/flyfishxu/kadb/core/AdbWriter;->writeOpen(ILjava/lang/String;I)V

    iget-object p1, p0, Lcom/flyfishxu/kadb/core/AdbConnection;->messageQueue:Lcom/flyfishxu/kadb/queue/AdbMessageQueue;

    const v1, 0x59414b4f

    invoke-virtual {p1, v0, v1}, Lcom/flyfishxu/kadb/queue/MessageQueue;->take(II)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcom/flyfishxu/kadb/core/AdbMessage;

    invoke-virtual {p1}, Lcom/flyfishxu/kadb/core/AdbMessage;->getArg0()I

    move-result v6

    sget-object v1, Lcom/flyfishxu/kadb/core/AdbConnection;->Companion:Lcom/flyfishxu/kadb/core/AdbConnection$Companion;

    iget-boolean v2, p0, Lcom/flyfishxu/kadb/core/AdbConnection;->delayedAckEnabled:Z

    invoke-static {v1, p1, v2}, Lcom/flyfishxu/kadb/core/AdbConnection$Companion;->access$decodeOkayAckBytes(Lcom/flyfishxu/kadb/core/AdbConnection$Companion;Lcom/flyfishxu/kadb/core/AdbMessage;Z)I

    move-result p1

    int-to-long v8, p1

    new-instance p1, Lcom/flyfishxu/kadb/stream/AdbStream;

    iget-object v2, p0, Lcom/flyfishxu/kadb/core/AdbConnection;->messageQueue:Lcom/flyfishxu/kadb/queue/AdbMessageQueue;

    iget-object v3, p0, Lcom/flyfishxu/kadb/core/AdbConnection;->adbWriter:Lcom/flyfishxu/kadb/core/AdbWriter;

    iget v4, p0, Lcom/flyfishxu/kadb/core/AdbConnection;->outboundMaxPayloadSize:I

    iget-boolean v7, p0, Lcom/flyfishxu/kadb/core/AdbConnection;->delayedAckEnabled:Z

    move-object v1, p1

    move v5, v0

    invoke-direct/range {v1 .. v9}, Lcom/flyfishxu/kadb/stream/AdbStream;-><init>(Lcom/flyfishxu/kadb/queue/AdbMessageQueue;Lcom/flyfishxu/kadb/core/AdbWriter;IIIZJ)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    return-object p1

    :catchall_0
    move-exception p1

    iget-object p0, p0, Lcom/flyfishxu/kadb/core/AdbConnection;->messageQueue:Lcom/flyfishxu/kadb/queue/AdbMessageQueue;

    invoke-virtual {p0, v0}, Lcom/flyfishxu/kadb/queue/MessageQueue;->stopListening(I)V

    throw p1
.end method

.method public final supportsFeature(Ljava/lang/String;)Z
    .locals 1

    const-string v0, "feature"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object p0, p0, Lcom/flyfishxu/kadb/core/AdbConnection;->supportedFeatures:Ljava/util/Set;

    invoke-interface {p0, p1}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result p0

    return p0
.end method
