.class public final Lcom/flyfishxu/kadb/Kadb$Companion;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/flyfishxu/kadb/Kadb;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Companion"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000D\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0008\u0003\n\u0002\u0010 \n\u0002\u0010\u000e\n\u0002\u0008\u0008\n\u0002\u0010\u0002\n\u0002\u0008\u0002\n\u0002\u0010\u0008\n\u0002\u0008\u0004\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0002\u0008\u0086\u0003\u0018\u00002\u00020\u0001B\t\u0008\u0002\u00a2\u0006\u0004\u0008\u0002\u0010\u0003J0\u0010\u000e\u001a\u00020\u000f2\u0006\u0010\u0010\u001a\u00020\u00062\u0006\u0010\u0011\u001a\u00020\u00122\u0006\u0010\u0013\u001a\u00020\u00062\u0008\u0008\u0002\u0010\u0014\u001a\u00020\u0006H\u0086@\u00a2\u0006\u0002\u0010\u0015J4\u0010\u0016\u001a\u00020\u00172\u0006\u0010\u0010\u001a\u00020\u00062\u0006\u0010\u0011\u001a\u00020\u00122\u0008\u0008\u0002\u0010\u0018\u001a\u00020\u00122\u0008\u0008\u0002\u0010\u0019\u001a\u00020\u00122\u0008\u0008\u0002\u0010\u001a\u001a\u00020\u001bJ\"\u0010\u001c\u001a\u0004\u0018\u00010\u00172\u0006\u0010\u0010\u001a\u00020\u00062\u0006\u0010\u0011\u001a\u00020\u00122\u0008\u0008\u0002\u0010\u001a\u001a\u00020\u001bJ\"\u0010\u001d\u001a\u00060\u001ej\u0002`\u001f2\u0006\u0010\u0010\u001a\u00020\u00062\u0006\u0010\u0011\u001a\u00020\u00122\u0006\u0010 \u001a\u00020\u0012R\u0014\u0010\u0004\u001a\u0008\u0012\u0004\u0012\u00020\u00060\u0005X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0006X\u0082T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0008\u001a\u00020\u0006X\u0082T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\u0006X\u0082T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u0006X\u0082T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\u0006X\u0082T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000c\u001a\u00020\u0006X\u0082T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\u0006X\u0082T\u00a2\u0006\u0002\n\u0000\u00a8\u0006!"
    }
    d2 = {
        "Lcom/flyfishxu/kadb/Kadb$Companion;",
        "",
        "<init>",
        "()V",
        "OPEN_TRANSPORT_FAILURE_MARKERS",
        "",
        "",
        "SHELL_V2_FEATURE",
        "SHELL_SERVICE_BASE",
        "SHELL_ARG_V2",
        "SHELL_ARG_TERM_PREFIX",
        "SHELL_TYPE_RAW",
        "SHELL_TYPE_PTY",
        "DEFAULT_TERM_TYPE",
        "pair",
        "",
        "host",
        "port",
        "",
        "pairingCode",
        "name",
        "(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;",
        "create",
        "Lcom/flyfishxu/kadb/Kadb;",
        "connectTimeout",
        "socketTimeout",
        "options",
        "Lcom/flyfishxu/kadb/KadbOptions;",
        "tryConnection",
        "tcpForward",
        "Ljava/lang/AutoCloseable;",
        "Lkotlin/AutoCloseable;",
        "targetPort",
        "com.github.IndiTheo:kadb"
    }
    k = 0x1
    mv = {
        0x2,
        0x4,
        0x0
    }
    xi = 0x30
.end annotation

.annotation build Lkotlin/jvm/internal/SourceDebugExtension;
    value = {
        "SMAP\nKadb.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Kadb.kt\ncom/flyfishxu/kadb/Kadb$Companion\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,532:1\n1#2:533\n*E\n"
    }
.end annotation


# direct methods
.method private constructor <init>()V
    .locals 0

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Lcom/flyfishxu/kadb/Kadb$Companion;-><init>()V

    return-void
.end method

.method public static synthetic create$default(Lcom/flyfishxu/kadb/Kadb$Companion;Ljava/lang/String;IIILcom/flyfishxu/kadb/KadbOptions;ILjava/lang/Object;)Lcom/flyfishxu/kadb/Kadb;
    .locals 7

    and-int/lit8 p7, p6, 0x4

    const/4 v0, 0x0

    if-eqz p7, :cond_0

    move v4, v0

    goto :goto_0

    :cond_0
    move v4, p3

    :goto_0
    and-int/lit8 p3, p6, 0x8

    if-eqz p3, :cond_1

    move v5, v0

    goto :goto_1

    :cond_1
    move v5, p4

    :goto_1
    and-int/lit8 p3, p6, 0x10

    if-eqz p3, :cond_2

    new-instance p5, Lcom/flyfishxu/kadb/KadbOptions;

    const/4 p3, 0x1

    const/4 p4, 0x0

    invoke-direct {p5, p4, p3, p4}, Lcom/flyfishxu/kadb/KadbOptions;-><init>(Lcom/flyfishxu/kadb/DelayedAckMode;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    :cond_2
    move-object v6, p5

    move-object v1, p0

    move-object v2, p1

    move v3, p2

    invoke-virtual/range {v1 .. v6}, Lcom/flyfishxu/kadb/Kadb$Companion;->create(Ljava/lang/String;IIILcom/flyfishxu/kadb/KadbOptions;)Lcom/flyfishxu/kadb/Kadb;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic pair$default(Lcom/flyfishxu/kadb/Kadb$Companion;Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Lkotlin/coroutines/Continuation;ILjava/lang/Object;)Ljava/lang/Object;
    .locals 6

    and-int/lit8 p6, p6, 0x8

    if-eqz p6, :cond_0

    const/4 p4, 0x1

    const/4 p6, 0x0

    invoke-static {p6, p4, p6}, Lcom/flyfishxu/kadb/cert/platform/DefaultDeviceName_androidKt;->defaultDeviceName$default(Ljava/lang/String;ILjava/lang/Object;)Ljava/lang/String;

    move-result-object p4

    :cond_0
    move-object v4, p4

    move-object v0, p0

    move-object v1, p1

    move v2, p2

    move-object v3, p3

    move-object v5, p5

    invoke-virtual/range {v0 .. v5}, Lcom/flyfishxu/kadb/Kadb$Companion;->pair(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic tryConnection$default(Lcom/flyfishxu/kadb/Kadb$Companion;Ljava/lang/String;ILcom/flyfishxu/kadb/KadbOptions;ILjava/lang/Object;)Lcom/flyfishxu/kadb/Kadb;
    .locals 0

    and-int/lit8 p4, p4, 0x4

    if-eqz p4, :cond_0

    new-instance p3, Lcom/flyfishxu/kadb/KadbOptions;

    const/4 p4, 0x1

    const/4 p5, 0x0

    invoke-direct {p3, p5, p4, p5}, Lcom/flyfishxu/kadb/KadbOptions;-><init>(Lcom/flyfishxu/kadb/DelayedAckMode;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    :cond_0
    invoke-virtual {p0, p1, p2, p3}, Lcom/flyfishxu/kadb/Kadb$Companion;->tryConnection(Ljava/lang/String;ILcom/flyfishxu/kadb/KadbOptions;)Lcom/flyfishxu/kadb/Kadb;

    move-result-object p0

    return-object p0
.end method


# virtual methods
.method public final create(Ljava/lang/String;IIILcom/flyfishxu/kadb/KadbOptions;)Lcom/flyfishxu/kadb/Kadb;
    .locals 7

    const-string p0, "host"

    invoke-static {p1, p0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string p0, "options"

    invoke-static {p5, p0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance p0, Lcom/flyfishxu/kadb/Kadb;

    const/4 v6, 0x0

    move-object v0, p0

    move-object v1, p1

    move v2, p2

    move v3, p3

    move v4, p4

    move-object v5, p5

    invoke-direct/range {v0 .. v6}, Lcom/flyfishxu/kadb/Kadb;-><init>(Ljava/lang/String;IIILcom/flyfishxu/kadb/KadbOptions;Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    return-object p0
.end method

.method public final pair(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "I",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    invoke-static {}, Lkotlinx/coroutines/Dispatchers;->getDefault()Lkotlinx/coroutines/CoroutineDispatcher;

    move-result-object p0

    new-instance v6, Lcom/flyfishxu/kadb/Kadb$Companion$pair$2;

    const/4 v5, 0x0

    move-object v0, v6

    move-object v1, p1

    move v2, p2

    move-object v3, p3

    move-object v4, p4

    invoke-direct/range {v0 .. v5}, Lcom/flyfishxu/kadb/Kadb$Companion$pair$2;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Lkotlin/coroutines/Continuation;)V

    invoke-static {p0, v6, p5}, Lkotlinx/coroutines/BuildersKt;->withContext(Lkotlin/coroutines/CoroutineContext;Lkotlin/jvm/functions/Function2;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    move-result-object p0

    invoke-static {}, Lkotlin/coroutines/intrinsics/IntrinsicsKt;->getCOROUTINE_SUSPENDED()Ljava/lang/Object;

    move-result-object p1

    if-ne p0, p1, :cond_0

    return-object p0

    :cond_0
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method public final tcpForward(Ljava/lang/String;II)Ljava/lang/AutoCloseable;
    .locals 7

    const-string p0, "host"

    invoke-static {p1, p0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance p0, Lcom/flyfishxu/kadb/Kadb;

    const/16 v5, 0xc

    const/4 v6, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    move-object v0, p0

    move-object v1, p1

    move v2, p2

    invoke-direct/range {v0 .. v6}, Lcom/flyfishxu/kadb/Kadb;-><init>(Ljava/lang/String;IIIILkotlin/jvm/internal/DefaultConstructorMarker;)V

    invoke-virtual {p0, p2, p3}, Lcom/flyfishxu/kadb/Kadb;->tcpForward(II)Ljava/lang/AutoCloseable;

    move-result-object p0

    return-object p0
.end method

.method public final tryConnection(Ljava/lang/String;ILcom/flyfishxu/kadb/KadbOptions;)Lcom/flyfishxu/kadb/Kadb;
    .locals 10

    const-string v0, "host"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "options"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v0, 0x0

    :try_start_0
    sget-object v1, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    const/16 v8, 0xc

    const/4 v9, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    move-object v2, p0

    move-object v3, p1

    move v4, p2

    move-object v7, p3

    invoke-static/range {v2 .. v9}, Lcom/flyfishxu/kadb/Kadb$Companion;->create$default(Lcom/flyfishxu/kadb/Kadb$Companion;Ljava/lang/String;IIILcom/flyfishxu/kadb/KadbOptions;ILjava/lang/Object;)Lcom/flyfishxu/kadb/Kadb;

    move-result-object p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    :try_start_1
    const-string p1, "echo success"

    invoke-virtual {p0, p1}, Lcom/flyfishxu/kadb/Kadb;->shell(Ljava/lang/String;)Lcom/flyfishxu/kadb/shell/AdbShellResponse;

    move-result-object p1

    invoke-virtual {p1}, Lcom/flyfishxu/kadb/shell/AdbShellResponse;->getAllOutput()Ljava/lang/String;

    move-result-object p1

    const-string p2, "success\n"

    invoke-static {p1, p2}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    invoke-static {p1}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception p1

    :try_start_2
    sget-object p2, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    invoke-static {p1}, Lkotlin/ResultKt;->createFailure(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object p1

    invoke-static {p1}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    :goto_0
    invoke-static {p1}, Lkotlin/Result;->exceptionOrNull-impl(Ljava/lang/Object;)Ljava/lang/Throwable;

    move-result-object p2

    if-nez p2, :cond_1

    check-cast p1, Ljava/lang/Boolean;

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    if-eqz p1, :cond_0

    goto :goto_1

    :cond_0
    invoke-virtual {p0}, Lcom/flyfishxu/kadb/Kadb;->close()V

    move-object p0, v0

    :goto_1
    invoke-static {p0}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    goto :goto_3

    :catchall_1
    move-exception p0

    goto :goto_2

    :cond_1
    invoke-virtual {p0}, Lcom/flyfishxu/kadb/Kadb;->close()V

    throw p2
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    :goto_2
    sget-object p1, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    invoke-static {p0}, Lkotlin/ResultKt;->createFailure(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object p0

    invoke-static {p0}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    :goto_3
    invoke-static {p0}, Lkotlin/Result;->isFailure-impl(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_2

    goto :goto_4

    :cond_2
    move-object v0, p0

    :goto_4
    check-cast v0, Lcom/flyfishxu/kadb/Kadb;

    return-object v0
.end method
