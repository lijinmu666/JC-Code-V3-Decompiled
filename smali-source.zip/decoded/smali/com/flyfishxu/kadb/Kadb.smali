.class public final Lcom/flyfishxu/kadb/Kadb;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/AutoCloseable;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/flyfishxu/kadb/Kadb$Companion;,
        Lcom/flyfishxu/kadb/Kadb$InstallSessionMode;,
        Lcom/flyfishxu/kadb/Kadb$WhenMappings;
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u00a0\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u0008\n\u0002\u0008\u0005\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0004\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0010\t\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0010\u0011\n\u0002\u0008\u0008\n\u0002\u0010 \n\u0002\u0008\u0011\n\u0002\u0010\u0003\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0008#\u0018\u0000 t2\u00060\u0001j\u0002`\u0002:\u0002stB+\u0012\u0006\u0010\u0003\u001a\u00020\u0004\u0012\u0006\u0010\u0005\u001a\u00020\u0006\u0012\u0008\u0008\u0002\u0010\u0007\u001a\u00020\u0006\u0012\u0008\u0008\u0002\u0010\u0008\u001a\u00020\u0006\u00a2\u0006\u0004\u0008\t\u0010\nB1\u0008\u0012\u0012\u0006\u0010\u0003\u001a\u00020\u0004\u0012\u0006\u0010\u0005\u001a\u00020\u0006\u0012\u0006\u0010\u0007\u001a\u00020\u0006\u0012\u0006\u0010\u0008\u001a\u00020\u0006\u0012\u0006\u0010\u000b\u001a\u00020\u000c\u00a2\u0006\u0004\u0008\t\u0010\rJ\u0006\u0010\u0012\u001a\u00020\u0013J\u000e\u0010\u0014\u001a\u00020\u00152\u0006\u0010\u0016\u001a\u00020\u0004J\u000e\u0010\u0017\u001a\u00020\u00132\u0006\u0010\u0018\u001a\u00020\u0004J\u000e\u0010\u0019\u001a\u00020\u001a2\u0006\u0010\u001b\u001a\u00020\u0004J\u0010\u0010\u001c\u001a\u00020\u001d2\u0008\u0008\u0002\u0010\u001b\u001a\u00020\u0004J\u001a\u0010\u001e\u001a\u00020\u001f2\u0008\u0008\u0002\u0010\u001b\u001a\u00020\u00042\u0008\u0008\u0002\u0010 \u001a\u00020\u0004J*\u0010!\u001a\u00020\"2\u0006\u0010#\u001a\u00020$2\u0006\u0010%\u001a\u00020\u00042\u0008\u0008\u0002\u0010&\u001a\u00020\u00062\u0008\u0008\u0002\u0010\'\u001a\u00020(J&\u0010!\u001a\u00020\"2\u0006\u0010)\u001a\u00020*2\u0006\u0010%\u001a\u00020\u00042\u0006\u0010&\u001a\u00020\u00062\u0006\u0010\'\u001a\u00020(J\u0016\u0010+\u001a\u00020\"2\u0006\u0010,\u001a\u00020$2\u0006\u0010%\u001a\u00020\u0004J\u0016\u0010+\u001a\u00020\"2\u0006\u0010-\u001a\u00020.2\u0006\u0010%\u001a\u00020\u0004J\u0006\u0010/\u001a\u000200J\'\u00101\u001a\u00020\"2\u0006\u00102\u001a\u00020$2\u0012\u0010\u000b\u001a\n\u0012\u0006\u0008\u0001\u0012\u00020\u000403\"\u00020\u0004\u00a2\u0006\u0002\u00104J/\u00101\u001a\u00020\"2\u0006\u0010)\u001a\u00020*2\u0006\u00105\u001a\u00020(2\u0012\u0010\u000b\u001a\n\u0012\u0006\u0008\u0001\u0012\u00020\u000403\"\u00020\u0004\u00a2\u0006\u0002\u00106J)\u00107\u001a\u00020\"2\u0006\u0010%\u001a\u00020\u00042\u0012\u0010\u000b\u001a\n\u0012\u0006\u0008\u0001\u0012\u00020\u000403\"\u00020\u0004H\u0002\u00a2\u0006\u0002\u00108J)\u00109\u001a\u00020\"2\u0006\u00102\u001a\u00020$2\u0012\u0010\u000b\u001a\n\u0012\u0006\u0008\u0001\u0012\u00020\u000403\"\u00020\u0004H\u0002\u00a2\u0006\u0002\u00104J-\u0010:\u001a\u00020\"2\u000c\u0010;\u001a\u0008\u0012\u0004\u0012\u00020$0<2\u0012\u0010\u000b\u001a\n\u0012\u0006\u0008\u0001\u0012\u00020\u000403\"\u00020\u0004\u00a2\u0006\u0002\u0010=J\u000e\u0010>\u001a\u00020\"2\u0006\u0010?\u001a\u00020\u0004J\u001f\u0010@\u001a\u00020\u00152\u0012\u0010\u001b\u001a\n\u0012\u0006\u0008\u0001\u0012\u00020\u000403\"\u00020\u0004\u00a2\u0006\u0002\u0010AJ\u001f\u0010B\u001a\u00020\u00152\u0012\u0010\u001b\u001a\n\u0012\u0006\u0008\u0001\u0012\u00020\u000403\"\u00020\u0004\u00a2\u0006\u0002\u0010AJ\u0006\u0010C\u001a\u00020\u0004J\u0006\u0010D\u001a\u00020\u0004J\u0008\u0010E\u001a\u00020\"H\u0016J\u0006\u0010F\u001a\u00020\"J\u0008\u0010\u000e\u001a\u00020\u0010H\u0002J\u0014\u0010G\u001a\u000e\u0012\u0004\u0012\u00020\u0010\u0012\u0004\u0012\u00020\u00110\u000fH\u0002J&\u0010H\u001a\u000e\u0012\u0004\u0012\u00020\u0010\u0012\u0004\u0012\u00020\u00150\u000f2\u0006\u0010\u0016\u001a\u00020\u00042\u0008\u0008\u0002\u0010I\u001a\u00020\u0013H\u0002J\u0010\u0010J\u001a\u00020\"2\u0006\u0010K\u001a\u00020\u0010H\u0002J\u0010\u0010L\u001a\u00020\u00132\u0006\u0010M\u001a\u00020NH\u0002J\u0010\u0010O\u001a\u00020\u00042\u0006\u0010P\u001a\u00020\u0004H\u0002J\u0008\u0010Q\u001a\u00020RH\u0002J&\u0010S\u001a\u00020\u00042\u0006\u0010T\u001a\u00020(2\u000c\u0010U\u001a\u0008\u0012\u0004\u0012\u00020\u00040<2\u0006\u0010V\u001a\u00020RH\u0002J \u0010W\u001a\u00020\u00042\u0006\u0010X\u001a\u00020$2\u0006\u0010Y\u001a\u00020\u00042\u0006\u0010V\u001a\u00020RH\u0002J)\u0010Z\u001a\u00020\u00152\u0006\u0010V\u001a\u00020R2\u0012\u0010\u001b\u001a\n\u0012\u0006\u0008\u0001\u0012\u00020\u000403\"\u00020\u0004H\u0002\u00a2\u0006\u0002\u0010[J \u0010\\\u001a\u00020\u00042\u0006\u0010X\u001a\u00020$2\u0006\u0010Y\u001a\u00020\u00042\u0006\u0010]\u001a\u00020\u0006H\u0002J\u0010\u0010^\u001a\u00020\"2\u0006\u0010%\u001a\u00020\u0004H\u0002J\"\u0010_\u001a\u00020\"2\u0006\u0010Y\u001a\u00020\u00042\u0008\u0010M\u001a\u0004\u0018\u00010\u00042\u0006\u0010V\u001a\u00020RH\u0002J#\u0010`\u001a\u0008\u0012\u0004\u0012\u00020\u00040<2\u000e\u0010\u000b\u001a\n\u0012\u0006\u0008\u0001\u0012\u00020\u000403H\u0002\u00a2\u0006\u0002\u0010aJ\u0016\u0010b\u001a\u00020\u00042\u000c\u0010c\u001a\u0008\u0012\u0004\u0012\u00020\u00040<H\u0002J\u0016\u0010d\u001a\u00020\u00042\u000c\u0010c\u001a\u0008\u0012\u0004\u0012\u00020\u00040<H\u0002J\u0010\u0010e\u001a\u00020\u00042\u0006\u0010%\u001a\u00020\u0004H\u0002J\u0010\u0010f\u001a\u00020\u00042\u0006\u0010g\u001a\u00020\u0004H\u0002J\u0010\u0010h\u001a\u00020\"2\u0006\u0010i\u001a\u00020\u0004H\u0002J\u0010\u0010j\u001a\u00020\"2\u0006\u0010k\u001a\u00020\u0004H\u0002J0\u0010l\u001a\u00020\u00042\u0006\u0010\u001b\u001a\u00020\u00042\u0006\u0010m\u001a\u00020\u00132\n\u0008\u0002\u0010 \u001a\u0004\u0018\u00010\u00042\n\u0008\u0002\u0010n\u001a\u0004\u0018\u00010\u0004H\u0002J\u001a\u0010o\u001a\u00060\u0001j\u0002`\u00022\u0006\u0010p\u001a\u00020\u00062\u0006\u0010q\u001a\u00020\u0006J\u0010\u0010r\u001a\u00020\u00042\u0006\u0010\u0016\u001a\u00020\u0004H\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0006X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0006X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0008\u001a\u00020\u0006X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\u000cX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u001c\u0010\u000e\u001a\u0010\u0012\u0004\u0012\u00020\u0010\u0012\u0004\u0012\u00020\u0011\u0018\u00010\u000fX\u0082\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u0006u"
    }
    d2 = {
        "Lcom/flyfishxu/kadb/Kadb;",
        "Ljava/lang/AutoCloseable;",
        "Lkotlin/AutoCloseable;",
        "host",
        "",
        "port",
        "",
        "connectTimeout",
        "socketTimeout",
        "<init>",
        "(Ljava/lang/String;III)V",
        "options",
        "Lcom/flyfishxu/kadb/KadbOptions;",
        "(Ljava/lang/String;IIILcom/flyfishxu/kadb/KadbOptions;)V",
        "connection",
        "Lkotlin/Pair;",
        "Lcom/flyfishxu/kadb/core/AdbConnection;",
        "Lcom/flyfishxu/kadb/transport/TransportChannel;",
        "connectionCheck",
        "",
        "open",
        "Lcom/flyfishxu/kadb/stream/AdbStream;",
        "destination",
        "supportsFeature",
        "feature",
        "shell",
        "Lcom/flyfishxu/kadb/shell/AdbShellResponse;",
        "command",
        "openShell",
        "Lcom/flyfishxu/kadb/shell/AdbShellStream;",
        "openPtyShellSession",
        "Lcom/flyfishxu/kadb/shell/AdbPtyShellSession;",
        "term",
        "push",
        "",
        "src",
        "Ljava/io/File;",
        "remotePath",
        "mode",
        "lastModifiedMs",
        "",
        "source",
        "Lokio/Source;",
        "pull",
        "dst",
        "sink",
        "Lokio/Sink;",
        "openSync",
        "Lcom/flyfishxu/kadb/stream/AdbSyncStream;",
        "install",
        "file",
        "",
        "(Ljava/io/File;[Ljava/lang/String;)V",
        "size",
        "(Lokio/Source;J[Ljava/lang/String;)V",
        "pmInstallRemote",
        "(Ljava/lang/String;[Ljava/lang/String;)V",
        "pmInstall",
        "installMultiple",
        "apks",
        "",
        "(Ljava/util/List;[Ljava/lang/String;)V",
        "uninstall",
        "packageName",
        "execCmd",
        "([Ljava/lang/String;)Lcom/flyfishxu/kadb/stream/AdbStream;",
        "abbExec",
        "root",
        "unroot",
        "close",
        "resetConnection",
        "newConnection",
        "openStream",
        "retryOnStaleTransport",
        "discardConnection",
        "failedConnection",
        "isRecoverableTransportOpenFailure",
        "error",
        "",
        "extractSessionId",
        "response",
        "installSessionMode",
        "Lcom/flyfishxu/kadb/Kadb$InstallSessionMode;",
        "createInstallSession",
        "totalLength",
        "installOptions",
        "sessionMode",
        "streamInstallWrite",
        "apk",
        "sessionId",
        "openInstallCommand",
        "(Lcom/flyfishxu/kadb/Kadb$InstallSessionMode;[Ljava/lang/String;)Lcom/flyfishxu/kadb/stream/AdbStream;",
        "pushAndWrite",
        "index",
        "cleanupRemoteTempFile",
        "finalizeSession",
        "nonBlankOptions",
        "([Ljava/lang/String;)Ljava/util/List;",
        "buildShellCommand",
        "parts",
        "buildExecCmdService",
        "buildDeleteDeviceFileCommand",
        "escapeArg",
        "arg",
        "enforceLegacyShellServiceLength",
        "service",
        "requireShellV2",
        "apiName",
        "buildShellService",
        "useShellProtocol",
        "typeArg",
        "tcpForward",
        "hostPort",
        "targetPort",
        "restartAdb",
        "InstallSessionMode",
        "Companion",
        "com.github.IndiTheo:kadb"
    }
    k = 0x1
    mv = {
        0x2,
        0x4,
        0x0
    }
    xi = 0x30
.end annotation

.annotation build Lkotlin/jvm/internal/SourceDebugExtension;
    value = {
        "SMAP\nKadb.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Kadb.kt\ncom/flyfishxu/kadb/Kadb\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n+ 4 ArraysJVM.kt\nkotlin/collections/ArraysKt__ArraysJVMKt\n+ 5 _Arrays.kt\nkotlin/collections/ArraysKt___ArraysKt\n*L\n1#1,532:1\n1#2:533\n1#2:538\n1759#3:534\n1770#3:535\n2077#3,2:536\n2079#3:539\n1771#3:540\n1960#3,3:541\n777#3:549\n873#3,2:550\n777#3:552\n873#3,2:553\n37#4,2:544\n3938#5:546\n4474#5,2:547\n*S KotlinDebug\n*F\n+ 1 Kadb.kt\ncom/flyfishxu/kadb/Kadb\n*L\n168#1:538\n168#1:534\n168#1:535\n168#1:536,2\n168#1:539\n168#1:540\n265#1:541,3\n389#1:549\n389#1:550,2\n394#1:552\n394#1:553,2\n295#1:544,2\n386#1:546\n386#1:547,2\n*E\n"
    }
.end annotation


# static fields
.field public static final Companion:Lcom/flyfishxu/kadb/Kadb$Companion;

.field private static final DEFAULT_TERM_TYPE:Ljava/lang/String; = "xterm-256color"

.field private static final OPEN_TRANSPORT_FAILURE_MARKERS:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private static final SHELL_ARG_TERM_PREFIX:Ljava/lang/String; = "TERM="

.field private static final SHELL_ARG_V2:Ljava/lang/String; = "v2"

.field private static final SHELL_SERVICE_BASE:Ljava/lang/String; = "shell"

.field private static final SHELL_TYPE_PTY:Ljava/lang/String; = "pty"

.field private static final SHELL_TYPE_RAW:Ljava/lang/String; = "raw"

.field private static final SHELL_V2_FEATURE:Ljava/lang/String; = "shell_v2"


# instance fields
.field private final connectTimeout:I

.field private connection:Lkotlin/Pair;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/Pair<",
            "Lcom/flyfishxu/kadb/core/AdbConnection;",
            "+",
            "Lcom/flyfishxu/kadb/transport/TransportChannel;",
            ">;"
        }
    .end annotation
.end field

.field private final host:Ljava/lang/String;

.field private options:Lcom/flyfishxu/kadb/KadbOptions;

.field private final port:I

.field private final socketTimeout:I


# direct methods
.method static constructor <clinit>()V
    .locals 12

    new-instance v0, Lcom/flyfishxu/kadb/Kadb$Companion;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lcom/flyfishxu/kadb/Kadb$Companion;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    sput-object v0, Lcom/flyfishxu/kadb/Kadb;->Companion:Lcom/flyfishxu/kadb/Kadb$Companion;

    const-string v10, "disconnected"

    const-string v11, "connection closed"

    const-string v2, "broken pipe"

    const-string v3, "connection reset"

    const-string v4, "connection aborted"

    const-string v5, "socket closed"

    const-string v6, "stream closed"

    const-string v7, "transport closed"

    const-string v8, "closed"

    const-string v9, "eof"

    filled-new-array/range {v2 .. v11}, [Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    sput-object v0, Lcom/flyfishxu/kadb/Kadb;->OPEN_TRANSPORT_FAILURE_MARKERS:Ljava/util/List;

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;III)V
    .locals 1

    const-string v0, "host"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    iput-object p1, p0, Lcom/flyfishxu/kadb/Kadb;->host:Ljava/lang/String;

    .line 4
    iput p2, p0, Lcom/flyfishxu/kadb/Kadb;->port:I

    .line 5
    iput p3, p0, Lcom/flyfishxu/kadb/Kadb;->connectTimeout:I

    .line 6
    iput p4, p0, Lcom/flyfishxu/kadb/Kadb;->socketTimeout:I

    .line 7
    new-instance p1, Lcom/flyfishxu/kadb/KadbOptions;

    const/4 p2, 0x0

    const/4 p3, 0x1

    invoke-direct {p1, p2, p3, p2}, Lcom/flyfishxu/kadb/KadbOptions;-><init>(Lcom/flyfishxu/kadb/DelayedAckMode;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    iput-object p1, p0, Lcom/flyfishxu/kadb/Kadb;->options:Lcom/flyfishxu/kadb/KadbOptions;

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/String;IIIILkotlin/jvm/internal/DefaultConstructorMarker;)V
    .locals 1

    and-int/lit8 p6, p5, 0x4

    const/4 v0, 0x0

    if-eqz p6, :cond_0

    move p3, v0

    :cond_0
    and-int/lit8 p5, p5, 0x8

    if-eqz p5, :cond_1

    move p4, v0

    .line 8
    :cond_1
    invoke-direct {p0, p1, p2, p3, p4}, Lcom/flyfishxu/kadb/Kadb;-><init>(Ljava/lang/String;III)V

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;IIILcom/flyfishxu/kadb/KadbOptions;)V
    .locals 0

    .line 9
    invoke-direct {p0, p1, p2, p3, p4}, Lcom/flyfishxu/kadb/Kadb;-><init>(Ljava/lang/String;III)V

    .line 10
    iput-object p5, p0, Lcom/flyfishxu/kadb/Kadb;->options:Lcom/flyfishxu/kadb/KadbOptions;

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/String;IIILcom/flyfishxu/kadb/KadbOptions;Lkotlin/jvm/internal/DefaultConstructorMarker;)V
    .locals 0

    .line 1
    invoke-direct/range {p0 .. p5}, Lcom/flyfishxu/kadb/Kadb;-><init>(Ljava/lang/String;IIILcom/flyfishxu/kadb/KadbOptions;)V

    return-void
.end method

.method public static synthetic KLFTb(Lcom/flyfishxu/kadb/Kadb;Ljava/lang/String;)Ljava/lang/CharSequence;
    .locals 0

    invoke-static {p0, p1}, Lcom/flyfishxu/kadb/Kadb;->buildExecCmdService$lambda$1(Lcom/flyfishxu/kadb/Kadb;Ljava/lang/String;)Ljava/lang/CharSequence;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic ZfxDd(Lcom/flyfishxu/kadb/Kadb;Ljava/lang/String;)Ljava/lang/CharSequence;
    .locals 0

    invoke-static {p0, p1}, Lcom/flyfishxu/kadb/Kadb;->buildShellCommand$lambda$1(Lcom/flyfishxu/kadb/Kadb;Ljava/lang/String;)Ljava/lang/CharSequence;

    move-result-object p0

    return-object p0
.end method

.method public static final synthetic access$getConnectTimeout$p(Lcom/flyfishxu/kadb/Kadb;)I
    .locals 0

    iget p0, p0, Lcom/flyfishxu/kadb/Kadb;->connectTimeout:I

    return p0
.end method

.method public static final synthetic access$getHost$p(Lcom/flyfishxu/kadb/Kadb;)Ljava/lang/String;
    .locals 0

    iget-object p0, p0, Lcom/flyfishxu/kadb/Kadb;->host:Ljava/lang/String;

    return-object p0
.end method

.method public static final synthetic access$getOptions$p(Lcom/flyfishxu/kadb/Kadb;)Lcom/flyfishxu/kadb/KadbOptions;
    .locals 0

    iget-object p0, p0, Lcom/flyfishxu/kadb/Kadb;->options:Lcom/flyfishxu/kadb/KadbOptions;

    return-object p0
.end method

.method public static final synthetic access$getPort$p(Lcom/flyfishxu/kadb/Kadb;)I
    .locals 0

    iget p0, p0, Lcom/flyfishxu/kadb/Kadb;->port:I

    return p0
.end method

.method public static final synthetic access$getSocketTimeout$p(Lcom/flyfishxu/kadb/Kadb;)I
    .locals 0

    iget p0, p0, Lcom/flyfishxu/kadb/Kadb;->socketTimeout:I

    return p0
.end method

.method private final buildDeleteDeviceFileCommand(Ljava/lang/String;)Ljava/lang/String;
    .locals 1

    invoke-direct {p0, p1}, Lcom/flyfishxu/kadb/Kadb;->escapeArg(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v0, "rm "

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p0, " </dev/null"

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method private final buildExecCmdService(Ljava/util/List;)Ljava/lang/String;
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)",
            "Ljava/lang/String;"
        }
    .end annotation

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :cond_0
    :goto_0
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    move-object v2, v1

    check-cast v2, Ljava/lang/String;

    invoke-static {v2}, Lkotlin/text/StringsKt;->isBlank(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_0

    invoke-interface {v0, v1}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_1
    new-instance v6, Lo/C0;

    invoke-direct {v6, p0}, Lo/C0;-><init>(Lcom/flyfishxu/kadb/Kadb;)V

    const/16 v7, 0x1e

    const/4 v8, 0x0

    const-string v1, " "

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-static/range {v0 .. v8}, Lkotlin/collections/CollectionsKt;->joinToString$default(Ljava/lang/Iterable;Ljava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/CharSequence;ILjava/lang/CharSequence;Lkotlin/jvm/functions/Function1;ILjava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    invoke-interface {p0}, Ljava/lang/CharSequence;->length()I

    move-result p1

    if-nez p1, :cond_2

    const-string p0, "exec:cmd"

    goto :goto_1

    :cond_2
    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v0, "exec:cmd "

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    :goto_1
    return-object p0
.end method

.method private static final buildExecCmdService$lambda$1(Lcom/flyfishxu/kadb/Kadb;Ljava/lang/String;)Ljava/lang/CharSequence;
    .locals 1

    const-string v0, "it"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0, p1}, Lcom/flyfishxu/kadb/Kadb;->escapeArg(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method private final buildShellCommand(Ljava/util/List;)Ljava/lang/String;
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)",
            "Ljava/lang/String;"
        }
    .end annotation

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :cond_0
    :goto_0
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    move-object v2, v1

    check-cast v2, Ljava/lang/String;

    invoke-static {v2}, Lkotlin/text/StringsKt;->isBlank(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_0

    invoke-interface {v0, v1}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_1
    new-instance v6, Lo/D0;

    invoke-direct {v6, p0}, Lo/D0;-><init>(Lcom/flyfishxu/kadb/Kadb;)V

    const/16 v7, 0x1e

    const/4 v8, 0x0

    const-string v1, " "

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-static/range {v0 .. v8}, Lkotlin/collections/CollectionsKt;->joinToString$default(Ljava/lang/Iterable;Ljava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/CharSequence;ILjava/lang/CharSequence;Lkotlin/jvm/functions/Function1;ILjava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method private static final buildShellCommand$lambda$1(Lcom/flyfishxu/kadb/Kadb;Ljava/lang/String;)Ljava/lang/CharSequence;
    .locals 1

    const-string v0, "it"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0, p1}, Lcom/flyfishxu/kadb/Kadb;->escapeArg(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method private final buildShellService(Ljava/lang/String;ZLjava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .locals 9

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    if-eqz p2, :cond_1

    const-string p0, "v2"

    invoke-interface {v0, p0}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    if-eqz p3, :cond_1

    invoke-static {p3}, Lkotlin/text/StringsKt;->isBlank(Ljava/lang/CharSequence;)Z

    move-result p0

    if-eqz p0, :cond_0

    goto :goto_0

    :cond_0
    new-instance p0, Ljava/lang/StringBuilder;

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    const-string p2, "TERM="

    invoke-virtual {p0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-interface {v0, p0}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    :cond_1
    :goto_0
    if-eqz p4, :cond_3

    invoke-static {p4}, Lkotlin/text/StringsKt;->isBlank(Ljava/lang/CharSequence;)Z

    move-result p0

    if-eqz p0, :cond_2

    goto :goto_1

    :cond_2
    invoke-interface {v0, p4}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    :cond_3
    :goto_1
    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    move-result p0

    if-eqz p0, :cond_4

    const-string p0, "shell"

    goto :goto_2

    :cond_4
    const/16 v7, 0x3e

    const/4 v8, 0x0

    const-string v1, ","

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-static/range {v0 .. v8}, Lkotlin/collections/CollectionsKt;->joinToString$default(Ljava/lang/Iterable;Ljava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/CharSequence;ILjava/lang/CharSequence;Lkotlin/jvm/functions/Function1;ILjava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    new-instance p2, Ljava/lang/StringBuilder;

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const-string p3, "shell,"

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    :goto_2
    new-instance p2, Ljava/lang/StringBuilder;

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p0, ":"

    invoke-virtual {p2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic buildShellService$default(Lcom/flyfishxu/kadb/Kadb;Ljava/lang/String;ZLjava/lang/String;Ljava/lang/String;ILjava/lang/Object;)Ljava/lang/String;
    .locals 1

    and-int/lit8 p6, p5, 0x4

    const/4 v0, 0x0

    if-eqz p6, :cond_0

    move-object p3, v0

    :cond_0
    and-int/lit8 p5, p5, 0x8

    if-eqz p5, :cond_1

    move-object p4, v0

    :cond_1
    invoke-direct {p0, p1, p2, p3, p4}, Lcom/flyfishxu/kadb/Kadb;->buildShellService(Ljava/lang/String;ZLjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method private final cleanupRemoteTempFile(Ljava/lang/String;)V
    .locals 1

    :try_start_0
    sget-object v0, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    invoke-direct {p0, p1}, Lcom/flyfishxu/kadb/Kadb;->buildDeleteDeviceFileCommand(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Lcom/flyfishxu/kadb/Kadb;->shell(Ljava/lang/String;)Lcom/flyfishxu/kadb/shell/AdbShellResponse;

    move-result-object p0

    invoke-static {p0}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception p0

    sget-object p1, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    invoke-static {p0}, Lkotlin/ResultKt;->createFailure(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object p0

    invoke-static {p0}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    :goto_0
    return-void
.end method

.method private final connection()Lcom/flyfishxu/kadb/core/AdbConnection;
    .locals 2

    iget-object v0, p0, Lcom/flyfishxu/kadb/Kadb;->connection:Lkotlin/Pair;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Lkotlin/Pair;->getSecond()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/flyfishxu/kadb/transport/TransportChannel;

    invoke-interface {v1}, Lcom/flyfishxu/kadb/transport/TransportChannel;->isOpen()Z

    move-result v1

    if-nez v1, :cond_0

    goto :goto_0

    :cond_0
    invoke-virtual {v0}, Lkotlin/Pair;->getFirst()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lcom/flyfishxu/kadb/core/AdbConnection;

    goto :goto_1

    :cond_1
    :goto_0
    invoke-direct {p0}, Lcom/flyfishxu/kadb/Kadb;->newConnection()Lkotlin/Pair;

    move-result-object v0

    iput-object v0, p0, Lcom/flyfishxu/kadb/Kadb;->connection:Lkotlin/Pair;

    invoke-virtual {v0}, Lkotlin/Pair;->getFirst()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lcom/flyfishxu/kadb/core/AdbConnection;

    :goto_1
    return-object p0
.end method

.method private final createInstallSession(JLjava/util/List;Lcom/flyfishxu/kadb/Kadb$InstallSessionMode;)Ljava/lang/String;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(J",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;",
            "Lcom/flyfishxu/kadb/Kadb$InstallSessionMode;",
            ")",
            "Ljava/lang/String;"
        }
    .end annotation

    sget-object v0, Lcom/flyfishxu/kadb/Kadb$WhenMappings;->$EnumSwitchMapping$0:[I

    invoke-virtual {p4}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    aget v0, v0, v1

    const/4 v1, 0x1

    const-string v2, "-S"

    const-string v3, "install-create"

    if-eq v0, v1, :cond_1

    const/4 v1, 0x2

    if-eq v0, v1, :cond_1

    const/4 p4, 0x3

    if-ne v0, p4, :cond_0

    const-string p4, "pm"

    invoke-static {p1, p2}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object p1

    filled-new-array {p4, v3, v2, p1}, [Ljava/lang/String;

    move-result-object p1

    invoke-static {p1}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object p1

    invoke-static {p1, p3}, Lkotlin/collections/CollectionsKt;->plus(Ljava/util/Collection;Ljava/lang/Iterable;)Ljava/util/List;

    move-result-object p1

    invoke-direct {p0, p1}, Lcom/flyfishxu/kadb/Kadb;->buildShellCommand(Ljava/util/List;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Lcom/flyfishxu/kadb/Kadb;->shell(Ljava/lang/String;)Lcom/flyfishxu/kadb/shell/AdbShellResponse;

    move-result-object p1

    invoke-virtual {p1}, Lcom/flyfishxu/kadb/shell/AdbShellResponse;->getAllOutput()Ljava/lang/String;

    move-result-object p1

    goto :goto_0

    :cond_0
    new-instance p0, Lkotlin/NoWhenBranchMatchedException;

    invoke-direct {p0}, Lkotlin/NoWhenBranchMatchedException;-><init>()V

    throw p0

    :cond_1
    new-instance v0, Lkotlin/jvm/internal/SpreadBuilder;

    const/4 v1, 0x5

    invoke-direct {v0, v1}, Lkotlin/jvm/internal/SpreadBuilder;-><init>(I)V

    const-string v1, "package"

    invoke-virtual {v0, v1}, Lkotlin/jvm/internal/SpreadBuilder;->add(Ljava/lang/Object;)V

    invoke-virtual {v0, v3}, Lkotlin/jvm/internal/SpreadBuilder;->add(Ljava/lang/Object;)V

    invoke-virtual {v0, v2}, Lkotlin/jvm/internal/SpreadBuilder;->add(Ljava/lang/Object;)V

    invoke-static {p1, p2}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Lkotlin/jvm/internal/SpreadBuilder;->add(Ljava/lang/Object;)V

    const/4 p1, 0x0

    new-array p1, p1, [Ljava/lang/String;

    invoke-interface {p3, p1}, Ljava/util/Collection;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object p1

    invoke-virtual {v0, p1}, Lkotlin/jvm/internal/SpreadBuilder;->addSpread(Ljava/lang/Object;)V

    invoke-virtual {v0}, Lkotlin/jvm/internal/SpreadBuilder;->size()I

    move-result p1

    new-array p1, p1, [Ljava/lang/String;

    invoke-virtual {v0, p1}, Lkotlin/jvm/internal/SpreadBuilder;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object p1

    check-cast p1, [Ljava/lang/String;

    invoke-direct {p0, p4, p1}, Lcom/flyfishxu/kadb/Kadb;->openInstallCommand(Lcom/flyfishxu/kadb/Kadb$InstallSessionMode;[Ljava/lang/String;)Lcom/flyfishxu/kadb/stream/AdbStream;

    move-result-object p1

    :try_start_0
    invoke-virtual {p1}, Lcom/flyfishxu/kadb/stream/AdbStream;->getSource()Lokio/BufferedSource;

    move-result-object p2

    invoke-interface {p2}, Lokio/BufferedSource;->readUtf8()Ljava/lang/String;

    move-result-object p2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 p3, 0x0

    invoke-static {p1, p3}, Lkotlin/jdk7/AutoCloseableKt;->closeFinally(Ljava/lang/AutoCloseable;Ljava/lang/Throwable;)V

    move-object p1, p2

    :goto_0
    invoke-direct {p0, p1}, Lcom/flyfishxu/kadb/Kadb;->extractSessionId(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0

    :catchall_0
    move-exception p0

    :try_start_1
    throw p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    :catchall_1
    move-exception p2

    invoke-static {p1, p0}, Lkotlin/jdk7/AutoCloseableKt;->closeFinally(Ljava/lang/AutoCloseable;Ljava/lang/Throwable;)V

    throw p2
.end method

.method private final discardConnection(Lcom/flyfishxu/kadb/core/AdbConnection;)V
    .locals 1

    iget-object v0, p0, Lcom/flyfishxu/kadb/Kadb;->connection:Lkotlin/Pair;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Lkotlin/Pair;->getFirst()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/flyfishxu/kadb/core/AdbConnection;

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    if-ne v0, p1, :cond_1

    invoke-virtual {p0}, Lcom/flyfishxu/kadb/Kadb;->resetConnection()V

    goto :goto_2

    :cond_1
    :try_start_0
    sget-object p0, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    invoke-virtual {p1}, Lcom/flyfishxu/kadb/core/AdbConnection;->close()V

    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    invoke-static {p0}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_1

    :catchall_0
    move-exception p0

    sget-object p1, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    invoke-static {p0}, Lkotlin/ResultKt;->createFailure(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object p0

    invoke-static {p0}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    :goto_1
    invoke-static {p0}, Lkotlin/Result;->box-impl(Ljava/lang/Object;)Lkotlin/Result;

    :goto_2
    return-void
.end method

.method private final enforceLegacyShellServiceLength(Ljava/lang/String;)V
    .locals 0

    invoke-static {p1}, Lkotlin/text/StringsKt;->encodeToByteArray(Ljava/lang/String;)[B

    move-result-object p0

    array-length p0, p0

    const/16 p1, 0x1000

    if-gt p0, p1, :cond_0

    return-void

    :cond_0
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string p1, "error: shell command too long"

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method private final escapeArg(Ljava/lang/String;)Ljava/lang/String;
    .locals 6

    const/4 v4, 0x4

    const/4 v5, 0x0

    const-string v1, "\'"

    const-string v2, "\'\\\'\'"

    const/4 v3, 0x0

    move-object v0, p1

    invoke-static/range {v0 .. v5}, Lkotlin/text/StringsKt;->replace$default(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v0, "\'"

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method private final extractSessionId(Ljava/lang/String;)Ljava/lang/String;
    .locals 3

    new-instance p0, Lkotlin/text/Regex;

    const-string v0, "\\[(\\w+)]"

    invoke-direct {p0, v0}, Lkotlin/text/Regex;-><init>(Ljava/lang/String;)V

    const/4 v0, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-static {p0, p1, v2, v0, v1}, Lkotlin/text/Regex;->find$default(Lkotlin/text/Regex;Ljava/lang/CharSequence;IILjava/lang/Object;)Lkotlin/text/MatchResult;

    move-result-object p0

    if-eqz p0, :cond_0

    invoke-interface {p0}, Lkotlin/text/MatchResult;->getGroupValues()Ljava/util/List;

    move-result-object p0

    if-eqz p0, :cond_0

    const/4 p1, 0x1

    invoke-interface {p0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/String;

    if-eqz p0, :cond_0

    return-object p0

    :cond_0
    new-instance p0, Ljava/io/IOException;

    const-string p1, "Failed to create session"

    invoke-direct {p0, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method private final finalizeSession(Ljava/lang/String;Ljava/lang/String;Lcom/flyfishxu/kadb/Kadb$InstallSessionMode;)V
    .locals 5

    if-nez p2, :cond_0

    const-string v0, "install-commit"

    goto :goto_0

    :cond_0
    const-string v0, "install-abandon"

    :goto_0
    sget-object v1, Lcom/flyfishxu/kadb/Kadb$WhenMappings;->$EnumSwitchMapping$0:[I

    invoke-virtual {p3}, Ljava/lang/Enum;->ordinal()I

    move-result v2

    aget v1, v1, v2

    const/4 v2, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x2

    if-eq v1, v2, :cond_2

    if-eq v1, v4, :cond_2

    const/4 p3, 0x3

    if-ne v1, p3, :cond_1

    const-string p3, "pm"

    filled-new-array {p3, v0, p1}, [Ljava/lang/String;

    move-result-object p1

    invoke-static {p1}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object p1

    invoke-direct {p0, p1}, Lcom/flyfishxu/kadb/Kadb;->buildShellCommand(Ljava/util/List;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Lcom/flyfishxu/kadb/Kadb;->shell(Ljava/lang/String;)Lcom/flyfishxu/kadb/shell/AdbShellResponse;

    move-result-object p0

    invoke-virtual {p0}, Lcom/flyfishxu/kadb/shell/AdbShellResponse;->getAllOutput()Ljava/lang/String;

    move-result-object p0

    goto :goto_1

    :cond_1
    new-instance p0, Lkotlin/NoWhenBranchMatchedException;

    invoke-direct {p0}, Lkotlin/NoWhenBranchMatchedException;-><init>()V

    throw p0

    :cond_2
    const-string v1, "package"

    filled-new-array {v1, v0, p1}, [Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p3, p1}, Lcom/flyfishxu/kadb/Kadb;->openInstallCommand(Lcom/flyfishxu/kadb/Kadb$InstallSessionMode;[Ljava/lang/String;)Lcom/flyfishxu/kadb/stream/AdbStream;

    move-result-object p0

    :try_start_0
    invoke-virtual {p0}, Lcom/flyfishxu/kadb/stream/AdbStream;->getSource()Lokio/BufferedSource;

    move-result-object p1

    invoke-interface {p1}, Lokio/BufferedSource;->readUtf8()Ljava/lang/String;

    move-result-object p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    invoke-static {p0, v3}, Lkotlin/jdk7/AutoCloseableKt;->closeFinally(Ljava/lang/AutoCloseable;Ljava/lang/Throwable;)V

    move-object p0, p1

    :goto_1
    const-string p1, "Success"

    const/4 p3, 0x0

    invoke-static {p0, p1, p3, v4, v3}, Lkotlin/text/StringsKt;->startsWith$default(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_4

    if-nez p2, :cond_3

    return-void

    :cond_3
    new-instance p0, Ljava/io/IOException;

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const-string p3, "Install failed: "

    invoke-virtual {p1, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_4
    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const-string p2, "Failed to finalize session: "

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    new-instance p1, Ljava/lang/IllegalStateException;

    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {p1, p0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :catchall_0
    move-exception p1

    :try_start_1
    throw p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    :catchall_1
    move-exception p2

    invoke-static {p0, p1}, Lkotlin/jdk7/AutoCloseableKt;->closeFinally(Ljava/lang/AutoCloseable;Ljava/lang/Throwable;)V

    throw p2
.end method

.method private final installSessionMode()Lcom/flyfishxu/kadb/Kadb$InstallSessionMode;
    .locals 1

    const-string v0, "abb_exec"

    invoke-virtual {p0, v0}, Lcom/flyfishxu/kadb/Kadb;->supportsFeature(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_0

    sget-object p0, Lcom/flyfishxu/kadb/Kadb$InstallSessionMode;->ABB_EXEC:Lcom/flyfishxu/kadb/Kadb$InstallSessionMode;

    goto :goto_0

    :cond_0
    const-string v0, "cmd"

    invoke-virtual {p0, v0}, Lcom/flyfishxu/kadb/Kadb;->supportsFeature(Ljava/lang/String;)Z

    move-result p0

    if-eqz p0, :cond_1

    sget-object p0, Lcom/flyfishxu/kadb/Kadb$InstallSessionMode;->EXEC_CMD:Lcom/flyfishxu/kadb/Kadb$InstallSessionMode;

    goto :goto_0

    :cond_1
    sget-object p0, Lcom/flyfishxu/kadb/Kadb$InstallSessionMode;->PM_SHELL:Lcom/flyfishxu/kadb/Kadb$InstallSessionMode;

    :goto_0
    return-object p0
.end method

.method private final isRecoverableTransportOpenFailure(Ljava/lang/Throwable;)Z
    .locals 7

    instance-of v0, p1, Ljava/io/EOFException;

    const/4 v1, 0x1

    if-eqz v0, :cond_0

    goto :goto_2

    :cond_0
    instance-of v0, p1, Ljava/io/IOException;

    const/4 v2, 0x0

    if-nez v0, :cond_3

    instance-of v0, p1, Ljava/lang/IllegalStateException;

    if-eqz v0, :cond_1

    goto :goto_0

    :cond_1
    invoke-virtual {p1}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    move-result-object p1

    if-eqz p1, :cond_2

    invoke-direct {p0, p1}, Lcom/flyfishxu/kadb/Kadb;->isRecoverableTransportOpenFailure(Ljava/lang/Throwable;)Z

    move-result p0

    if-ne p0, v1, :cond_2

    goto :goto_2

    :cond_2
    move v1, v2

    goto :goto_2

    :cond_3
    :goto_0
    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    if-nez v0, :cond_4

    const-string v0, ""

    :cond_4
    sget-object v3, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {v0, v3}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v0

    const-string v3, "toLowerCase(...)"

    invoke-static {v0, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object v3, Lcom/flyfishxu/kadb/Kadb;->OPEN_TRANSPORT_FAILURE_MARKERS:Ljava/util/List;

    if-eqz v3, :cond_5

    invoke-interface {v3}, Ljava/util/Collection;->isEmpty()Z

    move-result v4

    if-eqz v4, :cond_5

    goto :goto_1

    :cond_5
    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :cond_6
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_7

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/CharSequence;

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-static {v0, v4, v2, v5, v6}, Lkotlin/text/StringsKt;->contains$default(Ljava/lang/CharSequence;Ljava/lang/CharSequence;ZILjava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_6

    goto :goto_2

    :cond_7
    :goto_1
    invoke-virtual {p1}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    move-result-object p1

    if-eqz p1, :cond_2

    invoke-direct {p0, p1}, Lcom/flyfishxu/kadb/Kadb;->isRecoverableTransportOpenFailure(Ljava/lang/Throwable;)Z

    move-result p0

    if-ne p0, v1, :cond_2

    :goto_2
    return v1
.end method

.method private final newConnection()Lkotlin/Pair;
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlin/Pair<",
            "Lcom/flyfishxu/kadb/core/AdbConnection;",
            "Lcom/flyfishxu/kadb/transport/TransportChannel;",
            ">;"
        }
    .end annotation

    new-instance v0, Lcom/flyfishxu/kadb/Kadb$newConnection$1;

    const/4 v1, 0x0

    invoke-direct {v0, p0, v1}, Lcom/flyfishxu/kadb/Kadb$newConnection$1;-><init>(Lcom/flyfishxu/kadb/Kadb;Lkotlin/coroutines/Continuation;)V

    const/4 p0, 0x1

    invoke-static {v1, v0, p0, v1}, Lkotlinx/coroutines/BuildersKt;->runBlockingK$default(Lkotlin/coroutines/CoroutineContext;Lkotlin/jvm/functions/Function2;ILjava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lkotlin/Pair;

    return-object p0
.end method

.method private final nonBlankOptions([Ljava/lang/String;)Ljava/util/List;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "([",
            "Ljava/lang/String;",
            ")",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    new-instance p0, Ljava/util/ArrayList;

    invoke-direct {p0}, Ljava/util/ArrayList;-><init>()V

    array-length v0, p1

    const/4 v1, 0x0

    :goto_0
    if-ge v1, v0, :cond_1

    aget-object v2, p1, v1

    invoke-static {v2}, Lkotlin/text/StringsKt;->isBlank(Ljava/lang/CharSequence;)Z

    move-result v3

    if-nez v3, :cond_0

    invoke-interface {p0, v2}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    :cond_0
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_1
    return-object p0
.end method

.method private final varargs openInstallCommand(Lcom/flyfishxu/kadb/Kadb$InstallSessionMode;[Ljava/lang/String;)Lcom/flyfishxu/kadb/stream/AdbStream;
    .locals 1

    sget-object v0, Lcom/flyfishxu/kadb/Kadb$WhenMappings;->$EnumSwitchMapping$0:[I

    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    move-result p1

    aget p1, v0, p1

    const/4 v0, 0x1

    if-eq p1, v0, :cond_2

    const/4 v0, 0x2

    if-eq p1, v0, :cond_1

    const/4 p0, 0x3

    if-eq p1, p0, :cond_0

    new-instance p0, Lkotlin/NoWhenBranchMatchedException;

    invoke-direct {p0}, Lkotlin/NoWhenBranchMatchedException;-><init>()V

    throw p0

    :cond_0
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string p1, "Legacy pm shell path does not open streamed install commands"

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_1
    array-length p1, p2

    invoke-static {p2, p1}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object p1

    check-cast p1, [Ljava/lang/String;

    invoke-virtual {p0, p1}, Lcom/flyfishxu/kadb/Kadb;->execCmd([Ljava/lang/String;)Lcom/flyfishxu/kadb/stream/AdbStream;

    move-result-object p0

    goto :goto_0

    :cond_2
    array-length p1, p2

    invoke-static {p2, p1}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object p1

    check-cast p1, [Ljava/lang/String;

    invoke-virtual {p0, p1}, Lcom/flyfishxu/kadb/Kadb;->abbExec([Ljava/lang/String;)Lcom/flyfishxu/kadb/stream/AdbStream;

    move-result-object p0

    :goto_0
    return-object p0
.end method

.method public static synthetic openPtyShellSession$default(Lcom/flyfishxu/kadb/Kadb;Ljava/lang/String;Ljava/lang/String;ILjava/lang/Object;)Lcom/flyfishxu/kadb/shell/AdbPtyShellSession;
    .locals 0

    and-int/lit8 p4, p3, 0x1

    if-eqz p4, :cond_0

    const-string p1, ""

    :cond_0
    and-int/lit8 p3, p3, 0x2

    if-eqz p3, :cond_1

    const-string p2, "xterm-256color"

    :cond_1
    invoke-virtual {p0, p1, p2}, Lcom/flyfishxu/kadb/Kadb;->openPtyShellSession(Ljava/lang/String;Ljava/lang/String;)Lcom/flyfishxu/kadb/shell/AdbPtyShellSession;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic openShell$default(Lcom/flyfishxu/kadb/Kadb;Ljava/lang/String;ILjava/lang/Object;)Lcom/flyfishxu/kadb/shell/AdbShellStream;
    .locals 0

    and-int/lit8 p2, p2, 0x1

    if-eqz p2, :cond_0

    const-string p1, ""

    :cond_0
    invoke-virtual {p0, p1}, Lcom/flyfishxu/kadb/Kadb;->openShell(Ljava/lang/String;)Lcom/flyfishxu/kadb/shell/AdbShellStream;

    move-result-object p0

    return-object p0
.end method

.method private final openStream(Ljava/lang/String;Z)Lkotlin/Pair;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Z)",
            "Lkotlin/Pair<",
            "Lcom/flyfishxu/kadb/core/AdbConnection;",
            "Lcom/flyfishxu/kadb/stream/AdbStream;",
            ">;"
        }
    .end annotation

    invoke-direct {p0}, Lcom/flyfishxu/kadb/Kadb;->connection()Lcom/flyfishxu/kadb/core/AdbConnection;

    move-result-object v0

    :try_start_0
    invoke-virtual {v0, p1}, Lcom/flyfishxu/kadb/core/AdbConnection;->open(Ljava/lang/String;)Lcom/flyfishxu/kadb/stream/AdbStream;

    move-result-object v1

    invoke-static {v0, v1}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception v1

    invoke-direct {p0, v1}, Lcom/flyfishxu/kadb/Kadb;->isRecoverableTransportOpenFailure(Ljava/lang/Throwable;)Z

    move-result v2

    if-eqz v2, :cond_1

    invoke-direct {p0, v0}, Lcom/flyfishxu/kadb/Kadb;->discardConnection(Lcom/flyfishxu/kadb/core/AdbConnection;)V

    if-eqz p2, :cond_0

    const/4 p2, 0x0

    invoke-direct {p0, p1, p2}, Lcom/flyfishxu/kadb/Kadb;->openStream(Ljava/lang/String;Z)Lkotlin/Pair;

    move-result-object p0

    :goto_0
    return-object p0

    :cond_0
    throw v1

    :cond_1
    throw v1
.end method

.method public static synthetic openStream$default(Lcom/flyfishxu/kadb/Kadb;Ljava/lang/String;ZILjava/lang/Object;)Lkotlin/Pair;
    .locals 0

    and-int/lit8 p3, p3, 0x2

    if-eqz p3, :cond_0

    const/4 p2, 0x1

    :cond_0
    invoke-direct {p0, p1, p2}, Lcom/flyfishxu/kadb/Kadb;->openStream(Ljava/lang/String;Z)Lkotlin/Pair;

    move-result-object p0

    return-object p0
.end method

.method private final varargs pmInstall(Ljava/io/File;[Ljava/lang/String;)V
    .locals 9

    invoke-virtual {p1}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "/data/local/tmp/"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {p0, p1}, Lcom/flyfishxu/kadb/Kadb_androidKt;->readMode(Lcom/flyfishxu/kadb/Kadb;Ljava/io/File;)I

    move-result v6

    invoke-virtual {p1}, Ljava/io/File;->lastModified()J

    move-result-wide v7

    move-object v3, p0

    move-object v4, p1

    move-object v5, v0

    :try_start_0
    invoke-virtual/range {v3 .. v8}, Lcom/flyfishxu/kadb/Kadb;->push(Ljava/io/File;Ljava/lang/String;IJ)V

    array-length p1, p2

    invoke-static {p2, p1}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object p1

    check-cast p1, [Ljava/lang/String;

    invoke-direct {p0, v0, p1}, Lcom/flyfishxu/kadb/Kadb;->pmInstallRemote(Ljava/lang/String;[Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    invoke-direct {p0, v0}, Lcom/flyfishxu/kadb/Kadb;->cleanupRemoteTempFile(Ljava/lang/String;)V

    return-void

    :catchall_0
    move-exception p1

    invoke-direct {p0, v0}, Lcom/flyfishxu/kadb/Kadb;->cleanupRemoteTempFile(Ljava/lang/String;)V

    throw p1
.end method

.method private final varargs pmInstallRemote(Ljava/lang/String;[Ljava/lang/String;)V
    .locals 3

    const-string v0, "pm"

    const-string v1, "install"

    filled-new-array {v0, v1}, [Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    invoke-direct {p0, p2}, Lcom/flyfishxu/kadb/Kadb;->nonBlankOptions([Ljava/lang/String;)Ljava/util/List;

    move-result-object p2

    invoke-static {v0, p2}, Lkotlin/collections/CollectionsKt;->plus(Ljava/util/Collection;Ljava/lang/Iterable;)Ljava/util/List;

    move-result-object p2

    invoke-static {p2, p1}, Lkotlin/collections/CollectionsKt;->plus(Ljava/util/Collection;Ljava/lang/Object;)Ljava/util/List;

    move-result-object p1

    invoke-direct {p0, p1}, Lcom/flyfishxu/kadb/Kadb;->buildShellCommand(Ljava/util/List;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Lcom/flyfishxu/kadb/Kadb;->shell(Ljava/lang/String;)Lcom/flyfishxu/kadb/shell/AdbShellResponse;

    move-result-object p0

    invoke-virtual {p0}, Lcom/flyfishxu/kadb/shell/AdbShellResponse;->getAllOutput()Ljava/lang/String;

    move-result-object p1

    const/4 p2, 0x2

    const/4 v0, 0x0

    const-string v1, "Success"

    const/4 v2, 0x0

    invoke-static {p1, v1, v2, p2, v0}, Lkotlin/text/StringsKt;->startsWith$default(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    return-void

    :cond_0
    invoke-virtual {p0}, Lcom/flyfishxu/kadb/shell/AdbShellResponse;->getAllOutput()Ljava/lang/String;

    move-result-object p0

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const-string p2, "Install failed: "

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    new-instance p1, Ljava/lang/IllegalStateException;

    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {p1, p0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public static synthetic push$default(Lcom/flyfishxu/kadb/Kadb;Ljava/io/File;Ljava/lang/String;IJILjava/lang/Object;)V
    .locals 6

    and-int/lit8 p7, p6, 0x4

    if-eqz p7, :cond_0

    invoke-static {p0, p1}, Lcom/flyfishxu/kadb/Kadb_androidKt;->readMode(Lcom/flyfishxu/kadb/Kadb;Ljava/io/File;)I

    move-result p3

    :cond_0
    move v3, p3

    and-int/lit8 p3, p6, 0x8

    if-eqz p3, :cond_1

    invoke-virtual {p1}, Ljava/io/File;->lastModified()J

    move-result-wide p4

    :cond_1
    move-wide v4, p4

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    invoke-virtual/range {v0 .. v5}, Lcom/flyfishxu/kadb/Kadb;->push(Ljava/io/File;Ljava/lang/String;IJ)V

    return-void
.end method

.method private final pushAndWrite(Ljava/io/File;Ljava/lang/String;I)Ljava/lang/String;
    .locals 10

    invoke-virtual {p1}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "/data/local/tmp/"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {p0, p1}, Lcom/flyfishxu/kadb/Kadb_androidKt;->readMode(Lcom/flyfishxu/kadb/Kadb;Ljava/io/File;)I

    move-result v6

    invoke-virtual {p1}, Ljava/io/File;->lastModified()J

    move-result-wide v7

    move-object v3, p0

    move-object v4, p1

    move-object v5, v0

    :try_start_0
    invoke-virtual/range {v3 .. v8}, Lcom/flyfishxu/kadb/Kadb;->push(Ljava/io/File;Ljava/lang/String;IJ)V

    const-string v3, "pm"

    const-string v4, "install-write"

    const-string v5, "-S"

    invoke-virtual {p1}, Ljava/io/File;->length()J

    move-result-wide v1

    invoke-static {v1, v2}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object v6

    invoke-static {p3}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v8

    move-object v7, p2

    move-object v9, v0

    filled-new-array/range {v3 .. v9}, [Ljava/lang/String;

    move-result-object p1

    invoke-static {p1}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object p1

    invoke-direct {p0, p1}, Lcom/flyfishxu/kadb/Kadb;->buildShellCommand(Ljava/util/List;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Lcom/flyfishxu/kadb/Kadb;->shell(Ljava/lang/String;)Lcom/flyfishxu/kadb/shell/AdbShellResponse;

    move-result-object p1

    invoke-virtual {p1}, Lcom/flyfishxu/kadb/shell/AdbShellResponse;->getAllOutput()Ljava/lang/String;

    move-result-object p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    invoke-direct {p0, v0}, Lcom/flyfishxu/kadb/Kadb;->cleanupRemoteTempFile(Ljava/lang/String;)V

    return-object p1

    :catchall_0
    move-exception p1

    invoke-direct {p0, v0}, Lcom/flyfishxu/kadb/Kadb;->cleanupRemoteTempFile(Ljava/lang/String;)V

    throw p1
.end method

.method private final requireShellV2(Ljava/lang/String;)V
    .locals 1

    const-string v0, "shell_v2"

    invoke-virtual {p0, v0}, Lcom/flyfishxu/kadb/Kadb;->supportsFeature(Ljava/lang/String;)Z

    move-result p0

    if-eqz p0, :cond_0

    return-void

    :cond_0
    new-instance p0, Ljava/lang/StringBuilder;

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p1, " requires peer feature \'shell_v2\'; use shell(command) for legacy shell fallback."

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    new-instance p1, Ljava/lang/IllegalStateException;

    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {p1, p0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method private final restartAdb(Ljava/lang/String;)Ljava/lang/String;
    .locals 1

    invoke-virtual {p0, p1}, Lcom/flyfishxu/kadb/Kadb;->open(Ljava/lang/String;)Lcom/flyfishxu/kadb/stream/AdbStream;

    move-result-object p0

    :try_start_0
    invoke-virtual {p0}, Lcom/flyfishxu/kadb/stream/AdbStream;->getSource()Lokio/BufferedSource;

    move-result-object p1

    const/16 v0, 0xa

    invoke-static {p1, v0}, Lcom/flyfishxu/kadb/KadbKt;->access$readUntil(Lokio/BufferedSource;B)Lokio/Buffer;

    move-result-object p1

    sget-object v0, Lkotlin/text/Charsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-virtual {p1, v0}, Lokio/Buffer;->readString(Ljava/nio/charset/Charset;)Ljava/lang/String;

    move-result-object p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v0, 0x0

    invoke-static {p0, v0}, Lkotlin/jdk7/AutoCloseableKt;->closeFinally(Ljava/lang/AutoCloseable;Ljava/lang/Throwable;)V

    return-object p1

    :catchall_0
    move-exception p1

    :try_start_1
    throw p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    :catchall_1
    move-exception v0

    invoke-static {p0, p1}, Lkotlin/jdk7/AutoCloseableKt;->closeFinally(Ljava/lang/AutoCloseable;Ljava/lang/Throwable;)V

    throw v0
.end method

.method private final streamInstallWrite(Ljava/io/File;Ljava/lang/String;Lcom/flyfishxu/kadb/Kadb$InstallSessionMode;)Ljava/lang/String;
    .locals 9

    invoke-virtual {p1}, Ljava/io/File;->length()J

    move-result-wide v0

    invoke-static {v0, v1}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {p1}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object v7

    const-string v0, "getName(...)"

    invoke-static {v7, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v8, "-"

    const-string v2, "package"

    const-string v3, "install-write"

    const-string v4, "-S"

    move-object v6, p2

    filled-new-array/range {v2 .. v8}, [Ljava/lang/String;

    move-result-object p2

    invoke-direct {p0, p3, p2}, Lcom/flyfishxu/kadb/Kadb;->openInstallCommand(Lcom/flyfishxu/kadb/Kadb$InstallSessionMode;[Ljava/lang/String;)Lcom/flyfishxu/kadb/stream/AdbStream;

    move-result-object p0

    :try_start_0
    invoke-virtual {p0}, Lcom/flyfishxu/kadb/stream/AdbStream;->getSink()Lokio/BufferedSink;

    move-result-object p2

    invoke-static {p1}, Lokio/Okio;->source(Ljava/io/File;)Lokio/Source;

    move-result-object p1

    invoke-interface {p2, p1}, Lokio/BufferedSink;->writeAll(Lokio/Source;)J

    invoke-virtual {p0}, Lcom/flyfishxu/kadb/stream/AdbStream;->getSink()Lokio/BufferedSink;

    move-result-object p1

    invoke-interface {p1}, Lokio/BufferedSink;->flush()V

    invoke-virtual {p0}, Lcom/flyfishxu/kadb/stream/AdbStream;->getSource()Lokio/BufferedSource;

    move-result-object p1

    invoke-interface {p1}, Lokio/BufferedSource;->readUtf8()Ljava/lang/String;

    move-result-object p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 p2, 0x0

    invoke-static {p0, p2}, Lkotlin/jdk7/AutoCloseableKt;->closeFinally(Ljava/lang/AutoCloseable;Ljava/lang/Throwable;)V

    return-object p1

    :catchall_0
    move-exception p1

    :try_start_1
    throw p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    :catchall_1
    move-exception p2

    invoke-static {p0, p1}, Lkotlin/jdk7/AutoCloseableKt;->closeFinally(Ljava/lang/AutoCloseable;Ljava/lang/Throwable;)V

    throw p2
.end method


# virtual methods
.method public final varargs abbExec([Ljava/lang/String;)Lcom/flyfishxu/kadb/stream/AdbStream;
    .locals 10

    const-string v0, "command"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const/16 v8, 0x3e

    const/4 v9, 0x0

    const-string v2, "\u0000"

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    move-object v1, p1

    invoke-static/range {v1 .. v9}, Lkotlin/collections/ArraysKt;->joinToString$default([Ljava/lang/Object;Ljava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/CharSequence;ILjava/lang/CharSequence;Lkotlin/jvm/functions/Function1;ILjava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "abb_exec:"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Lcom/flyfishxu/kadb/Kadb;->open(Ljava/lang/String;)Lcom/flyfishxu/kadb/stream/AdbStream;

    move-result-object p0

    return-object p0
.end method

.method public close()V
    .locals 1

    iget-object v0, p0, Lcom/flyfishxu/kadb/Kadb;->connection:Lkotlin/Pair;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Lkotlin/Pair;->getFirst()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/flyfishxu/kadb/core/AdbConnection;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Lcom/flyfishxu/kadb/core/AdbConnection;->close()V

    :cond_0
    const/4 v0, 0x0

    iput-object v0, p0, Lcom/flyfishxu/kadb/Kadb;->connection:Lkotlin/Pair;

    return-void
.end method

.method public final connectionCheck()Z
    .locals 2

    iget-object p0, p0, Lcom/flyfishxu/kadb/Kadb;->connection:Lkotlin/Pair;

    const/4 v0, 0x0

    if-eqz p0, :cond_0

    invoke-virtual {p0}, Lkotlin/Pair;->getSecond()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lcom/flyfishxu/kadb/transport/TransportChannel;

    if-eqz p0, :cond_0

    invoke-interface {p0}, Lcom/flyfishxu/kadb/transport/TransportChannel;->isOpen()Z

    move-result p0

    const/4 v1, 0x1

    if-ne p0, v1, :cond_0

    move v0, v1

    :cond_0
    return v0
.end method

.method public final varargs execCmd([Ljava/lang/String;)Lcom/flyfishxu/kadb/stream/AdbStream;
    .locals 1

    const-string v0, "command"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {p1}, Lkotlin/collections/ArraysKt;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object p1

    invoke-direct {p0, p1}, Lcom/flyfishxu/kadb/Kadb;->buildExecCmdService(Ljava/util/List;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Lcom/flyfishxu/kadb/Kadb;->open(Ljava/lang/String;)Lcom/flyfishxu/kadb/stream/AdbStream;

    move-result-object p0

    return-object p0
.end method

.method public final varargs install(Ljava/io/File;[Ljava/lang/String;)V
    .locals 3

    const-string v0, "file"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "options"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1
    const-string v0, "cmd"

    invoke-virtual {p0, v0}, Lcom/flyfishxu/kadb/Kadb;->supportsFeature(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 2
    invoke-static {p1}, Lokio/Okio;->source(Ljava/io/File;)Lokio/Source;

    move-result-object v0

    invoke-virtual {p1}, Ljava/io/File;->length()J

    move-result-wide v1

    array-length p1, p2

    invoke-static {p2, p1}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object p1

    check-cast p1, [Ljava/lang/String;

    invoke-virtual {p0, v0, v1, v2, p1}, Lcom/flyfishxu/kadb/Kadb;->install(Lokio/Source;J[Ljava/lang/String;)V

    goto :goto_0

    .line 3
    :cond_0
    array-length v0, p2

    invoke-static {p2, v0}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object p2

    check-cast p2, [Ljava/lang/String;

    invoke-direct {p0, p1, p2}, Lcom/flyfishxu/kadb/Kadb;->pmInstall(Ljava/io/File;[Ljava/lang/String;)V

    :goto_0
    return-void
.end method

.method public final varargs install(Lokio/Source;J[Ljava/lang/String;)V
    .locals 7

    const-string v0, "source"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "options"

    invoke-static {p4, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    const-string v0, "cmd"

    invoke-virtual {p0, v0}, Lcom/flyfishxu/kadb/Kadb;->supportsFeature(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_1

    .line 5
    new-instance v0, Lkotlin/jvm/internal/SpreadBuilder;

    const/4 v1, 0x5

    invoke-direct {v0, v1}, Lkotlin/jvm/internal/SpreadBuilder;-><init>(I)V

    const-string v1, "package"

    invoke-virtual {v0, v1}, Lkotlin/jvm/internal/SpreadBuilder;->add(Ljava/lang/Object;)V

    const-string v1, "install"

    invoke-virtual {v0, v1}, Lkotlin/jvm/internal/SpreadBuilder;->add(Ljava/lang/Object;)V

    const-string v1, "-S"

    invoke-virtual {v0, v1}, Lkotlin/jvm/internal/SpreadBuilder;->add(Ljava/lang/Object;)V

    invoke-static {p2, p3}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {v0, p2}, Lkotlin/jvm/internal/SpreadBuilder;->add(Ljava/lang/Object;)V

    invoke-virtual {v0, p4}, Lkotlin/jvm/internal/SpreadBuilder;->addSpread(Ljava/lang/Object;)V

    invoke-virtual {v0}, Lkotlin/jvm/internal/SpreadBuilder;->size()I

    move-result p2

    new-array p2, p2, [Ljava/lang/String;

    invoke-virtual {v0, p2}, Lkotlin/jvm/internal/SpreadBuilder;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object p2

    check-cast p2, [Ljava/lang/String;

    invoke-virtual {p0, p2}, Lcom/flyfishxu/kadb/Kadb;->execCmd([Ljava/lang/String;)Lcom/flyfishxu/kadb/stream/AdbStream;

    move-result-object p0

    .line 6
    :try_start_0
    invoke-virtual {p0}, Lcom/flyfishxu/kadb/stream/AdbStream;->getSink()Lokio/BufferedSink;

    move-result-object p2

    invoke-interface {p2, p1}, Lokio/BufferedSink;->writeAll(Lokio/Source;)J

    .line 7
    invoke-virtual {p0}, Lcom/flyfishxu/kadb/stream/AdbStream;->getSink()Lokio/BufferedSink;

    move-result-object p1

    invoke-interface {p1}, Lokio/BufferedSink;->flush()V

    .line 8
    invoke-virtual {p0}, Lcom/flyfishxu/kadb/stream/AdbStream;->getSource()Lokio/BufferedSource;

    move-result-object p1

    invoke-interface {p1}, Lokio/BufferedSource;->readUtf8()Ljava/lang/String;

    move-result-object p1

    .line 9
    const-string p2, "Success"

    const/4 p3, 0x0

    const/4 p4, 0x2

    const/4 v0, 0x0

    invoke-static {p1, p2, p3, p4, v0}, Lkotlin/text/StringsKt;->startsWith$default(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z

    move-result p2

    if-eqz p2, :cond_0

    .line 10
    sget-object p1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 11
    invoke-static {p0, v0}, Lkotlin/jdk7/AutoCloseableKt;->closeFinally(Ljava/lang/AutoCloseable;Ljava/lang/Throwable;)V

    goto :goto_1

    :catchall_0
    move-exception p1

    goto :goto_0

    .line 12
    :cond_0
    :try_start_1
    new-instance p2, Ljava/lang/StringBuilder;

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const-string p3, "Install failed: "

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    new-instance p2, Ljava/lang/IllegalStateException;

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p2, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p2
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 13
    :goto_0
    :try_start_2
    throw p1
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    :catchall_1
    move-exception p2

    invoke-static {p0, p1}, Lkotlin/jdk7/AutoCloseableKt;->closeFinally(Ljava/lang/AutoCloseable;Ljava/lang/Throwable;)V

    throw p2

    .line 14
    :cond_1
    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide p2

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "/data/local/tmp/kadb-install-"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p2, p3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string p2, ".apk"

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    .line 15
    :try_start_3
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v5

    const/16 v4, 0x1a4

    move-object v1, p0

    move-object v2, p1

    move-object v3, p2

    invoke-virtual/range {v1 .. v6}, Lcom/flyfishxu/kadb/Kadb;->push(Lokio/Source;Ljava/lang/String;IJ)V

    .line 16
    array-length p1, p4

    invoke-static {p4, p1}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object p1

    check-cast p1, [Ljava/lang/String;

    invoke-direct {p0, p2, p1}, Lcom/flyfishxu/kadb/Kadb;->pmInstallRemote(Ljava/lang/String;[Ljava/lang/String;)V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_2

    .line 17
    invoke-direct {p0, p2}, Lcom/flyfishxu/kadb/Kadb;->cleanupRemoteTempFile(Ljava/lang/String;)V

    :goto_1
    return-void

    :catchall_2
    move-exception p1

    invoke-direct {p0, p2}, Lcom/flyfishxu/kadb/Kadb;->cleanupRemoteTempFile(Ljava/lang/String;)V

    throw p1
.end method

.method public final varargs installMultiple(Ljava/util/List;[Ljava/lang/String;)V
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "+",
            "Ljava/io/File;",
            ">;[",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    const-string v0, "apks"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "options"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0, p2}, Lcom/flyfishxu/kadb/Kadb;->nonBlankOptions([Ljava/lang/String;)Ljava/util/List;

    move-result-object p2

    invoke-direct {p0}, Lcom/flyfishxu/kadb/Kadb;->installSessionMode()Lcom/flyfishxu/kadb/Kadb$InstallSessionMode;

    move-result-object v0

    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    const-wide/16 v2, 0x0

    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_0

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/io/File;

    invoke-virtual {v4}, Ljava/io/File;->length()J

    move-result-wide v4

    add-long/2addr v2, v4

    goto :goto_0

    :cond_0
    invoke-direct {p0, v2, v3, p2, v0}, Lcom/flyfishxu/kadb/Kadb;->createInstallSession(JLjava/util/List;Lcom/flyfishxu/kadb/Kadb$InstallSessionMode;)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {v0}, Lcom/flyfishxu/kadb/Kadb$InstallSessionMode;->getUsesStreaming()Z

    move-result v1

    const/4 v2, 0x2

    const-string v3, "Success"

    const/4 v4, 0x0

    const/4 v5, 0x0

    if-eqz v1, :cond_3

    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :cond_1
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_8

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/io/File;

    invoke-direct {p0, v1, p2, v0}, Lcom/flyfishxu/kadb/Kadb;->streamInstallWrite(Ljava/io/File;Ljava/lang/String;Lcom/flyfishxu/kadb/Kadb$InstallSessionMode;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1, v3, v4, v2, v5}, Lkotlin/text/StringsKt;->startsWith$default(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z

    move-result v6

    if-nez v6, :cond_2

    goto :goto_1

    :cond_2
    move-object v1, v5

    :goto_1
    if-eqz v1, :cond_1

    move-object v5, v1

    goto :goto_4

    :cond_3
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p1

    move v6, v4

    :goto_2
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    if-eqz v7, :cond_7

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    add-int/lit8 v8, v6, 0x1

    if-gez v6, :cond_4

    invoke-static {}, Lkotlin/collections/CollectionsKt;->throwIndexOverflow()V

    :cond_4
    check-cast v7, Ljava/io/File;

    invoke-direct {p0, v7, p2, v6}, Lcom/flyfishxu/kadb/Kadb;->pushAndWrite(Ljava/io/File;Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v6

    invoke-static {v6, v3, v4, v2, v5}, Lkotlin/text/StringsKt;->startsWith$default(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z

    move-result v7

    if-nez v7, :cond_5

    goto :goto_3

    :cond_5
    move-object v6, v5

    :goto_3
    if-eqz v6, :cond_6

    invoke-interface {v1, v6}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    :cond_6
    move v6, v8

    goto :goto_2

    :cond_7
    invoke-static {v1}, Lkotlin/collections/CollectionsKt;->firstOrNull(Ljava/util/List;)Ljava/lang/Object;

    move-result-object p1

    move-object v5, p1

    check-cast v5, Ljava/lang/String;

    :cond_8
    :goto_4
    invoke-direct {p0, p2, v5, v0}, Lcom/flyfishxu/kadb/Kadb;->finalizeSession(Ljava/lang/String;Ljava/lang/String;Lcom/flyfishxu/kadb/Kadb$InstallSessionMode;)V

    return-void
.end method

.method public final open(Ljava/lang/String;)Lcom/flyfishxu/kadb/stream/AdbStream;
    .locals 3

    const-string v0, "destination"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v0, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-static {p0, p1, v2, v0, v1}, Lcom/flyfishxu/kadb/Kadb;->openStream$default(Lcom/flyfishxu/kadb/Kadb;Ljava/lang/String;ZILjava/lang/Object;)Lkotlin/Pair;

    move-result-object p0

    invoke-virtual {p0}, Lkotlin/Pair;->getSecond()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lcom/flyfishxu/kadb/stream/AdbStream;

    return-object p0
.end method

.method public final openPtyShellSession(Ljava/lang/String;Ljava/lang/String;)Lcom/flyfishxu/kadb/shell/AdbPtyShellSession;
    .locals 2

    const-string v0, "command"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "term"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "openPtyShellSession"

    invoke-direct {p0, v0}, Lcom/flyfishxu/kadb/Kadb;->requireShellV2(Ljava/lang/String;)V

    const/4 v0, 0x1

    const-string v1, "pty"

    invoke-direct {p0, p1, v0, p2, v1}, Lcom/flyfishxu/kadb/Kadb;->buildShellService(Ljava/lang/String;ZLjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    new-instance p2, Lcom/flyfishxu/kadb/shell/AdbPtyShellSession;

    new-instance v0, Lcom/flyfishxu/kadb/shell/AdbShellStream;

    invoke-virtual {p0, p1}, Lcom/flyfishxu/kadb/Kadb;->open(Ljava/lang/String;)Lcom/flyfishxu/kadb/stream/AdbStream;

    move-result-object p0

    invoke-direct {v0, p0}, Lcom/flyfishxu/kadb/shell/AdbShellStream;-><init>(Lcom/flyfishxu/kadb/stream/AdbStream;)V

    invoke-direct {p2, v0}, Lcom/flyfishxu/kadb/shell/AdbPtyShellSession;-><init>(Lcom/flyfishxu/kadb/shell/AdbShellStream;)V

    return-object p2
.end method

.method public final openShell(Ljava/lang/String;)Lcom/flyfishxu/kadb/shell/AdbShellStream;
    .locals 8

    const-string v0, "command"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "openShell"

    invoke-direct {p0, v0}, Lcom/flyfishxu/kadb/Kadb;->requireShellV2(Ljava/lang/String;)V

    new-instance v0, Lcom/flyfishxu/kadb/shell/AdbShellStream;

    const/4 v6, 0x4

    const/4 v7, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x0

    const-string v5, "raw"

    move-object v1, p0

    move-object v2, p1

    invoke-static/range {v1 .. v7}, Lcom/flyfishxu/kadb/Kadb;->buildShellService$default(Lcom/flyfishxu/kadb/Kadb;Ljava/lang/String;ZLjava/lang/String;Ljava/lang/String;ILjava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Lcom/flyfishxu/kadb/Kadb;->open(Ljava/lang/String;)Lcom/flyfishxu/kadb/stream/AdbStream;

    move-result-object p0

    invoke-direct {v0, p0}, Lcom/flyfishxu/kadb/shell/AdbShellStream;-><init>(Lcom/flyfishxu/kadb/stream/AdbStream;)V

    return-object v0
.end method

.method public final openSync()Lcom/flyfishxu/kadb/stream/AdbSyncStream;
    .locals 4

    const/4 v0, 0x2

    const/4 v1, 0x0

    const-string v2, "sync:"

    const/4 v3, 0x0

    invoke-static {p0, v2, v3, v0, v1}, Lcom/flyfishxu/kadb/Kadb;->openStream$default(Lcom/flyfishxu/kadb/Kadb;Ljava/lang/String;ZILjava/lang/Object;)Lkotlin/Pair;

    move-result-object p0

    invoke-virtual {p0}, Lkotlin/Pair;->component1()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/flyfishxu/kadb/core/AdbConnection;

    invoke-virtual {p0}, Lkotlin/Pair;->component2()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lcom/flyfishxu/kadb/stream/AdbStream;

    new-instance v1, Lcom/flyfishxu/kadb/stream/AdbSyncStream;

    invoke-virtual {v0}, Lcom/flyfishxu/kadb/core/AdbConnection;->featureSnapshot$com_github_IndiTheo_kadb()Ljava/util/Set;

    move-result-object v0

    invoke-direct {v1, p0, v0}, Lcom/flyfishxu/kadb/stream/AdbSyncStream;-><init>(Lcom/flyfishxu/kadb/stream/AdbStream;Ljava/util/Set;)V

    return-object v1
.end method

.method public final pull(Ljava/io/File;Ljava/lang/String;)V
    .locals 1

    const-string v0, "dst"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "remotePath"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, Lokio/Okio;->sink(Ljava/io/File;Z)Lokio/Sink;

    move-result-object p1

    invoke-virtual {p0, p1, p2}, Lcom/flyfishxu/kadb/Kadb;->pull(Lokio/Sink;Ljava/lang/String;)V

    return-void
.end method

.method public final pull(Lokio/Sink;Ljava/lang/String;)V
    .locals 1

    const-string v0, "sink"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "remotePath"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 2
    invoke-virtual {p0}, Lcom/flyfishxu/kadb/Kadb;->openSync()Lcom/flyfishxu/kadb/stream/AdbSyncStream;

    move-result-object p0

    :try_start_0
    invoke-virtual {p0, p1, p2}, Lcom/flyfishxu/kadb/stream/AdbSyncStream;->recv(Lokio/Sink;Ljava/lang/String;)V

    sget-object p1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 p1, 0x0

    invoke-static {p0, p1}, Lkotlin/jdk7/AutoCloseableKt;->closeFinally(Ljava/lang/AutoCloseable;Ljava/lang/Throwable;)V

    return-void

    :catchall_0
    move-exception p1

    :try_start_1
    throw p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    :catchall_1
    move-exception p2

    invoke-static {p0, p1}, Lkotlin/jdk7/AutoCloseableKt;->closeFinally(Ljava/lang/AutoCloseable;Ljava/lang/Throwable;)V

    throw p2
.end method

.method public final push(Ljava/io/File;Ljava/lang/String;IJ)V
    .locals 7

    const-string v0, "src"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "remotePath"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1
    invoke-static {p1}, Lokio/Okio;->source(Ljava/io/File;)Lokio/Source;

    move-result-object v2

    move-object v1, p0

    move-object v3, p2

    move v4, p3

    move-wide v5, p4

    invoke-virtual/range {v1 .. v6}, Lcom/flyfishxu/kadb/Kadb;->push(Lokio/Source;Ljava/lang/String;IJ)V

    return-void
.end method

.method public final push(Lokio/Source;Ljava/lang/String;IJ)V
    .locals 7

    const-string v0, "source"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "remotePath"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 2
    invoke-virtual {p0}, Lcom/flyfishxu/kadb/Kadb;->openSync()Lcom/flyfishxu/kadb/stream/AdbSyncStream;

    move-result-object p0

    move-object v1, p0

    move-object v2, p1

    move-object v3, p2

    move v4, p3

    move-wide v5, p4

    :try_start_0
    invoke-virtual/range {v1 .. v6}, Lcom/flyfishxu/kadb/stream/AdbSyncStream;->send(Lokio/Source;Ljava/lang/String;IJ)V

    sget-object p1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 p1, 0x0

    invoke-static {p0, p1}, Lkotlin/jdk7/AutoCloseableKt;->closeFinally(Ljava/lang/AutoCloseable;Ljava/lang/Throwable;)V

    return-void

    :catchall_0
    move-exception p1

    :try_start_1
    throw p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    :catchall_1
    move-exception p2

    invoke-static {p0, p1}, Lkotlin/jdk7/AutoCloseableKt;->closeFinally(Ljava/lang/AutoCloseable;Ljava/lang/Throwable;)V

    throw p2
.end method

.method public final resetConnection()V
    .locals 1

    iget-object v0, p0, Lcom/flyfishxu/kadb/Kadb;->connection:Lkotlin/Pair;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Lkotlin/Pair;->getFirst()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/flyfishxu/kadb/core/AdbConnection;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Lcom/flyfishxu/kadb/core/AdbConnection;->close()V

    :cond_0
    const/4 v0, 0x0

    iput-object v0, p0, Lcom/flyfishxu/kadb/Kadb;->connection:Lkotlin/Pair;

    return-void
.end method

.method public final root()Ljava/lang/String;
    .locals 1

    const-string v0, "root:"

    invoke-direct {p0, v0}, Lcom/flyfishxu/kadb/Kadb;->restartAdb(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public final shell(Ljava/lang/String;)Lcom/flyfishxu/kadb/shell/AdbShellResponse;
    .locals 9

    const-string v0, "command"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "shell_v2"

    invoke-virtual {p0, v0}, Lcom/flyfishxu/kadb/Kadb;->supportsFeature(Ljava/lang/String;)Z

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    invoke-virtual {p0, p1}, Lcom/flyfishxu/kadb/Kadb;->openShell(Ljava/lang/String;)Lcom/flyfishxu/kadb/shell/AdbShellStream;

    move-result-object p0

    :try_start_0
    invoke-virtual {p0}, Lcom/flyfishxu/kadb/shell/AdbShellStream;->readAll()Lcom/flyfishxu/kadb/shell/AdbShellResponse;

    move-result-object p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    invoke-static {p0, v1}, Lkotlin/jdk7/AutoCloseableKt;->closeFinally(Ljava/lang/AutoCloseable;Ljava/lang/Throwable;)V

    goto :goto_0

    :catchall_0
    move-exception p1

    :try_start_1
    throw p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    :catchall_1
    move-exception v0

    invoke-static {p0, p1}, Lkotlin/jdk7/AutoCloseableKt;->closeFinally(Ljava/lang/AutoCloseable;Ljava/lang/Throwable;)V

    throw v0

    :cond_0
    const/16 v7, 0xc

    const/4 v8, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    move-object v2, p0

    move-object v3, p1

    invoke-static/range {v2 .. v8}, Lcom/flyfishxu/kadb/Kadb;->buildShellService$default(Lcom/flyfishxu/kadb/Kadb;Ljava/lang/String;ZLjava/lang/String;Ljava/lang/String;ILjava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Lcom/flyfishxu/kadb/Kadb;->enforceLegacyShellServiceLength(Ljava/lang/String;)V

    invoke-virtual {p0, p1}, Lcom/flyfishxu/kadb/Kadb;->open(Ljava/lang/String;)Lcom/flyfishxu/kadb/stream/AdbStream;

    move-result-object p0

    :try_start_2
    invoke-virtual {p0}, Lcom/flyfishxu/kadb/stream/AdbStream;->getSource()Lokio/BufferedSource;

    move-result-object p1

    invoke-interface {p1}, Lokio/BufferedSource;->readUtf8()Ljava/lang/String;

    move-result-object p1

    new-instance v0, Lcom/flyfishxu/kadb/shell/AdbShellResponse;

    const-string v2, ""

    const/4 v3, 0x0

    invoke-direct {v0, p1, v2, v3}, Lcom/flyfishxu/kadb/shell/AdbShellResponse;-><init>(Ljava/lang/String;Ljava/lang/String;I)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_2

    invoke-static {p0, v1}, Lkotlin/jdk7/AutoCloseableKt;->closeFinally(Ljava/lang/AutoCloseable;Ljava/lang/Throwable;)V

    move-object p1, v0

    :goto_0
    return-object p1

    :catchall_2
    move-exception p1

    :try_start_3
    throw p1
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_3

    :catchall_3
    move-exception v0

    invoke-static {p0, p1}, Lkotlin/jdk7/AutoCloseableKt;->closeFinally(Ljava/lang/AutoCloseable;Ljava/lang/Throwable;)V

    throw v0
.end method

.method public final supportsFeature(Ljava/lang/String;)Z
    .locals 1

    const-string v0, "feature"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0}, Lcom/flyfishxu/kadb/Kadb;->connection()Lcom/flyfishxu/kadb/core/AdbConnection;

    move-result-object p0

    invoke-virtual {p0, p1}, Lcom/flyfishxu/kadb/core/AdbConnection;->supportsFeature(Ljava/lang/String;)Z

    move-result p0

    return p0
.end method

.method public final tcpForward(II)Ljava/lang/AutoCloseable;
    .locals 1

    new-instance v0, Lcom/flyfishxu/kadb/forwarding/TcpForwarder;

    invoke-direct {v0, p0, p1, p2}, Lcom/flyfishxu/kadb/forwarding/TcpForwarder;-><init>(Lcom/flyfishxu/kadb/Kadb;II)V

    invoke-virtual {v0}, Lcom/flyfishxu/kadb/forwarding/TcpForwarder;->start()V

    return-object v0
.end method

.method public final uninstall(Ljava/lang/String;)V
    .locals 3

    const-string v0, "packageName"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "cmd"

    invoke-virtual {p0, v0}, Lcom/flyfishxu/kadb/Kadb;->supportsFeature(Ljava/lang/String;)Z

    move-result v1

    const-string v2, "uninstall"

    if-eqz v1, :cond_0

    const-string v1, "package"

    filled-new-array {v0, v1, v2, p1}, [Ljava/lang/String;

    move-result-object p1

    invoke-static {p1}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object p1

    goto :goto_0

    :cond_0
    const-string v0, "pm"

    filled-new-array {v0, v2, p1}, [Ljava/lang/String;

    move-result-object p1

    invoke-static {p1}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object p1

    :goto_0
    invoke-direct {p0, p1}, Lcom/flyfishxu/kadb/Kadb;->buildShellCommand(Ljava/util/List;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Lcom/flyfishxu/kadb/Kadb;->shell(Ljava/lang/String;)Lcom/flyfishxu/kadb/shell/AdbShellResponse;

    move-result-object p0

    invoke-virtual {p0}, Lcom/flyfishxu/kadb/shell/AdbShellResponse;->getExitCode()I

    move-result p1

    if-nez p1, :cond_1

    return-void

    :cond_1
    invoke-virtual {p0}, Lcom/flyfishxu/kadb/shell/AdbShellResponse;->getAllOutput()Ljava/lang/String;

    move-result-object p0

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v0, "Uninstall failed: "

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    new-instance p1, Ljava/lang/IllegalStateException;

    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {p1, p0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public final unroot()Ljava/lang/String;
    .locals 1

    const-string v0, "unroot:"

    invoke-direct {p0, v0}, Lcom/flyfishxu/kadb/Kadb;->restartAdb(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
