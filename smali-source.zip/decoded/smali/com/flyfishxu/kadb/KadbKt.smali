.class public final Lcom/flyfishxu/kadb/KadbKt;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u0012\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0005\n\u0000\u001a\u0014\u0010\u0000\u001a\u00020\u0001*\u00020\u00022\u0006\u0010\u0003\u001a\u00020\u0004H\u0002\u00a8\u0006\u0005"
    }
    d2 = {
        "readUntil",
        "Lokio/Buffer;",
        "Lokio/BufferedSource;",
        "endByte",
        "",
        "com.github.IndiTheo:kadb"
    }
    k = 0x2
    mv = {
        0x2,
        0x4,
        0x0
    }
    xi = 0x30
.end annotation


# direct methods
.method public static final synthetic access$readUntil(Lokio/BufferedSource;B)Lokio/Buffer;
    .locals 0

    invoke-static {p0, p1}, Lcom/flyfishxu/kadb/KadbKt;->readUntil(Lokio/BufferedSource;B)Lokio/Buffer;

    move-result-object p0

    return-object p0
.end method

.method private static final readUntil(Lokio/BufferedSource;B)Lokio/Buffer;
    .locals 2

    new-instance v0, Lokio/Buffer;

    invoke-direct {v0}, Lokio/Buffer;-><init>()V

    :cond_0
    invoke-interface {p0}, Lokio/BufferedSource;->readByte()B

    move-result v1

    invoke-virtual {v0, v1}, Lokio/Buffer;->writeByte(I)Lokio/Buffer;

    if-ne v1, p1, :cond_0

    return-object v0
.end method
