.class final Lcom/flyfishxu/kadb/Kadb$Companion$pair$2;
.super Lkotlin/coroutines/jvm/internal/SuspendLambda;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/flyfishxu/kadb/Kadb$Companion;->pair(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/coroutines/jvm/internal/SuspendLambda;",
        "Lkotlin/jvm/functions/Function2<",
        "Lkotlinx/coroutines/CoroutineScope;",
        "Lkotlin/coroutines/Continuation<",
        "-",
        "Lkotlin/Unit;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"
    }
    d2 = {
        "<anonymous>",
        "",
        "Lkotlinx/coroutines/CoroutineScope;"
    }
    k = 0x3
    mv = {
        0x2,
        0x4,
        0x0
    }
    xi = 0x30
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.flyfishxu.kadb.Kadb$Companion$pair$2"
    f = "Kadb.kt"
    i = {}
    l = {}
    m = "invokeSuspend"
    n = {}
    nl = {}
    s = {}
    v = 0x2
.end annotation

.annotation build Lkotlin/jvm/internal/SourceDebugExtension;
    value = {
        "SMAP\nKadb.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Kadb.kt\ncom/flyfishxu/kadb/Kadb$Companion$pair$2\n+ 2 Okio.kt\nokio/Okio__OkioKt\n*L\n1#1,532:1\n72#2:533\n58#2,22:534\n*S KotlinDebug\n*F\n+ 1 Kadb.kt\ncom/flyfishxu/kadb/Kadb$Companion$pair$2\n*L\n480#1:533\n480#1:534,22\n*E\n"
    }
.end annotation


# instance fields
.field final synthetic $host:Ljava/lang/String;

.field final synthetic $name:Ljava/lang/String;

.field final synthetic $pairingCode:Ljava/lang/String;

.field final synthetic $port:I

.field label:I


# direct methods
.method public constructor <init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Lkotlin/coroutines/Continuation;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "I",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Lcom/flyfishxu/kadb/Kadb$Companion$pair$2;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, Lcom/flyfishxu/kadb/Kadb$Companion$pair$2;->$host:Ljava/lang/String;

    iput p2, p0, Lcom/flyfishxu/kadb/Kadb$Companion$pair$2;->$port:I

    iput-object p3, p0, Lcom/flyfishxu/kadb/Kadb$Companion$pair$2;->$pairingCode:Ljava/lang/String;

    iput-object p4, p0, Lcom/flyfishxu/kadb/Kadb$Companion$pair$2;->$name:Ljava/lang/String;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p5}, Lkotlin/coroutines/jvm/internal/SuspendLambda;-><init>(ILkotlin/coroutines/Continuation;)V

    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "Lkotlin/coroutines/Continuation<",
            "*>;)",
            "Lkotlin/coroutines/Continuation<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    new-instance p1, Lcom/flyfishxu/kadb/Kadb$Companion$pair$2;

    iget-object v1, p0, Lcom/flyfishxu/kadb/Kadb$Companion$pair$2;->$host:Ljava/lang/String;

    iget v2, p0, Lcom/flyfishxu/kadb/Kadb$Companion$pair$2;->$port:I

    iget-object v3, p0, Lcom/flyfishxu/kadb/Kadb$Companion$pair$2;->$pairingCode:Ljava/lang/String;

    iget-object v4, p0, Lcom/flyfishxu/kadb/Kadb$Companion$pair$2;->$name:Ljava/lang/String;

    move-object v0, p1

    move-object v5, p2

    invoke-direct/range {v0 .. v5}, Lcom/flyfishxu/kadb/Kadb$Companion$pair$2;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Lkotlin/coroutines/Continuation;)V

    return-object p1
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lkotlinx/coroutines/CoroutineScope;

    check-cast p2, Lkotlin/coroutines/Continuation;

    invoke-virtual {p0, p1, p2}, Lcom/flyfishxu/kadb/Kadb$Companion$pair$2;->invoke(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public final invoke(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/CoroutineScope;",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 2
    invoke-virtual {p0, p1, p2}, Lcom/flyfishxu/kadb/Kadb$Companion$pair$2;->create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;

    move-result-object p0

    check-cast p0, Lcom/flyfishxu/kadb/Kadb$Companion$pair$2;

    sget-object p1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    invoke-virtual {p0, p1}, Lcom/flyfishxu/kadb/Kadb$Companion$pair$2;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 7

    invoke-static {}, Lkotlin/coroutines/intrinsics/IntrinsicsKt;->getCOROUTINE_SUSPENDED()Ljava/lang/Object;

    iget v0, p0, Lcom/flyfishxu/kadb/Kadb$Companion$pair$2;->label:I

    if-nez v0, :cond_1

    invoke-static {p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    new-instance p1, Lcom/flyfishxu/kadb/pair/PairingConnectionCtx;

    iget-object v2, p0, Lcom/flyfishxu/kadb/Kadb$Companion$pair$2;->$host:Ljava/lang/String;

    iget v3, p0, Lcom/flyfishxu/kadb/Kadb$Companion$pair$2;->$port:I

    iget-object v0, p0, Lcom/flyfishxu/kadb/Kadb$Companion$pair$2;->$pairingCode:Ljava/lang/String;

    sget-object v1, Lkotlin/text/Charsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-virtual {v0, v1}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v4

    const-string v0, "getBytes(...)"

    invoke-static {v4, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object v0, Lcom/flyfishxu/kadb/cert/CertUtils;->INSTANCE:Lcom/flyfishxu/kadb/cert/CertUtils;

    invoke-virtual {v0}, Lcom/flyfishxu/kadb/cert/CertUtils;->loadKeyPair()Lcom/flyfishxu/kadb/cert/AdbKeyPair;

    move-result-object v5

    iget-object v6, p0, Lcom/flyfishxu/kadb/Kadb$Companion$pair$2;->$name:Ljava/lang/String;

    move-object v1, p1

    invoke-direct/range {v1 .. v6}, Lcom/flyfishxu/kadb/pair/PairingConnectionCtx;-><init>(Ljava/lang/String;I[BLcom/flyfishxu/kadb/cert/AdbKeyPair;Ljava/lang/String;)V

    :try_start_0
    invoke-virtual {p1}, Lcom/flyfishxu/kadb/pair/PairingConnectionCtx;->start()V

    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    :try_start_1
    invoke-interface {p1}, Ljava/io/Closeable;->close()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 p0, 0x0

    goto :goto_0

    :catchall_0
    move-exception p0

    goto :goto_0

    :catchall_1
    move-exception p0

    :try_start_2
    invoke-interface {p1}, Ljava/io/Closeable;->close()V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_2

    goto :goto_0

    :catchall_2
    move-exception p1

    invoke-static {p0, p1}, Lkotlin/ExceptionsKt;->addSuppressed(Ljava/lang/Throwable;Ljava/lang/Throwable;)V

    :goto_0
    if-nez p0, :cond_0

    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0

    :cond_0
    throw p0

    :cond_1
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string p1, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0
.end method
