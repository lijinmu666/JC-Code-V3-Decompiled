.class public final Landroidx/coordinatorlayout/widget/CoordinatorLayout$xJ$mjFkc;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/os/Parcelable$ClassLoaderCreator;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/coordinatorlayout/widget/CoordinatorLayout$xJ;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public AZxh(Landroid/os/Parcel;Ljava/lang/ClassLoader;)Landroidx/coordinatorlayout/widget/CoordinatorLayout$xJ;
    .locals 0

    new-instance p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$xJ;

    invoke-direct {p0, p1, p2}, Landroidx/coordinatorlayout/widget/CoordinatorLayout$xJ;-><init>(Landroid/os/Parcel;Ljava/lang/ClassLoader;)V

    return-object p0
.end method

.method public bridge synthetic createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;
    .locals 0

    .line 1
    invoke-virtual {p0, p1}, Landroidx/coordinatorlayout/widget/CoordinatorLayout$xJ$mjFkc;->mjFkc(Landroid/os/Parcel;)Landroidx/coordinatorlayout/widget/CoordinatorLayout$xJ;

    move-result-object p0

    return-object p0
.end method

.method public bridge synthetic createFromParcel(Landroid/os/Parcel;Ljava/lang/ClassLoader;)Ljava/lang/Object;
    .locals 0

    .line 2
    invoke-virtual {p0, p1, p2}, Landroidx/coordinatorlayout/widget/CoordinatorLayout$xJ$mjFkc;->AZxh(Landroid/os/Parcel;Ljava/lang/ClassLoader;)Landroidx/coordinatorlayout/widget/CoordinatorLayout$xJ;

    move-result-object p0

    return-object p0
.end method

.method public mjFkc(Landroid/os/Parcel;)Landroidx/coordinatorlayout/widget/CoordinatorLayout$xJ;
    .locals 1

    new-instance p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$xJ;

    const/4 v0, 0x0

    invoke-direct {p0, p1, v0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout$xJ;-><init>(Landroid/os/Parcel;Ljava/lang/ClassLoader;)V

    return-object p0
.end method

.method public bridge synthetic newArray(I)[Ljava/lang/Object;
    .locals 0

    invoke-virtual {p0, p1}, Landroidx/coordinatorlayout/widget/CoordinatorLayout$xJ$mjFkc;->wA(I)[Landroidx/coordinatorlayout/widget/CoordinatorLayout$xJ;

    move-result-object p0

    return-object p0
.end method

.method public wA(I)[Landroidx/coordinatorlayout/widget/CoordinatorLayout$xJ;
    .locals 0

    new-array p0, p1, [Landroidx/coordinatorlayout/widget/CoordinatorLayout$xJ;

    return-object p0
.end method
