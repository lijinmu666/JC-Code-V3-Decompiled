.class public final Landroidx/core/app/RemoteActionCompat;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lo/Q9;


# instance fields
.field public AZxh:Ljava/lang/CharSequence;

.field public JHa:Z

.field public KLFTb:Z

.field public ZfxDd:Landroid/app/PendingIntent;

.field public mjFkc:Landroidx/core/graphics/drawable/IconCompat;

.field public wA:Ljava/lang/CharSequence;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
