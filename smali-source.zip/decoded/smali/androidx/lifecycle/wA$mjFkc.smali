.class public final enum Landroidx/lifecycle/wA$mjFkc;
.super Ljava/lang/Enum;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/lifecycle/wA;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4019
    name = "mjFkc"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/lifecycle/wA$mjFkc$mjFkc;,
        Landroidx/lifecycle/wA$mjFkc$AZxh;
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Landroidx/lifecycle/wA$mjFkc;

.field public static final Companion:Landroidx/lifecycle/wA$mjFkc$mjFkc;

.field public static final enum ON_ANY:Landroidx/lifecycle/wA$mjFkc;

.field public static final enum ON_CREATE:Landroidx/lifecycle/wA$mjFkc;

.field public static final enum ON_DESTROY:Landroidx/lifecycle/wA$mjFkc;

.field public static final enum ON_PAUSE:Landroidx/lifecycle/wA$mjFkc;

.field public static final enum ON_RESUME:Landroidx/lifecycle/wA$mjFkc;

.field public static final enum ON_START:Landroidx/lifecycle/wA$mjFkc;

.field public static final enum ON_STOP:Landroidx/lifecycle/wA$mjFkc;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    new-instance v0, Landroidx/lifecycle/wA$mjFkc;

    const-string v1, "ON_CREATE"

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2}, Landroidx/lifecycle/wA$mjFkc;-><init>(Ljava/lang/String;I)V

    sput-object v0, Landroidx/lifecycle/wA$mjFkc;->ON_CREATE:Landroidx/lifecycle/wA$mjFkc;

    new-instance v0, Landroidx/lifecycle/wA$mjFkc;

    const-string v1, "ON_START"

    const/4 v2, 0x1

    invoke-direct {v0, v1, v2}, Landroidx/lifecycle/wA$mjFkc;-><init>(Ljava/lang/String;I)V

    sput-object v0, Landroidx/lifecycle/wA$mjFkc;->ON_START:Landroidx/lifecycle/wA$mjFkc;

    new-instance v0, Landroidx/lifecycle/wA$mjFkc;

    const-string v1, "ON_RESUME"

    const/4 v2, 0x2

    invoke-direct {v0, v1, v2}, Landroidx/lifecycle/wA$mjFkc;-><init>(Ljava/lang/String;I)V

    sput-object v0, Landroidx/lifecycle/wA$mjFkc;->ON_RESUME:Landroidx/lifecycle/wA$mjFkc;

    new-instance v0, Landroidx/lifecycle/wA$mjFkc;

    const-string v1, "ON_PAUSE"

    const/4 v2, 0x3

    invoke-direct {v0, v1, v2}, Landroidx/lifecycle/wA$mjFkc;-><init>(Ljava/lang/String;I)V

    sput-object v0, Landroidx/lifecycle/wA$mjFkc;->ON_PAUSE:Landroidx/lifecycle/wA$mjFkc;

    new-instance v0, Landroidx/lifecycle/wA$mjFkc;

    const-string v1, "ON_STOP"

    const/4 v2, 0x4

    invoke-direct {v0, v1, v2}, Landroidx/lifecycle/wA$mjFkc;-><init>(Ljava/lang/String;I)V

    sput-object v0, Landroidx/lifecycle/wA$mjFkc;->ON_STOP:Landroidx/lifecycle/wA$mjFkc;

    new-instance v0, Landroidx/lifecycle/wA$mjFkc;

    const-string v1, "ON_DESTROY"

    const/4 v2, 0x5

    invoke-direct {v0, v1, v2}, Landroidx/lifecycle/wA$mjFkc;-><init>(Ljava/lang/String;I)V

    sput-object v0, Landroidx/lifecycle/wA$mjFkc;->ON_DESTROY:Landroidx/lifecycle/wA$mjFkc;

    new-instance v0, Landroidx/lifecycle/wA$mjFkc;

    const-string v1, "ON_ANY"

    const/4 v2, 0x6

    invoke-direct {v0, v1, v2}, Landroidx/lifecycle/wA$mjFkc;-><init>(Ljava/lang/String;I)V

    sput-object v0, Landroidx/lifecycle/wA$mjFkc;->ON_ANY:Landroidx/lifecycle/wA$mjFkc;

    invoke-static {}, Landroidx/lifecycle/wA$mjFkc;->KLFTb()[Landroidx/lifecycle/wA$mjFkc;

    move-result-object v0

    sput-object v0, Landroidx/lifecycle/wA$mjFkc;->$VALUES:[Landroidx/lifecycle/wA$mjFkc;

    new-instance v0, Landroidx/lifecycle/wA$mjFkc$mjFkc;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Landroidx/lifecycle/wA$mjFkc$mjFkc;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    sput-object v0, Landroidx/lifecycle/wA$mjFkc;->Companion:Landroidx/lifecycle/wA$mjFkc$mjFkc;

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;I)V
    .locals 0

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    return-void
.end method

.method public static final synthetic KLFTb()[Landroidx/lifecycle/wA$mjFkc;
    .locals 7

    sget-object v0, Landroidx/lifecycle/wA$mjFkc;->ON_CREATE:Landroidx/lifecycle/wA$mjFkc;

    sget-object v1, Landroidx/lifecycle/wA$mjFkc;->ON_START:Landroidx/lifecycle/wA$mjFkc;

    sget-object v2, Landroidx/lifecycle/wA$mjFkc;->ON_RESUME:Landroidx/lifecycle/wA$mjFkc;

    sget-object v3, Landroidx/lifecycle/wA$mjFkc;->ON_PAUSE:Landroidx/lifecycle/wA$mjFkc;

    sget-object v4, Landroidx/lifecycle/wA$mjFkc;->ON_STOP:Landroidx/lifecycle/wA$mjFkc;

    sget-object v5, Landroidx/lifecycle/wA$mjFkc;->ON_DESTROY:Landroidx/lifecycle/wA$mjFkc;

    sget-object v6, Landroidx/lifecycle/wA$mjFkc;->ON_ANY:Landroidx/lifecycle/wA$mjFkc;

    filled-new-array/range {v0 .. v6}, [Landroidx/lifecycle/wA$mjFkc;

    move-result-object v0

    return-object v0
.end method

.method public static valueOf(Ljava/lang/String;)Landroidx/lifecycle/wA$mjFkc;
    .locals 1

    const-class v0, Landroidx/lifecycle/wA$mjFkc;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, Landroidx/lifecycle/wA$mjFkc;

    return-object p0
.end method

.method public static values()[Landroidx/lifecycle/wA$mjFkc;
    .locals 1

    sget-object v0, Landroidx/lifecycle/wA$mjFkc;->$VALUES:[Landroidx/lifecycle/wA$mjFkc;

    invoke-virtual {v0}, [Ljava/lang/Object;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Landroidx/lifecycle/wA$mjFkc;

    return-object v0
.end method


# virtual methods
.method public final lgHUyS()Landroidx/lifecycle/wA$AZxh;
    .locals 2

    sget-object v0, Landroidx/lifecycle/wA$mjFkc$AZxh;->mjFkc:[I

    invoke-virtual {p0}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    aget v0, v0, v1

    packed-switch v0, :pswitch_data_0

    new-instance v0, Ljava/lang/IllegalArgumentException;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p0, " has no target state"

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :pswitch_0
    sget-object p0, Landroidx/lifecycle/wA$AZxh;->mjFkc:Landroidx/lifecycle/wA$AZxh;

    return-object p0

    :pswitch_1
    sget-object p0, Landroidx/lifecycle/wA$AZxh;->KLFTb:Landroidx/lifecycle/wA$AZxh;

    return-object p0

    :pswitch_2
    sget-object p0, Landroidx/lifecycle/wA$AZxh;->ZfxDd:Landroidx/lifecycle/wA$AZxh;

    return-object p0

    :pswitch_3
    sget-object p0, Landroidx/lifecycle/wA$AZxh;->wA:Landroidx/lifecycle/wA$AZxh;

    return-object p0

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_3
        :pswitch_3
        :pswitch_2
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
