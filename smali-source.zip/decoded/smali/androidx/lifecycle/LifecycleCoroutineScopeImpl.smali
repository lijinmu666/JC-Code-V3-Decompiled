.class public final Landroidx/lifecycle/LifecycleCoroutineScopeImpl;
.super Lo/T0;
.source "SourceFile"

# interfaces
.implements Landroidx/lifecycle/KLFTb;


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u00000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0004\n\u0002\u0018\u0002\n\u0002\u0008\u0006\u0008\u0000\u0018\u00002\u00020\u00012\u00020\u0002J\u001f\u0010\u0008\u001a\u00020\u00072\u0006\u0010\u0004\u001a\u00020\u00032\u0006\u0010\u0006\u001a\u00020\u0005H\u0016\u00a2\u0006\u0004\u0008\u0008\u0010\tR\u001a\u0010\u000e\u001a\u00020\n8\u0010X\u0090\u0004\u00a2\u0006\u000c\n\u0004\u0008\u000b\u0010\u000c\u001a\u0004\u0008\u000b\u0010\rR\u001a\u0010\u0014\u001a\u00020\u000f8\u0016X\u0096\u0004\u00a2\u0006\u000c\n\u0004\u0008\u0010\u0010\u0011\u001a\u0004\u0008\u0012\u0010\u0013\u00a8\u0006\u0015"
    }
    d2 = {
        "Landroidx/lifecycle/LifecycleCoroutineScopeImpl;",
        "Lo/T0;",
        "Landroidx/lifecycle/KLFTb;",
        "Lo/W0;",
        "source",
        "Landroidx/lifecycle/wA$mjFkc;",
        "event",
        "",
        "VA",
        "(Lo/W0;Landroidx/lifecycle/wA$mjFkc;)V",
        "Landroidx/lifecycle/wA;",
        "mjFkc",
        "Landroidx/lifecycle/wA;",
        "()Landroidx/lifecycle/wA;",
        "lifecycle",
        "Lkotlin/coroutines/CoroutineContext;",
        "AZxh",
        "Lkotlin/coroutines/CoroutineContext;",
        "getCoroutineContext",
        "()Lkotlin/coroutines/CoroutineContext;",
        "coroutineContext",
        "lifecycle-common"
    }
    k = 0x1
    mv = {
        0x1,
        0x8,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field public final AZxh:Lkotlin/coroutines/CoroutineContext;

.field public final mjFkc:Landroidx/lifecycle/wA;


# virtual methods
.method public VA(Lo/W0;Landroidx/lifecycle/wA$mjFkc;)V
    .locals 1

    const-string v0, "source"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string p1, "event"

    invoke-static {p2, p1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p0}, Landroidx/lifecycle/LifecycleCoroutineScopeImpl;->mjFkc()Landroidx/lifecycle/wA;

    move-result-object p1

    invoke-virtual {p1}, Landroidx/lifecycle/wA;->AZxh()Landroidx/lifecycle/wA$AZxh;

    move-result-object p1

    sget-object p2, Landroidx/lifecycle/wA$AZxh;->mjFkc:Landroidx/lifecycle/wA$AZxh;

    invoke-virtual {p1, p2}, Ljava/lang/Enum;->compareTo(Ljava/lang/Enum;)I

    move-result p1

    if-gtz p1, :cond_0

    invoke-virtual {p0}, Landroidx/lifecycle/LifecycleCoroutineScopeImpl;->mjFkc()Landroidx/lifecycle/wA;

    move-result-object p1

    invoke-virtual {p1, p0}, Landroidx/lifecycle/wA;->wA(Lo/V0;)V

    invoke-virtual {p0}, Landroidx/lifecycle/LifecycleCoroutineScopeImpl;->getCoroutineContext()Lkotlin/coroutines/CoroutineContext;

    move-result-object p0

    const/4 p1, 0x1

    const/4 p2, 0x0

    invoke-static {p0, p2, p1, p2}, Lkotlinx/coroutines/JobKt;->cancel$default(Lkotlin/coroutines/CoroutineContext;Ljava/util/concurrent/CancellationException;ILjava/lang/Object;)V

    :cond_0
    return-void
.end method

.method public getCoroutineContext()Lkotlin/coroutines/CoroutineContext;
    .locals 0

    iget-object p0, p0, Landroidx/lifecycle/LifecycleCoroutineScopeImpl;->AZxh:Lkotlin/coroutines/CoroutineContext;

    return-object p0
.end method

.method public mjFkc()Landroidx/lifecycle/wA;
    .locals 0

    iget-object p0, p0, Landroidx/lifecycle/LifecycleCoroutineScopeImpl;->mjFkc:Landroidx/lifecycle/wA;

    return-object p0
.end method
