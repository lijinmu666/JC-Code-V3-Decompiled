.class public final Landroidx/lifecycle/qdMbNW$AZxh;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/lifecycle/qdMbNW;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "AZxh"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Landroidx/lifecycle/qdMbNW$AZxh;-><init>()V

    return-void
.end method


# virtual methods
.method public final AZxh(Landroid/content/Context;)V
    .locals 0

    const-string p0, "context"

    invoke-static {p1, p0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {}, Landroidx/lifecycle/qdMbNW;->wA()Landroidx/lifecycle/qdMbNW;

    move-result-object p0

    invoke-virtual {p0, p1}, Landroidx/lifecycle/qdMbNW;->qdMbNW(Landroid/content/Context;)V

    return-void
.end method

.method public final mjFkc()Lo/W0;
    .locals 0

    invoke-static {}, Landroidx/lifecycle/qdMbNW;->wA()Landroidx/lifecycle/qdMbNW;

    move-result-object p0

    return-object p0
.end method
