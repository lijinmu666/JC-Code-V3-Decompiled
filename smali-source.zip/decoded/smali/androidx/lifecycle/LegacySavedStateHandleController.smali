.class public final Landroidx/lifecycle/LegacySavedStateHandleController;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/lifecycle/LegacySavedStateHandleController$mjFkc;
    }
.end annotation


# static fields
.field public static final mjFkc:Landroidx/lifecycle/LegacySavedStateHandleController;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, Landroidx/lifecycle/LegacySavedStateHandleController;

    invoke-direct {v0}, Landroidx/lifecycle/LegacySavedStateHandleController;-><init>()V

    sput-object v0, Landroidx/lifecycle/LegacySavedStateHandleController;->mjFkc:Landroidx/lifecycle/LegacySavedStateHandleController;

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static final mjFkc(Lo/ga;Landroidx/savedstate/mjFkc;Landroidx/lifecycle/wA;)V
    .locals 1

    const-string v0, "viewModel"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "registry"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "lifecycle"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "androidx.lifecycle.savedstate.vm.tag"

    invoke-virtual {p0, v0}, Lo/ga;->mjFkc(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroidx/lifecycle/SavedStateHandleController;

    if-eqz p0, :cond_0

    invoke-virtual {p0}, Landroidx/lifecycle/SavedStateHandleController;->AZxh()Z

    move-result v0

    if-nez v0, :cond_0

    invoke-virtual {p0, p1, p2}, Landroidx/lifecycle/SavedStateHandleController;->mjFkc(Landroidx/savedstate/mjFkc;Landroidx/lifecycle/wA;)V

    sget-object p0, Landroidx/lifecycle/LegacySavedStateHandleController;->mjFkc:Landroidx/lifecycle/LegacySavedStateHandleController;

    invoke-virtual {p0, p1, p2}, Landroidx/lifecycle/LegacySavedStateHandleController;->AZxh(Landroidx/savedstate/mjFkc;Landroidx/lifecycle/wA;)V

    :cond_0
    return-void
.end method


# virtual methods
.method public final AZxh(Landroidx/savedstate/mjFkc;Landroidx/lifecycle/wA;)V
    .locals 1

    invoke-virtual {p2}, Landroidx/lifecycle/wA;->AZxh()Landroidx/lifecycle/wA$AZxh;

    move-result-object p0

    sget-object v0, Landroidx/lifecycle/wA$AZxh;->AZxh:Landroidx/lifecycle/wA$AZxh;

    if-eq p0, v0, :cond_1

    sget-object v0, Landroidx/lifecycle/wA$AZxh;->ZfxDd:Landroidx/lifecycle/wA$AZxh;

    invoke-virtual {p0, v0}, Landroidx/lifecycle/wA$AZxh;->lgHUyS(Landroidx/lifecycle/wA$AZxh;)Z

    move-result p0

    if-eqz p0, :cond_0

    goto :goto_0

    :cond_0
    new-instance p0, Landroidx/lifecycle/LegacySavedStateHandleController$tryToAddRecreator$1;

    invoke-direct {p0, p2, p1}, Landroidx/lifecycle/LegacySavedStateHandleController$tryToAddRecreator$1;-><init>(Landroidx/lifecycle/wA;Landroidx/savedstate/mjFkc;)V

    invoke-virtual {p2, p0}, Landroidx/lifecycle/wA;->mjFkc(Lo/V0;)V

    goto :goto_1

    :cond_1
    :goto_0
    const-class p0, Landroidx/lifecycle/LegacySavedStateHandleController$mjFkc;

    invoke-virtual {p1, p0}, Landroidx/savedstate/mjFkc;->lgHUyS(Ljava/lang/Class;)V

    :goto_1
    return-void
.end method
