.class public final Landroidx/lifecycle/qdMbNW;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lo/W0;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/lifecycle/qdMbNW$mjFkc;,
        Landroidx/lifecycle/qdMbNW$AZxh;
    }
.end annotation


# static fields
.field public static final Dt:Landroidx/lifecycle/qdMbNW;

.field public static final qdMbNW:Landroidx/lifecycle/qdMbNW$AZxh;


# instance fields
.field public AZxh:I

.field public final JHa:Landroidx/lifecycle/JHa;

.field public KLFTb:Landroid/os/Handler;

.field public ZfxDd:Z

.field public final lgHUyS:Landroidx/lifecycle/Dt$mjFkc;

.field public mjFkc:I

.field public wA:Z

.field public final xJ:Ljava/lang/Runnable;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    new-instance v0, Landroidx/lifecycle/qdMbNW$AZxh;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Landroidx/lifecycle/qdMbNW$AZxh;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    sput-object v0, Landroidx/lifecycle/qdMbNW;->qdMbNW:Landroidx/lifecycle/qdMbNW$AZxh;

    new-instance v0, Landroidx/lifecycle/qdMbNW;

    invoke-direct {v0}, Landroidx/lifecycle/qdMbNW;-><init>()V

    sput-object v0, Landroidx/lifecycle/qdMbNW;->Dt:Landroidx/lifecycle/qdMbNW;

    return-void
.end method

.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x1

    iput-boolean v0, p0, Landroidx/lifecycle/qdMbNW;->wA:Z

    iput-boolean v0, p0, Landroidx/lifecycle/qdMbNW;->ZfxDd:Z

    new-instance v0, Landroidx/lifecycle/JHa;

    invoke-direct {v0, p0}, Landroidx/lifecycle/JHa;-><init>(Lo/W0;)V

    iput-object v0, p0, Landroidx/lifecycle/qdMbNW;->JHa:Landroidx/lifecycle/JHa;

    new-instance v0, Lo/O3;

    invoke-direct {v0, p0}, Lo/O3;-><init>(Landroidx/lifecycle/qdMbNW;)V

    iput-object v0, p0, Landroidx/lifecycle/qdMbNW;->xJ:Ljava/lang/Runnable;

    new-instance v0, Landroidx/lifecycle/qdMbNW$ZfxDd;

    invoke-direct {v0, p0}, Landroidx/lifecycle/qdMbNW$ZfxDd;-><init>(Landroidx/lifecycle/qdMbNW;)V

    iput-object v0, p0, Landroidx/lifecycle/qdMbNW;->lgHUyS:Landroidx/lifecycle/Dt$mjFkc;

    return-void
.end method

.method public static synthetic AZxh(Landroidx/lifecycle/qdMbNW;)V
    .locals 0

    invoke-static {p0}, Landroidx/lifecycle/qdMbNW;->Dt(Landroidx/lifecycle/qdMbNW;)V

    return-void
.end method

.method public static final Dt(Landroidx/lifecycle/qdMbNW;)V
    .locals 1

    const-string v0, "this$0"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p0}, Landroidx/lifecycle/qdMbNW;->ETF()V

    invoke-virtual {p0}, Landroidx/lifecycle/qdMbNW;->VA()V

    return-void
.end method

.method public static final synthetic wA()Landroidx/lifecycle/qdMbNW;
    .locals 1

    sget-object v0, Landroidx/lifecycle/qdMbNW;->Dt:Landroidx/lifecycle/qdMbNW;

    return-object v0
.end method


# virtual methods
.method public final ETF()V
    .locals 1

    iget v0, p0, Landroidx/lifecycle/qdMbNW;->AZxh:I

    if-nez v0, :cond_0

    const/4 v0, 0x1

    iput-boolean v0, p0, Landroidx/lifecycle/qdMbNW;->wA:Z

    iget-object p0, p0, Landroidx/lifecycle/qdMbNW;->JHa:Landroidx/lifecycle/JHa;

    sget-object v0, Landroidx/lifecycle/wA$mjFkc;->ON_PAUSE:Landroidx/lifecycle/wA$mjFkc;

    invoke-virtual {p0, v0}, Landroidx/lifecycle/JHa;->lgHUyS(Landroidx/lifecycle/wA$mjFkc;)V

    :cond_0
    return-void
.end method

.method public JHa()Landroidx/lifecycle/wA;
    .locals 0

    iget-object p0, p0, Landroidx/lifecycle/qdMbNW;->JHa:Landroidx/lifecycle/JHa;

    return-object p0
.end method

.method public final KLFTb()V
    .locals 2

    iget v0, p0, Landroidx/lifecycle/qdMbNW;->AZxh:I

    const/4 v1, 0x1

    add-int/2addr v0, v1

    iput v0, p0, Landroidx/lifecycle/qdMbNW;->AZxh:I

    if-ne v0, v1, :cond_1

    iget-boolean v0, p0, Landroidx/lifecycle/qdMbNW;->wA:Z

    if-eqz v0, :cond_0

    iget-object v0, p0, Landroidx/lifecycle/qdMbNW;->JHa:Landroidx/lifecycle/JHa;

    sget-object v1, Landroidx/lifecycle/wA$mjFkc;->ON_RESUME:Landroidx/lifecycle/wA$mjFkc;

    invoke-virtual {v0, v1}, Landroidx/lifecycle/JHa;->lgHUyS(Landroidx/lifecycle/wA$mjFkc;)V

    const/4 v0, 0x0

    iput-boolean v0, p0, Landroidx/lifecycle/qdMbNW;->wA:Z

    goto :goto_0

    :cond_0
    iget-object v0, p0, Landroidx/lifecycle/qdMbNW;->KLFTb:Landroid/os/Handler;

    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    iget-object p0, p0, Landroidx/lifecycle/qdMbNW;->xJ:Ljava/lang/Runnable;

    invoke-virtual {v0, p0}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    :cond_1
    :goto_0
    return-void
.end method

.method public final VA()V
    .locals 2

    iget v0, p0, Landroidx/lifecycle/qdMbNW;->mjFkc:I

    if-nez v0, :cond_0

    iget-boolean v0, p0, Landroidx/lifecycle/qdMbNW;->wA:Z

    if-eqz v0, :cond_0

    iget-object v0, p0, Landroidx/lifecycle/qdMbNW;->JHa:Landroidx/lifecycle/JHa;

    sget-object v1, Landroidx/lifecycle/wA$mjFkc;->ON_STOP:Landroidx/lifecycle/wA$mjFkc;

    invoke-virtual {v0, v1}, Landroidx/lifecycle/JHa;->lgHUyS(Landroidx/lifecycle/wA$mjFkc;)V

    const/4 v0, 0x1

    iput-boolean v0, p0, Landroidx/lifecycle/qdMbNW;->ZfxDd:Z

    :cond_0
    return-void
.end method

.method public final ZfxDd()V
    .locals 3

    iget v0, p0, Landroidx/lifecycle/qdMbNW;->AZxh:I

    add-int/lit8 v0, v0, -0x1

    iput v0, p0, Landroidx/lifecycle/qdMbNW;->AZxh:I

    if-nez v0, :cond_0

    iget-object v0, p0, Landroidx/lifecycle/qdMbNW;->KLFTb:Landroid/os/Handler;

    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    iget-object p0, p0, Landroidx/lifecycle/qdMbNW;->xJ:Ljava/lang/Runnable;

    const-wide/16 v1, 0x2bc

    invoke-virtual {v0, p0, v1, v2}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    :cond_0
    return-void
.end method

.method public final lgHUyS()V
    .locals 1

    iget v0, p0, Landroidx/lifecycle/qdMbNW;->mjFkc:I

    add-int/lit8 v0, v0, -0x1

    iput v0, p0, Landroidx/lifecycle/qdMbNW;->mjFkc:I

    invoke-virtual {p0}, Landroidx/lifecycle/qdMbNW;->VA()V

    return-void
.end method

.method public final qdMbNW(Landroid/content/Context;)V
    .locals 2

    const-string v0, "context"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v0, Landroid/os/Handler;

    invoke-direct {v0}, Landroid/os/Handler;-><init>()V

    iput-object v0, p0, Landroidx/lifecycle/qdMbNW;->KLFTb:Landroid/os/Handler;

    iget-object v0, p0, Landroidx/lifecycle/qdMbNW;->JHa:Landroidx/lifecycle/JHa;

    sget-object v1, Landroidx/lifecycle/wA$mjFkc;->ON_CREATE:Landroidx/lifecycle/wA$mjFkc;

    invoke-virtual {v0, v1}, Landroidx/lifecycle/JHa;->lgHUyS(Landroidx/lifecycle/wA$mjFkc;)V

    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    const-string v0, "null cannot be cast to non-null type android.app.Application"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast p1, Landroid/app/Application;

    new-instance v0, Landroidx/lifecycle/qdMbNW$wA;

    invoke-direct {v0, p0}, Landroidx/lifecycle/qdMbNW$wA;-><init>(Landroidx/lifecycle/qdMbNW;)V

    invoke-virtual {p1, v0}, Landroid/app/Application;->registerActivityLifecycleCallbacks(Landroid/app/Application$ActivityLifecycleCallbacks;)V

    return-void
.end method

.method public final xJ()V
    .locals 2

    iget v0, p0, Landroidx/lifecycle/qdMbNW;->mjFkc:I

    const/4 v1, 0x1

    add-int/2addr v0, v1

    iput v0, p0, Landroidx/lifecycle/qdMbNW;->mjFkc:I

    if-ne v0, v1, :cond_0

    iget-boolean v0, p0, Landroidx/lifecycle/qdMbNW;->ZfxDd:Z

    if-eqz v0, :cond_0

    iget-object v0, p0, Landroidx/lifecycle/qdMbNW;->JHa:Landroidx/lifecycle/JHa;

    sget-object v1, Landroidx/lifecycle/wA$mjFkc;->ON_START:Landroidx/lifecycle/wA$mjFkc;

    invoke-virtual {v0, v1}, Landroidx/lifecycle/JHa;->lgHUyS(Landroidx/lifecycle/wA$mjFkc;)V

    const/4 v0, 0x0

    iput-boolean v0, p0, Landroidx/lifecycle/qdMbNW;->ZfxDd:Z

    :cond_0
    return-void
.end method
