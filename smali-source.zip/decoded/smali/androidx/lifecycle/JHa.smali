.class public Landroidx/lifecycle/JHa;
.super Landroidx/lifecycle/wA;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/lifecycle/JHa$mjFkc;,
        Landroidx/lifecycle/JHa$AZxh;
    }
.end annotation


# static fields
.field public static final Dt:Landroidx/lifecycle/JHa$mjFkc;


# instance fields
.field public final AZxh:Z

.field public JHa:I

.field public final KLFTb:Ljava/lang/ref/WeakReference;

.field public ZfxDd:Landroidx/lifecycle/wA$AZxh;

.field public lgHUyS:Z

.field public qdMbNW:Ljava/util/ArrayList;

.field public wA:Lo/tyXzYJ;

.field public xJ:Z


# direct methods
.method static constructor <clinit>()V
    .locals 2

    new-instance v0, Landroidx/lifecycle/JHa$mjFkc;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Landroidx/lifecycle/JHa$mjFkc;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    sput-object v0, Landroidx/lifecycle/JHa;->Dt:Landroidx/lifecycle/JHa$mjFkc;

    return-void
.end method

.method public constructor <init>(Lo/W0;)V
    .locals 1

    const-string v0, "provider"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v0, 0x1

    .line 7
    invoke-direct {p0, p1, v0}, Landroidx/lifecycle/JHa;-><init>(Lo/W0;Z)V

    return-void
.end method

.method public constructor <init>(Lo/W0;Z)V
    .locals 0

    .line 1
    invoke-direct {p0}, Landroidx/lifecycle/wA;-><init>()V

    .line 2
    iput-boolean p2, p0, Landroidx/lifecycle/JHa;->AZxh:Z

    .line 3
    new-instance p2, Lo/tyXzYJ;

    invoke-direct {p2}, Lo/tyXzYJ;-><init>()V

    iput-object p2, p0, Landroidx/lifecycle/JHa;->wA:Lo/tyXzYJ;

    .line 4
    sget-object p2, Landroidx/lifecycle/wA$AZxh;->AZxh:Landroidx/lifecycle/wA$AZxh;

    iput-object p2, p0, Landroidx/lifecycle/JHa;->ZfxDd:Landroidx/lifecycle/wA$AZxh;

    .line 5
    new-instance p2, Ljava/util/ArrayList;

    invoke-direct {p2}, Ljava/util/ArrayList;-><init>()V

    iput-object p2, p0, Landroidx/lifecycle/JHa;->qdMbNW:Ljava/util/ArrayList;

    .line 6
    new-instance p2, Ljava/lang/ref/WeakReference;

    invoke-direct {p2, p1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    iput-object p2, p0, Landroidx/lifecycle/JHa;->KLFTb:Ljava/lang/ref/WeakReference;

    return-void
.end method


# virtual methods
.method public AZxh()Landroidx/lifecycle/wA$AZxh;
    .locals 0

    iget-object p0, p0, Landroidx/lifecycle/JHa;->ZfxDd:Landroidx/lifecycle/wA$AZxh;

    return-object p0
.end method

.method public final Dt(Landroidx/lifecycle/wA$AZxh;)V
    .locals 2

    iget-object v0, p0, Landroidx/lifecycle/JHa;->ZfxDd:Landroidx/lifecycle/wA$AZxh;

    if-ne v0, p1, :cond_0

    return-void

    :cond_0
    sget-object v1, Landroidx/lifecycle/wA$AZxh;->AZxh:Landroidx/lifecycle/wA$AZxh;

    if-ne v0, v1, :cond_2

    sget-object v0, Landroidx/lifecycle/wA$AZxh;->mjFkc:Landroidx/lifecycle/wA$AZxh;

    if-eq p1, v0, :cond_1

    goto :goto_0

    :cond_1
    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v0, "no event down from "

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v0, p0, Landroidx/lifecycle/JHa;->ZfxDd:Landroidx/lifecycle/wA$AZxh;

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v0, " in component "

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object p0, p0, Landroidx/lifecycle/JHa;->KLFTb:Ljava/lang/ref/WeakReference;

    invoke-virtual {p0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object p0

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    new-instance p1, Ljava/lang/IllegalStateException;

    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {p1, p0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_2
    :goto_0
    iput-object p1, p0, Landroidx/lifecycle/JHa;->ZfxDd:Landroidx/lifecycle/wA$AZxh;

    iget-boolean p1, p0, Landroidx/lifecycle/JHa;->xJ:Z

    const/4 v0, 0x1

    if-nez p1, :cond_5

    iget p1, p0, Landroidx/lifecycle/JHa;->JHa:I

    if-eqz p1, :cond_3

    goto :goto_1

    :cond_3
    iput-boolean v0, p0, Landroidx/lifecycle/JHa;->xJ:Z

    invoke-virtual {p0}, Landroidx/lifecycle/JHa;->MiMN()V

    const/4 p1, 0x0

    iput-boolean p1, p0, Landroidx/lifecycle/JHa;->xJ:Z

    iget-object p1, p0, Landroidx/lifecycle/JHa;->ZfxDd:Landroidx/lifecycle/wA$AZxh;

    sget-object v0, Landroidx/lifecycle/wA$AZxh;->mjFkc:Landroidx/lifecycle/wA$AZxh;

    if-ne p1, v0, :cond_4

    new-instance p1, Lo/tyXzYJ;

    invoke-direct {p1}, Lo/tyXzYJ;-><init>()V

    iput-object p1, p0, Landroidx/lifecycle/JHa;->wA:Lo/tyXzYJ;

    :cond_4
    return-void

    :cond_5
    :goto_1
    iput-boolean v0, p0, Landroidx/lifecycle/JHa;->lgHUyS:Z

    return-void
.end method

.method public final ETF()V
    .locals 1

    iget-object p0, p0, Landroidx/lifecycle/JHa;->qdMbNW:Ljava/util/ArrayList;

    invoke-virtual {p0}, Ljava/util/ArrayList;->size()I

    move-result v0

    add-int/lit8 v0, v0, -0x1

    invoke-virtual {p0, v0}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    return-void
.end method

.method public final JHa(Ljava/lang/String;)V
    .locals 1

    iget-boolean p0, p0, Landroidx/lifecycle/JHa;->AZxh:Z

    if-eqz p0, :cond_1

    invoke-static {}, Lo/gtIJp;->JHa()Lo/gtIJp;

    move-result-object p0

    invoke-virtual {p0}, Lo/gtIJp;->AZxh()Z

    move-result p0

    if-eqz p0, :cond_0

    goto :goto_0

    :cond_0
    new-instance p0, Ljava/lang/StringBuilder;

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v0, "Method "

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p1, " must be called on the main thread"

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    new-instance p1, Ljava/lang/IllegalStateException;

    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {p1, p0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_1
    :goto_0
    return-void
.end method

.method public final KLFTb(Lo/V0;)Landroidx/lifecycle/wA$AZxh;
    .locals 2

    iget-object v0, p0, Landroidx/lifecycle/JHa;->wA:Lo/tyXzYJ;

    invoke-virtual {v0, p1}, Lo/tyXzYJ;->VA(Ljava/lang/Object;)Ljava/util/Map$Entry;

    move-result-object p1

    const/4 v0, 0x0

    if-eqz p1, :cond_0

    invoke-interface {p1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroidx/lifecycle/JHa$AZxh;

    if-eqz p1, :cond_0

    invoke-virtual {p1}, Landroidx/lifecycle/JHa$AZxh;->AZxh()Landroidx/lifecycle/wA$AZxh;

    move-result-object p1

    goto :goto_0

    :cond_0
    move-object p1, v0

    :goto_0
    iget-object v1, p0, Landroidx/lifecycle/JHa;->qdMbNW:Ljava/util/ArrayList;

    invoke-interface {v1}, Ljava/util/Collection;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_1

    iget-object v0, p0, Landroidx/lifecycle/JHa;->qdMbNW:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v1

    add-int/lit8 v1, v1, -0x1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroidx/lifecycle/wA$AZxh;

    :cond_1
    sget-object v1, Landroidx/lifecycle/JHa;->Dt:Landroidx/lifecycle/JHa$mjFkc;

    iget-object p0, p0, Landroidx/lifecycle/JHa;->ZfxDd:Landroidx/lifecycle/wA$AZxh;

    invoke-virtual {v1, p0, p1}, Landroidx/lifecycle/JHa$mjFkc;->mjFkc(Landroidx/lifecycle/wA$AZxh;Landroidx/lifecycle/wA$AZxh;)Landroidx/lifecycle/wA$AZxh;

    move-result-object p0

    invoke-virtual {v1, p0, v0}, Landroidx/lifecycle/JHa$mjFkc;->mjFkc(Landroidx/lifecycle/wA$AZxh;Landroidx/lifecycle/wA$AZxh;)Landroidx/lifecycle/wA$AZxh;

    move-result-object p0

    return-object p0
.end method

.method public final MiMN()V
    .locals 3

    iget-object v0, p0, Landroidx/lifecycle/JHa;->KLFTb:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lo/W0;

    if-eqz v0, :cond_3

    :cond_0
    :goto_0
    invoke-virtual {p0}, Landroidx/lifecycle/JHa;->qdMbNW()Z

    move-result v1

    const/4 v2, 0x0

    if-nez v1, :cond_2

    iput-boolean v2, p0, Landroidx/lifecycle/JHa;->lgHUyS:Z

    iget-object v1, p0, Landroidx/lifecycle/JHa;->ZfxDd:Landroidx/lifecycle/wA$AZxh;

    iget-object v2, p0, Landroidx/lifecycle/JHa;->wA:Lo/tyXzYJ;

    invoke-virtual {v2}, Lo/h6;->ZfxDd()Ljava/util/Map$Entry;

    move-result-object v2

    invoke-static {v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroidx/lifecycle/JHa$AZxh;

    invoke-virtual {v2}, Landroidx/lifecycle/JHa$AZxh;->AZxh()Landroidx/lifecycle/wA$AZxh;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/Enum;->compareTo(Ljava/lang/Enum;)I

    move-result v1

    if-gez v1, :cond_1

    invoke-virtual {p0, v0}, Landroidx/lifecycle/JHa;->ZfxDd(Lo/W0;)V

    :cond_1
    iget-object v1, p0, Landroidx/lifecycle/JHa;->wA:Lo/tyXzYJ;

    invoke-virtual {v1}, Lo/h6;->lgHUyS()Ljava/util/Map$Entry;

    move-result-object v1

    iget-boolean v2, p0, Landroidx/lifecycle/JHa;->lgHUyS:Z

    if-nez v2, :cond_0

    if-eqz v1, :cond_0

    iget-object v2, p0, Landroidx/lifecycle/JHa;->ZfxDd:Landroidx/lifecycle/wA$AZxh;

    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroidx/lifecycle/JHa$AZxh;

    invoke-virtual {v1}, Landroidx/lifecycle/JHa$AZxh;->AZxh()Landroidx/lifecycle/wA$AZxh;

    move-result-object v1

    invoke-virtual {v2, v1}, Ljava/lang/Enum;->compareTo(Ljava/lang/Enum;)I

    move-result v1

    if-lez v1, :cond_0

    invoke-virtual {p0, v0}, Landroidx/lifecycle/JHa;->xJ(Lo/W0;)V

    goto :goto_0

    :cond_2
    iput-boolean v2, p0, Landroidx/lifecycle/JHa;->lgHUyS:Z

    return-void

    :cond_3
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string v0, "LifecycleOwner of this LifecycleRegistry is already garbage collected. It is too late to change lifecycle state."

    invoke-direct {p0, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public final VA(Landroidx/lifecycle/wA$AZxh;)V
    .locals 0

    iget-object p0, p0, Landroidx/lifecycle/JHa;->qdMbNW:Ljava/util/ArrayList;

    invoke-virtual {p0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method public final ZfxDd(Lo/W0;)V
    .locals 5

    iget-object v0, p0, Landroidx/lifecycle/JHa;->wA:Lo/tyXzYJ;

    invoke-virtual {v0}, Lo/h6;->mjFkc()Ljava/util/Iterator;

    move-result-object v0

    const-string v1, "observerMap.descendingIterator()"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    :cond_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_2

    iget-boolean v1, p0, Landroidx/lifecycle/JHa;->lgHUyS:Z

    if-nez v1, :cond_2

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/util/Map$Entry;

    const-string v2, "next()"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-interface {v1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lo/V0;

    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroidx/lifecycle/JHa$AZxh;

    :goto_0
    invoke-virtual {v1}, Landroidx/lifecycle/JHa$AZxh;->AZxh()Landroidx/lifecycle/wA$AZxh;

    move-result-object v3

    iget-object v4, p0, Landroidx/lifecycle/JHa;->ZfxDd:Landroidx/lifecycle/wA$AZxh;

    invoke-virtual {v3, v4}, Ljava/lang/Enum;->compareTo(Ljava/lang/Enum;)I

    move-result v3

    if-lez v3, :cond_0

    iget-boolean v3, p0, Landroidx/lifecycle/JHa;->lgHUyS:Z

    if-nez v3, :cond_0

    iget-object v3, p0, Landroidx/lifecycle/JHa;->wA:Lo/tyXzYJ;

    invoke-virtual {v3, v2}, Lo/tyXzYJ;->contains(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_0

    sget-object v3, Landroidx/lifecycle/wA$mjFkc;->Companion:Landroidx/lifecycle/wA$mjFkc$mjFkc;

    invoke-virtual {v1}, Landroidx/lifecycle/JHa$AZxh;->AZxh()Landroidx/lifecycle/wA$AZxh;

    move-result-object v4

    invoke-virtual {v3, v4}, Landroidx/lifecycle/wA$mjFkc$mjFkc;->mjFkc(Landroidx/lifecycle/wA$AZxh;)Landroidx/lifecycle/wA$mjFkc;

    move-result-object v3

    if-eqz v3, :cond_1

    invoke-virtual {v3}, Landroidx/lifecycle/wA$mjFkc;->lgHUyS()Landroidx/lifecycle/wA$AZxh;

    move-result-object v4

    invoke-virtual {p0, v4}, Landroidx/lifecycle/JHa;->VA(Landroidx/lifecycle/wA$AZxh;)V

    invoke-virtual {v1, p1, v3}, Landroidx/lifecycle/JHa$AZxh;->mjFkc(Lo/W0;Landroidx/lifecycle/wA$mjFkc;)V

    invoke-virtual {p0}, Landroidx/lifecycle/JHa;->ETF()V

    goto :goto_0

    :cond_1
    new-instance p0, Ljava/lang/IllegalStateException;

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v0, "no event down from "

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Landroidx/lifecycle/JHa$AZxh;->AZxh()Landroidx/lifecycle/wA$AZxh;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_2
    return-void
.end method

.method public lgHUyS(Landroidx/lifecycle/wA$mjFkc;)V
    .locals 1

    const-string v0, "event"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "handleLifecycleEvent"

    invoke-virtual {p0, v0}, Landroidx/lifecycle/JHa;->JHa(Ljava/lang/String;)V

    invoke-virtual {p1}, Landroidx/lifecycle/wA$mjFkc;->lgHUyS()Landroidx/lifecycle/wA$AZxh;

    move-result-object p1

    invoke-virtual {p0, p1}, Landroidx/lifecycle/JHa;->Dt(Landroidx/lifecycle/wA$AZxh;)V

    return-void
.end method

.method public mjFkc(Lo/V0;)V
    .locals 6

    const-string v0, "observer"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "addObserver"

    invoke-virtual {p0, v0}, Landroidx/lifecycle/JHa;->JHa(Ljava/lang/String;)V

    iget-object v0, p0, Landroidx/lifecycle/JHa;->ZfxDd:Landroidx/lifecycle/wA$AZxh;

    sget-object v1, Landroidx/lifecycle/wA$AZxh;->mjFkc:Landroidx/lifecycle/wA$AZxh;

    if-ne v0, v1, :cond_0

    goto :goto_0

    :cond_0
    sget-object v1, Landroidx/lifecycle/wA$AZxh;->AZxh:Landroidx/lifecycle/wA$AZxh;

    :goto_0
    new-instance v0, Landroidx/lifecycle/JHa$AZxh;

    invoke-direct {v0, p1, v1}, Landroidx/lifecycle/JHa$AZxh;-><init>(Lo/V0;Landroidx/lifecycle/wA$AZxh;)V

    iget-object v1, p0, Landroidx/lifecycle/JHa;->wA:Lo/tyXzYJ;

    invoke-virtual {v1, p1, v0}, Lo/tyXzYJ;->Dt(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroidx/lifecycle/JHa$AZxh;

    if-eqz v1, :cond_1

    return-void

    :cond_1
    iget-object v1, p0, Landroidx/lifecycle/JHa;->KLFTb:Ljava/lang/ref/WeakReference;

    invoke-virtual {v1}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lo/W0;

    if-nez v1, :cond_2

    return-void

    :cond_2
    iget v2, p0, Landroidx/lifecycle/JHa;->JHa:I

    const/4 v3, 0x1

    if-nez v2, :cond_4

    iget-boolean v2, p0, Landroidx/lifecycle/JHa;->xJ:Z

    if-eqz v2, :cond_3

    goto :goto_1

    :cond_3
    const/4 v2, 0x0

    goto :goto_2

    :cond_4
    :goto_1
    move v2, v3

    :goto_2
    invoke-virtual {p0, p1}, Landroidx/lifecycle/JHa;->KLFTb(Lo/V0;)Landroidx/lifecycle/wA$AZxh;

    move-result-object v4

    iget v5, p0, Landroidx/lifecycle/JHa;->JHa:I

    add-int/2addr v5, v3

    iput v5, p0, Landroidx/lifecycle/JHa;->JHa:I

    :goto_3
    invoke-virtual {v0}, Landroidx/lifecycle/JHa$AZxh;->AZxh()Landroidx/lifecycle/wA$AZxh;

    move-result-object v3

    invoke-virtual {v3, v4}, Ljava/lang/Enum;->compareTo(Ljava/lang/Enum;)I

    move-result v3

    if-gez v3, :cond_6

    iget-object v3, p0, Landroidx/lifecycle/JHa;->wA:Lo/tyXzYJ;

    invoke-virtual {v3, p1}, Lo/tyXzYJ;->contains(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_6

    invoke-virtual {v0}, Landroidx/lifecycle/JHa$AZxh;->AZxh()Landroidx/lifecycle/wA$AZxh;

    move-result-object v3

    invoke-virtual {p0, v3}, Landroidx/lifecycle/JHa;->VA(Landroidx/lifecycle/wA$AZxh;)V

    sget-object v3, Landroidx/lifecycle/wA$mjFkc;->Companion:Landroidx/lifecycle/wA$mjFkc$mjFkc;

    invoke-virtual {v0}, Landroidx/lifecycle/JHa$AZxh;->AZxh()Landroidx/lifecycle/wA$AZxh;

    move-result-object v4

    invoke-virtual {v3, v4}, Landroidx/lifecycle/wA$mjFkc$mjFkc;->AZxh(Landroidx/lifecycle/wA$AZxh;)Landroidx/lifecycle/wA$mjFkc;

    move-result-object v3

    if-eqz v3, :cond_5

    invoke-virtual {v0, v1, v3}, Landroidx/lifecycle/JHa$AZxh;->mjFkc(Lo/W0;Landroidx/lifecycle/wA$mjFkc;)V

    invoke-virtual {p0}, Landroidx/lifecycle/JHa;->ETF()V

    invoke-virtual {p0, p1}, Landroidx/lifecycle/JHa;->KLFTb(Lo/V0;)Landroidx/lifecycle/wA$AZxh;

    move-result-object v4

    goto :goto_3

    :cond_5
    new-instance p0, Ljava/lang/IllegalStateException;

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "no event up from "

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Landroidx/lifecycle/JHa$AZxh;->AZxh()Landroidx/lifecycle/wA$AZxh;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_6
    if-nez v2, :cond_7

    invoke-virtual {p0}, Landroidx/lifecycle/JHa;->MiMN()V

    :cond_7
    iget p1, p0, Landroidx/lifecycle/JHa;->JHa:I

    add-int/lit8 p1, p1, -0x1

    iput p1, p0, Landroidx/lifecycle/JHa;->JHa:I

    return-void
.end method

.method public final qdMbNW()Z
    .locals 3

    iget-object v0, p0, Landroidx/lifecycle/JHa;->wA:Lo/tyXzYJ;

    invoke-virtual {v0}, Lo/h6;->size()I

    move-result v0

    const/4 v1, 0x1

    if-nez v0, :cond_0

    return v1

    :cond_0
    iget-object v0, p0, Landroidx/lifecycle/JHa;->wA:Lo/tyXzYJ;

    invoke-virtual {v0}, Lo/h6;->ZfxDd()Ljava/util/Map$Entry;

    move-result-object v0

    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    invoke-interface {v0}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroidx/lifecycle/JHa$AZxh;

    invoke-virtual {v0}, Landroidx/lifecycle/JHa$AZxh;->AZxh()Landroidx/lifecycle/wA$AZxh;

    move-result-object v0

    iget-object v2, p0, Landroidx/lifecycle/JHa;->wA:Lo/tyXzYJ;

    invoke-virtual {v2}, Lo/h6;->lgHUyS()Ljava/util/Map$Entry;

    move-result-object v2

    invoke-static {v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroidx/lifecycle/JHa$AZxh;

    invoke-virtual {v2}, Landroidx/lifecycle/JHa$AZxh;->AZxh()Landroidx/lifecycle/wA$AZxh;

    move-result-object v2

    if-ne v0, v2, :cond_1

    iget-object p0, p0, Landroidx/lifecycle/JHa;->ZfxDd:Landroidx/lifecycle/wA$AZxh;

    if-ne p0, v2, :cond_1

    goto :goto_0

    :cond_1
    const/4 v1, 0x0

    :goto_0
    return v1
.end method

.method public wA(Lo/V0;)V
    .locals 1

    const-string v0, "observer"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "removeObserver"

    invoke-virtual {p0, v0}, Landroidx/lifecycle/JHa;->JHa(Ljava/lang/String;)V

    iget-object p0, p0, Landroidx/lifecycle/JHa;->wA:Lo/tyXzYJ;

    invoke-virtual {p0, p1}, Lo/tyXzYJ;->ETF(Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method public final xJ(Lo/W0;)V
    .locals 5

    iget-object v0, p0, Landroidx/lifecycle/JHa;->wA:Lo/tyXzYJ;

    invoke-virtual {v0}, Lo/h6;->xJ()Lo/h6$ZfxDd;

    move-result-object v0

    const-string v1, "observerMap.iteratorWithAdditions()"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    :cond_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_2

    iget-boolean v1, p0, Landroidx/lifecycle/JHa;->lgHUyS:Z

    if-nez v1, :cond_2

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/util/Map$Entry;

    invoke-interface {v1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lo/V0;

    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroidx/lifecycle/JHa$AZxh;

    :goto_0
    invoke-virtual {v1}, Landroidx/lifecycle/JHa$AZxh;->AZxh()Landroidx/lifecycle/wA$AZxh;

    move-result-object v3

    iget-object v4, p0, Landroidx/lifecycle/JHa;->ZfxDd:Landroidx/lifecycle/wA$AZxh;

    invoke-virtual {v3, v4}, Ljava/lang/Enum;->compareTo(Ljava/lang/Enum;)I

    move-result v3

    if-gez v3, :cond_0

    iget-boolean v3, p0, Landroidx/lifecycle/JHa;->lgHUyS:Z

    if-nez v3, :cond_0

    iget-object v3, p0, Landroidx/lifecycle/JHa;->wA:Lo/tyXzYJ;

    invoke-virtual {v3, v2}, Lo/tyXzYJ;->contains(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_0

    invoke-virtual {v1}, Landroidx/lifecycle/JHa$AZxh;->AZxh()Landroidx/lifecycle/wA$AZxh;

    move-result-object v3

    invoke-virtual {p0, v3}, Landroidx/lifecycle/JHa;->VA(Landroidx/lifecycle/wA$AZxh;)V

    sget-object v3, Landroidx/lifecycle/wA$mjFkc;->Companion:Landroidx/lifecycle/wA$mjFkc$mjFkc;

    invoke-virtual {v1}, Landroidx/lifecycle/JHa$AZxh;->AZxh()Landroidx/lifecycle/wA$AZxh;

    move-result-object v4

    invoke-virtual {v3, v4}, Landroidx/lifecycle/wA$mjFkc$mjFkc;->AZxh(Landroidx/lifecycle/wA$AZxh;)Landroidx/lifecycle/wA$mjFkc;

    move-result-object v3

    if-eqz v3, :cond_1

    invoke-virtual {v1, p1, v3}, Landroidx/lifecycle/JHa$AZxh;->mjFkc(Lo/W0;Landroidx/lifecycle/wA$mjFkc;)V

    invoke-virtual {p0}, Landroidx/lifecycle/JHa;->ETF()V

    goto :goto_0

    :cond_1
    new-instance p0, Ljava/lang/IllegalStateException;

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v0, "no event up from "

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Landroidx/lifecycle/JHa$AZxh;->AZxh()Landroidx/lifecycle/wA$AZxh;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_2
    return-void
.end method
