.class Landroidx/lifecycle/ReflectiveGenericLifecycleObserver;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/lifecycle/KLFTb;


# annotations
.annotation runtime Ljava/lang/Deprecated;
.end annotation


# instance fields
.field public final AZxh:Landroidx/lifecycle/mjFkc$mjFkc;

.field public final mjFkc:Ljava/lang/Object;


# direct methods
.method public constructor <init>(Ljava/lang/Object;)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/lifecycle/ReflectiveGenericLifecycleObserver;->mjFkc:Ljava/lang/Object;

    sget-object v0, Landroidx/lifecycle/mjFkc;->wA:Landroidx/lifecycle/mjFkc;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p1

    invoke-virtual {v0, p1}, Landroidx/lifecycle/mjFkc;->wA(Ljava/lang/Class;)Landroidx/lifecycle/mjFkc$mjFkc;

    move-result-object p1

    iput-object p1, p0, Landroidx/lifecycle/ReflectiveGenericLifecycleObserver;->AZxh:Landroidx/lifecycle/mjFkc$mjFkc;

    return-void
.end method


# virtual methods
.method public VA(Lo/W0;Landroidx/lifecycle/wA$mjFkc;)V
    .locals 1

    iget-object v0, p0, Landroidx/lifecycle/ReflectiveGenericLifecycleObserver;->AZxh:Landroidx/lifecycle/mjFkc$mjFkc;

    iget-object p0, p0, Landroidx/lifecycle/ReflectiveGenericLifecycleObserver;->mjFkc:Ljava/lang/Object;

    invoke-virtual {v0, p1, p2, p0}, Landroidx/lifecycle/mjFkc$mjFkc;->mjFkc(Lo/W0;Landroidx/lifecycle/wA$mjFkc;Ljava/lang/Object;)V

    return-void
.end method
