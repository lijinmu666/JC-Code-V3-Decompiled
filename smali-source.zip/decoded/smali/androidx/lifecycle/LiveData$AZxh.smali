.class public abstract Landroidx/lifecycle/LiveData$AZxh;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/lifecycle/LiveData;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x401
    name = "AZxh"
.end annotation


# instance fields
.field public AZxh:Z

.field public final synthetic ZfxDd:Landroidx/lifecycle/LiveData;

.field public final mjFkc:Lo/W2;

.field public wA:I


# virtual methods
.method public abstract AZxh()V
.end method

.method public mjFkc(Z)V
    .locals 1

    iget-boolean v0, p0, Landroidx/lifecycle/LiveData$AZxh;->AZxh:Z

    if-ne p1, v0, :cond_0

    return-void

    :cond_0
    iput-boolean p1, p0, Landroidx/lifecycle/LiveData$AZxh;->AZxh:Z

    iget-object v0, p0, Landroidx/lifecycle/LiveData$AZxh;->ZfxDd:Landroidx/lifecycle/LiveData;

    if-eqz p1, :cond_1

    const/4 p1, 0x1

    goto :goto_0

    :cond_1
    const/4 p1, -0x1

    :goto_0
    invoke-virtual {v0, p1}, Landroidx/lifecycle/LiveData;->AZxh(I)V

    iget-boolean p1, p0, Landroidx/lifecycle/LiveData$AZxh;->AZxh:Z

    if-eqz p1, :cond_2

    iget-object p1, p0, Landroidx/lifecycle/LiveData$AZxh;->ZfxDd:Landroidx/lifecycle/LiveData;

    invoke-virtual {p1, p0}, Landroidx/lifecycle/LiveData;->ZfxDd(Landroidx/lifecycle/LiveData$AZxh;)V

    :cond_2
    return-void
.end method

.method public abstract wA()Z
.end method
