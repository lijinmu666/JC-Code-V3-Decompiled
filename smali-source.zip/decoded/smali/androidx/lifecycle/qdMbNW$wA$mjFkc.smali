.class public final Landroidx/lifecycle/qdMbNW$wA$mjFkc;
.super Lo/Ipwl;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Landroidx/lifecycle/qdMbNW$wA;->onActivityPreCreated(Landroid/app/Activity;Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Landroidx/lifecycle/qdMbNW;


# direct methods
.method public constructor <init>(Landroidx/lifecycle/qdMbNW;)V
    .locals 0

    iput-object p1, p0, Landroidx/lifecycle/qdMbNW$wA$mjFkc;->this$0:Landroidx/lifecycle/qdMbNW;

    invoke-direct {p0}, Lo/Ipwl;-><init>()V

    return-void
.end method


# virtual methods
.method public onActivityPostResumed(Landroid/app/Activity;)V
    .locals 1

    const-string v0, "activity"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object p0, p0, Landroidx/lifecycle/qdMbNW$wA$mjFkc;->this$0:Landroidx/lifecycle/qdMbNW;

    invoke-virtual {p0}, Landroidx/lifecycle/qdMbNW;->KLFTb()V

    return-void
.end method

.method public onActivityPostStarted(Landroid/app/Activity;)V
    .locals 1

    const-string v0, "activity"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object p0, p0, Landroidx/lifecycle/qdMbNW$wA$mjFkc;->this$0:Landroidx/lifecycle/qdMbNW;

    invoke-virtual {p0}, Landroidx/lifecycle/qdMbNW;->xJ()V

    return-void
.end method
