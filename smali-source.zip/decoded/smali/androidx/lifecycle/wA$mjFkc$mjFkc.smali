.class public final Landroidx/lifecycle/wA$mjFkc$mjFkc;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/lifecycle/wA$mjFkc;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "mjFkc"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/lifecycle/wA$mjFkc$mjFkc$mjFkc;
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Landroidx/lifecycle/wA$mjFkc$mjFkc;-><init>()V

    return-void
.end method


# virtual methods
.method public final AZxh(Landroidx/lifecycle/wA$AZxh;)Landroidx/lifecycle/wA$mjFkc;
    .locals 0

    const-string p0, "state"

    invoke-static {p1, p0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object p0, Landroidx/lifecycle/wA$mjFkc$mjFkc$mjFkc;->mjFkc:[I

    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    move-result p1

    aget p0, p0, p1

    const/4 p1, 0x1

    if-eq p0, p1, :cond_2

    const/4 p1, 0x2

    if-eq p0, p1, :cond_1

    const/4 p1, 0x5

    if-eq p0, p1, :cond_0

    const/4 p0, 0x0

    goto :goto_0

    :cond_0
    sget-object p0, Landroidx/lifecycle/wA$mjFkc;->ON_CREATE:Landroidx/lifecycle/wA$mjFkc;

    goto :goto_0

    :cond_1
    sget-object p0, Landroidx/lifecycle/wA$mjFkc;->ON_RESUME:Landroidx/lifecycle/wA$mjFkc;

    goto :goto_0

    :cond_2
    sget-object p0, Landroidx/lifecycle/wA$mjFkc;->ON_START:Landroidx/lifecycle/wA$mjFkc;

    :goto_0
    return-object p0
.end method

.method public final mjFkc(Landroidx/lifecycle/wA$AZxh;)Landroidx/lifecycle/wA$mjFkc;
    .locals 0

    const-string p0, "state"

    invoke-static {p1, p0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object p0, Landroidx/lifecycle/wA$mjFkc$mjFkc$mjFkc;->mjFkc:[I

    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    move-result p1

    aget p0, p0, p1

    const/4 p1, 0x1

    if-eq p0, p1, :cond_2

    const/4 p1, 0x2

    if-eq p0, p1, :cond_1

    const/4 p1, 0x3

    if-eq p0, p1, :cond_0

    const/4 p0, 0x0

    goto :goto_0

    :cond_0
    sget-object p0, Landroidx/lifecycle/wA$mjFkc;->ON_PAUSE:Landroidx/lifecycle/wA$mjFkc;

    goto :goto_0

    :cond_1
    sget-object p0, Landroidx/lifecycle/wA$mjFkc;->ON_STOP:Landroidx/lifecycle/wA$mjFkc;

    goto :goto_0

    :cond_2
    sget-object p0, Landroidx/lifecycle/wA$mjFkc;->ON_DESTROY:Landroidx/lifecycle/wA$mjFkc;

    :goto_0
    return-object p0
.end method
