.class public abstract Landroidx/lifecycle/wA;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/lifecycle/wA$mjFkc;,
        Landroidx/lifecycle/wA$AZxh;
    }
.end annotation


# instance fields
.field public mjFkc:Ljava/util/concurrent/atomic/AtomicReference;


# direct methods
.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/concurrent/atomic/AtomicReference;

    invoke-direct {v0}, Ljava/util/concurrent/atomic/AtomicReference;-><init>()V

    iput-object v0, p0, Landroidx/lifecycle/wA;->mjFkc:Ljava/util/concurrent/atomic/AtomicReference;

    return-void
.end method


# virtual methods
.method public abstract AZxh()Landroidx/lifecycle/wA$AZxh;
.end method

.method public abstract mjFkc(Lo/V0;)V
.end method

.method public abstract wA(Lo/V0;)V
.end method
