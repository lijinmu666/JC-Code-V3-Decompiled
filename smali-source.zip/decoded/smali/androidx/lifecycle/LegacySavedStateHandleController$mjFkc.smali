.class public final Landroidx/lifecycle/LegacySavedStateHandleController$mjFkc;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/savedstate/mjFkc$mjFkc;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/lifecycle/LegacySavedStateHandleController;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "mjFkc"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public mjFkc(Lo/n6;)V
    .locals 4

    const-string p0, "owner"

    invoke-static {p1, p0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    instance-of p0, p1, Lo/ja;

    if-eqz p0, :cond_2

    move-object p0, p1

    check-cast p0, Lo/ja;

    invoke-interface {p0}, Lo/ja;->wA()Lo/ia;

    move-result-object p0

    invoke-interface {p1}, Lo/n6;->mjFkc()Landroidx/savedstate/mjFkc;

    move-result-object v0

    invoke-virtual {p0}, Lo/ia;->AZxh()Ljava/util/Set;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_0

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    invoke-virtual {p0, v2}, Lo/ia;->mjFkc(Ljava/lang/String;)Lo/ga;

    move-result-object v2

    invoke-static {v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    invoke-interface {p1}, Lo/W0;->JHa()Landroidx/lifecycle/wA;

    move-result-object v3

    invoke-static {v2, v0, v3}, Landroidx/lifecycle/LegacySavedStateHandleController;->mjFkc(Lo/ga;Landroidx/savedstate/mjFkc;Landroidx/lifecycle/wA;)V

    goto :goto_0

    :cond_0
    invoke-virtual {p0}, Lo/ia;->AZxh()Ljava/util/Set;

    move-result-object p0

    invoke-interface {p0}, Ljava/util/Collection;->isEmpty()Z

    move-result p0

    if-nez p0, :cond_1

    const-class p0, Landroidx/lifecycle/LegacySavedStateHandleController$mjFkc;

    invoke-virtual {v0, p0}, Landroidx/savedstate/mjFkc;->lgHUyS(Ljava/lang/Class;)V

    :cond_1
    return-void

    :cond_2
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string p1, "Internal error: OnRecreation should be registered only on components that implement ViewModelStoreOwner"

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0
.end method
