.class Landroidx/lifecycle/LiveData$LifecycleBoundObserver;
.super Landroidx/lifecycle/LiveData$AZxh;
.source "SourceFile"

# interfaces
.implements Landroidx/lifecycle/KLFTb;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/lifecycle/LiveData;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "LifecycleBoundObserver"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Landroidx/lifecycle/LiveData.AZxh;",
        "Landroidx/lifecycle/KLFTb;"
    }
.end annotation


# instance fields
.field public final synthetic JHa:Landroidx/lifecycle/LiveData;

.field public final KLFTb:Lo/W0;


# virtual methods
.method public AZxh()V
    .locals 1

    iget-object v0, p0, Landroidx/lifecycle/LiveData$LifecycleBoundObserver;->KLFTb:Lo/W0;

    invoke-interface {v0}, Lo/W0;->JHa()Landroidx/lifecycle/wA;

    move-result-object v0

    invoke-virtual {v0, p0}, Landroidx/lifecycle/wA;->wA(Lo/V0;)V

    return-void
.end method

.method public VA(Lo/W0;Landroidx/lifecycle/wA$mjFkc;)V
    .locals 1

    iget-object p1, p0, Landroidx/lifecycle/LiveData$LifecycleBoundObserver;->KLFTb:Lo/W0;

    invoke-interface {p1}, Lo/W0;->JHa()Landroidx/lifecycle/wA;

    move-result-object p1

    invoke-virtual {p1}, Landroidx/lifecycle/wA;->AZxh()Landroidx/lifecycle/wA$AZxh;

    move-result-object p1

    sget-object p2, Landroidx/lifecycle/wA$AZxh;->mjFkc:Landroidx/lifecycle/wA$AZxh;

    if-ne p1, p2, :cond_0

    iget-object p1, p0, Landroidx/lifecycle/LiveData$LifecycleBoundObserver;->JHa:Landroidx/lifecycle/LiveData;

    iget-object p0, p0, Landroidx/lifecycle/LiveData$AZxh;->mjFkc:Lo/W2;

    invoke-virtual {p1, p0}, Landroidx/lifecycle/LiveData;->xJ(Lo/W2;)V

    return-void

    :cond_0
    const/4 p2, 0x0

    :goto_0
    if-eq p2, p1, :cond_1

    invoke-virtual {p0}, Landroidx/lifecycle/LiveData$LifecycleBoundObserver;->wA()Z

    move-result p2

    invoke-virtual {p0, p2}, Landroidx/lifecycle/LiveData$AZxh;->mjFkc(Z)V

    iget-object p2, p0, Landroidx/lifecycle/LiveData$LifecycleBoundObserver;->KLFTb:Lo/W0;

    invoke-interface {p2}, Lo/W0;->JHa()Landroidx/lifecycle/wA;

    move-result-object p2

    invoke-virtual {p2}, Landroidx/lifecycle/wA;->AZxh()Landroidx/lifecycle/wA$AZxh;

    move-result-object p2

    move-object v0, p2

    move-object p2, p1

    move-object p1, v0

    goto :goto_0

    :cond_1
    return-void
.end method

.method public wA()Z
    .locals 1

    iget-object p0, p0, Landroidx/lifecycle/LiveData$LifecycleBoundObserver;->KLFTb:Lo/W0;

    invoke-interface {p0}, Lo/W0;->JHa()Landroidx/lifecycle/wA;

    move-result-object p0

    invoke-virtual {p0}, Landroidx/lifecycle/wA;->AZxh()Landroidx/lifecycle/wA$AZxh;

    move-result-object p0

    sget-object v0, Landroidx/lifecycle/wA$AZxh;->ZfxDd:Landroidx/lifecycle/wA$AZxh;

    invoke-virtual {p0, v0}, Landroidx/lifecycle/wA$AZxh;->lgHUyS(Landroidx/lifecycle/wA$AZxh;)Z

    move-result p0

    return p0
.end method
