.class public interface abstract Landroidx/lifecycle/KLFTb;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lo/V0;


# virtual methods
.method public abstract VA(Lo/W0;Landroidx/lifecycle/wA$mjFkc;)V
.end method
