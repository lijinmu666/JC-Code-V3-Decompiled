.class public final Landroidx/lifecycle/ZfxDd$mjFkc;
.super Lo/Ipwl;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/lifecycle/ZfxDd;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "mjFkc"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Lo/Ipwl;-><init>()V

    return-void
.end method


# virtual methods
.method public onActivityCreated(Landroid/app/Activity;Landroid/os/Bundle;)V
    .locals 0

    const-string p0, "activity"

    invoke-static {p1, p0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object p0, Landroidx/lifecycle/Dt;->AZxh:Landroidx/lifecycle/Dt$AZxh;

    invoke-virtual {p0, p1}, Landroidx/lifecycle/Dt$AZxh;->AZxh(Landroid/app/Activity;)V

    return-void
.end method
