.class public abstract Landroidx/lifecycle/LiveData;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/lifecycle/LiveData$AZxh;,
        Landroidx/lifecycle/LiveData$LifecycleBoundObserver;
    }
.end annotation


# static fields
.field public static final ETF:Ljava/lang/Object;


# instance fields
.field public AZxh:Lo/h6;

.field public final Dt:Ljava/lang/Runnable;

.field public volatile JHa:Ljava/lang/Object;

.field public volatile KLFTb:Ljava/lang/Object;

.field public ZfxDd:Z

.field public lgHUyS:Z

.field public final mjFkc:Ljava/lang/Object;

.field public qdMbNW:Z

.field public wA:I

.field public xJ:I


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Landroidx/lifecycle/LiveData;->ETF:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    iput-object v0, p0, Landroidx/lifecycle/LiveData;->mjFkc:Ljava/lang/Object;

    new-instance v0, Lo/h6;

    invoke-direct {v0}, Lo/h6;-><init>()V

    iput-object v0, p0, Landroidx/lifecycle/LiveData;->AZxh:Lo/h6;

    const/4 v0, 0x0

    iput v0, p0, Landroidx/lifecycle/LiveData;->wA:I

    sget-object v0, Landroidx/lifecycle/LiveData;->ETF:Ljava/lang/Object;

    iput-object v0, p0, Landroidx/lifecycle/LiveData;->JHa:Ljava/lang/Object;

    new-instance v1, Landroidx/lifecycle/LiveData$mjFkc;

    invoke-direct {v1, p0}, Landroidx/lifecycle/LiveData$mjFkc;-><init>(Landroidx/lifecycle/LiveData;)V

    iput-object v1, p0, Landroidx/lifecycle/LiveData;->Dt:Ljava/lang/Runnable;

    iput-object v0, p0, Landroidx/lifecycle/LiveData;->KLFTb:Ljava/lang/Object;

    const/4 v0, -0x1

    iput v0, p0, Landroidx/lifecycle/LiveData;->xJ:I

    return-void
.end method

.method public static mjFkc(Ljava/lang/String;)V
    .locals 3

    invoke-static {}, Lo/gtIJp;->JHa()Lo/gtIJp;

    move-result-object v0

    invoke-virtual {v0}, Lo/gtIJp;->AZxh()Z

    move-result v0

    if-eqz v0, :cond_0

    return-void

    :cond_0
    new-instance v0, Ljava/lang/IllegalStateException;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "Cannot invoke "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p0, " on a background thread"

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0
.end method


# virtual methods
.method public AZxh(I)V
    .locals 4

    iget v0, p0, Landroidx/lifecycle/LiveData;->wA:I

    add-int/2addr p1, v0

    iput p1, p0, Landroidx/lifecycle/LiveData;->wA:I

    iget-boolean p1, p0, Landroidx/lifecycle/LiveData;->ZfxDd:Z

    if-eqz p1, :cond_0

    return-void

    :cond_0
    const/4 p1, 0x1

    iput-boolean p1, p0, Landroidx/lifecycle/LiveData;->ZfxDd:Z

    :goto_0
    const/4 v1, 0x0

    :try_start_0
    iget v2, p0, Landroidx/lifecycle/LiveData;->wA:I

    if-eq v0, v2, :cond_5

    if-nez v0, :cond_1

    if-lez v2, :cond_1

    move v3, p1

    goto :goto_1

    :cond_1
    move v3, v1

    :goto_1
    if-lez v0, :cond_2

    if-nez v2, :cond_2

    move v0, p1

    goto :goto_2

    :cond_2
    move v0, v1

    :goto_2
    if-eqz v3, :cond_3

    invoke-virtual {p0}, Landroidx/lifecycle/LiveData;->KLFTb()V

    goto :goto_3

    :catchall_0
    move-exception p1

    goto :goto_4

    :cond_3
    if-eqz v0, :cond_4

    invoke-virtual {p0}, Landroidx/lifecycle/LiveData;->JHa()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_4
    :goto_3
    move v0, v2

    goto :goto_0

    :cond_5
    iput-boolean v1, p0, Landroidx/lifecycle/LiveData;->ZfxDd:Z

    return-void

    :goto_4
    iput-boolean v1, p0, Landroidx/lifecycle/LiveData;->ZfxDd:Z

    throw p1
.end method

.method public JHa()V
    .locals 0

    return-void
.end method

.method public KLFTb()V
    .locals 0

    return-void
.end method

.method public ZfxDd(Landroidx/lifecycle/LiveData$AZxh;)V
    .locals 3

    iget-boolean v0, p0, Landroidx/lifecycle/LiveData;->lgHUyS:Z

    const/4 v1, 0x1

    if-eqz v0, :cond_0

    iput-boolean v1, p0, Landroidx/lifecycle/LiveData;->qdMbNW:Z

    return-void

    :cond_0
    iput-boolean v1, p0, Landroidx/lifecycle/LiveData;->lgHUyS:Z

    :cond_1
    const/4 v0, 0x0

    iput-boolean v0, p0, Landroidx/lifecycle/LiveData;->qdMbNW:Z

    if-eqz p1, :cond_2

    invoke-virtual {p0, p1}, Landroidx/lifecycle/LiveData;->wA(Landroidx/lifecycle/LiveData$AZxh;)V

    const/4 p1, 0x0

    goto :goto_0

    :cond_2
    iget-object v1, p0, Landroidx/lifecycle/LiveData;->AZxh:Lo/h6;

    invoke-virtual {v1}, Lo/h6;->xJ()Lo/h6$ZfxDd;

    move-result-object v1

    :cond_3
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_4

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/util/Map$Entry;

    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroidx/lifecycle/LiveData$AZxh;

    invoke-virtual {p0, v2}, Landroidx/lifecycle/LiveData;->wA(Landroidx/lifecycle/LiveData$AZxh;)V

    iget-boolean v2, p0, Landroidx/lifecycle/LiveData;->qdMbNW:Z

    if-eqz v2, :cond_3

    :cond_4
    :goto_0
    iget-boolean v1, p0, Landroidx/lifecycle/LiveData;->qdMbNW:Z

    if-nez v1, :cond_1

    iput-boolean v0, p0, Landroidx/lifecycle/LiveData;->lgHUyS:Z

    return-void
.end method

.method public lgHUyS(Ljava/lang/Object;)V
    .locals 1

    const-string v0, "setValue"

    invoke-static {v0}, Landroidx/lifecycle/LiveData;->mjFkc(Ljava/lang/String;)V

    iget v0, p0, Landroidx/lifecycle/LiveData;->xJ:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, Landroidx/lifecycle/LiveData;->xJ:I

    iput-object p1, p0, Landroidx/lifecycle/LiveData;->KLFTb:Ljava/lang/Object;

    const/4 p1, 0x0

    invoke-virtual {p0, p1}, Landroidx/lifecycle/LiveData;->ZfxDd(Landroidx/lifecycle/LiveData$AZxh;)V

    return-void
.end method

.method public final wA(Landroidx/lifecycle/LiveData$AZxh;)V
    .locals 2

    iget-boolean v0, p1, Landroidx/lifecycle/LiveData$AZxh;->AZxh:Z

    if-nez v0, :cond_0

    return-void

    :cond_0
    invoke-virtual {p1}, Landroidx/lifecycle/LiveData$AZxh;->wA()Z

    move-result v0

    if-nez v0, :cond_1

    const/4 p0, 0x0

    invoke-virtual {p1, p0}, Landroidx/lifecycle/LiveData$AZxh;->mjFkc(Z)V

    return-void

    :cond_1
    iget v0, p1, Landroidx/lifecycle/LiveData$AZxh;->wA:I

    iget v1, p0, Landroidx/lifecycle/LiveData;->xJ:I

    if-lt v0, v1, :cond_2

    return-void

    :cond_2
    iput v1, p1, Landroidx/lifecycle/LiveData$AZxh;->wA:I

    iget-object p1, p1, Landroidx/lifecycle/LiveData$AZxh;->mjFkc:Lo/W2;

    iget-object p0, p0, Landroidx/lifecycle/LiveData;->KLFTb:Ljava/lang/Object;

    invoke-interface {p1, p0}, Lo/W2;->mjFkc(Ljava/lang/Object;)V

    return-void
.end method

.method public xJ(Lo/W2;)V
    .locals 1

    const-string v0, "removeObserver"

    invoke-static {v0}, Landroidx/lifecycle/LiveData;->mjFkc(Ljava/lang/String;)V

    iget-object p0, p0, Landroidx/lifecycle/LiveData;->AZxh:Lo/h6;

    invoke-virtual {p0, p1}, Lo/h6;->ETF(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroidx/lifecycle/LiveData$AZxh;

    if-nez p0, :cond_0

    return-void

    :cond_0
    invoke-virtual {p0}, Landroidx/lifecycle/LiveData$AZxh;->AZxh()V

    const/4 p1, 0x0

    invoke-virtual {p0, p1}, Landroidx/lifecycle/LiveData$AZxh;->mjFkc(Z)V

    return-void
.end method
