.class public final enum Landroidx/lifecycle/wA$AZxh;
.super Ljava/lang/Enum;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/lifecycle/wA;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4019
    name = "AZxh"
.end annotation


# static fields
.field public static final enum AZxh:Landroidx/lifecycle/wA$AZxh;

.field public static final synthetic JHa:[Landroidx/lifecycle/wA$AZxh;

.field public static final enum KLFTb:Landroidx/lifecycle/wA$AZxh;

.field public static final enum ZfxDd:Landroidx/lifecycle/wA$AZxh;

.field public static final enum mjFkc:Landroidx/lifecycle/wA$AZxh;

.field public static final enum wA:Landroidx/lifecycle/wA$AZxh;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    new-instance v0, Landroidx/lifecycle/wA$AZxh;

    const-string v1, "DESTROYED"

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2}, Landroidx/lifecycle/wA$AZxh;-><init>(Ljava/lang/String;I)V

    sput-object v0, Landroidx/lifecycle/wA$AZxh;->mjFkc:Landroidx/lifecycle/wA$AZxh;

    new-instance v0, Landroidx/lifecycle/wA$AZxh;

    const-string v1, "INITIALIZED"

    const/4 v2, 0x1

    invoke-direct {v0, v1, v2}, Landroidx/lifecycle/wA$AZxh;-><init>(Ljava/lang/String;I)V

    sput-object v0, Landroidx/lifecycle/wA$AZxh;->AZxh:Landroidx/lifecycle/wA$AZxh;

    new-instance v0, Landroidx/lifecycle/wA$AZxh;

    const-string v1, "CREATED"

    const/4 v2, 0x2

    invoke-direct {v0, v1, v2}, Landroidx/lifecycle/wA$AZxh;-><init>(Ljava/lang/String;I)V

    sput-object v0, Landroidx/lifecycle/wA$AZxh;->wA:Landroidx/lifecycle/wA$AZxh;

    new-instance v0, Landroidx/lifecycle/wA$AZxh;

    const-string v1, "STARTED"

    const/4 v2, 0x3

    invoke-direct {v0, v1, v2}, Landroidx/lifecycle/wA$AZxh;-><init>(Ljava/lang/String;I)V

    sput-object v0, Landroidx/lifecycle/wA$AZxh;->ZfxDd:Landroidx/lifecycle/wA$AZxh;

    new-instance v0, Landroidx/lifecycle/wA$AZxh;

    const-string v1, "RESUMED"

    const/4 v2, 0x4

    invoke-direct {v0, v1, v2}, Landroidx/lifecycle/wA$AZxh;-><init>(Ljava/lang/String;I)V

    sput-object v0, Landroidx/lifecycle/wA$AZxh;->KLFTb:Landroidx/lifecycle/wA$AZxh;

    invoke-static {}, Landroidx/lifecycle/wA$AZxh;->KLFTb()[Landroidx/lifecycle/wA$AZxh;

    move-result-object v0

    sput-object v0, Landroidx/lifecycle/wA$AZxh;->JHa:[Landroidx/lifecycle/wA$AZxh;

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;I)V
    .locals 0

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    return-void
.end method

.method public static final synthetic KLFTb()[Landroidx/lifecycle/wA$AZxh;
    .locals 5

    sget-object v0, Landroidx/lifecycle/wA$AZxh;->mjFkc:Landroidx/lifecycle/wA$AZxh;

    sget-object v1, Landroidx/lifecycle/wA$AZxh;->AZxh:Landroidx/lifecycle/wA$AZxh;

    sget-object v2, Landroidx/lifecycle/wA$AZxh;->wA:Landroidx/lifecycle/wA$AZxh;

    sget-object v3, Landroidx/lifecycle/wA$AZxh;->ZfxDd:Landroidx/lifecycle/wA$AZxh;

    sget-object v4, Landroidx/lifecycle/wA$AZxh;->KLFTb:Landroidx/lifecycle/wA$AZxh;

    filled-new-array {v0, v1, v2, v3, v4}, [Landroidx/lifecycle/wA$AZxh;

    move-result-object v0

    return-object v0
.end method

.method public static valueOf(Ljava/lang/String;)Landroidx/lifecycle/wA$AZxh;
    .locals 1

    const-class v0, Landroidx/lifecycle/wA$AZxh;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, Landroidx/lifecycle/wA$AZxh;

    return-object p0
.end method

.method public static values()[Landroidx/lifecycle/wA$AZxh;
    .locals 1

    sget-object v0, Landroidx/lifecycle/wA$AZxh;->JHa:[Landroidx/lifecycle/wA$AZxh;

    invoke-virtual {v0}, [Ljava/lang/Object;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Landroidx/lifecycle/wA$AZxh;

    return-object v0
.end method


# virtual methods
.method public final lgHUyS(Landroidx/lifecycle/wA$AZxh;)Z
    .locals 1

    const-string v0, "state"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p0, p1}, Ljava/lang/Enum;->compareTo(Ljava/lang/Enum;)I

    move-result p0

    if-ltz p0, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method
