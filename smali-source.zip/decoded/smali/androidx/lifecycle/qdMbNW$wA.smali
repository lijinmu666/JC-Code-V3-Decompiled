.class public final Landroidx/lifecycle/qdMbNW$wA;
.super Lo/Ipwl;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Landroidx/lifecycle/qdMbNW;->qdMbNW(Landroid/content/Context;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Landroidx/lifecycle/qdMbNW;


# direct methods
.method public constructor <init>(Landroidx/lifecycle/qdMbNW;)V
    .locals 0

    iput-object p1, p0, Landroidx/lifecycle/qdMbNW$wA;->this$0:Landroidx/lifecycle/qdMbNW;

    invoke-direct {p0}, Lo/Ipwl;-><init>()V

    return-void
.end method


# virtual methods
.method public onActivityCreated(Landroid/app/Activity;Landroid/os/Bundle;)V
    .locals 0

    const-string p0, "activity"

    invoke-static {p1, p0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    return-void
.end method

.method public onActivityPaused(Landroid/app/Activity;)V
    .locals 1

    const-string v0, "activity"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object p0, p0, Landroidx/lifecycle/qdMbNW$wA;->this$0:Landroidx/lifecycle/qdMbNW;

    invoke-virtual {p0}, Landroidx/lifecycle/qdMbNW;->ZfxDd()V

    return-void
.end method

.method public onActivityPreCreated(Landroid/app/Activity;Landroid/os/Bundle;)V
    .locals 0

    const-string p2, "activity"

    invoke-static {p1, p2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance p2, Landroidx/lifecycle/qdMbNW$wA$mjFkc;

    iget-object p0, p0, Landroidx/lifecycle/qdMbNW$wA;->this$0:Landroidx/lifecycle/qdMbNW;

    invoke-direct {p2, p0}, Landroidx/lifecycle/qdMbNW$wA$mjFkc;-><init>(Landroidx/lifecycle/qdMbNW;)V

    invoke-static {p1, p2}, Landroidx/lifecycle/qdMbNW$mjFkc;->mjFkc(Landroid/app/Activity;Landroid/app/Application$ActivityLifecycleCallbacks;)V

    return-void
.end method

.method public onActivityStopped(Landroid/app/Activity;)V
    .locals 1

    const-string v0, "activity"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object p0, p0, Landroidx/lifecycle/qdMbNW$wA;->this$0:Landroidx/lifecycle/qdMbNW;

    invoke-virtual {p0}, Landroidx/lifecycle/qdMbNW;->lgHUyS()V

    return-void
.end method
