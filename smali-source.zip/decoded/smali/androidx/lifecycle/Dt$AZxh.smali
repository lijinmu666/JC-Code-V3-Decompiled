.class public final Landroidx/lifecycle/Dt$AZxh;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/lifecycle/Dt;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "AZxh"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Landroidx/lifecycle/Dt$AZxh;-><init>()V

    return-void
.end method


# virtual methods
.method public final AZxh(Landroid/app/Activity;)V
    .locals 2

    const-string p0, "activity"

    invoke-static {p1, p0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object p0, Landroidx/lifecycle/Dt$wA;->Companion:Landroidx/lifecycle/Dt$wA$mjFkc;

    invoke-virtual {p0, p1}, Landroidx/lifecycle/Dt$wA$mjFkc;->mjFkc(Landroid/app/Activity;)V

    invoke-virtual {p1}, Landroid/app/Activity;->getFragmentManager()Landroid/app/FragmentManager;

    move-result-object p0

    const-string p1, "androidx.lifecycle.LifecycleDispatcher.report_fragment_tag"

    invoke-virtual {p0, p1}, Landroid/app/FragmentManager;->findFragmentByTag(Ljava/lang/String;)Landroid/app/Fragment;

    move-result-object v0

    if-nez v0, :cond_0

    invoke-virtual {p0}, Landroid/app/FragmentManager;->beginTransaction()Landroid/app/FragmentTransaction;

    move-result-object v0

    new-instance v1, Landroidx/lifecycle/Dt;

    invoke-direct {v1}, Landroidx/lifecycle/Dt;-><init>()V

    invoke-virtual {v0, v1, p1}, Landroid/app/FragmentTransaction;->add(Landroid/app/Fragment;Ljava/lang/String;)Landroid/app/FragmentTransaction;

    move-result-object p1

    invoke-virtual {p1}, Landroid/app/FragmentTransaction;->commit()I

    invoke-virtual {p0}, Landroid/app/FragmentManager;->executePendingTransactions()Z

    :cond_0
    return-void
.end method

.method public final mjFkc(Landroid/app/Activity;Landroidx/lifecycle/wA$mjFkc;)V
    .locals 0

    const-string p0, "activity"

    invoke-static {p1, p0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string p0, "event"

    invoke-static {p2, p0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    instance-of p0, p1, Lo/W0;

    if-eqz p0, :cond_0

    check-cast p1, Lo/W0;

    invoke-interface {p1}, Lo/W0;->JHa()Landroidx/lifecycle/wA;

    move-result-object p0

    instance-of p1, p0, Landroidx/lifecycle/JHa;

    if-eqz p1, :cond_0

    check-cast p0, Landroidx/lifecycle/JHa;

    invoke-virtual {p0, p2}, Landroidx/lifecycle/JHa;->lgHUyS(Landroidx/lifecycle/wA$mjFkc;)V

    :cond_0
    return-void
.end method
