.class public Landroidx/lifecycle/mjFkc$mjFkc;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/lifecycle/mjFkc;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "mjFkc"
.end annotation


# instance fields
.field public final AZxh:Ljava/util/Map;

.field public final mjFkc:Ljava/util/Map;


# direct methods
.method public constructor <init>(Ljava/util/Map;)V
    .locals 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/lifecycle/mjFkc$mjFkc;->AZxh:Ljava/util/Map;

    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    iput-object v0, p0, Landroidx/lifecycle/mjFkc$mjFkc;->mjFkc:Ljava/util/Map;

    invoke-interface {p1}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object p1

    invoke-interface {p1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_0
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_1

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/Map$Entry;

    invoke-interface {v0}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroidx/lifecycle/wA$mjFkc;

    iget-object v2, p0, Landroidx/lifecycle/mjFkc$mjFkc;->mjFkc:Ljava/util/Map;

    invoke-interface {v2, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/util/List;

    if-nez v2, :cond_0

    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    iget-object v3, p0, Landroidx/lifecycle/mjFkc$mjFkc;->mjFkc:Ljava/util/Map;

    invoke-interface {v3, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_0
    invoke-interface {v0}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroidx/lifecycle/mjFkc$AZxh;

    invoke-interface {v2, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_1
    return-void
.end method

.method public static AZxh(Ljava/util/List;Lo/W0;Landroidx/lifecycle/wA$mjFkc;Ljava/lang/Object;)V
    .locals 2

    if-eqz p0, :cond_0

    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v0

    add-int/lit8 v0, v0, -0x1

    :goto_0
    if-ltz v0, :cond_0

    invoke-interface {p0, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroidx/lifecycle/mjFkc$AZxh;

    invoke-virtual {v1, p1, p2, p3}, Landroidx/lifecycle/mjFkc$AZxh;->mjFkc(Lo/W0;Landroidx/lifecycle/wA$mjFkc;Ljava/lang/Object;)V

    add-int/lit8 v0, v0, -0x1

    goto :goto_0

    :cond_0
    return-void
.end method


# virtual methods
.method public mjFkc(Lo/W0;Landroidx/lifecycle/wA$mjFkc;Ljava/lang/Object;)V
    .locals 1

    iget-object v0, p0, Landroidx/lifecycle/mjFkc$mjFkc;->mjFkc:Ljava/util/Map;

    invoke-interface {v0, p2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/List;

    invoke-static {v0, p1, p2, p3}, Landroidx/lifecycle/mjFkc$mjFkc;->AZxh(Ljava/util/List;Lo/W0;Landroidx/lifecycle/wA$mjFkc;Ljava/lang/Object;)V

    iget-object p0, p0, Landroidx/lifecycle/mjFkc$mjFkc;->mjFkc:Ljava/util/Map;

    sget-object v0, Landroidx/lifecycle/wA$mjFkc;->ON_ANY:Landroidx/lifecycle/wA$mjFkc;

    invoke-interface {p0, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/util/List;

    invoke-static {p0, p1, p2, p3}, Landroidx/lifecycle/mjFkc$mjFkc;->AZxh(Ljava/util/List;Lo/W0;Landroidx/lifecycle/wA$mjFkc;Ljava/lang/Object;)V

    return-void
.end method
