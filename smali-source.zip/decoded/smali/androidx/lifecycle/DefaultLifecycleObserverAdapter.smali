.class public final Landroidx/lifecycle/DefaultLifecycleObserverAdapter;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/lifecycle/KLFTb;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/lifecycle/DefaultLifecycleObserverAdapter$mjFkc;
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000$\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\u0008\u0007\u0008\u0000\u0018\u00002\u00020\u0001B\u0019\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\u0008\u0010\u0004\u001a\u0004\u0018\u00010\u0001\u00a2\u0006\u0004\u0008\u0005\u0010\u0006J\u001f\u0010\u000c\u001a\u00020\u000b2\u0006\u0010\u0008\u001a\u00020\u00072\u0006\u0010\n\u001a\u00020\tH\u0016\u00a2\u0006\u0004\u0008\u000c\u0010\rR\u0014\u0010\u0003\u001a\u00020\u00028\u0002X\u0082\u0004\u00a2\u0006\u0006\n\u0004\u0008\u000e\u0010\u000fR\u0016\u0010\u0004\u001a\u0004\u0018\u00010\u00018\u0002X\u0082\u0004\u00a2\u0006\u0006\n\u0004\u0008\u0010\u0010\u0011\u00a8\u0006\u0012"
    }
    d2 = {
        "Landroidx/lifecycle/DefaultLifecycleObserverAdapter;",
        "Landroidx/lifecycle/KLFTb;",
        "Lo/sMIIyd;",
        "defaultLifecycleObserver",
        "lifecycleEventObserver",
        "<init>",
        "(Lo/sMIIyd;Landroidx/lifecycle/KLFTb;)V",
        "Lo/W0;",
        "source",
        "Landroidx/lifecycle/wA$mjFkc;",
        "event",
        "",
        "VA",
        "(Lo/W0;Landroidx/lifecycle/wA$mjFkc;)V",
        "mjFkc",
        "Lo/sMIIyd;",
        "AZxh",
        "Landroidx/lifecycle/KLFTb;",
        "lifecycle-common"
    }
    k = 0x1
    mv = {
        0x1,
        0x8,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field public final AZxh:Landroidx/lifecycle/KLFTb;

.field public final mjFkc:Lo/sMIIyd;


# direct methods
.method public constructor <init>(Lo/sMIIyd;Landroidx/lifecycle/KLFTb;)V
    .locals 1

    const-string v0, "defaultLifecycleObserver"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/lifecycle/DefaultLifecycleObserverAdapter;->mjFkc:Lo/sMIIyd;

    iput-object p2, p0, Landroidx/lifecycle/DefaultLifecycleObserverAdapter;->AZxh:Landroidx/lifecycle/KLFTb;

    return-void
.end method


# virtual methods
.method public VA(Lo/W0;Landroidx/lifecycle/wA$mjFkc;)V
    .locals 2

    const-string v0, "source"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "event"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object v0, Landroidx/lifecycle/DefaultLifecycleObserverAdapter$mjFkc;->mjFkc:[I

    invoke-virtual {p2}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    aget v0, v0, v1

    packed-switch v0, :pswitch_data_0

    goto :goto_0

    :pswitch_0
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string p1, "ON_ANY must not been send by anybody"

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0

    :pswitch_1
    iget-object v0, p0, Landroidx/lifecycle/DefaultLifecycleObserverAdapter;->mjFkc:Lo/sMIIyd;

    invoke-interface {v0, p1}, Lo/sMIIyd;->xJ(Lo/W0;)V

    goto :goto_0

    :pswitch_2
    iget-object v0, p0, Landroidx/lifecycle/DefaultLifecycleObserverAdapter;->mjFkc:Lo/sMIIyd;

    invoke-interface {v0, p1}, Lo/sMIIyd;->fehf(Lo/W0;)V

    goto :goto_0

    :pswitch_3
    iget-object v0, p0, Landroidx/lifecycle/DefaultLifecycleObserverAdapter;->mjFkc:Lo/sMIIyd;

    invoke-interface {v0, p1}, Lo/sMIIyd;->MiMN(Lo/W0;)V

    goto :goto_0

    :pswitch_4
    iget-object v0, p0, Landroidx/lifecycle/DefaultLifecycleObserverAdapter;->mjFkc:Lo/sMIIyd;

    invoke-interface {v0, p1}, Lo/sMIIyd;->lgHUyS(Lo/W0;)V

    goto :goto_0

    :pswitch_5
    iget-object v0, p0, Landroidx/lifecycle/DefaultLifecycleObserverAdapter;->mjFkc:Lo/sMIIyd;

    invoke-interface {v0, p1}, Lo/sMIIyd;->KLFTb(Lo/W0;)V

    goto :goto_0

    :pswitch_6
    iget-object v0, p0, Landroidx/lifecycle/DefaultLifecycleObserverAdapter;->mjFkc:Lo/sMIIyd;

    invoke-interface {v0, p1}, Lo/sMIIyd;->qdMbNW(Lo/W0;)V

    :goto_0
    iget-object p0, p0, Landroidx/lifecycle/DefaultLifecycleObserverAdapter;->AZxh:Landroidx/lifecycle/KLFTb;

    if-eqz p0, :cond_0

    invoke-interface {p0, p1, p2}, Landroidx/lifecycle/KLFTb;->VA(Lo/W0;Landroidx/lifecycle/wA$mjFkc;)V

    :cond_0
    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
