.class public final Landroidx/lifecycle/Dt$wA;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/app/Application$ActivityLifecycleCallbacks;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/lifecycle/Dt;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "wA"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/lifecycle/Dt$wA$mjFkc;
    }
.end annotation


# static fields
.field public static final Companion:Landroidx/lifecycle/Dt$wA$mjFkc;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    new-instance v0, Landroidx/lifecycle/Dt$wA$mjFkc;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Landroidx/lifecycle/Dt$wA$mjFkc;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    sput-object v0, Landroidx/lifecycle/Dt$wA;->Companion:Landroidx/lifecycle/Dt$wA$mjFkc;

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static final registerIn(Landroid/app/Activity;)V
    .locals 1
    .annotation runtime Lkotlin/jvm/JvmStatic;
    .end annotation

    sget-object v0, Landroidx/lifecycle/Dt$wA;->Companion:Landroidx/lifecycle/Dt$wA$mjFkc;

    invoke-virtual {v0, p0}, Landroidx/lifecycle/Dt$wA$mjFkc;->mjFkc(Landroid/app/Activity;)V

    return-void
.end method


# virtual methods
.method public onActivityCreated(Landroid/app/Activity;Landroid/os/Bundle;)V
    .locals 0

    const-string p0, "activity"

    invoke-static {p1, p0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    return-void
.end method

.method public onActivityDestroyed(Landroid/app/Activity;)V
    .locals 0

    const-string p0, "activity"

    invoke-static {p1, p0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    return-void
.end method

.method public onActivityPaused(Landroid/app/Activity;)V
    .locals 0

    const-string p0, "activity"

    invoke-static {p1, p0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    return-void
.end method

.method public onActivityPostCreated(Landroid/app/Activity;Landroid/os/Bundle;)V
    .locals 0

    const-string p0, "activity"

    invoke-static {p1, p0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object p0, Landroidx/lifecycle/Dt;->AZxh:Landroidx/lifecycle/Dt$AZxh;

    sget-object p2, Landroidx/lifecycle/wA$mjFkc;->ON_CREATE:Landroidx/lifecycle/wA$mjFkc;

    invoke-virtual {p0, p1, p2}, Landroidx/lifecycle/Dt$AZxh;->mjFkc(Landroid/app/Activity;Landroidx/lifecycle/wA$mjFkc;)V

    return-void
.end method

.method public onActivityPostResumed(Landroid/app/Activity;)V
    .locals 1

    const-string p0, "activity"

    invoke-static {p1, p0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object p0, Landroidx/lifecycle/Dt;->AZxh:Landroidx/lifecycle/Dt$AZxh;

    sget-object v0, Landroidx/lifecycle/wA$mjFkc;->ON_RESUME:Landroidx/lifecycle/wA$mjFkc;

    invoke-virtual {p0, p1, v0}, Landroidx/lifecycle/Dt$AZxh;->mjFkc(Landroid/app/Activity;Landroidx/lifecycle/wA$mjFkc;)V

    return-void
.end method

.method public onActivityPostStarted(Landroid/app/Activity;)V
    .locals 1

    const-string p0, "activity"

    invoke-static {p1, p0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object p0, Landroidx/lifecycle/Dt;->AZxh:Landroidx/lifecycle/Dt$AZxh;

    sget-object v0, Landroidx/lifecycle/wA$mjFkc;->ON_START:Landroidx/lifecycle/wA$mjFkc;

    invoke-virtual {p0, p1, v0}, Landroidx/lifecycle/Dt$AZxh;->mjFkc(Landroid/app/Activity;Landroidx/lifecycle/wA$mjFkc;)V

    return-void
.end method

.method public onActivityPreDestroyed(Landroid/app/Activity;)V
    .locals 1

    const-string p0, "activity"

    invoke-static {p1, p0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object p0, Landroidx/lifecycle/Dt;->AZxh:Landroidx/lifecycle/Dt$AZxh;

    sget-object v0, Landroidx/lifecycle/wA$mjFkc;->ON_DESTROY:Landroidx/lifecycle/wA$mjFkc;

    invoke-virtual {p0, p1, v0}, Landroidx/lifecycle/Dt$AZxh;->mjFkc(Landroid/app/Activity;Landroidx/lifecycle/wA$mjFkc;)V

    return-void
.end method

.method public onActivityPrePaused(Landroid/app/Activity;)V
    .locals 1

    const-string p0, "activity"

    invoke-static {p1, p0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object p0, Landroidx/lifecycle/Dt;->AZxh:Landroidx/lifecycle/Dt$AZxh;

    sget-object v0, Landroidx/lifecycle/wA$mjFkc;->ON_PAUSE:Landroidx/lifecycle/wA$mjFkc;

    invoke-virtual {p0, p1, v0}, Landroidx/lifecycle/Dt$AZxh;->mjFkc(Landroid/app/Activity;Landroidx/lifecycle/wA$mjFkc;)V

    return-void
.end method

.method public onActivityPreStopped(Landroid/app/Activity;)V
    .locals 1

    const-string p0, "activity"

    invoke-static {p1, p0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object p0, Landroidx/lifecycle/Dt;->AZxh:Landroidx/lifecycle/Dt$AZxh;

    sget-object v0, Landroidx/lifecycle/wA$mjFkc;->ON_STOP:Landroidx/lifecycle/wA$mjFkc;

    invoke-virtual {p0, p1, v0}, Landroidx/lifecycle/Dt$AZxh;->mjFkc(Landroid/app/Activity;Landroidx/lifecycle/wA$mjFkc;)V

    return-void
.end method

.method public onActivityResumed(Landroid/app/Activity;)V
    .locals 0

    const-string p0, "activity"

    invoke-static {p1, p0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    return-void
.end method

.method public onActivitySaveInstanceState(Landroid/app/Activity;Landroid/os/Bundle;)V
    .locals 0

    const-string p0, "activity"

    invoke-static {p1, p0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string p0, "bundle"

    invoke-static {p2, p0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    return-void
.end method

.method public onActivityStarted(Landroid/app/Activity;)V
    .locals 0

    const-string p0, "activity"

    invoke-static {p1, p0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    return-void
.end method

.method public onActivityStopped(Landroid/app/Activity;)V
    .locals 0

    const-string p0, "activity"

    invoke-static {p1, p0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    return-void
.end method
