.class public final Landroidx/lifecycle/JHa$AZxh;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/lifecycle/JHa;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "AZxh"
.end annotation


# instance fields
.field public AZxh:Landroidx/lifecycle/KLFTb;

.field public mjFkc:Landroidx/lifecycle/wA$AZxh;


# direct methods
.method public constructor <init>(Lo/V0;Landroidx/lifecycle/wA$AZxh;)V
    .locals 1

    const-string v0, "initialState"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    invoke-static {p1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    invoke-static {p1}, Landroidx/lifecycle/xJ;->JHa(Ljava/lang/Object;)Landroidx/lifecycle/KLFTb;

    move-result-object p1

    iput-object p1, p0, Landroidx/lifecycle/JHa$AZxh;->AZxh:Landroidx/lifecycle/KLFTb;

    iput-object p2, p0, Landroidx/lifecycle/JHa$AZxh;->mjFkc:Landroidx/lifecycle/wA$AZxh;

    return-void
.end method


# virtual methods
.method public final AZxh()Landroidx/lifecycle/wA$AZxh;
    .locals 0

    iget-object p0, p0, Landroidx/lifecycle/JHa$AZxh;->mjFkc:Landroidx/lifecycle/wA$AZxh;

    return-object p0
.end method

.method public final mjFkc(Lo/W0;Landroidx/lifecycle/wA$mjFkc;)V
    .locals 3

    const-string v0, "event"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p2}, Landroidx/lifecycle/wA$mjFkc;->lgHUyS()Landroidx/lifecycle/wA$AZxh;

    move-result-object v0

    sget-object v1, Landroidx/lifecycle/JHa;->Dt:Landroidx/lifecycle/JHa$mjFkc;

    iget-object v2, p0, Landroidx/lifecycle/JHa$AZxh;->mjFkc:Landroidx/lifecycle/wA$AZxh;

    invoke-virtual {v1, v2, v0}, Landroidx/lifecycle/JHa$mjFkc;->mjFkc(Landroidx/lifecycle/wA$AZxh;Landroidx/lifecycle/wA$AZxh;)Landroidx/lifecycle/wA$AZxh;

    move-result-object v1

    iput-object v1, p0, Landroidx/lifecycle/JHa$AZxh;->mjFkc:Landroidx/lifecycle/wA$AZxh;

    iget-object v1, p0, Landroidx/lifecycle/JHa$AZxh;->AZxh:Landroidx/lifecycle/KLFTb;

    invoke-static {p1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    invoke-interface {v1, p1, p2}, Landroidx/lifecycle/KLFTb;->VA(Lo/W0;Landroidx/lifecycle/wA$mjFkc;)V

    iput-object v0, p0, Landroidx/lifecycle/JHa$AZxh;->mjFkc:Landroidx/lifecycle/wA$AZxh;

    return-void
.end method
