.class public Landroidx/lifecycle/Dt;
.super Landroid/app/Fragment;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/lifecycle/Dt$mjFkc;,
        Landroidx/lifecycle/Dt$AZxh;,
        Landroidx/lifecycle/Dt$wA;
    }
.end annotation


# static fields
.field public static final AZxh:Landroidx/lifecycle/Dt$AZxh;


# instance fields
.field public mjFkc:Landroidx/lifecycle/Dt$mjFkc;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    new-instance v0, Landroidx/lifecycle/Dt$AZxh;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Landroidx/lifecycle/Dt$AZxh;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    sput-object v0, Landroidx/lifecycle/Dt;->AZxh:Landroidx/lifecycle/Dt$AZxh;

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Landroid/app/Fragment;-><init>()V

    return-void
.end method


# virtual methods
.method public final AZxh(Landroidx/lifecycle/Dt$mjFkc;)V
    .locals 0

    if-eqz p1, :cond_0

    invoke-interface {p1}, Landroidx/lifecycle/Dt$mjFkc;->mjFkc()V

    :cond_0
    return-void
.end method

.method public final ZfxDd(Landroidx/lifecycle/Dt$mjFkc;)V
    .locals 0

    if-eqz p1, :cond_0

    invoke-interface {p1}, Landroidx/lifecycle/Dt$mjFkc;->wA()V

    :cond_0
    return-void
.end method

.method public final mjFkc(Landroidx/lifecycle/wA$mjFkc;)V
    .locals 0

    return-void
.end method

.method public onActivityCreated(Landroid/os/Bundle;)V
    .locals 0

    invoke-super {p0, p1}, Landroid/app/Fragment;->onActivityCreated(Landroid/os/Bundle;)V

    iget-object p1, p0, Landroidx/lifecycle/Dt;->mjFkc:Landroidx/lifecycle/Dt$mjFkc;

    invoke-virtual {p0, p1}, Landroidx/lifecycle/Dt;->AZxh(Landroidx/lifecycle/Dt$mjFkc;)V

    sget-object p1, Landroidx/lifecycle/wA$mjFkc;->ON_CREATE:Landroidx/lifecycle/wA$mjFkc;

    invoke-virtual {p0, p1}, Landroidx/lifecycle/Dt;->mjFkc(Landroidx/lifecycle/wA$mjFkc;)V

    return-void
.end method

.method public onDestroy()V
    .locals 1

    invoke-super {p0}, Landroid/app/Fragment;->onDestroy()V

    sget-object v0, Landroidx/lifecycle/wA$mjFkc;->ON_DESTROY:Landroidx/lifecycle/wA$mjFkc;

    invoke-virtual {p0, v0}, Landroidx/lifecycle/Dt;->mjFkc(Landroidx/lifecycle/wA$mjFkc;)V

    const/4 v0, 0x0

    iput-object v0, p0, Landroidx/lifecycle/Dt;->mjFkc:Landroidx/lifecycle/Dt$mjFkc;

    return-void
.end method

.method public onPause()V
    .locals 1

    invoke-super {p0}, Landroid/app/Fragment;->onPause()V

    sget-object v0, Landroidx/lifecycle/wA$mjFkc;->ON_PAUSE:Landroidx/lifecycle/wA$mjFkc;

    invoke-virtual {p0, v0}, Landroidx/lifecycle/Dt;->mjFkc(Landroidx/lifecycle/wA$mjFkc;)V

    return-void
.end method

.method public onResume()V
    .locals 1

    invoke-super {p0}, Landroid/app/Fragment;->onResume()V

    iget-object v0, p0, Landroidx/lifecycle/Dt;->mjFkc:Landroidx/lifecycle/Dt$mjFkc;

    invoke-virtual {p0, v0}, Landroidx/lifecycle/Dt;->wA(Landroidx/lifecycle/Dt$mjFkc;)V

    sget-object v0, Landroidx/lifecycle/wA$mjFkc;->ON_RESUME:Landroidx/lifecycle/wA$mjFkc;

    invoke-virtual {p0, v0}, Landroidx/lifecycle/Dt;->mjFkc(Landroidx/lifecycle/wA$mjFkc;)V

    return-void
.end method

.method public onStart()V
    .locals 1

    invoke-super {p0}, Landroid/app/Fragment;->onStart()V

    iget-object v0, p0, Landroidx/lifecycle/Dt;->mjFkc:Landroidx/lifecycle/Dt$mjFkc;

    invoke-virtual {p0, v0}, Landroidx/lifecycle/Dt;->ZfxDd(Landroidx/lifecycle/Dt$mjFkc;)V

    sget-object v0, Landroidx/lifecycle/wA$mjFkc;->ON_START:Landroidx/lifecycle/wA$mjFkc;

    invoke-virtual {p0, v0}, Landroidx/lifecycle/Dt;->mjFkc(Landroidx/lifecycle/wA$mjFkc;)V

    return-void
.end method

.method public onStop()V
    .locals 1

    invoke-super {p0}, Landroid/app/Fragment;->onStop()V

    sget-object v0, Landroidx/lifecycle/wA$mjFkc;->ON_STOP:Landroidx/lifecycle/wA$mjFkc;

    invoke-virtual {p0, v0}, Landroidx/lifecycle/Dt;->mjFkc(Landroidx/lifecycle/wA$mjFkc;)V

    return-void
.end method

.method public final wA(Landroidx/lifecycle/Dt$mjFkc;)V
    .locals 0

    if-eqz p1, :cond_0

    invoke-interface {p1}, Landroidx/lifecycle/Dt$mjFkc;->AZxh()V

    :cond_0
    return-void
.end method
