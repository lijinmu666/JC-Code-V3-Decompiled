.class public Landroidx/emoji2/text/wA$mjFkc$mjFkc;
.super Landroidx/emoji2/text/wA$lgHUyS;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Landroidx/emoji2/text/wA$mjFkc;->mjFkc()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic mjFkc:Landroidx/emoji2/text/wA$mjFkc;


# direct methods
.method public constructor <init>(Landroidx/emoji2/text/wA$mjFkc;)V
    .locals 0

    iput-object p1, p0, Landroidx/emoji2/text/wA$mjFkc$mjFkc;->mjFkc:Landroidx/emoji2/text/wA$mjFkc;

    invoke-direct {p0}, Landroidx/emoji2/text/wA$lgHUyS;-><init>()V

    return-void
.end method


# virtual methods
.method public AZxh(Landroidx/emoji2/text/JHa;)V
    .locals 0

    iget-object p0, p0, Landroidx/emoji2/text/wA$mjFkc$mjFkc;->mjFkc:Landroidx/emoji2/text/wA$mjFkc;

    invoke-virtual {p0, p1}, Landroidx/emoji2/text/wA$mjFkc;->ZfxDd(Landroidx/emoji2/text/JHa;)V

    return-void
.end method

.method public mjFkc(Ljava/lang/Throwable;)V
    .locals 0

    iget-object p0, p0, Landroidx/emoji2/text/wA$mjFkc$mjFkc;->mjFkc:Landroidx/emoji2/text/wA$mjFkc;

    iget-object p0, p0, Landroidx/emoji2/text/wA$AZxh;->mjFkc:Landroidx/emoji2/text/wA;

    invoke-virtual {p0, p1}, Landroidx/emoji2/text/wA;->MiMN(Ljava/lang/Throwable;)V

    return-void
.end method
