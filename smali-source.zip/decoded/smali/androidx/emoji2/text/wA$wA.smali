.class public abstract Landroidx/emoji2/text/wA$wA;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/emoji2/text/wA;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "wA"
.end annotation


# instance fields
.field public AZxh:Z

.field public JHa:Z

.field public KLFTb:Ljava/util/Set;

.field public ZfxDd:[I

.field public lgHUyS:I

.field public final mjFkc:Landroidx/emoji2/text/wA$xJ;

.field public qdMbNW:Landroidx/emoji2/text/wA$ZfxDd;

.field public wA:Z

.field public xJ:I


# direct methods
.method public constructor <init>(Landroidx/emoji2/text/wA$xJ;)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const v0, -0xff0100

    iput v0, p0, Landroidx/emoji2/text/wA$wA;->xJ:I

    const/4 v0, 0x0

    iput v0, p0, Landroidx/emoji2/text/wA$wA;->lgHUyS:I

    new-instance v0, Landroidx/emoji2/text/AZxh;

    invoke-direct {v0}, Landroidx/emoji2/text/AZxh;-><init>()V

    iput-object v0, p0, Landroidx/emoji2/text/wA$wA;->qdMbNW:Landroidx/emoji2/text/wA$ZfxDd;

    const-string v0, "metadataLoader cannot be null."

    invoke-static {p1, v0}, Lo/K3;->lgHUyS(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    iput-object p1, p0, Landroidx/emoji2/text/wA$wA;->mjFkc:Landroidx/emoji2/text/wA$xJ;

    return-void
.end method


# virtual methods
.method public AZxh(I)Landroidx/emoji2/text/wA$wA;
    .locals 0

    iput p1, p0, Landroidx/emoji2/text/wA$wA;->lgHUyS:I

    return-object p0
.end method

.method public final mjFkc()Landroidx/emoji2/text/wA$xJ;
    .locals 0

    iget-object p0, p0, Landroidx/emoji2/text/wA$wA;->mjFkc:Landroidx/emoji2/text/wA$xJ;

    return-object p0
.end method
