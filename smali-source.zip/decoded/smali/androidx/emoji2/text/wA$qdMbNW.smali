.class public Landroidx/emoji2/text/wA$qdMbNW;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/emoji2/text/wA;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "qdMbNW"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public mjFkc(Lo/vL;)Lo/Frh;
    .locals 0

    new-instance p0, Lo/q9;

    invoke-direct {p0, p1}, Lo/q9;-><init>(Lo/vL;)V

    return-object p0
.end method
