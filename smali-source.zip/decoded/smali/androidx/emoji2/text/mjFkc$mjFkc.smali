.class public Landroidx/emoji2/text/mjFkc$mjFkc;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/emoji2/text/mjFkc;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "mjFkc"
.end annotation


# instance fields
.field public final mjFkc:Landroidx/emoji2/text/mjFkc$AZxh;


# direct methods
.method public constructor <init>(Landroidx/emoji2/text/mjFkc$AZxh;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    if-eqz p1, :cond_0

    goto :goto_0

    :cond_0
    invoke-static {}, Landroidx/emoji2/text/mjFkc$mjFkc;->KLFTb()Landroidx/emoji2/text/mjFkc$AZxh;

    move-result-object p1

    :goto_0
    iput-object p1, p0, Landroidx/emoji2/text/mjFkc$mjFkc;->mjFkc:Landroidx/emoji2/text/mjFkc$AZxh;

    return-void
.end method

.method public static KLFTb()Landroidx/emoji2/text/mjFkc$AZxh;
    .locals 1

    new-instance v0, Landroidx/emoji2/text/mjFkc$ZfxDd;

    invoke-direct {v0}, Landroidx/emoji2/text/mjFkc$ZfxDd;-><init>()V

    return-object v0
.end method


# virtual methods
.method public final AZxh([Landroid/content/pm/Signature;)Ljava/util/List;
    .locals 3

    new-instance p0, Ljava/util/ArrayList;

    invoke-direct {p0}, Ljava/util/ArrayList;-><init>()V

    array-length v0, p1

    const/4 v1, 0x0

    :goto_0
    if-ge v1, v0, :cond_0

    aget-object v2, p1, v1

    invoke-virtual {v2}, Landroid/content/pm/Signature;->toByteArray()[B

    move-result-object v2

    invoke-interface {p0, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_0
    invoke-static {p0}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    move-result-object p0

    return-object p0
.end method

.method public final JHa(Landroid/content/pm/ProviderInfo;)Z
    .locals 0

    if-eqz p1, :cond_0

    iget-object p0, p1, Landroid/content/pm/ProviderInfo;->applicationInfo:Landroid/content/pm/ApplicationInfo;

    if-eqz p0, :cond_0

    iget p0, p0, Landroid/content/pm/ApplicationInfo;->flags:I

    const/4 p1, 0x1

    and-int/2addr p0, p1

    if-ne p0, p1, :cond_0

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    :goto_0
    return p1
.end method

.method public final ZfxDd(Landroid/content/pm/ProviderInfo;Landroid/content/pm/PackageManager;)Lo/avDfWJ;
    .locals 2

    iget-object v0, p1, Landroid/content/pm/ProviderInfo;->authority:Ljava/lang/String;

    iget-object p1, p1, Landroid/content/pm/ProviderInfo;->packageName:Ljava/lang/String;

    iget-object v1, p0, Landroidx/emoji2/text/mjFkc$mjFkc;->mjFkc:Landroidx/emoji2/text/mjFkc$AZxh;

    invoke-virtual {v1, p2, p1}, Landroidx/emoji2/text/mjFkc$AZxh;->AZxh(Landroid/content/pm/PackageManager;Ljava/lang/String;)[Landroid/content/pm/Signature;

    move-result-object p2

    invoke-virtual {p0, p2}, Landroidx/emoji2/text/mjFkc$mjFkc;->AZxh([Landroid/content/pm/Signature;)Ljava/util/List;

    move-result-object p0

    new-instance p2, Lo/avDfWJ;

    const-string v1, "emojicompat-emoji-font"

    invoke-direct {p2, v0, p1, v1, p0}, Lo/avDfWJ;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;)V

    return-object p2
.end method

.method public lgHUyS(Landroid/content/Context;)Lo/avDfWJ;
    .locals 2

    invoke-virtual {p1}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object p1

    const-string v0, "Package manager required to locate emoji font provider"

    invoke-static {p1, v0}, Lo/K3;->lgHUyS(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {p0, p1}, Landroidx/emoji2/text/mjFkc$mjFkc;->xJ(Landroid/content/pm/PackageManager;)Landroid/content/pm/ProviderInfo;

    move-result-object v0

    const/4 v1, 0x0

    if-nez v0, :cond_0

    return-object v1

    :cond_0
    :try_start_0
    invoke-virtual {p0, v0, p1}, Landroidx/emoji2/text/mjFkc$mjFkc;->ZfxDd(Landroid/content/pm/ProviderInfo;Landroid/content/pm/PackageManager;)Lo/avDfWJ;

    move-result-object p0
    :try_end_0
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    return-object p0

    :catch_0
    move-exception p0

    const-string p1, "emoji2.text.DefaultEmojiConfig"

    invoke-static {p1, p0}, Landroid/util/Log;->wtf(Ljava/lang/String;Ljava/lang/Throwable;)I

    return-object v1
.end method

.method public final mjFkc(Landroid/content/Context;Lo/avDfWJ;)Landroidx/emoji2/text/wA$wA;
    .locals 0

    if-nez p2, :cond_0

    const/4 p0, 0x0

    return-object p0

    :cond_0
    new-instance p0, Landroidx/emoji2/text/KLFTb;

    invoke-direct {p0, p1, p2}, Landroidx/emoji2/text/KLFTb;-><init>(Landroid/content/Context;Lo/avDfWJ;)V

    return-object p0
.end method

.method public wA(Landroid/content/Context;)Landroidx/emoji2/text/wA$wA;
    .locals 1

    invoke-virtual {p0, p1}, Landroidx/emoji2/text/mjFkc$mjFkc;->lgHUyS(Landroid/content/Context;)Lo/avDfWJ;

    move-result-object v0

    invoke-virtual {p0, p1, v0}, Landroidx/emoji2/text/mjFkc$mjFkc;->mjFkc(Landroid/content/Context;Lo/avDfWJ;)Landroidx/emoji2/text/wA$wA;

    move-result-object p0

    return-object p0
.end method

.method public final xJ(Landroid/content/pm/PackageManager;)Landroid/content/pm/ProviderInfo;
    .locals 3

    iget-object v0, p0, Landroidx/emoji2/text/mjFkc$mjFkc;->mjFkc:Landroidx/emoji2/text/mjFkc$AZxh;

    new-instance v1, Landroid/content/Intent;

    const-string v2, "androidx.content.action.LOAD_EMOJI_FONT"

    invoke-direct {v1, v2}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x0

    invoke-virtual {v0, p1, v1, v2}, Landroidx/emoji2/text/mjFkc$AZxh;->wA(Landroid/content/pm/PackageManager;Landroid/content/Intent;I)Ljava/util/List;

    move-result-object p1

    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :cond_0
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_1

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/content/pm/ResolveInfo;

    iget-object v1, p0, Landroidx/emoji2/text/mjFkc$mjFkc;->mjFkc:Landroidx/emoji2/text/mjFkc$AZxh;

    invoke-virtual {v1, v0}, Landroidx/emoji2/text/mjFkc$AZxh;->mjFkc(Landroid/content/pm/ResolveInfo;)Landroid/content/pm/ProviderInfo;

    move-result-object v0

    invoke-virtual {p0, v0}, Landroidx/emoji2/text/mjFkc$mjFkc;->JHa(Landroid/content/pm/ProviderInfo;)Z

    move-result v1

    if-eqz v1, :cond_0

    return-object v0

    :cond_1
    const/4 p0, 0x0

    return-object p0
.end method
