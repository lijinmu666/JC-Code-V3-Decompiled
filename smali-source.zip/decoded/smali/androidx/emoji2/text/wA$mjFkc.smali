.class public final Landroidx/emoji2/text/wA$mjFkc;
.super Landroidx/emoji2/text/wA$AZxh;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/emoji2/text/wA;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "mjFkc"
.end annotation


# instance fields
.field public volatile AZxh:Landroidx/emoji2/text/ZfxDd;

.field public volatile wA:Landroidx/emoji2/text/JHa;


# direct methods
.method public constructor <init>(Landroidx/emoji2/text/wA;)V
    .locals 0

    invoke-direct {p0, p1}, Landroidx/emoji2/text/wA$AZxh;-><init>(Landroidx/emoji2/text/wA;)V

    return-void
.end method


# virtual methods
.method public AZxh(Ljava/lang/CharSequence;IIIZ)Ljava/lang/CharSequence;
    .locals 6

    iget-object v0, p0, Landroidx/emoji2/text/wA$mjFkc;->AZxh:Landroidx/emoji2/text/ZfxDd;

    move-object v1, p1

    move v2, p2

    move v3, p3

    move v4, p4

    move v5, p5

    invoke-virtual/range {v0 .. v5}, Landroidx/emoji2/text/ZfxDd;->lgHUyS(Ljava/lang/CharSequence;IIIZ)Ljava/lang/CharSequence;

    move-result-object p0

    return-object p0
.end method

.method public ZfxDd(Landroidx/emoji2/text/JHa;)V
    .locals 7

    if-nez p1, :cond_0

    iget-object p0, p0, Landroidx/emoji2/text/wA$AZxh;->mjFkc:Landroidx/emoji2/text/wA;

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string v0, "metadataRepo cannot be null"

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0, p1}, Landroidx/emoji2/text/wA;->MiMN(Ljava/lang/Throwable;)V

    return-void

    :cond_0
    iput-object p1, p0, Landroidx/emoji2/text/wA$mjFkc;->wA:Landroidx/emoji2/text/JHa;

    new-instance p1, Landroidx/emoji2/text/ZfxDd;

    iget-object v2, p0, Landroidx/emoji2/text/wA$mjFkc;->wA:Landroidx/emoji2/text/JHa;

    new-instance v3, Landroidx/emoji2/text/wA$qdMbNW;

    invoke-direct {v3}, Landroidx/emoji2/text/wA$qdMbNW;-><init>()V

    iget-object v0, p0, Landroidx/emoji2/text/wA$AZxh;->mjFkc:Landroidx/emoji2/text/wA;

    invoke-static {v0}, Landroidx/emoji2/text/wA;->mjFkc(Landroidx/emoji2/text/wA;)Landroidx/emoji2/text/wA$ZfxDd;

    move-result-object v4

    iget-object v0, p0, Landroidx/emoji2/text/wA$AZxh;->mjFkc:Landroidx/emoji2/text/wA;

    iget-boolean v5, v0, Landroidx/emoji2/text/wA;->lgHUyS:Z

    iget-object v6, v0, Landroidx/emoji2/text/wA;->qdMbNW:[I

    move-object v1, p1

    invoke-direct/range {v1 .. v6}, Landroidx/emoji2/text/ZfxDd;-><init>(Landroidx/emoji2/text/JHa;Landroidx/emoji2/text/wA$qdMbNW;Landroidx/emoji2/text/wA$ZfxDd;Z[I)V

    iput-object p1, p0, Landroidx/emoji2/text/wA$mjFkc;->AZxh:Landroidx/emoji2/text/ZfxDd;

    iget-object p0, p0, Landroidx/emoji2/text/wA$AZxh;->mjFkc:Landroidx/emoji2/text/wA;

    invoke-virtual {p0}, Landroidx/emoji2/text/wA;->YoKzxo()V

    return-void
.end method

.method public mjFkc()V
    .locals 2

    :try_start_0
    new-instance v0, Landroidx/emoji2/text/wA$mjFkc$mjFkc;

    invoke-direct {v0, p0}, Landroidx/emoji2/text/wA$mjFkc$mjFkc;-><init>(Landroidx/emoji2/text/wA$mjFkc;)V

    iget-object v1, p0, Landroidx/emoji2/text/wA$AZxh;->mjFkc:Landroidx/emoji2/text/wA;

    iget-object v1, v1, Landroidx/emoji2/text/wA;->JHa:Landroidx/emoji2/text/wA$xJ;

    invoke-interface {v1, v0}, Landroidx/emoji2/text/wA$xJ;->mjFkc(Landroidx/emoji2/text/wA$lgHUyS;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception v0

    iget-object p0, p0, Landroidx/emoji2/text/wA$AZxh;->mjFkc:Landroidx/emoji2/text/wA;

    invoke-virtual {p0, v0}, Landroidx/emoji2/text/wA;->MiMN(Ljava/lang/Throwable;)V

    :goto_0
    return-void
.end method

.method public wA(Landroid/view/inputmethod/EditorInfo;)V
    .locals 3

    iget-object v0, p1, Landroid/view/inputmethod/EditorInfo;->extras:Landroid/os/Bundle;

    iget-object v1, p0, Landroidx/emoji2/text/wA$mjFkc;->wA:Landroidx/emoji2/text/JHa;

    invoke-virtual {v1}, Landroidx/emoji2/text/JHa;->KLFTb()I

    move-result v1

    const-string v2, "android.support.text.emoji.emojiCompat_metadataVersion"

    invoke-virtual {v0, v2, v1}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    iget-object p1, p1, Landroid/view/inputmethod/EditorInfo;->extras:Landroid/os/Bundle;

    iget-object p0, p0, Landroidx/emoji2/text/wA$AZxh;->mjFkc:Landroidx/emoji2/text/wA;

    iget-boolean p0, p0, Landroidx/emoji2/text/wA;->xJ:Z

    const-string v0, "android.support.text.emoji.emojiCompat_replaceAll"

    invoke-virtual {p1, v0, p0}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    return-void
.end method
