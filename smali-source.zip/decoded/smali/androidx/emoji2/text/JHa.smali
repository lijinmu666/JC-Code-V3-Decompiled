.class public final Landroidx/emoji2/text/JHa;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/emoji2/text/JHa$mjFkc;
    }
.end annotation


# instance fields
.field public final AZxh:[C

.field public final ZfxDd:Landroid/graphics/Typeface;

.field public final mjFkc:Lo/d2;

.field public final wA:Landroidx/emoji2/text/JHa$mjFkc;


# direct methods
.method public constructor <init>(Landroid/graphics/Typeface;Lo/d2;)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/emoji2/text/JHa;->ZfxDd:Landroid/graphics/Typeface;

    iput-object p2, p0, Landroidx/emoji2/text/JHa;->mjFkc:Lo/d2;

    new-instance p1, Landroidx/emoji2/text/JHa$mjFkc;

    const/16 v0, 0x400

    invoke-direct {p1, v0}, Landroidx/emoji2/text/JHa$mjFkc;-><init>(I)V

    iput-object p1, p0, Landroidx/emoji2/text/JHa;->wA:Landroidx/emoji2/text/JHa$mjFkc;

    invoke-virtual {p2}, Lo/d2;->ETF()I

    move-result p1

    mul-int/lit8 p1, p1, 0x2

    new-array p1, p1, [C

    iput-object p1, p0, Landroidx/emoji2/text/JHa;->AZxh:[C

    invoke-virtual {p0, p2}, Landroidx/emoji2/text/JHa;->mjFkc(Lo/d2;)V

    return-void
.end method

.method public static AZxh(Landroid/graphics/Typeface;Ljava/nio/ByteBuffer;)Landroidx/emoji2/text/JHa;
    .locals 1

    :try_start_0
    const-string v0, "EmojiCompat.MetadataRepo.create"

    invoke-static {v0}, Lo/L8;->mjFkc(Ljava/lang/String;)V

    new-instance v0, Landroidx/emoji2/text/JHa;

    invoke-static {p1}, Lo/e2;->AZxh(Ljava/nio/ByteBuffer;)Lo/d2;

    move-result-object p1

    invoke-direct {v0, p0, p1}, Landroidx/emoji2/text/JHa;-><init>(Landroid/graphics/Typeface;Lo/d2;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    invoke-static {}, Lo/L8;->AZxh()V

    return-object v0

    :catchall_0
    move-exception p0

    invoke-static {}, Lo/L8;->AZxh()V

    throw p0
.end method


# virtual methods
.method public JHa()Landroidx/emoji2/text/JHa$mjFkc;
    .locals 0

    iget-object p0, p0, Landroidx/emoji2/text/JHa;->wA:Landroidx/emoji2/text/JHa$mjFkc;

    return-object p0
.end method

.method public KLFTb()I
    .locals 0

    iget-object p0, p0, Landroidx/emoji2/text/JHa;->mjFkc:Lo/d2;

    invoke-virtual {p0}, Lo/d2;->VA()I

    move-result p0

    return p0
.end method

.method public ZfxDd()Lo/d2;
    .locals 0

    iget-object p0, p0, Landroidx/emoji2/text/JHa;->mjFkc:Lo/d2;

    return-object p0
.end method

.method public lgHUyS(Lo/vL;)V
    .locals 4

    const-string v0, "emoji metadata cannot be null"

    invoke-static {p1, v0}, Lo/K3;->lgHUyS(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {p1}, Lo/vL;->wA()I

    move-result v0

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-lez v0, :cond_0

    move v0, v2

    goto :goto_0

    :cond_0
    move v0, v1

    :goto_0
    const-string v3, "invalid metadata codepoint length"

    invoke-static {v0, v3}, Lo/K3;->AZxh(ZLjava/lang/Object;)V

    iget-object p0, p0, Landroidx/emoji2/text/JHa;->wA:Landroidx/emoji2/text/JHa$mjFkc;

    invoke-virtual {p1}, Lo/vL;->wA()I

    move-result v0

    sub-int/2addr v0, v2

    invoke-virtual {p0, p1, v1, v0}, Landroidx/emoji2/text/JHa$mjFkc;->wA(Lo/vL;II)V

    return-void
.end method

.method public final mjFkc(Lo/d2;)V
    .locals 5

    invoke-virtual {p1}, Lo/d2;->ETF()I

    move-result p1

    const/4 v0, 0x0

    :goto_0
    if-ge v0, p1, :cond_0

    new-instance v1, Lo/vL;

    invoke-direct {v1, p0, v0}, Lo/vL;-><init>(Landroidx/emoji2/text/JHa;I)V

    invoke-virtual {v1}, Lo/vL;->JHa()I

    move-result v2

    iget-object v3, p0, Landroidx/emoji2/text/JHa;->AZxh:[C

    mul-int/lit8 v4, v0, 0x2

    invoke-static {v2, v3, v4}, Ljava/lang/Character;->toChars(I[CI)I

    invoke-virtual {p0, v1}, Landroidx/emoji2/text/JHa;->lgHUyS(Lo/vL;)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_0
    return-void
.end method

.method public wA()[C
    .locals 0

    iget-object p0, p0, Landroidx/emoji2/text/JHa;->AZxh:[C

    return-object p0
.end method

.method public xJ()Landroid/graphics/Typeface;
    .locals 0

    iget-object p0, p0, Landroidx/emoji2/text/JHa;->ZfxDd:Landroid/graphics/Typeface;

    return-object p0
.end method
