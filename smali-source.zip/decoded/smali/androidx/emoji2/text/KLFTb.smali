.class public Landroidx/emoji2/text/KLFTb;
.super Landroidx/emoji2/text/wA$wA;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/emoji2/text/KLFTb$mjFkc;,
        Landroidx/emoji2/text/KLFTb$AZxh;
    }
.end annotation


# static fields
.field public static final Dt:Landroidx/emoji2/text/KLFTb$mjFkc;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, Landroidx/emoji2/text/KLFTb$mjFkc;

    invoke-direct {v0}, Landroidx/emoji2/text/KLFTb$mjFkc;-><init>()V

    sput-object v0, Landroidx/emoji2/text/KLFTb;->Dt:Landroidx/emoji2/text/KLFTb$mjFkc;

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Lo/avDfWJ;)V
    .locals 2

    new-instance v0, Landroidx/emoji2/text/KLFTb$AZxh;

    sget-object v1, Landroidx/emoji2/text/KLFTb;->Dt:Landroidx/emoji2/text/KLFTb$mjFkc;

    invoke-direct {v0, p1, p2, v1}, Landroidx/emoji2/text/KLFTb$AZxh;-><init>(Landroid/content/Context;Lo/avDfWJ;Landroidx/emoji2/text/KLFTb$mjFkc;)V

    invoke-direct {p0, v0}, Landroidx/emoji2/text/wA$wA;-><init>(Landroidx/emoji2/text/wA$xJ;)V

    return-void
.end method


# virtual methods
.method public wA(Ljava/util/concurrent/Executor;)Landroidx/emoji2/text/KLFTb;
    .locals 1

    invoke-virtual {p0}, Landroidx/emoji2/text/wA$wA;->mjFkc()Landroidx/emoji2/text/wA$xJ;

    move-result-object v0

    check-cast v0, Landroidx/emoji2/text/KLFTb$AZxh;

    invoke-virtual {v0, p1}, Landroidx/emoji2/text/KLFTb$AZxh;->JHa(Ljava/util/concurrent/Executor;)V

    return-object p0
.end method
