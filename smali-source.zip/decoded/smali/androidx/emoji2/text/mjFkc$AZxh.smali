.class public abstract Landroidx/emoji2/text/mjFkc$AZxh;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/emoji2/text/mjFkc;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "AZxh"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public abstract AZxh(Landroid/content/pm/PackageManager;Ljava/lang/String;)[Landroid/content/pm/Signature;
.end method

.method public abstract mjFkc(Landroid/content/pm/ResolveInfo;)Landroid/content/pm/ProviderInfo;
.end method

.method public abstract wA(Landroid/content/pm/PackageManager;Landroid/content/Intent;I)Ljava/util/List;
.end method
