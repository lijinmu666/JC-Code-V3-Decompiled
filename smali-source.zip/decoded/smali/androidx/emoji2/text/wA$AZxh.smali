.class public abstract Landroidx/emoji2/text/wA$AZxh;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/emoji2/text/wA;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "AZxh"
.end annotation


# instance fields
.field public final mjFkc:Landroidx/emoji2/text/wA;


# direct methods
.method public constructor <init>(Landroidx/emoji2/text/wA;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/emoji2/text/wA$AZxh;->mjFkc:Landroidx/emoji2/text/wA;

    return-void
.end method


# virtual methods
.method public abstract AZxh(Ljava/lang/CharSequence;IIIZ)Ljava/lang/CharSequence;
.end method

.method public abstract mjFkc()V
.end method

.method public abstract wA(Landroid/view/inputmethod/EditorInfo;)V
.end method
