.class public Landroidx/emoji2/text/EmojiCompatInitializer;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lo/L;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/emoji2/text/EmojiCompatInitializer$AZxh;,
        Landroidx/emoji2/text/EmojiCompatInitializer$mjFkc;,
        Landroidx/emoji2/text/EmojiCompatInitializer$wA;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lo/L;"
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public bridge synthetic AZxh(Landroid/content/Context;)Ljava/lang/Object;
    .locals 0

    invoke-virtual {p0, p1}, Landroidx/emoji2/text/EmojiCompatInitializer;->wA(Landroid/content/Context;)Ljava/lang/Boolean;

    move-result-object p0

    return-object p0
.end method

.method public KLFTb()V
    .locals 3

    invoke-static {}, Lo/IPpyV;->ZfxDd()Landroid/os/Handler;

    move-result-object p0

    new-instance v0, Landroidx/emoji2/text/EmojiCompatInitializer$wA;

    invoke-direct {v0}, Landroidx/emoji2/text/EmojiCompatInitializer$wA;-><init>()V

    const-wide/16 v1, 0x1f4

    invoke-virtual {p0, v0, v1, v2}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void
.end method

.method public ZfxDd(Landroid/content/Context;)V
    .locals 1

    invoke-static {p1}, Lo/SOS;->KLFTb(Landroid/content/Context;)Lo/SOS;

    move-result-object p1

    const-class v0, Landroidx/lifecycle/ProcessLifecycleInitializer;

    invoke-virtual {p1, v0}, Lo/SOS;->JHa(Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lo/W0;

    invoke-interface {p1}, Lo/W0;->JHa()Landroidx/lifecycle/wA;

    move-result-object p1

    new-instance v0, Landroidx/emoji2/text/EmojiCompatInitializer$1;

    invoke-direct {v0, p0, p1}, Landroidx/emoji2/text/EmojiCompatInitializer$1;-><init>(Landroidx/emoji2/text/EmojiCompatInitializer;Landroidx/lifecycle/wA;)V

    invoke-virtual {p1, v0}, Landroidx/lifecycle/wA;->mjFkc(Lo/V0;)V

    return-void
.end method

.method public mjFkc()Ljava/util/List;
    .locals 0

    const-class p0, Landroidx/lifecycle/ProcessLifecycleInitializer;

    invoke-static {p0}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    move-result-object p0

    return-object p0
.end method

.method public wA(Landroid/content/Context;)Ljava/lang/Boolean;
    .locals 1

    new-instance v0, Landroidx/emoji2/text/EmojiCompatInitializer$mjFkc;

    invoke-direct {v0, p1}, Landroidx/emoji2/text/EmojiCompatInitializer$mjFkc;-><init>(Landroid/content/Context;)V

    invoke-static {v0}, Landroidx/emoji2/text/wA;->xJ(Landroidx/emoji2/text/wA$wA;)Landroidx/emoji2/text/wA;

    invoke-virtual {p0, p1}, Landroidx/emoji2/text/EmojiCompatInitializer;->ZfxDd(Landroid/content/Context;)V

    sget-object p0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    return-object p0
.end method
