.class public Landroidx/emoji2/text/KLFTb$mjFkc;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/emoji2/text/KLFTb;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "mjFkc"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public AZxh(Landroid/content/Context;Lo/avDfWJ;)Lo/Tz$mjFkc;
    .locals 0

    const/4 p0, 0x0

    invoke-static {p1, p0, p2}, Lo/Tz;->AZxh(Landroid/content/Context;Landroid/os/CancellationSignal;Lo/avDfWJ;)Lo/Tz$mjFkc;

    move-result-object p0

    return-object p0
.end method

.method public mjFkc(Landroid/content/Context;Lo/Tz$AZxh;)Landroid/graphics/Typeface;
    .locals 0

    const/4 p0, 0x0

    filled-new-array {p2}, [Lo/Tz$AZxh;

    move-result-object p2

    invoke-static {p1, p0, p2}, Lo/Tz;->mjFkc(Landroid/content/Context;Landroid/os/CancellationSignal;[Lo/Tz$AZxh;)Landroid/graphics/Typeface;

    move-result-object p0

    return-object p0
.end method

.method public wA(Landroid/content/Context;Landroid/database/ContentObserver;)V
    .locals 0

    invoke-virtual {p1}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object p0

    invoke-virtual {p0, p2}, Landroid/content/ContentResolver;->unregisterContentObserver(Landroid/database/ContentObserver;)V

    return-void
.end method
