.class public interface abstract Landroidx/emoji2/text/wA$ZfxDd;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/emoji2/text/wA;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "ZfxDd"
.end annotation


# virtual methods
.method public abstract mjFkc(Ljava/lang/CharSequence;III)Z
.end method
