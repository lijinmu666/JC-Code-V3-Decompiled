.class public Landroidx/emoji2/text/EmojiCompatInitializer$AZxh$mjFkc;
.super Landroidx/emoji2/text/wA$lgHUyS;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Landroidx/emoji2/text/EmojiCompatInitializer$AZxh;->wA(Landroidx/emoji2/text/wA$lgHUyS;Ljava/util/concurrent/ThreadPoolExecutor;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic AZxh:Ljava/util/concurrent/ThreadPoolExecutor;

.field public final synthetic mjFkc:Landroidx/emoji2/text/wA$lgHUyS;

.field public final synthetic wA:Landroidx/emoji2/text/EmojiCompatInitializer$AZxh;


# direct methods
.method public constructor <init>(Landroidx/emoji2/text/EmojiCompatInitializer$AZxh;Landroidx/emoji2/text/wA$lgHUyS;Ljava/util/concurrent/ThreadPoolExecutor;)V
    .locals 0

    iput-object p1, p0, Landroidx/emoji2/text/EmojiCompatInitializer$AZxh$mjFkc;->wA:Landroidx/emoji2/text/EmojiCompatInitializer$AZxh;

    iput-object p2, p0, Landroidx/emoji2/text/EmojiCompatInitializer$AZxh$mjFkc;->mjFkc:Landroidx/emoji2/text/wA$lgHUyS;

    iput-object p3, p0, Landroidx/emoji2/text/EmojiCompatInitializer$AZxh$mjFkc;->AZxh:Ljava/util/concurrent/ThreadPoolExecutor;

    invoke-direct {p0}, Landroidx/emoji2/text/wA$lgHUyS;-><init>()V

    return-void
.end method


# virtual methods
.method public AZxh(Landroidx/emoji2/text/JHa;)V
    .locals 1

    :try_start_0
    iget-object v0, p0, Landroidx/emoji2/text/EmojiCompatInitializer$AZxh$mjFkc;->mjFkc:Landroidx/emoji2/text/wA$lgHUyS;

    invoke-virtual {v0, p1}, Landroidx/emoji2/text/wA$lgHUyS;->AZxh(Landroidx/emoji2/text/JHa;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    iget-object p0, p0, Landroidx/emoji2/text/EmojiCompatInitializer$AZxh$mjFkc;->AZxh:Ljava/util/concurrent/ThreadPoolExecutor;

    invoke-virtual {p0}, Ljava/util/concurrent/ThreadPoolExecutor;->shutdown()V

    return-void

    :catchall_0
    move-exception p1

    iget-object p0, p0, Landroidx/emoji2/text/EmojiCompatInitializer$AZxh$mjFkc;->AZxh:Ljava/util/concurrent/ThreadPoolExecutor;

    invoke-virtual {p0}, Ljava/util/concurrent/ThreadPoolExecutor;->shutdown()V

    throw p1
.end method

.method public mjFkc(Ljava/lang/Throwable;)V
    .locals 1

    :try_start_0
    iget-object v0, p0, Landroidx/emoji2/text/EmojiCompatInitializer$AZxh$mjFkc;->mjFkc:Landroidx/emoji2/text/wA$lgHUyS;

    invoke-virtual {v0, p1}, Landroidx/emoji2/text/wA$lgHUyS;->mjFkc(Ljava/lang/Throwable;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    iget-object p0, p0, Landroidx/emoji2/text/EmojiCompatInitializer$AZxh$mjFkc;->AZxh:Ljava/util/concurrent/ThreadPoolExecutor;

    invoke-virtual {p0}, Ljava/util/concurrent/ThreadPoolExecutor;->shutdown()V

    return-void

    :catchall_0
    move-exception p1

    iget-object p0, p0, Landroidx/emoji2/text/EmojiCompatInitializer$AZxh$mjFkc;->AZxh:Ljava/util/concurrent/ThreadPoolExecutor;

    invoke-virtual {p0}, Ljava/util/concurrent/ThreadPoolExecutor;->shutdown()V

    throw p1
.end method
