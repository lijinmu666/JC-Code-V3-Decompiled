.class public Landroidx/emoji2/text/JHa$mjFkc;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/emoji2/text/JHa;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "mjFkc"
.end annotation


# instance fields
.field public AZxh:Lo/vL;

.field public final mjFkc:Landroid/util/SparseArray;


# direct methods
.method public constructor <init>()V
    .locals 1

    const/4 v0, 0x1

    .line 1
    invoke-direct {p0, v0}, Landroidx/emoji2/text/JHa$mjFkc;-><init>(I)V

    return-void
.end method

.method public constructor <init>(I)V
    .locals 1

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    new-instance v0, Landroid/util/SparseArray;

    invoke-direct {v0, p1}, Landroid/util/SparseArray;-><init>(I)V

    iput-object v0, p0, Landroidx/emoji2/text/JHa$mjFkc;->mjFkc:Landroid/util/SparseArray;

    return-void
.end method


# virtual methods
.method public final AZxh()Lo/vL;
    .locals 0

    iget-object p0, p0, Landroidx/emoji2/text/JHa$mjFkc;->AZxh:Lo/vL;

    return-object p0
.end method

.method public mjFkc(I)Landroidx/emoji2/text/JHa$mjFkc;
    .locals 0

    iget-object p0, p0, Landroidx/emoji2/text/JHa$mjFkc;->mjFkc:Landroid/util/SparseArray;

    if-nez p0, :cond_0

    const/4 p0, 0x0

    goto :goto_0

    :cond_0
    invoke-virtual {p0, p1}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroidx/emoji2/text/JHa$mjFkc;

    :goto_0
    return-object p0
.end method

.method public wA(Lo/vL;II)V
    .locals 2

    invoke-virtual {p1, p2}, Lo/vL;->AZxh(I)I

    move-result v0

    invoke-virtual {p0, v0}, Landroidx/emoji2/text/JHa$mjFkc;->mjFkc(I)Landroidx/emoji2/text/JHa$mjFkc;

    move-result-object v0

    if-nez v0, :cond_0

    new-instance v0, Landroidx/emoji2/text/JHa$mjFkc;

    invoke-direct {v0}, Landroidx/emoji2/text/JHa$mjFkc;-><init>()V

    iget-object p0, p0, Landroidx/emoji2/text/JHa$mjFkc;->mjFkc:Landroid/util/SparseArray;

    invoke-virtual {p1, p2}, Lo/vL;->AZxh(I)I

    move-result v1

    invoke-virtual {p0, v1, v0}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    :cond_0
    if-le p3, p2, :cond_1

    add-int/lit8 p2, p2, 0x1

    invoke-virtual {v0, p1, p2, p3}, Landroidx/emoji2/text/JHa$mjFkc;->wA(Lo/vL;II)V

    goto :goto_0

    :cond_1
    iput-object p1, v0, Landroidx/emoji2/text/JHa$mjFkc;->AZxh:Lo/vL;

    :goto_0
    return-void
.end method
