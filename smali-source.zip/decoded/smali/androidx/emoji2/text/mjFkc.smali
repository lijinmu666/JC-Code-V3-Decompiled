.class public abstract Landroidx/emoji2/text/mjFkc;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/emoji2/text/mjFkc$ZfxDd;,
        Landroidx/emoji2/text/mjFkc$wA;,
        Landroidx/emoji2/text/mjFkc$AZxh;,
        Landroidx/emoji2/text/mjFkc$mjFkc;
    }
.end annotation


# direct methods
.method public static mjFkc(Landroid/content/Context;)Landroidx/emoji2/text/KLFTb;
    .locals 2

    new-instance v0, Landroidx/emoji2/text/mjFkc$mjFkc;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Landroidx/emoji2/text/mjFkc$mjFkc;-><init>(Landroidx/emoji2/text/mjFkc$AZxh;)V

    invoke-virtual {v0, p0}, Landroidx/emoji2/text/mjFkc$mjFkc;->wA(Landroid/content/Context;)Landroidx/emoji2/text/wA$wA;

    move-result-object p0

    check-cast p0, Landroidx/emoji2/text/KLFTb;

    return-object p0
.end method
