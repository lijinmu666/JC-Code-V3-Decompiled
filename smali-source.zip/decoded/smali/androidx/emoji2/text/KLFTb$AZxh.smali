.class public Landroidx/emoji2/text/KLFTb$AZxh;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/emoji2/text/wA$xJ;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/emoji2/text/KLFTb;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "AZxh"
.end annotation


# instance fields
.field public final AZxh:Lo/avDfWJ;

.field public Dt:Ljava/lang/Runnable;

.field public JHa:Ljava/util/concurrent/Executor;

.field public KLFTb:Landroid/os/Handler;

.field public final ZfxDd:Ljava/lang/Object;

.field public lgHUyS:Landroidx/emoji2/text/wA$lgHUyS;

.field public final mjFkc:Landroid/content/Context;

.field public qdMbNW:Landroid/database/ContentObserver;

.field public final wA:Landroidx/emoji2/text/KLFTb$mjFkc;

.field public xJ:Ljava/util/concurrent/ThreadPoolExecutor;


# direct methods
.method public constructor <init>(Landroid/content/Context;Lo/avDfWJ;Landroidx/emoji2/text/KLFTb$mjFkc;)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    iput-object v0, p0, Landroidx/emoji2/text/KLFTb$AZxh;->ZfxDd:Ljava/lang/Object;

    const-string v0, "Context cannot be null"

    invoke-static {p1, v0}, Lo/K3;->lgHUyS(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v0, "FontRequest cannot be null"

    invoke-static {p2, v0}, Lo/K3;->lgHUyS(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    iput-object p1, p0, Landroidx/emoji2/text/KLFTb$AZxh;->mjFkc:Landroid/content/Context;

    iput-object p2, p0, Landroidx/emoji2/text/KLFTb$AZxh;->AZxh:Lo/avDfWJ;

    iput-object p3, p0, Landroidx/emoji2/text/KLFTb$AZxh;->wA:Landroidx/emoji2/text/KLFTb$mjFkc;

    return-void
.end method


# virtual methods
.method public final AZxh()V
    .locals 5

    iget-object v0, p0, Landroidx/emoji2/text/KLFTb$AZxh;->ZfxDd:Ljava/lang/Object;

    monitor-enter v0

    const/4 v1, 0x0

    :try_start_0
    iput-object v1, p0, Landroidx/emoji2/text/KLFTb$AZxh;->lgHUyS:Landroidx/emoji2/text/wA$lgHUyS;

    iget-object v2, p0, Landroidx/emoji2/text/KLFTb$AZxh;->qdMbNW:Landroid/database/ContentObserver;

    if-eqz v2, :cond_0

    iget-object v3, p0, Landroidx/emoji2/text/KLFTb$AZxh;->wA:Landroidx/emoji2/text/KLFTb$mjFkc;

    iget-object v4, p0, Landroidx/emoji2/text/KLFTb$AZxh;->mjFkc:Landroid/content/Context;

    invoke-virtual {v3, v4, v2}, Landroidx/emoji2/text/KLFTb$mjFkc;->wA(Landroid/content/Context;Landroid/database/ContentObserver;)V

    iput-object v1, p0, Landroidx/emoji2/text/KLFTb$AZxh;->qdMbNW:Landroid/database/ContentObserver;

    goto :goto_0

    :catchall_0
    move-exception p0

    goto :goto_1

    :cond_0
    :goto_0
    iget-object v2, p0, Landroidx/emoji2/text/KLFTb$AZxh;->KLFTb:Landroid/os/Handler;

    if-eqz v2, :cond_1

    iget-object v3, p0, Landroidx/emoji2/text/KLFTb$AZxh;->Dt:Ljava/lang/Runnable;

    invoke-virtual {v2, v3}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    :cond_1
    iput-object v1, p0, Landroidx/emoji2/text/KLFTb$AZxh;->KLFTb:Landroid/os/Handler;

    iget-object v2, p0, Landroidx/emoji2/text/KLFTb$AZxh;->xJ:Ljava/util/concurrent/ThreadPoolExecutor;

    if-eqz v2, :cond_2

    invoke-virtual {v2}, Ljava/util/concurrent/ThreadPoolExecutor;->shutdown()V

    :cond_2
    iput-object v1, p0, Landroidx/emoji2/text/KLFTb$AZxh;->JHa:Ljava/util/concurrent/Executor;

    iput-object v1, p0, Landroidx/emoji2/text/KLFTb$AZxh;->xJ:Ljava/util/concurrent/ThreadPoolExecutor;

    monitor-exit v0

    return-void

    :goto_1
    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw p0
.end method

.method public JHa(Ljava/util/concurrent/Executor;)V
    .locals 1

    iget-object v0, p0, Landroidx/emoji2/text/KLFTb$AZxh;->ZfxDd:Ljava/lang/Object;

    monitor-enter v0

    :try_start_0
    iput-object p1, p0, Landroidx/emoji2/text/KLFTb$AZxh;->JHa:Ljava/util/concurrent/Executor;

    monitor-exit v0

    return-void

    :catchall_0
    move-exception p0

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw p0
.end method

.method public final KLFTb()Lo/Tz$AZxh;
    .locals 3

    :try_start_0
    iget-object v0, p0, Landroidx/emoji2/text/KLFTb$AZxh;->wA:Landroidx/emoji2/text/KLFTb$mjFkc;

    iget-object v1, p0, Landroidx/emoji2/text/KLFTb$AZxh;->mjFkc:Landroid/content/Context;

    iget-object p0, p0, Landroidx/emoji2/text/KLFTb$AZxh;->AZxh:Lo/avDfWJ;

    invoke-virtual {v0, v1, p0}, Landroidx/emoji2/text/KLFTb$mjFkc;->AZxh(Landroid/content/Context;Lo/avDfWJ;)Lo/Tz$mjFkc;

    move-result-object p0
    :try_end_0
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    invoke-virtual {p0}, Lo/Tz$mjFkc;->wA()I

    move-result v0

    if-nez v0, :cond_1

    invoke-virtual {p0}, Lo/Tz$mjFkc;->AZxh()[Lo/Tz$AZxh;

    move-result-object p0

    if-eqz p0, :cond_0

    array-length v0, p0

    if-eqz v0, :cond_0

    const/4 v0, 0x0

    aget-object p0, p0, v0

    return-object p0

    :cond_0
    new-instance p0, Ljava/lang/RuntimeException;

    const-string v0, "fetchFonts failed (empty result)"

    invoke-direct {p0, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_1
    new-instance v0, Ljava/lang/RuntimeException;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "fetchFonts failed ("

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Lo/Tz$mjFkc;->wA()I

    move-result p0

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p0, ")"

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw v0

    :catch_0
    move-exception p0

    new-instance v0, Ljava/lang/RuntimeException;

    const-string v1, "provider not found"

    invoke-direct {v0, v1, p0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw v0
.end method

.method public ZfxDd()V
    .locals 3

    iget-object v0, p0, Landroidx/emoji2/text/KLFTb$AZxh;->ZfxDd:Ljava/lang/Object;

    monitor-enter v0

    :try_start_0
    iget-object v1, p0, Landroidx/emoji2/text/KLFTb$AZxh;->lgHUyS:Landroidx/emoji2/text/wA$lgHUyS;

    if-nez v1, :cond_0

    monitor-exit v0

    return-void

    :catchall_0
    move-exception p0

    goto :goto_0

    :cond_0
    iget-object v1, p0, Landroidx/emoji2/text/KLFTb$AZxh;->JHa:Ljava/util/concurrent/Executor;

    if-nez v1, :cond_1

    const-string v1, "emojiCompat"

    invoke-static {v1}, Lo/IPpyV;->AZxh(Ljava/lang/String;)Ljava/util/concurrent/ThreadPoolExecutor;

    move-result-object v1

    iput-object v1, p0, Landroidx/emoji2/text/KLFTb$AZxh;->xJ:Ljava/util/concurrent/ThreadPoolExecutor;

    iput-object v1, p0, Landroidx/emoji2/text/KLFTb$AZxh;->JHa:Ljava/util/concurrent/Executor;

    :cond_1
    iget-object v1, p0, Landroidx/emoji2/text/KLFTb$AZxh;->JHa:Ljava/util/concurrent/Executor;

    new-instance v2, Lo/WjcLD;

    invoke-direct {v2, p0}, Lo/WjcLD;-><init>(Landroidx/emoji2/text/KLFTb$AZxh;)V

    invoke-interface {v1, v2}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    monitor-exit v0

    return-void

    :goto_0
    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw p0
.end method

.method public mjFkc(Landroidx/emoji2/text/wA$lgHUyS;)V
    .locals 1

    const-string v0, "LoaderCallback cannot be null"

    invoke-static {p1, v0}, Lo/K3;->lgHUyS(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    iget-object v0, p0, Landroidx/emoji2/text/KLFTb$AZxh;->ZfxDd:Ljava/lang/Object;

    monitor-enter v0

    :try_start_0
    iput-object p1, p0, Landroidx/emoji2/text/KLFTb$AZxh;->lgHUyS:Landroidx/emoji2/text/wA$lgHUyS;

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    invoke-virtual {p0}, Landroidx/emoji2/text/KLFTb$AZxh;->ZfxDd()V

    return-void

    :catchall_0
    move-exception p0

    :try_start_1
    monitor-exit v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw p0
.end method

.method public wA()V
    .locals 4

    iget-object v0, p0, Landroidx/emoji2/text/KLFTb$AZxh;->ZfxDd:Ljava/lang/Object;

    monitor-enter v0

    :try_start_0
    iget-object v1, p0, Landroidx/emoji2/text/KLFTb$AZxh;->lgHUyS:Landroidx/emoji2/text/wA$lgHUyS;

    if-nez v1, :cond_0

    monitor-exit v0

    return-void

    :catchall_0
    move-exception p0

    goto/16 :goto_8

    :cond_0
    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :try_start_1
    invoke-virtual {p0}, Landroidx/emoji2/text/KLFTb$AZxh;->KLFTb()Lo/Tz$AZxh;

    move-result-object v0

    invoke-virtual {v0}, Lo/Tz$AZxh;->AZxh()I

    move-result v1

    const/4 v2, 0x2

    if-ne v1, v2, :cond_1

    iget-object v2, p0, Landroidx/emoji2/text/KLFTb$AZxh;->ZfxDd:Ljava/lang/Object;

    monitor-enter v2
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_2

    :try_start_2
    monitor-exit v2

    goto :goto_0

    :catchall_1
    move-exception v0

    monitor-exit v2
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    :try_start_3
    throw v0
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_2

    :catchall_2
    move-exception v0

    goto :goto_4

    :cond_1
    :goto_0
    if-nez v1, :cond_4

    :try_start_4
    const-string v1, "EmojiCompat.FontRequestEmojiCompatConfig.buildTypeface"

    invoke-static {v1}, Lo/L8;->mjFkc(Ljava/lang/String;)V

    iget-object v1, p0, Landroidx/emoji2/text/KLFTb$AZxh;->wA:Landroidx/emoji2/text/KLFTb$mjFkc;

    iget-object v2, p0, Landroidx/emoji2/text/KLFTb$AZxh;->mjFkc:Landroid/content/Context;

    invoke-virtual {v1, v2, v0}, Landroidx/emoji2/text/KLFTb$mjFkc;->mjFkc(Landroid/content/Context;Lo/Tz$AZxh;)Landroid/graphics/Typeface;

    move-result-object v1

    iget-object v2, p0, Landroidx/emoji2/text/KLFTb$AZxh;->mjFkc:Landroid/content/Context;

    invoke-virtual {v0}, Lo/Tz$AZxh;->ZfxDd()Landroid/net/Uri;

    move-result-object v0

    const/4 v3, 0x0

    invoke-static {v2, v3, v0}, Lo/p9;->mjFkc(Landroid/content/Context;Landroid/os/CancellationSignal;Landroid/net/Uri;)Ljava/nio/ByteBuffer;

    move-result-object v0

    if-eqz v0, :cond_3

    if-eqz v1, :cond_3

    invoke-static {v1, v0}, Landroidx/emoji2/text/JHa;->AZxh(Landroid/graphics/Typeface;Ljava/nio/ByteBuffer;)Landroidx/emoji2/text/JHa;

    move-result-object v0
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_4

    :try_start_5
    invoke-static {}, Lo/L8;->AZxh()V

    iget-object v1, p0, Landroidx/emoji2/text/KLFTb$AZxh;->ZfxDd:Ljava/lang/Object;

    monitor-enter v1
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_2

    :try_start_6
    iget-object v2, p0, Landroidx/emoji2/text/KLFTb$AZxh;->lgHUyS:Landroidx/emoji2/text/wA$lgHUyS;

    if-eqz v2, :cond_2

    invoke-virtual {v2, v0}, Landroidx/emoji2/text/wA$lgHUyS;->AZxh(Landroidx/emoji2/text/JHa;)V

    goto :goto_1

    :catchall_3
    move-exception v0

    goto :goto_2

    :cond_2
    :goto_1
    monitor-exit v1
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_3

    :try_start_7
    invoke-virtual {p0}, Landroidx/emoji2/text/KLFTb$AZxh;->AZxh()V
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_2

    goto :goto_6

    :goto_2
    :try_start_8
    monitor-exit v1
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_3

    :try_start_9
    throw v0
    :try_end_9
    .catchall {:try_start_9 .. :try_end_9} :catchall_2

    :catchall_4
    move-exception v0

    goto :goto_3

    :cond_3
    :try_start_a
    new-instance v0, Ljava/lang/RuntimeException;

    const-string v1, "Unable to open file."

    invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw v0
    :try_end_a
    .catchall {:try_start_a .. :try_end_a} :catchall_4

    :goto_3
    :try_start_b
    invoke-static {}, Lo/L8;->AZxh()V

    throw v0

    :cond_4
    new-instance v0, Ljava/lang/RuntimeException;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "fetchFonts result is not OK. ("

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, ")"

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw v0
    :try_end_b
    .catchall {:try_start_b .. :try_end_b} :catchall_2

    :goto_4
    iget-object v1, p0, Landroidx/emoji2/text/KLFTb$AZxh;->ZfxDd:Ljava/lang/Object;

    monitor-enter v1

    :try_start_c
    iget-object v2, p0, Landroidx/emoji2/text/KLFTb$AZxh;->lgHUyS:Landroidx/emoji2/text/wA$lgHUyS;

    if-eqz v2, :cond_5

    invoke-virtual {v2, v0}, Landroidx/emoji2/text/wA$lgHUyS;->mjFkc(Ljava/lang/Throwable;)V

    goto :goto_5

    :catchall_5
    move-exception p0

    goto :goto_7

    :cond_5
    :goto_5
    monitor-exit v1
    :try_end_c
    .catchall {:try_start_c .. :try_end_c} :catchall_5

    invoke-virtual {p0}, Landroidx/emoji2/text/KLFTb$AZxh;->AZxh()V

    :goto_6
    return-void

    :goto_7
    :try_start_d
    monitor-exit v1
    :try_end_d
    .catchall {:try_start_d .. :try_end_d} :catchall_5

    throw p0

    :goto_8
    :try_start_e
    monitor-exit v0
    :try_end_e
    .catchall {:try_start_e .. :try_end_e} :catchall_0

    throw p0
.end method
