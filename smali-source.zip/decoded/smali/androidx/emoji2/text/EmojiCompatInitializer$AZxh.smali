.class public Landroidx/emoji2/text/EmojiCompatInitializer$AZxh;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/emoji2/text/wA$xJ;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/emoji2/text/EmojiCompatInitializer;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "AZxh"
.end annotation


# instance fields
.field public final mjFkc:Landroid/content/Context;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    iput-object p1, p0, Landroidx/emoji2/text/EmojiCompatInitializer$AZxh;->mjFkc:Landroid/content/Context;

    return-void
.end method

.method public static synthetic AZxh(Landroidx/emoji2/text/EmojiCompatInitializer$AZxh;Landroidx/emoji2/text/wA$lgHUyS;Ljava/util/concurrent/ThreadPoolExecutor;)V
    .locals 0

    invoke-virtual {p0, p1, p2}, Landroidx/emoji2/text/EmojiCompatInitializer$AZxh;->ZfxDd(Landroidx/emoji2/text/wA$lgHUyS;Ljava/util/concurrent/ThreadPoolExecutor;)V

    return-void
.end method


# virtual methods
.method public final synthetic ZfxDd(Landroidx/emoji2/text/wA$lgHUyS;Ljava/util/concurrent/ThreadPoolExecutor;)V
    .locals 0

    invoke-virtual {p0, p1, p2}, Landroidx/emoji2/text/EmojiCompatInitializer$AZxh;->wA(Landroidx/emoji2/text/wA$lgHUyS;Ljava/util/concurrent/ThreadPoolExecutor;)V

    return-void
.end method

.method public mjFkc(Landroidx/emoji2/text/wA$lgHUyS;)V
    .locals 2

    const-string v0, "EmojiCompatInitializer"

    invoke-static {v0}, Lo/IPpyV;->AZxh(Ljava/lang/String;)Ljava/util/concurrent/ThreadPoolExecutor;

    move-result-object v0

    new-instance v1, Lo/gb;

    invoke-direct {v1, p0, p1, v0}, Lo/gb;-><init>(Landroidx/emoji2/text/EmojiCompatInitializer$AZxh;Landroidx/emoji2/text/wA$lgHUyS;Ljava/util/concurrent/ThreadPoolExecutor;)V

    invoke-virtual {v0, v1}, Ljava/util/concurrent/ThreadPoolExecutor;->execute(Ljava/lang/Runnable;)V

    return-void
.end method

.method public wA(Landroidx/emoji2/text/wA$lgHUyS;Ljava/util/concurrent/ThreadPoolExecutor;)V
    .locals 2

    :try_start_0
    iget-object v0, p0, Landroidx/emoji2/text/EmojiCompatInitializer$AZxh;->mjFkc:Landroid/content/Context;

    invoke-static {v0}, Landroidx/emoji2/text/mjFkc;->mjFkc(Landroid/content/Context;)Landroidx/emoji2/text/KLFTb;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-virtual {v0, p2}, Landroidx/emoji2/text/KLFTb;->wA(Ljava/util/concurrent/Executor;)Landroidx/emoji2/text/KLFTb;

    invoke-virtual {v0}, Landroidx/emoji2/text/wA$wA;->mjFkc()Landroidx/emoji2/text/wA$xJ;

    move-result-object v0

    new-instance v1, Landroidx/emoji2/text/EmojiCompatInitializer$AZxh$mjFkc;

    invoke-direct {v1, p0, p1, p2}, Landroidx/emoji2/text/EmojiCompatInitializer$AZxh$mjFkc;-><init>(Landroidx/emoji2/text/EmojiCompatInitializer$AZxh;Landroidx/emoji2/text/wA$lgHUyS;Ljava/util/concurrent/ThreadPoolExecutor;)V

    invoke-interface {v0, v1}, Landroidx/emoji2/text/wA$xJ;->mjFkc(Landroidx/emoji2/text/wA$lgHUyS;)V

    goto :goto_1

    :catchall_0
    move-exception p0

    goto :goto_0

    :cond_0
    new-instance p0, Ljava/lang/RuntimeException;

    const-string v0, "EmojiCompat font provider not available on this device."

    invoke-direct {p0, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :goto_0
    invoke-virtual {p1, p0}, Landroidx/emoji2/text/wA$lgHUyS;->mjFkc(Ljava/lang/Throwable;)V

    invoke-virtual {p2}, Ljava/util/concurrent/ThreadPoolExecutor;->shutdown()V

    :goto_1
    return-void
.end method
