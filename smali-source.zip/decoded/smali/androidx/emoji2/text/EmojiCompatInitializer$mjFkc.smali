.class public Landroidx/emoji2/text/EmojiCompatInitializer$mjFkc;
.super Landroidx/emoji2/text/wA$wA;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/emoji2/text/EmojiCompatInitializer;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "mjFkc"
.end annotation


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 1

    new-instance v0, Landroidx/emoji2/text/EmojiCompatInitializer$AZxh;

    invoke-direct {v0, p1}, Landroidx/emoji2/text/EmojiCompatInitializer$AZxh;-><init>(Landroid/content/Context;)V

    invoke-direct {p0, v0}, Landroidx/emoji2/text/wA$wA;-><init>(Landroidx/emoji2/text/wA$xJ;)V

    const/4 p1, 0x1

    invoke-virtual {p0, p1}, Landroidx/emoji2/text/wA$wA;->AZxh(I)Landroidx/emoji2/text/wA$wA;

    return-void
.end method
