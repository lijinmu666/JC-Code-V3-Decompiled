.class public final Landroidx/emoji2/text/ZfxDd$AZxh;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/emoji2/text/ZfxDd;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "AZxh"
.end annotation


# instance fields
.field public final AZxh:Landroidx/emoji2/text/JHa$mjFkc;

.field public JHa:I

.field public KLFTb:I

.field public ZfxDd:Landroidx/emoji2/text/JHa$mjFkc;

.field public final lgHUyS:[I

.field public mjFkc:I

.field public wA:Landroidx/emoji2/text/JHa$mjFkc;

.field public final xJ:Z


# direct methods
.method public constructor <init>(Landroidx/emoji2/text/JHa$mjFkc;Z[I)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x1

    iput v0, p0, Landroidx/emoji2/text/ZfxDd$AZxh;->mjFkc:I

    iput-object p1, p0, Landroidx/emoji2/text/ZfxDd$AZxh;->AZxh:Landroidx/emoji2/text/JHa$mjFkc;

    iput-object p1, p0, Landroidx/emoji2/text/ZfxDd$AZxh;->wA:Landroidx/emoji2/text/JHa$mjFkc;

    iput-boolean p2, p0, Landroidx/emoji2/text/ZfxDd$AZxh;->xJ:Z

    iput-object p3, p0, Landroidx/emoji2/text/ZfxDd$AZxh;->lgHUyS:[I

    return-void
.end method

.method public static JHa(I)Z
    .locals 1

    const v0, 0xfe0e

    if-ne p0, v0, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method

.method public static ZfxDd(I)Z
    .locals 1

    const v0, 0xfe0f

    if-ne p0, v0, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method


# virtual methods
.method public AZxh()Lo/vL;
    .locals 0

    iget-object p0, p0, Landroidx/emoji2/text/ZfxDd$AZxh;->wA:Landroidx/emoji2/text/JHa$mjFkc;

    invoke-virtual {p0}, Landroidx/emoji2/text/JHa$mjFkc;->AZxh()Lo/vL;

    move-result-object p0

    return-object p0
.end method

.method public KLFTb()Z
    .locals 2

    iget v0, p0, Landroidx/emoji2/text/ZfxDd$AZxh;->mjFkc:I

    const/4 v1, 0x2

    if-ne v0, v1, :cond_0

    iget-object v0, p0, Landroidx/emoji2/text/ZfxDd$AZxh;->wA:Landroidx/emoji2/text/JHa$mjFkc;

    invoke-virtual {v0}, Landroidx/emoji2/text/JHa$mjFkc;->AZxh()Lo/vL;

    move-result-object v0

    if-eqz v0, :cond_0

    iget v0, p0, Landroidx/emoji2/text/ZfxDd$AZxh;->JHa:I

    const/4 v1, 0x1

    if-gt v0, v1, :cond_1

    invoke-virtual {p0}, Landroidx/emoji2/text/ZfxDd$AZxh;->lgHUyS()Z

    move-result p0

    if-eqz p0, :cond_0

    goto :goto_0

    :cond_0
    const/4 v1, 0x0

    :cond_1
    :goto_0
    return v1
.end method

.method public final lgHUyS()Z
    .locals 3

    iget-object v0, p0, Landroidx/emoji2/text/ZfxDd$AZxh;->wA:Landroidx/emoji2/text/JHa$mjFkc;

    invoke-virtual {v0}, Landroidx/emoji2/text/JHa$mjFkc;->AZxh()Lo/vL;

    move-result-object v0

    invoke-virtual {v0}, Lo/vL;->Dt()Z

    move-result v0

    const/4 v1, 0x1

    if-eqz v0, :cond_0

    return v1

    :cond_0
    iget v0, p0, Landroidx/emoji2/text/ZfxDd$AZxh;->KLFTb:I

    invoke-static {v0}, Landroidx/emoji2/text/ZfxDd$AZxh;->ZfxDd(I)Z

    move-result v0

    if-eqz v0, :cond_1

    return v1

    :cond_1
    iget-boolean v0, p0, Landroidx/emoji2/text/ZfxDd$AZxh;->xJ:Z

    const/4 v2, 0x0

    if-eqz v0, :cond_3

    iget-object v0, p0, Landroidx/emoji2/text/ZfxDd$AZxh;->lgHUyS:[I

    if-nez v0, :cond_2

    return v1

    :cond_2
    iget-object v0, p0, Landroidx/emoji2/text/ZfxDd$AZxh;->wA:Landroidx/emoji2/text/JHa$mjFkc;

    invoke-virtual {v0}, Landroidx/emoji2/text/JHa$mjFkc;->AZxh()Lo/vL;

    move-result-object v0

    invoke-virtual {v0, v2}, Lo/vL;->AZxh(I)I

    move-result v0

    iget-object p0, p0, Landroidx/emoji2/text/ZfxDd$AZxh;->lgHUyS:[I

    invoke-static {p0, v0}, Ljava/util/Arrays;->binarySearch([II)I

    move-result p0

    if-gez p0, :cond_3

    return v1

    :cond_3
    return v2
.end method

.method public mjFkc(I)I
    .locals 4

    iget-object v0, p0, Landroidx/emoji2/text/ZfxDd$AZxh;->wA:Landroidx/emoji2/text/JHa$mjFkc;

    invoke-virtual {v0, p1}, Landroidx/emoji2/text/JHa$mjFkc;->mjFkc(I)Landroidx/emoji2/text/JHa$mjFkc;

    move-result-object v0

    iget v1, p0, Landroidx/emoji2/text/ZfxDd$AZxh;->mjFkc:I

    const/4 v2, 0x1

    const/4 v3, 0x2

    if-eq v1, v3, :cond_1

    if-nez v0, :cond_0

    invoke-virtual {p0}, Landroidx/emoji2/text/ZfxDd$AZxh;->xJ()I

    move-result v3

    goto :goto_0

    :cond_0
    iput v3, p0, Landroidx/emoji2/text/ZfxDd$AZxh;->mjFkc:I

    iput-object v0, p0, Landroidx/emoji2/text/ZfxDd$AZxh;->wA:Landroidx/emoji2/text/JHa$mjFkc;

    iput v2, p0, Landroidx/emoji2/text/ZfxDd$AZxh;->JHa:I

    goto :goto_0

    :cond_1
    if-eqz v0, :cond_2

    iput-object v0, p0, Landroidx/emoji2/text/ZfxDd$AZxh;->wA:Landroidx/emoji2/text/JHa$mjFkc;

    iget v0, p0, Landroidx/emoji2/text/ZfxDd$AZxh;->JHa:I

    add-int/2addr v0, v2

    iput v0, p0, Landroidx/emoji2/text/ZfxDd$AZxh;->JHa:I

    goto :goto_0

    :cond_2
    invoke-static {p1}, Landroidx/emoji2/text/ZfxDd$AZxh;->JHa(I)Z

    move-result v0

    if-eqz v0, :cond_3

    invoke-virtual {p0}, Landroidx/emoji2/text/ZfxDd$AZxh;->xJ()I

    move-result v3

    goto :goto_0

    :cond_3
    invoke-static {p1}, Landroidx/emoji2/text/ZfxDd$AZxh;->ZfxDd(I)Z

    move-result v0

    if-eqz v0, :cond_4

    goto :goto_0

    :cond_4
    iget-object v0, p0, Landroidx/emoji2/text/ZfxDd$AZxh;->wA:Landroidx/emoji2/text/JHa$mjFkc;

    invoke-virtual {v0}, Landroidx/emoji2/text/JHa$mjFkc;->AZxh()Lo/vL;

    move-result-object v0

    if-eqz v0, :cond_7

    iget v0, p0, Landroidx/emoji2/text/ZfxDd$AZxh;->JHa:I

    const/4 v3, 0x3

    if-ne v0, v2, :cond_6

    invoke-virtual {p0}, Landroidx/emoji2/text/ZfxDd$AZxh;->lgHUyS()Z

    move-result v0

    if-eqz v0, :cond_5

    iget-object v0, p0, Landroidx/emoji2/text/ZfxDd$AZxh;->wA:Landroidx/emoji2/text/JHa$mjFkc;

    iput-object v0, p0, Landroidx/emoji2/text/ZfxDd$AZxh;->ZfxDd:Landroidx/emoji2/text/JHa$mjFkc;

    invoke-virtual {p0}, Landroidx/emoji2/text/ZfxDd$AZxh;->xJ()I

    goto :goto_0

    :cond_5
    invoke-virtual {p0}, Landroidx/emoji2/text/ZfxDd$AZxh;->xJ()I

    move-result v3

    goto :goto_0

    :cond_6
    iget-object v0, p0, Landroidx/emoji2/text/ZfxDd$AZxh;->wA:Landroidx/emoji2/text/JHa$mjFkc;

    iput-object v0, p0, Landroidx/emoji2/text/ZfxDd$AZxh;->ZfxDd:Landroidx/emoji2/text/JHa$mjFkc;

    invoke-virtual {p0}, Landroidx/emoji2/text/ZfxDd$AZxh;->xJ()I

    goto :goto_0

    :cond_7
    invoke-virtual {p0}, Landroidx/emoji2/text/ZfxDd$AZxh;->xJ()I

    move-result v3

    :goto_0
    iput p1, p0, Landroidx/emoji2/text/ZfxDd$AZxh;->KLFTb:I

    return v3
.end method

.method public wA()Lo/vL;
    .locals 0

    iget-object p0, p0, Landroidx/emoji2/text/ZfxDd$AZxh;->ZfxDd:Landroidx/emoji2/text/JHa$mjFkc;

    invoke-virtual {p0}, Landroidx/emoji2/text/JHa$mjFkc;->AZxh()Lo/vL;

    move-result-object p0

    return-object p0
.end method

.method public final xJ()I
    .locals 2

    const/4 v0, 0x1

    iput v0, p0, Landroidx/emoji2/text/ZfxDd$AZxh;->mjFkc:I

    iget-object v1, p0, Landroidx/emoji2/text/ZfxDd$AZxh;->AZxh:Landroidx/emoji2/text/JHa$mjFkc;

    iput-object v1, p0, Landroidx/emoji2/text/ZfxDd$AZxh;->wA:Landroidx/emoji2/text/JHa$mjFkc;

    const/4 v1, 0x0

    iput v1, p0, Landroidx/emoji2/text/ZfxDd$AZxh;->JHa:I

    return v0
.end method
