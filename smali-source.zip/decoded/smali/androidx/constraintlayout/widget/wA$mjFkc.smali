.class public Landroidx/constraintlayout/widget/wA$mjFkc;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/constraintlayout/widget/wA;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "mjFkc"
.end annotation


# instance fields
.field public final AZxh:Landroidx/constraintlayout/widget/wA$ZfxDd;

.field public JHa:Ljava/util/HashMap;

.field public final KLFTb:Landroidx/constraintlayout/widget/wA$KLFTb;

.field public final ZfxDd:Landroidx/constraintlayout/widget/wA$AZxh;

.field public mjFkc:I

.field public final wA:Landroidx/constraintlayout/widget/wA$wA;


# direct methods
.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Landroidx/constraintlayout/widget/wA$ZfxDd;

    invoke-direct {v0}, Landroidx/constraintlayout/widget/wA$ZfxDd;-><init>()V

    iput-object v0, p0, Landroidx/constraintlayout/widget/wA$mjFkc;->AZxh:Landroidx/constraintlayout/widget/wA$ZfxDd;

    new-instance v0, Landroidx/constraintlayout/widget/wA$wA;

    invoke-direct {v0}, Landroidx/constraintlayout/widget/wA$wA;-><init>()V

    iput-object v0, p0, Landroidx/constraintlayout/widget/wA$mjFkc;->wA:Landroidx/constraintlayout/widget/wA$wA;

    new-instance v0, Landroidx/constraintlayout/widget/wA$AZxh;

    invoke-direct {v0}, Landroidx/constraintlayout/widget/wA$AZxh;-><init>()V

    iput-object v0, p0, Landroidx/constraintlayout/widget/wA$mjFkc;->ZfxDd:Landroidx/constraintlayout/widget/wA$AZxh;

    new-instance v0, Landroidx/constraintlayout/widget/wA$KLFTb;

    invoke-direct {v0}, Landroidx/constraintlayout/widget/wA$KLFTb;-><init>()V

    iput-object v0, p0, Landroidx/constraintlayout/widget/wA$mjFkc;->KLFTb:Landroidx/constraintlayout/widget/wA$KLFTb;

    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    iput-object v0, p0, Landroidx/constraintlayout/widget/wA$mjFkc;->JHa:Ljava/util/HashMap;

    return-void
.end method

.method public static synthetic mjFkc(Landroidx/constraintlayout/widget/wA$mjFkc;ILandroidx/constraintlayout/widget/ConstraintLayout$AZxh;)V
    .locals 0

    invoke-virtual {p0, p1, p2}, Landroidx/constraintlayout/widget/wA$mjFkc;->ZfxDd(ILandroidx/constraintlayout/widget/ConstraintLayout$AZxh;)V

    return-void
.end method


# virtual methods
.method public AZxh(Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;)V
    .locals 2

    iget-object v0, p0, Landroidx/constraintlayout/widget/wA$mjFkc;->ZfxDd:Landroidx/constraintlayout/widget/wA$AZxh;

    iget v1, v0, Landroidx/constraintlayout/widget/wA$AZxh;->lgHUyS:I

    iput v1, p1, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->ZfxDd:I

    iget v1, v0, Landroidx/constraintlayout/widget/wA$AZxh;->qdMbNW:I

    iput v1, p1, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->KLFTb:I

    iget v1, v0, Landroidx/constraintlayout/widget/wA$AZxh;->Dt:I

    iput v1, p1, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->JHa:I

    iget v1, v0, Landroidx/constraintlayout/widget/wA$AZxh;->ETF:I

    iput v1, p1, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->xJ:I

    iget v1, v0, Landroidx/constraintlayout/widget/wA$AZxh;->VA:I

    iput v1, p1, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->lgHUyS:I

    iget v1, v0, Landroidx/constraintlayout/widget/wA$AZxh;->MiMN:I

    iput v1, p1, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->qdMbNW:I

    iget v1, v0, Landroidx/constraintlayout/widget/wA$AZxh;->YoKzxo:I

    iput v1, p1, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->Dt:I

    iget v1, v0, Landroidx/constraintlayout/widget/wA$AZxh;->rkYL:I

    iput v1, p1, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->ETF:I

    iget v1, v0, Landroidx/constraintlayout/widget/wA$AZxh;->qGY:I

    iput v1, p1, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->VA:I

    iget v1, v0, Landroidx/constraintlayout/widget/wA$AZxh;->fehf:I

    iput v1, p1, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->qGY:I

    iget v1, v0, Landroidx/constraintlayout/widget/wA$AZxh;->IEE:I

    iput v1, p1, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->fehf:I

    iget v1, v0, Landroidx/constraintlayout/widget/wA$AZxh;->Pq:I

    iput v1, p1, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->IEE:I

    iget v1, v0, Landroidx/constraintlayout/widget/wA$AZxh;->diqgf:I

    iput v1, p1, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->Pq:I

    iget v1, v0, Landroidx/constraintlayout/widget/wA$AZxh;->wJVbdd:I

    iput v1, p1, Landroid/view/ViewGroup$MarginLayoutParams;->leftMargin:I

    iget v1, v0, Landroidx/constraintlayout/widget/wA$AZxh;->mByQ:I

    iput v1, p1, Landroid/view/ViewGroup$MarginLayoutParams;->rightMargin:I

    iget v1, v0, Landroidx/constraintlayout/widget/wA$AZxh;->OjSQV:I

    iput v1, p1, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    iget v1, v0, Landroidx/constraintlayout/widget/wA$AZxh;->Ne:I

    iput v1, p1, Landroid/view/ViewGroup$MarginLayoutParams;->bottomMargin:I

    iget v1, v0, Landroidx/constraintlayout/widget/wA$AZxh;->NPj:I

    iput v1, p1, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->Gd:I

    iget v1, v0, Landroidx/constraintlayout/widget/wA$AZxh;->Vnb:I

    iput v1, p1, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->HGpJ:I

    iget v1, v0, Landroidx/constraintlayout/widget/wA$AZxh;->zvd:I

    iput v1, p1, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->eyqo:I

    iget v1, v0, Landroidx/constraintlayout/widget/wA$AZxh;->rWxwaT:I

    iput v1, p1, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->huTpC:I

    iget v1, v0, Landroidx/constraintlayout/widget/wA$AZxh;->eyqo:F

    iput v1, p1, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->vI:F

    iget v1, v0, Landroidx/constraintlayout/widget/wA$AZxh;->Ucbh:F

    iput v1, p1, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->VocHEe:F

    iget v1, v0, Landroidx/constraintlayout/widget/wA$AZxh;->Gd:I

    iput v1, p1, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->MiMN:I

    iget v1, v0, Landroidx/constraintlayout/widget/wA$AZxh;->HGpJ:I

    iput v1, p1, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->YoKzxo:I

    iget v1, v0, Landroidx/constraintlayout/widget/wA$AZxh;->vI:F

    iput v1, p1, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->rkYL:F

    iget-object v1, v0, Landroidx/constraintlayout/widget/wA$AZxh;->huTpC:Ljava/lang/String;

    iput-object v1, p1, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->BAnRFn:Ljava/lang/String;

    iget v1, v0, Landroidx/constraintlayout/widget/wA$AZxh;->VocHEe:I

    iput v1, p1, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->oCFDzJ:I

    iget v1, v0, Landroidx/constraintlayout/widget/wA$AZxh;->BAnRFn:I

    iput v1, p1, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->aqHPIZ:I

    iget v1, v0, Landroidx/constraintlayout/widget/wA$AZxh;->vadzgd:F

    iput v1, p1, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->OjSQV:F

    iget v1, v0, Landroidx/constraintlayout/widget/wA$AZxh;->oCFDzJ:F

    iput v1, p1, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->mByQ:F

    iget v1, v0, Landroidx/constraintlayout/widget/wA$AZxh;->WrLQs:I

    iput v1, p1, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->CqaNbM:I

    iget v1, v0, Landroidx/constraintlayout/widget/wA$AZxh;->aqHPIZ:I

    iput v1, p1, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->Ne:I

    iget-boolean v1, v0, Landroidx/constraintlayout/widget/wA$AZxh;->ANMGZc:Z

    iput-boolean v1, p1, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->KRTLGT:Z

    iget-boolean v1, v0, Landroidx/constraintlayout/widget/wA$AZxh;->alEkx:Z

    iput-boolean v1, p1, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->GMIER:Z

    iget v1, v0, Landroidx/constraintlayout/widget/wA$AZxh;->KRTLGT:I

    iput v1, p1, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->xrEuO:I

    iget v1, v0, Landroidx/constraintlayout/widget/wA$AZxh;->GMIER:I

    iput v1, p1, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->KLMXS:I

    iget v1, v0, Landroidx/constraintlayout/widget/wA$AZxh;->uHVRx:I

    iput v1, p1, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->rWxwaT:I

    iget v1, v0, Landroidx/constraintlayout/widget/wA$AZxh;->JYn:I

    iput v1, p1, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->Vnb:I

    iget v1, v0, Landroidx/constraintlayout/widget/wA$AZxh;->JYgkl:I

    iput v1, p1, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->zvd:I

    iget v1, v0, Landroidx/constraintlayout/widget/wA$AZxh;->JrJO:I

    iput v1, p1, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->cMLeY:I

    iget v1, v0, Landroidx/constraintlayout/widget/wA$AZxh;->nxI:F

    iput v1, p1, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->NPj:F

    iget v1, v0, Landroidx/constraintlayout/widget/wA$AZxh;->WGXroI:F

    iput v1, p1, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->vadzgd:F

    iget v1, v0, Landroidx/constraintlayout/widget/wA$AZxh;->lB:I

    iput v1, p1, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->WrLQs:I

    iget v1, v0, Landroidx/constraintlayout/widget/wA$AZxh;->xJ:F

    iput v1, p1, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->wA:F

    iget v1, v0, Landroidx/constraintlayout/widget/wA$AZxh;->KLFTb:I

    iput v1, p1, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->mjFkc:I

    iget v1, v0, Landroidx/constraintlayout/widget/wA$AZxh;->JHa:I

    iput v1, p1, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->AZxh:I

    iget v1, v0, Landroidx/constraintlayout/widget/wA$AZxh;->wA:I

    iput v1, p1, Landroid/view/ViewGroup$MarginLayoutParams;->width:I

    iget v1, v0, Landroidx/constraintlayout/widget/wA$AZxh;->ZfxDd:I

    iput v1, p1, Landroid/view/ViewGroup$MarginLayoutParams;->height:I

    iget-object v1, v0, Landroidx/constraintlayout/widget/wA$AZxh;->jm:Ljava/lang/String;

    if-eqz v1, :cond_0

    iput-object v1, p1, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->uHVRx:Ljava/lang/String;

    :cond_0
    iget v0, v0, Landroidx/constraintlayout/widget/wA$AZxh;->xrEuO:I

    invoke-virtual {p1, v0}, Landroid/view/ViewGroup$MarginLayoutParams;->setMarginStart(I)V

    iget-object p0, p0, Landroidx/constraintlayout/widget/wA$mjFkc;->ZfxDd:Landroidx/constraintlayout/widget/wA$AZxh;

    iget p0, p0, Landroidx/constraintlayout/widget/wA$AZxh;->CqaNbM:I

    invoke-virtual {p1, p0}, Landroid/view/ViewGroup$MarginLayoutParams;->setMarginEnd(I)V

    invoke-virtual {p1}, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->mjFkc()V

    return-void
.end method

.method public final ZfxDd(ILandroidx/constraintlayout/widget/ConstraintLayout$AZxh;)V
    .locals 1

    iput p1, p0, Landroidx/constraintlayout/widget/wA$mjFkc;->mjFkc:I

    iget-object p1, p0, Landroidx/constraintlayout/widget/wA$mjFkc;->ZfxDd:Landroidx/constraintlayout/widget/wA$AZxh;

    iget v0, p2, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->ZfxDd:I

    iput v0, p1, Landroidx/constraintlayout/widget/wA$AZxh;->lgHUyS:I

    iget v0, p2, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->KLFTb:I

    iput v0, p1, Landroidx/constraintlayout/widget/wA$AZxh;->qdMbNW:I

    iget v0, p2, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->JHa:I

    iput v0, p1, Landroidx/constraintlayout/widget/wA$AZxh;->Dt:I

    iget v0, p2, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->xJ:I

    iput v0, p1, Landroidx/constraintlayout/widget/wA$AZxh;->ETF:I

    iget v0, p2, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->lgHUyS:I

    iput v0, p1, Landroidx/constraintlayout/widget/wA$AZxh;->VA:I

    iget v0, p2, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->qdMbNW:I

    iput v0, p1, Landroidx/constraintlayout/widget/wA$AZxh;->MiMN:I

    iget v0, p2, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->Dt:I

    iput v0, p1, Landroidx/constraintlayout/widget/wA$AZxh;->YoKzxo:I

    iget v0, p2, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->ETF:I

    iput v0, p1, Landroidx/constraintlayout/widget/wA$AZxh;->rkYL:I

    iget v0, p2, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->VA:I

    iput v0, p1, Landroidx/constraintlayout/widget/wA$AZxh;->qGY:I

    iget v0, p2, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->qGY:I

    iput v0, p1, Landroidx/constraintlayout/widget/wA$AZxh;->fehf:I

    iget v0, p2, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->fehf:I

    iput v0, p1, Landroidx/constraintlayout/widget/wA$AZxh;->IEE:I

    iget v0, p2, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->IEE:I

    iput v0, p1, Landroidx/constraintlayout/widget/wA$AZxh;->Pq:I

    iget v0, p2, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->Pq:I

    iput v0, p1, Landroidx/constraintlayout/widget/wA$AZxh;->diqgf:I

    iget v0, p2, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->vI:F

    iput v0, p1, Landroidx/constraintlayout/widget/wA$AZxh;->eyqo:F

    iget v0, p2, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->VocHEe:F

    iput v0, p1, Landroidx/constraintlayout/widget/wA$AZxh;->Ucbh:F

    iget-object v0, p2, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->BAnRFn:Ljava/lang/String;

    iput-object v0, p1, Landroidx/constraintlayout/widget/wA$AZxh;->huTpC:Ljava/lang/String;

    iget v0, p2, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->MiMN:I

    iput v0, p1, Landroidx/constraintlayout/widget/wA$AZxh;->Gd:I

    iget v0, p2, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->YoKzxo:I

    iput v0, p1, Landroidx/constraintlayout/widget/wA$AZxh;->HGpJ:I

    iget v0, p2, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->rkYL:F

    iput v0, p1, Landroidx/constraintlayout/widget/wA$AZxh;->vI:F

    iget v0, p2, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->oCFDzJ:I

    iput v0, p1, Landroidx/constraintlayout/widget/wA$AZxh;->VocHEe:I

    iget v0, p2, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->aqHPIZ:I

    iput v0, p1, Landroidx/constraintlayout/widget/wA$AZxh;->BAnRFn:I

    iget v0, p2, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->WrLQs:I

    iput v0, p1, Landroidx/constraintlayout/widget/wA$AZxh;->lB:I

    iget v0, p2, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->wA:F

    iput v0, p1, Landroidx/constraintlayout/widget/wA$AZxh;->xJ:F

    iget v0, p2, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->mjFkc:I

    iput v0, p1, Landroidx/constraintlayout/widget/wA$AZxh;->KLFTb:I

    iget v0, p2, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->AZxh:I

    iput v0, p1, Landroidx/constraintlayout/widget/wA$AZxh;->JHa:I

    iget v0, p2, Landroid/view/ViewGroup$MarginLayoutParams;->width:I

    iput v0, p1, Landroidx/constraintlayout/widget/wA$AZxh;->wA:I

    iget v0, p2, Landroid/view/ViewGroup$MarginLayoutParams;->height:I

    iput v0, p1, Landroidx/constraintlayout/widget/wA$AZxh;->ZfxDd:I

    iget v0, p2, Landroid/view/ViewGroup$MarginLayoutParams;->leftMargin:I

    iput v0, p1, Landroidx/constraintlayout/widget/wA$AZxh;->wJVbdd:I

    iget v0, p2, Landroid/view/ViewGroup$MarginLayoutParams;->rightMargin:I

    iput v0, p1, Landroidx/constraintlayout/widget/wA$AZxh;->mByQ:I

    iget v0, p2, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    iput v0, p1, Landroidx/constraintlayout/widget/wA$AZxh;->OjSQV:I

    iget v0, p2, Landroid/view/ViewGroup$MarginLayoutParams;->bottomMargin:I

    iput v0, p1, Landroidx/constraintlayout/widget/wA$AZxh;->Ne:I

    iget v0, p2, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->OjSQV:F

    iput v0, p1, Landroidx/constraintlayout/widget/wA$AZxh;->vadzgd:F

    iget v0, p2, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->mByQ:F

    iput v0, p1, Landroidx/constraintlayout/widget/wA$AZxh;->oCFDzJ:F

    iget v0, p2, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->CqaNbM:I

    iput v0, p1, Landroidx/constraintlayout/widget/wA$AZxh;->WrLQs:I

    iget v0, p2, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->Ne:I

    iput v0, p1, Landroidx/constraintlayout/widget/wA$AZxh;->aqHPIZ:I

    iget-boolean v0, p2, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->KRTLGT:Z

    iput-boolean v0, p1, Landroidx/constraintlayout/widget/wA$AZxh;->ANMGZc:Z

    iget-boolean v0, p2, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->GMIER:Z

    iput-boolean v0, p1, Landroidx/constraintlayout/widget/wA$AZxh;->alEkx:Z

    iget v0, p2, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->xrEuO:I

    iput v0, p1, Landroidx/constraintlayout/widget/wA$AZxh;->KRTLGT:I

    iget v0, p2, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->KLMXS:I

    iput v0, p1, Landroidx/constraintlayout/widget/wA$AZxh;->GMIER:I

    iget v0, p2, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->rWxwaT:I

    iput v0, p1, Landroidx/constraintlayout/widget/wA$AZxh;->uHVRx:I

    iget v0, p2, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->Vnb:I

    iput v0, p1, Landroidx/constraintlayout/widget/wA$AZxh;->JYn:I

    iget v0, p2, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->zvd:I

    iput v0, p1, Landroidx/constraintlayout/widget/wA$AZxh;->JYgkl:I

    iget v0, p2, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->cMLeY:I

    iput v0, p1, Landroidx/constraintlayout/widget/wA$AZxh;->JrJO:I

    iget v0, p2, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->NPj:F

    iput v0, p1, Landroidx/constraintlayout/widget/wA$AZxh;->nxI:F

    iget v0, p2, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->vadzgd:F

    iput v0, p1, Landroidx/constraintlayout/widget/wA$AZxh;->WGXroI:F

    iget-object v0, p2, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->uHVRx:Ljava/lang/String;

    iput-object v0, p1, Landroidx/constraintlayout/widget/wA$AZxh;->jm:Ljava/lang/String;

    iget v0, p2, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->eyqo:I

    iput v0, p1, Landroidx/constraintlayout/widget/wA$AZxh;->zvd:I

    iget v0, p2, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->huTpC:I

    iput v0, p1, Landroidx/constraintlayout/widget/wA$AZxh;->rWxwaT:I

    iget v0, p2, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->diqgf:I

    iput v0, p1, Landroidx/constraintlayout/widget/wA$AZxh;->KLMXS:I

    iget v0, p2, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->Ucbh:I

    iput v0, p1, Landroidx/constraintlayout/widget/wA$AZxh;->cMLeY:I

    iget v0, p2, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->Gd:I

    iput v0, p1, Landroidx/constraintlayout/widget/wA$AZxh;->NPj:I

    iget v0, p2, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->HGpJ:I

    iput v0, p1, Landroidx/constraintlayout/widget/wA$AZxh;->Vnb:I

    invoke-virtual {p2}, Landroid/view/ViewGroup$MarginLayoutParams;->getMarginEnd()I

    move-result v0

    iput v0, p1, Landroidx/constraintlayout/widget/wA$AZxh;->CqaNbM:I

    iget-object p0, p0, Landroidx/constraintlayout/widget/wA$mjFkc;->ZfxDd:Landroidx/constraintlayout/widget/wA$AZxh;

    invoke-virtual {p2}, Landroid/view/ViewGroup$MarginLayoutParams;->getMarginStart()I

    move-result p1

    iput p1, p0, Landroidx/constraintlayout/widget/wA$AZxh;->xrEuO:I

    return-void
.end method

.method public bridge synthetic clone()Ljava/lang/Object;
    .locals 0

    invoke-virtual {p0}, Landroidx/constraintlayout/widget/wA$mjFkc;->wA()Landroidx/constraintlayout/widget/wA$mjFkc;

    move-result-object p0

    return-object p0
.end method

.method public wA()Landroidx/constraintlayout/widget/wA$mjFkc;
    .locals 3

    new-instance v0, Landroidx/constraintlayout/widget/wA$mjFkc;

    invoke-direct {v0}, Landroidx/constraintlayout/widget/wA$mjFkc;-><init>()V

    iget-object v1, v0, Landroidx/constraintlayout/widget/wA$mjFkc;->ZfxDd:Landroidx/constraintlayout/widget/wA$AZxh;

    iget-object v2, p0, Landroidx/constraintlayout/widget/wA$mjFkc;->ZfxDd:Landroidx/constraintlayout/widget/wA$AZxh;

    invoke-virtual {v1, v2}, Landroidx/constraintlayout/widget/wA$AZxh;->mjFkc(Landroidx/constraintlayout/widget/wA$AZxh;)V

    iget-object v1, v0, Landroidx/constraintlayout/widget/wA$mjFkc;->wA:Landroidx/constraintlayout/widget/wA$wA;

    iget-object v2, p0, Landroidx/constraintlayout/widget/wA$mjFkc;->wA:Landroidx/constraintlayout/widget/wA$wA;

    invoke-virtual {v1, v2}, Landroidx/constraintlayout/widget/wA$wA;->mjFkc(Landroidx/constraintlayout/widget/wA$wA;)V

    iget-object v1, v0, Landroidx/constraintlayout/widget/wA$mjFkc;->AZxh:Landroidx/constraintlayout/widget/wA$ZfxDd;

    iget-object v2, p0, Landroidx/constraintlayout/widget/wA$mjFkc;->AZxh:Landroidx/constraintlayout/widget/wA$ZfxDd;

    invoke-virtual {v1, v2}, Landroidx/constraintlayout/widget/wA$ZfxDd;->mjFkc(Landroidx/constraintlayout/widget/wA$ZfxDd;)V

    iget-object v1, v0, Landroidx/constraintlayout/widget/wA$mjFkc;->KLFTb:Landroidx/constraintlayout/widget/wA$KLFTb;

    iget-object v2, p0, Landroidx/constraintlayout/widget/wA$mjFkc;->KLFTb:Landroidx/constraintlayout/widget/wA$KLFTb;

    invoke-virtual {v1, v2}, Landroidx/constraintlayout/widget/wA$KLFTb;->mjFkc(Landroidx/constraintlayout/widget/wA$KLFTb;)V

    iget p0, p0, Landroidx/constraintlayout/widget/wA$mjFkc;->mjFkc:I

    iput p0, v0, Landroidx/constraintlayout/widget/wA$mjFkc;->mjFkc:I

    return-object v0
.end method
