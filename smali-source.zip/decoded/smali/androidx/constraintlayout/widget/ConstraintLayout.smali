.class public Landroidx/constraintlayout/widget/ConstraintLayout;
.super Landroid/view/ViewGroup;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;,
        Landroidx/constraintlayout/widget/ConstraintLayout$wA;
    }
.end annotation


# instance fields
.field public AZxh:Ljava/util/ArrayList;

.field public Dt:Landroidx/constraintlayout/widget/wA;

.field public ETF:Lo/xVYW;

.field public IEE:I

.field public JHa:I

.field public KLFTb:I

.field public MiMN:Ljava/util/HashMap;

.field public Pq:I

.field public Ucbh:I

.field public VA:I

.field public YoKzxo:I

.field public ZfxDd:I

.field public diqgf:Landroid/util/SparseArray;

.field public eyqo:Landroidx/constraintlayout/widget/ConstraintLayout$wA;

.field public fehf:I

.field public huTpC:I

.field public lgHUyS:Z

.field public mjFkc:Landroid/util/SparseArray;

.field public qGY:I

.field public qdMbNW:I

.field public rkYL:I

.field public wA:Lo/kw;

.field public xJ:I


# direct methods
.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 2

    .line 1
    invoke-direct {p0, p1, p2}, Landroid/view/ViewGroup;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    .line 2
    new-instance p1, Landroid/util/SparseArray;

    invoke-direct {p1}, Landroid/util/SparseArray;-><init>()V

    iput-object p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->mjFkc:Landroid/util/SparseArray;

    .line 3
    new-instance p1, Ljava/util/ArrayList;

    const/4 v0, 0x4

    invoke-direct {p1, v0}, Ljava/util/ArrayList;-><init>(I)V

    iput-object p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->AZxh:Ljava/util/ArrayList;

    .line 4
    new-instance p1, Lo/kw;

    invoke-direct {p1}, Lo/kw;-><init>()V

    iput-object p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->wA:Lo/kw;

    const/4 p1, 0x0

    .line 5
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->ZfxDd:I

    .line 6
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->KLFTb:I

    const v0, 0x7fffffff

    .line 7
    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->JHa:I

    .line 8
    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->xJ:I

    const/4 v0, 0x1

    .line 9
    iput-boolean v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->lgHUyS:Z

    const/16 v0, 0x107

    .line 10
    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->qdMbNW:I

    const/4 v0, 0x0

    .line 11
    iput-object v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->Dt:Landroidx/constraintlayout/widget/wA;

    .line 12
    iput-object v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->ETF:Lo/xVYW;

    const/4 v0, -0x1

    .line 13
    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->VA:I

    .line 14
    new-instance v1, Ljava/util/HashMap;

    invoke-direct {v1}, Ljava/util/HashMap;-><init>()V

    iput-object v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->MiMN:Ljava/util/HashMap;

    .line 15
    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->YoKzxo:I

    .line 16
    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->rkYL:I

    .line 17
    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->qGY:I

    .line 18
    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->fehf:I

    .line 19
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->IEE:I

    .line 20
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->Pq:I

    .line 21
    new-instance v0, Landroid/util/SparseArray;

    invoke-direct {v0}, Landroid/util/SparseArray;-><init>()V

    iput-object v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->diqgf:Landroid/util/SparseArray;

    .line 22
    new-instance v0, Landroidx/constraintlayout/widget/ConstraintLayout$wA;

    invoke-direct {v0, p0, p0}, Landroidx/constraintlayout/widget/ConstraintLayout$wA;-><init>(Landroidx/constraintlayout/widget/ConstraintLayout;Landroidx/constraintlayout/widget/ConstraintLayout;)V

    iput-object v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->eyqo:Landroidx/constraintlayout/widget/ConstraintLayout$wA;

    .line 23
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->Ucbh:I

    .line 24
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->huTpC:I

    .line 25
    invoke-virtual {p0, p2, p1, p1}, Landroidx/constraintlayout/widget/ConstraintLayout;->Dt(Landroid/util/AttributeSet;II)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .locals 2

    .line 26
    invoke-direct {p0, p1, p2, p3}, Landroid/view/ViewGroup;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    .line 27
    new-instance p1, Landroid/util/SparseArray;

    invoke-direct {p1}, Landroid/util/SparseArray;-><init>()V

    iput-object p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->mjFkc:Landroid/util/SparseArray;

    .line 28
    new-instance p1, Ljava/util/ArrayList;

    const/4 v0, 0x4

    invoke-direct {p1, v0}, Ljava/util/ArrayList;-><init>(I)V

    iput-object p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->AZxh:Ljava/util/ArrayList;

    .line 29
    new-instance p1, Lo/kw;

    invoke-direct {p1}, Lo/kw;-><init>()V

    iput-object p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->wA:Lo/kw;

    const/4 p1, 0x0

    .line 30
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->ZfxDd:I

    .line 31
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->KLFTb:I

    const v0, 0x7fffffff

    .line 32
    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->JHa:I

    .line 33
    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->xJ:I

    const/4 v0, 0x1

    .line 34
    iput-boolean v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->lgHUyS:Z

    const/16 v0, 0x107

    .line 35
    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->qdMbNW:I

    const/4 v0, 0x0

    .line 36
    iput-object v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->Dt:Landroidx/constraintlayout/widget/wA;

    .line 37
    iput-object v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->ETF:Lo/xVYW;

    const/4 v0, -0x1

    .line 38
    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->VA:I

    .line 39
    new-instance v1, Ljava/util/HashMap;

    invoke-direct {v1}, Ljava/util/HashMap;-><init>()V

    iput-object v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->MiMN:Ljava/util/HashMap;

    .line 40
    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->YoKzxo:I

    .line 41
    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->rkYL:I

    .line 42
    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->qGY:I

    .line 43
    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->fehf:I

    .line 44
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->IEE:I

    .line 45
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->Pq:I

    .line 46
    new-instance v0, Landroid/util/SparseArray;

    invoke-direct {v0}, Landroid/util/SparseArray;-><init>()V

    iput-object v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->diqgf:Landroid/util/SparseArray;

    .line 47
    new-instance v0, Landroidx/constraintlayout/widget/ConstraintLayout$wA;

    invoke-direct {v0, p0, p0}, Landroidx/constraintlayout/widget/ConstraintLayout$wA;-><init>(Landroidx/constraintlayout/widget/ConstraintLayout;Landroidx/constraintlayout/widget/ConstraintLayout;)V

    iput-object v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->eyqo:Landroidx/constraintlayout/widget/ConstraintLayout$wA;

    .line 48
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->Ucbh:I

    .line 49
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->huTpC:I

    .line 50
    invoke-virtual {p0, p2, p3, p1}, Landroidx/constraintlayout/widget/ConstraintLayout;->Dt(Landroid/util/AttributeSet;II)V

    return-void
.end method

.method public static synthetic AZxh(Landroidx/constraintlayout/widget/ConstraintLayout;)Ljava/util/ArrayList;
    .locals 0

    iget-object p0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->AZxh:Ljava/util/ArrayList;

    return-object p0
.end method

.method private getPaddingWidth()I
    .locals 3

    invoke-virtual {p0}, Landroid/view/View;->getPaddingLeft()I

    move-result v0

    const/4 v1, 0x0

    invoke-static {v1, v0}, Ljava/lang/Math;->max(II)I

    move-result v0

    invoke-virtual {p0}, Landroid/view/View;->getPaddingRight()I

    move-result v2

    invoke-static {v1, v2}, Ljava/lang/Math;->max(II)I

    move-result v2

    add-int/2addr v0, v2

    invoke-virtual {p0}, Landroid/view/View;->getPaddingStart()I

    move-result v2

    invoke-static {v1, v2}, Ljava/lang/Math;->max(II)I

    move-result v2

    invoke-virtual {p0}, Landroid/view/View;->getPaddingEnd()I

    move-result p0

    invoke-static {v1, p0}, Ljava/lang/Math;->max(II)I

    move-result p0

    add-int/2addr v2, p0

    if-lez v2, :cond_0

    move v0, v2

    :cond_0
    return v0
.end method


# virtual methods
.method public final Dt(Landroid/util/AttributeSet;II)V
    .locals 5

    iget-object v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->wA:Lo/kw;

    invoke-virtual {v0, p0}, Lo/gjvQ;->bbzow(Ljava/lang/Object;)V

    iget-object v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->wA:Lo/kw;

    iget-object v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->eyqo:Landroidx/constraintlayout/widget/ConstraintLayout$wA;

    invoke-virtual {v0, v1}, Lo/kw;->mPWV(Lo/dkKKW$AZxh;)V

    iget-object v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->mjFkc:Landroid/util/SparseArray;

    invoke-virtual {p0}, Landroid/view/View;->getId()I

    move-result v1

    invoke-virtual {v0, v1, p0}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    const/4 v0, 0x0

    iput-object v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->Dt:Landroidx/constraintlayout/widget/wA;

    if-eqz p1, :cond_8

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    sget-object v2, Lo/V4;->dGDT:[I

    invoke-virtual {v1, p1, v2, p2, p3}, Landroid/content/Context;->obtainStyledAttributes(Landroid/util/AttributeSet;[III)Landroid/content/res/TypedArray;

    move-result-object p1

    invoke-virtual {p1}, Landroid/content/res/TypedArray;->getIndexCount()I

    move-result p2

    const/4 p3, 0x0

    move v1, p3

    :goto_0
    if-ge v1, p2, :cond_7

    invoke-virtual {p1, v1}, Landroid/content/res/TypedArray;->getIndex(I)I

    move-result v2

    sget v3, Lo/V4;->APn:I

    if-ne v2, v3, :cond_0

    iget v3, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->ZfxDd:I

    invoke-virtual {p1, v2, v3}, Landroid/content/res/TypedArray;->getDimensionPixelOffset(II)I

    move-result v2

    iput v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->ZfxDd:I

    goto :goto_2

    :cond_0
    sget v3, Lo/V4;->knzZ:I

    if-ne v2, v3, :cond_1

    iget v3, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->KLFTb:I

    invoke-virtual {p1, v2, v3}, Landroid/content/res/TypedArray;->getDimensionPixelOffset(II)I

    move-result v2

    iput v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->KLFTb:I

    goto :goto_2

    :cond_1
    sget v3, Lo/V4;->Jidt:I

    if-ne v2, v3, :cond_2

    iget v3, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->JHa:I

    invoke-virtual {p1, v2, v3}, Landroid/content/res/TypedArray;->getDimensionPixelOffset(II)I

    move-result v2

    iput v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->JHa:I

    goto :goto_2

    :cond_2
    sget v3, Lo/V4;->IvRQOa:I

    if-ne v2, v3, :cond_3

    iget v3, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->xJ:I

    invoke-virtual {p1, v2, v3}, Landroid/content/res/TypedArray;->getDimensionPixelOffset(II)I

    move-result v2

    iput v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->xJ:I

    goto :goto_2

    :cond_3
    sget v3, Lo/V4;->jpz:I

    if-ne v2, v3, :cond_4

    iget v3, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->qdMbNW:I

    invoke-virtual {p1, v2, v3}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v2

    iput v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->qdMbNW:I

    goto :goto_2

    :cond_4
    sget v3, Lo/V4;->vUsV:I

    if-ne v2, v3, :cond_5

    invoke-virtual {p1, v2, p3}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v2

    if-eqz v2, :cond_6

    :try_start_0
    invoke-virtual {p0, v2}, Landroidx/constraintlayout/widget/ConstraintLayout;->MiMN(I)V
    :try_end_0
    .catch Landroid/content/res/Resources$NotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_2

    :catch_0
    iput-object v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->ETF:Lo/xVYW;

    goto :goto_2

    :cond_5
    sget v3, Lo/V4;->oVXlhB:I

    if-ne v2, v3, :cond_6

    invoke-virtual {p1, v2, p3}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v2

    :try_start_1
    new-instance v3, Landroidx/constraintlayout/widget/wA;

    invoke-direct {v3}, Landroidx/constraintlayout/widget/wA;-><init>()V

    iput-object v3, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->Dt:Landroidx/constraintlayout/widget/wA;

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v4

    invoke-virtual {v3, v4, v2}, Landroidx/constraintlayout/widget/wA;->ETF(Landroid/content/Context;I)V
    :try_end_1
    .catch Landroid/content/res/Resources$NotFoundException; {:try_start_1 .. :try_end_1} :catch_1

    goto :goto_1

    :catch_1
    iput-object v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->Dt:Landroidx/constraintlayout/widget/wA;

    :goto_1
    iput v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->VA:I

    :cond_6
    :goto_2
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_7
    invoke-virtual {p1}, Landroid/content/res/TypedArray;->recycle()V

    :cond_8
    iget-object p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->wA:Lo/kw;

    iget p0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->qdMbNW:I

    invoke-virtual {p1, p0}, Lo/kw;->dkKKW(I)V

    return-void
.end method

.method public ETF()Z
    .locals 2

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/Context;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;

    move-result-object v0

    iget v0, v0, Landroid/content/pm/ApplicationInfo;->flags:I

    const/high16 v1, 0x400000

    and-int/2addr v0, v1

    if-eqz v0, :cond_0

    invoke-virtual {p0}, Landroid/view/View;->getLayoutDirection()I

    move-result p0

    const/4 v0, 0x1

    if-ne v0, p0, :cond_0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public IEE(Lo/kw;IIII)V
    .locals 7

    iget-object v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->eyqo:Landroidx/constraintlayout/widget/ConstraintLayout$wA;

    iget v1, v0, Landroidx/constraintlayout/widget/ConstraintLayout$wA;->KLFTb:I

    iget v0, v0, Landroidx/constraintlayout/widget/ConstraintLayout$wA;->ZfxDd:I

    sget-object v2, Lo/gjvQ$AZxh;->mjFkc:Lo/gjvQ$AZxh;

    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v3

    const/high16 v4, 0x40000000    # 2.0f

    const/high16 v5, -0x80000000

    const/4 v6, 0x0

    if-eq p2, v5, :cond_3

    if-eqz p2, :cond_2

    if-eq p2, v4, :cond_1

    move-object p2, v2

    :cond_0
    move p3, v6

    goto :goto_0

    :cond_1
    iget p2, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->JHa:I

    sub-int/2addr p2, v0

    invoke-static {p2, p3}, Ljava/lang/Math;->min(II)I

    move-result p3

    move-object p2, v2

    goto :goto_0

    :cond_2
    sget-object p2, Lo/gjvQ$AZxh;->AZxh:Lo/gjvQ$AZxh;

    if-nez v3, :cond_0

    iget p3, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->ZfxDd:I

    invoke-static {v6, p3}, Ljava/lang/Math;->max(II)I

    move-result p3

    goto :goto_0

    :cond_3
    sget-object p2, Lo/gjvQ$AZxh;->AZxh:Lo/gjvQ$AZxh;

    if-nez v3, :cond_4

    iget p3, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->ZfxDd:I

    invoke-static {v6, p3}, Ljava/lang/Math;->max(II)I

    move-result p3

    :cond_4
    :goto_0
    if-eq p4, v5, :cond_8

    if-eqz p4, :cond_7

    if-eq p4, v4, :cond_6

    :cond_5
    move p5, v6

    goto :goto_1

    :cond_6
    iget p4, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->xJ:I

    sub-int/2addr p4, v1

    invoke-static {p4, p5}, Ljava/lang/Math;->min(II)I

    move-result p5

    goto :goto_1

    :cond_7
    sget-object v2, Lo/gjvQ$AZxh;->AZxh:Lo/gjvQ$AZxh;

    if-nez v3, :cond_5

    iget p4, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->KLFTb:I

    invoke-static {v6, p4}, Ljava/lang/Math;->max(II)I

    move-result p5

    goto :goto_1

    :cond_8
    sget-object v2, Lo/gjvQ$AZxh;->AZxh:Lo/gjvQ$AZxh;

    if-nez v3, :cond_9

    iget p4, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->KLFTb:I

    invoke-static {v6, p4}, Ljava/lang/Math;->max(II)I

    move-result p5

    :cond_9
    :goto_1
    invoke-virtual {p1}, Lo/gjvQ;->vadzgd()I

    move-result p4

    if-ne p3, p4, :cond_a

    invoke-virtual {p1}, Lo/gjvQ;->Ucbh()I

    move-result p4

    if-eq p5, p4, :cond_b

    :cond_a
    invoke-virtual {p1}, Lo/kw;->IyS()V

    :cond_b
    invoke-virtual {p1, v6}, Lo/gjvQ;->uH(I)V

    invoke-virtual {p1, v6}, Lo/gjvQ;->tISON(I)V

    iget p4, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->JHa:I

    sub-int/2addr p4, v0

    invoke-virtual {p1, p4}, Lo/gjvQ;->Qr(I)V

    iget p4, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->xJ:I

    sub-int/2addr p4, v1

    invoke-virtual {p1, p4}, Lo/gjvQ;->SOS(I)V

    invoke-virtual {p1, v6}, Lo/gjvQ;->gtIJp(I)V

    invoke-virtual {p1, v6}, Lo/gjvQ;->NKyg(I)V

    invoke-virtual {p1, p2}, Lo/gjvQ;->yfx(Lo/gjvQ$AZxh;)V

    invoke-virtual {p1, p3}, Lo/gjvQ;->jx(I)V

    invoke-virtual {p1, v2}, Lo/gjvQ;->fFz(Lo/gjvQ$AZxh;)V

    invoke-virtual {p1, p5}, Lo/gjvQ;->ANMGZc(I)V

    iget p2, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->ZfxDd:I

    sub-int/2addr p2, v0

    invoke-virtual {p1, p2}, Lo/gjvQ;->gtIJp(I)V

    iget p0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->KLFTb:I

    sub-int/2addr p0, v1

    invoke-virtual {p1, p0}, Lo/gjvQ;->NKyg(I)V

    return-void
.end method

.method public JHa(ILjava/lang/Object;)Ljava/lang/Object;
    .locals 0

    if-nez p1, :cond_0

    instance-of p1, p2, Ljava/lang/String;

    if-eqz p1, :cond_0

    check-cast p2, Ljava/lang/String;

    iget-object p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->MiMN:Ljava/util/HashMap;

    if-eqz p1, :cond_0

    invoke-virtual {p1, p2}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    iget-object p0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->MiMN:Ljava/util/HashMap;

    invoke-virtual {p0, p2}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :cond_0
    const/4 p0, 0x0

    return-object p0
.end method

.method public KLFTb(Landroid/util/AttributeSet;)Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;
    .locals 1

    new-instance v0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p0

    invoke-direct {v0, p0, p1}, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    return-object v0
.end method

.method public MiMN(I)V
    .locals 2

    new-instance v0, Lo/xVYW;

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-direct {v0, v1, p0, p1}, Lo/xVYW;-><init>(Landroid/content/Context;Landroidx/constraintlayout/widget/ConstraintLayout;I)V

    iput-object v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->ETF:Lo/xVYW;

    return-void
.end method

.method public final Pq()Z
    .locals 4

    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v0

    const/4 v1, 0x0

    move v2, v1

    :goto_0
    if-ge v2, v0, :cond_1

    invoke-virtual {p0, v2}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v3

    invoke-virtual {v3}, Landroid/view/View;->isLayoutRequested()Z

    move-result v3

    if-eqz v3, :cond_0

    const/4 v1, 0x1

    goto :goto_1

    :cond_0
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_1
    :goto_1
    if-eqz v1, :cond_2

    invoke-virtual {p0}, Landroidx/constraintlayout/widget/ConstraintLayout;->qGY()V

    :cond_2
    return v1
.end method

.method public final VA()V
    .locals 1

    const/4 v0, 0x1

    iput-boolean v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->lgHUyS:Z

    const/4 v0, -0x1

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->YoKzxo:I

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->rkYL:I

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->qGY:I

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->fehf:I

    const/4 v0, 0x0

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->IEE:I

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->Pq:I

    return-void
.end method

.method public YoKzxo(IIIIZZ)V
    .locals 2

    iget-object v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->eyqo:Landroidx/constraintlayout/widget/ConstraintLayout$wA;

    iget v1, v0, Landroidx/constraintlayout/widget/ConstraintLayout$wA;->KLFTb:I

    iget v0, v0, Landroidx/constraintlayout/widget/ConstraintLayout$wA;->ZfxDd:I

    add-int/2addr p3, v0

    add-int/2addr p4, v1

    const/4 v0, 0x0

    invoke-static {p3, p1, v0}, Landroid/view/View;->resolveSizeAndState(III)I

    move-result p1

    invoke-static {p4, p2, v0}, Landroid/view/View;->resolveSizeAndState(III)I

    move-result p2

    const p3, 0xffffff

    and-int/2addr p1, p3

    and-int/2addr p2, p3

    iget p3, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->JHa:I

    invoke-static {p3, p1}, Ljava/lang/Math;->min(II)I

    move-result p1

    iget p3, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->xJ:I

    invoke-static {p3, p2}, Ljava/lang/Math;->min(II)I

    move-result p2

    const/high16 p3, 0x1000000

    if-eqz p5, :cond_0

    or-int/2addr p1, p3

    :cond_0
    if-eqz p6, :cond_1

    or-int/2addr p2, p3

    :cond_1
    invoke-virtual {p0, p1, p2}, Landroid/view/View;->setMeasuredDimension(II)V

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->YoKzxo:I

    iput p2, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->rkYL:I

    return-void
.end method

.method public ZfxDd()Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;
    .locals 1

    new-instance p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;

    const/4 v0, -0x2

    invoke-direct {p0, v0, v0}, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;-><init>(II)V

    return-object p0
.end method

.method public addView(Landroid/view/View;ILandroid/view/ViewGroup$LayoutParams;)V
    .locals 0

    invoke-super {p0, p1, p2, p3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;ILandroid/view/ViewGroup$LayoutParams;)V

    return-void
.end method

.method public checkLayoutParams(Landroid/view/ViewGroup$LayoutParams;)Z
    .locals 0

    instance-of p0, p1, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;

    return p0
.end method

.method public dispatchDraw(Landroid/graphics/Canvas;)V
    .locals 18

    move-object/from16 v0, p0

    iget-object v1, v0, Landroidx/constraintlayout/widget/ConstraintLayout;->AZxh:Ljava/util/ArrayList;

    const/4 v2, 0x0

    if-eqz v1, :cond_0

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-lez v1, :cond_0

    move v3, v2

    :goto_0
    if-ge v3, v1, :cond_0

    iget-object v4, v0, Landroidx/constraintlayout/widget/ConstraintLayout;->AZxh:Ljava/util/ArrayList;

    invoke-virtual {v4, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Landroidx/constraintlayout/widget/AZxh;

    invoke-virtual {v4, v0}, Landroidx/constraintlayout/widget/AZxh;->ETF(Landroidx/constraintlayout/widget/ConstraintLayout;)V

    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    :cond_0
    invoke-super/range {p0 .. p1}, Landroid/view/ViewGroup;->dispatchDraw(Landroid/graphics/Canvas;)V

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->isInEditMode()Z

    move-result v1

    if-eqz v1, :cond_3

    invoke-virtual/range {p0 .. p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v1

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getWidth()I

    move-result v3

    int-to-float v3, v3

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getHeight()I

    move-result v4

    int-to-float v4, v4

    move v5, v2

    :goto_1
    if-ge v5, v1, :cond_3

    invoke-virtual {v0, v5}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v6

    invoke-virtual {v6}, Landroid/view/View;->getVisibility()I

    move-result v7

    const/16 v8, 0x8

    if-ne v7, v8, :cond_1

    goto/16 :goto_2

    :cond_1
    invoke-virtual {v6}, Landroid/view/View;->getTag()Ljava/lang/Object;

    move-result-object v6

    if-eqz v6, :cond_2

    instance-of v7, v6, Ljava/lang/String;

    if-eqz v7, :cond_2

    check-cast v6, Ljava/lang/String;

    const-string v7, ","

    invoke-virtual {v6, v7}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v6

    array-length v7, v6

    const/4 v8, 0x4

    if-ne v7, v8, :cond_2

    aget-object v7, v6, v2

    invoke-static {v7}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v7

    const/4 v8, 0x1

    aget-object v8, v6, v8

    invoke-static {v8}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v8

    const/4 v9, 0x2

    aget-object v9, v6, v9

    invoke-static {v9}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v9

    const/4 v10, 0x3

    aget-object v6, v6, v10

    invoke-static {v6}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v6

    int-to-float v7, v7

    const/high16 v10, 0x44870000    # 1080.0f

    div-float/2addr v7, v10

    mul-float/2addr v7, v3

    float-to-int v7, v7

    int-to-float v8, v8

    const/high16 v11, 0x44f00000    # 1920.0f

    div-float/2addr v8, v11

    mul-float/2addr v8, v4

    float-to-int v8, v8

    int-to-float v9, v9

    div-float/2addr v9, v10

    mul-float/2addr v9, v3

    float-to-int v9, v9

    int-to-float v6, v6

    div-float/2addr v6, v11

    mul-float/2addr v6, v4

    float-to-int v6, v6

    new-instance v15, Landroid/graphics/Paint;

    invoke-direct {v15}, Landroid/graphics/Paint;-><init>()V

    const/high16 v10, -0x10000

    invoke-virtual {v15, v10}, Landroid/graphics/Paint;->setColor(I)V

    int-to-float v14, v7

    int-to-float v13, v8

    add-int/2addr v7, v9

    int-to-float v7, v7

    move-object/from16 v10, p1

    move v11, v14

    move v12, v13

    move v9, v13

    move v13, v7

    move/from16 v16, v14

    move v14, v9

    move-object/from16 v17, v15

    invoke-virtual/range {v10 .. v15}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    add-int/2addr v8, v6

    int-to-float v6, v8

    move v11, v7

    move v12, v9

    move v14, v6

    invoke-virtual/range {v10 .. v15}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    move v12, v6

    move/from16 v13, v16

    invoke-virtual/range {v10 .. v15}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    move/from16 v11, v16

    move v14, v9

    invoke-virtual/range {v10 .. v15}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    const v8, -0xff0100

    invoke-virtual {v15, v8}, Landroid/graphics/Paint;->setColor(I)V

    move v12, v9

    move v13, v7

    move v14, v6

    move-object v8, v15

    invoke-virtual/range {v10 .. v15}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    move v12, v6

    move v14, v9

    invoke-virtual/range {v10 .. v15}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    :cond_2
    :goto_2
    add-int/lit8 v5, v5, 0x1

    goto/16 :goto_1

    :cond_3
    return-void
.end method

.method public fehf(ILjava/lang/Object;Ljava/lang/Object;)V
    .locals 1

    if-nez p1, :cond_2

    instance-of p1, p2, Ljava/lang/String;

    if-eqz p1, :cond_2

    instance-of p1, p3, Ljava/lang/Integer;

    if-eqz p1, :cond_2

    iget-object p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->MiMN:Ljava/util/HashMap;

    if-nez p1, :cond_0

    new-instance p1, Ljava/util/HashMap;

    invoke-direct {p1}, Ljava/util/HashMap;-><init>()V

    iput-object p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->MiMN:Ljava/util/HashMap;

    :cond_0
    check-cast p2, Ljava/lang/String;

    const-string p1, "/"

    invoke-virtual {p2, p1}, Ljava/lang/String;->indexOf(Ljava/lang/String;)I

    move-result p1

    const/4 v0, -0x1

    if-eq p1, v0, :cond_1

    add-int/lit8 p1, p1, 0x1

    invoke-virtual {p2, p1}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object p2

    :cond_1
    check-cast p3, Ljava/lang/Integer;

    invoke-virtual {p3}, Ljava/lang/Integer;->intValue()I

    iget-object p0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->MiMN:Ljava/util/HashMap;

    invoke-virtual {p0, p2, p3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_2
    return-void
.end method

.method public forceLayout()V
    .locals 0

    invoke-virtual {p0}, Landroidx/constraintlayout/widget/ConstraintLayout;->VA()V

    invoke-super {p0}, Landroid/view/View;->forceLayout()V

    return-void
.end method

.method public bridge synthetic generateDefaultLayoutParams()Landroid/view/ViewGroup$LayoutParams;
    .locals 0

    invoke-virtual {p0}, Landroidx/constraintlayout/widget/ConstraintLayout;->ZfxDd()Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;

    move-result-object p0

    return-object p0
.end method

.method public bridge synthetic generateLayoutParams(Landroid/util/AttributeSet;)Landroid/view/ViewGroup$LayoutParams;
    .locals 0

    .line 1
    invoke-virtual {p0, p1}, Landroidx/constraintlayout/widget/ConstraintLayout;->KLFTb(Landroid/util/AttributeSet;)Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;

    move-result-object p0

    return-object p0
.end method

.method public generateLayoutParams(Landroid/view/ViewGroup$LayoutParams;)Landroid/view/ViewGroup$LayoutParams;
    .locals 0

    .line 2
    new-instance p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;

    invoke-direct {p0, p1}, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;-><init>(Landroid/view/ViewGroup$LayoutParams;)V

    return-object p0
.end method

.method public getMaxHeight()I
    .locals 0

    iget p0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->xJ:I

    return p0
.end method

.method public getMaxWidth()I
    .locals 0

    iget p0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->JHa:I

    return p0
.end method

.method public getMinHeight()I
    .locals 0

    iget p0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->KLFTb:I

    return p0
.end method

.method public getMinWidth()I
    .locals 0

    iget p0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->ZfxDd:I

    return p0
.end method

.method public getOptimizationLevel()I
    .locals 0

    iget-object p0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->wA:Lo/kw;

    invoke-virtual {p0}, Lo/kw;->FbxKQm()I

    move-result p0

    return p0
.end method

.method public lgHUyS(I)Landroid/view/View;
    .locals 0

    iget-object p0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->mjFkc:Landroid/util/SparseArray;

    invoke-virtual {p0, p1}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/view/View;

    return-object p0
.end method

.method public onLayout(ZIIII)V
    .locals 4

    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result p1

    invoke-virtual {p0}, Landroid/view/View;->isInEditMode()Z

    move-result p2

    const/4 p3, 0x0

    move p4, p3

    :goto_0
    if-ge p4, p1, :cond_2

    invoke-virtual {p0, p4}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object p5

    invoke-virtual {p5}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    check-cast v0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;

    iget-object v1, v0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->xROA:Lo/gjvQ;

    invoke-virtual {p5}, Landroid/view/View;->getVisibility()I

    move-result v2

    const/16 v3, 0x8

    if-ne v2, v3, :cond_0

    iget-boolean v2, v0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->nxI:Z

    if-nez v2, :cond_0

    iget-boolean v2, v0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->WGXroI:Z

    if-nez v2, :cond_0

    iget-boolean v2, v0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->bbzow:Z

    if-nez v2, :cond_0

    if-nez p2, :cond_0

    goto :goto_1

    :cond_0
    iget-boolean v0, v0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->XV:Z

    if-eqz v0, :cond_1

    goto :goto_1

    :cond_1
    invoke-virtual {v1}, Lo/gjvQ;->oCFDzJ()I

    move-result v0

    invoke-virtual {v1}, Lo/gjvQ;->aqHPIZ()I

    move-result v2

    invoke-virtual {v1}, Lo/gjvQ;->vadzgd()I

    move-result v3

    add-int/2addr v3, v0

    invoke-virtual {v1}, Lo/gjvQ;->Ucbh()I

    move-result v1

    add-int/2addr v1, v2

    invoke-virtual {p5, v0, v2, v3, v1}, Landroid/view/View;->layout(IIII)V

    :goto_1
    add-int/lit8 p4, p4, 0x1

    goto :goto_0

    :cond_2
    iget-object p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->AZxh:Ljava/util/ArrayList;

    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result p1

    if-lez p1, :cond_3

    :goto_2
    if-ge p3, p1, :cond_3

    iget-object p2, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->AZxh:Ljava/util/ArrayList;

    invoke-virtual {p2, p3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Landroidx/constraintlayout/widget/AZxh;

    invoke-virtual {p2, p0}, Landroidx/constraintlayout/widget/AZxh;->qdMbNW(Landroidx/constraintlayout/widget/ConstraintLayout;)V

    add-int/lit8 p3, p3, 0x1

    goto :goto_2

    :cond_3
    return-void
.end method

.method public onMeasure(II)V
    .locals 8

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->Ucbh:I

    iput p2, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->huTpC:I

    iget-object v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->wA:Lo/kw;

    invoke-virtual {p0}, Landroidx/constraintlayout/widget/ConstraintLayout;->ETF()Z

    move-result v1

    invoke-virtual {v0, v1}, Lo/kw;->NV(Z)V

    iget-boolean v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->lgHUyS:Z

    if-eqz v0, :cond_0

    const/4 v0, 0x0

    iput-boolean v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->lgHUyS:Z

    invoke-virtual {p0}, Landroidx/constraintlayout/widget/ConstraintLayout;->Pq()Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->wA:Lo/kw;

    invoke-virtual {v0}, Lo/kw;->IvRQOa()V

    :cond_0
    iget-object v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->wA:Lo/kw;

    iget v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->qdMbNW:I

    invoke-virtual {p0, v0, v1, p1, p2}, Landroidx/constraintlayout/widget/ConstraintLayout;->rkYL(Lo/kw;III)V

    iget-object v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->wA:Lo/kw;

    invoke-virtual {v0}, Lo/gjvQ;->vadzgd()I

    move-result v4

    iget-object v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->wA:Lo/kw;

    invoke-virtual {v0}, Lo/gjvQ;->Ucbh()I

    move-result v5

    iget-object v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->wA:Lo/kw;

    invoke-virtual {v0}, Lo/kw;->Xxz()Z

    move-result v6

    iget-object v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->wA:Lo/kw;

    invoke-virtual {v0}, Lo/kw;->tAfC()Z

    move-result v7

    move-object v1, p0

    move v2, p1

    move v3, p2

    invoke-virtual/range {v1 .. v7}, Landroidx/constraintlayout/widget/ConstraintLayout;->YoKzxo(IIIIZZ)V

    return-void
.end method

.method public onViewAdded(Landroid/view/View;)V
    .locals 3

    invoke-super {p0, p1}, Landroid/view/ViewGroup;->onViewAdded(Landroid/view/View;)V

    invoke-virtual {p0, p1}, Landroidx/constraintlayout/widget/ConstraintLayout;->qdMbNW(Landroid/view/View;)Lo/gjvQ;

    move-result-object v0

    instance-of v1, p1, Landroidx/constraintlayout/widget/ZfxDd;

    const/4 v2, 0x1

    if-eqz v1, :cond_0

    instance-of v0, v0, Lo/n;

    if-nez v0, :cond_0

    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    check-cast v0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;

    new-instance v1, Lo/n;

    invoke-direct {v1}, Lo/n;-><init>()V

    iput-object v1, v0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->xROA:Lo/gjvQ;

    iput-boolean v2, v0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->nxI:Z

    iget v0, v0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->WrLQs:I

    invoke-virtual {v1, v0}, Lo/n;->SKTn(I)V

    :cond_0
    instance-of v0, p1, Landroidx/constraintlayout/widget/AZxh;

    if-eqz v0, :cond_1

    move-object v0, p1

    check-cast v0, Landroidx/constraintlayout/widget/AZxh;

    invoke-virtual {v0}, Landroidx/constraintlayout/widget/AZxh;->MiMN()V

    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v1

    check-cast v1, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;

    iput-boolean v2, v1, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->WGXroI:Z

    iget-object v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->AZxh:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_1

    iget-object v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->AZxh:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_1
    iget-object v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->mjFkc:Landroid/util/SparseArray;

    invoke-virtual {p1}, Landroid/view/View;->getId()I

    move-result v1

    invoke-virtual {v0, v1, p1}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    iput-boolean v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->lgHUyS:Z

    return-void
.end method

.method public onViewRemoved(Landroid/view/View;)V
    .locals 2

    invoke-super {p0, p1}, Landroid/view/ViewGroup;->onViewRemoved(Landroid/view/View;)V

    iget-object v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->mjFkc:Landroid/util/SparseArray;

    invoke-virtual {p1}, Landroid/view/View;->getId()I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/util/SparseArray;->remove(I)V

    invoke-virtual {p0, p1}, Landroidx/constraintlayout/widget/ConstraintLayout;->qdMbNW(Landroid/view/View;)Lo/gjvQ;

    move-result-object v0

    iget-object v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->wA:Lo/kw;

    invoke-virtual {v1, v0}, Lo/Ia;->XD(Lo/gjvQ;)V

    iget-object v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->AZxh:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    const/4 p1, 0x1

    iput-boolean p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->lgHUyS:Z

    return-void
.end method

.method public final qGY()V
    .locals 9

    invoke-virtual {p0}, Landroid/view/View;->isInEditMode()Z

    move-result v6

    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v7

    const/4 v0, 0x0

    move v1, v0

    :goto_0
    if-ge v1, v7, :cond_1

    invoke-virtual {p0, v1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v2

    invoke-virtual {p0, v2}, Landroidx/constraintlayout/widget/ConstraintLayout;->qdMbNW(Landroid/view/View;)Lo/gjvQ;

    move-result-object v2

    if-nez v2, :cond_0

    goto :goto_1

    :cond_0
    invoke-virtual {v2}, Lo/gjvQ;->JrJO()V

    :goto_1
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_1
    const/4 v1, -0x1

    if-eqz v6, :cond_3

    move v2, v0

    :goto_2
    if-ge v2, v7, :cond_3

    invoke-virtual {p0, v2}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v3

    :try_start_0
    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v4

    invoke-virtual {v3}, Landroid/view/View;->getId()I

    move-result v5

    invoke-virtual {v4, v5}, Landroid/content/res/Resources;->getResourceName(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3}, Landroid/view/View;->getId()I

    move-result v5

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-virtual {p0, v0, v4, v5}, Landroidx/constraintlayout/widget/ConstraintLayout;->fehf(ILjava/lang/Object;Ljava/lang/Object;)V

    const/16 v5, 0x2f

    invoke-virtual {v4, v5}, Ljava/lang/String;->indexOf(I)I

    move-result v5

    if-eq v5, v1, :cond_2

    add-int/lit8 v5, v5, 0x1

    invoke-virtual {v4, v5}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v4

    :cond_2
    invoke-virtual {v3}, Landroid/view/View;->getId()I

    move-result v3

    invoke-virtual {p0, v3}, Landroidx/constraintlayout/widget/ConstraintLayout;->xJ(I)Lo/gjvQ;

    move-result-object v3

    invoke-virtual {v3, v4}, Lo/gjvQ;->SwgkN(Ljava/lang/String;)V
    :try_end_0
    .catch Landroid/content/res/Resources$NotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    add-int/lit8 v2, v2, 0x1

    goto :goto_2

    :cond_3
    iget v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->VA:I

    if-eq v2, v1, :cond_4

    move v1, v0

    :goto_3
    if-ge v1, v7, :cond_4

    invoke-virtual {p0, v1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v2

    invoke-virtual {v2}, Landroid/view/View;->getId()I

    add-int/lit8 v1, v1, 0x1

    goto :goto_3

    :cond_4
    iget-object v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->Dt:Landroidx/constraintlayout/widget/wA;

    if-eqz v1, :cond_5

    const/4 v2, 0x1

    invoke-virtual {v1, p0, v2}, Landroidx/constraintlayout/widget/wA;->ZfxDd(Landroidx/constraintlayout/widget/ConstraintLayout;Z)V

    :cond_5
    iget-object v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->wA:Lo/kw;

    invoke-virtual {v1}, Lo/Ia;->gtr()V

    iget-object v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->AZxh:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-lez v1, :cond_6

    move v2, v0

    :goto_4
    if-ge v2, v1, :cond_6

    iget-object v3, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->AZxh:Ljava/util/ArrayList;

    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroidx/constraintlayout/widget/AZxh;

    invoke-virtual {v3, p0}, Landroidx/constraintlayout/widget/AZxh;->VA(Landroidx/constraintlayout/widget/ConstraintLayout;)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_4

    :cond_6
    move v1, v0

    :goto_5
    if-ge v1, v7, :cond_7

    invoke-virtual {p0, v1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    add-int/lit8 v1, v1, 0x1

    goto :goto_5

    :cond_7
    iget-object v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->diqgf:Landroid/util/SparseArray;

    invoke-virtual {v1}, Landroid/util/SparseArray;->clear()V

    iget-object v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->diqgf:Landroid/util/SparseArray;

    iget-object v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->wA:Lo/kw;

    invoke-virtual {v1, v0, v2}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    iget-object v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->diqgf:Landroid/util/SparseArray;

    invoke-virtual {p0}, Landroid/view/View;->getId()I

    move-result v2

    iget-object v3, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->wA:Lo/kw;

    invoke-virtual {v1, v2, v3}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    move v1, v0

    :goto_6
    if-ge v1, v7, :cond_8

    invoke-virtual {p0, v1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v2

    invoke-virtual {p0, v2}, Landroidx/constraintlayout/widget/ConstraintLayout;->qdMbNW(Landroid/view/View;)Lo/gjvQ;

    move-result-object v3

    iget-object v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->diqgf:Landroid/util/SparseArray;

    invoke-virtual {v2}, Landroid/view/View;->getId()I

    move-result v2

    invoke-virtual {v4, v2, v3}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    add-int/lit8 v1, v1, 0x1

    goto :goto_6

    :cond_8
    move v8, v0

    :goto_7
    if-ge v8, v7, :cond_a

    invoke-virtual {p0, v8}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v2

    invoke-virtual {p0, v2}, Landroidx/constraintlayout/widget/ConstraintLayout;->qdMbNW(Landroid/view/View;)Lo/gjvQ;

    move-result-object v3

    if-nez v3, :cond_9

    goto :goto_8

    :cond_9
    invoke-virtual {v2}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    move-object v4, v0

    check-cast v4, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;

    iget-object v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->wA:Lo/kw;

    invoke-virtual {v0, v3}, Lo/Ia;->AZxh(Lo/gjvQ;)V

    iget-object v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->diqgf:Landroid/util/SparseArray;

    move-object v0, p0

    move v1, v6

    invoke-virtual/range {v0 .. v5}, Landroidx/constraintlayout/widget/ConstraintLayout;->wA(ZLandroid/view/View;Lo/gjvQ;Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;Landroid/util/SparseArray;)V

    :goto_8
    add-int/lit8 v8, v8, 0x1

    goto :goto_7

    :cond_a
    return-void
.end method

.method public final qdMbNW(Landroid/view/View;)Lo/gjvQ;
    .locals 0

    if-ne p1, p0, :cond_0

    iget-object p0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->wA:Lo/kw;

    return-object p0

    :cond_0
    if-nez p1, :cond_1

    const/4 p0, 0x0

    goto :goto_0

    :cond_1
    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object p0

    check-cast p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;

    iget-object p0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->xROA:Lo/gjvQ;

    :goto_0
    return-object p0
.end method

.method public removeView(Landroid/view/View;)V
    .locals 0

    invoke-super {p0, p1}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    return-void
.end method

.method public requestLayout()V
    .locals 0

    invoke-virtual {p0}, Landroidx/constraintlayout/widget/ConstraintLayout;->VA()V

    invoke-super {p0}, Landroid/view/View;->requestLayout()V

    return-void
.end method

.method public rkYL(Lo/kw;III)V
    .locals 17

    move-object/from16 v6, p0

    invoke-static/range {p3 .. p3}, Landroid/view/View$MeasureSpec;->getMode(I)I

    move-result v7

    invoke-static/range {p3 .. p3}, Landroid/view/View$MeasureSpec;->getSize(I)I

    move-result v0

    invoke-static/range {p4 .. p4}, Landroid/view/View$MeasureSpec;->getMode(I)I

    move-result v8

    invoke-static/range {p4 .. p4}, Landroid/view/View$MeasureSpec;->getSize(I)I

    move-result v1

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getPaddingTop()I

    move-result v2

    const/4 v3, 0x0

    invoke-static {v3, v2}, Ljava/lang/Math;->max(II)I

    move-result v16

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getPaddingBottom()I

    move-result v2

    invoke-static {v3, v2}, Ljava/lang/Math;->max(II)I

    move-result v13

    add-int v2, v16, v13

    invoke-direct/range {p0 .. p0}, Landroidx/constraintlayout/widget/ConstraintLayout;->getPaddingWidth()I

    move-result v4

    iget-object v9, v6, Landroidx/constraintlayout/widget/ConstraintLayout;->eyqo:Landroidx/constraintlayout/widget/ConstraintLayout$wA;

    move/from16 v10, p3

    move/from16 v11, p4

    move/from16 v12, v16

    move v14, v4

    move v15, v2

    invoke-virtual/range {v9 .. v15}, Landroidx/constraintlayout/widget/ConstraintLayout$wA;->wA(IIIIII)V

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getPaddingStart()I

    move-result v5

    invoke-static {v3, v5}, Ljava/lang/Math;->max(II)I

    move-result v5

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getPaddingEnd()I

    move-result v9

    invoke-static {v3, v9}, Ljava/lang/Math;->max(II)I

    move-result v9

    if-gtz v5, :cond_1

    if-lez v9, :cond_0

    goto :goto_0

    :cond_0
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getPaddingLeft()I

    move-result v5

    invoke-static {v3, v5}, Ljava/lang/Math;->max(II)I

    move-result v3

    move v9, v3

    goto :goto_1

    :cond_1
    :goto_0
    invoke-virtual/range {p0 .. p0}, Landroidx/constraintlayout/widget/ConstraintLayout;->ETF()Z

    move-result v3

    if-eqz v3, :cond_2

    goto :goto_1

    :cond_2
    move v9, v5

    :goto_1
    sub-int v10, v0, v4

    sub-int v11, v1, v2

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move v2, v7

    move v3, v10

    move v4, v8

    move v5, v11

    invoke-virtual/range {v0 .. v5}, Landroidx/constraintlayout/widget/ConstraintLayout;->IEE(Lo/kw;IIII)V

    iget v12, v6, Landroidx/constraintlayout/widget/ConstraintLayout;->YoKzxo:I

    iget v13, v6, Landroidx/constraintlayout/widget/ConstraintLayout;->rkYL:I

    move-object/from16 v0, p1

    move/from16 v1, p2

    move v6, v12

    move v7, v13

    move v8, v9

    move/from16 v9, v16

    invoke-virtual/range {v0 .. v9}, Lo/kw;->Zdbk(IIIIIIIII)J

    return-void
.end method

.method public setConstraintSet(Landroidx/constraintlayout/widget/wA;)V
    .locals 0

    iput-object p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->Dt:Landroidx/constraintlayout/widget/wA;

    return-void
.end method

.method public setId(I)V
    .locals 2

    iget-object v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->mjFkc:Landroid/util/SparseArray;

    invoke-virtual {p0}, Landroid/view/View;->getId()I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/util/SparseArray;->remove(I)V

    invoke-super {p0, p1}, Landroid/view/View;->setId(I)V

    iget-object p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->mjFkc:Landroid/util/SparseArray;

    invoke-virtual {p0}, Landroid/view/View;->getId()I

    move-result v0

    invoke-virtual {p1, v0, p0}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    return-void
.end method

.method public setMaxHeight(I)V
    .locals 1

    iget v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->xJ:I

    if-ne p1, v0, :cond_0

    return-void

    :cond_0
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->xJ:I

    invoke-virtual {p0}, Landroidx/constraintlayout/widget/ConstraintLayout;->requestLayout()V

    return-void
.end method

.method public setMaxWidth(I)V
    .locals 1

    iget v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->JHa:I

    if-ne p1, v0, :cond_0

    return-void

    :cond_0
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->JHa:I

    invoke-virtual {p0}, Landroidx/constraintlayout/widget/ConstraintLayout;->requestLayout()V

    return-void
.end method

.method public setMinHeight(I)V
    .locals 1

    iget v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->KLFTb:I

    if-ne p1, v0, :cond_0

    return-void

    :cond_0
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->KLFTb:I

    invoke-virtual {p0}, Landroidx/constraintlayout/widget/ConstraintLayout;->requestLayout()V

    return-void
.end method

.method public setMinWidth(I)V
    .locals 1

    iget v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->ZfxDd:I

    if-ne p1, v0, :cond_0

    return-void

    :cond_0
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->ZfxDd:I

    invoke-virtual {p0}, Landroidx/constraintlayout/widget/ConstraintLayout;->requestLayout()V

    return-void
.end method

.method public setOnConstraintsChanged(Lo/ih;)V
    .locals 0

    iget-object p0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->ETF:Lo/xVYW;

    if-eqz p0, :cond_0

    invoke-virtual {p0, p1}, Lo/xVYW;->wA(Lo/ih;)V

    :cond_0
    return-void
.end method

.method public setOptimizationLevel(I)V
    .locals 0

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->qdMbNW:I

    iget-object p0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->wA:Lo/kw;

    invoke-virtual {p0, p1}, Lo/kw;->dkKKW(I)V

    return-void
.end method

.method public shouldDelayChildPressedState()Z
    .locals 0

    const/4 p0, 0x0

    return p0
.end method

.method public wA(ZLandroid/view/View;Lo/gjvQ;Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;Landroid/util/SparseArray;)V
    .locals 18

    move-object/from16 v0, p0

    move-object/from16 v1, p2

    move-object/from16 v7, p3

    move-object/from16 v8, p4

    move-object/from16 v9, p5

    invoke-virtual/range {p4 .. p4}, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->mjFkc()V

    const/4 v10, 0x0

    iput-boolean v10, v8, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->IVlxe:Z

    invoke-virtual/range {p2 .. p2}, Landroid/view/View;->getVisibility()I

    move-result v2

    invoke-virtual {v7, v2}, Lo/gjvQ;->XtE(I)V

    iget-boolean v2, v8, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->XV:Z

    const/4 v11, 0x1

    if-eqz v2, :cond_0

    invoke-virtual {v7, v11}, Lo/gjvQ;->Moer(Z)V

    const/16 v2, 0x8

    invoke-virtual {v7, v2}, Lo/gjvQ;->XtE(I)V

    :cond_0
    invoke-virtual {v7, v1}, Lo/gjvQ;->bbzow(Ljava/lang/Object;)V

    instance-of v2, v1, Landroidx/constraintlayout/widget/AZxh;

    if-eqz v2, :cond_1

    check-cast v1, Landroidx/constraintlayout/widget/AZxh;

    iget-object v2, v0, Landroidx/constraintlayout/widget/ConstraintLayout;->wA:Lo/kw;

    invoke-virtual {v2}, Lo/kw;->dGDT()Z

    move-result v2

    invoke-virtual {v1, v7, v2}, Landroidx/constraintlayout/widget/AZxh;->lgHUyS(Lo/gjvQ;Z)V

    :cond_1
    iget-boolean v1, v8, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->nxI:Z

    const/4 v12, -0x1

    if-eqz v1, :cond_4

    move-object v0, v7

    check-cast v0, Lo/n;

    iget v1, v8, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->tQ:I

    iget v2, v8, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->yfx:I

    iget v3, v8, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->vjlshU:F

    const/high16 v4, -0x40800000    # -1.0f

    cmpl-float v4, v3, v4

    if-eqz v4, :cond_2

    invoke-virtual {v0, v3}, Lo/n;->Rc(F)V

    goto/16 :goto_9

    :cond_2
    if-eq v1, v12, :cond_3

    invoke-virtual {v0, v1}, Lo/n;->fLidf(I)V

    goto/16 :goto_9

    :cond_3
    if-eq v2, v12, :cond_1c

    invoke-virtual {v0, v2}, Lo/n;->hvGY(I)V

    goto/16 :goto_9

    :cond_4
    iget v1, v8, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->SwgkN:I

    iget v2, v8, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->JBhc:I

    iget v13, v8, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->Vdz:I

    iget v14, v8, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->jm:I

    iget v6, v8, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->ANMGZc:I

    iget v15, v8, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->alEkx:I

    iget v5, v8, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->dm:F

    iget v3, v8, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->MiMN:I

    if-eq v3, v12, :cond_5

    invoke-virtual {v9, v3}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lo/gjvQ;

    if-eqz v0, :cond_11

    iget v1, v8, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->rkYL:F

    iget v2, v8, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->YoKzxo:I

    invoke-virtual {v7, v0, v1, v2}, Lo/gjvQ;->ETF(Lo/gjvQ;FI)V

    goto/16 :goto_4

    :cond_5
    if-eq v1, v12, :cond_7

    invoke-virtual {v9, v1}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v1

    move-object v3, v1

    check-cast v3, Lo/gjvQ;

    if-eqz v3, :cond_6

    sget-object v4, Lo/qtZIjO$AZxh;->AZxh:Lo/qtZIjO$AZxh;

    iget v2, v8, Landroid/view/ViewGroup$MarginLayoutParams;->leftMargin:I

    move-object/from16 v1, p3

    move/from16 v16, v2

    move-object v2, v4

    move/from16 v17, v5

    move/from16 v5, v16

    invoke-virtual/range {v1 .. v6}, Lo/gjvQ;->KRTLGT(Lo/qtZIjO$AZxh;Lo/gjvQ;Lo/qtZIjO$AZxh;II)V

    goto :goto_0

    :cond_6
    move/from16 v17, v5

    goto :goto_0

    :cond_7
    move/from16 v17, v5

    if-eq v2, v12, :cond_8

    invoke-virtual {v9, v2}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v1

    move-object v3, v1

    check-cast v3, Lo/gjvQ;

    if-eqz v3, :cond_8

    sget-object v2, Lo/qtZIjO$AZxh;->AZxh:Lo/qtZIjO$AZxh;

    sget-object v4, Lo/qtZIjO$AZxh;->ZfxDd:Lo/qtZIjO$AZxh;

    iget v5, v8, Landroid/view/ViewGroup$MarginLayoutParams;->leftMargin:I

    move-object/from16 v1, p3

    invoke-virtual/range {v1 .. v6}, Lo/gjvQ;->KRTLGT(Lo/qtZIjO$AZxh;Lo/gjvQ;Lo/qtZIjO$AZxh;II)V

    :cond_8
    :goto_0
    if-eq v13, v12, :cond_9

    invoke-virtual {v9, v13}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v1

    move-object v3, v1

    check-cast v3, Lo/gjvQ;

    if-eqz v3, :cond_a

    sget-object v2, Lo/qtZIjO$AZxh;->ZfxDd:Lo/qtZIjO$AZxh;

    sget-object v4, Lo/qtZIjO$AZxh;->AZxh:Lo/qtZIjO$AZxh;

    iget v5, v8, Landroid/view/ViewGroup$MarginLayoutParams;->rightMargin:I

    move-object/from16 v1, p3

    move v6, v15

    invoke-virtual/range {v1 .. v6}, Lo/gjvQ;->KRTLGT(Lo/qtZIjO$AZxh;Lo/gjvQ;Lo/qtZIjO$AZxh;II)V

    goto :goto_1

    :cond_9
    if-eq v14, v12, :cond_a

    invoke-virtual {v9, v14}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v1

    move-object v3, v1

    check-cast v3, Lo/gjvQ;

    if-eqz v3, :cond_a

    sget-object v4, Lo/qtZIjO$AZxh;->ZfxDd:Lo/qtZIjO$AZxh;

    iget v5, v8, Landroid/view/ViewGroup$MarginLayoutParams;->rightMargin:I

    move-object/from16 v1, p3

    move-object v2, v4

    move v6, v15

    invoke-virtual/range {v1 .. v6}, Lo/gjvQ;->KRTLGT(Lo/qtZIjO$AZxh;Lo/gjvQ;Lo/qtZIjO$AZxh;II)V

    :cond_a
    :goto_1
    iget v1, v8, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->lgHUyS:I

    if-eq v1, v12, :cond_b

    invoke-virtual {v9, v1}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v1

    move-object v3, v1

    check-cast v3, Lo/gjvQ;

    if-eqz v3, :cond_c

    sget-object v4, Lo/qtZIjO$AZxh;->wA:Lo/qtZIjO$AZxh;

    iget v5, v8, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    iget v6, v8, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->eyqo:I

    move-object/from16 v1, p3

    move-object v2, v4

    invoke-virtual/range {v1 .. v6}, Lo/gjvQ;->KRTLGT(Lo/qtZIjO$AZxh;Lo/gjvQ;Lo/qtZIjO$AZxh;II)V

    goto :goto_2

    :cond_b
    iget v1, v8, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->qdMbNW:I

    if-eq v1, v12, :cond_c

    invoke-virtual {v9, v1}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v1

    move-object v3, v1

    check-cast v3, Lo/gjvQ;

    if-eqz v3, :cond_c

    sget-object v2, Lo/qtZIjO$AZxh;->wA:Lo/qtZIjO$AZxh;

    sget-object v4, Lo/qtZIjO$AZxh;->KLFTb:Lo/qtZIjO$AZxh;

    iget v5, v8, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    iget v6, v8, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->eyqo:I

    move-object/from16 v1, p3

    invoke-virtual/range {v1 .. v6}, Lo/gjvQ;->KRTLGT(Lo/qtZIjO$AZxh;Lo/gjvQ;Lo/qtZIjO$AZxh;II)V

    :cond_c
    :goto_2
    iget v1, v8, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->Dt:I

    if-eq v1, v12, :cond_d

    invoke-virtual {v9, v1}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v1

    move-object v3, v1

    check-cast v3, Lo/gjvQ;

    if-eqz v3, :cond_e

    sget-object v2, Lo/qtZIjO$AZxh;->KLFTb:Lo/qtZIjO$AZxh;

    sget-object v4, Lo/qtZIjO$AZxh;->wA:Lo/qtZIjO$AZxh;

    iget v5, v8, Landroid/view/ViewGroup$MarginLayoutParams;->bottomMargin:I

    iget v6, v8, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->huTpC:I

    move-object/from16 v1, p3

    invoke-virtual/range {v1 .. v6}, Lo/gjvQ;->KRTLGT(Lo/qtZIjO$AZxh;Lo/gjvQ;Lo/qtZIjO$AZxh;II)V

    goto :goto_3

    :cond_d
    iget v1, v8, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->ETF:I

    if-eq v1, v12, :cond_e

    invoke-virtual {v9, v1}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v1

    move-object v3, v1

    check-cast v3, Lo/gjvQ;

    if-eqz v3, :cond_e

    sget-object v4, Lo/qtZIjO$AZxh;->KLFTb:Lo/qtZIjO$AZxh;

    iget v5, v8, Landroid/view/ViewGroup$MarginLayoutParams;->bottomMargin:I

    iget v6, v8, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->huTpC:I

    move-object/from16 v1, p3

    move-object v2, v4

    invoke-virtual/range {v1 .. v6}, Lo/gjvQ;->KRTLGT(Lo/qtZIjO$AZxh;Lo/gjvQ;Lo/qtZIjO$AZxh;II)V

    :cond_e
    :goto_3
    iget v1, v8, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->VA:I

    if-eq v1, v12, :cond_f

    iget-object v0, v0, Landroidx/constraintlayout/widget/ConstraintLayout;->mjFkc:Landroid/util/SparseArray;

    invoke-virtual {v0, v1}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/view/View;

    iget v1, v8, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->VA:I

    invoke-virtual {v9, v1}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lo/gjvQ;

    if-eqz v1, :cond_f

    if-eqz v0, :cond_f

    invoke-virtual {v0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v2

    instance-of v2, v2, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;

    if-eqz v2, :cond_f

    invoke-virtual {v0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    check-cast v0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;

    iput-boolean v11, v8, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->JrJO:Z

    iput-boolean v11, v0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->JrJO:Z

    sget-object v2, Lo/qtZIjO$AZxh;->JHa:Lo/qtZIjO$AZxh;

    invoke-virtual {v7, v2}, Lo/gjvQ;->MiMN(Lo/qtZIjO$AZxh;)Lo/qtZIjO;

    move-result-object v3

    invoke-virtual {v1, v2}, Lo/gjvQ;->MiMN(Lo/qtZIjO$AZxh;)Lo/qtZIjO;

    move-result-object v1

    invoke-virtual {v3, v1, v10, v12, v11}, Lo/qtZIjO;->AZxh(Lo/qtZIjO;IIZ)Z

    invoke-virtual {v7, v11}, Lo/gjvQ;->jm(Z)V

    iget-object v0, v0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->xROA:Lo/gjvQ;

    invoke-virtual {v0, v11}, Lo/gjvQ;->jm(Z)V

    sget-object v0, Lo/qtZIjO$AZxh;->wA:Lo/qtZIjO$AZxh;

    invoke-virtual {v7, v0}, Lo/gjvQ;->MiMN(Lo/qtZIjO$AZxh;)Lo/qtZIjO;

    move-result-object v0

    invoke-virtual {v0}, Lo/qtZIjO;->VA()V

    sget-object v0, Lo/qtZIjO$AZxh;->KLFTb:Lo/qtZIjO$AZxh;

    invoke-virtual {v7, v0}, Lo/gjvQ;->MiMN(Lo/qtZIjO$AZxh;)Lo/qtZIjO;

    move-result-object v0

    invoke-virtual {v0}, Lo/qtZIjO;->VA()V

    :cond_f
    const/4 v0, 0x0

    move/from16 v1, v17

    cmpl-float v2, v1, v0

    if-ltz v2, :cond_10

    invoke-virtual {v7, v1}, Lo/gjvQ;->alEkx(F)V

    :cond_10
    iget v1, v8, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->VocHEe:F

    cmpl-float v0, v1, v0

    if-ltz v0, :cond_11

    invoke-virtual {v7, v1}, Lo/gjvQ;->yX(F)V

    :cond_11
    :goto_4
    if-eqz p1, :cond_13

    iget v0, v8, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->oCFDzJ:I

    if-ne v0, v12, :cond_12

    iget v1, v8, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->aqHPIZ:I

    if-eq v1, v12, :cond_13

    :cond_12
    iget v1, v8, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->aqHPIZ:I

    invoke-virtual {v7, v0, v1}, Lo/gjvQ;->kism(II)V

    :cond_13
    iget-boolean v0, v8, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->JYn:Z

    const/4 v1, -0x2

    if-nez v0, :cond_16

    iget v0, v8, Landroid/view/ViewGroup$MarginLayoutParams;->width:I

    if-ne v0, v12, :cond_15

    iget-boolean v0, v8, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->KRTLGT:Z

    if-eqz v0, :cond_14

    sget-object v0, Lo/gjvQ$AZxh;->wA:Lo/gjvQ$AZxh;

    invoke-virtual {v7, v0}, Lo/gjvQ;->yfx(Lo/gjvQ$AZxh;)V

    goto :goto_5

    :cond_14
    sget-object v0, Lo/gjvQ$AZxh;->ZfxDd:Lo/gjvQ$AZxh;

    invoke-virtual {v7, v0}, Lo/gjvQ;->yfx(Lo/gjvQ$AZxh;)V

    :goto_5
    sget-object v0, Lo/qtZIjO$AZxh;->AZxh:Lo/qtZIjO$AZxh;

    invoke-virtual {v7, v0}, Lo/gjvQ;->MiMN(Lo/qtZIjO$AZxh;)Lo/qtZIjO;

    move-result-object v0

    iget v2, v8, Landroid/view/ViewGroup$MarginLayoutParams;->leftMargin:I

    iput v2, v0, Lo/qtZIjO;->KLFTb:I

    sget-object v0, Lo/qtZIjO$AZxh;->ZfxDd:Lo/qtZIjO$AZxh;

    invoke-virtual {v7, v0}, Lo/gjvQ;->MiMN(Lo/qtZIjO$AZxh;)Lo/qtZIjO;

    move-result-object v0

    iget v2, v8, Landroid/view/ViewGroup$MarginLayoutParams;->rightMargin:I

    iput v2, v0, Lo/qtZIjO;->KLFTb:I

    goto :goto_6

    :cond_15
    sget-object v0, Lo/gjvQ$AZxh;->wA:Lo/gjvQ$AZxh;

    invoke-virtual {v7, v0}, Lo/gjvQ;->yfx(Lo/gjvQ$AZxh;)V

    invoke-virtual {v7, v10}, Lo/gjvQ;->jx(I)V

    goto :goto_6

    :cond_16
    sget-object v0, Lo/gjvQ$AZxh;->mjFkc:Lo/gjvQ$AZxh;

    invoke-virtual {v7, v0}, Lo/gjvQ;->yfx(Lo/gjvQ$AZxh;)V

    iget v0, v8, Landroid/view/ViewGroup$MarginLayoutParams;->width:I

    invoke-virtual {v7, v0}, Lo/gjvQ;->jx(I)V

    iget v0, v8, Landroid/view/ViewGroup$MarginLayoutParams;->width:I

    if-ne v0, v1, :cond_17

    sget-object v0, Lo/gjvQ$AZxh;->AZxh:Lo/gjvQ$AZxh;

    invoke-virtual {v7, v0}, Lo/gjvQ;->yfx(Lo/gjvQ$AZxh;)V

    :cond_17
    :goto_6
    iget-boolean v0, v8, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->JYgkl:Z

    if-nez v0, :cond_1a

    iget v0, v8, Landroid/view/ViewGroup$MarginLayoutParams;->height:I

    if-ne v0, v12, :cond_19

    iget-boolean v0, v8, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->GMIER:Z

    if-eqz v0, :cond_18

    sget-object v0, Lo/gjvQ$AZxh;->wA:Lo/gjvQ$AZxh;

    invoke-virtual {v7, v0}, Lo/gjvQ;->fFz(Lo/gjvQ$AZxh;)V

    goto :goto_7

    :cond_18
    sget-object v0, Lo/gjvQ$AZxh;->ZfxDd:Lo/gjvQ$AZxh;

    invoke-virtual {v7, v0}, Lo/gjvQ;->fFz(Lo/gjvQ$AZxh;)V

    :goto_7
    sget-object v0, Lo/qtZIjO$AZxh;->wA:Lo/qtZIjO$AZxh;

    invoke-virtual {v7, v0}, Lo/gjvQ;->MiMN(Lo/qtZIjO$AZxh;)Lo/qtZIjO;

    move-result-object v0

    iget v1, v8, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    iput v1, v0, Lo/qtZIjO;->KLFTb:I

    sget-object v0, Lo/qtZIjO$AZxh;->KLFTb:Lo/qtZIjO$AZxh;

    invoke-virtual {v7, v0}, Lo/gjvQ;->MiMN(Lo/qtZIjO$AZxh;)Lo/qtZIjO;

    move-result-object v0

    iget v1, v8, Landroid/view/ViewGroup$MarginLayoutParams;->bottomMargin:I

    iput v1, v0, Lo/qtZIjO;->KLFTb:I

    goto :goto_8

    :cond_19
    sget-object v0, Lo/gjvQ$AZxh;->wA:Lo/gjvQ$AZxh;

    invoke-virtual {v7, v0}, Lo/gjvQ;->fFz(Lo/gjvQ$AZxh;)V

    invoke-virtual {v7, v10}, Lo/gjvQ;->ANMGZc(I)V

    goto :goto_8

    :cond_1a
    sget-object v0, Lo/gjvQ$AZxh;->mjFkc:Lo/gjvQ$AZxh;

    invoke-virtual {v7, v0}, Lo/gjvQ;->fFz(Lo/gjvQ$AZxh;)V

    iget v0, v8, Landroid/view/ViewGroup$MarginLayoutParams;->height:I

    invoke-virtual {v7, v0}, Lo/gjvQ;->ANMGZc(I)V

    iget v0, v8, Landroid/view/ViewGroup$MarginLayoutParams;->height:I

    if-ne v0, v1, :cond_1b

    sget-object v0, Lo/gjvQ$AZxh;->AZxh:Lo/gjvQ$AZxh;

    invoke-virtual {v7, v0}, Lo/gjvQ;->fFz(Lo/gjvQ$AZxh;)V

    :cond_1b
    :goto_8
    iget-object v0, v8, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->BAnRFn:Ljava/lang/String;

    invoke-virtual {v7, v0}, Lo/gjvQ;->JBhc(Ljava/lang/String;)V

    iget v0, v8, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->mByQ:F

    invoke-virtual {v7, v0}, Lo/gjvQ;->xROA(F)V

    iget v0, v8, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->OjSQV:F

    invoke-virtual {v7, v0}, Lo/gjvQ;->XFUzSY(F)V

    iget v0, v8, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->Ne:I

    invoke-virtual {v7, v0}, Lo/gjvQ;->dm(I)V

    iget v0, v8, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->CqaNbM:I

    invoke-virtual {v7, v0}, Lo/gjvQ;->gYa(I)V

    iget v0, v8, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->xrEuO:I

    iget v1, v8, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->zvd:I

    iget v2, v8, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->rWxwaT:I

    iget v3, v8, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->NPj:F

    invoke-virtual {v7, v0, v1, v2, v3}, Lo/gjvQ;->vjlshU(IIIF)V

    iget v0, v8, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->KLMXS:I

    iget v1, v8, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->cMLeY:I

    iget v2, v8, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->Vnb:I

    iget v3, v8, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->vadzgd:F

    invoke-virtual {v7, v0, v1, v2, v3}, Lo/gjvQ;->XbiWeM(IIIF)V

    :cond_1c
    :goto_9
    return-void
.end method

.method public final xJ(I)Lo/gjvQ;
    .locals 1

    if-nez p1, :cond_0

    iget-object p0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->wA:Lo/kw;

    return-object p0

    :cond_0
    iget-object v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->mjFkc:Landroid/util/SparseArray;

    invoke-virtual {v0, p1}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/view/View;

    if-nez v0, :cond_1

    invoke-virtual {p0, p1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_1

    if-eq v0, p0, :cond_1

    invoke-virtual {v0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object p1

    if-ne p1, p0, :cond_1

    invoke-virtual {p0, v0}, Landroidx/constraintlayout/widget/ConstraintLayout;->onViewAdded(Landroid/view/View;)V

    :cond_1
    if-ne v0, p0, :cond_2

    iget-object p0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->wA:Lo/kw;

    return-object p0

    :cond_2
    if-nez v0, :cond_3

    const/4 p0, 0x0

    goto :goto_0

    :cond_3
    invoke-virtual {v0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object p0

    check-cast p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;

    iget-object p0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->xROA:Lo/gjvQ;

    :goto_0
    return-object p0
.end method
