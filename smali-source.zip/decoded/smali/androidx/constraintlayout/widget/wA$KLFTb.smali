.class public Landroidx/constraintlayout/widget/wA$KLFTb;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/constraintlayout/widget/wA;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "KLFTb"
.end annotation


# static fields
.field public static YoKzxo:Landroid/util/SparseIntArray;


# instance fields
.field public AZxh:F

.field public Dt:F

.field public ETF:F

.field public JHa:F

.field public KLFTb:F

.field public MiMN:F

.field public VA:Z

.field public ZfxDd:F

.field public lgHUyS:F

.field public mjFkc:Z

.field public qdMbNW:F

.field public wA:F

.field public xJ:F


# direct methods
.method static constructor <clinit>()V
    .locals 3

    new-instance v0, Landroid/util/SparseIntArray;

    invoke-direct {v0}, Landroid/util/SparseIntArray;-><init>()V

    sput-object v0, Landroidx/constraintlayout/widget/wA$KLFTb;->YoKzxo:Landroid/util/SparseIntArray;

    sget v1, Lo/V4;->jIShy:I

    const/4 v2, 0x1

    invoke-virtual {v0, v1, v2}, Landroid/util/SparseIntArray;->append(II)V

    sget-object v0, Landroidx/constraintlayout/widget/wA$KLFTb;->YoKzxo:Landroid/util/SparseIntArray;

    sget v1, Lo/V4;->ORe:I

    const/4 v2, 0x2

    invoke-virtual {v0, v1, v2}, Landroid/util/SparseIntArray;->append(II)V

    sget-object v0, Landroidx/constraintlayout/widget/wA$KLFTb;->YoKzxo:Landroid/util/SparseIntArray;

    sget v1, Lo/V4;->ofUPN:I

    const/4 v2, 0x3

    invoke-virtual {v0, v1, v2}, Landroid/util/SparseIntArray;->append(II)V

    sget-object v0, Landroidx/constraintlayout/widget/wA$KLFTb;->YoKzxo:Landroid/util/SparseIntArray;

    sget v1, Lo/V4;->jxC:I

    const/4 v2, 0x4

    invoke-virtual {v0, v1, v2}, Landroid/util/SparseIntArray;->append(II)V

    sget-object v0, Landroidx/constraintlayout/widget/wA$KLFTb;->YoKzxo:Landroid/util/SparseIntArray;

    sget v1, Lo/V4;->dXmy:I

    const/4 v2, 0x5

    invoke-virtual {v0, v1, v2}, Landroid/util/SparseIntArray;->append(II)V

    sget-object v0, Landroidx/constraintlayout/widget/wA$KLFTb;->YoKzxo:Landroid/util/SparseIntArray;

    sget v1, Lo/V4;->Ipwl:I

    const/4 v2, 0x6

    invoke-virtual {v0, v1, v2}, Landroid/util/SparseIntArray;->append(II)V

    sget-object v0, Landroidx/constraintlayout/widget/wA$KLFTb;->YoKzxo:Landroid/util/SparseIntArray;

    sget v1, Lo/V4;->vBFMCS:I

    const/4 v2, 0x7

    invoke-virtual {v0, v1, v2}, Landroid/util/SparseIntArray;->append(II)V

    sget-object v0, Landroidx/constraintlayout/widget/wA$KLFTb;->YoKzxo:Landroid/util/SparseIntArray;

    sget v1, Lo/V4;->ZxmHEb:I

    const/16 v2, 0x8

    invoke-virtual {v0, v1, v2}, Landroid/util/SparseIntArray;->append(II)V

    sget-object v0, Landroidx/constraintlayout/widget/wA$KLFTb;->YoKzxo:Landroid/util/SparseIntArray;

    sget v1, Lo/V4;->mYYU:I

    const/16 v2, 0x9

    invoke-virtual {v0, v1, v2}, Landroid/util/SparseIntArray;->append(II)V

    sget-object v0, Landroidx/constraintlayout/widget/wA$KLFTb;->YoKzxo:Landroid/util/SparseIntArray;

    sget v1, Lo/V4;->CBhInx:I

    const/16 v2, 0xa

    invoke-virtual {v0, v1, v2}, Landroid/util/SparseIntArray;->append(II)V

    sget-object v0, Landroidx/constraintlayout/widget/wA$KLFTb;->YoKzxo:Landroid/util/SparseIntArray;

    sget v1, Lo/V4;->vdbwS:I

    const/16 v2, 0xb

    invoke-virtual {v0, v1, v2}, Landroid/util/SparseIntArray;->append(II)V

    return-void
.end method

.method public constructor <init>()V
    .locals 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput-boolean v0, p0, Landroidx/constraintlayout/widget/wA$KLFTb;->mjFkc:Z

    const/4 v1, 0x0

    iput v1, p0, Landroidx/constraintlayout/widget/wA$KLFTb;->AZxh:F

    iput v1, p0, Landroidx/constraintlayout/widget/wA$KLFTb;->wA:F

    iput v1, p0, Landroidx/constraintlayout/widget/wA$KLFTb;->ZfxDd:F

    const/high16 v2, 0x3f800000    # 1.0f

    iput v2, p0, Landroidx/constraintlayout/widget/wA$KLFTb;->KLFTb:F

    iput v2, p0, Landroidx/constraintlayout/widget/wA$KLFTb;->JHa:F

    const/high16 v2, 0x7fc00000    # Float.NaN

    iput v2, p0, Landroidx/constraintlayout/widget/wA$KLFTb;->xJ:F

    iput v2, p0, Landroidx/constraintlayout/widget/wA$KLFTb;->lgHUyS:F

    iput v1, p0, Landroidx/constraintlayout/widget/wA$KLFTb;->qdMbNW:F

    iput v1, p0, Landroidx/constraintlayout/widget/wA$KLFTb;->Dt:F

    iput v1, p0, Landroidx/constraintlayout/widget/wA$KLFTb;->ETF:F

    iput-boolean v0, p0, Landroidx/constraintlayout/widget/wA$KLFTb;->VA:Z

    iput v1, p0, Landroidx/constraintlayout/widget/wA$KLFTb;->MiMN:F

    return-void
.end method


# virtual methods
.method public AZxh(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 4

    sget-object v0, Lo/V4;->mz:[I

    invoke-virtual {p1, p2, v0}, Landroid/content/Context;->obtainStyledAttributes(Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;

    move-result-object p1

    const/4 p2, 0x1

    iput-boolean p2, p0, Landroidx/constraintlayout/widget/wA$KLFTb;->mjFkc:Z

    invoke-virtual {p1}, Landroid/content/res/TypedArray;->getIndexCount()I

    move-result v0

    const/4 v1, 0x0

    :goto_0
    if-ge v1, v0, :cond_0

    invoke-virtual {p1, v1}, Landroid/content/res/TypedArray;->getIndex(I)I

    move-result v2

    sget-object v3, Landroidx/constraintlayout/widget/wA$KLFTb;->YoKzxo:Landroid/util/SparseIntArray;

    invoke-virtual {v3, v2}, Landroid/util/SparseIntArray;->get(I)I

    move-result v3

    packed-switch v3, :pswitch_data_0

    goto :goto_1

    :pswitch_0
    iput-boolean p2, p0, Landroidx/constraintlayout/widget/wA$KLFTb;->VA:Z

    iget v3, p0, Landroidx/constraintlayout/widget/wA$KLFTb;->MiMN:F

    invoke-virtual {p1, v2, v3}, Landroid/content/res/TypedArray;->getDimension(IF)F

    move-result v2

    iput v2, p0, Landroidx/constraintlayout/widget/wA$KLFTb;->MiMN:F

    goto :goto_1

    :pswitch_1
    iget v3, p0, Landroidx/constraintlayout/widget/wA$KLFTb;->ETF:F

    invoke-virtual {p1, v2, v3}, Landroid/content/res/TypedArray;->getDimension(IF)F

    move-result v2

    iput v2, p0, Landroidx/constraintlayout/widget/wA$KLFTb;->ETF:F

    goto :goto_1

    :pswitch_2
    iget v3, p0, Landroidx/constraintlayout/widget/wA$KLFTb;->Dt:F

    invoke-virtual {p1, v2, v3}, Landroid/content/res/TypedArray;->getDimension(IF)F

    move-result v2

    iput v2, p0, Landroidx/constraintlayout/widget/wA$KLFTb;->Dt:F

    goto :goto_1

    :pswitch_3
    iget v3, p0, Landroidx/constraintlayout/widget/wA$KLFTb;->qdMbNW:F

    invoke-virtual {p1, v2, v3}, Landroid/content/res/TypedArray;->getDimension(IF)F

    move-result v2

    iput v2, p0, Landroidx/constraintlayout/widget/wA$KLFTb;->qdMbNW:F

    goto :goto_1

    :pswitch_4
    iget v3, p0, Landroidx/constraintlayout/widget/wA$KLFTb;->lgHUyS:F

    invoke-virtual {p1, v2, v3}, Landroid/content/res/TypedArray;->getDimension(IF)F

    move-result v2

    iput v2, p0, Landroidx/constraintlayout/widget/wA$KLFTb;->lgHUyS:F

    goto :goto_1

    :pswitch_5
    iget v3, p0, Landroidx/constraintlayout/widget/wA$KLFTb;->xJ:F

    invoke-virtual {p1, v2, v3}, Landroid/content/res/TypedArray;->getDimension(IF)F

    move-result v2

    iput v2, p0, Landroidx/constraintlayout/widget/wA$KLFTb;->xJ:F

    goto :goto_1

    :pswitch_6
    iget v3, p0, Landroidx/constraintlayout/widget/wA$KLFTb;->JHa:F

    invoke-virtual {p1, v2, v3}, Landroid/content/res/TypedArray;->getFloat(IF)F

    move-result v2

    iput v2, p0, Landroidx/constraintlayout/widget/wA$KLFTb;->JHa:F

    goto :goto_1

    :pswitch_7
    iget v3, p0, Landroidx/constraintlayout/widget/wA$KLFTb;->KLFTb:F

    invoke-virtual {p1, v2, v3}, Landroid/content/res/TypedArray;->getFloat(IF)F

    move-result v2

    iput v2, p0, Landroidx/constraintlayout/widget/wA$KLFTb;->KLFTb:F

    goto :goto_1

    :pswitch_8
    iget v3, p0, Landroidx/constraintlayout/widget/wA$KLFTb;->ZfxDd:F

    invoke-virtual {p1, v2, v3}, Landroid/content/res/TypedArray;->getFloat(IF)F

    move-result v2

    iput v2, p0, Landroidx/constraintlayout/widget/wA$KLFTb;->ZfxDd:F

    goto :goto_1

    :pswitch_9
    iget v3, p0, Landroidx/constraintlayout/widget/wA$KLFTb;->wA:F

    invoke-virtual {p1, v2, v3}, Landroid/content/res/TypedArray;->getFloat(IF)F

    move-result v2

    iput v2, p0, Landroidx/constraintlayout/widget/wA$KLFTb;->wA:F

    goto :goto_1

    :pswitch_a
    iget v3, p0, Landroidx/constraintlayout/widget/wA$KLFTb;->AZxh:F

    invoke-virtual {p1, v2, v3}, Landroid/content/res/TypedArray;->getFloat(IF)F

    move-result v2

    iput v2, p0, Landroidx/constraintlayout/widget/wA$KLFTb;->AZxh:F

    :goto_1
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_0
    invoke-virtual {p1}, Landroid/content/res/TypedArray;->recycle()V

    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public mjFkc(Landroidx/constraintlayout/widget/wA$KLFTb;)V
    .locals 1

    iget-boolean v0, p1, Landroidx/constraintlayout/widget/wA$KLFTb;->mjFkc:Z

    iput-boolean v0, p0, Landroidx/constraintlayout/widget/wA$KLFTb;->mjFkc:Z

    iget v0, p1, Landroidx/constraintlayout/widget/wA$KLFTb;->AZxh:F

    iput v0, p0, Landroidx/constraintlayout/widget/wA$KLFTb;->AZxh:F

    iget v0, p1, Landroidx/constraintlayout/widget/wA$KLFTb;->wA:F

    iput v0, p0, Landroidx/constraintlayout/widget/wA$KLFTb;->wA:F

    iget v0, p1, Landroidx/constraintlayout/widget/wA$KLFTb;->ZfxDd:F

    iput v0, p0, Landroidx/constraintlayout/widget/wA$KLFTb;->ZfxDd:F

    iget v0, p1, Landroidx/constraintlayout/widget/wA$KLFTb;->KLFTb:F

    iput v0, p0, Landroidx/constraintlayout/widget/wA$KLFTb;->KLFTb:F

    iget v0, p1, Landroidx/constraintlayout/widget/wA$KLFTb;->JHa:F

    iput v0, p0, Landroidx/constraintlayout/widget/wA$KLFTb;->JHa:F

    iget v0, p1, Landroidx/constraintlayout/widget/wA$KLFTb;->xJ:F

    iput v0, p0, Landroidx/constraintlayout/widget/wA$KLFTb;->xJ:F

    iget v0, p1, Landroidx/constraintlayout/widget/wA$KLFTb;->lgHUyS:F

    iput v0, p0, Landroidx/constraintlayout/widget/wA$KLFTb;->lgHUyS:F

    iget v0, p1, Landroidx/constraintlayout/widget/wA$KLFTb;->qdMbNW:F

    iput v0, p0, Landroidx/constraintlayout/widget/wA$KLFTb;->qdMbNW:F

    iget v0, p1, Landroidx/constraintlayout/widget/wA$KLFTb;->Dt:F

    iput v0, p0, Landroidx/constraintlayout/widget/wA$KLFTb;->Dt:F

    iget v0, p1, Landroidx/constraintlayout/widget/wA$KLFTb;->ETF:F

    iput v0, p0, Landroidx/constraintlayout/widget/wA$KLFTb;->ETF:F

    iget-boolean v0, p1, Landroidx/constraintlayout/widget/wA$KLFTb;->VA:Z

    iput-boolean v0, p0, Landroidx/constraintlayout/widget/wA$KLFTb;->VA:Z

    iget p1, p1, Landroidx/constraintlayout/widget/wA$KLFTb;->MiMN:F

    iput p1, p0, Landroidx/constraintlayout/widget/wA$KLFTb;->MiMN:F

    return-void
.end method
