.class public Landroidx/constraintlayout/widget/wA$ZfxDd;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/constraintlayout/widget/wA;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "ZfxDd"
.end annotation


# instance fields
.field public AZxh:I

.field public KLFTb:F

.field public ZfxDd:F

.field public mjFkc:Z

.field public wA:I


# direct methods
.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput-boolean v0, p0, Landroidx/constraintlayout/widget/wA$ZfxDd;->mjFkc:Z

    iput v0, p0, Landroidx/constraintlayout/widget/wA$ZfxDd;->AZxh:I

    iput v0, p0, Landroidx/constraintlayout/widget/wA$ZfxDd;->wA:I

    const/high16 v0, 0x3f800000    # 1.0f

    iput v0, p0, Landroidx/constraintlayout/widget/wA$ZfxDd;->ZfxDd:F

    const/high16 v0, 0x7fc00000    # Float.NaN

    iput v0, p0, Landroidx/constraintlayout/widget/wA$ZfxDd;->KLFTb:F

    return-void
.end method


# virtual methods
.method public AZxh(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 3

    sget-object v0, Lo/V4;->mL:[I

    invoke-virtual {p1, p2, v0}, Landroid/content/Context;->obtainStyledAttributes(Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;

    move-result-object p1

    const/4 p2, 0x1

    iput-boolean p2, p0, Landroidx/constraintlayout/widget/wA$ZfxDd;->mjFkc:Z

    invoke-virtual {p1}, Landroid/content/res/TypedArray;->getIndexCount()I

    move-result p2

    const/4 v0, 0x0

    :goto_0
    if-ge v0, p2, :cond_4

    invoke-virtual {p1, v0}, Landroid/content/res/TypedArray;->getIndex(I)I

    move-result v1

    sget v2, Lo/V4;->LyQ:I

    if-ne v1, v2, :cond_0

    iget v2, p0, Landroidx/constraintlayout/widget/wA$ZfxDd;->ZfxDd:F

    invoke-virtual {p1, v1, v2}, Landroid/content/res/TypedArray;->getFloat(IF)F

    move-result v1

    iput v1, p0, Landroidx/constraintlayout/widget/wA$ZfxDd;->ZfxDd:F

    goto :goto_1

    :cond_0
    sget v2, Lo/V4;->UXIO:I

    if-ne v1, v2, :cond_1

    iget v2, p0, Landroidx/constraintlayout/widget/wA$ZfxDd;->AZxh:I

    invoke-virtual {p1, v1, v2}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v1

    iput v1, p0, Landroidx/constraintlayout/widget/wA$ZfxDd;->AZxh:I

    invoke-static {}, Landroidx/constraintlayout/widget/wA;->AZxh()[I

    move-result-object v1

    iget v2, p0, Landroidx/constraintlayout/widget/wA$ZfxDd;->AZxh:I

    aget v1, v1, v2

    iput v1, p0, Landroidx/constraintlayout/widget/wA$ZfxDd;->AZxh:I

    goto :goto_1

    :cond_1
    sget v2, Lo/V4;->rtBEoQ:I

    if-ne v1, v2, :cond_2

    iget v2, p0, Landroidx/constraintlayout/widget/wA$ZfxDd;->wA:I

    invoke-virtual {p1, v1, v2}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v1

    iput v1, p0, Landroidx/constraintlayout/widget/wA$ZfxDd;->wA:I

    goto :goto_1

    :cond_2
    sget v2, Lo/V4;->rKxis:I

    if-ne v1, v2, :cond_3

    iget v2, p0, Landroidx/constraintlayout/widget/wA$ZfxDd;->KLFTb:F

    invoke-virtual {p1, v1, v2}, Landroid/content/res/TypedArray;->getFloat(IF)F

    move-result v1

    iput v1, p0, Landroidx/constraintlayout/widget/wA$ZfxDd;->KLFTb:F

    :cond_3
    :goto_1
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_4
    invoke-virtual {p1}, Landroid/content/res/TypedArray;->recycle()V

    return-void
.end method

.method public mjFkc(Landroidx/constraintlayout/widget/wA$ZfxDd;)V
    .locals 1

    iget-boolean v0, p1, Landroidx/constraintlayout/widget/wA$ZfxDd;->mjFkc:Z

    iput-boolean v0, p0, Landroidx/constraintlayout/widget/wA$ZfxDd;->mjFkc:Z

    iget v0, p1, Landroidx/constraintlayout/widget/wA$ZfxDd;->AZxh:I

    iput v0, p0, Landroidx/constraintlayout/widget/wA$ZfxDd;->AZxh:I

    iget v0, p1, Landroidx/constraintlayout/widget/wA$ZfxDd;->ZfxDd:F

    iput v0, p0, Landroidx/constraintlayout/widget/wA$ZfxDd;->ZfxDd:F

    iget v0, p1, Landroidx/constraintlayout/widget/wA$ZfxDd;->KLFTb:F

    iput v0, p0, Landroidx/constraintlayout/widget/wA$ZfxDd;->KLFTb:F

    iget p1, p1, Landroidx/constraintlayout/widget/wA$ZfxDd;->wA:I

    iput p1, p0, Landroidx/constraintlayout/widget/wA$ZfxDd;->wA:I

    return-void
.end method
