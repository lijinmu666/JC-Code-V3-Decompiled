.class public Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;
.super Landroid/view/ViewGroup$MarginLayoutParams;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/constraintlayout/widget/ConstraintLayout;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "AZxh"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/constraintlayout/widget/ConstraintLayout$AZxh$mjFkc;
    }
.end annotation


# instance fields
.field public ANMGZc:I

.field public AZxh:I

.field public BAnRFn:Ljava/lang/String;

.field public CqaNbM:I

.field public Dt:I

.field public ETF:I

.field public GMIER:Z

.field public Gd:I

.field public HGpJ:I

.field public IEE:I

.field public IVlxe:Z

.field public JBhc:I

.field public JHa:I

.field public JYgkl:Z

.field public JYn:Z

.field public JrJO:Z

.field public KLFTb:I

.field public KLMXS:I

.field public KRTLGT:Z

.field public MiMN:I

.field public NPj:F

.field public Ne:I

.field public OjSQV:F

.field public Pq:I

.field public SwgkN:I

.field public Ucbh:I

.field public VA:I

.field public Vdz:I

.field public Vnb:I

.field public VocHEe:F

.field public WGXroI:Z

.field public WrLQs:I

.field public XV:Z

.field public YoKzxo:I

.field public ZfxDd:I

.field public alEkx:I

.field public aqHPIZ:I

.field public bbzow:Z

.field public cMLeY:I

.field public diqgf:I

.field public dm:F

.field public eyqo:I

.field public fehf:I

.field public huTpC:I

.field public jm:I

.field public lB:F

.field public lgHUyS:I

.field public mByQ:F

.field public mjFkc:I

.field public nxI:Z

.field public oCFDzJ:I

.field public qGY:I

.field public qdMbNW:I

.field public rWxwaT:I

.field public rkYL:F

.field public tQ:I

.field public uHVRx:Ljava/lang/String;

.field public vI:F

.field public vadzgd:F

.field public vjlshU:F

.field public wA:F

.field public wJVbdd:I

.field public xJ:I

.field public xROA:Lo/gjvQ;

.field public xrEuO:I

.field public yfx:I

.field public zvd:I


# direct methods
.method public constructor <init>(II)V
    .locals 4

    .line 167
    invoke-direct {p0, p1, p2}, Landroid/view/ViewGroup$MarginLayoutParams;-><init>(II)V

    const/4 p1, -0x1

    .line 168
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->mjFkc:I

    .line 169
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->AZxh:I

    const/high16 p2, -0x40800000    # -1.0f

    .line 170
    iput p2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->wA:F

    .line 171
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->ZfxDd:I

    .line 172
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->KLFTb:I

    .line 173
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->JHa:I

    .line 174
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->xJ:I

    .line 175
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->lgHUyS:I

    .line 176
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->qdMbNW:I

    .line 177
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->Dt:I

    .line 178
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->ETF:I

    .line 179
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->VA:I

    .line 180
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->MiMN:I

    const/4 v0, 0x0

    .line 181
    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->YoKzxo:I

    const/4 v1, 0x0

    .line 182
    iput v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->rkYL:F

    .line 183
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->qGY:I

    .line 184
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->fehf:I

    .line 185
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->IEE:I

    .line 186
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->Pq:I

    .line 187
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->diqgf:I

    .line 188
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->eyqo:I

    .line 189
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->Ucbh:I

    .line 190
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->huTpC:I

    .line 191
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->Gd:I

    .line 192
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->HGpJ:I

    const/high16 v2, 0x3f000000    # 0.5f

    .line 193
    iput v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->vI:F

    .line 194
    iput v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->VocHEe:F

    const/4 v3, 0x0

    .line 195
    iput-object v3, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->BAnRFn:Ljava/lang/String;

    .line 196
    iput v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->lB:F

    const/4 v1, 0x1

    .line 197
    iput v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->wJVbdd:I

    .line 198
    iput p2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->mByQ:F

    .line 199
    iput p2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->OjSQV:F

    .line 200
    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->Ne:I

    .line 201
    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->CqaNbM:I

    .line 202
    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->xrEuO:I

    .line 203
    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->KLMXS:I

    .line 204
    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->zvd:I

    .line 205
    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->cMLeY:I

    .line 206
    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->rWxwaT:I

    .line 207
    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->Vnb:I

    const/high16 p2, 0x3f800000    # 1.0f

    .line 208
    iput p2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->NPj:F

    .line 209
    iput p2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->vadzgd:F

    .line 210
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->oCFDzJ:I

    .line 211
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->aqHPIZ:I

    .line 212
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->WrLQs:I

    .line 213
    iput-boolean v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->KRTLGT:Z

    .line 214
    iput-boolean v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->GMIER:Z

    .line 215
    iput-object v3, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->uHVRx:Ljava/lang/String;

    .line 216
    iput-boolean v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->JYn:Z

    .line 217
    iput-boolean v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->JYgkl:Z

    .line 218
    iput-boolean v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->JrJO:Z

    .line 219
    iput-boolean v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->nxI:Z

    .line 220
    iput-boolean v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->WGXroI:Z

    .line 221
    iput-boolean v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->XV:Z

    .line 222
    iput-boolean v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->bbzow:Z

    .line 223
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->SwgkN:I

    .line 224
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->JBhc:I

    .line 225
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->Vdz:I

    .line 226
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->jm:I

    .line 227
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->ANMGZc:I

    .line 228
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->alEkx:I

    .line 229
    iput v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->dm:F

    .line 230
    new-instance p1, Lo/gjvQ;

    invoke-direct {p1}, Lo/gjvQ;-><init>()V

    iput-object p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->xROA:Lo/gjvQ;

    .line 231
    iput-boolean v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->IVlxe:Z

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 10

    .line 1
    invoke-direct {p0, p1, p2}, Landroid/view/ViewGroup$MarginLayoutParams;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    const/4 v0, -0x1

    .line 2
    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->mjFkc:I

    .line 3
    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->AZxh:I

    const/high16 v1, -0x40800000    # -1.0f

    .line 4
    iput v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->wA:F

    .line 5
    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->ZfxDd:I

    .line 6
    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->KLFTb:I

    .line 7
    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->JHa:I

    .line 8
    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->xJ:I

    .line 9
    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->lgHUyS:I

    .line 10
    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->qdMbNW:I

    .line 11
    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->Dt:I

    .line 12
    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->ETF:I

    .line 13
    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->VA:I

    .line 14
    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->MiMN:I

    const/4 v2, 0x0

    .line 15
    iput v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->YoKzxo:I

    const/4 v3, 0x0

    .line 16
    iput v3, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->rkYL:F

    .line 17
    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->qGY:I

    .line 18
    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->fehf:I

    .line 19
    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->IEE:I

    .line 20
    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->Pq:I

    .line 21
    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->diqgf:I

    .line 22
    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->eyqo:I

    .line 23
    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->Ucbh:I

    .line 24
    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->huTpC:I

    .line 25
    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->Gd:I

    .line 26
    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->HGpJ:I

    const/high16 v4, 0x3f000000    # 0.5f

    .line 27
    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->vI:F

    .line 28
    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->VocHEe:F

    const/4 v5, 0x0

    .line 29
    iput-object v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->BAnRFn:Ljava/lang/String;

    .line 30
    iput v3, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->lB:F

    const/4 v6, 0x1

    .line 31
    iput v6, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->wJVbdd:I

    .line 32
    iput v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->mByQ:F

    .line 33
    iput v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->OjSQV:F

    .line 34
    iput v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->Ne:I

    .line 35
    iput v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->CqaNbM:I

    .line 36
    iput v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->xrEuO:I

    .line 37
    iput v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->KLMXS:I

    .line 38
    iput v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->zvd:I

    .line 39
    iput v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->cMLeY:I

    .line 40
    iput v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->rWxwaT:I

    .line 41
    iput v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->Vnb:I

    const/high16 v1, 0x3f800000    # 1.0f

    .line 42
    iput v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->NPj:F

    .line 43
    iput v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->vadzgd:F

    .line 44
    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->oCFDzJ:I

    .line 45
    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->aqHPIZ:I

    .line 46
    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->WrLQs:I

    .line 47
    iput-boolean v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->KRTLGT:Z

    .line 48
    iput-boolean v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->GMIER:Z

    .line 49
    iput-object v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->uHVRx:Ljava/lang/String;

    .line 50
    iput-boolean v6, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->JYn:Z

    .line 51
    iput-boolean v6, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->JYgkl:Z

    .line 52
    iput-boolean v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->JrJO:Z

    .line 53
    iput-boolean v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->nxI:Z

    .line 54
    iput-boolean v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->WGXroI:Z

    .line 55
    iput-boolean v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->XV:Z

    .line 56
    iput-boolean v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->bbzow:Z

    .line 57
    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->SwgkN:I

    .line 58
    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->JBhc:I

    .line 59
    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->Vdz:I

    .line 60
    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->jm:I

    .line 61
    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->ANMGZc:I

    .line 62
    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->alEkx:I

    .line 63
    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->dm:F

    .line 64
    new-instance v1, Lo/gjvQ;

    invoke-direct {v1}, Lo/gjvQ;-><init>()V

    iput-object v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->xROA:Lo/gjvQ;

    .line 65
    iput-boolean v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->IVlxe:Z

    .line 66
    sget-object v1, Lo/V4;->dGDT:[I

    invoke-virtual {p1, p2, v1}, Landroid/content/Context;->obtainStyledAttributes(Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;

    move-result-object p1

    .line 67
    invoke-virtual {p1}, Landroid/content/res/TypedArray;->getIndexCount()I

    move-result p2

    move v1, v2

    :goto_0
    if-ge v1, p2, :cond_6

    .line 68
    invoke-virtual {p1, v1}, Landroid/content/res/TypedArray;->getIndex(I)I

    move-result v4

    .line 69
    sget-object v5, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh$mjFkc;->mjFkc:Landroid/util/SparseIntArray;

    invoke-virtual {v5, v4}, Landroid/util/SparseIntArray;->get(I)I

    move-result v5

    .line 70
    const-string v7, "ConstraintLayout"

    const/4 v8, 0x2

    const/4 v9, -0x2

    packed-switch v5, :pswitch_data_0

    packed-switch v5, :pswitch_data_1

    goto/16 :goto_3

    .line 71
    :pswitch_0
    invoke-virtual {p1, v4}, Landroid/content/res/TypedArray;->getString(I)Ljava/lang/String;

    move-result-object v4

    iput-object v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->uHVRx:Ljava/lang/String;

    goto/16 :goto_3

    .line 72
    :pswitch_1
    iget v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->aqHPIZ:I

    invoke-virtual {p1, v4, v5}, Landroid/content/res/TypedArray;->getDimensionPixelOffset(II)I

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->aqHPIZ:I

    goto/16 :goto_3

    .line 73
    :pswitch_2
    iget v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->oCFDzJ:I

    invoke-virtual {p1, v4, v5}, Landroid/content/res/TypedArray;->getDimensionPixelOffset(II)I

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->oCFDzJ:I

    goto/16 :goto_3

    .line 74
    :pswitch_3
    invoke-virtual {p1, v4, v2}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->CqaNbM:I

    goto/16 :goto_3

    .line 75
    :pswitch_4
    invoke-virtual {p1, v4, v2}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->Ne:I

    goto/16 :goto_3

    .line 76
    :pswitch_5
    iget v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->OjSQV:F

    invoke-virtual {p1, v4, v5}, Landroid/content/res/TypedArray;->getFloat(IF)F

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->OjSQV:F

    goto/16 :goto_3

    .line 77
    :pswitch_6
    iget v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->mByQ:F

    invoke-virtual {p1, v4, v5}, Landroid/content/res/TypedArray;->getFloat(IF)F

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->mByQ:F

    goto/16 :goto_3

    .line 78
    :pswitch_7
    invoke-virtual {p1, v4}, Landroid/content/res/TypedArray;->getString(I)Ljava/lang/String;

    move-result-object v4

    iput-object v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->BAnRFn:Ljava/lang/String;

    const/high16 v5, 0x7fc00000    # Float.NaN

    .line 79
    iput v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->lB:F

    .line 80
    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->wJVbdd:I

    if-eqz v4, :cond_5

    .line 81
    invoke-virtual {v4}, Ljava/lang/String;->length()I

    move-result v4

    .line 82
    iget-object v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->BAnRFn:Ljava/lang/String;

    const/16 v7, 0x2c

    invoke-virtual {v5, v7}, Ljava/lang/String;->indexOf(I)I

    move-result v5

    if-lez v5, :cond_2

    add-int/lit8 v7, v4, -0x1

    if-ge v5, v7, :cond_2

    .line 83
    iget-object v7, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->BAnRFn:Ljava/lang/String;

    invoke-virtual {v7, v2, v5}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v7

    .line 84
    const-string v8, "W"

    invoke-virtual {v7, v8}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v8

    if-eqz v8, :cond_0

    .line 85
    iput v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->wJVbdd:I

    goto :goto_1

    .line 86
    :cond_0
    const-string v8, "H"

    invoke-virtual {v7, v8}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v7

    if-eqz v7, :cond_1

    .line 87
    iput v6, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->wJVbdd:I

    :cond_1
    :goto_1
    add-int/lit8 v5, v5, 0x1

    goto :goto_2

    :cond_2
    move v5, v2

    .line 88
    :goto_2
    iget-object v7, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->BAnRFn:Ljava/lang/String;

    const/16 v8, 0x3a

    invoke-virtual {v7, v8}, Ljava/lang/String;->indexOf(I)I

    move-result v7

    if-ltz v7, :cond_4

    add-int/lit8 v4, v4, -0x1

    if-ge v7, v4, :cond_4

    .line 89
    iget-object v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->BAnRFn:Ljava/lang/String;

    invoke-virtual {v4, v5, v7}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v4

    .line 90
    iget-object v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->BAnRFn:Ljava/lang/String;

    add-int/lit8 v7, v7, 0x1

    invoke-virtual {v5, v7}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v5

    .line 91
    invoke-virtual {v4}, Ljava/lang/String;->length()I

    move-result v7

    if-lez v7, :cond_5

    invoke-virtual {v5}, Ljava/lang/String;->length()I

    move-result v7

    if-lez v7, :cond_5

    .line 92
    :try_start_0
    invoke-static {v4}, Ljava/lang/Float;->parseFloat(Ljava/lang/String;)F

    move-result v4

    .line 93
    invoke-static {v5}, Ljava/lang/Float;->parseFloat(Ljava/lang/String;)F

    move-result v5

    cmpl-float v7, v4, v3

    if-lez v7, :cond_5

    cmpl-float v7, v5, v3

    if-lez v7, :cond_5

    .line 94
    iget v7, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->wJVbdd:I

    if-ne v7, v6, :cond_3

    div-float/2addr v5, v4

    .line 95
    invoke-static {v5}, Ljava/lang/Math;->abs(F)F

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->lB:F

    goto/16 :goto_3

    :cond_3
    div-float/2addr v4, v5

    .line 96
    invoke-static {v4}, Ljava/lang/Math;->abs(F)F

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->lB:F
    :try_end_0
    .catch Ljava/lang/NumberFormatException; {:try_start_0 .. :try_end_0} :catch_4

    goto/16 :goto_3

    .line 97
    :cond_4
    iget-object v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->BAnRFn:Ljava/lang/String;

    invoke-virtual {v4, v5}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v4

    .line 98
    invoke-virtual {v4}, Ljava/lang/String;->length()I

    move-result v5

    if-lez v5, :cond_5

    .line 99
    :try_start_1
    invoke-static {v4}, Ljava/lang/Float;->parseFloat(Ljava/lang/String;)F

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->lB:F
    :try_end_1
    .catch Ljava/lang/NumberFormatException; {:try_start_1 .. :try_end_1} :catch_4

    goto/16 :goto_3

    .line 100
    :pswitch_8
    iget v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->vadzgd:F

    invoke-virtual {p1, v4, v5}, Landroid/content/res/TypedArray;->getFloat(IF)F

    move-result v4

    invoke-static {v3, v4}, Ljava/lang/Math;->max(FF)F

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->vadzgd:F

    .line 101
    iput v8, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->KLMXS:I

    goto/16 :goto_3

    .line 102
    :pswitch_9
    :try_start_2
    iget v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->Vnb:I

    invoke-virtual {p1, v4, v5}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v5

    iput v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->Vnb:I
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0

    goto/16 :goto_3

    .line 103
    :catch_0
    iget v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->Vnb:I

    invoke-virtual {p1, v4, v5}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v4

    if-ne v4, v9, :cond_5

    .line 104
    iput v9, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->Vnb:I

    goto/16 :goto_3

    .line 105
    :pswitch_a
    :try_start_3
    iget v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->cMLeY:I

    invoke-virtual {p1, v4, v5}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v5

    iput v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->cMLeY:I
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_1

    goto/16 :goto_3

    .line 106
    :catch_1
    iget v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->cMLeY:I

    invoke-virtual {p1, v4, v5}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v4

    if-ne v4, v9, :cond_5

    .line 107
    iput v9, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->cMLeY:I

    goto/16 :goto_3

    .line 108
    :pswitch_b
    iget v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->NPj:F

    invoke-virtual {p1, v4, v5}, Landroid/content/res/TypedArray;->getFloat(IF)F

    move-result v4

    invoke-static {v3, v4}, Ljava/lang/Math;->max(FF)F

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->NPj:F

    .line 109
    iput v8, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->xrEuO:I

    goto/16 :goto_3

    .line 110
    :pswitch_c
    :try_start_4
    iget v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->rWxwaT:I

    invoke-virtual {p1, v4, v5}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v5

    iput v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->rWxwaT:I
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_2

    goto/16 :goto_3

    .line 111
    :catch_2
    iget v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->rWxwaT:I

    invoke-virtual {p1, v4, v5}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v4

    if-ne v4, v9, :cond_5

    .line 112
    iput v9, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->rWxwaT:I

    goto/16 :goto_3

    .line 113
    :pswitch_d
    :try_start_5
    iget v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->zvd:I

    invoke-virtual {p1, v4, v5}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v5

    iput v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->zvd:I
    :try_end_5
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_5} :catch_3

    goto/16 :goto_3

    .line 114
    :catch_3
    iget v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->zvd:I

    invoke-virtual {p1, v4, v5}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v4

    if-ne v4, v9, :cond_5

    .line 115
    iput v9, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->zvd:I

    goto/16 :goto_3

    .line 116
    :pswitch_e
    invoke-virtual {p1, v4, v2}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->KLMXS:I

    if-ne v4, v6, :cond_5

    .line 117
    const-string v4, "layout_constraintHeight_default=\"wrap\" is deprecated.\nUse layout_height=\"WRAP_CONTENT\" and layout_constrainedHeight=\"true\" instead."

    invoke-static {v7, v4}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    goto/16 :goto_3

    .line 118
    :pswitch_f
    invoke-virtual {p1, v4, v2}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->xrEuO:I

    if-ne v4, v6, :cond_5

    .line 119
    const-string v4, "layout_constraintWidth_default=\"wrap\" is deprecated.\nUse layout_width=\"WRAP_CONTENT\" and layout_constrainedWidth=\"true\" instead."

    invoke-static {v7, v4}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    goto/16 :goto_3

    .line 120
    :pswitch_10
    iget v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->VocHEe:F

    invoke-virtual {p1, v4, v5}, Landroid/content/res/TypedArray;->getFloat(IF)F

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->VocHEe:F

    goto/16 :goto_3

    .line 121
    :pswitch_11
    iget v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->vI:F

    invoke-virtual {p1, v4, v5}, Landroid/content/res/TypedArray;->getFloat(IF)F

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->vI:F

    goto/16 :goto_3

    .line 122
    :pswitch_12
    iget-boolean v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->GMIER:Z

    invoke-virtual {p1, v4, v5}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result v4

    iput-boolean v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->GMIER:Z

    goto/16 :goto_3

    .line 123
    :pswitch_13
    iget-boolean v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->KRTLGT:Z

    invoke-virtual {p1, v4, v5}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result v4

    iput-boolean v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->KRTLGT:Z

    goto/16 :goto_3

    .line 124
    :pswitch_14
    iget v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->HGpJ:I

    invoke-virtual {p1, v4, v5}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->HGpJ:I

    goto/16 :goto_3

    .line 125
    :pswitch_15
    iget v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->Gd:I

    invoke-virtual {p1, v4, v5}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->Gd:I

    goto/16 :goto_3

    .line 126
    :pswitch_16
    iget v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->huTpC:I

    invoke-virtual {p1, v4, v5}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->huTpC:I

    goto/16 :goto_3

    .line 127
    :pswitch_17
    iget v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->Ucbh:I

    invoke-virtual {p1, v4, v5}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->Ucbh:I

    goto/16 :goto_3

    .line 128
    :pswitch_18
    iget v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->eyqo:I

    invoke-virtual {p1, v4, v5}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->eyqo:I

    goto/16 :goto_3

    .line 129
    :pswitch_19
    iget v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->diqgf:I

    invoke-virtual {p1, v4, v5}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->diqgf:I

    goto/16 :goto_3

    .line 130
    :pswitch_1a
    iget v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->Pq:I

    invoke-virtual {p1, v4, v5}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v5

    iput v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->Pq:I

    if-ne v5, v0, :cond_5

    .line 131
    invoke-virtual {p1, v4, v0}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->Pq:I

    goto/16 :goto_3

    .line 132
    :pswitch_1b
    iget v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->IEE:I

    invoke-virtual {p1, v4, v5}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v5

    iput v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->IEE:I

    if-ne v5, v0, :cond_5

    .line 133
    invoke-virtual {p1, v4, v0}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->IEE:I

    goto/16 :goto_3

    .line 134
    :pswitch_1c
    iget v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->fehf:I

    invoke-virtual {p1, v4, v5}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v5

    iput v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->fehf:I

    if-ne v5, v0, :cond_5

    .line 135
    invoke-virtual {p1, v4, v0}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->fehf:I

    goto/16 :goto_3

    .line 136
    :pswitch_1d
    iget v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->qGY:I

    invoke-virtual {p1, v4, v5}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v5

    iput v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->qGY:I

    if-ne v5, v0, :cond_5

    .line 137
    invoke-virtual {p1, v4, v0}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->qGY:I

    goto/16 :goto_3

    .line 138
    :pswitch_1e
    iget v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->VA:I

    invoke-virtual {p1, v4, v5}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v5

    iput v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->VA:I

    if-ne v5, v0, :cond_5

    .line 139
    invoke-virtual {p1, v4, v0}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->VA:I

    goto/16 :goto_3

    .line 140
    :pswitch_1f
    iget v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->ETF:I

    invoke-virtual {p1, v4, v5}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v5

    iput v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->ETF:I

    if-ne v5, v0, :cond_5

    .line 141
    invoke-virtual {p1, v4, v0}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->ETF:I

    goto/16 :goto_3

    .line 142
    :pswitch_20
    iget v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->Dt:I

    invoke-virtual {p1, v4, v5}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v5

    iput v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->Dt:I

    if-ne v5, v0, :cond_5

    .line 143
    invoke-virtual {p1, v4, v0}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->Dt:I

    goto/16 :goto_3

    .line 144
    :pswitch_21
    iget v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->qdMbNW:I

    invoke-virtual {p1, v4, v5}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v5

    iput v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->qdMbNW:I

    if-ne v5, v0, :cond_5

    .line 145
    invoke-virtual {p1, v4, v0}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->qdMbNW:I

    goto/16 :goto_3

    .line 146
    :pswitch_22
    iget v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->lgHUyS:I

    invoke-virtual {p1, v4, v5}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v5

    iput v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->lgHUyS:I

    if-ne v5, v0, :cond_5

    .line 147
    invoke-virtual {p1, v4, v0}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->lgHUyS:I

    goto/16 :goto_3

    .line 148
    :pswitch_23
    iget v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->xJ:I

    invoke-virtual {p1, v4, v5}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v5

    iput v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->xJ:I

    if-ne v5, v0, :cond_5

    .line 149
    invoke-virtual {p1, v4, v0}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->xJ:I

    goto/16 :goto_3

    .line 150
    :pswitch_24
    iget v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->JHa:I

    invoke-virtual {p1, v4, v5}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v5

    iput v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->JHa:I

    if-ne v5, v0, :cond_5

    .line 151
    invoke-virtual {p1, v4, v0}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->JHa:I

    goto/16 :goto_3

    .line 152
    :pswitch_25
    iget v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->KLFTb:I

    invoke-virtual {p1, v4, v5}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v5

    iput v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->KLFTb:I

    if-ne v5, v0, :cond_5

    .line 153
    invoke-virtual {p1, v4, v0}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->KLFTb:I

    goto :goto_3

    .line 154
    :pswitch_26
    iget v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->ZfxDd:I

    invoke-virtual {p1, v4, v5}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v5

    iput v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->ZfxDd:I

    if-ne v5, v0, :cond_5

    .line 155
    invoke-virtual {p1, v4, v0}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->ZfxDd:I

    goto :goto_3

    .line 156
    :pswitch_27
    iget v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->wA:F

    invoke-virtual {p1, v4, v5}, Landroid/content/res/TypedArray;->getFloat(IF)F

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->wA:F

    goto :goto_3

    .line 157
    :pswitch_28
    iget v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->AZxh:I

    invoke-virtual {p1, v4, v5}, Landroid/content/res/TypedArray;->getDimensionPixelOffset(II)I

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->AZxh:I

    goto :goto_3

    .line 158
    :pswitch_29
    iget v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->mjFkc:I

    invoke-virtual {p1, v4, v5}, Landroid/content/res/TypedArray;->getDimensionPixelOffset(II)I

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->mjFkc:I

    goto :goto_3

    .line 159
    :pswitch_2a
    iget v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->rkYL:F

    invoke-virtual {p1, v4, v5}, Landroid/content/res/TypedArray;->getFloat(IF)F

    move-result v4

    const/high16 v5, 0x43b40000    # 360.0f

    rem-float/2addr v4, v5

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->rkYL:F

    cmpg-float v7, v4, v3

    if-gez v7, :cond_5

    sub-float v4, v5, v4

    rem-float/2addr v4, v5

    .line 160
    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->rkYL:F

    goto :goto_3

    .line 161
    :pswitch_2b
    iget v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->YoKzxo:I

    invoke-virtual {p1, v4, v5}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->YoKzxo:I

    goto :goto_3

    .line 162
    :pswitch_2c
    iget v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->MiMN:I

    invoke-virtual {p1, v4, v5}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v5

    iput v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->MiMN:I

    if-ne v5, v0, :cond_5

    .line 163
    invoke-virtual {p1, v4, v0}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->MiMN:I

    goto :goto_3

    .line 164
    :pswitch_2d
    iget v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->WrLQs:I

    invoke-virtual {p1, v4, v5}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->WrLQs:I

    :catch_4
    :cond_5
    :goto_3
    add-int/lit8 v1, v1, 0x1

    goto/16 :goto_0

    .line 165
    :cond_6
    invoke-virtual {p1}, Landroid/content/res/TypedArray;->recycle()V

    .line 166
    invoke-virtual {p0}, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->mjFkc()V

    return-void

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_2d
        :pswitch_2c
        :pswitch_2b
        :pswitch_2a
        :pswitch_29
        :pswitch_28
        :pswitch_27
        :pswitch_26
        :pswitch_25
        :pswitch_24
        :pswitch_23
        :pswitch_22
        :pswitch_21
        :pswitch_20
        :pswitch_1f
        :pswitch_1e
        :pswitch_1d
        :pswitch_1c
        :pswitch_1b
        :pswitch_1a
        :pswitch_19
        :pswitch_18
        :pswitch_17
        :pswitch_16
        :pswitch_15
        :pswitch_14
        :pswitch_13
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
    .end packed-switch

    :pswitch_data_1
    .packed-switch 0x2c
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public constructor <init>(Landroid/view/ViewGroup$LayoutParams;)V
    .locals 5

    .line 232
    invoke-direct {p0, p1}, Landroid/view/ViewGroup$MarginLayoutParams;-><init>(Landroid/view/ViewGroup$LayoutParams;)V

    const/4 p1, -0x1

    .line 233
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->mjFkc:I

    .line 234
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->AZxh:I

    const/high16 v0, -0x40800000    # -1.0f

    .line 235
    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->wA:F

    .line 236
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->ZfxDd:I

    .line 237
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->KLFTb:I

    .line 238
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->JHa:I

    .line 239
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->xJ:I

    .line 240
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->lgHUyS:I

    .line 241
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->qdMbNW:I

    .line 242
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->Dt:I

    .line 243
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->ETF:I

    .line 244
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->VA:I

    .line 245
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->MiMN:I

    const/4 v1, 0x0

    .line 246
    iput v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->YoKzxo:I

    const/4 v2, 0x0

    .line 247
    iput v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->rkYL:F

    .line 248
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->qGY:I

    .line 249
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->fehf:I

    .line 250
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->IEE:I

    .line 251
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->Pq:I

    .line 252
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->diqgf:I

    .line 253
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->eyqo:I

    .line 254
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->Ucbh:I

    .line 255
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->huTpC:I

    .line 256
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->Gd:I

    .line 257
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->HGpJ:I

    const/high16 v3, 0x3f000000    # 0.5f

    .line 258
    iput v3, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->vI:F

    .line 259
    iput v3, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->VocHEe:F

    const/4 v4, 0x0

    .line 260
    iput-object v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->BAnRFn:Ljava/lang/String;

    .line 261
    iput v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->lB:F

    const/4 v2, 0x1

    .line 262
    iput v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->wJVbdd:I

    .line 263
    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->mByQ:F

    .line 264
    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->OjSQV:F

    .line 265
    iput v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->Ne:I

    .line 266
    iput v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->CqaNbM:I

    .line 267
    iput v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->xrEuO:I

    .line 268
    iput v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->KLMXS:I

    .line 269
    iput v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->zvd:I

    .line 270
    iput v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->cMLeY:I

    .line 271
    iput v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->rWxwaT:I

    .line 272
    iput v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->Vnb:I

    const/high16 v0, 0x3f800000    # 1.0f

    .line 273
    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->NPj:F

    .line 274
    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->vadzgd:F

    .line 275
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->oCFDzJ:I

    .line 276
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->aqHPIZ:I

    .line 277
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->WrLQs:I

    .line 278
    iput-boolean v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->KRTLGT:Z

    .line 279
    iput-boolean v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->GMIER:Z

    .line 280
    iput-object v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->uHVRx:Ljava/lang/String;

    .line 281
    iput-boolean v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->JYn:Z

    .line 282
    iput-boolean v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->JYgkl:Z

    .line 283
    iput-boolean v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->JrJO:Z

    .line 284
    iput-boolean v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->nxI:Z

    .line 285
    iput-boolean v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->WGXroI:Z

    .line 286
    iput-boolean v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->XV:Z

    .line 287
    iput-boolean v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->bbzow:Z

    .line 288
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->SwgkN:I

    .line 289
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->JBhc:I

    .line 290
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->Vdz:I

    .line 291
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->jm:I

    .line 292
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->ANMGZc:I

    .line 293
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->alEkx:I

    .line 294
    iput v3, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->dm:F

    .line 295
    new-instance p1, Lo/gjvQ;

    invoke-direct {p1}, Lo/gjvQ;-><init>()V

    iput-object p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->xROA:Lo/gjvQ;

    .line 296
    iput-boolean v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->IVlxe:Z

    return-void
.end method


# virtual methods
.method public mjFkc()V
    .locals 6

    const/4 v0, 0x0

    iput-boolean v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->nxI:Z

    const/4 v1, 0x1

    iput-boolean v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->JYn:Z

    iput-boolean v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->JYgkl:Z

    iget v2, p0, Landroid/view/ViewGroup$MarginLayoutParams;->width:I

    const/4 v3, -0x2

    if-ne v2, v3, :cond_0

    iget-boolean v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->KRTLGT:Z

    if-eqz v4, :cond_0

    iput-boolean v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->JYn:Z

    iget v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->xrEuO:I

    if-nez v4, :cond_0

    iput v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->xrEuO:I

    :cond_0
    iget v4, p0, Landroid/view/ViewGroup$MarginLayoutParams;->height:I

    if-ne v4, v3, :cond_1

    iget-boolean v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->GMIER:Z

    if-eqz v5, :cond_1

    iput-boolean v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->JYgkl:Z

    iget v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->KLMXS:I

    if-nez v5, :cond_1

    iput v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->KLMXS:I

    :cond_1
    const/4 v5, -0x1

    if-eqz v2, :cond_2

    if-ne v2, v5, :cond_3

    :cond_2
    iput-boolean v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->JYn:Z

    if-nez v2, :cond_3

    iget v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->xrEuO:I

    if-ne v2, v1, :cond_3

    iput v3, p0, Landroid/view/ViewGroup$MarginLayoutParams;->width:I

    iput-boolean v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->KRTLGT:Z

    :cond_3
    if-eqz v4, :cond_4

    if-ne v4, v5, :cond_5

    :cond_4
    iput-boolean v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->JYgkl:Z

    if-nez v4, :cond_5

    iget v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->KLMXS:I

    if-ne v0, v1, :cond_5

    iput v3, p0, Landroid/view/ViewGroup$MarginLayoutParams;->height:I

    iput-boolean v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->GMIER:Z

    :cond_5
    iget v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->wA:F

    const/high16 v2, -0x40800000    # -1.0f

    cmpl-float v0, v0, v2

    if-nez v0, :cond_6

    iget v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->mjFkc:I

    if-ne v0, v5, :cond_6

    iget v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->AZxh:I

    if-eq v0, v5, :cond_8

    :cond_6
    iput-boolean v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->nxI:Z

    iput-boolean v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->JYn:Z

    iput-boolean v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->JYgkl:Z

    iget-object v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->xROA:Lo/gjvQ;

    instance-of v0, v0, Lo/n;

    if-nez v0, :cond_7

    new-instance v0, Lo/n;

    invoke-direct {v0}, Lo/n;-><init>()V

    iput-object v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->xROA:Lo/gjvQ;

    :cond_7
    iget-object v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->xROA:Lo/gjvQ;

    check-cast v0, Lo/n;

    iget p0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->WrLQs:I

    invoke-virtual {v0, p0}, Lo/n;->SKTn(I)V

    :cond_8
    return-void
.end method

.method public resolveLayoutDirection(I)V
    .locals 9

    iget v0, p0, Landroid/view/ViewGroup$MarginLayoutParams;->leftMargin:I

    iget v1, p0, Landroid/view/ViewGroup$MarginLayoutParams;->rightMargin:I

    invoke-super {p0, p1}, Landroid/view/ViewGroup$MarginLayoutParams;->resolveLayoutDirection(I)V

    invoke-virtual {p0}, Landroid/view/ViewGroup$MarginLayoutParams;->getLayoutDirection()I

    move-result p1

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-ne v3, p1, :cond_0

    move p1, v3

    goto :goto_0

    :cond_0
    move p1, v2

    :goto_0
    const/4 v4, -0x1

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->Vdz:I

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->jm:I

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->SwgkN:I

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->JBhc:I

    iget v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->diqgf:I

    iput v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->ANMGZc:I

    iget v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->Ucbh:I

    iput v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->alEkx:I

    iget v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->vI:F

    iput v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->dm:F

    iget v6, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->mjFkc:I

    iput v6, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->tQ:I

    iget v7, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->AZxh:I

    iput v7, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->yfx:I

    iget v8, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->wA:F

    iput v8, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->vjlshU:F

    if-eqz p1, :cond_a

    iget p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->qGY:I

    if-eq p1, v4, :cond_1

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->Vdz:I

    :goto_1
    move v2, v3

    goto :goto_2

    :cond_1
    iget p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->fehf:I

    if-eq p1, v4, :cond_2

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->jm:I

    goto :goto_1

    :cond_2
    :goto_2
    iget p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->IEE:I

    if-eq p1, v4, :cond_3

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->JBhc:I

    move v2, v3

    :cond_3
    iget p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->Pq:I

    if-eq p1, v4, :cond_4

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->SwgkN:I

    move v2, v3

    :cond_4
    iget p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->Gd:I

    if-eq p1, v4, :cond_5

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->alEkx:I

    :cond_5
    iget p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->HGpJ:I

    if-eq p1, v4, :cond_6

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->ANMGZc:I

    :cond_6
    const/high16 p1, 0x3f800000    # 1.0f

    if-eqz v2, :cond_7

    sub-float v2, p1, v5

    iput v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->dm:F

    :cond_7
    iget-boolean v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->nxI:Z

    if-eqz v2, :cond_10

    iget v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->WrLQs:I

    if-ne v2, v3, :cond_10

    const/high16 v2, -0x40800000    # -1.0f

    cmpl-float v3, v8, v2

    if-eqz v3, :cond_8

    sub-float/2addr p1, v8

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->vjlshU:F

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->tQ:I

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->yfx:I

    goto :goto_3

    :cond_8
    if-eq v6, v4, :cond_9

    iput v6, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->yfx:I

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->tQ:I

    iput v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->vjlshU:F

    goto :goto_3

    :cond_9
    if-eq v7, v4, :cond_10

    iput v7, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->tQ:I

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->yfx:I

    iput v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->vjlshU:F

    goto :goto_3

    :cond_a
    iget p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->qGY:I

    if-eq p1, v4, :cond_b

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->JBhc:I

    :cond_b
    iget p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->fehf:I

    if-eq p1, v4, :cond_c

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->SwgkN:I

    :cond_c
    iget p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->IEE:I

    if-eq p1, v4, :cond_d

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->Vdz:I

    :cond_d
    iget p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->Pq:I

    if-eq p1, v4, :cond_e

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->jm:I

    :cond_e
    iget p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->Gd:I

    if-eq p1, v4, :cond_f

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->ANMGZc:I

    :cond_f
    iget p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->HGpJ:I

    if-eq p1, v4, :cond_10

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->alEkx:I

    :cond_10
    :goto_3
    iget p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->IEE:I

    if-ne p1, v4, :cond_14

    iget p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->Pq:I

    if-ne p1, v4, :cond_14

    iget p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->fehf:I

    if-ne p1, v4, :cond_14

    iget p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->qGY:I

    if-ne p1, v4, :cond_14

    iget p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->JHa:I

    if-eq p1, v4, :cond_11

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->Vdz:I

    iget p1, p0, Landroid/view/ViewGroup$MarginLayoutParams;->rightMargin:I

    if-gtz p1, :cond_12

    if-lez v1, :cond_12

    iput v1, p0, Landroid/view/ViewGroup$MarginLayoutParams;->rightMargin:I

    goto :goto_4

    :cond_11
    iget p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->xJ:I

    if-eq p1, v4, :cond_12

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->jm:I

    iget p1, p0, Landroid/view/ViewGroup$MarginLayoutParams;->rightMargin:I

    if-gtz p1, :cond_12

    if-lez v1, :cond_12

    iput v1, p0, Landroid/view/ViewGroup$MarginLayoutParams;->rightMargin:I

    :cond_12
    :goto_4
    iget p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->ZfxDd:I

    if-eq p1, v4, :cond_13

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->SwgkN:I

    iget p1, p0, Landroid/view/ViewGroup$MarginLayoutParams;->leftMargin:I

    if-gtz p1, :cond_14

    if-lez v0, :cond_14

    iput v0, p0, Landroid/view/ViewGroup$MarginLayoutParams;->leftMargin:I

    goto :goto_5

    :cond_13
    iget p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->KLFTb:I

    if-eq p1, v4, :cond_14

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$AZxh;->JBhc:I

    iget p1, p0, Landroid/view/ViewGroup$MarginLayoutParams;->leftMargin:I

    if-gtz p1, :cond_14

    if-lez v0, :cond_14

    iput v0, p0, Landroid/view/ViewGroup$MarginLayoutParams;->leftMargin:I

    :cond_14
    :goto_5
    return-void
.end method
