.class public Landroidx/constraintlayout/widget/Barrier;
.super Landroidx/constraintlayout/widget/AZxh;
.source "SourceFile"


# instance fields
.field public Dt:I

.field public ETF:Lo/Jk;

.field public qdMbNW:I


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 0

    .line 1
    invoke-direct {p0, p1}, Landroidx/constraintlayout/widget/AZxh;-><init>(Landroid/content/Context;)V

    const/16 p1, 0x8

    .line 2
    invoke-super {p0, p1}, Landroid/view/View;->setVisibility(I)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 0

    .line 3
    invoke-direct {p0, p1, p2}, Landroidx/constraintlayout/widget/AZxh;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    const/16 p1, 0x8

    .line 4
    invoke-super {p0, p1}, Landroid/view/View;->setVisibility(I)V

    return-void
.end method


# virtual methods
.method public YoKzxo()Z
    .locals 0

    iget-object p0, p0, Landroidx/constraintlayout/widget/Barrier;->ETF:Lo/Jk;

    invoke-virtual {p0}, Lo/Jk;->sRqPfw()Z

    move-result p0

    return p0
.end method

.method public getMargin()I
    .locals 0

    iget-object p0, p0, Landroidx/constraintlayout/widget/Barrier;->ETF:Lo/Jk;

    invoke-virtual {p0}, Lo/Jk;->gtr()I

    move-result p0

    return p0
.end method

.method public getType()I
    .locals 0

    iget p0, p0, Landroidx/constraintlayout/widget/Barrier;->qdMbNW:I

    return p0
.end method

.method public lgHUyS(Lo/gjvQ;Z)V
    .locals 1

    iget v0, p0, Landroidx/constraintlayout/widget/Barrier;->qdMbNW:I

    invoke-virtual {p0, p1, v0, p2}, Landroidx/constraintlayout/widget/Barrier;->rkYL(Lo/gjvQ;IZ)V

    return-void
.end method

.method public final rkYL(Lo/gjvQ;IZ)V
    .locals 3

    iput p2, p0, Landroidx/constraintlayout/widget/Barrier;->Dt:I

    const/4 p2, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x5

    if-eqz p3, :cond_1

    iget p3, p0, Landroidx/constraintlayout/widget/Barrier;->qdMbNW:I

    if-ne p3, v2, :cond_0

    iput v1, p0, Landroidx/constraintlayout/widget/Barrier;->Dt:I

    goto :goto_0

    :cond_0
    if-ne p3, v0, :cond_3

    iput p2, p0, Landroidx/constraintlayout/widget/Barrier;->Dt:I

    goto :goto_0

    :cond_1
    iget p3, p0, Landroidx/constraintlayout/widget/Barrier;->qdMbNW:I

    if-ne p3, v2, :cond_2

    iput p2, p0, Landroidx/constraintlayout/widget/Barrier;->Dt:I

    goto :goto_0

    :cond_2
    if-ne p3, v0, :cond_3

    iput v1, p0, Landroidx/constraintlayout/widget/Barrier;->Dt:I

    :cond_3
    :goto_0
    instance-of p2, p1, Lo/Jk;

    if-eqz p2, :cond_4

    check-cast p1, Lo/Jk;

    iget p0, p0, Landroidx/constraintlayout/widget/Barrier;->Dt:I

    invoke-virtual {p1, p0}, Lo/Jk;->hvGY(I)V

    :cond_4
    return-void
.end method

.method public setAllowsGoneWidget(Z)V
    .locals 0

    iget-object p0, p0, Landroidx/constraintlayout/widget/Barrier;->ETF:Lo/Jk;

    invoke-virtual {p0, p1}, Lo/Jk;->fLidf(Z)V

    return-void
.end method

.method public setDpMargin(I)V
    .locals 1

    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v0

    iget v0, v0, Landroid/util/DisplayMetrics;->density:F

    int-to-float p1, p1

    mul-float/2addr p1, v0

    const/high16 v0, 0x3f000000    # 0.5f

    add-float/2addr p1, v0

    float-to-int p1, p1

    iget-object p0, p0, Landroidx/constraintlayout/widget/Barrier;->ETF:Lo/Jk;

    invoke-virtual {p0, p1}, Lo/Jk;->Rc(I)V

    return-void
.end method

.method public setMargin(I)V
    .locals 0

    iget-object p0, p0, Landroidx/constraintlayout/widget/Barrier;->ETF:Lo/Jk;

    invoke-virtual {p0, p1}, Lo/Jk;->Rc(I)V

    return-void
.end method

.method public setType(I)V
    .locals 0

    iput p1, p0, Landroidx/constraintlayout/widget/Barrier;->qdMbNW:I

    return-void
.end method

.method public xJ(Landroid/util/AttributeSet;)V
    .locals 6

    invoke-super {p0, p1}, Landroidx/constraintlayout/widget/AZxh;->xJ(Landroid/util/AttributeSet;)V

    new-instance v0, Lo/Jk;

    invoke-direct {v0}, Lo/Jk;-><init>()V

    iput-object v0, p0, Landroidx/constraintlayout/widget/Barrier;->ETF:Lo/Jk;

    if-eqz p1, :cond_3

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    sget-object v1, Lo/V4;->dGDT:[I

    invoke-virtual {v0, p1, v1}, Landroid/content/Context;->obtainStyledAttributes(Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;

    move-result-object p1

    invoke-virtual {p1}, Landroid/content/res/TypedArray;->getIndexCount()I

    move-result v0

    const/4 v1, 0x0

    move v2, v1

    :goto_0
    if-ge v2, v0, :cond_3

    invoke-virtual {p1, v2}, Landroid/content/res/TypedArray;->getIndex(I)I

    move-result v3

    sget v4, Lo/V4;->Vu:I

    if-ne v3, v4, :cond_0

    invoke-virtual {p1, v3, v1}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v3

    invoke-virtual {p0, v3}, Landroidx/constraintlayout/widget/Barrier;->setType(I)V

    goto :goto_1

    :cond_0
    sget v4, Lo/V4;->RWyiuY:I

    if-ne v3, v4, :cond_1

    iget-object v4, p0, Landroidx/constraintlayout/widget/Barrier;->ETF:Lo/Jk;

    const/4 v5, 0x1

    invoke-virtual {p1, v3, v5}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result v3

    invoke-virtual {v4, v3}, Lo/Jk;->fLidf(Z)V

    goto :goto_1

    :cond_1
    sget v4, Lo/V4;->uxlM:I

    if-ne v3, v4, :cond_2

    invoke-virtual {p1, v3, v1}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v3

    iget-object v4, p0, Landroidx/constraintlayout/widget/Barrier;->ETF:Lo/Jk;

    invoke-virtual {v4, v3}, Lo/Jk;->Rc(I)V

    :cond_2
    :goto_1
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_3
    iget-object p1, p0, Landroidx/constraintlayout/widget/Barrier;->ETF:Lo/Jk;

    iput-object p1, p0, Landroidx/constraintlayout/widget/AZxh;->ZfxDd:Lo/v;

    invoke-virtual {p0}, Landroidx/constraintlayout/widget/AZxh;->MiMN()V

    return-void
.end method
