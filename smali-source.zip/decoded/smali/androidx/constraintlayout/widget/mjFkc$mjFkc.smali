.class public abstract synthetic Landroidx/constraintlayout/widget/mjFkc$mjFkc;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/constraintlayout/widget/mjFkc;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1009
    name = null
.end annotation


# static fields
.field public static final synthetic mjFkc:[I


# direct methods
.method static constructor <clinit>()V
    .locals 3

    invoke-static {}, Landroidx/constraintlayout/widget/mjFkc$AZxh;->values()[Landroidx/constraintlayout/widget/mjFkc$AZxh;

    move-result-object v0

    array-length v0, v0

    new-array v0, v0, [I

    sput-object v0, Landroidx/constraintlayout/widget/mjFkc$mjFkc;->mjFkc:[I

    :try_start_0
    sget-object v1, Landroidx/constraintlayout/widget/mjFkc$AZxh;->wA:Landroidx/constraintlayout/widget/mjFkc$AZxh;

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    const/4 v2, 0x1

    aput v2, v0, v1
    :try_end_0
    .catch Ljava/lang/NoSuchFieldError; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :try_start_1
    sget-object v0, Landroidx/constraintlayout/widget/mjFkc$mjFkc;->mjFkc:[I

    sget-object v1, Landroidx/constraintlayout/widget/mjFkc$AZxh;->ZfxDd:Landroidx/constraintlayout/widget/mjFkc$AZxh;

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    const/4 v2, 0x2

    aput v2, v0, v1
    :try_end_1
    .catch Ljava/lang/NoSuchFieldError; {:try_start_1 .. :try_end_1} :catch_1

    :catch_1
    :try_start_2
    sget-object v0, Landroidx/constraintlayout/widget/mjFkc$mjFkc;->mjFkc:[I

    sget-object v1, Landroidx/constraintlayout/widget/mjFkc$AZxh;->mjFkc:Landroidx/constraintlayout/widget/mjFkc$AZxh;

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    const/4 v2, 0x3

    aput v2, v0, v1
    :try_end_2
    .catch Ljava/lang/NoSuchFieldError; {:try_start_2 .. :try_end_2} :catch_2

    :catch_2
    :try_start_3
    sget-object v0, Landroidx/constraintlayout/widget/mjFkc$mjFkc;->mjFkc:[I

    sget-object v1, Landroidx/constraintlayout/widget/mjFkc$AZxh;->AZxh:Landroidx/constraintlayout/widget/mjFkc$AZxh;

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    const/4 v2, 0x4

    aput v2, v0, v1
    :try_end_3
    .catch Ljava/lang/NoSuchFieldError; {:try_start_3 .. :try_end_3} :catch_3

    :catch_3
    :try_start_4
    sget-object v0, Landroidx/constraintlayout/widget/mjFkc$mjFkc;->mjFkc:[I

    sget-object v1, Landroidx/constraintlayout/widget/mjFkc$AZxh;->KLFTb:Landroidx/constraintlayout/widget/mjFkc$AZxh;

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    const/4 v2, 0x5

    aput v2, v0, v1
    :try_end_4
    .catch Ljava/lang/NoSuchFieldError; {:try_start_4 .. :try_end_4} :catch_4

    :catch_4
    :try_start_5
    sget-object v0, Landroidx/constraintlayout/widget/mjFkc$mjFkc;->mjFkc:[I

    sget-object v1, Landroidx/constraintlayout/widget/mjFkc$AZxh;->JHa:Landroidx/constraintlayout/widget/mjFkc$AZxh;

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    const/4 v2, 0x6

    aput v2, v0, v1
    :try_end_5
    .catch Ljava/lang/NoSuchFieldError; {:try_start_5 .. :try_end_5} :catch_5

    :catch_5
    :try_start_6
    sget-object v0, Landroidx/constraintlayout/widget/mjFkc$mjFkc;->mjFkc:[I

    sget-object v1, Landroidx/constraintlayout/widget/mjFkc$AZxh;->xJ:Landroidx/constraintlayout/widget/mjFkc$AZxh;

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    const/4 v2, 0x7

    aput v2, v0, v1
    :try_end_6
    .catch Ljava/lang/NoSuchFieldError; {:try_start_6 .. :try_end_6} :catch_6

    :catch_6
    return-void
.end method
