.class public abstract synthetic Landroidx/constraintlayout/widget/ConstraintLayout$mjFkc;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/constraintlayout/widget/ConstraintLayout;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1009
    name = null
.end annotation


# static fields
.field public static final synthetic mjFkc:[I


# direct methods
.method static constructor <clinit>()V
    .locals 3

    invoke-static {}, Lo/gjvQ$AZxh;->values()[Lo/gjvQ$AZxh;

    move-result-object v0

    array-length v0, v0

    new-array v0, v0, [I

    sput-object v0, Landroidx/constraintlayout/widget/ConstraintLayout$mjFkc;->mjFkc:[I

    :try_start_0
    sget-object v1, Lo/gjvQ$AZxh;->mjFkc:Lo/gjvQ$AZxh;

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    const/4 v2, 0x1

    aput v2, v0, v1
    :try_end_0
    .catch Ljava/lang/NoSuchFieldError; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :try_start_1
    sget-object v0, Landroidx/constraintlayout/widget/ConstraintLayout$mjFkc;->mjFkc:[I

    sget-object v1, Lo/gjvQ$AZxh;->AZxh:Lo/gjvQ$AZxh;

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    const/4 v2, 0x2

    aput v2, v0, v1
    :try_end_1
    .catch Ljava/lang/NoSuchFieldError; {:try_start_1 .. :try_end_1} :catch_1

    :catch_1
    :try_start_2
    sget-object v0, Landroidx/constraintlayout/widget/ConstraintLayout$mjFkc;->mjFkc:[I

    sget-object v1, Lo/gjvQ$AZxh;->ZfxDd:Lo/gjvQ$AZxh;

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    const/4 v2, 0x3

    aput v2, v0, v1
    :try_end_2
    .catch Ljava/lang/NoSuchFieldError; {:try_start_2 .. :try_end_2} :catch_2

    :catch_2
    :try_start_3
    sget-object v0, Landroidx/constraintlayout/widget/ConstraintLayout$mjFkc;->mjFkc:[I

    sget-object v1, Lo/gjvQ$AZxh;->wA:Lo/gjvQ$AZxh;

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    const/4 v2, 0x4

    aput v2, v0, v1
    :try_end_3
    .catch Ljava/lang/NoSuchFieldError; {:try_start_3 .. :try_end_3} :catch_3

    :catch_3
    return-void
.end method
