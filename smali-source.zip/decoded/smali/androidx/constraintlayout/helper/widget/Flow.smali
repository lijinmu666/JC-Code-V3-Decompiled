.class public Landroidx/constraintlayout/helper/widget/Flow;
.super Lo/Ca;
.source "SourceFile"


# instance fields
.field public ETF:Lo/qMaC;


# direct methods
.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 0

    invoke-direct {p0, p1, p2}, Lo/Ca;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    return-void
.end method


# virtual methods
.method public YoKzxo(Lo/Da;II)V
    .locals 2

    invoke-static {p2}, Landroid/view/View$MeasureSpec;->getMode(I)I

    move-result v0

    invoke-static {p2}, Landroid/view/View$MeasureSpec;->getSize(I)I

    move-result p2

    invoke-static {p3}, Landroid/view/View$MeasureSpec;->getMode(I)I

    move-result v1

    invoke-static {p3}, Landroid/view/View$MeasureSpec;->getSize(I)I

    move-result p3

    if-eqz p1, :cond_0

    invoke-virtual {p1, v0, p2, v1, p3}, Lo/Da;->rdJr(IIII)V

    invoke-virtual {p1}, Lo/Da;->Dp()I

    move-result p2

    invoke-virtual {p1}, Lo/Da;->gtr()I

    move-result p1

    invoke-virtual {p0, p2, p1}, Landroid/view/View;->setMeasuredDimension(II)V

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    invoke-virtual {p0, p1, p1}, Landroid/view/View;->setMeasuredDimension(II)V

    :goto_0
    return-void
.end method

.method public lgHUyS(Lo/gjvQ;Z)V
    .locals 0

    iget-object p0, p0, Landroidx/constraintlayout/helper/widget/Flow;->ETF:Lo/qMaC;

    invoke-virtual {p0, p2}, Lo/Da;->sRqPfw(Z)V

    return-void
.end method

.method public onMeasure(II)V
    .locals 1

    iget-object v0, p0, Landroidx/constraintlayout/helper/widget/Flow;->ETF:Lo/qMaC;

    invoke-virtual {p0, v0, p1, p2}, Landroidx/constraintlayout/helper/widget/Flow;->YoKzxo(Lo/Da;II)V

    return-void
.end method

.method public setFirstHorizontalBias(F)V
    .locals 1

    iget-object v0, p0, Landroidx/constraintlayout/helper/widget/Flow;->ETF:Lo/qMaC;

    invoke-virtual {v0, p1}, Lo/qMaC;->xCVa(F)V

    invoke-virtual {p0}, Landroid/view/View;->requestLayout()V

    return-void
.end method

.method public setFirstHorizontalStyle(I)V
    .locals 1

    iget-object v0, p0, Landroidx/constraintlayout/helper/widget/Flow;->ETF:Lo/qMaC;

    invoke-virtual {v0, p1}, Lo/qMaC;->bc(I)V

    invoke-virtual {p0}, Landroid/view/View;->requestLayout()V

    return-void
.end method

.method public setFirstVerticalBias(F)V
    .locals 1

    iget-object v0, p0, Landroidx/constraintlayout/helper/widget/Flow;->ETF:Lo/qMaC;

    invoke-virtual {v0, p1}, Lo/qMaC;->wLtdyQ(F)V

    invoke-virtual {p0}, Landroid/view/View;->requestLayout()V

    return-void
.end method

.method public setFirstVerticalStyle(I)V
    .locals 1

    iget-object v0, p0, Landroidx/constraintlayout/helper/widget/Flow;->ETF:Lo/qMaC;

    invoke-virtual {v0, p1}, Lo/qMaC;->yP(I)V

    invoke-virtual {p0}, Landroid/view/View;->requestLayout()V

    return-void
.end method

.method public setHorizontalAlign(I)V
    .locals 1

    iget-object v0, p0, Landroidx/constraintlayout/helper/widget/Flow;->ETF:Lo/qMaC;

    invoke-virtual {v0, p1}, Lo/qMaC;->ui(I)V

    invoke-virtual {p0}, Landroid/view/View;->requestLayout()V

    return-void
.end method

.method public setHorizontalBias(F)V
    .locals 1

    iget-object v0, p0, Landroidx/constraintlayout/helper/widget/Flow;->ETF:Lo/qMaC;

    invoke-virtual {v0, p1}, Lo/qMaC;->tpGcn(F)V

    invoke-virtual {p0}, Landroid/view/View;->requestLayout()V

    return-void
.end method

.method public setHorizontalGap(I)V
    .locals 1

    iget-object v0, p0, Landroidx/constraintlayout/helper/widget/Flow;->ETF:Lo/qMaC;

    invoke-virtual {v0, p1}, Lo/qMaC;->qGgY(I)V

    invoke-virtual {p0}, Landroid/view/View;->requestLayout()V

    return-void
.end method

.method public setHorizontalStyle(I)V
    .locals 1

    iget-object v0, p0, Landroidx/constraintlayout/helper/widget/Flow;->ETF:Lo/qMaC;

    invoke-virtual {v0, p1}, Lo/qMaC;->vUsV(I)V

    invoke-virtual {p0}, Landroid/view/View;->requestLayout()V

    return-void
.end method

.method public setMaxElementsWrap(I)V
    .locals 1

    iget-object v0, p0, Landroidx/constraintlayout/helper/widget/Flow;->ETF:Lo/qMaC;

    invoke-virtual {v0, p1}, Lo/qMaC;->np(I)V

    invoke-virtual {p0}, Landroid/view/View;->requestLayout()V

    return-void
.end method

.method public setOrientation(I)V
    .locals 1

    iget-object v0, p0, Landroidx/constraintlayout/helper/widget/Flow;->ETF:Lo/qMaC;

    invoke-virtual {v0, p1}, Lo/qMaC;->QyMqpM(I)V

    invoke-virtual {p0}, Landroid/view/View;->requestLayout()V

    return-void
.end method

.method public setPadding(I)V
    .locals 1

    iget-object v0, p0, Landroidx/constraintlayout/helper/widget/Flow;->ETF:Lo/qMaC;

    invoke-virtual {v0, p1}, Lo/Da;->IyS(I)V

    invoke-virtual {p0}, Landroid/view/View;->requestLayout()V

    return-void
.end method

.method public setPaddingBottom(I)V
    .locals 1

    iget-object v0, p0, Landroidx/constraintlayout/helper/widget/Flow;->ETF:Lo/qMaC;

    invoke-virtual {v0, p1}, Lo/Da;->tAfC(I)V

    invoke-virtual {p0}, Landroid/view/View;->requestLayout()V

    return-void
.end method

.method public setPaddingLeft(I)V
    .locals 1

    iget-object v0, p0, Landroidx/constraintlayout/helper/widget/Flow;->ETF:Lo/qMaC;

    invoke-virtual {v0, p1}, Lo/Da;->Xxz(I)V

    invoke-virtual {p0}, Landroid/view/View;->requestLayout()V

    return-void
.end method

.method public setPaddingRight(I)V
    .locals 1

    iget-object v0, p0, Landroidx/constraintlayout/helper/widget/Flow;->ETF:Lo/qMaC;

    invoke-virtual {v0, p1}, Lo/Da;->Zdbk(I)V

    invoke-virtual {p0}, Landroid/view/View;->requestLayout()V

    return-void
.end method

.method public setPaddingTop(I)V
    .locals 1

    iget-object v0, p0, Landroidx/constraintlayout/helper/widget/Flow;->ETF:Lo/qMaC;

    invoke-virtual {v0, p1}, Lo/Da;->KRckQg(I)V

    invoke-virtual {p0}, Landroid/view/View;->requestLayout()V

    return-void
.end method

.method public setVerticalAlign(I)V
    .locals 1

    iget-object v0, p0, Landroidx/constraintlayout/helper/widget/Flow;->ETF:Lo/qMaC;

    invoke-virtual {v0, p1}, Lo/qMaC;->HExgdj(I)V

    invoke-virtual {p0}, Landroid/view/View;->requestLayout()V

    return-void
.end method

.method public setVerticalBias(F)V
    .locals 1

    iget-object v0, p0, Landroidx/constraintlayout/helper/widget/Flow;->ETF:Lo/qMaC;

    invoke-virtual {v0, p1}, Lo/qMaC;->KSf(F)V

    invoke-virtual {p0}, Landroid/view/View;->requestLayout()V

    return-void
.end method

.method public setVerticalGap(I)V
    .locals 1

    iget-object v0, p0, Landroidx/constraintlayout/helper/widget/Flow;->ETF:Lo/qMaC;

    invoke-virtual {v0, p1}, Lo/qMaC;->Vptz(I)V

    invoke-virtual {p0}, Landroid/view/View;->requestLayout()V

    return-void
.end method

.method public setVerticalStyle(I)V
    .locals 1

    iget-object v0, p0, Landroidx/constraintlayout/helper/widget/Flow;->ETF:Lo/qMaC;

    invoke-virtual {v0, p1}, Lo/qMaC;->qrxT(I)V

    invoke-virtual {p0}, Landroid/view/View;->requestLayout()V

    return-void
.end method

.method public setWrapMode(I)V
    .locals 1

    iget-object v0, p0, Landroidx/constraintlayout/helper/widget/Flow;->ETF:Lo/qMaC;

    invoke-virtual {v0, p1}, Lo/qMaC;->CcoH(I)V

    invoke-virtual {p0}, Landroid/view/View;->requestLayout()V

    return-void
.end method

.method public xJ(Landroid/util/AttributeSet;)V
    .locals 6

    invoke-super {p0, p1}, Lo/Ca;->xJ(Landroid/util/AttributeSet;)V

    new-instance v0, Lo/qMaC;

    invoke-direct {v0}, Lo/qMaC;-><init>()V

    iput-object v0, p0, Landroidx/constraintlayout/helper/widget/Flow;->ETF:Lo/qMaC;

    if-eqz p1, :cond_1a

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    sget-object v1, Lo/V4;->dGDT:[I

    invoke-virtual {v0, p1, v1}, Landroid/content/Context;->obtainStyledAttributes(Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;

    move-result-object p1

    invoke-virtual {p1}, Landroid/content/res/TypedArray;->getIndexCount()I

    move-result v0

    const/4 v1, 0x0

    move v2, v1

    :goto_0
    if-ge v2, v0, :cond_1a

    invoke-virtual {p1, v2}, Landroid/content/res/TypedArray;->getIndex(I)I

    move-result v3

    sget v4, Lo/V4;->Xxz:I

    if-ne v3, v4, :cond_0

    iget-object v4, p0, Landroidx/constraintlayout/helper/widget/Flow;->ETF:Lo/qMaC;

    invoke-virtual {p1, v3, v1}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v3

    invoke-virtual {v4, v3}, Lo/qMaC;->QyMqpM(I)V

    goto/16 :goto_1

    :cond_0
    sget v4, Lo/V4;->Zdbk:I

    if-ne v3, v4, :cond_1

    iget-object v4, p0, Landroidx/constraintlayout/helper/widget/Flow;->ETF:Lo/qMaC;

    invoke-virtual {p1, v3, v1}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v3

    invoke-virtual {v4, v3}, Lo/Da;->IyS(I)V

    goto/16 :goto_1

    :cond_1
    sget v4, Lo/V4;->ybBTr:I

    if-ne v3, v4, :cond_2

    iget-object v4, p0, Landroidx/constraintlayout/helper/widget/Flow;->ETF:Lo/qMaC;

    invoke-virtual {p1, v3, v1}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v3

    invoke-virtual {v4, v3}, Lo/Da;->Jk(I)V

    goto/16 :goto_1

    :cond_2
    sget v4, Lo/V4;->sqndV:I

    if-ne v3, v4, :cond_3

    iget-object v4, p0, Landroidx/constraintlayout/helper/widget/Flow;->ETF:Lo/qMaC;

    invoke-virtual {p1, v3, v1}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v3

    invoke-virtual {v4, v3}, Lo/Da;->dGDT(I)V

    goto/16 :goto_1

    :cond_3
    sget v4, Lo/V4;->Jk:I

    if-ne v3, v4, :cond_4

    iget-object v4, p0, Landroidx/constraintlayout/helper/widget/Flow;->ETF:Lo/qMaC;

    invoke-virtual {p1, v3, v1}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v3

    invoke-virtual {v4, v3}, Lo/Da;->Xxz(I)V

    goto/16 :goto_1

    :cond_4
    sget v4, Lo/V4;->KRckQg:I

    if-ne v3, v4, :cond_5

    iget-object v4, p0, Landroidx/constraintlayout/helper/widget/Flow;->ETF:Lo/qMaC;

    invoke-virtual {p1, v3, v1}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v3

    invoke-virtual {v4, v3}, Lo/Da;->KRckQg(I)V

    goto/16 :goto_1

    :cond_5
    sget v4, Lo/V4;->mPWV:I

    if-ne v3, v4, :cond_6

    iget-object v4, p0, Landroidx/constraintlayout/helper/widget/Flow;->ETF:Lo/qMaC;

    invoke-virtual {p1, v3, v1}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v3

    invoke-virtual {v4, v3}, Lo/Da;->Zdbk(I)V

    goto/16 :goto_1

    :cond_6
    sget v4, Lo/V4;->dkKKW:I

    if-ne v3, v4, :cond_7

    iget-object v4, p0, Landroidx/constraintlayout/helper/widget/Flow;->ETF:Lo/qMaC;

    invoke-virtual {p1, v3, v1}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v3

    invoke-virtual {v4, v3}, Lo/Da;->tAfC(I)V

    goto/16 :goto_1

    :cond_7
    sget v4, Lo/V4;->qGgY:I

    if-ne v3, v4, :cond_8

    iget-object v4, p0, Landroidx/constraintlayout/helper/widget/Flow;->ETF:Lo/qMaC;

    invoke-virtual {p1, v3, v1}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v3

    invoke-virtual {v4, v3}, Lo/qMaC;->CcoH(I)V

    goto/16 :goto_1

    :cond_8
    sget v4, Lo/V4;->QyqF:I

    if-ne v3, v4, :cond_9

    iget-object v4, p0, Landroidx/constraintlayout/helper/widget/Flow;->ETF:Lo/qMaC;

    invoke-virtual {p1, v3, v1}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v3

    invoke-virtual {v4, v3}, Lo/qMaC;->vUsV(I)V

    goto/16 :goto_1

    :cond_9
    sget v4, Lo/V4;->tpGcn:I

    if-ne v3, v4, :cond_a

    iget-object v4, p0, Landroidx/constraintlayout/helper/widget/Flow;->ETF:Lo/qMaC;

    invoke-virtual {p1, v3, v1}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v3

    invoke-virtual {v4, v3}, Lo/qMaC;->qrxT(I)V

    goto/16 :goto_1

    :cond_a
    sget v4, Lo/V4;->Fztqa:I

    if-ne v3, v4, :cond_b

    iget-object v4, p0, Landroidx/constraintlayout/helper/widget/Flow;->ETF:Lo/qMaC;

    invoke-virtual {p1, v3, v1}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v3

    invoke-virtual {v4, v3}, Lo/qMaC;->bc(I)V

    goto/16 :goto_1

    :cond_b
    sget v4, Lo/V4;->nUaNy:I

    if-ne v3, v4, :cond_c

    iget-object v4, p0, Landroidx/constraintlayout/helper/widget/Flow;->ETF:Lo/qMaC;

    invoke-virtual {p1, v3, v1}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v3

    invoke-virtual {v4, v3}, Lo/qMaC;->ERt(I)V

    goto/16 :goto_1

    :cond_c
    sget v4, Lo/V4;->VfB:I

    if-ne v3, v4, :cond_d

    iget-object v4, p0, Landroidx/constraintlayout/helper/widget/Flow;->ETF:Lo/qMaC;

    invoke-virtual {p1, v3, v1}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v3

    invoke-virtual {v4, v3}, Lo/qMaC;->yP(I)V

    goto/16 :goto_1

    :cond_d
    sget v4, Lo/V4;->xCVa:I

    if-ne v3, v4, :cond_e

    iget-object v4, p0, Landroidx/constraintlayout/helper/widget/Flow;->ETF:Lo/qMaC;

    invoke-virtual {p1, v3, v1}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v3

    invoke-virtual {v4, v3}, Lo/qMaC;->pJeaSR(I)V

    goto/16 :goto_1

    :cond_e
    sget v4, Lo/V4;->BxruE:I

    const/high16 v5, 0x3f000000    # 0.5f

    if-ne v3, v4, :cond_f

    iget-object v4, p0, Landroidx/constraintlayout/helper/widget/Flow;->ETF:Lo/qMaC;

    invoke-virtual {p1, v3, v5}, Landroid/content/res/TypedArray;->getFloat(IF)F

    move-result v3

    invoke-virtual {v4, v3}, Lo/qMaC;->tpGcn(F)V

    goto/16 :goto_1

    :cond_f
    sget v4, Lo/V4;->LeWm:I

    if-ne v3, v4, :cond_10

    iget-object v4, p0, Landroidx/constraintlayout/helper/widget/Flow;->ETF:Lo/qMaC;

    invoke-virtual {p1, v3, v5}, Landroid/content/res/TypedArray;->getFloat(IF)F

    move-result v3

    invoke-virtual {v4, v3}, Lo/qMaC;->xCVa(F)V

    goto/16 :goto_1

    :cond_10
    sget v4, Lo/V4;->LsBneK:I

    if-ne v3, v4, :cond_11

    iget-object v4, p0, Landroidx/constraintlayout/helper/widget/Flow;->ETF:Lo/qMaC;

    invoke-virtual {p1, v3, v5}, Landroid/content/res/TypedArray;->getFloat(IF)F

    move-result v3

    invoke-virtual {v4, v3}, Lo/qMaC;->FOJ(F)V

    goto/16 :goto_1

    :cond_11
    sget v4, Lo/V4;->mzUGzO:I

    if-ne v3, v4, :cond_12

    iget-object v4, p0, Landroidx/constraintlayout/helper/widget/Flow;->ETF:Lo/qMaC;

    invoke-virtual {p1, v3, v5}, Landroid/content/res/TypedArray;->getFloat(IF)F

    move-result v3

    invoke-virtual {v4, v3}, Lo/qMaC;->wLtdyQ(F)V

    goto :goto_1

    :cond_12
    sget v4, Lo/V4;->ub:I

    if-ne v3, v4, :cond_13

    iget-object v4, p0, Landroidx/constraintlayout/helper/widget/Flow;->ETF:Lo/qMaC;

    invoke-virtual {p1, v3, v5}, Landroid/content/res/TypedArray;->getFloat(IF)F

    move-result v3

    invoke-virtual {v4, v3}, Lo/qMaC;->JOe(F)V

    goto :goto_1

    :cond_13
    sget v4, Lo/V4;->yP:I

    if-ne v3, v4, :cond_14

    iget-object v4, p0, Landroidx/constraintlayout/helper/widget/Flow;->ETF:Lo/qMaC;

    invoke-virtual {p1, v3, v5}, Landroid/content/res/TypedArray;->getFloat(IF)F

    move-result v3

    invoke-virtual {v4, v3}, Lo/qMaC;->KSf(F)V

    goto :goto_1

    :cond_14
    sget v4, Lo/V4;->Htq:I

    const/4 v5, 0x2

    if-ne v3, v4, :cond_15

    iget-object v4, p0, Landroidx/constraintlayout/helper/widget/Flow;->ETF:Lo/qMaC;

    invoke-virtual {p1, v3, v5}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v3

    invoke-virtual {v4, v3}, Lo/qMaC;->ui(I)V

    goto :goto_1

    :cond_15
    sget v4, Lo/V4;->wLtdyQ:I

    if-ne v3, v4, :cond_16

    iget-object v4, p0, Landroidx/constraintlayout/helper/widget/Flow;->ETF:Lo/qMaC;

    invoke-virtual {p1, v3, v5}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v3

    invoke-virtual {v4, v3}, Lo/qMaC;->HExgdj(I)V

    goto :goto_1

    :cond_16
    sget v4, Lo/V4;->Tw:I

    if-ne v3, v4, :cond_17

    iget-object v4, p0, Landroidx/constraintlayout/helper/widget/Flow;->ETF:Lo/qMaC;

    invoke-virtual {p1, v3, v1}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v3

    invoke-virtual {v4, v3}, Lo/qMaC;->qGgY(I)V

    goto :goto_1

    :cond_17
    sget v4, Lo/V4;->ui:I

    if-ne v3, v4, :cond_18

    iget-object v4, p0, Landroidx/constraintlayout/helper/widget/Flow;->ETF:Lo/qMaC;

    invoke-virtual {p1, v3, v1}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v3

    invoke-virtual {v4, v3}, Lo/qMaC;->Vptz(I)V

    goto :goto_1

    :cond_18
    sget v4, Lo/V4;->bc:I

    if-ne v3, v4, :cond_19

    iget-object v4, p0, Landroidx/constraintlayout/helper/widget/Flow;->ETF:Lo/qMaC;

    const/4 v5, -0x1

    invoke-virtual {p1, v3, v5}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v3

    invoke-virtual {v4, v3}, Lo/qMaC;->np(I)V

    :cond_19
    :goto_1
    add-int/lit8 v2, v2, 0x1

    goto/16 :goto_0

    :cond_1a
    iget-object p1, p0, Landroidx/constraintlayout/helper/widget/Flow;->ETF:Lo/qMaC;

    iput-object p1, p0, Landroidx/constraintlayout/widget/AZxh;->ZfxDd:Lo/v;

    invoke-virtual {p0}, Landroidx/constraintlayout/widget/AZxh;->MiMN()V

    return-void
.end method
