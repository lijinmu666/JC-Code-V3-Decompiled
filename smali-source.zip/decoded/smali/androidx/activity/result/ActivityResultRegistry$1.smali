.class Landroidx/activity/result/ActivityResultRegistry$1;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/lifecycle/KLFTb;


# virtual methods
.method public VA(Lo/W0;Landroidx/lifecycle/wA$mjFkc;)V
    .locals 0

    sget-object p0, Landroidx/lifecycle/wA$mjFkc;->ON_START:Landroidx/lifecycle/wA$mjFkc;

    invoke-virtual {p0, p2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result p0

    const/4 p1, 0x0

    if-nez p0, :cond_2

    sget-object p0, Landroidx/lifecycle/wA$mjFkc;->ON_STOP:Landroidx/lifecycle/wA$mjFkc;

    invoke-virtual {p0, p2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_1

    sget-object p0, Landroidx/lifecycle/wA$mjFkc;->ON_DESTROY:Landroidx/lifecycle/wA$mjFkc;

    invoke-virtual {p0, p2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_0

    return-void

    :cond_0
    throw p1

    :cond_1
    throw p1

    :cond_2
    throw p1
.end method
