.class Landroidx/activity/OnBackPressedDispatcher$LifecycleOnBackPressedCancellable;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/lifecycle/KLFTb;
.implements Lo/VfB;


# instance fields
.field public final AZxh:Lo/Y2;

.field public final mjFkc:Landroidx/lifecycle/wA;

.field public wA:Lo/VfB;


# virtual methods
.method public VA(Lo/W0;Landroidx/lifecycle/wA$mjFkc;)V
    .locals 0

    sget-object p1, Landroidx/lifecycle/wA$mjFkc;->ON_START:Landroidx/lifecycle/wA$mjFkc;

    if-eq p2, p1, :cond_2

    sget-object p1, Landroidx/lifecycle/wA$mjFkc;->ON_STOP:Landroidx/lifecycle/wA$mjFkc;

    if-ne p2, p1, :cond_0

    iget-object p0, p0, Landroidx/activity/OnBackPressedDispatcher$LifecycleOnBackPressedCancellable;->wA:Lo/VfB;

    if-eqz p0, :cond_1

    invoke-interface {p0}, Lo/VfB;->cancel()V

    goto :goto_0

    :cond_0
    sget-object p1, Landroidx/lifecycle/wA$mjFkc;->ON_DESTROY:Landroidx/lifecycle/wA$mjFkc;

    if-ne p2, p1, :cond_1

    invoke-virtual {p0}, Landroidx/activity/OnBackPressedDispatcher$LifecycleOnBackPressedCancellable;->cancel()V

    :cond_1
    :goto_0
    return-void

    :cond_2
    const/4 p0, 0x0

    throw p0
.end method

.method public cancel()V
    .locals 1

    iget-object v0, p0, Landroidx/activity/OnBackPressedDispatcher$LifecycleOnBackPressedCancellable;->mjFkc:Landroidx/lifecycle/wA;

    invoke-virtual {v0, p0}, Landroidx/lifecycle/wA;->wA(Lo/V0;)V

    iget-object v0, p0, Landroidx/activity/OnBackPressedDispatcher$LifecycleOnBackPressedCancellable;->AZxh:Lo/Y2;

    invoke-virtual {v0, p0}, Lo/Y2;->mjFkc(Lo/VfB;)V

    iget-object v0, p0, Landroidx/activity/OnBackPressedDispatcher$LifecycleOnBackPressedCancellable;->wA:Lo/VfB;

    if-eqz v0, :cond_0

    invoke-interface {v0}, Lo/VfB;->cancel()V

    const/4 v0, 0x0

    iput-object v0, p0, Landroidx/activity/OnBackPressedDispatcher$LifecycleOnBackPressedCancellable;->wA:Lo/VfB;

    :cond_0
    return-void
.end method
