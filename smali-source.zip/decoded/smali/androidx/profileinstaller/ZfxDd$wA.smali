.class public Landroidx/profileinstaller/ZfxDd$wA;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/profileinstaller/ZfxDd;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "wA"
.end annotation


# instance fields
.field public final AZxh:Z

.field public final mjFkc:I

.field public final wA:Z


# direct methods
.method public constructor <init>(IZZ)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, Landroidx/profileinstaller/ZfxDd$wA;->mjFkc:I

    iput-boolean p3, p0, Landroidx/profileinstaller/ZfxDd$wA;->wA:Z

    iput-boolean p2, p0, Landroidx/profileinstaller/ZfxDd$wA;->AZxh:Z

    return-void
.end method
