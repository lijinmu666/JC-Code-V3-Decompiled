.class public Landroidx/profileinstaller/ProfileInstallerInitializer;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lo/L;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/profileinstaller/ProfileInstallerInitializer$wA;,
        Landroidx/profileinstaller/ProfileInstallerInitializer$mjFkc;,
        Landroidx/profileinstaller/ProfileInstallerInitializer$AZxh;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lo/L;"
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static synthetic Dt(Landroid/content/Context;)V
    .locals 0

    invoke-static {p0}, Landroidx/profileinstaller/ProfileInstallerInitializer;->VA(Landroid/content/Context;)V

    return-void
.end method

.method public static synthetic ETF(Landroid/content/Context;)V
    .locals 0

    invoke-static {p0}, Landroidx/profileinstaller/wA;->qdMbNW(Landroid/content/Context;)V

    return-void
.end method

.method public static synthetic KLFTb(Landroid/content/Context;)V
    .locals 0

    invoke-static {p0}, Landroidx/profileinstaller/ProfileInstallerInitializer;->Dt(Landroid/content/Context;)V

    return-void
.end method

.method public static VA(Landroid/content/Context;)V
    .locals 8

    new-instance v7, Ljava/util/concurrent/ThreadPoolExecutor;

    sget-object v5, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    new-instance v6, Ljava/util/concurrent/LinkedBlockingQueue;

    invoke-direct {v6}, Ljava/util/concurrent/LinkedBlockingQueue;-><init>()V

    const/4 v1, 0x0

    const/4 v2, 0x1

    const-wide/16 v3, 0x0

    move-object v0, v7

    invoke-direct/range {v0 .. v6}, Ljava/util/concurrent/ThreadPoolExecutor;-><init>(IIJLjava/util/concurrent/TimeUnit;Ljava/util/concurrent/BlockingQueue;)V

    new-instance v0, Lo/U3;

    invoke-direct {v0, p0}, Lo/U3;-><init>(Landroid/content/Context;)V

    invoke-interface {v7, v0}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    return-void
.end method

.method public static synthetic ZfxDd(Landroid/content/Context;)V
    .locals 0

    invoke-static {p0}, Landroidx/profileinstaller/ProfileInstallerInitializer;->ETF(Landroid/content/Context;)V

    return-void
.end method

.method public static synthetic wA(Landroidx/profileinstaller/ProfileInstallerInitializer;Landroid/content/Context;)V
    .locals 0

    invoke-virtual {p0, p1}, Landroidx/profileinstaller/ProfileInstallerInitializer;->qdMbNW(Landroid/content/Context;)V

    return-void
.end method


# virtual methods
.method public bridge synthetic AZxh(Landroid/content/Context;)Ljava/lang/Object;
    .locals 0

    invoke-virtual {p0, p1}, Landroidx/profileinstaller/ProfileInstallerInitializer;->JHa(Landroid/content/Context;)Landroidx/profileinstaller/ProfileInstallerInitializer$wA;

    move-result-object p0

    return-object p0
.end method

.method public JHa(Landroid/content/Context;)Landroidx/profileinstaller/ProfileInstallerInitializer$wA;
    .locals 0

    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    invoke-virtual {p0, p1}, Landroidx/profileinstaller/ProfileInstallerInitializer;->xJ(Landroid/content/Context;)V

    new-instance p0, Landroidx/profileinstaller/ProfileInstallerInitializer$wA;

    invoke-direct {p0}, Landroidx/profileinstaller/ProfileInstallerInitializer$wA;-><init>()V

    return-object p0
.end method

.method public lgHUyS(Landroid/content/Context;)V
    .locals 4

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object p0

    invoke-static {p0}, Landroidx/profileinstaller/ProfileInstallerInitializer$AZxh;->mjFkc(Landroid/os/Looper;)Landroid/os/Handler;

    move-result-object p0

    new-instance v0, Ljava/util/Random;

    invoke-direct {v0}, Ljava/util/Random;-><init>()V

    const/16 v1, 0x3e8

    const/4 v2, 0x1

    invoke-static {v1, v2}, Ljava/lang/Math;->max(II)I

    move-result v1

    invoke-virtual {v0, v1}, Ljava/util/Random;->nextInt(I)I

    move-result v0

    new-instance v1, Lo/T3;

    invoke-direct {v1, p1}, Lo/T3;-><init>(Landroid/content/Context;)V

    add-int/lit16 v0, v0, 0x1388

    int-to-long v2, v0

    invoke-virtual {p0, v1, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void
.end method

.method public mjFkc()Ljava/util/List;
    .locals 0

    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object p0

    return-object p0
.end method

.method public final synthetic qdMbNW(Landroid/content/Context;)V
    .locals 0

    invoke-virtual {p0, p1}, Landroidx/profileinstaller/ProfileInstallerInitializer;->lgHUyS(Landroid/content/Context;)V

    return-void
.end method

.method public xJ(Landroid/content/Context;)V
    .locals 1

    new-instance v0, Lo/S3;

    invoke-direct {v0, p0, p1}, Lo/S3;-><init>(Landroidx/profileinstaller/ProfileInstallerInitializer;Landroid/content/Context;)V

    invoke-static {v0}, Landroidx/profileinstaller/ProfileInstallerInitializer$mjFkc;->wA(Ljava/lang/Runnable;)V

    return-void
.end method
