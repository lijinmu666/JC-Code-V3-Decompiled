.class public interface abstract Landroidx/profileinstaller/wA$wA;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/profileinstaller/wA;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "wA"
.end annotation


# virtual methods
.method public abstract AZxh(ILjava/lang/Object;)V
.end method

.method public abstract mjFkc(ILjava/lang/Object;)V
.end method
