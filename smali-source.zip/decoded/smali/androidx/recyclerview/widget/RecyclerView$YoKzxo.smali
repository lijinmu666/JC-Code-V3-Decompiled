.class public Landroidx/recyclerview/widget/RecyclerView$YoKzxo;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/recyclerview/widget/RecyclerView$MiMN$mjFkc;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/recyclerview/widget/RecyclerView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "YoKzxo"
.end annotation


# instance fields
.field public final synthetic mjFkc:Landroidx/recyclerview/widget/RecyclerView;


# direct methods
.method public constructor <init>(Landroidx/recyclerview/widget/RecyclerView;)V
    .locals 0

    iput-object p1, p0, Landroidx/recyclerview/widget/RecyclerView$YoKzxo;->mjFkc:Landroidx/recyclerview/widget/RecyclerView;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public mjFkc(Landroidx/recyclerview/widget/RecyclerView$mByQ;)V
    .locals 2

    const/4 v0, 0x1

    invoke-virtual {p1, v0}, Landroidx/recyclerview/widget/RecyclerView$mByQ;->Ne(Z)V

    iget-object v0, p1, Landroidx/recyclerview/widget/RecyclerView$mByQ;->lgHUyS:Landroidx/recyclerview/widget/RecyclerView$mByQ;

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    iget-object v0, p1, Landroidx/recyclerview/widget/RecyclerView$mByQ;->qdMbNW:Landroidx/recyclerview/widget/RecyclerView$mByQ;

    if-nez v0, :cond_0

    iput-object v1, p1, Landroidx/recyclerview/widget/RecyclerView$mByQ;->lgHUyS:Landroidx/recyclerview/widget/RecyclerView$mByQ;

    :cond_0
    iput-object v1, p1, Landroidx/recyclerview/widget/RecyclerView$mByQ;->qdMbNW:Landroidx/recyclerview/widget/RecyclerView$mByQ;

    invoke-virtual {p1}, Landroidx/recyclerview/widget/RecyclerView$mByQ;->xrEuO()Z

    move-result v0

    if-nez v0, :cond_1

    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView$YoKzxo;->mjFkc:Landroidx/recyclerview/widget/RecyclerView;

    iget-object v1, p1, Landroidx/recyclerview/widget/RecyclerView$mByQ;->mjFkc:Landroid/view/View;

    invoke-virtual {v0, v1}, Landroidx/recyclerview/widget/RecyclerView;->Zdbk(Landroid/view/View;)Z

    move-result v0

    if-nez v0, :cond_1

    invoke-virtual {p1}, Landroidx/recyclerview/widget/RecyclerView$mByQ;->Gd()Z

    move-result v0

    if-eqz v0, :cond_1

    iget-object p0, p0, Landroidx/recyclerview/widget/RecyclerView$YoKzxo;->mjFkc:Landroidx/recyclerview/widget/RecyclerView;

    iget-object p1, p1, Landroidx/recyclerview/widget/RecyclerView$mByQ;->mjFkc:Landroid/view/View;

    const/4 v0, 0x0

    invoke-virtual {p0, p1, v0}, Landroidx/recyclerview/widget/RecyclerView;->removeDetachedView(Landroid/view/View;Z)V

    :cond_1
    return-void
.end method
