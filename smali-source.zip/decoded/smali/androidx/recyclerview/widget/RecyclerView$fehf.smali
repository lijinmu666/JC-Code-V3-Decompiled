.class public Landroidx/recyclerview/widget/RecyclerView$fehf;
.super Landroid/view/ViewGroup$MarginLayoutParams;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/recyclerview/widget/RecyclerView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "fehf"
.end annotation


# instance fields
.field public final AZxh:Landroid/graphics/Rect;

.field public ZfxDd:Z

.field public mjFkc:Landroidx/recyclerview/widget/RecyclerView$mByQ;

.field public wA:Z


# direct methods
.method public constructor <init>(II)V
    .locals 0

    .line 5
    invoke-direct {p0, p1, p2}, Landroid/view/ViewGroup$MarginLayoutParams;-><init>(II)V

    .line 6
    new-instance p1, Landroid/graphics/Rect;

    invoke-direct {p1}, Landroid/graphics/Rect;-><init>()V

    iput-object p1, p0, Landroidx/recyclerview/widget/RecyclerView$fehf;->AZxh:Landroid/graphics/Rect;

    const/4 p1, 0x1

    .line 7
    iput-boolean p1, p0, Landroidx/recyclerview/widget/RecyclerView$fehf;->wA:Z

    const/4 p1, 0x0

    .line 8
    iput-boolean p1, p0, Landroidx/recyclerview/widget/RecyclerView$fehf;->ZfxDd:Z

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 0

    .line 1
    invoke-direct {p0, p1, p2}, Landroid/view/ViewGroup$MarginLayoutParams;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    .line 2
    new-instance p1, Landroid/graphics/Rect;

    invoke-direct {p1}, Landroid/graphics/Rect;-><init>()V

    iput-object p1, p0, Landroidx/recyclerview/widget/RecyclerView$fehf;->AZxh:Landroid/graphics/Rect;

    const/4 p1, 0x1

    .line 3
    iput-boolean p1, p0, Landroidx/recyclerview/widget/RecyclerView$fehf;->wA:Z

    const/4 p1, 0x0

    .line 4
    iput-boolean p1, p0, Landroidx/recyclerview/widget/RecyclerView$fehf;->ZfxDd:Z

    return-void
.end method

.method public constructor <init>(Landroid/view/ViewGroup$LayoutParams;)V
    .locals 0

    .line 13
    invoke-direct {p0, p1}, Landroid/view/ViewGroup$MarginLayoutParams;-><init>(Landroid/view/ViewGroup$LayoutParams;)V

    .line 14
    new-instance p1, Landroid/graphics/Rect;

    invoke-direct {p1}, Landroid/graphics/Rect;-><init>()V

    iput-object p1, p0, Landroidx/recyclerview/widget/RecyclerView$fehf;->AZxh:Landroid/graphics/Rect;

    const/4 p1, 0x1

    .line 15
    iput-boolean p1, p0, Landroidx/recyclerview/widget/RecyclerView$fehf;->wA:Z

    const/4 p1, 0x0

    .line 16
    iput-boolean p1, p0, Landroidx/recyclerview/widget/RecyclerView$fehf;->ZfxDd:Z

    return-void
.end method

.method public constructor <init>(Landroid/view/ViewGroup$MarginLayoutParams;)V
    .locals 0

    .line 9
    invoke-direct {p0, p1}, Landroid/view/ViewGroup$MarginLayoutParams;-><init>(Landroid/view/ViewGroup$MarginLayoutParams;)V

    .line 10
    new-instance p1, Landroid/graphics/Rect;

    invoke-direct {p1}, Landroid/graphics/Rect;-><init>()V

    iput-object p1, p0, Landroidx/recyclerview/widget/RecyclerView$fehf;->AZxh:Landroid/graphics/Rect;

    const/4 p1, 0x1

    .line 11
    iput-boolean p1, p0, Landroidx/recyclerview/widget/RecyclerView$fehf;->wA:Z

    const/4 p1, 0x0

    .line 12
    iput-boolean p1, p0, Landroidx/recyclerview/widget/RecyclerView$fehf;->ZfxDd:Z

    return-void
.end method

.method public constructor <init>(Landroidx/recyclerview/widget/RecyclerView$fehf;)V
    .locals 0

    .line 17
    invoke-direct {p0, p1}, Landroid/view/ViewGroup$MarginLayoutParams;-><init>(Landroid/view/ViewGroup$LayoutParams;)V

    .line 18
    new-instance p1, Landroid/graphics/Rect;

    invoke-direct {p1}, Landroid/graphics/Rect;-><init>()V

    iput-object p1, p0, Landroidx/recyclerview/widget/RecyclerView$fehf;->AZxh:Landroid/graphics/Rect;

    const/4 p1, 0x1

    .line 19
    iput-boolean p1, p0, Landroidx/recyclerview/widget/RecyclerView$fehf;->wA:Z

    const/4 p1, 0x0

    .line 20
    iput-boolean p1, p0, Landroidx/recyclerview/widget/RecyclerView$fehf;->ZfxDd:Z

    return-void
.end method


# virtual methods
.method public AZxh()Z
    .locals 0

    iget-object p0, p0, Landroidx/recyclerview/widget/RecyclerView$fehf;->mjFkc:Landroidx/recyclerview/widget/RecyclerView$mByQ;

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$mByQ;->HGpJ()Z

    move-result p0

    return p0
.end method

.method public ZfxDd()Z
    .locals 0

    iget-object p0, p0, Landroidx/recyclerview/widget/RecyclerView$fehf;->mjFkc:Landroidx/recyclerview/widget/RecyclerView$mByQ;

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$mByQ;->diqgf()Z

    move-result p0

    return p0
.end method

.method public mjFkc()I
    .locals 0

    iget-object p0, p0, Landroidx/recyclerview/widget/RecyclerView$fehf;->mjFkc:Landroidx/recyclerview/widget/RecyclerView$mByQ;

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$mByQ;->MiMN()I

    move-result p0

    return p0
.end method

.method public wA()Z
    .locals 0

    iget-object p0, p0, Landroidx/recyclerview/widget/RecyclerView$fehf;->mjFkc:Landroidx/recyclerview/widget/RecyclerView$mByQ;

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$mByQ;->Ucbh()Z

    move-result p0

    return p0
.end method
