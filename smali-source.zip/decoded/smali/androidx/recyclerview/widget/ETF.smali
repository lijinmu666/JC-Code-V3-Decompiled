.class public Landroidx/recyclerview/widget/ETF;
.super Lo/MiMN;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/recyclerview/widget/ETF$mjFkc;
    }
.end annotation


# instance fields
.field public final KLFTb:Landroidx/recyclerview/widget/ETF$mjFkc;

.field public final ZfxDd:Landroidx/recyclerview/widget/RecyclerView;


# direct methods
.method public constructor <init>(Landroidx/recyclerview/widget/RecyclerView;)V
    .locals 1

    invoke-direct {p0}, Lo/MiMN;-><init>()V

    iput-object p1, p0, Landroidx/recyclerview/widget/ETF;->ZfxDd:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {p0}, Landroidx/recyclerview/widget/ETF;->YoKzxo()Lo/MiMN;

    move-result-object p1

    if-eqz p1, :cond_0

    instance-of v0, p1, Landroidx/recyclerview/widget/ETF$mjFkc;

    if-eqz v0, :cond_0

    check-cast p1, Landroidx/recyclerview/widget/ETF$mjFkc;

    iput-object p1, p0, Landroidx/recyclerview/widget/ETF;->KLFTb:Landroidx/recyclerview/widget/ETF$mjFkc;

    goto :goto_0

    :cond_0
    new-instance p1, Landroidx/recyclerview/widget/ETF$mjFkc;

    invoke-direct {p1, p0}, Landroidx/recyclerview/widget/ETF$mjFkc;-><init>(Landroidx/recyclerview/widget/ETF;)V

    iput-object p1, p0, Landroidx/recyclerview/widget/ETF;->KLFTb:Landroidx/recyclerview/widget/ETF$mjFkc;

    :goto_0
    return-void
.end method


# virtual methods
.method public Dt(Landroid/view/View;ILandroid/os/Bundle;)Z
    .locals 0

    invoke-super {p0, p1, p2, p3}, Lo/MiMN;->Dt(Landroid/view/View;ILandroid/os/Bundle;)Z

    move-result p1

    if-eqz p1, :cond_0

    const/4 p0, 0x1

    return p0

    :cond_0
    invoke-virtual {p0}, Landroidx/recyclerview/widget/ETF;->rkYL()Z

    move-result p1

    if-nez p1, :cond_1

    iget-object p1, p0, Landroidx/recyclerview/widget/ETF;->ZfxDd:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {p1}, Landroidx/recyclerview/widget/RecyclerView;->getLayoutManager()Landroidx/recyclerview/widget/RecyclerView$qGY;

    move-result-object p1

    if-eqz p1, :cond_1

    iget-object p0, p0, Landroidx/recyclerview/widget/ETF;->ZfxDd:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView;->getLayoutManager()Landroidx/recyclerview/widget/RecyclerView$qGY;

    move-result-object p0

    invoke-virtual {p0, p2, p3}, Landroidx/recyclerview/widget/RecyclerView$qGY;->IvRQOa(ILandroid/os/Bundle;)Z

    move-result p0

    return p0

    :cond_1
    const/4 p0, 0x0

    return p0
.end method

.method public JHa(Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)V
    .locals 1

    invoke-super {p0, p1, p2}, Lo/MiMN;->JHa(Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)V

    instance-of v0, p1, Landroidx/recyclerview/widget/RecyclerView;

    if-eqz v0, :cond_0

    invoke-virtual {p0}, Landroidx/recyclerview/widget/ETF;->rkYL()Z

    move-result p0

    if-nez p0, :cond_0

    check-cast p1, Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {p1}, Landroidx/recyclerview/widget/RecyclerView;->getLayoutManager()Landroidx/recyclerview/widget/RecyclerView$qGY;

    move-result-object p0

    if-eqz p0, :cond_0

    invoke-virtual {p1}, Landroidx/recyclerview/widget/RecyclerView;->getLayoutManager()Landroidx/recyclerview/widget/RecyclerView$qGY;

    move-result-object p0

    invoke-virtual {p0, p2}, Landroidx/recyclerview/widget/RecyclerView$qGY;->Dp(Landroid/view/accessibility/AccessibilityEvent;)V

    :cond_0
    return-void
.end method

.method public YoKzxo()Lo/MiMN;
    .locals 0

    iget-object p0, p0, Landroidx/recyclerview/widget/ETF;->KLFTb:Landroidx/recyclerview/widget/ETF$mjFkc;

    return-object p0
.end method

.method public rkYL()Z
    .locals 0

    iget-object p0, p0, Landroidx/recyclerview/widget/ETF;->ZfxDd:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView;->SmIWf()Z

    move-result p0

    return p0
.end method

.method public xJ(Landroid/view/View;Lo/Ucbh;)V
    .locals 0

    invoke-super {p0, p1, p2}, Lo/MiMN;->xJ(Landroid/view/View;Lo/Ucbh;)V

    invoke-virtual {p0}, Landroidx/recyclerview/widget/ETF;->rkYL()Z

    move-result p1

    if-nez p1, :cond_0

    iget-object p1, p0, Landroidx/recyclerview/widget/ETF;->ZfxDd:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {p1}, Landroidx/recyclerview/widget/RecyclerView;->getLayoutManager()Landroidx/recyclerview/widget/RecyclerView$qGY;

    move-result-object p1

    if-eqz p1, :cond_0

    iget-object p0, p0, Landroidx/recyclerview/widget/ETF;->ZfxDd:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView;->getLayoutManager()Landroidx/recyclerview/widget/RecyclerView$qGY;

    move-result-object p0

    invoke-virtual {p0, p2}, Landroidx/recyclerview/widget/RecyclerView$qGY;->Rc(Lo/Ucbh;)V

    :cond_0
    return-void
.end method
