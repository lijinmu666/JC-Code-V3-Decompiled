.class public Landroidx/recyclerview/widget/JHa;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public AZxh:I

.field public JHa:I

.field public KLFTb:I

.field public ZfxDd:I

.field public lgHUyS:Z

.field public mjFkc:Z

.field public qdMbNW:Z

.field public wA:I

.field public xJ:I


# direct methods
.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x1

    iput-boolean v0, p0, Landroidx/recyclerview/widget/JHa;->mjFkc:Z

    const/4 v0, 0x0

    iput v0, p0, Landroidx/recyclerview/widget/JHa;->JHa:I

    iput v0, p0, Landroidx/recyclerview/widget/JHa;->xJ:I

    return-void
.end method


# virtual methods
.method public AZxh(Landroidx/recyclerview/widget/RecyclerView$Ucbh;)Landroid/view/View;
    .locals 2

    iget v0, p0, Landroidx/recyclerview/widget/JHa;->wA:I

    invoke-virtual {p1, v0}, Landroidx/recyclerview/widget/RecyclerView$Ucbh;->rkYL(I)Landroid/view/View;

    move-result-object p1

    iget v0, p0, Landroidx/recyclerview/widget/JHa;->wA:I

    iget v1, p0, Landroidx/recyclerview/widget/JHa;->ZfxDd:I

    add-int/2addr v0, v1

    iput v0, p0, Landroidx/recyclerview/widget/JHa;->wA:I

    return-object p1
.end method

.method public mjFkc(Landroidx/recyclerview/widget/RecyclerView$VocHEe;)Z
    .locals 0

    iget p0, p0, Landroidx/recyclerview/widget/JHa;->wA:I

    if-ltz p0, :cond_0

    invoke-virtual {p1}, Landroidx/recyclerview/widget/RecyclerView$VocHEe;->AZxh()I

    move-result p1

    if-ge p0, p1, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method

.method public toString()Ljava/lang/String;
    .locals 2

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "LayoutState{mAvailable="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, Landroidx/recyclerview/widget/JHa;->AZxh:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, ", mCurrentPosition="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, Landroidx/recyclerview/widget/JHa;->wA:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, ", mItemDirection="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, Landroidx/recyclerview/widget/JHa;->ZfxDd:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, ", mLayoutDirection="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, Landroidx/recyclerview/widget/JHa;->KLFTb:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, ", mStartLine="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, Landroidx/recyclerview/widget/JHa;->JHa:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, ", mEndLine="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget p0, p0, Landroidx/recyclerview/widget/JHa;->xJ:I

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/16 p0, 0x7d

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
