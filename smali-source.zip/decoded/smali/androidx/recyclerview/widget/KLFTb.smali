.class public final Landroidx/recyclerview/widget/KLFTb;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/recyclerview/widget/KLFTb$AZxh;,
        Landroidx/recyclerview/widget/KLFTb$wA;
    }
.end annotation


# static fields
.field public static JHa:Ljava/util/Comparator;

.field public static final KLFTb:Ljava/lang/ThreadLocal;


# instance fields
.field public AZxh:J

.field public ZfxDd:Ljava/util/ArrayList;

.field public mjFkc:Ljava/util/ArrayList;

.field public wA:J


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, Ljava/lang/ThreadLocal;

    invoke-direct {v0}, Ljava/lang/ThreadLocal;-><init>()V

    sput-object v0, Landroidx/recyclerview/widget/KLFTb;->KLFTb:Ljava/lang/ThreadLocal;

    new-instance v0, Landroidx/recyclerview/widget/KLFTb$mjFkc;

    invoke-direct {v0}, Landroidx/recyclerview/widget/KLFTb$mjFkc;-><init>()V

    sput-object v0, Landroidx/recyclerview/widget/KLFTb;->JHa:Ljava/util/Comparator;

    return-void
.end method

.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Landroidx/recyclerview/widget/KLFTb;->mjFkc:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Landroidx/recyclerview/widget/KLFTb;->ZfxDd:Ljava/util/ArrayList;

    return-void
.end method

.method public static KLFTb(Landroidx/recyclerview/widget/RecyclerView;I)Z
    .locals 5

    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->JHa:Landroidx/recyclerview/widget/AZxh;

    invoke-virtual {v0}, Landroidx/recyclerview/widget/AZxh;->Dt()I

    move-result v0

    const/4 v1, 0x0

    move v2, v1

    :goto_0
    if-ge v2, v0, :cond_1

    iget-object v3, p0, Landroidx/recyclerview/widget/RecyclerView;->JHa:Landroidx/recyclerview/widget/AZxh;

    invoke-virtual {v3, v2}, Landroidx/recyclerview/widget/AZxh;->qdMbNW(I)Landroid/view/View;

    move-result-object v3

    invoke-static {v3}, Landroidx/recyclerview/widget/RecyclerView;->dm(Landroid/view/View;)Landroidx/recyclerview/widget/RecyclerView$mByQ;

    move-result-object v3

    iget v4, v3, Landroidx/recyclerview/widget/RecyclerView$mByQ;->wA:I

    if-ne v4, p1, :cond_0

    invoke-virtual {v3}, Landroidx/recyclerview/widget/RecyclerView$mByQ;->diqgf()Z

    move-result v3

    if-nez v3, :cond_0

    const/4 p0, 0x1

    return p0

    :cond_0
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_1
    return v1
.end method


# virtual methods
.method public final AZxh()V
    .locals 12

    iget-object v0, p0, Landroidx/recyclerview/widget/KLFTb;->mjFkc:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v1, 0x0

    move v2, v1

    move v3, v2

    :goto_0
    if-ge v2, v0, :cond_1

    iget-object v4, p0, Landroidx/recyclerview/widget/KLFTb;->mjFkc:Ljava/util/ArrayList;

    invoke-virtual {v4, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {v4}, Landroid/view/View;->getWindowVisibility()I

    move-result v5

    if-nez v5, :cond_0

    iget-object v5, v4, Landroidx/recyclerview/widget/RecyclerView;->JBhc:Landroidx/recyclerview/widget/KLFTb$AZxh;

    invoke-virtual {v5, v4, v1}, Landroidx/recyclerview/widget/KLFTb$AZxh;->wA(Landroidx/recyclerview/widget/RecyclerView;Z)V

    iget-object v4, v4, Landroidx/recyclerview/widget/RecyclerView;->JBhc:Landroidx/recyclerview/widget/KLFTb$AZxh;

    iget v4, v4, Landroidx/recyclerview/widget/KLFTb$AZxh;->ZfxDd:I

    add-int/2addr v3, v4

    :cond_0
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_1
    iget-object v2, p0, Landroidx/recyclerview/widget/KLFTb;->ZfxDd:Ljava/util/ArrayList;

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->ensureCapacity(I)V

    move v2, v1

    move v3, v2

    :goto_1
    if-ge v2, v0, :cond_6

    iget-object v4, p0, Landroidx/recyclerview/widget/KLFTb;->mjFkc:Ljava/util/ArrayList;

    invoke-virtual {v4, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {v4}, Landroid/view/View;->getWindowVisibility()I

    move-result v5

    if-eqz v5, :cond_2

    goto :goto_5

    :cond_2
    iget-object v5, v4, Landroidx/recyclerview/widget/RecyclerView;->JBhc:Landroidx/recyclerview/widget/KLFTb$AZxh;

    iget v6, v5, Landroidx/recyclerview/widget/KLFTb$AZxh;->mjFkc:I

    invoke-static {v6}, Ljava/lang/Math;->abs(I)I

    move-result v6

    iget v7, v5, Landroidx/recyclerview/widget/KLFTb$AZxh;->AZxh:I

    invoke-static {v7}, Ljava/lang/Math;->abs(I)I

    move-result v7

    add-int/2addr v6, v7

    move v7, v1

    :goto_2
    iget v8, v5, Landroidx/recyclerview/widget/KLFTb$AZxh;->ZfxDd:I

    mul-int/lit8 v8, v8, 0x2

    if-ge v7, v8, :cond_5

    iget-object v8, p0, Landroidx/recyclerview/widget/KLFTb;->ZfxDd:Ljava/util/ArrayList;

    invoke-virtual {v8}, Ljava/util/ArrayList;->size()I

    move-result v8

    if-lt v3, v8, :cond_3

    new-instance v8, Landroidx/recyclerview/widget/KLFTb$wA;

    invoke-direct {v8}, Landroidx/recyclerview/widget/KLFTb$wA;-><init>()V

    iget-object v9, p0, Landroidx/recyclerview/widget/KLFTb;->ZfxDd:Ljava/util/ArrayList;

    invoke-virtual {v9, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_3

    :cond_3
    iget-object v8, p0, Landroidx/recyclerview/widget/KLFTb;->ZfxDd:Ljava/util/ArrayList;

    invoke-virtual {v8, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Landroidx/recyclerview/widget/KLFTb$wA;

    :goto_3
    iget-object v9, v5, Landroidx/recyclerview/widget/KLFTb$AZxh;->wA:[I

    add-int/lit8 v10, v7, 0x1

    aget v10, v9, v10

    if-gt v10, v6, :cond_4

    const/4 v11, 0x1

    goto :goto_4

    :cond_4
    move v11, v1

    :goto_4
    iput-boolean v11, v8, Landroidx/recyclerview/widget/KLFTb$wA;->mjFkc:Z

    iput v6, v8, Landroidx/recyclerview/widget/KLFTb$wA;->AZxh:I

    iput v10, v8, Landroidx/recyclerview/widget/KLFTb$wA;->wA:I

    iput-object v4, v8, Landroidx/recyclerview/widget/KLFTb$wA;->ZfxDd:Landroidx/recyclerview/widget/RecyclerView;

    aget v9, v9, v7

    iput v9, v8, Landroidx/recyclerview/widget/KLFTb$wA;->KLFTb:I

    add-int/lit8 v3, v3, 0x1

    add-int/lit8 v7, v7, 0x2

    goto :goto_2

    :cond_5
    :goto_5
    add-int/lit8 v2, v2, 0x1

    goto :goto_1

    :cond_6
    iget-object p0, p0, Landroidx/recyclerview/widget/KLFTb;->ZfxDd:Ljava/util/ArrayList;

    sget-object v0, Landroidx/recyclerview/widget/KLFTb;->JHa:Ljava/util/Comparator;

    invoke-static {p0, v0}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    return-void
.end method

.method public Dt(Landroidx/recyclerview/widget/RecyclerView;)V
    .locals 0

    iget-object p0, p0, Landroidx/recyclerview/widget/KLFTb;->mjFkc:Ljava/util/ArrayList;

    invoke-virtual {p0, p1}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    move-result p0

    sget-boolean p1, Landroidx/recyclerview/widget/RecyclerView;->gYa:Z

    if-eqz p1, :cond_1

    if-eqz p0, :cond_0

    goto :goto_0

    :cond_0
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string p1, "RecyclerView removal failed!"

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_1
    :goto_0
    return-void
.end method

.method public JHa(Landroidx/recyclerview/widget/RecyclerView;II)V
    .locals 4

    invoke-virtual {p1}, Landroidx/recyclerview/widget/RecyclerView;->isAttachedToWindow()Z

    move-result v0

    if-eqz v0, :cond_2

    sget-boolean v0, Landroidx/recyclerview/widget/RecyclerView;->gYa:Z

    if-eqz v0, :cond_1

    iget-object v0, p0, Landroidx/recyclerview/widget/KLFTb;->mjFkc:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    goto :goto_0

    :cond_0
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string p1, "attempting to post unregistered view!"

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_1
    :goto_0
    iget-wide v0, p0, Landroidx/recyclerview/widget/KLFTb;->AZxh:J

    const-wide/16 v2, 0x0

    cmp-long v0, v0, v2

    if-nez v0, :cond_2

    invoke-virtual {p1}, Landroidx/recyclerview/widget/RecyclerView;->getNanoTime()J

    move-result-wide v0

    iput-wide v0, p0, Landroidx/recyclerview/widget/KLFTb;->AZxh:J

    invoke-virtual {p1, p0}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    :cond_2
    iget-object p0, p1, Landroidx/recyclerview/widget/RecyclerView;->JBhc:Landroidx/recyclerview/widget/KLFTb$AZxh;

    invoke-virtual {p0, p2, p3}, Landroidx/recyclerview/widget/KLFTb$AZxh;->KLFTb(II)V

    return-void
.end method

.method public final ZfxDd(J)V
    .locals 3

    const/4 v0, 0x0

    :goto_0
    iget-object v1, p0, Landroidx/recyclerview/widget/KLFTb;->ZfxDd:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_1

    iget-object v1, p0, Landroidx/recyclerview/widget/KLFTb;->ZfxDd:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroidx/recyclerview/widget/KLFTb$wA;

    iget-object v2, v1, Landroidx/recyclerview/widget/KLFTb$wA;->ZfxDd:Landroidx/recyclerview/widget/RecyclerView;

    if-nez v2, :cond_0

    goto :goto_1

    :cond_0
    invoke-virtual {p0, v1, p1, p2}, Landroidx/recyclerview/widget/KLFTb;->wA(Landroidx/recyclerview/widget/KLFTb$wA;J)V

    invoke-virtual {v1}, Landroidx/recyclerview/widget/KLFTb$wA;->mjFkc()V

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    :goto_1
    return-void
.end method

.method public final lgHUyS(Landroidx/recyclerview/widget/RecyclerView;J)V
    .locals 3

    if-nez p1, :cond_0

    return-void

    :cond_0
    iget-boolean v0, p1, Landroidx/recyclerview/widget/RecyclerView;->mByQ:Z

    if-eqz v0, :cond_1

    iget-object v0, p1, Landroidx/recyclerview/widget/RecyclerView;->JHa:Landroidx/recyclerview/widget/AZxh;

    invoke-virtual {v0}, Landroidx/recyclerview/widget/AZxh;->Dt()I

    move-result v0

    if-eqz v0, :cond_1

    invoke-virtual {p1}, Landroidx/recyclerview/widget/RecyclerView;->Xxz()V

    :cond_1
    iget-object v0, p1, Landroidx/recyclerview/widget/RecyclerView;->JBhc:Landroidx/recyclerview/widget/KLFTb$AZxh;

    const/4 v1, 0x1

    invoke-virtual {v0, p1, v1}, Landroidx/recyclerview/widget/KLFTb$AZxh;->wA(Landroidx/recyclerview/widget/RecyclerView;Z)V

    iget v1, v0, Landroidx/recyclerview/widget/KLFTb$AZxh;->ZfxDd:I

    if-eqz v1, :cond_3

    :try_start_0
    const-string v1, "RV Nested Prefetch"

    invoke-static {v1}, Lo/L8;->mjFkc(Ljava/lang/String;)V

    iget-object v1, p1, Landroidx/recyclerview/widget/RecyclerView;->Vdz:Landroidx/recyclerview/widget/RecyclerView$VocHEe;

    iget-object v2, p1, Landroidx/recyclerview/widget/RecyclerView;->MiMN:Landroidx/recyclerview/widget/RecyclerView$lgHUyS;

    invoke-virtual {v1, v2}, Landroidx/recyclerview/widget/RecyclerView$VocHEe;->JHa(Landroidx/recyclerview/widget/RecyclerView$lgHUyS;)V

    const/4 v1, 0x0

    :goto_0
    iget v2, v0, Landroidx/recyclerview/widget/KLFTb$AZxh;->ZfxDd:I

    mul-int/lit8 v2, v2, 0x2

    if-ge v1, v2, :cond_2

    iget-object v2, v0, Landroidx/recyclerview/widget/KLFTb$AZxh;->wA:[I

    aget v2, v2, v1

    invoke-virtual {p0, p1, v2, p2, p3}, Landroidx/recyclerview/widget/KLFTb;->qdMbNW(Landroidx/recyclerview/widget/RecyclerView;IJ)Landroidx/recyclerview/widget/RecyclerView$mByQ;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    add-int/lit8 v1, v1, 0x2

    goto :goto_0

    :catchall_0
    move-exception p0

    goto :goto_1

    :cond_2
    invoke-static {}, Lo/L8;->AZxh()V

    goto :goto_2

    :goto_1
    invoke-static {}, Lo/L8;->AZxh()V

    throw p0

    :cond_3
    :goto_2
    return-void
.end method

.method public mjFkc(Landroidx/recyclerview/widget/RecyclerView;)V
    .locals 1

    sget-boolean v0, Landroidx/recyclerview/widget/RecyclerView;->gYa:Z

    if-eqz v0, :cond_1

    iget-object v0, p0, Landroidx/recyclerview/widget/KLFTb;->mjFkc:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_0

    goto :goto_0

    :cond_0
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string p1, "RecyclerView already present in worker list!"

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_1
    :goto_0
    iget-object p0, p0, Landroidx/recyclerview/widget/KLFTb;->mjFkc:Ljava/util/ArrayList;

    invoke-virtual {p0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method public final qdMbNW(Landroidx/recyclerview/widget/RecyclerView;IJ)Landroidx/recyclerview/widget/RecyclerView$mByQ;
    .locals 1

    invoke-static {p1, p2}, Landroidx/recyclerview/widget/KLFTb;->KLFTb(Landroidx/recyclerview/widget/RecyclerView;I)Z

    move-result p0

    if-eqz p0, :cond_0

    const/4 p0, 0x0

    return-object p0

    :cond_0
    iget-object p0, p1, Landroidx/recyclerview/widget/RecyclerView;->wA:Landroidx/recyclerview/widget/RecyclerView$Ucbh;

    const/4 v0, 0x0

    :try_start_0
    invoke-virtual {p1}, Landroidx/recyclerview/widget/RecyclerView;->XD()V

    invoke-virtual {p0, p2, v0, p3, p4}, Landroidx/recyclerview/widget/RecyclerView$Ucbh;->Vnb(IZJ)Landroidx/recyclerview/widget/RecyclerView$mByQ;

    move-result-object p2

    if-eqz p2, :cond_2

    invoke-virtual {p2}, Landroidx/recyclerview/widget/RecyclerView$mByQ;->Pq()Z

    move-result p3

    if-eqz p3, :cond_1

    invoke-virtual {p2}, Landroidx/recyclerview/widget/RecyclerView$mByQ;->diqgf()Z

    move-result p3

    if-nez p3, :cond_1

    iget-object p3, p2, Landroidx/recyclerview/widget/RecyclerView$mByQ;->mjFkc:Landroid/view/View;

    invoke-virtual {p0, p3}, Landroidx/recyclerview/widget/RecyclerView$Ucbh;->Ne(Landroid/view/View;)V

    goto :goto_0

    :catchall_0
    move-exception p0

    goto :goto_1

    :cond_1
    invoke-virtual {p0, p2, v0}, Landroidx/recyclerview/widget/RecyclerView$Ucbh;->mjFkc(Landroidx/recyclerview/widget/RecyclerView$mByQ;Z)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_2
    :goto_0
    invoke-virtual {p1, v0}, Landroidx/recyclerview/widget/RecyclerView;->Dp(Z)V

    return-object p2

    :goto_1
    invoke-virtual {p1, v0}, Landroidx/recyclerview/widget/RecyclerView;->Dp(Z)V

    throw p0
.end method

.method public run()V
    .locals 8

    const-wide/16 v0, 0x0

    :try_start_0
    const-string v2, "RV Prefetch"

    invoke-static {v2}, Lo/L8;->mjFkc(Ljava/lang/String;)V

    iget-object v2, p0, Landroidx/recyclerview/widget/KLFTb;->mjFkc:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-eqz v2, :cond_0

    :goto_0
    iput-wide v0, p0, Landroidx/recyclerview/widget/KLFTb;->AZxh:J

    invoke-static {}, Lo/L8;->AZxh()V

    return-void

    :cond_0
    :try_start_1
    iget-object v2, p0, Landroidx/recyclerview/widget/KLFTb;->mjFkc:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    const/4 v3, 0x0

    move-wide v4, v0

    :goto_1
    if-ge v3, v2, :cond_2

    iget-object v6, p0, Landroidx/recyclerview/widget/KLFTb;->mjFkc:Ljava/util/ArrayList;

    invoke-virtual {v6, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {v6}, Landroid/view/View;->getWindowVisibility()I

    move-result v7

    if-nez v7, :cond_1

    invoke-virtual {v6}, Landroid/view/View;->getDrawingTime()J

    move-result-wide v6

    invoke-static {v6, v7, v4, v5}, Ljava/lang/Math;->max(JJ)J

    move-result-wide v4

    goto :goto_2

    :catchall_0
    move-exception v2

    goto :goto_3

    :cond_1
    :goto_2
    add-int/lit8 v3, v3, 0x1

    goto :goto_1

    :cond_2
    cmp-long v2, v4, v0

    if-nez v2, :cond_3

    goto :goto_0

    :cond_3
    sget-object v2, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    invoke-virtual {v2, v4, v5}, Ljava/util/concurrent/TimeUnit;->toNanos(J)J

    move-result-wide v2

    iget-wide v4, p0, Landroidx/recyclerview/widget/KLFTb;->wA:J

    add-long/2addr v2, v4

    invoke-virtual {p0, v2, v3}, Landroidx/recyclerview/widget/KLFTb;->xJ(J)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    iput-wide v0, p0, Landroidx/recyclerview/widget/KLFTb;->AZxh:J

    invoke-static {}, Lo/L8;->AZxh()V

    return-void

    :goto_3
    iput-wide v0, p0, Landroidx/recyclerview/widget/KLFTb;->AZxh:J

    invoke-static {}, Lo/L8;->AZxh()V

    throw v2
.end method

.method public final wA(Landroidx/recyclerview/widget/KLFTb$wA;J)V
    .locals 3

    iget-boolean v0, p1, Landroidx/recyclerview/widget/KLFTb$wA;->mjFkc:Z

    if-eqz v0, :cond_0

    const-wide v0, 0x7fffffffffffffffL

    goto :goto_0

    :cond_0
    move-wide v0, p2

    :goto_0
    iget-object v2, p1, Landroidx/recyclerview/widget/KLFTb$wA;->ZfxDd:Landroidx/recyclerview/widget/RecyclerView;

    iget p1, p1, Landroidx/recyclerview/widget/KLFTb$wA;->KLFTb:I

    invoke-virtual {p0, v2, p1, v0, v1}, Landroidx/recyclerview/widget/KLFTb;->qdMbNW(Landroidx/recyclerview/widget/RecyclerView;IJ)Landroidx/recyclerview/widget/RecyclerView$mByQ;

    move-result-object p1

    if-eqz p1, :cond_1

    iget-object v0, p1, Landroidx/recyclerview/widget/RecyclerView$mByQ;->AZxh:Ljava/lang/ref/WeakReference;

    if-eqz v0, :cond_1

    invoke-virtual {p1}, Landroidx/recyclerview/widget/RecyclerView$mByQ;->Pq()Z

    move-result v0

    if-eqz v0, :cond_1

    invoke-virtual {p1}, Landroidx/recyclerview/widget/RecyclerView$mByQ;->diqgf()Z

    move-result v0

    if-nez v0, :cond_1

    iget-object p1, p1, Landroidx/recyclerview/widget/RecyclerView$mByQ;->AZxh:Ljava/lang/ref/WeakReference;

    invoke-virtual {p1}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {p0, p1, p2, p3}, Landroidx/recyclerview/widget/KLFTb;->lgHUyS(Landroidx/recyclerview/widget/RecyclerView;J)V

    :cond_1
    return-void
.end method

.method public xJ(J)V
    .locals 0

    invoke-virtual {p0}, Landroidx/recyclerview/widget/KLFTb;->AZxh()V

    invoke-virtual {p0, p1, p2}, Landroidx/recyclerview/widget/KLFTb;->ZfxDd(J)V

    return-void
.end method
