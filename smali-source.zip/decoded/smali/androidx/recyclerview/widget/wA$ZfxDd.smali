.class public Landroidx/recyclerview/widget/wA$ZfxDd;
.super Landroid/animation/AnimatorListenerAdapter;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Landroidx/recyclerview/widget/wA;->KRTLGT(Landroidx/recyclerview/widget/RecyclerView$mByQ;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic AZxh:Landroid/view/ViewPropertyAnimator;

.field public final synthetic ZfxDd:Landroidx/recyclerview/widget/wA;

.field public final synthetic mjFkc:Landroidx/recyclerview/widget/RecyclerView$mByQ;

.field public final synthetic wA:Landroid/view/View;


# direct methods
.method public constructor <init>(Landroidx/recyclerview/widget/wA;Landroidx/recyclerview/widget/RecyclerView$mByQ;Landroid/view/ViewPropertyAnimator;Landroid/view/View;)V
    .locals 0

    iput-object p1, p0, Landroidx/recyclerview/widget/wA$ZfxDd;->ZfxDd:Landroidx/recyclerview/widget/wA;

    iput-object p2, p0, Landroidx/recyclerview/widget/wA$ZfxDd;->mjFkc:Landroidx/recyclerview/widget/RecyclerView$mByQ;

    iput-object p3, p0, Landroidx/recyclerview/widget/wA$ZfxDd;->AZxh:Landroid/view/ViewPropertyAnimator;

    iput-object p4, p0, Landroidx/recyclerview/widget/wA$ZfxDd;->wA:Landroid/view/View;

    invoke-direct {p0}, Landroid/animation/AnimatorListenerAdapter;-><init>()V

    return-void
.end method


# virtual methods
.method public onAnimationEnd(Landroid/animation/Animator;)V
    .locals 1

    iget-object p1, p0, Landroidx/recyclerview/widget/wA$ZfxDd;->AZxh:Landroid/view/ViewPropertyAnimator;

    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Landroid/view/ViewPropertyAnimator;->setListener(Landroid/animation/Animator$AnimatorListener;)Landroid/view/ViewPropertyAnimator;

    iget-object p1, p0, Landroidx/recyclerview/widget/wA$ZfxDd;->wA:Landroid/view/View;

    const/high16 v0, 0x3f800000    # 1.0f

    invoke-virtual {p1, v0}, Landroid/view/View;->setAlpha(F)V

    iget-object p1, p0, Landroidx/recyclerview/widget/wA$ZfxDd;->ZfxDd:Landroidx/recyclerview/widget/wA;

    iget-object v0, p0, Landroidx/recyclerview/widget/wA$ZfxDd;->mjFkc:Landroidx/recyclerview/widget/RecyclerView$mByQ;

    invoke-virtual {p1, v0}, Landroidx/recyclerview/widget/MiMN;->Ne(Landroidx/recyclerview/widget/RecyclerView$mByQ;)V

    iget-object p1, p0, Landroidx/recyclerview/widget/wA$ZfxDd;->ZfxDd:Landroidx/recyclerview/widget/wA;

    iget-object p1, p1, Landroidx/recyclerview/widget/wA;->fehf:Ljava/util/ArrayList;

    iget-object v0, p0, Landroidx/recyclerview/widget/wA$ZfxDd;->mjFkc:Landroidx/recyclerview/widget/RecyclerView$mByQ;

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    iget-object p0, p0, Landroidx/recyclerview/widget/wA$ZfxDd;->ZfxDd:Landroidx/recyclerview/widget/wA;

    invoke-virtual {p0}, Landroidx/recyclerview/widget/wA;->uHVRx()V

    return-void
.end method

.method public onAnimationStart(Landroid/animation/Animator;)V
    .locals 0

    iget-object p1, p0, Landroidx/recyclerview/widget/wA$ZfxDd;->ZfxDd:Landroidx/recyclerview/widget/wA;

    iget-object p0, p0, Landroidx/recyclerview/widget/wA$ZfxDd;->mjFkc:Landroidx/recyclerview/widget/RecyclerView$mByQ;

    invoke-virtual {p1, p0}, Landroidx/recyclerview/widget/MiMN;->CqaNbM(Landroidx/recyclerview/widget/RecyclerView$mByQ;)V

    return-void
.end method
