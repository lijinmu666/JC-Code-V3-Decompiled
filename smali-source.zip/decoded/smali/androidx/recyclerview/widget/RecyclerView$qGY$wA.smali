.class public interface abstract Landroidx/recyclerview/widget/RecyclerView$qGY$wA;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/recyclerview/widget/RecyclerView$qGY;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "wA"
.end annotation


# virtual methods
.method public abstract mjFkc(II)V
.end method
