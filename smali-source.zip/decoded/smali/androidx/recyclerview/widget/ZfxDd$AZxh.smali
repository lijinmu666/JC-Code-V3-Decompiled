.class public Landroidx/recyclerview/widget/ZfxDd$AZxh;
.super Landroidx/recyclerview/widget/RecyclerView$diqgf;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/recyclerview/widget/ZfxDd;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic mjFkc:Landroidx/recyclerview/widget/ZfxDd;


# direct methods
.method public constructor <init>(Landroidx/recyclerview/widget/ZfxDd;)V
    .locals 0

    iput-object p1, p0, Landroidx/recyclerview/widget/ZfxDd$AZxh;->mjFkc:Landroidx/recyclerview/widget/ZfxDd;

    invoke-direct {p0}, Landroidx/recyclerview/widget/RecyclerView$diqgf;-><init>()V

    return-void
.end method


# virtual methods
.method public AZxh(Landroidx/recyclerview/widget/RecyclerView;II)V
    .locals 0

    iget-object p0, p0, Landroidx/recyclerview/widget/ZfxDd$AZxh;->mjFkc:Landroidx/recyclerview/widget/ZfxDd;

    invoke-virtual {p1}, Landroidx/recyclerview/widget/RecyclerView;->computeHorizontalScrollOffset()I

    move-result p2

    invoke-virtual {p1}, Landroidx/recyclerview/widget/RecyclerView;->computeVerticalScrollOffset()I

    move-result p1

    invoke-virtual {p0, p2, p1}, Landroidx/recyclerview/widget/ZfxDd;->BAnRFn(II)V

    return-void
.end method
