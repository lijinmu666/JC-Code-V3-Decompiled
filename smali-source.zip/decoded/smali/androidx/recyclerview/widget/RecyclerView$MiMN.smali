.class public abstract Landroidx/recyclerview/widget/RecyclerView$MiMN;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/recyclerview/widget/RecyclerView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "MiMN"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/recyclerview/widget/RecyclerView$MiMN$AZxh;,
        Landroidx/recyclerview/widget/RecyclerView$MiMN$mjFkc;
    }
.end annotation


# instance fields
.field public AZxh:Ljava/util/ArrayList;

.field public JHa:J

.field public KLFTb:J

.field public ZfxDd:J

.field public mjFkc:Landroidx/recyclerview/widget/RecyclerView$MiMN$mjFkc;

.field public wA:J


# direct methods
.method public constructor <init>()V
    .locals 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput-object v0, p0, Landroidx/recyclerview/widget/RecyclerView$MiMN;->mjFkc:Landroidx/recyclerview/widget/RecyclerView$MiMN$mjFkc;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Landroidx/recyclerview/widget/RecyclerView$MiMN;->AZxh:Ljava/util/ArrayList;

    const-wide/16 v0, 0x78

    iput-wide v0, p0, Landroidx/recyclerview/widget/RecyclerView$MiMN;->wA:J

    iput-wide v0, p0, Landroidx/recyclerview/widget/RecyclerView$MiMN;->ZfxDd:J

    const-wide/16 v0, 0xfa

    iput-wide v0, p0, Landroidx/recyclerview/widget/RecyclerView$MiMN;->KLFTb:J

    iput-wide v0, p0, Landroidx/recyclerview/widget/RecyclerView$MiMN;->JHa:J

    return-void
.end method

.method public static KLFTb(Landroidx/recyclerview/widget/RecyclerView$mByQ;)I
    .locals 4

    iget v0, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->Dt:I

    and-int/lit8 v1, v0, 0xe

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$mByQ;->diqgf()Z

    move-result v2

    const/4 v3, 0x4

    if-eqz v2, :cond_0

    return v3

    :cond_0
    and-int/2addr v0, v3

    if-nez v0, :cond_1

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$mByQ;->YoKzxo()I

    move-result v0

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$mByQ;->Dt()I

    move-result p0

    const/4 v2, -0x1

    if-eq v0, v2, :cond_1

    if-eq p0, v2, :cond_1

    if-eq v0, p0, :cond_1

    or-int/lit16 v1, v1, 0x800

    :cond_1
    return v1
.end method


# virtual methods
.method public abstract AZxh(Landroidx/recyclerview/widget/RecyclerView$mByQ;Landroidx/recyclerview/widget/RecyclerView$mByQ;Landroidx/recyclerview/widget/RecyclerView$MiMN$AZxh;Landroidx/recyclerview/widget/RecyclerView$MiMN$AZxh;)Z
.end method

.method public abstract Dt(Landroidx/recyclerview/widget/RecyclerView$mByQ;)V
.end method

.method public abstract ETF()V
.end method

.method public IEE(Landroidx/recyclerview/widget/RecyclerView$mByQ;)V
    .locals 0

    return-void
.end method

.method public abstract JHa(Landroidx/recyclerview/widget/RecyclerView$mByQ;)Z
.end method

.method public MiMN()J
    .locals 2

    iget-wide v0, p0, Landroidx/recyclerview/widget/RecyclerView$MiMN;->JHa:J

    return-wide v0
.end method

.method public Pq(Landroidx/recyclerview/widget/RecyclerView$VocHEe;Landroidx/recyclerview/widget/RecyclerView$mByQ;)Landroidx/recyclerview/widget/RecyclerView$MiMN$AZxh;
    .locals 0

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$MiMN;->fehf()Landroidx/recyclerview/widget/RecyclerView$MiMN$AZxh;

    move-result-object p0

    invoke-virtual {p0, p2}, Landroidx/recyclerview/widget/RecyclerView$MiMN$AZxh;->mjFkc(Landroidx/recyclerview/widget/RecyclerView$mByQ;)Landroidx/recyclerview/widget/RecyclerView$MiMN$AZxh;

    move-result-object p0

    return-object p0
.end method

.method public Ucbh(Landroidx/recyclerview/widget/RecyclerView$MiMN$mjFkc;)V
    .locals 0

    iput-object p1, p0, Landroidx/recyclerview/widget/RecyclerView$MiMN;->mjFkc:Landroidx/recyclerview/widget/RecyclerView$MiMN$mjFkc;

    return-void
.end method

.method public VA()J
    .locals 2

    iget-wide v0, p0, Landroidx/recyclerview/widget/RecyclerView$MiMN;->wA:J

    return-wide v0
.end method

.method public YoKzxo()J
    .locals 2

    iget-wide v0, p0, Landroidx/recyclerview/widget/RecyclerView$MiMN;->KLFTb:J

    return-wide v0
.end method

.method public abstract ZfxDd(Landroidx/recyclerview/widget/RecyclerView$mByQ;Landroidx/recyclerview/widget/RecyclerView$MiMN$AZxh;Landroidx/recyclerview/widget/RecyclerView$MiMN$AZxh;)Z
.end method

.method public diqgf(Landroidx/recyclerview/widget/RecyclerView$VocHEe;Landroidx/recyclerview/widget/RecyclerView$mByQ;ILjava/util/List;)Landroidx/recyclerview/widget/RecyclerView$MiMN$AZxh;
    .locals 0

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$MiMN;->fehf()Landroidx/recyclerview/widget/RecyclerView$MiMN$AZxh;

    move-result-object p0

    invoke-virtual {p0, p2}, Landroidx/recyclerview/widget/RecyclerView$MiMN$AZxh;->mjFkc(Landroidx/recyclerview/widget/RecyclerView$mByQ;)Landroidx/recyclerview/widget/RecyclerView$MiMN$AZxh;

    move-result-object p0

    return-object p0
.end method

.method public abstract eyqo()V
.end method

.method public fehf()Landroidx/recyclerview/widget/RecyclerView$MiMN$AZxh;
    .locals 0

    new-instance p0, Landroidx/recyclerview/widget/RecyclerView$MiMN$AZxh;

    invoke-direct {p0}, Landroidx/recyclerview/widget/RecyclerView$MiMN$AZxh;-><init>()V

    return-object p0
.end method

.method public final lgHUyS(Landroidx/recyclerview/widget/RecyclerView$mByQ;)V
    .locals 0

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/RecyclerView$MiMN;->IEE(Landroidx/recyclerview/widget/RecyclerView$mByQ;)V

    iget-object p0, p0, Landroidx/recyclerview/widget/RecyclerView$MiMN;->mjFkc:Landroidx/recyclerview/widget/RecyclerView$MiMN$mjFkc;

    if-eqz p0, :cond_0

    invoke-interface {p0, p1}, Landroidx/recyclerview/widget/RecyclerView$MiMN$mjFkc;->mjFkc(Landroidx/recyclerview/widget/RecyclerView$mByQ;)V

    :cond_0
    return-void
.end method

.method public abstract mjFkc(Landroidx/recyclerview/widget/RecyclerView$mByQ;Landroidx/recyclerview/widget/RecyclerView$MiMN$AZxh;Landroidx/recyclerview/widget/RecyclerView$MiMN$AZxh;)Z
.end method

.method public abstract qGY()Z
.end method

.method public final qdMbNW()V
    .locals 1

    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView$MiMN;->AZxh:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-gtz v0, :cond_0

    iget-object p0, p0, Landroidx/recyclerview/widget/RecyclerView$MiMN;->AZxh:Ljava/util/ArrayList;

    invoke-virtual {p0}, Ljava/util/ArrayList;->clear()V

    return-void

    :cond_0
    iget-object p0, p0, Landroidx/recyclerview/widget/RecyclerView$MiMN;->AZxh:Ljava/util/ArrayList;

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p0

    invoke-static {p0}, Lo/w7;->mjFkc(Ljava/lang/Object;)V

    const/4 p0, 0x0

    throw p0
.end method

.method public rkYL()J
    .locals 2

    iget-wide v0, p0, Landroidx/recyclerview/widget/RecyclerView$MiMN;->ZfxDd:J

    return-wide v0
.end method

.method public abstract wA(Landroidx/recyclerview/widget/RecyclerView$mByQ;Landroidx/recyclerview/widget/RecyclerView$MiMN$AZxh;Landroidx/recyclerview/widget/RecyclerView$MiMN$AZxh;)Z
.end method

.method public xJ(Landroidx/recyclerview/widget/RecyclerView$mByQ;Ljava/util/List;)Z
    .locals 0

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/RecyclerView$MiMN;->JHa(Landroidx/recyclerview/widget/RecyclerView$mByQ;)Z

    move-result p0

    return p0
.end method
