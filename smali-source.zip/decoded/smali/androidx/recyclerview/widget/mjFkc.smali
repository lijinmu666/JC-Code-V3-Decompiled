.class public final Landroidx/recyclerview/widget/mjFkc;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/recyclerview/widget/lgHUyS$mjFkc;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/recyclerview/widget/mjFkc$mjFkc;,
        Landroidx/recyclerview/widget/mjFkc$AZxh;
    }
.end annotation


# instance fields
.field public final AZxh:Ljava/util/ArrayList;

.field public final JHa:Z

.field public KLFTb:Ljava/lang/Runnable;

.field public final ZfxDd:Landroidx/recyclerview/widget/mjFkc$mjFkc;

.field public lgHUyS:I

.field public mjFkc:Lo/A3;

.field public final wA:Ljava/util/ArrayList;

.field public final xJ:Landroidx/recyclerview/widget/lgHUyS;


# direct methods
.method public constructor <init>(Landroidx/recyclerview/widget/mjFkc$mjFkc;)V
    .locals 1

    const/4 v0, 0x0

    .line 1
    invoke-direct {p0, p1, v0}, Landroidx/recyclerview/widget/mjFkc;-><init>(Landroidx/recyclerview/widget/mjFkc$mjFkc;Z)V

    return-void
.end method

.method public constructor <init>(Landroidx/recyclerview/widget/mjFkc$mjFkc;Z)V
    .locals 2

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    new-instance v0, Lo/C3;

    const/16 v1, 0x1e

    invoke-direct {v0, v1}, Lo/C3;-><init>(I)V

    iput-object v0, p0, Landroidx/recyclerview/widget/mjFkc;->mjFkc:Lo/A3;

    .line 4
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Landroidx/recyclerview/widget/mjFkc;->AZxh:Ljava/util/ArrayList;

    .line 5
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Landroidx/recyclerview/widget/mjFkc;->wA:Ljava/util/ArrayList;

    const/4 v0, 0x0

    .line 6
    iput v0, p0, Landroidx/recyclerview/widget/mjFkc;->lgHUyS:I

    .line 7
    iput-object p1, p0, Landroidx/recyclerview/widget/mjFkc;->ZfxDd:Landroidx/recyclerview/widget/mjFkc$mjFkc;

    .line 8
    iput-boolean p2, p0, Landroidx/recyclerview/widget/mjFkc;->JHa:Z

    .line 9
    new-instance p1, Landroidx/recyclerview/widget/lgHUyS;

    invoke-direct {p1, p0}, Landroidx/recyclerview/widget/lgHUyS;-><init>(Landroidx/recyclerview/widget/lgHUyS$mjFkc;)V

    iput-object p1, p0, Landroidx/recyclerview/widget/mjFkc;->xJ:Landroidx/recyclerview/widget/lgHUyS;

    return-void
.end method


# virtual methods
.method public AZxh(IIILjava/lang/Object;)Landroidx/recyclerview/widget/mjFkc$AZxh;
    .locals 0

    iget-object p0, p0, Landroidx/recyclerview/widget/mjFkc;->mjFkc:Lo/A3;

    invoke-interface {p0}, Lo/A3;->AZxh()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroidx/recyclerview/widget/mjFkc$AZxh;

    if-nez p0, :cond_0

    new-instance p0, Landroidx/recyclerview/widget/mjFkc$AZxh;

    invoke-direct {p0, p1, p2, p3, p4}, Landroidx/recyclerview/widget/mjFkc$AZxh;-><init>(IIILjava/lang/Object;)V

    goto :goto_0

    :cond_0
    iput p1, p0, Landroidx/recyclerview/widget/mjFkc$AZxh;->mjFkc:I

    iput p2, p0, Landroidx/recyclerview/widget/mjFkc$AZxh;->AZxh:I

    iput p3, p0, Landroidx/recyclerview/widget/mjFkc$AZxh;->ZfxDd:I

    iput-object p4, p0, Landroidx/recyclerview/widget/mjFkc$AZxh;->wA:Ljava/lang/Object;

    :goto_0
    return-object p0
.end method

.method public Dt()V
    .locals 7

    invoke-virtual {p0}, Landroidx/recyclerview/widget/mjFkc;->qdMbNW()V

    iget-object v0, p0, Landroidx/recyclerview/widget/mjFkc;->AZxh:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v1, 0x0

    move v2, v1

    :goto_0
    if-ge v2, v0, :cond_5

    iget-object v3, p0, Landroidx/recyclerview/widget/mjFkc;->AZxh:Ljava/util/ArrayList;

    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroidx/recyclerview/widget/mjFkc$AZxh;

    iget v4, v3, Landroidx/recyclerview/widget/mjFkc$AZxh;->mjFkc:I

    const/4 v5, 0x1

    if-eq v4, v5, :cond_3

    const/4 v5, 0x2

    if-eq v4, v5, :cond_2

    const/4 v5, 0x4

    if-eq v4, v5, :cond_1

    const/16 v5, 0x8

    if-eq v4, v5, :cond_0

    goto :goto_1

    :cond_0
    iget-object v4, p0, Landroidx/recyclerview/widget/mjFkc;->ZfxDd:Landroidx/recyclerview/widget/mjFkc$mjFkc;

    invoke-interface {v4, v3}, Landroidx/recyclerview/widget/mjFkc$mjFkc;->AZxh(Landroidx/recyclerview/widget/mjFkc$AZxh;)V

    iget-object v4, p0, Landroidx/recyclerview/widget/mjFkc;->ZfxDd:Landroidx/recyclerview/widget/mjFkc$mjFkc;

    iget v5, v3, Landroidx/recyclerview/widget/mjFkc$AZxh;->AZxh:I

    iget v3, v3, Landroidx/recyclerview/widget/mjFkc$AZxh;->ZfxDd:I

    invoke-interface {v4, v5, v3}, Landroidx/recyclerview/widget/mjFkc$mjFkc;->mjFkc(II)V

    goto :goto_1

    :cond_1
    iget-object v4, p0, Landroidx/recyclerview/widget/mjFkc;->ZfxDd:Landroidx/recyclerview/widget/mjFkc$mjFkc;

    invoke-interface {v4, v3}, Landroidx/recyclerview/widget/mjFkc$mjFkc;->AZxh(Landroidx/recyclerview/widget/mjFkc$AZxh;)V

    iget-object v4, p0, Landroidx/recyclerview/widget/mjFkc;->ZfxDd:Landroidx/recyclerview/widget/mjFkc$mjFkc;

    iget v5, v3, Landroidx/recyclerview/widget/mjFkc$AZxh;->AZxh:I

    iget v6, v3, Landroidx/recyclerview/widget/mjFkc$AZxh;->ZfxDd:I

    iget-object v3, v3, Landroidx/recyclerview/widget/mjFkc$AZxh;->wA:Ljava/lang/Object;

    invoke-interface {v4, v5, v6, v3}, Landroidx/recyclerview/widget/mjFkc$mjFkc;->lgHUyS(IILjava/lang/Object;)V

    goto :goto_1

    :cond_2
    iget-object v4, p0, Landroidx/recyclerview/widget/mjFkc;->ZfxDd:Landroidx/recyclerview/widget/mjFkc$mjFkc;

    invoke-interface {v4, v3}, Landroidx/recyclerview/widget/mjFkc$mjFkc;->AZxh(Landroidx/recyclerview/widget/mjFkc$AZxh;)V

    iget-object v4, p0, Landroidx/recyclerview/widget/mjFkc;->ZfxDd:Landroidx/recyclerview/widget/mjFkc$mjFkc;

    iget v5, v3, Landroidx/recyclerview/widget/mjFkc$AZxh;->AZxh:I

    iget v3, v3, Landroidx/recyclerview/widget/mjFkc$AZxh;->ZfxDd:I

    invoke-interface {v4, v5, v3}, Landroidx/recyclerview/widget/mjFkc$mjFkc;->JHa(II)V

    goto :goto_1

    :cond_3
    iget-object v4, p0, Landroidx/recyclerview/widget/mjFkc;->ZfxDd:Landroidx/recyclerview/widget/mjFkc$mjFkc;

    invoke-interface {v4, v3}, Landroidx/recyclerview/widget/mjFkc$mjFkc;->AZxh(Landroidx/recyclerview/widget/mjFkc$AZxh;)V

    iget-object v4, p0, Landroidx/recyclerview/widget/mjFkc;->ZfxDd:Landroidx/recyclerview/widget/mjFkc$mjFkc;

    iget v5, v3, Landroidx/recyclerview/widget/mjFkc$AZxh;->AZxh:I

    iget v3, v3, Landroidx/recyclerview/widget/mjFkc$AZxh;->ZfxDd:I

    invoke-interface {v4, v5, v3}, Landroidx/recyclerview/widget/mjFkc$mjFkc;->KLFTb(II)V

    :goto_1
    iget-object v3, p0, Landroidx/recyclerview/widget/mjFkc;->KLFTb:Ljava/lang/Runnable;

    if-eqz v3, :cond_4

    invoke-interface {v3}, Ljava/lang/Runnable;->run()V

    :cond_4
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_5
    iget-object v0, p0, Landroidx/recyclerview/widget/mjFkc;->AZxh:Ljava/util/ArrayList;

    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/mjFkc;->diqgf(Ljava/util/List;)V

    iput v1, p0, Landroidx/recyclerview/widget/mjFkc;->lgHUyS:I

    return-void
.end method

.method public final ETF(Landroidx/recyclerview/widget/mjFkc$AZxh;)V
    .locals 11

    iget v0, p1, Landroidx/recyclerview/widget/mjFkc$AZxh;->mjFkc:I

    const/4 v1, 0x1

    if-eq v0, v1, :cond_8

    const/16 v2, 0x8

    if-eq v0, v2, :cond_8

    iget v2, p1, Landroidx/recyclerview/widget/mjFkc$AZxh;->AZxh:I

    invoke-virtual {p0, v2, v0}, Landroidx/recyclerview/widget/mjFkc;->Ucbh(II)I

    move-result v0

    iget v2, p1, Landroidx/recyclerview/widget/mjFkc$AZxh;->AZxh:I

    iget v3, p1, Landroidx/recyclerview/widget/mjFkc$AZxh;->mjFkc:I

    const/4 v4, 0x2

    const/4 v5, 0x4

    if-eq v3, v4, :cond_1

    if-ne v3, v5, :cond_0

    move v3, v1

    goto :goto_0

    :cond_0
    new-instance p0, Ljava/lang/IllegalArgumentException;

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "op should be remove or update."

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_1
    const/4 v3, 0x0

    :goto_0
    move v6, v1

    move v7, v6

    :goto_1
    iget v8, p1, Landroidx/recyclerview/widget/mjFkc$AZxh;->ZfxDd:I

    if-ge v6, v8, :cond_6

    iget v8, p1, Landroidx/recyclerview/widget/mjFkc$AZxh;->AZxh:I

    mul-int v9, v3, v6

    add-int/2addr v8, v9

    iget v9, p1, Landroidx/recyclerview/widget/mjFkc$AZxh;->mjFkc:I

    invoke-virtual {p0, v8, v9}, Landroidx/recyclerview/widget/mjFkc;->Ucbh(II)I

    move-result v8

    iget v9, p1, Landroidx/recyclerview/widget/mjFkc$AZxh;->mjFkc:I

    if-eq v9, v4, :cond_3

    if-eq v9, v5, :cond_2

    goto :goto_3

    :cond_2
    add-int/lit8 v10, v0, 0x1

    if-ne v8, v10, :cond_4

    goto :goto_2

    :cond_3
    if-ne v8, v0, :cond_4

    :goto_2
    add-int/lit8 v7, v7, 0x1

    goto :goto_4

    :cond_4
    :goto_3
    iget-object v10, p1, Landroidx/recyclerview/widget/mjFkc$AZxh;->wA:Ljava/lang/Object;

    invoke-virtual {p0, v9, v0, v7, v10}, Landroidx/recyclerview/widget/mjFkc;->AZxh(IIILjava/lang/Object;)Landroidx/recyclerview/widget/mjFkc$AZxh;

    move-result-object v0

    invoke-virtual {p0, v0, v2}, Landroidx/recyclerview/widget/mjFkc;->VA(Landroidx/recyclerview/widget/mjFkc$AZxh;I)V

    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/mjFkc;->mjFkc(Landroidx/recyclerview/widget/mjFkc$AZxh;)V

    iget v0, p1, Landroidx/recyclerview/widget/mjFkc$AZxh;->mjFkc:I

    if-ne v0, v5, :cond_5

    add-int/2addr v2, v7

    :cond_5
    move v7, v1

    move v0, v8

    :goto_4
    add-int/lit8 v6, v6, 0x1

    goto :goto_1

    :cond_6
    iget-object v1, p1, Landroidx/recyclerview/widget/mjFkc$AZxh;->wA:Ljava/lang/Object;

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/mjFkc;->mjFkc(Landroidx/recyclerview/widget/mjFkc$AZxh;)V

    if-lez v7, :cond_7

    iget p1, p1, Landroidx/recyclerview/widget/mjFkc$AZxh;->mjFkc:I

    invoke-virtual {p0, p1, v0, v7, v1}, Landroidx/recyclerview/widget/mjFkc;->AZxh(IIILjava/lang/Object;)Landroidx/recyclerview/widget/mjFkc$AZxh;

    move-result-object p1

    invoke-virtual {p0, p1, v2}, Landroidx/recyclerview/widget/mjFkc;->VA(Landroidx/recyclerview/widget/mjFkc$AZxh;I)V

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/mjFkc;->mjFkc(Landroidx/recyclerview/widget/mjFkc$AZxh;)V

    :cond_7
    return-void

    :cond_8
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string p1, "should not dispatch add or move for pre layout"

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public final IEE(Landroidx/recyclerview/widget/mjFkc$AZxh;)V
    .locals 2

    iget-object v0, p0, Landroidx/recyclerview/widget/mjFkc;->wA:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget v0, p1, Landroidx/recyclerview/widget/mjFkc$AZxh;->mjFkc:I

    const/4 v1, 0x1

    if-eq v0, v1, :cond_3

    const/4 v1, 0x2

    if-eq v0, v1, :cond_2

    const/4 v1, 0x4

    if-eq v0, v1, :cond_1

    const/16 v1, 0x8

    if-ne v0, v1, :cond_0

    iget-object p0, p0, Landroidx/recyclerview/widget/mjFkc;->ZfxDd:Landroidx/recyclerview/widget/mjFkc$mjFkc;

    iget v0, p1, Landroidx/recyclerview/widget/mjFkc$AZxh;->AZxh:I

    iget p1, p1, Landroidx/recyclerview/widget/mjFkc$AZxh;->ZfxDd:I

    invoke-interface {p0, v0, p1}, Landroidx/recyclerview/widget/mjFkc$mjFkc;->mjFkc(II)V

    goto :goto_0

    :cond_0
    new-instance p0, Ljava/lang/IllegalArgumentException;

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "Unknown update op type for "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_1
    iget-object p0, p0, Landroidx/recyclerview/widget/mjFkc;->ZfxDd:Landroidx/recyclerview/widget/mjFkc$mjFkc;

    iget v0, p1, Landroidx/recyclerview/widget/mjFkc$AZxh;->AZxh:I

    iget v1, p1, Landroidx/recyclerview/widget/mjFkc$AZxh;->ZfxDd:I

    iget-object p1, p1, Landroidx/recyclerview/widget/mjFkc$AZxh;->wA:Ljava/lang/Object;

    invoke-interface {p0, v0, v1, p1}, Landroidx/recyclerview/widget/mjFkc$mjFkc;->lgHUyS(IILjava/lang/Object;)V

    goto :goto_0

    :cond_2
    iget-object p0, p0, Landroidx/recyclerview/widget/mjFkc;->ZfxDd:Landroidx/recyclerview/widget/mjFkc$mjFkc;

    iget v0, p1, Landroidx/recyclerview/widget/mjFkc$AZxh;->AZxh:I

    iget p1, p1, Landroidx/recyclerview/widget/mjFkc$AZxh;->ZfxDd:I

    invoke-interface {p0, v0, p1}, Landroidx/recyclerview/widget/mjFkc$mjFkc;->ZfxDd(II)V

    goto :goto_0

    :cond_3
    iget-object p0, p0, Landroidx/recyclerview/widget/mjFkc;->ZfxDd:Landroidx/recyclerview/widget/mjFkc$mjFkc;

    iget v0, p1, Landroidx/recyclerview/widget/mjFkc$AZxh;->AZxh:I

    iget p1, p1, Landroidx/recyclerview/widget/mjFkc$AZxh;->ZfxDd:I

    invoke-interface {p0, v0, p1}, Landroidx/recyclerview/widget/mjFkc$mjFkc;->KLFTb(II)V

    :goto_0
    return-void
.end method

.method public final JHa(Landroidx/recyclerview/widget/mjFkc$AZxh;)V
    .locals 10

    iget v0, p1, Landroidx/recyclerview/widget/mjFkc$AZxh;->AZxh:I

    iget v1, p1, Landroidx/recyclerview/widget/mjFkc$AZxh;->ZfxDd:I

    add-int/2addr v1, v0

    const/4 v2, 0x0

    const/4 v3, -0x1

    move v4, v0

    move v5, v2

    :goto_0
    const/4 v6, 0x0

    const/4 v7, 0x2

    if-ge v4, v1, :cond_5

    iget-object v8, p0, Landroidx/recyclerview/widget/mjFkc;->ZfxDd:Landroidx/recyclerview/widget/mjFkc$mjFkc;

    invoke-interface {v8, v4}, Landroidx/recyclerview/widget/mjFkc$mjFkc;->wA(I)Landroidx/recyclerview/widget/RecyclerView$mByQ;

    move-result-object v8

    const/4 v9, 0x1

    if-nez v8, :cond_2

    invoke-virtual {p0, v4}, Landroidx/recyclerview/widget/mjFkc;->lgHUyS(I)Z

    move-result v8

    if-eqz v8, :cond_0

    goto :goto_2

    :cond_0
    if-ne v3, v9, :cond_1

    invoke-virtual {p0, v7, v0, v5, v6}, Landroidx/recyclerview/widget/mjFkc;->AZxh(IIILjava/lang/Object;)Landroidx/recyclerview/widget/mjFkc$AZxh;

    move-result-object v3

    invoke-virtual {p0, v3}, Landroidx/recyclerview/widget/mjFkc;->IEE(Landroidx/recyclerview/widget/mjFkc$AZxh;)V

    move v3, v9

    goto :goto_1

    :cond_1
    move v3, v2

    :goto_1
    move v6, v2

    goto :goto_4

    :cond_2
    :goto_2
    if-nez v3, :cond_3

    invoke-virtual {p0, v7, v0, v5, v6}, Landroidx/recyclerview/widget/mjFkc;->AZxh(IIILjava/lang/Object;)Landroidx/recyclerview/widget/mjFkc$AZxh;

    move-result-object v3

    invoke-virtual {p0, v3}, Landroidx/recyclerview/widget/mjFkc;->ETF(Landroidx/recyclerview/widget/mjFkc$AZxh;)V

    move v3, v9

    goto :goto_3

    :cond_3
    move v3, v2

    :goto_3
    move v6, v9

    :goto_4
    if-eqz v3, :cond_4

    sub-int/2addr v4, v5

    sub-int/2addr v1, v5

    move v5, v9

    goto :goto_5

    :cond_4
    add-int/lit8 v5, v5, 0x1

    :goto_5
    add-int/2addr v4, v9

    move v3, v6

    goto :goto_0

    :cond_5
    iget v1, p1, Landroidx/recyclerview/widget/mjFkc$AZxh;->ZfxDd:I

    if-eq v5, v1, :cond_6

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/mjFkc;->mjFkc(Landroidx/recyclerview/widget/mjFkc$AZxh;)V

    invoke-virtual {p0, v7, v0, v5, v6}, Landroidx/recyclerview/widget/mjFkc;->AZxh(IIILjava/lang/Object;)Landroidx/recyclerview/widget/mjFkc$AZxh;

    move-result-object p1

    :cond_6
    if-nez v3, :cond_7

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/mjFkc;->ETF(Landroidx/recyclerview/widget/mjFkc$AZxh;)V

    goto :goto_6

    :cond_7
    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/mjFkc;->IEE(Landroidx/recyclerview/widget/mjFkc$AZxh;)V

    :goto_6
    return-void
.end method

.method public KLFTb(I)I
    .locals 5

    iget-object v0, p0, Landroidx/recyclerview/widget/mjFkc;->AZxh:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v1, 0x0

    :goto_0
    if-ge v1, v0, :cond_7

    iget-object v2, p0, Landroidx/recyclerview/widget/mjFkc;->AZxh:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroidx/recyclerview/widget/mjFkc$AZxh;

    iget v3, v2, Landroidx/recyclerview/widget/mjFkc$AZxh;->mjFkc:I

    const/4 v4, 0x1

    if-eq v3, v4, :cond_5

    const/4 v4, 0x2

    if-eq v3, v4, :cond_3

    const/16 v4, 0x8

    if-eq v3, v4, :cond_0

    goto :goto_1

    :cond_0
    iget v3, v2, Landroidx/recyclerview/widget/mjFkc$AZxh;->AZxh:I

    if-ne v3, p1, :cond_1

    iget p1, v2, Landroidx/recyclerview/widget/mjFkc$AZxh;->ZfxDd:I

    goto :goto_1

    :cond_1
    if-ge v3, p1, :cond_2

    add-int/lit8 p1, p1, -0x1

    :cond_2
    iget v2, v2, Landroidx/recyclerview/widget/mjFkc$AZxh;->ZfxDd:I

    if-gt v2, p1, :cond_6

    add-int/lit8 p1, p1, 0x1

    goto :goto_1

    :cond_3
    iget v3, v2, Landroidx/recyclerview/widget/mjFkc$AZxh;->AZxh:I

    if-gt v3, p1, :cond_6

    iget v2, v2, Landroidx/recyclerview/widget/mjFkc$AZxh;->ZfxDd:I

    add-int/2addr v3, v2

    if-le v3, p1, :cond_4

    const/4 p0, -0x1

    return p0

    :cond_4
    sub-int/2addr p1, v2

    goto :goto_1

    :cond_5
    iget v3, v2, Landroidx/recyclerview/widget/mjFkc$AZxh;->AZxh:I

    if-gt v3, p1, :cond_6

    iget v2, v2, Landroidx/recyclerview/widget/mjFkc$AZxh;->ZfxDd:I

    add-int/2addr p1, v2

    :cond_6
    :goto_1
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_7
    return p1
.end method

.method public MiMN(I)I
    .locals 1

    const/4 v0, 0x0

    invoke-virtual {p0, p1, v0}, Landroidx/recyclerview/widget/mjFkc;->YoKzxo(II)I

    move-result p0

    return p0
.end method

.method public Pq()V
    .locals 5

    iget-object v0, p0, Landroidx/recyclerview/widget/mjFkc;->xJ:Landroidx/recyclerview/widget/lgHUyS;

    iget-object v1, p0, Landroidx/recyclerview/widget/mjFkc;->AZxh:Ljava/util/ArrayList;

    invoke-virtual {v0, v1}, Landroidx/recyclerview/widget/lgHUyS;->AZxh(Ljava/util/List;)V

    iget-object v0, p0, Landroidx/recyclerview/widget/mjFkc;->AZxh:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v1, 0x0

    :goto_0
    if-ge v1, v0, :cond_5

    iget-object v2, p0, Landroidx/recyclerview/widget/mjFkc;->AZxh:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroidx/recyclerview/widget/mjFkc$AZxh;

    iget v3, v2, Landroidx/recyclerview/widget/mjFkc$AZxh;->mjFkc:I

    const/4 v4, 0x1

    if-eq v3, v4, :cond_3

    const/4 v4, 0x2

    if-eq v3, v4, :cond_2

    const/4 v4, 0x4

    if-eq v3, v4, :cond_1

    const/16 v4, 0x8

    if-eq v3, v4, :cond_0

    goto :goto_1

    :cond_0
    invoke-virtual {p0, v2}, Landroidx/recyclerview/widget/mjFkc;->ZfxDd(Landroidx/recyclerview/widget/mjFkc$AZxh;)V

    goto :goto_1

    :cond_1
    invoke-virtual {p0, v2}, Landroidx/recyclerview/widget/mjFkc;->xJ(Landroidx/recyclerview/widget/mjFkc$AZxh;)V

    goto :goto_1

    :cond_2
    invoke-virtual {p0, v2}, Landroidx/recyclerview/widget/mjFkc;->JHa(Landroidx/recyclerview/widget/mjFkc$AZxh;)V

    goto :goto_1

    :cond_3
    invoke-virtual {p0, v2}, Landroidx/recyclerview/widget/mjFkc;->wA(Landroidx/recyclerview/widget/mjFkc$AZxh;)V

    :goto_1
    iget-object v2, p0, Landroidx/recyclerview/widget/mjFkc;->KLFTb:Ljava/lang/Runnable;

    if-eqz v2, :cond_4

    invoke-interface {v2}, Ljava/lang/Runnable;->run()V

    :cond_4
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_5
    iget-object p0, p0, Landroidx/recyclerview/widget/mjFkc;->AZxh:Ljava/util/ArrayList;

    invoke-virtual {p0}, Ljava/util/ArrayList;->clear()V

    return-void
.end method

.method public final Ucbh(II)I
    .locals 8

    iget-object v0, p0, Landroidx/recyclerview/widget/mjFkc;->wA:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v1, 0x1

    sub-int/2addr v0, v1

    :goto_0
    const/16 v2, 0x8

    if-ltz v0, :cond_d

    iget-object v3, p0, Landroidx/recyclerview/widget/mjFkc;->wA:Ljava/util/ArrayList;

    invoke-virtual {v3, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroidx/recyclerview/widget/mjFkc$AZxh;

    iget v4, v3, Landroidx/recyclerview/widget/mjFkc$AZxh;->mjFkc:I

    const/4 v5, 0x2

    if-ne v4, v2, :cond_8

    iget v2, v3, Landroidx/recyclerview/widget/mjFkc$AZxh;->AZxh:I

    iget v4, v3, Landroidx/recyclerview/widget/mjFkc$AZxh;->ZfxDd:I

    if-ge v2, v4, :cond_0

    move v6, v2

    move v7, v4

    goto :goto_1

    :cond_0
    move v7, v2

    move v6, v4

    :goto_1
    if-lt p1, v6, :cond_6

    if-gt p1, v7, :cond_6

    if-ne v6, v2, :cond_3

    if-ne p2, v1, :cond_1

    add-int/lit8 v4, v4, 0x1

    iput v4, v3, Landroidx/recyclerview/widget/mjFkc$AZxh;->ZfxDd:I

    goto :goto_2

    :cond_1
    if-ne p2, v5, :cond_2

    add-int/lit8 v4, v4, -0x1

    iput v4, v3, Landroidx/recyclerview/widget/mjFkc$AZxh;->ZfxDd:I

    :cond_2
    :goto_2
    add-int/lit8 p1, p1, 0x1

    goto :goto_4

    :cond_3
    if-ne p2, v1, :cond_4

    add-int/lit8 v2, v2, 0x1

    iput v2, v3, Landroidx/recyclerview/widget/mjFkc$AZxh;->AZxh:I

    goto :goto_3

    :cond_4
    if-ne p2, v5, :cond_5

    add-int/lit8 v2, v2, -0x1

    iput v2, v3, Landroidx/recyclerview/widget/mjFkc$AZxh;->AZxh:I

    :cond_5
    :goto_3
    add-int/lit8 p1, p1, -0x1

    goto :goto_4

    :cond_6
    if-ge p1, v2, :cond_c

    if-ne p2, v1, :cond_7

    add-int/lit8 v2, v2, 0x1

    iput v2, v3, Landroidx/recyclerview/widget/mjFkc$AZxh;->AZxh:I

    add-int/lit8 v4, v4, 0x1

    iput v4, v3, Landroidx/recyclerview/widget/mjFkc$AZxh;->ZfxDd:I

    goto :goto_4

    :cond_7
    if-ne p2, v5, :cond_c

    add-int/lit8 v2, v2, -0x1

    iput v2, v3, Landroidx/recyclerview/widget/mjFkc$AZxh;->AZxh:I

    add-int/lit8 v4, v4, -0x1

    iput v4, v3, Landroidx/recyclerview/widget/mjFkc$AZxh;->ZfxDd:I

    goto :goto_4

    :cond_8
    iget v2, v3, Landroidx/recyclerview/widget/mjFkc$AZxh;->AZxh:I

    if-gt v2, p1, :cond_a

    if-ne v4, v1, :cond_9

    iget v2, v3, Landroidx/recyclerview/widget/mjFkc$AZxh;->ZfxDd:I

    sub-int/2addr p1, v2

    goto :goto_4

    :cond_9
    if-ne v4, v5, :cond_c

    iget v2, v3, Landroidx/recyclerview/widget/mjFkc$AZxh;->ZfxDd:I

    add-int/2addr p1, v2

    goto :goto_4

    :cond_a
    if-ne p2, v1, :cond_b

    add-int/lit8 v2, v2, 0x1

    iput v2, v3, Landroidx/recyclerview/widget/mjFkc$AZxh;->AZxh:I

    goto :goto_4

    :cond_b
    if-ne p2, v5, :cond_c

    add-int/lit8 v2, v2, -0x1

    iput v2, v3, Landroidx/recyclerview/widget/mjFkc$AZxh;->AZxh:I

    :cond_c
    :goto_4
    add-int/lit8 v0, v0, -0x1

    goto :goto_0

    :cond_d
    iget-object p2, p0, Landroidx/recyclerview/widget/mjFkc;->wA:Ljava/util/ArrayList;

    invoke-virtual {p2}, Ljava/util/ArrayList;->size()I

    move-result p2

    sub-int/2addr p2, v1

    :goto_5
    if-ltz p2, :cond_11

    iget-object v0, p0, Landroidx/recyclerview/widget/mjFkc;->wA:Ljava/util/ArrayList;

    invoke-virtual {v0, p2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroidx/recyclerview/widget/mjFkc$AZxh;

    iget v1, v0, Landroidx/recyclerview/widget/mjFkc$AZxh;->mjFkc:I

    if-ne v1, v2, :cond_f

    iget v1, v0, Landroidx/recyclerview/widget/mjFkc$AZxh;->ZfxDd:I

    iget v3, v0, Landroidx/recyclerview/widget/mjFkc$AZxh;->AZxh:I

    if-eq v1, v3, :cond_e

    if-gez v1, :cond_10

    :cond_e
    iget-object v1, p0, Landroidx/recyclerview/widget/mjFkc;->wA:Ljava/util/ArrayList;

    invoke-virtual {v1, p2}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/mjFkc;->mjFkc(Landroidx/recyclerview/widget/mjFkc$AZxh;)V

    goto :goto_6

    :cond_f
    iget v1, v0, Landroidx/recyclerview/widget/mjFkc$AZxh;->ZfxDd:I

    if-gtz v1, :cond_10

    iget-object v1, p0, Landroidx/recyclerview/widget/mjFkc;->wA:Ljava/util/ArrayList;

    invoke-virtual {v1, p2}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/mjFkc;->mjFkc(Landroidx/recyclerview/widget/mjFkc$AZxh;)V

    :cond_10
    :goto_6
    add-int/lit8 p2, p2, -0x1

    goto :goto_5

    :cond_11
    return p1
.end method

.method public VA(Landroidx/recyclerview/widget/mjFkc$AZxh;I)V
    .locals 2

    iget-object v0, p0, Landroidx/recyclerview/widget/mjFkc;->ZfxDd:Landroidx/recyclerview/widget/mjFkc$mjFkc;

    invoke-interface {v0, p1}, Landroidx/recyclerview/widget/mjFkc$mjFkc;->xJ(Landroidx/recyclerview/widget/mjFkc$AZxh;)V

    iget v0, p1, Landroidx/recyclerview/widget/mjFkc$AZxh;->mjFkc:I

    const/4 v1, 0x2

    if-eq v0, v1, :cond_1

    const/4 v1, 0x4

    if-ne v0, v1, :cond_0

    iget-object p0, p0, Landroidx/recyclerview/widget/mjFkc;->ZfxDd:Landroidx/recyclerview/widget/mjFkc$mjFkc;

    iget v0, p1, Landroidx/recyclerview/widget/mjFkc$AZxh;->ZfxDd:I

    iget-object p1, p1, Landroidx/recyclerview/widget/mjFkc$AZxh;->wA:Ljava/lang/Object;

    invoke-interface {p0, p2, v0, p1}, Landroidx/recyclerview/widget/mjFkc$mjFkc;->lgHUyS(IILjava/lang/Object;)V

    goto :goto_0

    :cond_0
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string p1, "only remove and update ops can be dispatched in first pass"

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_1
    iget-object p0, p0, Landroidx/recyclerview/widget/mjFkc;->ZfxDd:Landroidx/recyclerview/widget/mjFkc$mjFkc;

    iget p1, p1, Landroidx/recyclerview/widget/mjFkc$AZxh;->ZfxDd:I

    invoke-interface {p0, p2, p1}, Landroidx/recyclerview/widget/mjFkc$mjFkc;->JHa(II)V

    :goto_0
    return-void
.end method

.method public YoKzxo(II)I
    .locals 5

    iget-object v0, p0, Landroidx/recyclerview/widget/mjFkc;->wA:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    :goto_0
    if-ge p2, v0, :cond_6

    iget-object v1, p0, Landroidx/recyclerview/widget/mjFkc;->wA:Ljava/util/ArrayList;

    invoke-virtual {v1, p2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroidx/recyclerview/widget/mjFkc$AZxh;

    iget v2, v1, Landroidx/recyclerview/widget/mjFkc$AZxh;->mjFkc:I

    const/16 v3, 0x8

    if-ne v2, v3, :cond_2

    iget v2, v1, Landroidx/recyclerview/widget/mjFkc$AZxh;->AZxh:I

    if-ne v2, p1, :cond_0

    iget p1, v1, Landroidx/recyclerview/widget/mjFkc$AZxh;->ZfxDd:I

    goto :goto_1

    :cond_0
    if-ge v2, p1, :cond_1

    add-int/lit8 p1, p1, -0x1

    :cond_1
    iget v1, v1, Landroidx/recyclerview/widget/mjFkc$AZxh;->ZfxDd:I

    if-gt v1, p1, :cond_5

    add-int/lit8 p1, p1, 0x1

    goto :goto_1

    :cond_2
    iget v3, v1, Landroidx/recyclerview/widget/mjFkc$AZxh;->AZxh:I

    if-gt v3, p1, :cond_5

    const/4 v4, 0x2

    if-ne v2, v4, :cond_4

    iget v1, v1, Landroidx/recyclerview/widget/mjFkc$AZxh;->ZfxDd:I

    add-int/2addr v3, v1

    if-ge p1, v3, :cond_3

    const/4 p0, -0x1

    return p0

    :cond_3
    sub-int/2addr p1, v1

    goto :goto_1

    :cond_4
    const/4 v3, 0x1

    if-ne v2, v3, :cond_5

    iget v1, v1, Landroidx/recyclerview/widget/mjFkc$AZxh;->ZfxDd:I

    add-int/2addr p1, v1

    :cond_5
    :goto_1
    add-int/lit8 p2, p2, 0x1

    goto :goto_0

    :cond_6
    return p1
.end method

.method public final ZfxDd(Landroidx/recyclerview/widget/mjFkc$AZxh;)V
    .locals 0

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/mjFkc;->IEE(Landroidx/recyclerview/widget/mjFkc$AZxh;)V

    return-void
.end method

.method public diqgf(Ljava/util/List;)V
    .locals 3

    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v0

    const/4 v1, 0x0

    :goto_0
    if-ge v1, v0, :cond_0

    invoke-interface {p1, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroidx/recyclerview/widget/mjFkc$AZxh;

    invoke-virtual {p0, v2}, Landroidx/recyclerview/widget/mjFkc;->mjFkc(Landroidx/recyclerview/widget/mjFkc$AZxh;)V

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_0
    invoke-interface {p1}, Ljava/util/List;->clear()V

    return-void
.end method

.method public eyqo()V
    .locals 1

    iget-object v0, p0, Landroidx/recyclerview/widget/mjFkc;->AZxh:Ljava/util/ArrayList;

    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/mjFkc;->diqgf(Ljava/util/List;)V

    iget-object v0, p0, Landroidx/recyclerview/widget/mjFkc;->wA:Ljava/util/ArrayList;

    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/mjFkc;->diqgf(Ljava/util/List;)V

    const/4 v0, 0x0

    iput v0, p0, Landroidx/recyclerview/widget/mjFkc;->lgHUyS:I

    return-void
.end method

.method public fehf()Z
    .locals 1

    iget-object v0, p0, Landroidx/recyclerview/widget/mjFkc;->wA:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_0

    iget-object p0, p0, Landroidx/recyclerview/widget/mjFkc;->AZxh:Ljava/util/ArrayList;

    invoke-virtual {p0}, Ljava/util/ArrayList;->isEmpty()Z

    move-result p0

    if-nez p0, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method

.method public final lgHUyS(I)Z
    .locals 7

    iget-object v0, p0, Landroidx/recyclerview/widget/mjFkc;->wA:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v1, 0x0

    move v2, v1

    :goto_0
    if-ge v2, v0, :cond_3

    iget-object v3, p0, Landroidx/recyclerview/widget/mjFkc;->wA:Ljava/util/ArrayList;

    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroidx/recyclerview/widget/mjFkc$AZxh;

    iget v4, v3, Landroidx/recyclerview/widget/mjFkc$AZxh;->mjFkc:I

    const/16 v5, 0x8

    const/4 v6, 0x1

    if-ne v4, v5, :cond_0

    iget v3, v3, Landroidx/recyclerview/widget/mjFkc$AZxh;->ZfxDd:I

    add-int/lit8 v4, v2, 0x1

    invoke-virtual {p0, v3, v4}, Landroidx/recyclerview/widget/mjFkc;->YoKzxo(II)I

    move-result v3

    if-ne v3, p1, :cond_2

    return v6

    :cond_0
    if-ne v4, v6, :cond_2

    iget v4, v3, Landroidx/recyclerview/widget/mjFkc$AZxh;->AZxh:I

    iget v3, v3, Landroidx/recyclerview/widget/mjFkc$AZxh;->ZfxDd:I

    add-int/2addr v3, v4

    :goto_1
    if-ge v4, v3, :cond_2

    add-int/lit8 v5, v2, 0x1

    invoke-virtual {p0, v4, v5}, Landroidx/recyclerview/widget/mjFkc;->YoKzxo(II)I

    move-result v5

    if-ne v5, p1, :cond_1

    return v6

    :cond_1
    add-int/lit8 v4, v4, 0x1

    goto :goto_1

    :cond_2
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_3
    return v1
.end method

.method public mjFkc(Landroidx/recyclerview/widget/mjFkc$AZxh;)V
    .locals 1

    iget-boolean v0, p0, Landroidx/recyclerview/widget/mjFkc;->JHa:Z

    if-nez v0, :cond_0

    const/4 v0, 0x0

    iput-object v0, p1, Landroidx/recyclerview/widget/mjFkc$AZxh;->wA:Ljava/lang/Object;

    iget-object p0, p0, Landroidx/recyclerview/widget/mjFkc;->mjFkc:Lo/A3;

    invoke-interface {p0, p1}, Lo/A3;->mjFkc(Ljava/lang/Object;)Z

    :cond_0
    return-void
.end method

.method public qGY()Z
    .locals 0

    iget-object p0, p0, Landroidx/recyclerview/widget/mjFkc;->AZxh:Ljava/util/ArrayList;

    invoke-virtual {p0}, Ljava/util/ArrayList;->size()I

    move-result p0

    if-lez p0, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method

.method public qdMbNW()V
    .locals 5

    iget-object v0, p0, Landroidx/recyclerview/widget/mjFkc;->wA:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v1, 0x0

    move v2, v1

    :goto_0
    if-ge v2, v0, :cond_0

    iget-object v3, p0, Landroidx/recyclerview/widget/mjFkc;->ZfxDd:Landroidx/recyclerview/widget/mjFkc$mjFkc;

    iget-object v4, p0, Landroidx/recyclerview/widget/mjFkc;->wA:Ljava/util/ArrayList;

    invoke-virtual {v4, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Landroidx/recyclerview/widget/mjFkc$AZxh;

    invoke-interface {v3, v4}, Landroidx/recyclerview/widget/mjFkc$mjFkc;->AZxh(Landroidx/recyclerview/widget/mjFkc$AZxh;)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_0
    iget-object v0, p0, Landroidx/recyclerview/widget/mjFkc;->wA:Ljava/util/ArrayList;

    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/mjFkc;->diqgf(Ljava/util/List;)V

    iput v1, p0, Landroidx/recyclerview/widget/mjFkc;->lgHUyS:I

    return-void
.end method

.method public rkYL(I)Z
    .locals 0

    iget p0, p0, Landroidx/recyclerview/widget/mjFkc;->lgHUyS:I

    and-int/2addr p0, p1

    if-eqz p0, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method

.method public final wA(Landroidx/recyclerview/widget/mjFkc$AZxh;)V
    .locals 0

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/mjFkc;->IEE(Landroidx/recyclerview/widget/mjFkc$AZxh;)V

    return-void
.end method

.method public final xJ(Landroidx/recyclerview/widget/mjFkc$AZxh;)V
    .locals 9

    iget v0, p1, Landroidx/recyclerview/widget/mjFkc$AZxh;->AZxh:I

    iget v1, p1, Landroidx/recyclerview/widget/mjFkc$AZxh;->ZfxDd:I

    add-int/2addr v1, v0

    const/4 v2, 0x0

    const/4 v3, -0x1

    move v5, v2

    move v4, v3

    move v3, v0

    :goto_0
    const/4 v6, 0x4

    if-ge v0, v1, :cond_4

    iget-object v7, p0, Landroidx/recyclerview/widget/mjFkc;->ZfxDd:Landroidx/recyclerview/widget/mjFkc$mjFkc;

    invoke-interface {v7, v0}, Landroidx/recyclerview/widget/mjFkc$mjFkc;->wA(I)Landroidx/recyclerview/widget/RecyclerView$mByQ;

    move-result-object v7

    const/4 v8, 0x1

    if-nez v7, :cond_2

    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/mjFkc;->lgHUyS(I)Z

    move-result v7

    if-eqz v7, :cond_0

    goto :goto_1

    :cond_0
    if-ne v4, v8, :cond_1

    iget-object v4, p1, Landroidx/recyclerview/widget/mjFkc$AZxh;->wA:Ljava/lang/Object;

    invoke-virtual {p0, v6, v3, v5, v4}, Landroidx/recyclerview/widget/mjFkc;->AZxh(IIILjava/lang/Object;)Landroidx/recyclerview/widget/mjFkc$AZxh;

    move-result-object v3

    invoke-virtual {p0, v3}, Landroidx/recyclerview/widget/mjFkc;->IEE(Landroidx/recyclerview/widget/mjFkc$AZxh;)V

    move v3, v0

    move v5, v2

    :cond_1
    move v4, v2

    goto :goto_2

    :cond_2
    :goto_1
    if-nez v4, :cond_3

    iget-object v4, p1, Landroidx/recyclerview/widget/mjFkc$AZxh;->wA:Ljava/lang/Object;

    invoke-virtual {p0, v6, v3, v5, v4}, Landroidx/recyclerview/widget/mjFkc;->AZxh(IIILjava/lang/Object;)Landroidx/recyclerview/widget/mjFkc$AZxh;

    move-result-object v3

    invoke-virtual {p0, v3}, Landroidx/recyclerview/widget/mjFkc;->ETF(Landroidx/recyclerview/widget/mjFkc$AZxh;)V

    move v3, v0

    move v5, v2

    :cond_3
    move v4, v8

    :goto_2
    add-int/2addr v5, v8

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_4
    iget v0, p1, Landroidx/recyclerview/widget/mjFkc$AZxh;->ZfxDd:I

    if-eq v5, v0, :cond_5

    iget-object v0, p1, Landroidx/recyclerview/widget/mjFkc$AZxh;->wA:Ljava/lang/Object;

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/mjFkc;->mjFkc(Landroidx/recyclerview/widget/mjFkc$AZxh;)V

    invoke-virtual {p0, v6, v3, v5, v0}, Landroidx/recyclerview/widget/mjFkc;->AZxh(IIILjava/lang/Object;)Landroidx/recyclerview/widget/mjFkc$AZxh;

    move-result-object p1

    :cond_5
    if-nez v4, :cond_6

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/mjFkc;->ETF(Landroidx/recyclerview/widget/mjFkc$AZxh;)V

    goto :goto_3

    :cond_6
    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/mjFkc;->IEE(Landroidx/recyclerview/widget/mjFkc$AZxh;)V

    :goto_3
    return-void
.end method
