.class public final enum Landroidx/recyclerview/widget/RecyclerView$lgHUyS$mjFkc;
.super Ljava/lang/Enum;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/recyclerview/widget/RecyclerView$lgHUyS;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4019
    name = "mjFkc"
.end annotation


# static fields
.field public static final enum AZxh:Landroidx/recyclerview/widget/RecyclerView$lgHUyS$mjFkc;

.field public static final synthetic ZfxDd:[Landroidx/recyclerview/widget/RecyclerView$lgHUyS$mjFkc;

.field public static final enum mjFkc:Landroidx/recyclerview/widget/RecyclerView$lgHUyS$mjFkc;

.field public static final enum wA:Landroidx/recyclerview/widget/RecyclerView$lgHUyS$mjFkc;


# direct methods
.method static constructor <clinit>()V
    .locals 5

    new-instance v0, Landroidx/recyclerview/widget/RecyclerView$lgHUyS$mjFkc;

    const-string v1, "ALLOW"

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2}, Landroidx/recyclerview/widget/RecyclerView$lgHUyS$mjFkc;-><init>(Ljava/lang/String;I)V

    sput-object v0, Landroidx/recyclerview/widget/RecyclerView$lgHUyS$mjFkc;->mjFkc:Landroidx/recyclerview/widget/RecyclerView$lgHUyS$mjFkc;

    new-instance v1, Landroidx/recyclerview/widget/RecyclerView$lgHUyS$mjFkc;

    const-string v2, "PREVENT_WHEN_EMPTY"

    const/4 v3, 0x1

    invoke-direct {v1, v2, v3}, Landroidx/recyclerview/widget/RecyclerView$lgHUyS$mjFkc;-><init>(Ljava/lang/String;I)V

    sput-object v1, Landroidx/recyclerview/widget/RecyclerView$lgHUyS$mjFkc;->AZxh:Landroidx/recyclerview/widget/RecyclerView$lgHUyS$mjFkc;

    new-instance v2, Landroidx/recyclerview/widget/RecyclerView$lgHUyS$mjFkc;

    const-string v3, "PREVENT"

    const/4 v4, 0x2

    invoke-direct {v2, v3, v4}, Landroidx/recyclerview/widget/RecyclerView$lgHUyS$mjFkc;-><init>(Ljava/lang/String;I)V

    sput-object v2, Landroidx/recyclerview/widget/RecyclerView$lgHUyS$mjFkc;->wA:Landroidx/recyclerview/widget/RecyclerView$lgHUyS$mjFkc;

    filled-new-array {v0, v1, v2}, [Landroidx/recyclerview/widget/RecyclerView$lgHUyS$mjFkc;

    move-result-object v0

    sput-object v0, Landroidx/recyclerview/widget/RecyclerView$lgHUyS$mjFkc;->ZfxDd:[Landroidx/recyclerview/widget/RecyclerView$lgHUyS$mjFkc;

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;I)V
    .locals 0

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    return-void
.end method

.method public static valueOf(Ljava/lang/String;)Landroidx/recyclerview/widget/RecyclerView$lgHUyS$mjFkc;
    .locals 1

    const-class v0, Landroidx/recyclerview/widget/RecyclerView$lgHUyS$mjFkc;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, Landroidx/recyclerview/widget/RecyclerView$lgHUyS$mjFkc;

    return-object p0
.end method

.method public static values()[Landroidx/recyclerview/widget/RecyclerView$lgHUyS$mjFkc;
    .locals 1

    sget-object v0, Landroidx/recyclerview/widget/RecyclerView$lgHUyS$mjFkc;->ZfxDd:[Landroidx/recyclerview/widget/RecyclerView$lgHUyS$mjFkc;

    invoke-virtual {v0}, [Landroidx/recyclerview/widget/RecyclerView$lgHUyS$mjFkc;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Landroidx/recyclerview/widget/RecyclerView$lgHUyS$mjFkc;

    return-object v0
.end method
