.class public Landroidx/recyclerview/widget/LinearLayoutManager$wA;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/recyclerview/widget/LinearLayoutManager;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "wA"
.end annotation


# instance fields
.field public AZxh:I

.field public Dt:Z

.field public ETF:I

.field public JHa:I

.field public KLFTb:I

.field public MiMN:Z

.field public VA:Ljava/util/List;

.field public ZfxDd:I

.field public lgHUyS:I

.field public mjFkc:Z

.field public qdMbNW:I

.field public wA:I

.field public xJ:I


# direct methods
.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x1

    iput-boolean v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->mjFkc:Z

    const/4 v0, 0x0

    iput v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->lgHUyS:I

    iput v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->qdMbNW:I

    iput-boolean v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->Dt:Z

    const/4 v0, 0x0

    iput-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->VA:Ljava/util/List;

    return-void
.end method


# virtual methods
.method public AZxh(Landroid/view/View;)V
    .locals 0

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->JHa(Landroid/view/View;)Landroid/view/View;

    move-result-object p1

    if-nez p1, :cond_0

    const/4 p1, -0x1

    iput p1, p0, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->ZfxDd:I

    goto :goto_0

    :cond_0
    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object p1

    check-cast p1, Landroidx/recyclerview/widget/RecyclerView$fehf;

    invoke-virtual {p1}, Landroidx/recyclerview/widget/RecyclerView$fehf;->mjFkc()I

    move-result p1

    iput p1, p0, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->ZfxDd:I

    :goto_0
    return-void
.end method

.method public JHa(Landroid/view/View;)Landroid/view/View;
    .locals 7

    iget-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->VA:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    const/4 v1, 0x0

    const v2, 0x7fffffff

    const/4 v3, 0x0

    :goto_0
    if-ge v3, v0, :cond_4

    iget-object v4, p0, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->VA:Ljava/util/List;

    invoke-interface {v4, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Landroidx/recyclerview/widget/RecyclerView$mByQ;

    iget-object v4, v4, Landroidx/recyclerview/widget/RecyclerView$mByQ;->mjFkc:Landroid/view/View;

    invoke-virtual {v4}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v5

    check-cast v5, Landroidx/recyclerview/widget/RecyclerView$fehf;

    if-eq v4, p1, :cond_3

    invoke-virtual {v5}, Landroidx/recyclerview/widget/RecyclerView$fehf;->wA()Z

    move-result v6

    if-eqz v6, :cond_0

    goto :goto_1

    :cond_0
    invoke-virtual {v5}, Landroidx/recyclerview/widget/RecyclerView$fehf;->mjFkc()I

    move-result v5

    iget v6, p0, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->ZfxDd:I

    sub-int/2addr v5, v6

    iget v6, p0, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->KLFTb:I

    mul-int/2addr v5, v6

    if-gez v5, :cond_1

    goto :goto_1

    :cond_1
    if-ge v5, v2, :cond_3

    move-object v1, v4

    if-nez v5, :cond_2

    goto :goto_2

    :cond_2
    move v2, v5

    :cond_3
    :goto_1
    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    :cond_4
    :goto_2
    return-object v1
.end method

.method public final KLFTb()Landroid/view/View;
    .locals 5

    iget-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->VA:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    const/4 v1, 0x0

    :goto_0
    if-ge v1, v0, :cond_2

    iget-object v2, p0, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->VA:Ljava/util/List;

    invoke-interface {v2, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroidx/recyclerview/widget/RecyclerView$mByQ;

    iget-object v2, v2, Landroidx/recyclerview/widget/RecyclerView$mByQ;->mjFkc:Landroid/view/View;

    invoke-virtual {v2}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v3

    check-cast v3, Landroidx/recyclerview/widget/RecyclerView$fehf;

    invoke-virtual {v3}, Landroidx/recyclerview/widget/RecyclerView$fehf;->wA()Z

    move-result v4

    if-eqz v4, :cond_0

    goto :goto_1

    :cond_0
    iget v4, p0, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->ZfxDd:I

    invoke-virtual {v3}, Landroidx/recyclerview/widget/RecyclerView$fehf;->mjFkc()I

    move-result v3

    if-ne v4, v3, :cond_1

    invoke-virtual {p0, v2}, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->AZxh(Landroid/view/View;)V

    return-object v2

    :cond_1
    :goto_1
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_2
    const/4 p0, 0x0

    return-object p0
.end method

.method public ZfxDd(Landroidx/recyclerview/widget/RecyclerView$Ucbh;)Landroid/view/View;
    .locals 2

    iget-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->VA:Ljava/util/List;

    if-eqz v0, :cond_0

    invoke-virtual {p0}, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->KLFTb()Landroid/view/View;

    move-result-object p0

    return-object p0

    :cond_0
    iget v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->ZfxDd:I

    invoke-virtual {p1, v0}, Landroidx/recyclerview/widget/RecyclerView$Ucbh;->rkYL(I)Landroid/view/View;

    move-result-object p1

    iget v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->ZfxDd:I

    iget v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->KLFTb:I

    add-int/2addr v0, v1

    iput v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->ZfxDd:I

    return-object p1
.end method

.method public mjFkc()V
    .locals 1

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->AZxh(Landroid/view/View;)V

    return-void
.end method

.method public wA(Landroidx/recyclerview/widget/RecyclerView$VocHEe;)Z
    .locals 0

    iget p0, p0, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->ZfxDd:I

    if-ltz p0, :cond_0

    invoke-virtual {p1}, Landroidx/recyclerview/widget/RecyclerView$VocHEe;->AZxh()I

    move-result p1

    if-ge p0, p1, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method
