.class public Landroidx/recyclerview/widget/wA$KLFTb;
.super Landroid/animation/AnimatorListenerAdapter;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Landroidx/recyclerview/widget/wA;->oCFDzJ(Landroidx/recyclerview/widget/RecyclerView$mByQ;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic AZxh:Landroid/view/View;

.field public final synthetic ZfxDd:Landroidx/recyclerview/widget/wA;

.field public final synthetic mjFkc:Landroidx/recyclerview/widget/RecyclerView$mByQ;

.field public final synthetic wA:Landroid/view/ViewPropertyAnimator;


# direct methods
.method public constructor <init>(Landroidx/recyclerview/widget/wA;Landroidx/recyclerview/widget/RecyclerView$mByQ;Landroid/view/View;Landroid/view/ViewPropertyAnimator;)V
    .locals 0

    iput-object p1, p0, Landroidx/recyclerview/widget/wA$KLFTb;->ZfxDd:Landroidx/recyclerview/widget/wA;

    iput-object p2, p0, Landroidx/recyclerview/widget/wA$KLFTb;->mjFkc:Landroidx/recyclerview/widget/RecyclerView$mByQ;

    iput-object p3, p0, Landroidx/recyclerview/widget/wA$KLFTb;->AZxh:Landroid/view/View;

    iput-object p4, p0, Landroidx/recyclerview/widget/wA$KLFTb;->wA:Landroid/view/ViewPropertyAnimator;

    invoke-direct {p0}, Landroid/animation/AnimatorListenerAdapter;-><init>()V

    return-void
.end method


# virtual methods
.method public onAnimationCancel(Landroid/animation/Animator;)V
    .locals 0

    iget-object p0, p0, Landroidx/recyclerview/widget/wA$KLFTb;->AZxh:Landroid/view/View;

    const/high16 p1, 0x3f800000    # 1.0f

    invoke-virtual {p0, p1}, Landroid/view/View;->setAlpha(F)V

    return-void
.end method

.method public onAnimationEnd(Landroid/animation/Animator;)V
    .locals 1

    iget-object p1, p0, Landroidx/recyclerview/widget/wA$KLFTb;->wA:Landroid/view/ViewPropertyAnimator;

    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Landroid/view/ViewPropertyAnimator;->setListener(Landroid/animation/Animator$AnimatorListener;)Landroid/view/ViewPropertyAnimator;

    iget-object p1, p0, Landroidx/recyclerview/widget/wA$KLFTb;->ZfxDd:Landroidx/recyclerview/widget/wA;

    iget-object v0, p0, Landroidx/recyclerview/widget/wA$KLFTb;->mjFkc:Landroidx/recyclerview/widget/RecyclerView$mByQ;

    invoke-virtual {p1, v0}, Landroidx/recyclerview/widget/MiMN;->VocHEe(Landroidx/recyclerview/widget/RecyclerView$mByQ;)V

    iget-object p1, p0, Landroidx/recyclerview/widget/wA$KLFTb;->ZfxDd:Landroidx/recyclerview/widget/wA;

    iget-object p1, p1, Landroidx/recyclerview/widget/wA;->rkYL:Ljava/util/ArrayList;

    iget-object v0, p0, Landroidx/recyclerview/widget/wA$KLFTb;->mjFkc:Landroidx/recyclerview/widget/RecyclerView$mByQ;

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    iget-object p0, p0, Landroidx/recyclerview/widget/wA$KLFTb;->ZfxDd:Landroidx/recyclerview/widget/wA;

    invoke-virtual {p0}, Landroidx/recyclerview/widget/wA;->uHVRx()V

    return-void
.end method

.method public onAnimationStart(Landroid/animation/Animator;)V
    .locals 0

    iget-object p1, p0, Landroidx/recyclerview/widget/wA$KLFTb;->ZfxDd:Landroidx/recyclerview/widget/wA;

    iget-object p0, p0, Landroidx/recyclerview/widget/wA$KLFTb;->mjFkc:Landroidx/recyclerview/widget/RecyclerView$mByQ;

    invoke-virtual {p1, p0}, Landroidx/recyclerview/widget/MiMN;->BAnRFn(Landroidx/recyclerview/widget/RecyclerView$mByQ;)V

    return-void
.end method
