.class public Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/recyclerview/widget/LinearLayoutManager;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "mjFkc"
.end annotation


# instance fields
.field public AZxh:I

.field public KLFTb:Z

.field public ZfxDd:Z

.field public mjFkc:Landroidx/recyclerview/widget/qdMbNW;

.field public wA:I


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    invoke-virtual {p0}, Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;->KLFTb()V

    return-void
.end method


# virtual methods
.method public AZxh(Landroid/view/View;I)V
    .locals 1

    iget-boolean v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;->ZfxDd:Z

    if-eqz v0, :cond_0

    iget-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;->mjFkc:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v0, p1}, Landroidx/recyclerview/widget/qdMbNW;->ZfxDd(Landroid/view/View;)I

    move-result p1

    iget-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;->mjFkc:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v0}, Landroidx/recyclerview/widget/qdMbNW;->rkYL()I

    move-result v0

    add-int/2addr p1, v0

    iput p1, p0, Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;->wA:I

    goto :goto_0

    :cond_0
    iget-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;->mjFkc:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v0, p1}, Landroidx/recyclerview/widget/qdMbNW;->xJ(Landroid/view/View;)I

    move-result p1

    iput p1, p0, Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;->wA:I

    :goto_0
    iput p2, p0, Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;->AZxh:I

    return-void
.end method

.method public KLFTb()V
    .locals 1

    const/4 v0, -0x1

    iput v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;->AZxh:I

    const/high16 v0, -0x80000000

    iput v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;->wA:I

    const/4 v0, 0x0

    iput-boolean v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;->ZfxDd:Z

    iput-boolean v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;->KLFTb:Z

    return-void
.end method

.method public ZfxDd(Landroid/view/View;Landroidx/recyclerview/widget/RecyclerView$VocHEe;)Z
    .locals 0

    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object p0

    check-cast p0, Landroidx/recyclerview/widget/RecyclerView$fehf;

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$fehf;->wA()Z

    move-result p1

    if-nez p1, :cond_0

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$fehf;->mjFkc()I

    move-result p1

    if-ltz p1, :cond_0

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$fehf;->mjFkc()I

    move-result p0

    invoke-virtual {p2}, Landroidx/recyclerview/widget/RecyclerView$VocHEe;->AZxh()I

    move-result p1

    if-ge p0, p1, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method

.method public mjFkc()V
    .locals 1

    iget-boolean v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;->ZfxDd:Z

    if-eqz v0, :cond_0

    iget-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;->mjFkc:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v0}, Landroidx/recyclerview/widget/qdMbNW;->qdMbNW()I

    move-result v0

    goto :goto_0

    :cond_0
    iget-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;->mjFkc:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v0}, Landroidx/recyclerview/widget/qdMbNW;->MiMN()I

    move-result v0

    :goto_0
    iput v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;->wA:I

    return-void
.end method

.method public toString()Ljava/lang/String;
    .locals 2

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "AnchorInfo{mPosition="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;->AZxh:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, ", mCoordinate="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;->wA:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, ", mLayoutFromEnd="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-boolean v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;->ZfxDd:Z

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const-string v1, ", mValid="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-boolean p0, p0, Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;->KLFTb:Z

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const/16 p0, 0x7d

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public wA(Landroid/view/View;I)V
    .locals 4

    iget-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;->mjFkc:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v0}, Landroidx/recyclerview/widget/qdMbNW;->rkYL()I

    move-result v0

    if-ltz v0, :cond_0

    invoke-virtual {p0, p1, p2}, Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;->AZxh(Landroid/view/View;I)V

    return-void

    :cond_0
    iput p2, p0, Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;->AZxh:I

    iget-boolean p2, p0, Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;->ZfxDd:Z

    const/4 v1, 0x0

    if-eqz p2, :cond_1

    iget-object p2, p0, Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;->mjFkc:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {p2}, Landroidx/recyclerview/widget/qdMbNW;->qdMbNW()I

    move-result p2

    sub-int/2addr p2, v0

    iget-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;->mjFkc:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v0, p1}, Landroidx/recyclerview/widget/qdMbNW;->ZfxDd(Landroid/view/View;)I

    move-result v0

    sub-int/2addr p2, v0

    iget-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;->mjFkc:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v0}, Landroidx/recyclerview/widget/qdMbNW;->qdMbNW()I

    move-result v0

    sub-int/2addr v0, p2

    iput v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;->wA:I

    if-lez p2, :cond_2

    iget-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;->mjFkc:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v0, p1}, Landroidx/recyclerview/widget/qdMbNW;->KLFTb(Landroid/view/View;)I

    move-result v0

    iget v2, p0, Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;->wA:I

    sub-int/2addr v2, v0

    iget-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;->mjFkc:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v0}, Landroidx/recyclerview/widget/qdMbNW;->MiMN()I

    move-result v0

    iget-object v3, p0, Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;->mjFkc:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v3, p1}, Landroidx/recyclerview/widget/qdMbNW;->xJ(Landroid/view/View;)I

    move-result p1

    sub-int/2addr p1, v0

    invoke-static {p1, v1}, Ljava/lang/Math;->min(II)I

    move-result p1

    add-int/2addr v0, p1

    sub-int/2addr v2, v0

    if-gez v2, :cond_2

    iget p1, p0, Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;->wA:I

    neg-int v0, v2

    invoke-static {p2, v0}, Ljava/lang/Math;->min(II)I

    move-result p2

    add-int/2addr p1, p2

    iput p1, p0, Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;->wA:I

    goto :goto_0

    :cond_1
    iget-object p2, p0, Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;->mjFkc:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {p2, p1}, Landroidx/recyclerview/widget/qdMbNW;->xJ(Landroid/view/View;)I

    move-result p2

    iget-object v2, p0, Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;->mjFkc:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v2}, Landroidx/recyclerview/widget/qdMbNW;->MiMN()I

    move-result v2

    sub-int v2, p2, v2

    iput p2, p0, Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;->wA:I

    if-lez v2, :cond_2

    iget-object v3, p0, Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;->mjFkc:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v3, p1}, Landroidx/recyclerview/widget/qdMbNW;->KLFTb(Landroid/view/View;)I

    move-result v3

    add-int/2addr p2, v3

    iget-object v3, p0, Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;->mjFkc:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v3}, Landroidx/recyclerview/widget/qdMbNW;->qdMbNW()I

    move-result v3

    sub-int/2addr v3, v0

    iget-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;->mjFkc:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v0, p1}, Landroidx/recyclerview/widget/qdMbNW;->ZfxDd(Landroid/view/View;)I

    move-result p1

    sub-int/2addr v3, p1

    iget-object p1, p0, Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;->mjFkc:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {p1}, Landroidx/recyclerview/widget/qdMbNW;->qdMbNW()I

    move-result p1

    invoke-static {v1, v3}, Ljava/lang/Math;->min(II)I

    move-result v0

    sub-int/2addr p1, v0

    sub-int/2addr p1, p2

    if-gez p1, :cond_2

    iget p2, p0, Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;->wA:I

    neg-int p1, p1

    invoke-static {v2, p1}, Ljava/lang/Math;->min(II)I

    move-result p1

    sub-int/2addr p2, p1

    iput p2, p0, Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;->wA:I

    :cond_2
    :goto_0
    return-void
.end method
