.class public Landroidx/recyclerview/widget/StaggeredGridLayoutManager;
.super Landroidx/recyclerview/widget/RecyclerView$qGY;
.source "SourceFile"

# interfaces
.implements Landroidx/recyclerview/widget/RecyclerView$vI$AZxh;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/recyclerview/widget/StaggeredGridLayoutManager$AZxh;,
        Landroidx/recyclerview/widget/StaggeredGridLayoutManager$KLFTb;,
        Landroidx/recyclerview/widget/StaggeredGridLayoutManager$ZfxDd;,
        Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;,
        Landroidx/recyclerview/widget/StaggeredGridLayoutManager$wA;
    }
.end annotation


# instance fields
.field public BAnRFn:Ljava/util/BitSet;

.field public CqaNbM:Z

.field public Gd:I

.field public final HGpJ:Landroidx/recyclerview/widget/JHa;

.field public KLMXS:I

.field public NPj:[I

.field public Ne:Z

.field public OjSQV:I

.field public Pq:I

.field public Ucbh:Landroidx/recyclerview/widget/qdMbNW;

.field public Vnb:Z

.field public VocHEe:Z

.field public final cMLeY:Landroidx/recyclerview/widget/StaggeredGridLayoutManager$AZxh;

.field public diqgf:[Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;

.field public eyqo:Landroidx/recyclerview/widget/qdMbNW;

.field public huTpC:I

.field public lB:I

.field public mByQ:Landroidx/recyclerview/widget/StaggeredGridLayoutManager$ZfxDd;

.field public rWxwaT:Z

.field public vI:Z

.field public final vadzgd:Ljava/lang/Runnable;

.field public wJVbdd:I

.field public xrEuO:Landroidx/recyclerview/widget/StaggeredGridLayoutManager$KLFTb;

.field public final zvd:Landroid/graphics/Rect;


# direct methods
.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;II)V
    .locals 2

    invoke-direct {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;-><init>()V

    const/4 v0, -0x1

    iput v0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Pq:I

    const/4 v1, 0x0

    iput-boolean v1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->vI:Z

    iput-boolean v1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->VocHEe:Z

    iput v0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->lB:I

    const/high16 v0, -0x80000000

    iput v0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->wJVbdd:I

    new-instance v0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$ZfxDd;

    invoke-direct {v0}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$ZfxDd;-><init>()V

    iput-object v0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->mByQ:Landroidx/recyclerview/widget/StaggeredGridLayoutManager$ZfxDd;

    const/4 v0, 0x2

    iput v0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->OjSQV:I

    new-instance v0, Landroid/graphics/Rect;

    invoke-direct {v0}, Landroid/graphics/Rect;-><init>()V

    iput-object v0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->zvd:Landroid/graphics/Rect;

    new-instance v0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$AZxh;

    invoke-direct {v0, p0}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$AZxh;-><init>(Landroidx/recyclerview/widget/StaggeredGridLayoutManager;)V

    iput-object v0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->cMLeY:Landroidx/recyclerview/widget/StaggeredGridLayoutManager$AZxh;

    iput-boolean v1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->rWxwaT:Z

    const/4 v0, 0x1

    iput-boolean v0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Vnb:Z

    new-instance v0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$mjFkc;

    invoke-direct {v0, p0}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$mjFkc;-><init>(Landroidx/recyclerview/widget/StaggeredGridLayoutManager;)V

    iput-object v0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->vadzgd:Ljava/lang/Runnable;

    invoke-static {p1, p2, p3, p4}, Landroidx/recyclerview/widget/RecyclerView$qGY;->yfx(Landroid/content/Context;Landroid/util/AttributeSet;II)Landroidx/recyclerview/widget/RecyclerView$qGY$ZfxDd;

    move-result-object p1

    iget p2, p1, Landroidx/recyclerview/widget/RecyclerView$qGY$ZfxDd;->mjFkc:I

    invoke-virtual {p0, p2}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->ZGL(I)V

    iget p2, p1, Landroidx/recyclerview/widget/RecyclerView$qGY$ZfxDd;->AZxh:I

    invoke-virtual {p0, p2}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->eEOGOh(I)V

    iget-boolean p1, p1, Landroidx/recyclerview/widget/RecyclerView$qGY$ZfxDd;->wA:Z

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->jpz(Z)V

    new-instance p1, Landroidx/recyclerview/widget/JHa;

    invoke-direct {p1}, Landroidx/recyclerview/widget/JHa;-><init>()V

    iput-object p1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->HGpJ:Landroidx/recyclerview/widget/JHa;

    invoke-virtual {p0}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->aDq()V

    return-void
.end method

.method private CcoH(Landroidx/recyclerview/widget/RecyclerView$VocHEe;)I
    .locals 6

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->zvd()I

    move-result v0

    if-nez v0, :cond_0

    const/4 p0, 0x0

    return p0

    :cond_0
    iget-object v1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    iget-boolean v0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Vnb:Z

    xor-int/lit8 v0, v0, 0x1

    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Rsp(Z)Landroid/view/View;

    move-result-object v2

    iget-boolean v0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Vnb:Z

    xor-int/lit8 v0, v0, 0x1

    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->CqAnRZ(Z)Landroid/view/View;

    move-result-object v3

    iget-boolean v5, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Vnb:Z

    move-object v0, p1

    move-object v4, p0

    invoke-static/range {v0 .. v5}, Landroidx/recyclerview/widget/VA;->mjFkc(Landroidx/recyclerview/widget/RecyclerView$VocHEe;Landroidx/recyclerview/widget/qdMbNW;Landroid/view/View;Landroid/view/View;Landroidx/recyclerview/widget/RecyclerView$qGY;Z)I

    move-result p0

    return p0
.end method

.method private EoC(Landroidx/recyclerview/widget/RecyclerView$VocHEe;)I
    .locals 6

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->zvd()I

    move-result v0

    if-nez v0, :cond_0

    const/4 p0, 0x0

    return p0

    :cond_0
    iget-object v1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    iget-boolean v0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Vnb:Z

    xor-int/lit8 v0, v0, 0x1

    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Rsp(Z)Landroid/view/View;

    move-result-object v2

    iget-boolean v0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Vnb:Z

    xor-int/lit8 v0, v0, 0x1

    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->CqAnRZ(Z)Landroid/view/View;

    move-result-object v3

    iget-boolean v5, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Vnb:Z

    move-object v0, p1

    move-object v4, p0

    invoke-static/range {v0 .. v5}, Landroidx/recyclerview/widget/VA;->wA(Landroidx/recyclerview/widget/RecyclerView$VocHEe;Landroidx/recyclerview/widget/qdMbNW;Landroid/view/View;Landroid/view/View;Landroidx/recyclerview/widget/RecyclerView$qGY;Z)I

    move-result p0

    return p0
.end method

.method private HX(Landroidx/recyclerview/widget/RecyclerView$VocHEe;)I
    .locals 7

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->zvd()I

    move-result v0

    if-nez v0, :cond_0

    const/4 p0, 0x0

    return p0

    :cond_0
    iget-object v1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    iget-boolean v0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Vnb:Z

    xor-int/lit8 v0, v0, 0x1

    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Rsp(Z)Landroid/view/View;

    move-result-object v2

    iget-boolean v0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Vnb:Z

    xor-int/lit8 v0, v0, 0x1

    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->CqAnRZ(Z)Landroid/view/View;

    move-result-object v3

    iget-boolean v5, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Vnb:Z

    iget-boolean v6, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->VocHEe:Z

    move-object v0, p1

    move-object v4, p0

    invoke-static/range {v0 .. v6}, Landroidx/recyclerview/widget/VA;->AZxh(Landroidx/recyclerview/widget/RecyclerView$VocHEe;Landroidx/recyclerview/widget/qdMbNW;Landroid/view/View;Landroid/view/View;Landroidx/recyclerview/widget/RecyclerView$qGY;ZZ)I

    move-result p0

    return p0
.end method

.method private OzIs(Landroid/view/View;IIZ)V
    .locals 4

    iget-object v0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->zvd:Landroid/graphics/Rect;

    invoke-virtual {p0, p1, v0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->ETF(Landroid/view/View;Landroid/graphics/Rect;)V

    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    check-cast v0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$wA;

    iget v1, v0, Landroid/view/ViewGroup$MarginLayoutParams;->leftMargin:I

    iget-object v2, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->zvd:Landroid/graphics/Rect;

    iget v3, v2, Landroid/graphics/Rect;->left:I

    add-int/2addr v1, v3

    iget v3, v0, Landroid/view/ViewGroup$MarginLayoutParams;->rightMargin:I

    iget v2, v2, Landroid/graphics/Rect;->right:I

    add-int/2addr v3, v2

    invoke-virtual {p0, p2, v1, v3}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->KbE(III)I

    move-result p2

    iget v1, v0, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    iget-object v2, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->zvd:Landroid/graphics/Rect;

    iget v3, v2, Landroid/graphics/Rect;->top:I

    add-int/2addr v1, v3

    iget v3, v0, Landroid/view/ViewGroup$MarginLayoutParams;->bottomMargin:I

    iget v2, v2, Landroid/graphics/Rect;->bottom:I

    add-int/2addr v3, v2

    invoke-virtual {p0, p3, v1, v3}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->KbE(III)I

    move-result p3

    if-eqz p4, :cond_0

    invoke-virtual {p0, p1, p2, p3, v0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->tpGcn(Landroid/view/View;IILandroidx/recyclerview/widget/RecyclerView$fehf;)Z

    move-result p0

    goto :goto_0

    :cond_0
    invoke-virtual {p0, p1, p2, p3, v0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->yP(Landroid/view/View;IILandroidx/recyclerview/widget/RecyclerView$fehf;)Z

    move-result p0

    :goto_0
    if-eqz p0, :cond_1

    invoke-virtual {p1, p2, p3}, Landroid/view/View;->measure(II)V

    :cond_1
    return-void
.end method

.method private kOlLW()V
    .locals 2

    iget v0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->huTpC:I

    const/4 v1, 0x1

    if-eq v0, v1, :cond_1

    invoke-virtual {p0}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Otxclu()Z

    move-result v0

    if-nez v0, :cond_0

    goto :goto_0

    :cond_0
    iget-boolean v0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->vI:Z

    xor-int/2addr v0, v1

    iput-boolean v0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->VocHEe:Z

    goto :goto_1

    :cond_1
    :goto_0
    iget-boolean v0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->vI:Z

    iput-boolean v0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->VocHEe:Z

    :goto_1
    return-void
.end method

.method private xbjHT(I)I
    .locals 4

    const/4 v0, -0x1

    const/4 v1, 0x1

    if-eq p1, v1, :cond_b

    const/4 v2, 0x2

    if-eq p1, v2, :cond_8

    const/16 v2, 0x11

    const/high16 v3, -0x80000000

    if-eq p1, v2, :cond_6

    const/16 v2, 0x21

    if-eq p1, v2, :cond_4

    const/16 v0, 0x42

    if-eq p1, v0, :cond_2

    const/16 v0, 0x82

    if-eq p1, v0, :cond_0

    return v3

    :cond_0
    iget p0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->huTpC:I

    if-ne p0, v1, :cond_1

    goto :goto_0

    :cond_1
    move v1, v3

    :goto_0
    return v1

    :cond_2
    iget p0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->huTpC:I

    if-nez p0, :cond_3

    goto :goto_1

    :cond_3
    move v1, v3

    :goto_1
    return v1

    :cond_4
    iget p0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->huTpC:I

    if-ne p0, v1, :cond_5

    goto :goto_2

    :cond_5
    move v0, v3

    :goto_2
    return v0

    :cond_6
    iget p0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->huTpC:I

    if-nez p0, :cond_7

    goto :goto_3

    :cond_7
    move v0, v3

    :goto_3
    return v0

    :cond_8
    iget p1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->huTpC:I

    if-ne p1, v1, :cond_9

    return v1

    :cond_9
    invoke-virtual {p0}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Otxclu()Z

    move-result p0

    if-eqz p0, :cond_a

    return v0

    :cond_a
    return v1

    :cond_b
    iget p1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->huTpC:I

    if-ne p1, v1, :cond_c

    return v0

    :cond_c
    invoke-virtual {p0}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Otxclu()Z

    move-result p0

    if-eqz p0, :cond_d

    return v1

    :cond_d
    return v0
.end method


# virtual methods
.method public AZxh(I)Landroid/graphics/PointF;
    .locals 2

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->KSf(I)I

    move-result p1

    new-instance v0, Landroid/graphics/PointF;

    invoke-direct {v0}, Landroid/graphics/PointF;-><init>()V

    if-nez p1, :cond_0

    const/4 p0, 0x0

    return-object p0

    :cond_0
    iget p0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->huTpC:I

    const/4 v1, 0x0

    if-nez p0, :cond_1

    int-to-float p0, p1

    iput p0, v0, Landroid/graphics/PointF;->x:F

    iput v1, v0, Landroid/graphics/PointF;->y:F

    goto :goto_0

    :cond_1
    iput v1, v0, Landroid/graphics/PointF;->x:F

    int-to-float p0, p1

    iput p0, v0, Landroid/graphics/PointF;->y:F

    :goto_0
    return-object v0
.end method

.method public final ArO(Landroid/view/View;Landroidx/recyclerview/widget/StaggeredGridLayoutManager$wA;Z)V
    .locals 6

    iget-boolean v0, p2, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$wA;->JHa:Z

    const/4 v1, 0x1

    if-eqz v0, :cond_1

    iget v0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->huTpC:I

    if-ne v0, v1, :cond_0

    iget v0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->KLMXS:I

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->JYgkl()I

    move-result v2

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->JrJO()I

    move-result v3

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->dm()I

    move-result v4

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->JBhc()I

    move-result v5

    add-int/2addr v4, v5

    iget p2, p2, Landroid/view/ViewGroup$MarginLayoutParams;->height:I

    invoke-static {v2, v3, v4, p2, v1}, Landroidx/recyclerview/widget/RecyclerView$qGY;->cMLeY(IIIIZ)I

    move-result p2

    invoke-direct {p0, p1, v0, p2, p3}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->OzIs(Landroid/view/View;IIZ)V

    goto :goto_0

    :cond_0
    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->SOS()I

    move-result v0

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->Qr()I

    move-result v2

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->jm()I

    move-result v3

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->ANMGZc()I

    move-result v4

    add-int/2addr v3, v4

    iget p2, p2, Landroid/view/ViewGroup$MarginLayoutParams;->width:I

    invoke-static {v0, v2, v3, p2, v1}, Landroidx/recyclerview/widget/RecyclerView$qGY;->cMLeY(IIIIZ)I

    move-result p2

    iget v0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->KLMXS:I

    invoke-direct {p0, p1, p2, v0, p3}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->OzIs(Landroid/view/View;IIZ)V

    goto :goto_0

    :cond_1
    iget v0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->huTpC:I

    const/4 v2, 0x0

    if-ne v0, v1, :cond_2

    iget v0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Gd:I

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->Qr()I

    move-result v3

    iget v4, p2, Landroid/view/ViewGroup$MarginLayoutParams;->width:I

    invoke-static {v0, v3, v2, v4, v2}, Landroidx/recyclerview/widget/RecyclerView$qGY;->cMLeY(IIIIZ)I

    move-result v0

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->JYgkl()I

    move-result v2

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->JrJO()I

    move-result v3

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->dm()I

    move-result v4

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->JBhc()I

    move-result v5

    add-int/2addr v4, v5

    iget p2, p2, Landroid/view/ViewGroup$MarginLayoutParams;->height:I

    invoke-static {v2, v3, v4, p2, v1}, Landroidx/recyclerview/widget/RecyclerView$qGY;->cMLeY(IIIIZ)I

    move-result p2

    invoke-direct {p0, p1, v0, p2, p3}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->OzIs(Landroid/view/View;IIZ)V

    goto :goto_0

    :cond_2
    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->SOS()I

    move-result v0

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->Qr()I

    move-result v3

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->jm()I

    move-result v4

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->ANMGZc()I

    move-result v5

    add-int/2addr v4, v5

    iget v5, p2, Landroid/view/ViewGroup$MarginLayoutParams;->width:I

    invoke-static {v0, v3, v4, v5, v1}, Landroidx/recyclerview/widget/RecyclerView$qGY;->cMLeY(IIIIZ)I

    move-result v0

    iget v1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Gd:I

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->JrJO()I

    move-result v3

    iget p2, p2, Landroid/view/ViewGroup$MarginLayoutParams;->height:I

    invoke-static {v1, v3, v2, p2, v2}, Landroidx/recyclerview/widget/RecyclerView$qGY;->cMLeY(IIIIZ)I

    move-result p2

    invoke-direct {p0, p1, v0, p2, p3}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->OzIs(Landroid/view/View;IIZ)V

    :goto_0
    return-void
.end method

.method public final BABY(II)V
    .locals 2

    const/4 v0, 0x0

    :goto_0
    iget v1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Pq:I

    if-ge v0, v1, :cond_1

    iget-object v1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->diqgf:[Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;

    aget-object v1, v1, v0

    iget-object v1, v1, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;->mjFkc:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_0

    goto :goto_1

    :cond_0
    iget-object v1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->diqgf:[Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;

    aget-object v1, v1, v0

    invoke-virtual {p0, v1, p1, p2}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->ih(Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;II)V

    :goto_1
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    return-void
.end method

.method public BxruE(ILandroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;)I
    .locals 0

    invoke-virtual {p0, p1, p2, p3}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->LlB(ILandroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;)I

    move-result p0

    return p0
.end method

.method public CqAnRZ(Z)Landroid/view/View;
    .locals 7

    iget-object v0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v0}, Landroidx/recyclerview/widget/qdMbNW;->MiMN()I

    move-result v0

    iget-object v1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v1}, Landroidx/recyclerview/widget/qdMbNW;->qdMbNW()I

    move-result v1

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->zvd()I

    move-result v2

    add-int/lit8 v2, v2, -0x1

    const/4 v3, 0x0

    :goto_0
    if-ltz v2, :cond_4

    invoke-virtual {p0, v2}, Landroidx/recyclerview/widget/RecyclerView$qGY;->KLMXS(I)Landroid/view/View;

    move-result-object v4

    iget-object v5, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v5, v4}, Landroidx/recyclerview/widget/qdMbNW;->xJ(Landroid/view/View;)I

    move-result v5

    iget-object v6, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v6, v4}, Landroidx/recyclerview/widget/qdMbNW;->ZfxDd(Landroid/view/View;)I

    move-result v6

    if-le v6, v0, :cond_3

    if-lt v5, v1, :cond_0

    goto :goto_2

    :cond_0
    if-le v6, v1, :cond_2

    if-nez p1, :cond_1

    goto :goto_1

    :cond_1
    if-nez v3, :cond_3

    move-object v3, v4

    goto :goto_2

    :cond_2
    :goto_1
    return-object v4

    :cond_3
    :goto_2
    add-int/lit8 v2, v2, -0x1

    goto :goto_0

    :cond_4
    return-object v3
.end method

.method public Dp(Landroid/view/accessibility/AccessibilityEvent;)V
    .locals 2

    invoke-super {p0, p1}, Landroidx/recyclerview/widget/RecyclerView$qGY;->Dp(Landroid/view/accessibility/AccessibilityEvent;)V

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->zvd()I

    move-result v0

    if-lez v0, :cond_2

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Rsp(Z)Landroid/view/View;

    move-result-object v1

    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->CqAnRZ(Z)Landroid/view/View;

    move-result-object v0

    if-eqz v1, :cond_2

    if-nez v0, :cond_0

    goto :goto_0

    :cond_0
    invoke-virtual {p0, v1}, Landroidx/recyclerview/widget/RecyclerView$qGY;->tQ(Landroid/view/View;)I

    move-result v1

    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->tQ(Landroid/view/View;)I

    move-result p0

    if-ge v1, p0, :cond_1

    invoke-virtual {p1, v1}, Landroid/view/accessibility/AccessibilityRecord;->setFromIndex(I)V

    invoke-virtual {p1, p0}, Landroid/view/accessibility/AccessibilityRecord;->setToIndex(I)V

    goto :goto_0

    :cond_1
    invoke-virtual {p1, p0}, Landroid/view/accessibility/AccessibilityRecord;->setFromIndex(I)V

    invoke-virtual {p1, v1}, Landroid/view/accessibility/AccessibilityRecord;->setToIndex(I)V

    nop

    :cond_2
    :goto_0
    return-void
.end method

.method public ERt()Z
    .locals 0

    iget-object p0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->xrEuO:Landroidx/recyclerview/widget/StaggeredGridLayoutManager$KLFTb;

    if-nez p0, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method

.method public EeoThB(ILandroidx/recyclerview/widget/RecyclerView$VocHEe;)V
    .locals 4

    const/4 v0, 0x1

    if-lez p1, :cond_0

    invoke-virtual {p0}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->XyP()I

    move-result v1

    move v2, v0

    goto :goto_0

    :cond_0
    invoke-virtual {p0}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->bWIyu()I

    move-result v1

    const/4 v2, -0x1

    :goto_0
    iget-object v3, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->HGpJ:Landroidx/recyclerview/widget/JHa;

    iput-boolean v0, v3, Landroidx/recyclerview/widget/JHa;->mjFkc:Z

    invoke-virtual {p0, v1, p2}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->gjvQ(ILandroidx/recyclerview/widget/RecyclerView$VocHEe;)V

    invoke-virtual {p0, v2}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Es(I)V

    iget-object p0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->HGpJ:Landroidx/recyclerview/widget/JHa;

    iget p2, p0, Landroidx/recyclerview/widget/JHa;->ZfxDd:I

    add-int/2addr v1, p2

    iput v1, p0, Landroidx/recyclerview/widget/JHa;->wA:I

    invoke-static {p1}, Ljava/lang/Math;->abs(I)I

    move-result p1

    iput p1, p0, Landroidx/recyclerview/widget/JHa;->AZxh:I

    return-void
.end method

.method public final Es(I)V
    .locals 3

    iget-object v0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->HGpJ:Landroidx/recyclerview/widget/JHa;

    iput p1, v0, Landroidx/recyclerview/widget/JHa;->KLFTb:I

    iget-boolean p0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->VocHEe:Z

    const/4 v1, 0x1

    const/4 v2, -0x1

    if-ne p1, v2, :cond_0

    move p1, v1

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    :goto_0
    if-ne p0, p1, :cond_1

    goto :goto_1

    :cond_1
    move v1, v2

    :goto_1
    iput v1, v0, Landroidx/recyclerview/widget/JHa;->ZfxDd:I

    return-void
.end method

.method public FbxKQm(Landroidx/recyclerview/widget/RecyclerView;)V
    .locals 0

    iget-object p1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->mByQ:Landroidx/recyclerview/widget/StaggeredGridLayoutManager$ZfxDd;

    invoke-virtual {p1}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$ZfxDd;->AZxh()V

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->mzUGzO()V

    return-void
.end method

.method public final HExgdj(Landroid/view/View;Landroidx/recyclerview/widget/StaggeredGridLayoutManager$wA;Landroidx/recyclerview/widget/JHa;)V
    .locals 1

    iget p3, p3, Landroidx/recyclerview/widget/JHa;->KLFTb:I

    const/4 v0, 0x1

    if-ne p3, v0, :cond_1

    iget-boolean p3, p2, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$wA;->JHa:Z

    if-eqz p3, :cond_0

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->JOe(Landroid/view/View;)V

    goto :goto_0

    :cond_0
    iget-object p0, p2, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$wA;->KLFTb:Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;->mjFkc(Landroid/view/View;)V

    goto :goto_0

    :cond_1
    iget-boolean p3, p2, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$wA;->JHa:Z

    if-eqz p3, :cond_2

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->cdjp(Landroid/view/View;)V

    goto :goto_0

    :cond_2
    iget-object p0, p2, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$wA;->KLFTb:Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;->eyqo(Landroid/view/View;)V

    :goto_0
    return-void
.end method

.method public final Hk(Landroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;Z)V
    .locals 2

    const/high16 v0, -0x80000000

    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->UDcil(I)I

    move-result v1

    if-ne v1, v0, :cond_0

    return-void

    :cond_0
    iget-object v0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v0}, Landroidx/recyclerview/widget/qdMbNW;->qdMbNW()I

    move-result v0

    sub-int/2addr v0, v1

    if-lez v0, :cond_1

    neg-int v1, v0

    invoke-virtual {p0, v1, p1, p2}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->LlB(ILandroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;)I

    move-result p1

    neg-int p1, p1

    sub-int/2addr v0, p1

    if-eqz p3, :cond_1

    if-lez v0, :cond_1

    iget-object p0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/qdMbNW;->IEE(I)V

    :cond_1
    return-void
.end method

.method public IEE(Landroidx/recyclerview/widget/RecyclerView$VocHEe;)I
    .locals 0

    invoke-direct {p0, p1}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->CcoH(Landroidx/recyclerview/widget/RecyclerView$VocHEe;)I

    move-result p0

    return p0
.end method

.method public final IPpyV()V
    .locals 9

    iget-object v0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Ucbh:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v0}, Landroidx/recyclerview/widget/qdMbNW;->ETF()I

    move-result v0

    const/high16 v1, 0x40000000    # 2.0f

    if-ne v0, v1, :cond_0

    return-void

    :cond_0
    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->zvd()I

    move-result v0

    const/4 v1, 0x0

    const/4 v2, 0x0

    move v3, v1

    :goto_0
    if-ge v3, v0, :cond_3

    invoke-virtual {p0, v3}, Landroidx/recyclerview/widget/RecyclerView$qGY;->KLMXS(I)Landroid/view/View;

    move-result-object v4

    iget-object v5, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Ucbh:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v5, v4}, Landroidx/recyclerview/widget/qdMbNW;->KLFTb(Landroid/view/View;)I

    move-result v5

    int-to-float v5, v5

    cmpg-float v6, v5, v2

    if-gez v6, :cond_1

    goto :goto_1

    :cond_1
    invoke-virtual {v4}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v4

    check-cast v4, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$wA;

    invoke-virtual {v4}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$wA;->KLFTb()Z

    move-result v4

    if-eqz v4, :cond_2

    const/high16 v4, 0x3f800000    # 1.0f

    mul-float/2addr v5, v4

    iget v4, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Pq:I

    int-to-float v4, v4

    div-float/2addr v5, v4

    :cond_2
    invoke-static {v2, v5}, Ljava/lang/Math;->max(FF)F

    move-result v2

    :goto_1
    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    :cond_3
    iget v3, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Gd:I

    iget v4, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Pq:I

    int-to-float v4, v4

    mul-float/2addr v2, v4

    invoke-static {v2}, Ljava/lang/Math;->round(F)I

    move-result v2

    iget-object v4, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Ucbh:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v4}, Landroidx/recyclerview/widget/qdMbNW;->ETF()I

    move-result v4

    const/high16 v5, -0x80000000

    if-ne v4, v5, :cond_4

    iget-object v4, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Ucbh:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v4}, Landroidx/recyclerview/widget/qdMbNW;->YoKzxo()I

    move-result v4

    invoke-static {v2, v4}, Ljava/lang/Math;->min(II)I

    move-result v2

    :cond_4
    invoke-virtual {p0, v2}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->kw(I)V

    iget v2, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Gd:I

    if-ne v2, v3, :cond_5

    return-void

    :cond_5
    :goto_2
    if-ge v1, v0, :cond_9

    invoke-virtual {p0, v1}, Landroidx/recyclerview/widget/RecyclerView$qGY;->KLMXS(I)Landroid/view/View;

    move-result-object v2

    invoke-virtual {v2}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v4

    check-cast v4, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$wA;

    iget-boolean v5, v4, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$wA;->JHa:Z

    if-eqz v5, :cond_6

    goto :goto_3

    :cond_6
    invoke-virtual {p0}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Otxclu()Z

    move-result v5

    const/4 v6, 0x1

    if-eqz v5, :cond_7

    iget v5, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->huTpC:I

    if-ne v5, v6, :cond_7

    iget v5, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Pq:I

    add-int/lit8 v7, v5, -0x1

    iget-object v4, v4, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$wA;->KLFTb:Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;

    iget v4, v4, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;->KLFTb:I

    sub-int/2addr v7, v4

    neg-int v7, v7

    iget v8, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Gd:I

    mul-int/2addr v7, v8

    sub-int/2addr v5, v6

    sub-int/2addr v5, v4

    neg-int v4, v5

    mul-int/2addr v4, v3

    sub-int/2addr v7, v4

    invoke-virtual {v2, v7}, Landroid/view/View;->offsetLeftAndRight(I)V

    goto :goto_3

    :cond_7
    iget-object v4, v4, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$wA;->KLFTb:Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;

    iget v4, v4, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;->KLFTb:I

    iget v5, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Gd:I

    mul-int/2addr v5, v4

    mul-int/2addr v4, v3

    iget v7, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->huTpC:I

    if-ne v7, v6, :cond_8

    sub-int/2addr v5, v4

    invoke-virtual {v2, v5}, Landroid/view/View;->offsetLeftAndRight(I)V

    goto :goto_3

    :cond_8
    sub-int/2addr v5, v4

    invoke-virtual {v2, v5}, Landroid/view/View;->offsetTopAndBottom(I)V

    :goto_3
    add-int/lit8 v1, v1, 0x1

    goto :goto_2

    :cond_9
    return-void
.end method

.method public final JOe(Landroid/view/View;)V
    .locals 2

    iget v0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Pq:I

    add-int/lit8 v0, v0, -0x1

    :goto_0
    if-ltz v0, :cond_0

    iget-object v1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->diqgf:[Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;

    aget-object v1, v1, v0

    invoke-virtual {v1, p1}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;->mjFkc(Landroid/view/View;)V

    add-int/lit8 v0, v0, -0x1

    goto :goto_0

    :cond_0
    return-void
.end method

.method public final KSf(I)I
    .locals 3

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->zvd()I

    move-result v0

    const/4 v1, -0x1

    const/4 v2, 0x1

    if-nez v0, :cond_1

    iget-boolean p0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->VocHEe:Z

    if-eqz p0, :cond_0

    move v1, v2

    :cond_0
    return v1

    :cond_1
    invoke-virtual {p0}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->bWIyu()I

    move-result v0

    if-ge p1, v0, :cond_2

    move p1, v2

    goto :goto_0

    :cond_2
    const/4 p1, 0x0

    :goto_0
    iget-boolean p0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->VocHEe:Z

    if-eq p1, p0, :cond_3

    goto :goto_1

    :cond_3
    move v1, v2

    :goto_1
    return v1
.end method

.method public final KbE(III)I
    .locals 1

    if-nez p2, :cond_0

    if-nez p3, :cond_0

    return p1

    :cond_0
    invoke-static {p1}, Landroid/view/View$MeasureSpec;->getMode(I)I

    move-result p0

    const/high16 v0, -0x80000000

    if-eq p0, v0, :cond_2

    const/high16 v0, 0x40000000    # 2.0f

    if-ne p0, v0, :cond_1

    goto :goto_0

    :cond_1
    return p1

    :cond_2
    :goto_0
    invoke-static {p1}, Landroid/view/View$MeasureSpec;->getSize(I)I

    move-result p1

    sub-int/2addr p1, p2

    sub-int/2addr p1, p3

    const/4 p2, 0x0

    invoke-static {p2, p1}, Ljava/lang/Math;->max(II)I

    move-result p1

    invoke-static {p1, p0}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result p0

    return p0
.end method

.method public LlB(ILandroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;)I
    .locals 2

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->zvd()I

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_3

    if-nez p1, :cond_0

    goto :goto_1

    :cond_0
    invoke-virtual {p0, p1, p3}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->EeoThB(ILandroidx/recyclerview/widget/RecyclerView$VocHEe;)V

    iget-object v0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->HGpJ:Landroidx/recyclerview/widget/JHa;

    invoke-virtual {p0, p2, v0, p3}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->vZ(Landroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/JHa;Landroidx/recyclerview/widget/RecyclerView$VocHEe;)I

    move-result p3

    iget-object v0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->HGpJ:Landroidx/recyclerview/widget/JHa;

    iget v0, v0, Landroidx/recyclerview/widget/JHa;->AZxh:I

    if-ge v0, p3, :cond_1

    goto :goto_0

    :cond_1
    if-gez p1, :cond_2

    neg-int p1, p3

    goto :goto_0

    :cond_2
    move p1, p3

    :goto_0
    iget-object p3, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    neg-int v0, p1

    invoke-virtual {p3, v0}, Landroidx/recyclerview/widget/qdMbNW;->IEE(I)V

    iget-boolean p3, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->VocHEe:Z

    iput-boolean p3, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Ne:Z

    iget-object p3, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->HGpJ:Landroidx/recyclerview/widget/JHa;

    iput v1, p3, Landroidx/recyclerview/widget/JHa;->AZxh:I

    invoke-virtual {p0, p2, p3}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->xBQUgd(Landroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/JHa;)V

    return p1

    :cond_3
    :goto_1
    return v1
.end method

.method public final MC(I)Landroidx/recyclerview/widget/StaggeredGridLayoutManager$ZfxDd$mjFkc;
    .locals 4

    new-instance v0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$ZfxDd$mjFkc;

    invoke-direct {v0}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$ZfxDd$mjFkc;-><init>()V

    iget v1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Pq:I

    new-array v1, v1, [I

    iput-object v1, v0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$ZfxDd$mjFkc;->wA:[I

    const/4 v1, 0x0

    :goto_0
    iget v2, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Pq:I

    if-ge v1, v2, :cond_0

    iget-object v2, v0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$ZfxDd$mjFkc;->wA:[I

    iget-object v3, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->diqgf:[Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;

    aget-object v3, v3, v1

    invoke-virtual {v3, p1}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;->qGY(I)I

    move-result v3

    sub-int/2addr v3, p1

    aput v3, v2, v1

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_0
    return-object v0
.end method

.method public final MFekjo(Landroidx/recyclerview/widget/RecyclerView$Ucbh;I)V
    .locals 6

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->zvd()I

    move-result v0

    const/4 v1, 0x1

    sub-int/2addr v0, v1

    :goto_0
    if-ltz v0, :cond_5

    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->KLMXS(I)Landroid/view/View;

    move-result-object v2

    iget-object v3, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v3, v2}, Landroidx/recyclerview/widget/qdMbNW;->xJ(Landroid/view/View;)I

    move-result v3

    if-lt v3, p2, :cond_5

    iget-object v3, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v3, v2}, Landroidx/recyclerview/widget/qdMbNW;->fehf(Landroid/view/View;)I

    move-result v3

    if-lt v3, p2, :cond_5

    invoke-virtual {v2}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v3

    check-cast v3, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$wA;

    iget-boolean v4, v3, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$wA;->JHa:Z

    if-eqz v4, :cond_2

    const/4 v3, 0x0

    move v4, v3

    :goto_1
    iget v5, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Pq:I

    if-ge v4, v5, :cond_1

    iget-object v5, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->diqgf:[Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;

    aget-object v5, v5, v4

    iget-object v5, v5, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;->mjFkc:Ljava/util/ArrayList;

    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    move-result v5

    if-ne v5, v1, :cond_0

    return-void

    :cond_0
    add-int/lit8 v4, v4, 0x1

    goto :goto_1

    :cond_1
    :goto_2
    iget v4, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Pq:I

    if-ge v3, v4, :cond_4

    iget-object v4, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->diqgf:[Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;

    aget-object v4, v4, v3

    invoke-virtual {v4}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;->Pq()V

    add-int/lit8 v3, v3, 0x1

    goto :goto_2

    :cond_2
    iget-object v4, v3, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$wA;->KLFTb:Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;

    iget-object v4, v4, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;->mjFkc:Ljava/util/ArrayList;

    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v4

    if-ne v4, v1, :cond_3

    return-void

    :cond_3
    iget-object v3, v3, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$wA;->KLFTb:Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;

    invoke-virtual {v3}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;->Pq()V

    :cond_4
    invoke-virtual {p0, v2, p1}, Landroidx/recyclerview/widget/RecyclerView$qGY;->RWyiuY(Landroid/view/View;Landroidx/recyclerview/widget/RecyclerView$Ucbh;)V

    add-int/lit8 v0, v0, -0x1

    goto :goto_0

    :cond_5
    return-void
.end method

.method public MiMN()Z
    .locals 1

    iget p0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->huTpC:I

    const/4 v0, 0x1

    if-ne p0, v0, :cond_0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public final Mpf(I)I
    .locals 2

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->zvd()I

    move-result v0

    add-int/lit8 v0, v0, -0x1

    :goto_0
    if-ltz v0, :cond_1

    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->KLMXS(I)Landroid/view/View;

    move-result-object v1

    invoke-virtual {p0, v1}, Landroidx/recyclerview/widget/RecyclerView$qGY;->tQ(Landroid/view/View;)I

    move-result v1

    if-ltz v1, :cond_0

    if-ge v1, p1, :cond_0

    return v1

    :cond_0
    add-int/lit8 v0, v0, -0x1

    goto :goto_0

    :cond_1
    const/4 p0, 0x0

    return p0
.end method

.method public NV(I)V
    .locals 0

    if-nez p1, :cond_0

    invoke-virtual {p0}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Vptz()Z

    :cond_0
    return-void
.end method

.method public Ne(Landroid/view/ViewGroup$LayoutParams;)Landroidx/recyclerview/widget/RecyclerView$fehf;
    .locals 0

    instance-of p0, p1, Landroid/view/ViewGroup$MarginLayoutParams;

    if-eqz p0, :cond_0

    new-instance p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$wA;

    check-cast p1, Landroid/view/ViewGroup$MarginLayoutParams;

    invoke-direct {p0, p1}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$wA;-><init>(Landroid/view/ViewGroup$MarginLayoutParams;)V

    return-object p0

    :cond_0
    new-instance p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$wA;

    invoke-direct {p0, p1}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$wA;-><init>(Landroid/view/ViewGroup$LayoutParams;)V

    return-object p0
.end method

.method public OjSQV(Landroid/content/Context;Landroid/util/AttributeSet;)Landroidx/recyclerview/widget/RecyclerView$fehf;
    .locals 0

    new-instance p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$wA;

    invoke-direct {p0, p1, p2}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$wA;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    return-object p0
.end method

.method public Otxclu()Z
    .locals 1

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->WGXroI()I

    move-result p0

    const/4 v0, 0x1

    if-ne p0, v0, :cond_0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public Pq(Landroidx/recyclerview/widget/RecyclerView$VocHEe;)I
    .locals 0

    invoke-direct {p0, p1}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->HX(Landroidx/recyclerview/widget/RecyclerView$VocHEe;)I

    move-result p0

    return p0
.end method

.method public QyMqpM()Z
    .locals 6

    iget-object v0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->diqgf:[Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;

    const/4 v1, 0x0

    aget-object v0, v0, v1

    const/high16 v2, -0x80000000

    invoke-virtual {v0, v2}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;->qGY(I)I

    move-result v0

    const/4 v3, 0x1

    move v4, v3

    :goto_0
    iget v5, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Pq:I

    if-ge v4, v5, :cond_1

    iget-object v5, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->diqgf:[Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;

    aget-object v5, v5, v4

    invoke-virtual {v5, v2}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;->qGY(I)I

    move-result v5

    if-eq v5, v0, :cond_0

    return v1

    :cond_0
    add-int/lit8 v4, v4, 0x1

    goto :goto_0

    :cond_1
    return v3
.end method

.method public QyqF(ILandroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;)I
    .locals 0

    invoke-virtual {p0, p1, p2, p3}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->LlB(ILandroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;)I

    move-result p0

    return p0
.end method

.method public final RWb(Landroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;Z)V
    .locals 8

    iget-object v0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->cMLeY:Landroidx/recyclerview/widget/StaggeredGridLayoutManager$AZxh;

    iget-object v1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->xrEuO:Landroidx/recyclerview/widget/StaggeredGridLayoutManager$KLFTb;

    const/4 v2, -0x1

    if-nez v1, :cond_0

    iget v1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->lB:I

    if-eq v1, v2, :cond_1

    :cond_0
    invoke-virtual {p2}, Landroidx/recyclerview/widget/RecyclerView$VocHEe;->AZxh()I

    move-result v1

    if-nez v1, :cond_1

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/RecyclerView$qGY;->sqndV(Landroidx/recyclerview/widget/RecyclerView$Ucbh;)V

    invoke-virtual {v0}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$AZxh;->wA()V

    return-void

    :cond_1
    iget-boolean v1, v0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$AZxh;->KLFTb:Z

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-eqz v1, :cond_3

    iget v1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->lB:I

    if-ne v1, v2, :cond_3

    iget-object v1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->xrEuO:Landroidx/recyclerview/widget/StaggeredGridLayoutManager$KLFTb;

    if-eqz v1, :cond_2

    goto :goto_0

    :cond_2
    move v1, v3

    goto :goto_1

    :cond_3
    :goto_0
    move v1, v4

    :goto_1
    if-eqz v1, :cond_5

    invoke-virtual {v0}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$AZxh;->wA()V

    iget-object v5, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->xrEuO:Landroidx/recyclerview/widget/StaggeredGridLayoutManager$KLFTb;

    if-eqz v5, :cond_4

    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->pJeaSR(Landroidx/recyclerview/widget/StaggeredGridLayoutManager$AZxh;)V

    goto :goto_2

    :cond_4
    invoke-direct {p0}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->kOlLW()V

    iget-boolean v5, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->VocHEe:Z

    iput-boolean v5, v0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$AZxh;->wA:Z

    :goto_2
    invoke-virtual {p0, p2, v0}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->xVYW(Landroidx/recyclerview/widget/RecyclerView$VocHEe;Landroidx/recyclerview/widget/StaggeredGridLayoutManager$AZxh;)V

    iput-boolean v4, v0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$AZxh;->KLFTb:Z

    :cond_5
    iget-object v5, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->xrEuO:Landroidx/recyclerview/widget/StaggeredGridLayoutManager$KLFTb;

    if-nez v5, :cond_7

    iget v5, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->lB:I

    if-ne v5, v2, :cond_7

    iget-boolean v5, v0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$AZxh;->wA:Z

    iget-boolean v6, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Ne:Z

    if-ne v5, v6, :cond_6

    invoke-virtual {p0}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Otxclu()Z

    move-result v5

    iget-boolean v6, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->CqaNbM:Z

    if-eq v5, v6, :cond_7

    :cond_6
    iget-object v5, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->mByQ:Landroidx/recyclerview/widget/StaggeredGridLayoutManager$ZfxDd;

    invoke-virtual {v5}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$ZfxDd;->AZxh()V

    iput-boolean v4, v0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$AZxh;->ZfxDd:Z

    :cond_7
    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->zvd()I

    move-result v5

    if-lez v5, :cond_e

    iget-object v5, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->xrEuO:Landroidx/recyclerview/widget/StaggeredGridLayoutManager$KLFTb;

    if-eqz v5, :cond_8

    iget v5, v5, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$KLFTb;->wA:I

    if-ge v5, v4, :cond_e

    :cond_8
    iget-boolean v5, v0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$AZxh;->ZfxDd:Z

    if-eqz v5, :cond_a

    move v1, v3

    :goto_3
    iget v5, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Pq:I

    if-ge v1, v5, :cond_e

    iget-object v5, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->diqgf:[Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;

    aget-object v5, v5, v1

    invoke-virtual {v5}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;->KLFTb()V

    iget v5, v0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$AZxh;->AZxh:I

    const/high16 v6, -0x80000000

    if-eq v5, v6, :cond_9

    iget-object v6, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->diqgf:[Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;

    aget-object v6, v6, v1

    invoke-virtual {v6, v5}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;->Ucbh(I)V

    :cond_9
    add-int/lit8 v1, v1, 0x1

    goto :goto_3

    :cond_a
    if-nez v1, :cond_c

    iget-object v1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->cMLeY:Landroidx/recyclerview/widget/StaggeredGridLayoutManager$AZxh;

    iget-object v1, v1, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$AZxh;->JHa:[I

    if-nez v1, :cond_b

    goto :goto_5

    :cond_b
    move v1, v3

    :goto_4
    iget v5, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Pq:I

    if-ge v1, v5, :cond_e

    iget-object v5, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->diqgf:[Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;

    aget-object v5, v5, v1

    invoke-virtual {v5}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;->KLFTb()V

    iget-object v6, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->cMLeY:Landroidx/recyclerview/widget/StaggeredGridLayoutManager$AZxh;

    iget-object v6, v6, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$AZxh;->JHa:[I

    aget v6, v6, v1

    invoke-virtual {v5, v6}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;->Ucbh(I)V

    add-int/lit8 v1, v1, 0x1

    goto :goto_4

    :cond_c
    :goto_5
    move v1, v3

    :goto_6
    iget v5, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Pq:I

    if-ge v1, v5, :cond_d

    iget-object v5, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->diqgf:[Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;

    aget-object v5, v5, v1

    iget-boolean v6, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->VocHEe:Z

    iget v7, v0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$AZxh;->AZxh:I

    invoke-virtual {v5, v6, v7}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;->AZxh(ZI)V

    add-int/lit8 v1, v1, 0x1

    goto :goto_6

    :cond_d
    iget-object v1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->cMLeY:Landroidx/recyclerview/widget/StaggeredGridLayoutManager$AZxh;

    iget-object v5, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->diqgf:[Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;

    invoke-virtual {v1, v5}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$AZxh;->ZfxDd([Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;)V

    :cond_e
    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/RecyclerView$qGY;->Gd(Landroidx/recyclerview/widget/RecyclerView$Ucbh;)V

    iget-object v1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->HGpJ:Landroidx/recyclerview/widget/JHa;

    iput-boolean v3, v1, Landroidx/recyclerview/widget/JHa;->mjFkc:Z

    iput-boolean v3, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->rWxwaT:Z

    iget-object v1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Ucbh:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v1}, Landroidx/recyclerview/widget/qdMbNW;->YoKzxo()I

    move-result v1

    invoke-virtual {p0, v1}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->kw(I)V

    iget v1, v0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$AZxh;->mjFkc:I

    invoke-virtual {p0, v1, p2}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->gjvQ(ILandroidx/recyclerview/widget/RecyclerView$VocHEe;)V

    iget-boolean v1, v0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$AZxh;->wA:Z

    if-eqz v1, :cond_f

    invoke-virtual {p0, v2}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Es(I)V

    iget-object v1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->HGpJ:Landroidx/recyclerview/widget/JHa;

    invoke-virtual {p0, p1, v1, p2}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->vZ(Landroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/JHa;Landroidx/recyclerview/widget/RecyclerView$VocHEe;)I

    invoke-virtual {p0, v4}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Es(I)V

    iget-object v1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->HGpJ:Landroidx/recyclerview/widget/JHa;

    iget v2, v0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$AZxh;->mjFkc:I

    iget v5, v1, Landroidx/recyclerview/widget/JHa;->ZfxDd:I

    add-int/2addr v2, v5

    iput v2, v1, Landroidx/recyclerview/widget/JHa;->wA:I

    invoke-virtual {p0, p1, v1, p2}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->vZ(Landroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/JHa;Landroidx/recyclerview/widget/RecyclerView$VocHEe;)I

    goto :goto_7

    :cond_f
    invoke-virtual {p0, v4}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Es(I)V

    iget-object v1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->HGpJ:Landroidx/recyclerview/widget/JHa;

    invoke-virtual {p0, p1, v1, p2}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->vZ(Landroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/JHa;Landroidx/recyclerview/widget/RecyclerView$VocHEe;)I

    invoke-virtual {p0, v2}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Es(I)V

    iget-object v1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->HGpJ:Landroidx/recyclerview/widget/JHa;

    iget v2, v0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$AZxh;->mjFkc:I

    iget v5, v1, Landroidx/recyclerview/widget/JHa;->ZfxDd:I

    add-int/2addr v2, v5

    iput v2, v1, Landroidx/recyclerview/widget/JHa;->wA:I

    invoke-virtual {p0, p1, v1, p2}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->vZ(Landroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/JHa;Landroidx/recyclerview/widget/RecyclerView$VocHEe;)I

    :goto_7
    invoke-virtual {p0}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->IPpyV()V

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->zvd()I

    move-result v1

    if-lez v1, :cond_11

    iget-boolean v1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->VocHEe:Z

    if-eqz v1, :cond_10

    invoke-virtual {p0, p1, p2, v4}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Hk(Landroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;Z)V

    invoke-virtual {p0, p1, p2, v3}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->oJ(Landroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;Z)V

    goto :goto_8

    :cond_10
    invoke-virtual {p0, p1, p2, v4}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->oJ(Landroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;Z)V

    invoke-virtual {p0, p1, p2, v3}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Hk(Landroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;Z)V

    :cond_11
    :goto_8
    if-eqz p3, :cond_13

    invoke-virtual {p2}, Landroidx/recyclerview/widget/RecyclerView$VocHEe;->KLFTb()Z

    move-result p3

    if-nez p3, :cond_13

    iget p3, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->OjSQV:I

    if-eqz p3, :cond_13

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->zvd()I

    move-result p3

    if-lez p3, :cond_13

    iget-boolean p3, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->rWxwaT:Z

    if-nez p3, :cond_12

    invoke-virtual {p0}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->tPvjn()Landroid/view/View;

    move-result-object p3

    if-eqz p3, :cond_13

    :cond_12
    iget-object p3, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->vadzgd:Ljava/lang/Runnable;

    invoke-virtual {p0, p3}, Landroidx/recyclerview/widget/RecyclerView$qGY;->uxlM(Ljava/lang/Runnable;)Z

    invoke-virtual {p0}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Vptz()Z

    move-result p3

    if-eqz p3, :cond_13

    goto :goto_9

    :cond_13
    move v4, v3

    :goto_9
    invoke-virtual {p2}, Landroidx/recyclerview/widget/RecyclerView$VocHEe;->KLFTb()Z

    move-result p3

    if-eqz p3, :cond_14

    iget-object p3, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->cMLeY:Landroidx/recyclerview/widget/StaggeredGridLayoutManager$AZxh;

    invoke-virtual {p3}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$AZxh;->wA()V

    :cond_14
    iget-boolean p3, v0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$AZxh;->wA:Z

    iput-boolean p3, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Ne:Z

    invoke-virtual {p0}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Otxclu()Z

    move-result p3

    iput-boolean p3, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->CqaNbM:Z

    if-eqz v4, :cond_15

    iget-object p3, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->cMLeY:Landroidx/recyclerview/widget/StaggeredGridLayoutManager$AZxh;

    invoke-virtual {p3}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$AZxh;->wA()V

    invoke-virtual {p0, p1, p2, v3}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->RWb(Landroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;Z)V

    :cond_15
    return-void
.end method

.method public Rsp(Z)Landroid/view/View;
    .locals 8

    iget-object v0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v0}, Landroidx/recyclerview/widget/qdMbNW;->MiMN()I

    move-result v0

    iget-object v1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v1}, Landroidx/recyclerview/widget/qdMbNW;->qdMbNW()I

    move-result v1

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->zvd()I

    move-result v2

    const/4 v3, 0x0

    const/4 v4, 0x0

    :goto_0
    if-ge v4, v2, :cond_4

    invoke-virtual {p0, v4}, Landroidx/recyclerview/widget/RecyclerView$qGY;->KLMXS(I)Landroid/view/View;

    move-result-object v5

    iget-object v6, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v6, v5}, Landroidx/recyclerview/widget/qdMbNW;->xJ(Landroid/view/View;)I

    move-result v6

    iget-object v7, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v7, v5}, Landroidx/recyclerview/widget/qdMbNW;->ZfxDd(Landroid/view/View;)I

    move-result v7

    if-le v7, v0, :cond_3

    if-lt v6, v1, :cond_0

    goto :goto_2

    :cond_0
    if-ge v6, v0, :cond_2

    if-nez p1, :cond_1

    goto :goto_1

    :cond_1
    if-nez v3, :cond_3

    move-object v3, v5

    goto :goto_2

    :cond_2
    :goto_1
    return-object v5

    :cond_3
    :goto_2
    add-int/lit8 v4, v4, 0x1

    goto :goto_0

    :cond_4
    return-object v3
.end method

.method public final Sx(I)I
    .locals 3

    iget-object v0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->diqgf:[Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;

    const/4 v1, 0x0

    aget-object v0, v0, v1

    invoke-virtual {v0, p1}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;->qGY(I)I

    move-result v0

    const/4 v1, 0x1

    :goto_0
    iget v2, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Pq:I

    if-ge v1, v2, :cond_1

    iget-object v2, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->diqgf:[Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;

    aget-object v2, v2, v1

    invoke-virtual {v2, p1}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;->qGY(I)I

    move-result v2

    if-ge v2, v0, :cond_0

    move v0, v2

    :cond_0
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_1
    return v0
.end method

.method public TFbkuO()V
    .locals 1

    iget-object v0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->mByQ:Landroidx/recyclerview/widget/StaggeredGridLayoutManager$ZfxDd;

    invoke-virtual {v0}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$ZfxDd;->AZxh()V

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->mzUGzO()V

    return-void
.end method

.method public final TvfBiy(I)I
    .locals 4

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->zvd()I

    move-result v0

    const/4 v1, 0x0

    move v2, v1

    :goto_0
    if-ge v2, v0, :cond_1

    invoke-virtual {p0, v2}, Landroidx/recyclerview/widget/RecyclerView$qGY;->KLMXS(I)Landroid/view/View;

    move-result-object v3

    invoke-virtual {p0, v3}, Landroidx/recyclerview/widget/RecyclerView$qGY;->tQ(Landroid/view/View;)I

    move-result v3

    if-ltz v3, :cond_0

    if-ge v3, p1, :cond_0

    return v3

    :cond_0
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_1
    return v1
.end method

.method public Tw(I)V
    .locals 2

    iget-object v0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->xrEuO:Landroidx/recyclerview/widget/StaggeredGridLayoutManager$KLFTb;

    if-eqz v0, :cond_0

    iget v1, v0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$KLFTb;->mjFkc:I

    if-eq v1, p1, :cond_0

    invoke-virtual {v0}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$KLFTb;->mjFkc()V

    :cond_0
    iput p1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->lB:I

    const/high16 p1, -0x80000000

    iput p1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->wJVbdd:I

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->mzUGzO()V

    return-void
.end method

.method public final UDcil(I)I
    .locals 3

    iget-object v0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->diqgf:[Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;

    const/4 v1, 0x0

    aget-object v0, v0, v1

    invoke-virtual {v0, p1}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;->VA(I)I

    move-result v0

    const/4 v1, 0x1

    :goto_0
    iget v2, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Pq:I

    if-ge v1, v2, :cond_1

    iget-object v2, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->diqgf:[Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;

    aget-object v2, v2, v1

    invoke-virtual {v2, p1}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;->VA(I)I

    move-result v2

    if-le v2, v0, :cond_0

    move v0, v2

    :cond_0
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_1
    return v0
.end method

.method public final UOnCkw(I)I
    .locals 3

    iget-object v0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->diqgf:[Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;

    const/4 v1, 0x0

    aget-object v0, v0, v1

    invoke-virtual {v0, p1}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;->VA(I)I

    move-result v0

    const/4 v1, 0x1

    :goto_0
    iget v2, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Pq:I

    if-ge v1, v2, :cond_1

    iget-object v2, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->diqgf:[Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;

    aget-object v2, v2, v1

    invoke-virtual {v2, p1}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;->VA(I)I

    move-result v2

    if-ge v2, v0, :cond_0

    move v0, v2

    :cond_0
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_1
    return v0
.end method

.method public final UPU(Landroidx/recyclerview/widget/RecyclerView$Ucbh;I)V
    .locals 5

    :goto_0
    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->zvd()I

    move-result v0

    if-lez v0, :cond_5

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->KLMXS(I)Landroid/view/View;

    move-result-object v1

    iget-object v2, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v2, v1}, Landroidx/recyclerview/widget/qdMbNW;->ZfxDd(Landroid/view/View;)I

    move-result v2

    if-gt v2, p2, :cond_5

    iget-object v2, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v2, v1}, Landroidx/recyclerview/widget/qdMbNW;->qGY(Landroid/view/View;)I

    move-result v2

    if-gt v2, p2, :cond_5

    invoke-virtual {v1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v2

    check-cast v2, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$wA;

    iget-boolean v3, v2, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$wA;->JHa:Z

    const/4 v4, 0x1

    if-eqz v3, :cond_2

    move v2, v0

    :goto_1
    iget v3, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Pq:I

    if-ge v2, v3, :cond_1

    iget-object v3, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->diqgf:[Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;

    aget-object v3, v3, v2

    iget-object v3, v3, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;->mjFkc:Ljava/util/ArrayList;

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ne v3, v4, :cond_0

    return-void

    :cond_0
    add-int/lit8 v2, v2, 0x1

    goto :goto_1

    :cond_1
    :goto_2
    iget v2, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Pq:I

    if-ge v0, v2, :cond_4

    iget-object v2, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->diqgf:[Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;

    aget-object v2, v2, v0

    invoke-virtual {v2}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;->diqgf()V

    add-int/lit8 v0, v0, 0x1

    goto :goto_2

    :cond_2
    iget-object v0, v2, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$wA;->KLFTb:Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;

    iget-object v0, v0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;->mjFkc:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-ne v0, v4, :cond_3

    return-void

    :cond_3
    iget-object v0, v2, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$wA;->KLFTb:Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;

    invoke-virtual {v0}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;->diqgf()V

    :cond_4
    invoke-virtual {p0, v1, p1}, Landroidx/recyclerview/widget/RecyclerView$qGY;->RWyiuY(Landroid/view/View;Landroidx/recyclerview/widget/RecyclerView$Ucbh;)V

    goto :goto_0

    :cond_5
    return-void
.end method

.method public Ucbh(Landroidx/recyclerview/widget/RecyclerView$VocHEe;)I
    .locals 0

    invoke-direct {p0, p1}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->HX(Landroidx/recyclerview/widget/RecyclerView$VocHEe;)I

    move-result p0

    return p0
.end method

.method public VA()Z
    .locals 0

    iget p0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->huTpC:I

    if-nez p0, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method

.method public Vgyli(Landroidx/recyclerview/widget/RecyclerView$lgHUyS;Landroidx/recyclerview/widget/RecyclerView$lgHUyS;)V
    .locals 0

    iget-object p1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->mByQ:Landroidx/recyclerview/widget/StaggeredGridLayoutManager$ZfxDd;

    invoke-virtual {p1}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$ZfxDd;->AZxh()V

    const/4 p1, 0x0

    :goto_0
    iget p2, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Pq:I

    if-ge p1, p2, :cond_0

    iget-object p2, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->diqgf:[Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;

    aget-object p2, p2, p1

    invoke-virtual {p2}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;->KLFTb()V

    add-int/lit8 p1, p1, 0x1

    goto :goto_0

    :cond_0
    return-void
.end method

.method public Vptz()Z
    .locals 7

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->zvd()I

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_7

    iget v0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->OjSQV:I

    if-eqz v0, :cond_7

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->gtIJp()Z

    move-result v0

    if-nez v0, :cond_0

    goto :goto_3

    :cond_0
    iget-boolean v0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->VocHEe:Z

    if-eqz v0, :cond_1

    invoke-virtual {p0}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->XyP()I

    move-result v0

    invoke-virtual {p0}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->bWIyu()I

    move-result v2

    goto :goto_0

    :cond_1
    invoke-virtual {p0}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->bWIyu()I

    move-result v0

    invoke-virtual {p0}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->XyP()I

    move-result v2

    :goto_0
    const/4 v3, 0x1

    if-nez v0, :cond_2

    invoke-virtual {p0}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->tPvjn()Landroid/view/View;

    move-result-object v4

    if-eqz v4, :cond_2

    iget-object v0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->mByQ:Landroidx/recyclerview/widget/StaggeredGridLayoutManager$ZfxDd;

    invoke-virtual {v0}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$ZfxDd;->AZxh()V

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->VfB()V

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->mzUGzO()V

    return v3

    :cond_2
    iget-boolean v4, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->rWxwaT:Z

    if-nez v4, :cond_3

    return v1

    :cond_3
    iget-boolean v4, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->VocHEe:Z

    const/4 v5, -0x1

    if-eqz v4, :cond_4

    move v4, v5

    goto :goto_1

    :cond_4
    move v4, v3

    :goto_1
    iget-object v6, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->mByQ:Landroidx/recyclerview/widget/StaggeredGridLayoutManager$ZfxDd;

    add-int/2addr v2, v3

    invoke-virtual {v6, v0, v2, v4, v3}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$ZfxDd;->KLFTb(IIIZ)Landroidx/recyclerview/widget/StaggeredGridLayoutManager$ZfxDd$mjFkc;

    move-result-object v6

    if-nez v6, :cond_5

    iput-boolean v1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->rWxwaT:Z

    iget-object p0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->mByQ:Landroidx/recyclerview/widget/StaggeredGridLayoutManager$ZfxDd;

    invoke-virtual {p0, v2}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$ZfxDd;->ZfxDd(I)I

    return v1

    :cond_5
    iget-object v1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->mByQ:Landroidx/recyclerview/widget/StaggeredGridLayoutManager$ZfxDd;

    iget v2, v6, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$ZfxDd$mjFkc;->mjFkc:I

    mul-int/2addr v4, v5

    invoke-virtual {v1, v0, v2, v4, v3}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$ZfxDd;->KLFTb(IIIZ)Landroidx/recyclerview/widget/StaggeredGridLayoutManager$ZfxDd$mjFkc;

    move-result-object v0

    if-nez v0, :cond_6

    iget-object v0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->mByQ:Landroidx/recyclerview/widget/StaggeredGridLayoutManager$ZfxDd;

    iget v1, v6, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$ZfxDd$mjFkc;->mjFkc:I

    invoke-virtual {v0, v1}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$ZfxDd;->ZfxDd(I)I

    goto :goto_2

    :cond_6
    iget-object v1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->mByQ:Landroidx/recyclerview/widget/StaggeredGridLayoutManager$ZfxDd;

    iget v0, v0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$ZfxDd$mjFkc;->mjFkc:I

    add-int/2addr v0, v3

    invoke-virtual {v1, v0}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$ZfxDd;->ZfxDd(I)I

    :goto_2
    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->VfB()V

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->mzUGzO()V

    return v3

    :cond_7
    :goto_3
    return v1
.end method

.method public XD(Landroidx/recyclerview/widget/RecyclerView;Landroidx/recyclerview/widget/RecyclerView$Ucbh;)V
    .locals 1

    invoke-super {p0, p1, p2}, Landroidx/recyclerview/widget/RecyclerView$qGY;->XD(Landroidx/recyclerview/widget/RecyclerView;Landroidx/recyclerview/widget/RecyclerView$Ucbh;)V

    iget-object p2, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->vadzgd:Ljava/lang/Runnable;

    invoke-virtual {p0, p2}, Landroidx/recyclerview/widget/RecyclerView$qGY;->uxlM(Ljava/lang/Runnable;)Z

    const/4 p2, 0x0

    :goto_0
    iget v0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Pq:I

    if-ge p2, v0, :cond_0

    iget-object v0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->diqgf:[Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;

    aget-object v0, v0, p2

    invoke-virtual {v0}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;->KLFTb()V

    add-int/lit8 p2, p2, 0x1

    goto :goto_0

    :cond_0
    invoke-virtual {p1}, Landroidx/recyclerview/widget/RecyclerView;->requestLayout()V

    return-void
.end method

.method public XgAT(Landroidx/recyclerview/widget/RecyclerView;II)V
    .locals 0

    const/4 p1, 0x2

    invoke-virtual {p0, p2, p3, p1}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->wGscSa(III)V

    return-void
.end method

.method public Xxz(Landroidx/recyclerview/widget/RecyclerView$VocHEe;)V
    .locals 0

    invoke-super {p0, p1}, Landroidx/recyclerview/widget/RecyclerView$qGY;->Xxz(Landroidx/recyclerview/widget/RecyclerView$VocHEe;)V

    const/4 p1, -0x1

    iput p1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->lB:I

    const/high16 p1, -0x80000000

    iput p1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->wJVbdd:I

    const/4 p1, 0x0

    iput-object p1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->xrEuO:Landroidx/recyclerview/widget/StaggeredGridLayoutManager$KLFTb;

    iget-object p0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->cMLeY:Landroidx/recyclerview/widget/StaggeredGridLayoutManager$AZxh;

    invoke-virtual {p0}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$AZxh;->wA()V

    return-void
.end method

.method public XyP()I
    .locals 1

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->zvd()I

    move-result v0

    if-nez v0, :cond_0

    const/4 p0, 0x0

    goto :goto_0

    :cond_0
    add-int/lit8 v0, v0, -0x1

    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->KLMXS(I)Landroid/view/View;

    move-result-object v0

    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->tQ(Landroid/view/View;)I

    move-result p0

    :goto_0
    return p0
.end method

.method public YoKzxo(Landroidx/recyclerview/widget/RecyclerView$fehf;)Z
    .locals 0

    instance-of p0, p1, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$wA;

    return p0
.end method

.method public ZGL(I)V
    .locals 1

    if-eqz p1, :cond_1

    const/4 v0, 0x1

    if-ne p1, v0, :cond_0

    goto :goto_0

    :cond_0
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string p1, "invalid orientation."

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_1
    :goto_0
    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->lgHUyS(Ljava/lang/String;)V

    iget v0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->huTpC:I

    if-ne p1, v0, :cond_2

    return-void

    :cond_2
    iput p1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->huTpC:I

    iget-object p1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    iget-object v0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Ucbh:Landroidx/recyclerview/widget/qdMbNW;

    iput-object v0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    iput-object p1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Ucbh:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->mzUGzO()V

    return-void
.end method

.method public final aDq()V
    .locals 1

    iget v0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->huTpC:I

    invoke-static {p0, v0}, Landroidx/recyclerview/widget/qdMbNW;->AZxh(Landroidx/recyclerview/widget/RecyclerView$qGY;I)Landroidx/recyclerview/widget/qdMbNW;

    move-result-object v0

    iput-object v0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    iget v0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->huTpC:I

    rsub-int/lit8 v0, v0, 0x1

    invoke-static {p0, v0}, Landroidx/recyclerview/widget/qdMbNW;->AZxh(Landroidx/recyclerview/widget/RecyclerView$qGY;I)Landroidx/recyclerview/widget/qdMbNW;

    move-result-object v0

    iput-object v0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Ucbh:Landroidx/recyclerview/widget/qdMbNW;

    return-void
.end method

.method public bWIyu()I
    .locals 2

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->zvd()I

    move-result v0

    const/4 v1, 0x0

    if-nez v0, :cond_0

    goto :goto_0

    :cond_0
    invoke-virtual {p0, v1}, Landroidx/recyclerview/widget/RecyclerView$qGY;->KLMXS(I)Landroid/view/View;

    move-result-object v0

    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->tQ(Landroid/view/View;)I

    move-result v1

    :goto_0
    return v1
.end method

.method public final cdjp(Landroid/view/View;)V
    .locals 2

    iget v0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Pq:I

    add-int/lit8 v0, v0, -0x1

    :goto_0
    if-ltz v0, :cond_0

    iget-object v1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->diqgf:[Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;

    aget-object v1, v1, v0

    invoke-virtual {v1, p1}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;->eyqo(Landroid/view/View;)V

    add-int/lit8 v0, v0, -0x1

    goto :goto_0

    :cond_0
    return-void
.end method

.method public dGDT(Landroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;)V
    .locals 1

    const/4 v0, 0x1

    invoke-virtual {p0, p1, p2, v0}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->RWb(Landroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;Z)V

    return-void
.end method

.method public diqgf(Landroidx/recyclerview/widget/RecyclerView$VocHEe;)I
    .locals 0

    invoke-direct {p0, p1}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->EoC(Landroidx/recyclerview/widget/RecyclerView$VocHEe;)I

    move-result p0

    return p0
.end method

.method public dkKKW()Landroid/os/Parcelable;
    .locals 4

    iget-object v0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->xrEuO:Landroidx/recyclerview/widget/StaggeredGridLayoutManager$KLFTb;

    if-eqz v0, :cond_0

    new-instance v0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$KLFTb;

    iget-object p0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->xrEuO:Landroidx/recyclerview/widget/StaggeredGridLayoutManager$KLFTb;

    invoke-direct {v0, p0}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$KLFTb;-><init>(Landroidx/recyclerview/widget/StaggeredGridLayoutManager$KLFTb;)V

    return-object v0

    :cond_0
    new-instance v0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$KLFTb;

    invoke-direct {v0}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$KLFTb;-><init>()V

    iget-boolean v1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->vI:Z

    iput-boolean v1, v0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$KLFTb;->lgHUyS:Z

    iget-boolean v1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Ne:Z

    iput-boolean v1, v0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$KLFTb;->qdMbNW:Z

    iget-boolean v1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->CqaNbM:Z

    iput-boolean v1, v0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$KLFTb;->Dt:Z

    iget-object v1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->mByQ:Landroidx/recyclerview/widget/StaggeredGridLayoutManager$ZfxDd;

    const/4 v2, 0x0

    if-eqz v1, :cond_1

    iget-object v3, v1, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$ZfxDd;->mjFkc:[I

    if-eqz v3, :cond_1

    iput-object v3, v0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$KLFTb;->JHa:[I

    array-length v3, v3

    iput v3, v0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$KLFTb;->KLFTb:I

    iget-object v1, v1, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$ZfxDd;->AZxh:Ljava/util/List;

    iput-object v1, v0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$KLFTb;->xJ:Ljava/util/List;

    goto :goto_0

    :cond_1
    iput v2, v0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$KLFTb;->KLFTb:I

    :goto_0
    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->zvd()I

    move-result v1

    if-lez v1, :cond_5

    iget-boolean v1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Ne:Z

    if-eqz v1, :cond_2

    invoke-virtual {p0}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->XyP()I

    move-result v1

    goto :goto_1

    :cond_2
    invoke-virtual {p0}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->bWIyu()I

    move-result v1

    :goto_1
    iput v1, v0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$KLFTb;->mjFkc:I

    invoke-virtual {p0}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->xfXeiC()I

    move-result v1

    iput v1, v0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$KLFTb;->AZxh:I

    iget v1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Pq:I

    iput v1, v0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$KLFTb;->wA:I

    new-array v1, v1, [I

    iput-object v1, v0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$KLFTb;->ZfxDd:[I

    :goto_2
    iget v1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Pq:I

    if-ge v2, v1, :cond_6

    iget-boolean v1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Ne:Z

    const/high16 v3, -0x80000000

    if-eqz v1, :cond_3

    iget-object v1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->diqgf:[Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;

    aget-object v1, v1, v2

    invoke-virtual {v1, v3}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;->VA(I)I

    move-result v1

    if-eq v1, v3, :cond_4

    iget-object v3, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v3}, Landroidx/recyclerview/widget/qdMbNW;->qdMbNW()I

    move-result v3

    :goto_3
    sub-int/2addr v1, v3

    goto :goto_4

    :cond_3
    iget-object v1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->diqgf:[Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;

    aget-object v1, v1, v2

    invoke-virtual {v1, v3}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;->qGY(I)I

    move-result v1

    if-eq v1, v3, :cond_4

    iget-object v3, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v3}, Landroidx/recyclerview/widget/qdMbNW;->MiMN()I

    move-result v3

    goto :goto_3

    :cond_4
    :goto_4
    iget-object v3, v0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$KLFTb;->ZfxDd:[I

    aput v1, v3, v2

    add-int/lit8 v2, v2, 0x1

    goto :goto_2

    :cond_5
    const/4 p0, -0x1

    iput p0, v0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$KLFTb;->mjFkc:I

    iput p0, v0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$KLFTb;->AZxh:I

    iput v2, v0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$KLFTb;->wA:I

    :cond_6
    return-object v0
.end method

.method public eEOGOh(I)V
    .locals 2

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->lgHUyS(Ljava/lang/String;)V

    iget v0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Pq:I

    if-eq p1, v0, :cond_1

    invoke-virtual {p0}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->TFbkuO()V

    iput p1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Pq:I

    new-instance p1, Ljava/util/BitSet;

    iget v0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Pq:I

    invoke-direct {p1, v0}, Ljava/util/BitSet;-><init>(I)V

    iput-object p1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->BAnRFn:Ljava/util/BitSet;

    iget p1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Pq:I

    new-array p1, p1, [Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;

    iput-object p1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->diqgf:[Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;

    const/4 p1, 0x0

    :goto_0
    iget v0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Pq:I

    if-ge p1, v0, :cond_0

    iget-object v0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->diqgf:[Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;

    new-instance v1, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;

    invoke-direct {v1, p0, p1}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;-><init>(Landroidx/recyclerview/widget/StaggeredGridLayoutManager;I)V

    aput-object v1, v0, p1

    add-int/lit8 p1, p1, 0x1

    goto :goto_0

    :cond_0
    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->mzUGzO()V

    :cond_1
    return-void
.end method

.method public eQ(Landroidx/recyclerview/widget/RecyclerView;II)V
    .locals 0

    const/4 p1, 0x1

    invoke-virtual {p0, p2, p3, p1}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->wGscSa(III)V

    return-void
.end method

.method public eyqo(Landroidx/recyclerview/widget/RecyclerView$VocHEe;)I
    .locals 0

    invoke-direct {p0, p1}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->CcoH(Landroidx/recyclerview/widget/RecyclerView$VocHEe;)I

    move-result p0

    return p0
.end method

.method public final gJsSk(Landroidx/recyclerview/widget/RecyclerView$VocHEe;Landroidx/recyclerview/widget/StaggeredGridLayoutManager$AZxh;)Z
    .locals 1

    iget-boolean v0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Ne:Z

    if-eqz v0, :cond_0

    invoke-virtual {p1}, Landroidx/recyclerview/widget/RecyclerView$VocHEe;->AZxh()I

    move-result p1

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Mpf(I)I

    move-result p0

    goto :goto_0

    :cond_0
    invoke-virtual {p1}, Landroidx/recyclerview/widget/RecyclerView$VocHEe;->AZxh()I

    move-result p1

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->TvfBiy(I)I

    move-result p0

    :goto_0
    iput p0, p2, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$AZxh;->mjFkc:I

    const/high16 p0, -0x80000000

    iput p0, p2, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$AZxh;->AZxh:I

    const/4 p0, 0x1

    return p0
.end method

.method public final gjvQ(ILandroidx/recyclerview/widget/RecyclerView$VocHEe;)V
    .locals 4

    iget-object v0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->HGpJ:Landroidx/recyclerview/widget/JHa;

    const/4 v1, 0x0

    iput v1, v0, Landroidx/recyclerview/widget/JHa;->AZxh:I

    iput p1, v0, Landroidx/recyclerview/widget/JHa;->wA:I

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->fFz()Z

    move-result v0

    const/4 v2, 0x1

    if-eqz v0, :cond_2

    invoke-virtual {p2}, Landroidx/recyclerview/widget/RecyclerView$VocHEe;->wA()I

    move-result p2

    const/4 v0, -0x1

    if-eq p2, v0, :cond_2

    iget-boolean v0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->VocHEe:Z

    if-ge p2, p1, :cond_0

    move p1, v2

    goto :goto_0

    :cond_0
    move p1, v1

    :goto_0
    if-ne v0, p1, :cond_1

    iget-object p1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {p1}, Landroidx/recyclerview/widget/qdMbNW;->YoKzxo()I

    move-result p1

    move p2, v1

    goto :goto_1

    :cond_1
    iget-object p1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {p1}, Landroidx/recyclerview/widget/qdMbNW;->YoKzxo()I

    move-result p1

    move p2, p1

    move p1, v1

    goto :goto_1

    :cond_2
    move p1, v1

    move p2, p1

    :goto_1
    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->Vnb()Z

    move-result v0

    if-eqz v0, :cond_3

    iget-object v0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->HGpJ:Landroidx/recyclerview/widget/JHa;

    iget-object v3, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v3}, Landroidx/recyclerview/widget/qdMbNW;->MiMN()I

    move-result v3

    sub-int/2addr v3, p2

    iput v3, v0, Landroidx/recyclerview/widget/JHa;->JHa:I

    iget-object p2, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->HGpJ:Landroidx/recyclerview/widget/JHa;

    iget-object v0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v0}, Landroidx/recyclerview/widget/qdMbNW;->qdMbNW()I

    move-result v0

    add-int/2addr v0, p1

    iput v0, p2, Landroidx/recyclerview/widget/JHa;->xJ:I

    goto :goto_2

    :cond_3
    iget-object v0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->HGpJ:Landroidx/recyclerview/widget/JHa;

    iget-object v3, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v3}, Landroidx/recyclerview/widget/qdMbNW;->lgHUyS()I

    move-result v3

    add-int/2addr v3, p1

    iput v3, v0, Landroidx/recyclerview/widget/JHa;->xJ:I

    iget-object p1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->HGpJ:Landroidx/recyclerview/widget/JHa;

    neg-int p2, p2

    iput p2, p1, Landroidx/recyclerview/widget/JHa;->JHa:I

    :goto_2
    iget-object p1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->HGpJ:Landroidx/recyclerview/widget/JHa;

    iput-boolean v1, p1, Landroidx/recyclerview/widget/JHa;->lgHUyS:Z

    iput-boolean v2, p1, Landroidx/recyclerview/widget/JHa;->mjFkc:Z

    iget-object p2, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {p2}, Landroidx/recyclerview/widget/qdMbNW;->ETF()I

    move-result p2

    if-nez p2, :cond_4

    iget-object p0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {p0}, Landroidx/recyclerview/widget/qdMbNW;->lgHUyS()I

    move-result p0

    if-nez p0, :cond_4

    move v1, v2

    :cond_4
    iput-boolean v1, p1, Landroidx/recyclerview/widget/JHa;->qdMbNW:Z

    return-void
.end method

.method public gtr(Landroid/view/View;ILandroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;)Landroid/view/View;
    .locals 8

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->zvd()I

    move-result v0

    const/4 v1, 0x0

    if-nez v0, :cond_0

    return-object v1

    :cond_0
    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/RecyclerView$qGY;->lB(Landroid/view/View;)Landroid/view/View;

    move-result-object p1

    if-nez p1, :cond_1

    return-object v1

    :cond_1
    invoke-direct {p0}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->kOlLW()V

    invoke-direct {p0, p2}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->xbjHT(I)I

    move-result p2

    const/high16 v0, -0x80000000

    if-ne p2, v0, :cond_2

    return-object v1

    :cond_2
    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    check-cast v0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$wA;

    iget-boolean v2, v0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$wA;->JHa:Z

    iget-object v0, v0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$wA;->KLFTb:Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;

    const/4 v3, 0x1

    if-ne p2, v3, :cond_3

    invoke-virtual {p0}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->XyP()I

    move-result v4

    goto :goto_0

    :cond_3
    invoke-virtual {p0}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->bWIyu()I

    move-result v4

    :goto_0
    invoke-virtual {p0, v4, p4}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->gjvQ(ILandroidx/recyclerview/widget/RecyclerView$VocHEe;)V

    invoke-virtual {p0, p2}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Es(I)V

    iget-object v5, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->HGpJ:Landroidx/recyclerview/widget/JHa;

    iget v6, v5, Landroidx/recyclerview/widget/JHa;->ZfxDd:I

    add-int/2addr v6, v4

    iput v6, v5, Landroidx/recyclerview/widget/JHa;->wA:I

    iget-object v6, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v6}, Landroidx/recyclerview/widget/qdMbNW;->YoKzxo()I

    move-result v6

    int-to-float v6, v6

    const v7, 0x3eaaaaab

    mul-float/2addr v6, v7

    float-to-int v6, v6

    iput v6, v5, Landroidx/recyclerview/widget/JHa;->AZxh:I

    iget-object v5, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->HGpJ:Landroidx/recyclerview/widget/JHa;

    iput-boolean v3, v5, Landroidx/recyclerview/widget/JHa;->lgHUyS:Z

    const/4 v6, 0x0

    iput-boolean v6, v5, Landroidx/recyclerview/widget/JHa;->mjFkc:Z

    invoke-virtual {p0, p3, v5, p4}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->vZ(Landroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/JHa;Landroidx/recyclerview/widget/RecyclerView$VocHEe;)I

    iget-boolean p3, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->VocHEe:Z

    iput-boolean p3, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Ne:Z

    if-nez v2, :cond_4

    invoke-virtual {v0, v4, p2}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;->MiMN(II)Landroid/view/View;

    move-result-object p3

    if-eqz p3, :cond_4

    if-eq p3, p1, :cond_4

    return-object p3

    :cond_4
    invoke-virtual {p0, p2}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->jTNPnW(I)Z

    move-result p3

    if-eqz p3, :cond_6

    iget p3, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Pq:I

    sub-int/2addr p3, v3

    :goto_1
    if-ltz p3, :cond_8

    iget-object p4, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->diqgf:[Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;

    aget-object p4, p4, p3

    invoke-virtual {p4, v4, p2}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;->MiMN(II)Landroid/view/View;

    move-result-object p4

    if-eqz p4, :cond_5

    if-eq p4, p1, :cond_5

    return-object p4

    :cond_5
    add-int/lit8 p3, p3, -0x1

    goto :goto_1

    :cond_6
    move p3, v6

    :goto_2
    iget p4, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Pq:I

    if-ge p3, p4, :cond_8

    iget-object p4, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->diqgf:[Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;

    aget-object p4, p4, p3

    invoke-virtual {p4, v4, p2}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;->MiMN(II)Landroid/view/View;

    move-result-object p4

    if-eqz p4, :cond_7

    if-eq p4, p1, :cond_7

    return-object p4

    :cond_7
    add-int/lit8 p3, p3, 0x1

    goto :goto_2

    :cond_8
    iget-boolean p3, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->vI:Z

    xor-int/2addr p3, v3

    const/4 p4, -0x1

    if-ne p2, p4, :cond_9

    move p4, v3

    goto :goto_3

    :cond_9
    move p4, v6

    :goto_3
    if-ne p3, p4, :cond_a

    move p3, v3

    goto :goto_4

    :cond_a
    move p3, v6

    :goto_4
    if-nez v2, :cond_c

    if-eqz p3, :cond_b

    invoke-virtual {v0}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;->JHa()I

    move-result p4

    goto :goto_5

    :cond_b
    invoke-virtual {v0}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;->xJ()I

    move-result p4

    :goto_5
    invoke-virtual {p0, p4}, Landroidx/recyclerview/widget/RecyclerView$qGY;->wJVbdd(I)Landroid/view/View;

    move-result-object p4

    if-eqz p4, :cond_c

    if-eq p4, p1, :cond_c

    return-object p4

    :cond_c
    invoke-virtual {p0, p2}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->jTNPnW(I)Z

    move-result p2

    if-eqz p2, :cond_10

    iget p2, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Pq:I

    sub-int/2addr p2, v3

    :goto_6
    if-ltz p2, :cond_13

    iget p4, v0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;->KLFTb:I

    if-ne p2, p4, :cond_d

    goto :goto_8

    :cond_d
    if-eqz p3, :cond_e

    iget-object p4, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->diqgf:[Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;

    aget-object p4, p4, p2

    invoke-virtual {p4}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;->JHa()I

    move-result p4

    goto :goto_7

    :cond_e
    iget-object p4, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->diqgf:[Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;

    aget-object p4, p4, p2

    invoke-virtual {p4}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;->xJ()I

    move-result p4

    :goto_7
    invoke-virtual {p0, p4}, Landroidx/recyclerview/widget/RecyclerView$qGY;->wJVbdd(I)Landroid/view/View;

    move-result-object p4

    if-eqz p4, :cond_f

    if-eq p4, p1, :cond_f

    return-object p4

    :cond_f
    :goto_8
    add-int/lit8 p2, p2, -0x1

    goto :goto_6

    :cond_10
    :goto_9
    iget p2, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Pq:I

    if-ge v6, p2, :cond_13

    if-eqz p3, :cond_11

    iget-object p2, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->diqgf:[Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;

    aget-object p2, p2, v6

    invoke-virtual {p2}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;->JHa()I

    move-result p2

    goto :goto_a

    :cond_11
    iget-object p2, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->diqgf:[Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;

    aget-object p2, p2, v6

    invoke-virtual {p2}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;->xJ()I

    move-result p2

    :goto_a
    invoke-virtual {p0, p2}, Landroidx/recyclerview/widget/RecyclerView$qGY;->wJVbdd(I)Landroid/view/View;

    move-result-object p2

    if-eqz p2, :cond_12

    if-eq p2, p1, :cond_12

    return-object p2

    :cond_12
    add-int/lit8 v6, v6, 0x1

    goto :goto_9

    :cond_13
    return-object v1
.end method

.method public huTpC(Landroidx/recyclerview/widget/RecyclerView$VocHEe;)I
    .locals 0

    invoke-direct {p0, p1}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->EoC(Landroidx/recyclerview/widget/RecyclerView$VocHEe;)I

    move-result p0

    return p0
.end method

.method public final ih(Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;II)V
    .locals 3

    invoke-virtual {p1}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;->Dt()I

    move-result v0

    const/4 v1, -0x1

    const/4 v2, 0x0

    if-ne p2, v1, :cond_0

    invoke-virtual {p1}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;->rkYL()I

    move-result p2

    add-int/2addr p2, v0

    if-gt p2, p3, :cond_1

    iget-object p0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->BAnRFn:Ljava/util/BitSet;

    iget p1, p1, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;->KLFTb:I

    invoke-virtual {p0, p1, v2}, Ljava/util/BitSet;->set(IZ)V

    goto :goto_0

    :cond_0
    invoke-virtual {p1}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;->ETF()I

    move-result p2

    sub-int/2addr p2, v0

    if-lt p2, p3, :cond_1

    iget-object p0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->BAnRFn:Ljava/util/BitSet;

    iget p1, p1, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;->KLFTb:I

    invoke-virtual {p0, p1, v2}, Ljava/util/BitSet;->set(IZ)V

    :cond_1
    :goto_0
    return-void
.end method

.method public final jTNPnW(I)Z
    .locals 4

    iget v0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->huTpC:I

    const/4 v1, -0x1

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-nez v0, :cond_2

    if-ne p1, v1, :cond_0

    move p1, v3

    goto :goto_0

    :cond_0
    move p1, v2

    :goto_0
    iget-boolean p0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->VocHEe:Z

    if-eq p1, p0, :cond_1

    move v2, v3

    :cond_1
    return v2

    :cond_2
    if-ne p1, v1, :cond_3

    move p1, v3

    goto :goto_1

    :cond_3
    move p1, v2

    :goto_1
    iget-boolean v0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->VocHEe:Z

    if-ne p1, v0, :cond_4

    move p1, v3

    goto :goto_2

    :cond_4
    move p1, v2

    :goto_2
    invoke-virtual {p0}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Otxclu()Z

    move-result p0

    if-ne p1, p0, :cond_5

    move v2, v3

    :cond_5
    return v2
.end method

.method public final jY(I)I
    .locals 3

    iget-object v0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->diqgf:[Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;

    const/4 v1, 0x0

    aget-object v0, v0, v1

    invoke-virtual {v0, p1}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;->qGY(I)I

    move-result v0

    const/4 v1, 0x1

    :goto_0
    iget v2, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Pq:I

    if-ge v1, v2, :cond_1

    iget-object v2, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->diqgf:[Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;

    aget-object v2, v2, v1

    invoke-virtual {v2, p1}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;->qGY(I)I

    move-result v2

    if-le v2, v0, :cond_0

    move v0, v2

    :cond_0
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_1
    return v0
.end method

.method public jpz(Z)V
    .locals 2

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->lgHUyS(Ljava/lang/String;)V

    iget-object v0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->xrEuO:Landroidx/recyclerview/widget/StaggeredGridLayoutManager$KLFTb;

    if-eqz v0, :cond_0

    iget-boolean v1, v0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$KLFTb;->lgHUyS:Z

    if-eq v1, p1, :cond_0

    iput-boolean p1, v0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$KLFTb;->lgHUyS:Z

    :cond_0
    iput-boolean p1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->vI:Z

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->mzUGzO()V

    return-void
.end method

.method public jtz(Landroidx/recyclerview/widget/RecyclerView;III)V
    .locals 0

    const/16 p1, 0x8

    invoke-virtual {p0, p2, p3, p1}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->wGscSa(III)V

    return-void
.end method

.method public kism()Z
    .locals 0

    iget p0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->OjSQV:I

    if-eqz p0, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method

.method public kw(I)V
    .locals 1

    iget v0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Pq:I

    div-int v0, p1, v0

    iput v0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Gd:I

    iget-object v0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Ucbh:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v0}, Landroidx/recyclerview/widget/qdMbNW;->ETF()I

    move-result v0

    invoke-static {p1, v0}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result p1

    iput p1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->KLMXS:I

    return-void
.end method

.method public lgHUyS(Ljava/lang/String;)V
    .locals 1

    iget-object v0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->xrEuO:Landroidx/recyclerview/widget/StaggeredGridLayoutManager$KLFTb;

    if-nez v0, :cond_0

    invoke-super {p0, p1}, Landroidx/recyclerview/widget/RecyclerView$qGY;->lgHUyS(Ljava/lang/String;)V

    :cond_0
    return-void
.end method

.method public mByQ()Landroidx/recyclerview/widget/RecyclerView$fehf;
    .locals 2

    iget p0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->huTpC:I

    const/4 v0, -0x1

    const/4 v1, -0x2

    if-nez p0, :cond_0

    new-instance p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$wA;

    invoke-direct {p0, v1, v0}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$wA;-><init>(II)V

    return-object p0

    :cond_0
    new-instance p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$wA;

    invoke-direct {p0, v0, v1}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$wA;-><init>(II)V

    return-object p0
.end method

.method public mPWV(Landroid/os/Parcelable;)V
    .locals 2

    instance-of v0, p1, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$KLFTb;

    if-eqz v0, :cond_1

    check-cast p1, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$KLFTb;

    iput-object p1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->xrEuO:Landroidx/recyclerview/widget/StaggeredGridLayoutManager$KLFTb;

    iget v0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->lB:I

    const/4 v1, -0x1

    if-eq v0, v1, :cond_0

    invoke-virtual {p1}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$KLFTb;->mjFkc()V

    iget-object p1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->xrEuO:Landroidx/recyclerview/widget/StaggeredGridLayoutManager$KLFTb;

    invoke-virtual {p1}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$KLFTb;->AZxh()V

    :cond_0
    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->mzUGzO()V

    :cond_1
    return-void
.end method

.method public np()Z
    .locals 6

    iget-object v0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->diqgf:[Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;

    const/4 v1, 0x0

    aget-object v0, v0, v1

    const/high16 v2, -0x80000000

    invoke-virtual {v0, v2}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;->VA(I)I

    move-result v0

    const/4 v3, 0x1

    move v4, v3

    :goto_0
    iget v5, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Pq:I

    if-ge v4, v5, :cond_1

    iget-object v5, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->diqgf:[Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;

    aget-object v5, v5, v4

    invoke-virtual {v5, v2}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;->VA(I)I

    move-result v5

    if-eq v5, v0, :cond_0

    return v1

    :cond_0
    add-int/lit8 v4, v4, 0x1

    goto :goto_0

    :cond_1
    return v3
.end method

.method public final oJ(Landroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;Z)V
    .locals 2

    const v0, 0x7fffffff

    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Sx(I)I

    move-result v1

    if-ne v1, v0, :cond_0

    return-void

    :cond_0
    iget-object v0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v0}, Landroidx/recyclerview/widget/qdMbNW;->MiMN()I

    move-result v0

    sub-int/2addr v1, v0

    if-lez v1, :cond_1

    invoke-virtual {p0, v1, p1, p2}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->LlB(ILandroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;)I

    move-result p1

    sub-int/2addr v1, p1

    if-eqz p3, :cond_1

    if-lez v1, :cond_1

    iget-object p0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    neg-int p1, v1

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/qdMbNW;->IEE(I)V

    :cond_1
    return-void
.end method

.method public final pJeaSR(Landroidx/recyclerview/widget/StaggeredGridLayoutManager$AZxh;)V
    .locals 4

    iget-object v0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->xrEuO:Landroidx/recyclerview/widget/StaggeredGridLayoutManager$KLFTb;

    iget v1, v0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$KLFTb;->wA:I

    if-lez v1, :cond_3

    iget v2, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Pq:I

    if-ne v1, v2, :cond_2

    const/4 v0, 0x0

    :goto_0
    iget v1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Pq:I

    if-ge v0, v1, :cond_3

    iget-object v1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->diqgf:[Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;

    aget-object v1, v1, v0

    invoke-virtual {v1}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;->KLFTb()V

    iget-object v1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->xrEuO:Landroidx/recyclerview/widget/StaggeredGridLayoutManager$KLFTb;

    iget-object v2, v1, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$KLFTb;->ZfxDd:[I

    aget v2, v2, v0

    const/high16 v3, -0x80000000

    if-eq v2, v3, :cond_1

    iget-boolean v1, v1, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$KLFTb;->qdMbNW:Z

    if-eqz v1, :cond_0

    iget-object v1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v1}, Landroidx/recyclerview/widget/qdMbNW;->qdMbNW()I

    move-result v1

    :goto_1
    add-int/2addr v2, v1

    goto :goto_2

    :cond_0
    iget-object v1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v1}, Landroidx/recyclerview/widget/qdMbNW;->MiMN()I

    move-result v1

    goto :goto_1

    :cond_1
    :goto_2
    iget-object v1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->diqgf:[Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;

    aget-object v1, v1, v0

    invoke-virtual {v1, v2}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;->Ucbh(I)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_2
    invoke-virtual {v0}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$KLFTb;->AZxh()V

    iget-object v0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->xrEuO:Landroidx/recyclerview/widget/StaggeredGridLayoutManager$KLFTb;

    iget v1, v0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$KLFTb;->AZxh:I

    iput v1, v0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$KLFTb;->mjFkc:I

    :cond_3
    iget-object v0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->xrEuO:Landroidx/recyclerview/widget/StaggeredGridLayoutManager$KLFTb;

    iget-boolean v1, v0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$KLFTb;->Dt:Z

    iput-boolean v1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->CqaNbM:Z

    iget-boolean v0, v0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$KLFTb;->lgHUyS:Z

    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->jpz(Z)V

    invoke-direct {p0}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->kOlLW()V

    iget-object v0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->xrEuO:Landroidx/recyclerview/widget/StaggeredGridLayoutManager$KLFTb;

    iget v1, v0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$KLFTb;->mjFkc:I

    const/4 v2, -0x1

    if-eq v1, v2, :cond_4

    iput v1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->lB:I

    iget-boolean v1, v0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$KLFTb;->qdMbNW:Z

    iput-boolean v1, p1, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$AZxh;->wA:Z

    goto :goto_3

    :cond_4
    iget-boolean v1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->VocHEe:Z

    iput-boolean v1, p1, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$AZxh;->wA:Z

    :goto_3
    iget p1, v0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$KLFTb;->KLFTb:I

    const/4 v1, 0x1

    if-le p1, v1, :cond_5

    iget-object p0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->mByQ:Landroidx/recyclerview/widget/StaggeredGridLayoutManager$ZfxDd;

    iget-object p1, v0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$KLFTb;->JHa:[I

    iput-object p1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$ZfxDd;->mjFkc:[I

    iget-object p1, v0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$KLFTb;->xJ:Ljava/util/List;

    iput-object p1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$ZfxDd;->AZxh:Ljava/util/List;

    :cond_5
    return-void
.end method

.method public final peCqC(Landroidx/recyclerview/widget/JHa;)Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;
    .locals 7

    iget v0, p1, Landroidx/recyclerview/widget/JHa;->KLFTb:I

    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->jTNPnW(I)Z

    move-result v0

    const/4 v1, 0x1

    if-eqz v0, :cond_0

    iget v0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Pq:I

    sub-int/2addr v0, v1

    const/4 v2, -0x1

    move v3, v2

    goto :goto_0

    :cond_0
    iget v2, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Pq:I

    const/4 v0, 0x0

    move v3, v1

    :goto_0
    iget p1, p1, Landroidx/recyclerview/widget/JHa;->KLFTb:I

    const/4 v4, 0x0

    if-ne p1, v1, :cond_3

    iget-object p1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {p1}, Landroidx/recyclerview/widget/qdMbNW;->MiMN()I

    move-result p1

    const v1, 0x7fffffff

    :goto_1
    if-eq v0, v2, :cond_2

    iget-object v5, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->diqgf:[Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;

    aget-object v5, v5, v0

    invoke-virtual {v5, p1}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;->VA(I)I

    move-result v6

    if-ge v6, v1, :cond_1

    move-object v4, v5

    move v1, v6

    :cond_1
    add-int/2addr v0, v3

    goto :goto_1

    :cond_2
    return-object v4

    :cond_3
    iget-object p1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {p1}, Landroidx/recyclerview/widget/qdMbNW;->qdMbNW()I

    move-result p1

    const/high16 v1, -0x80000000

    :goto_2
    if-eq v0, v2, :cond_5

    iget-object v5, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->diqgf:[Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;

    aget-object v5, v5, v0

    invoke-virtual {v5, p1}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;->qGY(I)I

    move-result v6

    if-le v6, v1, :cond_4

    move-object v4, v5

    move v1, v6

    :cond_4
    add-int/2addr v0, v3

    goto :goto_2

    :cond_5
    return-object v4
.end method

.method public qGY(IILandroidx/recyclerview/widget/RecyclerView$VocHEe;Landroidx/recyclerview/widget/RecyclerView$qGY$wA;)V
    .locals 4

    iget v0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->huTpC:I

    if-nez v0, :cond_0

    goto :goto_0

    :cond_0
    move p1, p2

    :goto_0
    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->zvd()I

    move-result p2

    if-eqz p2, :cond_7

    if-nez p1, :cond_1

    goto/16 :goto_5

    :cond_1
    invoke-virtual {p0, p1, p3}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->EeoThB(ILandroidx/recyclerview/widget/RecyclerView$VocHEe;)V

    iget-object p1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->NPj:[I

    if-eqz p1, :cond_2

    array-length p1, p1

    iget p2, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Pq:I

    if-ge p1, p2, :cond_3

    :cond_2
    iget p1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Pq:I

    new-array p1, p1, [I

    iput-object p1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->NPj:[I

    :cond_3
    const/4 p1, 0x0

    move p2, p1

    move v0, p2

    :goto_1
    iget v1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Pq:I

    if-ge p2, v1, :cond_6

    iget-object v1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->HGpJ:Landroidx/recyclerview/widget/JHa;

    iget v2, v1, Landroidx/recyclerview/widget/JHa;->ZfxDd:I

    const/4 v3, -0x1

    if-ne v2, v3, :cond_4

    iget v1, v1, Landroidx/recyclerview/widget/JHa;->JHa:I

    iget-object v2, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->diqgf:[Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;

    aget-object v2, v2, p2

    invoke-virtual {v2, v1}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;->qGY(I)I

    move-result v2

    :goto_2
    sub-int/2addr v1, v2

    goto :goto_3

    :cond_4
    iget-object v2, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->diqgf:[Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;

    aget-object v2, v2, p2

    iget v1, v1, Landroidx/recyclerview/widget/JHa;->xJ:I

    invoke-virtual {v2, v1}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;->VA(I)I

    move-result v1

    iget-object v2, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->HGpJ:Landroidx/recyclerview/widget/JHa;

    iget v2, v2, Landroidx/recyclerview/widget/JHa;->xJ:I

    goto :goto_2

    :goto_3
    if-ltz v1, :cond_5

    iget-object v2, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->NPj:[I

    aput v1, v2, v0

    add-int/lit8 v0, v0, 0x1

    :cond_5
    add-int/lit8 p2, p2, 0x1

    goto :goto_1

    :cond_6
    iget-object p2, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->NPj:[I

    invoke-static {p2, p1, v0}, Ljava/util/Arrays;->sort([III)V

    :goto_4
    if-ge p1, v0, :cond_7

    iget-object p2, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->HGpJ:Landroidx/recyclerview/widget/JHa;

    invoke-virtual {p2, p3}, Landroidx/recyclerview/widget/JHa;->mjFkc(Landroidx/recyclerview/widget/RecyclerView$VocHEe;)Z

    move-result p2

    if-eqz p2, :cond_7

    iget-object p2, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->HGpJ:Landroidx/recyclerview/widget/JHa;

    iget p2, p2, Landroidx/recyclerview/widget/JHa;->wA:I

    iget-object v1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->NPj:[I

    aget v1, v1, p1

    invoke-interface {p4, p2, v1}, Landroidx/recyclerview/widget/RecyclerView$qGY$wA;->mjFkc(II)V

    iget-object p2, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->HGpJ:Landroidx/recyclerview/widget/JHa;

    iget v1, p2, Landroidx/recyclerview/widget/JHa;->wA:I

    iget v2, p2, Landroidx/recyclerview/widget/JHa;->ZfxDd:I

    add-int/2addr v1, v2

    iput v1, p2, Landroidx/recyclerview/widget/JHa;->wA:I

    add-int/lit8 p1, p1, 0x1

    goto :goto_4

    :cond_7
    :goto_5
    return-void
.end method

.method public qGgY(Landroidx/recyclerview/widget/RecyclerView;Landroidx/recyclerview/widget/RecyclerView$VocHEe;I)V
    .locals 0

    new-instance p2, Landroidx/recyclerview/widget/xJ;

    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p1

    invoke-direct {p2, p1}, Landroidx/recyclerview/widget/xJ;-><init>(Landroid/content/Context;)V

    invoke-virtual {p2, p3}, Landroidx/recyclerview/widget/RecyclerView$vI;->qGY(I)V

    invoke-virtual {p0, p2}, Landroidx/recyclerview/widget/RecyclerView$qGY;->vUsV(Landroidx/recyclerview/widget/RecyclerView$vI;)V

    return-void
.end method

.method public final qrxT(Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;)Z
    .locals 2

    iget-boolean v0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->VocHEe:Z

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    invoke-virtual {p1}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;->ETF()I

    move-result v0

    iget-object p0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {p0}, Landroidx/recyclerview/widget/qdMbNW;->qdMbNW()I

    move-result p0

    if-ge v0, p0, :cond_1

    iget-object p0, p1, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;->mjFkc:Ljava/util/ArrayList;

    invoke-virtual {p0}, Ljava/util/ArrayList;->size()I

    move-result v0

    add-int/lit8 v0, v0, -0x1

    invoke-virtual {p0, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/view/View;

    invoke-virtual {p1, p0}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;->YoKzxo(Landroid/view/View;)Landroidx/recyclerview/widget/StaggeredGridLayoutManager$wA;

    move-result-object p0

    iget-boolean p0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$wA;->JHa:Z

    xor-int/lit8 p0, p0, 0x1

    return p0

    :cond_0
    invoke-virtual {p1}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;->rkYL()I

    move-result v0

    iget-object p0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {p0}, Landroidx/recyclerview/widget/qdMbNW;->MiMN()I

    move-result p0

    if-le v0, p0, :cond_1

    iget-object p0, p1, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;->mjFkc:Ljava/util/ArrayList;

    invoke-virtual {p0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/view/View;

    invoke-virtual {p1, p0}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;->YoKzxo(Landroid/view/View;)Landroidx/recyclerview/widget/StaggeredGridLayoutManager$wA;

    move-result-object p0

    iget-boolean p0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$wA;->JHa:Z

    xor-int/lit8 p0, p0, 0x1

    return p0

    :cond_1
    return v1
.end method

.method public qtZIjO(Landroidx/recyclerview/widget/RecyclerView$VocHEe;Landroidx/recyclerview/widget/StaggeredGridLayoutManager$AZxh;)Z
    .locals 5

    invoke-virtual {p1}, Landroidx/recyclerview/widget/RecyclerView$VocHEe;->KLFTb()Z

    move-result v0

    const/4 v1, 0x0

    if-nez v0, :cond_f

    iget v0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->lB:I

    const/4 v2, -0x1

    if-ne v0, v2, :cond_0

    goto/16 :goto_7

    :cond_0
    const/high16 v3, -0x80000000

    if-ltz v0, :cond_e

    invoke-virtual {p1}, Landroidx/recyclerview/widget/RecyclerView$VocHEe;->AZxh()I

    move-result p1

    if-lt v0, p1, :cond_1

    goto/16 :goto_6

    :cond_1
    iget-object p1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->xrEuO:Landroidx/recyclerview/widget/StaggeredGridLayoutManager$KLFTb;

    const/4 v0, 0x1

    if-eqz p1, :cond_3

    iget v4, p1, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$KLFTb;->mjFkc:I

    if-eq v4, v2, :cond_3

    iget p1, p1, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$KLFTb;->wA:I

    if-ge p1, v0, :cond_2

    goto :goto_0

    :cond_2
    iput v3, p2, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$AZxh;->AZxh:I

    iget p0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->lB:I

    iput p0, p2, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$AZxh;->mjFkc:I

    goto/16 :goto_5

    :cond_3
    :goto_0
    iget p1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->lB:I

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/RecyclerView$qGY;->wJVbdd(I)Landroid/view/View;

    move-result-object p1

    if-eqz p1, :cond_b

    iget-boolean v1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->VocHEe:Z

    if-eqz v1, :cond_4

    invoke-virtual {p0}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->XyP()I

    move-result v1

    goto :goto_1

    :cond_4
    invoke-virtual {p0}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->bWIyu()I

    move-result v1

    :goto_1
    iput v1, p2, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$AZxh;->mjFkc:I

    iget v1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->wJVbdd:I

    if-eq v1, v3, :cond_6

    iget-boolean v1, p2, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$AZxh;->wA:Z

    if-eqz v1, :cond_5

    iget-object v1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v1}, Landroidx/recyclerview/widget/qdMbNW;->qdMbNW()I

    move-result v1

    iget v2, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->wJVbdd:I

    sub-int/2addr v1, v2

    iget-object p0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/qdMbNW;->ZfxDd(Landroid/view/View;)I

    move-result p0

    sub-int/2addr v1, p0

    iput v1, p2, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$AZxh;->AZxh:I

    goto :goto_2

    :cond_5
    iget-object v1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v1}, Landroidx/recyclerview/widget/qdMbNW;->MiMN()I

    move-result v1

    iget v2, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->wJVbdd:I

    add-int/2addr v1, v2

    iget-object p0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/qdMbNW;->xJ(Landroid/view/View;)I

    move-result p0

    sub-int/2addr v1, p0

    iput v1, p2, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$AZxh;->AZxh:I

    :goto_2
    return v0

    :cond_6
    iget-object v1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v1, p1}, Landroidx/recyclerview/widget/qdMbNW;->KLFTb(Landroid/view/View;)I

    move-result v1

    iget-object v2, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v2}, Landroidx/recyclerview/widget/qdMbNW;->YoKzxo()I

    move-result v2

    if-le v1, v2, :cond_8

    iget-boolean p1, p2, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$AZxh;->wA:Z

    if-eqz p1, :cond_7

    iget-object p0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {p0}, Landroidx/recyclerview/widget/qdMbNW;->qdMbNW()I

    move-result p0

    goto :goto_3

    :cond_7
    iget-object p0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {p0}, Landroidx/recyclerview/widget/qdMbNW;->MiMN()I

    move-result p0

    :goto_3
    iput p0, p2, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$AZxh;->AZxh:I

    return v0

    :cond_8
    iget-object v1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v1, p1}, Landroidx/recyclerview/widget/qdMbNW;->xJ(Landroid/view/View;)I

    move-result v1

    iget-object v2, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v2}, Landroidx/recyclerview/widget/qdMbNW;->MiMN()I

    move-result v2

    sub-int/2addr v1, v2

    if-gez v1, :cond_9

    neg-int p0, v1

    iput p0, p2, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$AZxh;->AZxh:I

    return v0

    :cond_9
    iget-object v1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v1}, Landroidx/recyclerview/widget/qdMbNW;->qdMbNW()I

    move-result v1

    iget-object p0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/qdMbNW;->ZfxDd(Landroid/view/View;)I

    move-result p0

    sub-int/2addr v1, p0

    if-gez v1, :cond_a

    iput v1, p2, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$AZxh;->AZxh:I

    return v0

    :cond_a
    iput v3, p2, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$AZxh;->AZxh:I

    goto :goto_5

    :cond_b
    iget p1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->lB:I

    iput p1, p2, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$AZxh;->mjFkc:I

    iget v2, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->wJVbdd:I

    if-ne v2, v3, :cond_d

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->KSf(I)I

    move-result p0

    if-ne p0, v0, :cond_c

    move v1, v0

    :cond_c
    iput-boolean v1, p2, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$AZxh;->wA:Z

    invoke-virtual {p2}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$AZxh;->mjFkc()V

    goto :goto_4

    :cond_d
    invoke-virtual {p2, v2}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$AZxh;->AZxh(I)V

    :goto_4
    iput-boolean v0, p2, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$AZxh;->ZfxDd:Z

    :goto_5
    return v0

    :cond_e
    :goto_6
    iput v2, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->lB:I

    iput v3, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->wJVbdd:I

    :cond_f
    :goto_7
    return v1
.end method

.method public tAfC(Landroidx/recyclerview/widget/RecyclerView;IILjava/lang/Object;)V
    .locals 0

    const/4 p1, 0x4

    invoke-virtual {p0, p2, p3, p1}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->wGscSa(III)V

    return-void
.end method

.method public tISON(I)V
    .locals 2

    invoke-super {p0, p1}, Landroidx/recyclerview/widget/RecyclerView$qGY;->tISON(I)V

    const/4 v0, 0x0

    :goto_0
    iget v1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Pq:I

    if-ge v0, v1, :cond_0

    iget-object v1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->diqgf:[Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;

    aget-object v1, v1, v0

    invoke-virtual {v1, p1}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;->IEE(I)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_0
    return-void
.end method

.method public tPvjn()Landroid/view/View;
    .locals 12

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->zvd()I

    move-result v0

    add-int/lit8 v1, v0, -0x1

    new-instance v2, Ljava/util/BitSet;

    iget v3, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Pq:I

    invoke-direct {v2, v3}, Ljava/util/BitSet;-><init>(I)V

    iget v3, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Pq:I

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-virtual {v2, v4, v3, v5}, Ljava/util/BitSet;->set(IIZ)V

    iget v3, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->huTpC:I

    const/4 v6, -0x1

    if-ne v3, v5, :cond_0

    invoke-virtual {p0}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Otxclu()Z

    move-result v3

    if-eqz v3, :cond_0

    move v3, v5

    goto :goto_0

    :cond_0
    move v3, v6

    :goto_0
    iget-boolean v7, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->VocHEe:Z

    if-eqz v7, :cond_1

    move v0, v6

    goto :goto_1

    :cond_1
    move v1, v4

    :goto_1
    if-ge v1, v0, :cond_2

    move v6, v5

    :cond_2
    :goto_2
    if-eq v1, v0, :cond_c

    invoke-virtual {p0, v1}, Landroidx/recyclerview/widget/RecyclerView$qGY;->KLMXS(I)Landroid/view/View;

    move-result-object v7

    invoke-virtual {v7}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v8

    check-cast v8, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$wA;

    iget-object v9, v8, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$wA;->KLFTb:Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;

    iget v9, v9, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;->KLFTb:I

    invoke-virtual {v2, v9}, Ljava/util/BitSet;->get(I)Z

    move-result v9

    if-eqz v9, :cond_4

    iget-object v9, v8, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$wA;->KLFTb:Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;

    invoke-virtual {p0, v9}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->qrxT(Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;)Z

    move-result v9

    if-eqz v9, :cond_3

    return-object v7

    :cond_3
    iget-object v9, v8, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$wA;->KLFTb:Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;

    iget v9, v9, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;->KLFTb:I

    invoke-virtual {v2, v9}, Ljava/util/BitSet;->clear(I)V

    :cond_4
    iget-boolean v9, v8, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$wA;->JHa:Z

    if-eqz v9, :cond_5

    goto :goto_6

    :cond_5
    add-int v9, v1, v6

    if-eq v9, v0, :cond_b

    invoke-virtual {p0, v9}, Landroidx/recyclerview/widget/RecyclerView$qGY;->KLMXS(I)Landroid/view/View;

    move-result-object v9

    iget-boolean v10, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->VocHEe:Z

    if-eqz v10, :cond_7

    iget-object v10, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v10, v7}, Landroidx/recyclerview/widget/qdMbNW;->ZfxDd(Landroid/view/View;)I

    move-result v10

    iget-object v11, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v11, v9}, Landroidx/recyclerview/widget/qdMbNW;->ZfxDd(Landroid/view/View;)I

    move-result v11

    if-ge v10, v11, :cond_6

    return-object v7

    :cond_6
    if-ne v10, v11, :cond_b

    goto :goto_3

    :cond_7
    iget-object v10, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v10, v7}, Landroidx/recyclerview/widget/qdMbNW;->xJ(Landroid/view/View;)I

    move-result v10

    iget-object v11, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v11, v9}, Landroidx/recyclerview/widget/qdMbNW;->xJ(Landroid/view/View;)I

    move-result v11

    if-le v10, v11, :cond_8

    return-object v7

    :cond_8
    if-ne v10, v11, :cond_b

    :goto_3
    invoke-virtual {v9}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v9

    check-cast v9, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$wA;

    iget-object v8, v8, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$wA;->KLFTb:Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;

    iget v8, v8, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;->KLFTb:I

    iget-object v9, v9, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$wA;->KLFTb:Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;

    iget v9, v9, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;->KLFTb:I

    sub-int/2addr v8, v9

    if-gez v8, :cond_9

    move v8, v5

    goto :goto_4

    :cond_9
    move v8, v4

    :goto_4
    if-gez v3, :cond_a

    move v9, v5

    goto :goto_5

    :cond_a
    move v9, v4

    :goto_5
    if-eq v8, v9, :cond_b

    return-object v7

    :cond_b
    :goto_6
    add-int/2addr v1, v6

    goto :goto_2

    :cond_c
    const/4 p0, 0x0

    return-object p0
.end method

.method public uH(I)V
    .locals 2

    invoke-super {p0, p1}, Landroidx/recyclerview/widget/RecyclerView$qGY;->uH(I)V

    const/4 v0, 0x0

    :goto_0
    iget v1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Pq:I

    if-ge v0, v1, :cond_0

    iget-object v1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->diqgf:[Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;

    aget-object v1, v1, v0

    invoke-virtual {v1, p1}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;->IEE(I)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_0
    return-void
.end method

.method public final vZ(Landroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/JHa;Landroidx/recyclerview/widget/RecyclerView$VocHEe;)I
    .locals 16

    move-object/from16 v6, p0

    move-object/from16 v7, p1

    move-object/from16 v8, p2

    iget-object v0, v6, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->BAnRFn:Ljava/util/BitSet;

    iget v1, v6, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Pq:I

    const/4 v9, 0x0

    const/4 v10, 0x1

    invoke-virtual {v0, v9, v1, v10}, Ljava/util/BitSet;->set(IIZ)V

    iget-object v0, v6, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->HGpJ:Landroidx/recyclerview/widget/JHa;

    iget-boolean v0, v0, Landroidx/recyclerview/widget/JHa;->qdMbNW:Z

    if-eqz v0, :cond_1

    iget v0, v8, Landroidx/recyclerview/widget/JHa;->KLFTb:I

    if-ne v0, v10, :cond_0

    const v0, 0x7fffffff

    :goto_0
    move v11, v0

    goto :goto_1

    :cond_0
    const/high16 v0, -0x80000000

    goto :goto_0

    :cond_1
    iget v0, v8, Landroidx/recyclerview/widget/JHa;->KLFTb:I

    if-ne v0, v10, :cond_2

    iget v0, v8, Landroidx/recyclerview/widget/JHa;->xJ:I

    iget v1, v8, Landroidx/recyclerview/widget/JHa;->AZxh:I

    add-int/2addr v0, v1

    goto :goto_0

    :cond_2
    iget v0, v8, Landroidx/recyclerview/widget/JHa;->JHa:I

    iget v1, v8, Landroidx/recyclerview/widget/JHa;->AZxh:I

    sub-int/2addr v0, v1

    goto :goto_0

    :goto_1
    iget v0, v8, Landroidx/recyclerview/widget/JHa;->KLFTb:I

    invoke-virtual {v6, v0, v11}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->BABY(II)V

    iget-boolean v0, v6, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->VocHEe:Z

    if-eqz v0, :cond_3

    iget-object v0, v6, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v0}, Landroidx/recyclerview/widget/qdMbNW;->qdMbNW()I

    move-result v0

    :goto_2
    move v12, v0

    goto :goto_3

    :cond_3
    iget-object v0, v6, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v0}, Landroidx/recyclerview/widget/qdMbNW;->MiMN()I

    move-result v0

    goto :goto_2

    :goto_3
    move v0, v9

    :goto_4
    invoke-virtual/range {p2 .. p3}, Landroidx/recyclerview/widget/JHa;->mjFkc(Landroidx/recyclerview/widget/RecyclerView$VocHEe;)Z

    move-result v1

    const/4 v2, -0x1

    if-eqz v1, :cond_4

    iget-object v1, v6, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->HGpJ:Landroidx/recyclerview/widget/JHa;

    iget-boolean v1, v1, Landroidx/recyclerview/widget/JHa;->qdMbNW:Z

    if-nez v1, :cond_5

    iget-object v1, v6, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->BAnRFn:Ljava/util/BitSet;

    invoke-virtual {v1}, Ljava/util/BitSet;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_4

    goto :goto_5

    :cond_4
    move v3, v9

    goto/16 :goto_17

    :cond_5
    :goto_5
    invoke-virtual {v8, v7}, Landroidx/recyclerview/widget/JHa;->AZxh(Landroidx/recyclerview/widget/RecyclerView$Ucbh;)Landroid/view/View;

    move-result-object v13

    invoke-virtual {v13}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    move-object v14, v0

    check-cast v14, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$wA;

    invoke-virtual {v14}, Landroidx/recyclerview/widget/RecyclerView$fehf;->mjFkc()I

    move-result v0

    iget-object v1, v6, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->mByQ:Landroidx/recyclerview/widget/StaggeredGridLayoutManager$ZfxDd;

    invoke-virtual {v1, v0}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$ZfxDd;->xJ(I)I

    move-result v1

    if-ne v1, v2, :cond_6

    move v3, v10

    goto :goto_6

    :cond_6
    move v3, v9

    :goto_6
    if-eqz v3, :cond_8

    iget-boolean v1, v14, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$wA;->JHa:Z

    if-eqz v1, :cond_7

    iget-object v1, v6, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->diqgf:[Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;

    aget-object v1, v1, v9

    goto :goto_7

    :cond_7
    invoke-virtual {v6, v8}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->peCqC(Landroidx/recyclerview/widget/JHa;)Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;

    move-result-object v1

    :goto_7
    iget-object v4, v6, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->mByQ:Landroidx/recyclerview/widget/StaggeredGridLayoutManager$ZfxDd;

    invoke-virtual {v4, v0, v1}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$ZfxDd;->YoKzxo(ILandroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;)V

    :goto_8
    move-object v15, v1

    goto :goto_9

    :cond_8
    iget-object v4, v6, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->diqgf:[Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;

    aget-object v1, v4, v1

    goto :goto_8

    :goto_9
    iput-object v15, v14, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$wA;->KLFTb:Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;

    iget v1, v8, Landroidx/recyclerview/widget/JHa;->KLFTb:I

    if-ne v1, v10, :cond_9

    invoke-virtual {v6, v13}, Landroidx/recyclerview/widget/RecyclerView$qGY;->KLFTb(Landroid/view/View;)V

    goto :goto_a

    :cond_9
    invoke-virtual {v6, v13, v9}, Landroidx/recyclerview/widget/RecyclerView$qGY;->JHa(Landroid/view/View;I)V

    :goto_a
    invoke-virtual {v6, v13, v14, v9}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->ArO(Landroid/view/View;Landroidx/recyclerview/widget/StaggeredGridLayoutManager$wA;Z)V

    iget v1, v8, Landroidx/recyclerview/widget/JHa;->KLFTb:I

    if-ne v1, v10, :cond_c

    iget-boolean v1, v14, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$wA;->JHa:Z

    if-eqz v1, :cond_a

    invoke-virtual {v6, v12}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->UDcil(I)I

    move-result v1

    goto :goto_b

    :cond_a
    invoke-virtual {v15, v12}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;->VA(I)I

    move-result v1

    :goto_b
    iget-object v4, v6, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v4, v13}, Landroidx/recyclerview/widget/qdMbNW;->KLFTb(Landroid/view/View;)I

    move-result v4

    add-int/2addr v4, v1

    if-eqz v3, :cond_b

    iget-boolean v5, v14, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$wA;->JHa:Z

    if-eqz v5, :cond_b

    invoke-virtual {v6, v1}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->zPp(I)Landroidx/recyclerview/widget/StaggeredGridLayoutManager$ZfxDd$mjFkc;

    move-result-object v5

    iput v2, v5, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$ZfxDd$mjFkc;->AZxh:I

    iput v0, v5, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$ZfxDd$mjFkc;->mjFkc:I

    iget-object v9, v6, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->mByQ:Landroidx/recyclerview/widget/StaggeredGridLayoutManager$ZfxDd;

    invoke-virtual {v9, v5}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$ZfxDd;->mjFkc(Landroidx/recyclerview/widget/StaggeredGridLayoutManager$ZfxDd$mjFkc;)V

    :cond_b
    move v5, v4

    move v4, v1

    goto :goto_d

    :cond_c
    iget-boolean v1, v14, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$wA;->JHa:Z

    if-eqz v1, :cond_d

    invoke-virtual {v6, v12}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Sx(I)I

    move-result v1

    goto :goto_c

    :cond_d
    invoke-virtual {v15, v12}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;->qGY(I)I

    move-result v1

    :goto_c
    iget-object v4, v6, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v4, v13}, Landroidx/recyclerview/widget/qdMbNW;->KLFTb(Landroid/view/View;)I

    move-result v4

    sub-int v4, v1, v4

    if-eqz v3, :cond_e

    iget-boolean v5, v14, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$wA;->JHa:Z

    if-eqz v5, :cond_e

    invoke-virtual {v6, v1}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->MC(I)Landroidx/recyclerview/widget/StaggeredGridLayoutManager$ZfxDd$mjFkc;

    move-result-object v5

    iput v10, v5, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$ZfxDd$mjFkc;->AZxh:I

    iput v0, v5, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$ZfxDd$mjFkc;->mjFkc:I

    iget-object v9, v6, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->mByQ:Landroidx/recyclerview/widget/StaggeredGridLayoutManager$ZfxDd;

    invoke-virtual {v9, v5}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$ZfxDd;->mjFkc(Landroidx/recyclerview/widget/StaggeredGridLayoutManager$ZfxDd$mjFkc;)V

    :cond_e
    move v5, v1

    :goto_d
    iget-boolean v1, v14, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$wA;->JHa:Z

    if-eqz v1, :cond_12

    iget v1, v8, Landroidx/recyclerview/widget/JHa;->ZfxDd:I

    if-ne v1, v2, :cond_12

    if-eqz v3, :cond_f

    iput-boolean v10, v6, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->rWxwaT:Z

    goto :goto_10

    :cond_f
    iget v1, v8, Landroidx/recyclerview/widget/JHa;->KLFTb:I

    if-ne v1, v10, :cond_10

    invoke-virtual/range {p0 .. p0}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->np()Z

    move-result v1

    :goto_e
    xor-int/2addr v1, v10

    goto :goto_f

    :cond_10
    invoke-virtual/range {p0 .. p0}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->QyMqpM()Z

    move-result v1

    goto :goto_e

    :goto_f
    if-eqz v1, :cond_12

    iget-object v1, v6, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->mByQ:Landroidx/recyclerview/widget/StaggeredGridLayoutManager$ZfxDd;

    invoke-virtual {v1, v0}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$ZfxDd;->JHa(I)Landroidx/recyclerview/widget/StaggeredGridLayoutManager$ZfxDd$mjFkc;

    move-result-object v0

    if-eqz v0, :cond_11

    iput-boolean v10, v0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$ZfxDd$mjFkc;->ZfxDd:Z

    :cond_11
    iput-boolean v10, v6, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->rWxwaT:Z

    :cond_12
    :goto_10
    invoke-virtual {v6, v13, v14, v8}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->HExgdj(Landroid/view/View;Landroidx/recyclerview/widget/StaggeredGridLayoutManager$wA;Landroidx/recyclerview/widget/JHa;)V

    invoke-virtual/range {p0 .. p0}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Otxclu()Z

    move-result v0

    if-eqz v0, :cond_14

    iget v0, v6, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->huTpC:I

    if-ne v0, v10, :cond_14

    iget-boolean v0, v14, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$wA;->JHa:Z

    if-eqz v0, :cond_13

    iget-object v0, v6, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Ucbh:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v0}, Landroidx/recyclerview/widget/qdMbNW;->qdMbNW()I

    move-result v0

    goto :goto_11

    :cond_13
    iget-object v0, v6, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Ucbh:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v0}, Landroidx/recyclerview/widget/qdMbNW;->qdMbNW()I

    move-result v0

    iget v1, v6, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Pq:I

    sub-int/2addr v1, v10

    iget v2, v15, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;->KLFTb:I

    sub-int/2addr v1, v2

    iget v2, v6, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Gd:I

    mul-int/2addr v1, v2

    sub-int/2addr v0, v1

    :goto_11
    iget-object v1, v6, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Ucbh:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v1, v13}, Landroidx/recyclerview/widget/qdMbNW;->KLFTb(Landroid/view/View;)I

    move-result v1

    sub-int v1, v0, v1

    move v9, v0

    move v3, v1

    goto :goto_13

    :cond_14
    iget-boolean v0, v14, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$wA;->JHa:Z

    if-eqz v0, :cond_15

    iget-object v0, v6, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Ucbh:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v0}, Landroidx/recyclerview/widget/qdMbNW;->MiMN()I

    move-result v0

    goto :goto_12

    :cond_15
    iget v0, v15, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;->KLFTb:I

    iget v1, v6, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Gd:I

    mul-int/2addr v0, v1

    iget-object v1, v6, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Ucbh:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v1}, Landroidx/recyclerview/widget/qdMbNW;->MiMN()I

    move-result v1

    add-int/2addr v0, v1

    :goto_12
    iget-object v1, v6, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Ucbh:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v1, v13}, Landroidx/recyclerview/widget/qdMbNW;->KLFTb(Landroid/view/View;)I

    move-result v1

    add-int/2addr v1, v0

    move v3, v0

    move v9, v1

    :goto_13
    iget v0, v6, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->huTpC:I

    if-ne v0, v10, :cond_16

    move-object/from16 v0, p0

    move-object v1, v13

    move v2, v3

    move v3, v4

    move v4, v9

    invoke-virtual/range {v0 .. v5}, Landroidx/recyclerview/widget/RecyclerView$qGY;->XFUzSY(Landroid/view/View;IIII)V

    goto :goto_14

    :cond_16
    move-object/from16 v0, p0

    move-object v1, v13

    move v2, v4

    move v4, v5

    move v5, v9

    invoke-virtual/range {v0 .. v5}, Landroidx/recyclerview/widget/RecyclerView$qGY;->XFUzSY(Landroid/view/View;IIII)V

    :goto_14
    iget-boolean v0, v14, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$wA;->JHa:Z

    if-eqz v0, :cond_17

    iget-object v0, v6, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->HGpJ:Landroidx/recyclerview/widget/JHa;

    iget v0, v0, Landroidx/recyclerview/widget/JHa;->KLFTb:I

    invoke-virtual {v6, v0, v11}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->BABY(II)V

    goto :goto_15

    :cond_17
    iget-object v0, v6, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->HGpJ:Landroidx/recyclerview/widget/JHa;

    iget v0, v0, Landroidx/recyclerview/widget/JHa;->KLFTb:I

    invoke-virtual {v6, v15, v0, v11}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->ih(Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;II)V

    :goto_15
    iget-object v0, v6, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->HGpJ:Landroidx/recyclerview/widget/JHa;

    invoke-virtual {v6, v7, v0}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->xBQUgd(Landroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/JHa;)V

    iget-object v0, v6, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->HGpJ:Landroidx/recyclerview/widget/JHa;

    iget-boolean v0, v0, Landroidx/recyclerview/widget/JHa;->lgHUyS:Z

    if-eqz v0, :cond_18

    invoke-virtual {v13}, Landroid/view/View;->hasFocusable()Z

    move-result v0

    if-eqz v0, :cond_18

    iget-boolean v0, v14, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$wA;->JHa:Z

    if-eqz v0, :cond_19

    iget-object v0, v6, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->BAnRFn:Ljava/util/BitSet;

    invoke-virtual {v0}, Ljava/util/BitSet;->clear()V

    :cond_18
    const/4 v3, 0x0

    goto :goto_16

    :cond_19
    iget-object v0, v6, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->BAnRFn:Ljava/util/BitSet;

    iget v1, v15, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;->KLFTb:I

    const/4 v3, 0x0

    invoke-virtual {v0, v1, v3}, Ljava/util/BitSet;->set(IZ)V

    :goto_16
    move v9, v3

    move v0, v10

    goto/16 :goto_4

    :goto_17
    if-nez v0, :cond_1a

    iget-object v0, v6, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->HGpJ:Landroidx/recyclerview/widget/JHa;

    invoke-virtual {v6, v7, v0}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->xBQUgd(Landroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/JHa;)V

    :cond_1a
    iget-object v0, v6, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->HGpJ:Landroidx/recyclerview/widget/JHa;

    iget v0, v0, Landroidx/recyclerview/widget/JHa;->KLFTb:I

    if-ne v0, v2, :cond_1b

    iget-object v0, v6, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v0}, Landroidx/recyclerview/widget/qdMbNW;->MiMN()I

    move-result v0

    invoke-virtual {v6, v0}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Sx(I)I

    move-result v0

    iget-object v1, v6, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v1}, Landroidx/recyclerview/widget/qdMbNW;->MiMN()I

    move-result v1

    sub-int/2addr v1, v0

    goto :goto_18

    :cond_1b
    iget-object v0, v6, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v0}, Landroidx/recyclerview/widget/qdMbNW;->qdMbNW()I

    move-result v0

    invoke-virtual {v6, v0}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->UDcil(I)I

    move-result v0

    iget-object v1, v6, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v1}, Landroidx/recyclerview/widget/qdMbNW;->qdMbNW()I

    move-result v1

    sub-int v1, v0, v1

    :goto_18
    if-lez v1, :cond_1c

    iget v0, v8, Landroidx/recyclerview/widget/JHa;->AZxh:I

    invoke-static {v0, v1}, Ljava/lang/Math;->min(II)I

    move-result v9

    goto :goto_19

    :cond_1c
    move v9, v3

    :goto_19
    return v9
.end method

.method public final wGscSa(III)V
    .locals 6

    iget-boolean v0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->VocHEe:Z

    if-eqz v0, :cond_0

    invoke-virtual {p0}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->XyP()I

    move-result v0

    goto :goto_0

    :cond_0
    invoke-virtual {p0}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->bWIyu()I

    move-result v0

    :goto_0
    const/16 v1, 0x8

    if-ne p3, v1, :cond_2

    if-ge p1, p2, :cond_1

    add-int/lit8 v2, p2, 0x1

    :goto_1
    move v3, p1

    goto :goto_2

    :cond_1
    add-int/lit8 v2, p1, 0x1

    move v3, p2

    goto :goto_2

    :cond_2
    add-int v2, p1, p2

    goto :goto_1

    :goto_2
    iget-object v4, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->mByQ:Landroidx/recyclerview/widget/StaggeredGridLayoutManager$ZfxDd;

    invoke-virtual {v4, v3}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$ZfxDd;->lgHUyS(I)I

    const/4 v4, 0x1

    if-eq p3, v4, :cond_5

    const/4 v5, 0x2

    if-eq p3, v5, :cond_4

    if-eq p3, v1, :cond_3

    goto :goto_3

    :cond_3
    iget-object p3, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->mByQ:Landroidx/recyclerview/widget/StaggeredGridLayoutManager$ZfxDd;

    invoke-virtual {p3, p1, v4}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$ZfxDd;->ETF(II)V

    iget-object p1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->mByQ:Landroidx/recyclerview/widget/StaggeredGridLayoutManager$ZfxDd;

    invoke-virtual {p1, p2, v4}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$ZfxDd;->Dt(II)V

    goto :goto_3

    :cond_4
    iget-object p3, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->mByQ:Landroidx/recyclerview/widget/StaggeredGridLayoutManager$ZfxDd;

    invoke-virtual {p3, p1, p2}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$ZfxDd;->ETF(II)V

    goto :goto_3

    :cond_5
    iget-object p3, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->mByQ:Landroidx/recyclerview/widget/StaggeredGridLayoutManager$ZfxDd;

    invoke-virtual {p3, p1, p2}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$ZfxDd;->Dt(II)V

    :goto_3
    if-gt v2, v0, :cond_6

    return-void

    :cond_6
    iget-boolean p1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->VocHEe:Z

    if-eqz p1, :cond_7

    invoke-virtual {p0}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->bWIyu()I

    move-result p1

    goto :goto_4

    :cond_7
    invoke-virtual {p0}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->XyP()I

    move-result p1

    :goto_4
    if-gt v3, p1, :cond_8

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->mzUGzO()V

    :cond_8
    return-void
.end method

.method public final xBQUgd(Landroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/JHa;)V
    .locals 2

    iget-boolean v0, p2, Landroidx/recyclerview/widget/JHa;->mjFkc:Z

    if-eqz v0, :cond_6

    iget-boolean v0, p2, Landroidx/recyclerview/widget/JHa;->qdMbNW:Z

    if-eqz v0, :cond_0

    goto :goto_2

    :cond_0
    iget v0, p2, Landroidx/recyclerview/widget/JHa;->AZxh:I

    const/4 v1, -0x1

    if-nez v0, :cond_2

    iget v0, p2, Landroidx/recyclerview/widget/JHa;->KLFTb:I

    if-ne v0, v1, :cond_1

    iget p2, p2, Landroidx/recyclerview/widget/JHa;->xJ:I

    invoke-virtual {p0, p1, p2}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->MFekjo(Landroidx/recyclerview/widget/RecyclerView$Ucbh;I)V

    goto :goto_2

    :cond_1
    iget p2, p2, Landroidx/recyclerview/widget/JHa;->JHa:I

    invoke-virtual {p0, p1, p2}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->UPU(Landroidx/recyclerview/widget/RecyclerView$Ucbh;I)V

    goto :goto_2

    :cond_2
    iget v0, p2, Landroidx/recyclerview/widget/JHa;->KLFTb:I

    if-ne v0, v1, :cond_4

    iget v0, p2, Landroidx/recyclerview/widget/JHa;->JHa:I

    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->jY(I)I

    move-result v1

    sub-int/2addr v0, v1

    if-gez v0, :cond_3

    iget p2, p2, Landroidx/recyclerview/widget/JHa;->xJ:I

    goto :goto_0

    :cond_3
    iget v1, p2, Landroidx/recyclerview/widget/JHa;->xJ:I

    iget p2, p2, Landroidx/recyclerview/widget/JHa;->AZxh:I

    invoke-static {v0, p2}, Ljava/lang/Math;->min(II)I

    move-result p2

    sub-int p2, v1, p2

    :goto_0
    invoke-virtual {p0, p1, p2}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->MFekjo(Landroidx/recyclerview/widget/RecyclerView$Ucbh;I)V

    goto :goto_2

    :cond_4
    iget v0, p2, Landroidx/recyclerview/widget/JHa;->xJ:I

    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->UOnCkw(I)I

    move-result v0

    iget v1, p2, Landroidx/recyclerview/widget/JHa;->xJ:I

    sub-int/2addr v0, v1

    if-gez v0, :cond_5

    iget p2, p2, Landroidx/recyclerview/widget/JHa;->JHa:I

    goto :goto_1

    :cond_5
    iget v1, p2, Landroidx/recyclerview/widget/JHa;->JHa:I

    iget p2, p2, Landroidx/recyclerview/widget/JHa;->AZxh:I

    invoke-static {v0, p2}, Ljava/lang/Math;->min(II)I

    move-result p2

    add-int/2addr p2, v1

    :goto_1
    invoke-virtual {p0, p1, p2}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->UPU(Landroidx/recyclerview/widget/RecyclerView$Ucbh;I)V

    :cond_6
    :goto_2
    return-void
.end method

.method public xCVa(Landroid/graphics/Rect;II)V
    .locals 4

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->jm()I

    move-result v0

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->ANMGZc()I

    move-result v1

    add-int/2addr v0, v1

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->dm()I

    move-result v1

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->JBhc()I

    move-result v2

    add-int/2addr v1, v2

    iget v2, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->huTpC:I

    const/4 v3, 0x1

    if-ne v2, v3, :cond_0

    invoke-virtual {p1}, Landroid/graphics/Rect;->height()I

    move-result p1

    add-int/2addr p1, v1

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->bbzow()I

    move-result v1

    invoke-static {p3, p1, v1}, Landroidx/recyclerview/widget/RecyclerView$qGY;->rkYL(III)I

    move-result p1

    iget p3, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Gd:I

    iget v1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Pq:I

    mul-int/2addr p3, v1

    add-int/2addr p3, v0

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->SwgkN()I

    move-result v0

    invoke-static {p2, p3, v0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->rkYL(III)I

    move-result p2

    goto :goto_0

    :cond_0
    invoke-virtual {p1}, Landroid/graphics/Rect;->width()I

    move-result p1

    add-int/2addr p1, v0

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->SwgkN()I

    move-result v0

    invoke-static {p2, p1, v0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->rkYL(III)I

    move-result p2

    iget p1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Gd:I

    iget v0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Pq:I

    mul-int/2addr p1, v0

    add-int/2addr p1, v1

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->bbzow()I

    move-result v0

    invoke-static {p3, p1, v0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->rkYL(III)I

    move-result p1

    :goto_0
    invoke-virtual {p0, p2, p1}, Landroidx/recyclerview/widget/RecyclerView$qGY;->ub(II)V

    return-void
.end method

.method public xVYW(Landroidx/recyclerview/widget/RecyclerView$VocHEe;Landroidx/recyclerview/widget/StaggeredGridLayoutManager$AZxh;)V
    .locals 1

    invoke-virtual {p0, p1, p2}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->qtZIjO(Landroidx/recyclerview/widget/RecyclerView$VocHEe;Landroidx/recyclerview/widget/StaggeredGridLayoutManager$AZxh;)Z

    move-result v0

    if-eqz v0, :cond_0

    return-void

    :cond_0
    invoke-virtual {p0, p1, p2}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->gJsSk(Landroidx/recyclerview/widget/RecyclerView$VocHEe;Landroidx/recyclerview/widget/StaggeredGridLayoutManager$AZxh;)Z

    move-result p0

    if-eqz p0, :cond_1

    return-void

    :cond_1
    invoke-virtual {p2}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$AZxh;->mjFkc()V

    const/4 p0, 0x0

    iput p0, p2, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$AZxh;->mjFkc:I

    return-void
.end method

.method public xfXeiC()I
    .locals 2

    iget-boolean v0, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->VocHEe:Z

    const/4 v1, 0x1

    if-eqz v0, :cond_0

    invoke-virtual {p0, v1}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->CqAnRZ(Z)Landroid/view/View;

    move-result-object v0

    goto :goto_0

    :cond_0
    invoke-virtual {p0, v1}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Rsp(Z)Landroid/view/View;

    move-result-object v0

    :goto_0
    if-nez v0, :cond_1

    const/4 p0, -0x1

    goto :goto_1

    :cond_1
    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->tQ(Landroid/view/View;)I

    move-result p0

    :goto_1
    return p0
.end method

.method public final zPp(I)Landroidx/recyclerview/widget/StaggeredGridLayoutManager$ZfxDd$mjFkc;
    .locals 4

    new-instance v0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$ZfxDd$mjFkc;

    invoke-direct {v0}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$ZfxDd$mjFkc;-><init>()V

    iget v1, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Pq:I

    new-array v1, v1, [I

    iput-object v1, v0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$ZfxDd$mjFkc;->wA:[I

    const/4 v1, 0x0

    :goto_0
    iget v2, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->Pq:I

    if-ge v1, v2, :cond_0

    iget-object v2, v0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$ZfxDd$mjFkc;->wA:[I

    iget-object v3, p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->diqgf:[Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;

    aget-object v3, v3, v1

    invoke-virtual {v3, p1}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$JHa;->VA(I)I

    move-result v3

    sub-int v3, p1, v3

    aput v3, v2, v1

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_0
    return-object v0
.end method
