.class public Landroidx/recyclerview/widget/ZfxDd;
.super Landroidx/recyclerview/widget/RecyclerView$rkYL;
.source "SourceFile"

# interfaces
.implements Landroidx/recyclerview/widget/RecyclerView$Pq;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/recyclerview/widget/ZfxDd$ZfxDd;,
        Landroidx/recyclerview/widget/ZfxDd$wA;
    }
.end annotation


# static fields
.field public static final mByQ:[I

.field public static final wJVbdd:[I


# instance fields
.field public final AZxh:I

.field public final BAnRFn:Ljava/lang/Runnable;

.field public final Dt:I

.field public ETF:I

.field public final Gd:[I

.field public final HGpJ:[I

.field public IEE:I

.field public final JHa:I

.field public final KLFTb:I

.field public MiMN:F

.field public Pq:Landroidx/recyclerview/widget/RecyclerView;

.field public Ucbh:I

.field public VA:I

.field public VocHEe:I

.field public YoKzxo:I

.field public final ZfxDd:Landroid/graphics/drawable/Drawable;

.field public diqgf:Z

.field public eyqo:Z

.field public fehf:I

.field public huTpC:I

.field public final lB:Landroidx/recyclerview/widget/RecyclerView$diqgf;

.field public final lgHUyS:Landroid/graphics/drawable/Drawable;

.field public final mjFkc:I

.field public qGY:F

.field public final qdMbNW:I

.field public rkYL:I

.field public final vI:Landroid/animation/ValueAnimator;

.field public final wA:Landroid/graphics/drawable/StateListDrawable;

.field public final xJ:Landroid/graphics/drawable/StateListDrawable;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    const v0, 0x10100a7

    filled-new-array {v0}, [I

    move-result-object v0

    sput-object v0, Landroidx/recyclerview/widget/ZfxDd;->wJVbdd:[I

    const/4 v0, 0x0

    new-array v0, v0, [I

    sput-object v0, Landroidx/recyclerview/widget/ZfxDd;->mByQ:[I

    return-void
.end method

.method public constructor <init>(Landroidx/recyclerview/widget/RecyclerView;Landroid/graphics/drawable/StateListDrawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/StateListDrawable;Landroid/graphics/drawable/Drawable;III)V
    .locals 3

    invoke-direct {p0}, Landroidx/recyclerview/widget/RecyclerView$rkYL;-><init>()V

    const/4 v0, 0x0

    iput v0, p0, Landroidx/recyclerview/widget/ZfxDd;->fehf:I

    iput v0, p0, Landroidx/recyclerview/widget/ZfxDd;->IEE:I

    iput-boolean v0, p0, Landroidx/recyclerview/widget/ZfxDd;->diqgf:Z

    iput-boolean v0, p0, Landroidx/recyclerview/widget/ZfxDd;->eyqo:Z

    iput v0, p0, Landroidx/recyclerview/widget/ZfxDd;->Ucbh:I

    iput v0, p0, Landroidx/recyclerview/widget/ZfxDd;->huTpC:I

    const/4 v1, 0x2

    new-array v2, v1, [I

    iput-object v2, p0, Landroidx/recyclerview/widget/ZfxDd;->Gd:[I

    new-array v2, v1, [I

    iput-object v2, p0, Landroidx/recyclerview/widget/ZfxDd;->HGpJ:[I

    new-array v1, v1, [F

    fill-array-data v1, :array_0

    invoke-static {v1}, Landroid/animation/ValueAnimator;->ofFloat([F)Landroid/animation/ValueAnimator;

    move-result-object v1

    iput-object v1, p0, Landroidx/recyclerview/widget/ZfxDd;->vI:Landroid/animation/ValueAnimator;

    iput v0, p0, Landroidx/recyclerview/widget/ZfxDd;->VocHEe:I

    new-instance v0, Landroidx/recyclerview/widget/ZfxDd$mjFkc;

    invoke-direct {v0, p0}, Landroidx/recyclerview/widget/ZfxDd$mjFkc;-><init>(Landroidx/recyclerview/widget/ZfxDd;)V

    iput-object v0, p0, Landroidx/recyclerview/widget/ZfxDd;->BAnRFn:Ljava/lang/Runnable;

    new-instance v0, Landroidx/recyclerview/widget/ZfxDd$AZxh;

    invoke-direct {v0, p0}, Landroidx/recyclerview/widget/ZfxDd$AZxh;-><init>(Landroidx/recyclerview/widget/ZfxDd;)V

    iput-object v0, p0, Landroidx/recyclerview/widget/ZfxDd;->lB:Landroidx/recyclerview/widget/RecyclerView$diqgf;

    iput-object p2, p0, Landroidx/recyclerview/widget/ZfxDd;->wA:Landroid/graphics/drawable/StateListDrawable;

    iput-object p3, p0, Landroidx/recyclerview/widget/ZfxDd;->ZfxDd:Landroid/graphics/drawable/Drawable;

    iput-object p4, p0, Landroidx/recyclerview/widget/ZfxDd;->xJ:Landroid/graphics/drawable/StateListDrawable;

    iput-object p5, p0, Landroidx/recyclerview/widget/ZfxDd;->lgHUyS:Landroid/graphics/drawable/Drawable;

    invoke-virtual {p2}, Landroid/graphics/drawable/Drawable;->getIntrinsicWidth()I

    move-result v0

    invoke-static {p6, v0}, Ljava/lang/Math;->max(II)I

    move-result v0

    iput v0, p0, Landroidx/recyclerview/widget/ZfxDd;->KLFTb:I

    invoke-virtual {p3}, Landroid/graphics/drawable/Drawable;->getIntrinsicWidth()I

    move-result v0

    invoke-static {p6, v0}, Ljava/lang/Math;->max(II)I

    move-result v0

    iput v0, p0, Landroidx/recyclerview/widget/ZfxDd;->JHa:I

    invoke-virtual {p4}, Landroid/graphics/drawable/Drawable;->getIntrinsicWidth()I

    move-result p4

    invoke-static {p6, p4}, Ljava/lang/Math;->max(II)I

    move-result p4

    iput p4, p0, Landroidx/recyclerview/widget/ZfxDd;->qdMbNW:I

    invoke-virtual {p5}, Landroid/graphics/drawable/Drawable;->getIntrinsicWidth()I

    move-result p4

    invoke-static {p6, p4}, Ljava/lang/Math;->max(II)I

    move-result p4

    iput p4, p0, Landroidx/recyclerview/widget/ZfxDd;->Dt:I

    iput p7, p0, Landroidx/recyclerview/widget/ZfxDd;->mjFkc:I

    iput p8, p0, Landroidx/recyclerview/widget/ZfxDd;->AZxh:I

    const/16 p4, 0xff

    invoke-virtual {p2, p4}, Landroid/graphics/drawable/Drawable;->setAlpha(I)V

    invoke-virtual {p3, p4}, Landroid/graphics/drawable/Drawable;->setAlpha(I)V

    new-instance p2, Landroidx/recyclerview/widget/ZfxDd$wA;

    invoke-direct {p2, p0}, Landroidx/recyclerview/widget/ZfxDd$wA;-><init>(Landroidx/recyclerview/widget/ZfxDd;)V

    invoke-virtual {v1, p2}, Landroid/animation/Animator;->addListener(Landroid/animation/Animator$AnimatorListener;)V

    new-instance p2, Landroidx/recyclerview/widget/ZfxDd$ZfxDd;

    invoke-direct {p2, p0}, Landroidx/recyclerview/widget/ZfxDd$ZfxDd;-><init>(Landroidx/recyclerview/widget/ZfxDd;)V

    invoke-virtual {v1, p2}, Landroid/animation/ValueAnimator;->addUpdateListener(Landroid/animation/ValueAnimator$AnimatorUpdateListener;)V

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/ZfxDd;->Dt(Landroidx/recyclerview/widget/RecyclerView;)V

    return-void

    :array_0
    .array-data 4
        0x0
        0x3f800000    # 1.0f
    .end array-data
.end method


# virtual methods
.method public AZxh(Landroidx/recyclerview/widget/RecyclerView;Landroid/view/MotionEvent;)V
    .locals 4

    iget p1, p0, Landroidx/recyclerview/widget/ZfxDd;->Ucbh:I

    if-nez p1, :cond_0

    return-void

    :cond_0
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getAction()I

    move-result p1

    const/4 v0, 0x1

    const/4 v1, 0x2

    if-nez p1, :cond_4

    invoke-virtual {p2}, Landroid/view/MotionEvent;->getX()F

    move-result p1

    invoke-virtual {p2}, Landroid/view/MotionEvent;->getY()F

    move-result v2

    invoke-virtual {p0, p1, v2}, Landroidx/recyclerview/widget/ZfxDd;->eyqo(FF)Z

    move-result p1

    invoke-virtual {p2}, Landroid/view/MotionEvent;->getX()F

    move-result v2

    invoke-virtual {p2}, Landroid/view/MotionEvent;->getY()F

    move-result v3

    invoke-virtual {p0, v2, v3}, Landroidx/recyclerview/widget/ZfxDd;->diqgf(FF)Z

    move-result v2

    if-nez p1, :cond_1

    if-eqz v2, :cond_7

    :cond_1
    if-eqz v2, :cond_2

    iput v0, p0, Landroidx/recyclerview/widget/ZfxDd;->huTpC:I

    invoke-virtual {p2}, Landroid/view/MotionEvent;->getX()F

    move-result p1

    float-to-int p1, p1

    int-to-float p1, p1

    iput p1, p0, Landroidx/recyclerview/widget/ZfxDd;->qGY:F

    goto :goto_0

    :cond_2
    if-eqz p1, :cond_3

    iput v1, p0, Landroidx/recyclerview/widget/ZfxDd;->huTpC:I

    invoke-virtual {p2}, Landroid/view/MotionEvent;->getY()F

    move-result p1

    float-to-int p1, p1

    int-to-float p1, p1

    iput p1, p0, Landroidx/recyclerview/widget/ZfxDd;->MiMN:F

    :cond_3
    :goto_0
    invoke-virtual {p0, v1}, Landroidx/recyclerview/widget/ZfxDd;->HGpJ(I)V

    goto :goto_1

    :cond_4
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getAction()I

    move-result p1

    if-ne p1, v0, :cond_5

    iget p1, p0, Landroidx/recyclerview/widget/ZfxDd;->Ucbh:I

    if-ne p1, v1, :cond_5

    const/4 p1, 0x0

    iput p1, p0, Landroidx/recyclerview/widget/ZfxDd;->MiMN:F

    iput p1, p0, Landroidx/recyclerview/widget/ZfxDd;->qGY:F

    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/ZfxDd;->HGpJ(I)V

    const/4 p1, 0x0

    iput p1, p0, Landroidx/recyclerview/widget/ZfxDd;->huTpC:I

    goto :goto_1

    :cond_5
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getAction()I

    move-result p1

    if-ne p1, v1, :cond_7

    iget p1, p0, Landroidx/recyclerview/widget/ZfxDd;->Ucbh:I

    if-ne p1, v1, :cond_7

    invoke-virtual {p0}, Landroidx/recyclerview/widget/ZfxDd;->VocHEe()V

    iget p1, p0, Landroidx/recyclerview/widget/ZfxDd;->huTpC:I

    if-ne p1, v0, :cond_6

    invoke-virtual {p2}, Landroid/view/MotionEvent;->getX()F

    move-result p1

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/ZfxDd;->IEE(F)V

    :cond_6
    iget p1, p0, Landroidx/recyclerview/widget/ZfxDd;->huTpC:I

    if-ne p1, v1, :cond_7

    invoke-virtual {p2}, Landroid/view/MotionEvent;->getY()F

    move-result p1

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/ZfxDd;->lB(F)V

    :cond_7
    :goto_1
    return-void
.end method

.method public BAnRFn(II)V
    .locals 8

    iget-object v0, p0, Landroidx/recyclerview/widget/ZfxDd;->Pq:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {v0}, Landroidx/recyclerview/widget/RecyclerView;->computeVerticalScrollRange()I

    move-result v0

    iget v1, p0, Landroidx/recyclerview/widget/ZfxDd;->IEE:I

    sub-int v2, v0, v1

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-lez v2, :cond_0

    iget v2, p0, Landroidx/recyclerview/widget/ZfxDd;->mjFkc:I

    if-lt v1, v2, :cond_0

    move v2, v4

    goto :goto_0

    :cond_0
    move v2, v3

    :goto_0
    iput-boolean v2, p0, Landroidx/recyclerview/widget/ZfxDd;->diqgf:Z

    iget-object v2, p0, Landroidx/recyclerview/widget/ZfxDd;->Pq:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {v2}, Landroidx/recyclerview/widget/RecyclerView;->computeHorizontalScrollRange()I

    move-result v2

    iget v5, p0, Landroidx/recyclerview/widget/ZfxDd;->fehf:I

    sub-int v6, v2, v5

    if-lez v6, :cond_1

    iget v6, p0, Landroidx/recyclerview/widget/ZfxDd;->mjFkc:I

    if-lt v5, v6, :cond_1

    move v6, v4

    goto :goto_1

    :cond_1
    move v6, v3

    :goto_1
    iput-boolean v6, p0, Landroidx/recyclerview/widget/ZfxDd;->eyqo:Z

    iget-boolean v7, p0, Landroidx/recyclerview/widget/ZfxDd;->diqgf:Z

    if-nez v7, :cond_3

    if-nez v6, :cond_3

    iget p1, p0, Landroidx/recyclerview/widget/ZfxDd;->Ucbh:I

    if-eqz p1, :cond_2

    invoke-virtual {p0, v3}, Landroidx/recyclerview/widget/ZfxDd;->HGpJ(I)V

    :cond_2
    return-void

    :cond_3
    const/high16 v3, 0x40000000    # 2.0f

    if-eqz v7, :cond_4

    int-to-float p2, p2

    int-to-float v6, v1

    div-float v7, v6, v3

    add-float/2addr p2, v7

    mul-float/2addr v6, p2

    int-to-float p2, v0

    div-float/2addr v6, p2

    float-to-int p2, v6

    iput p2, p0, Landroidx/recyclerview/widget/ZfxDd;->VA:I

    mul-int p2, v1, v1

    div-int/2addr p2, v0

    invoke-static {v1, p2}, Ljava/lang/Math;->min(II)I

    move-result p2

    iput p2, p0, Landroidx/recyclerview/widget/ZfxDd;->ETF:I

    :cond_4
    iget-boolean p2, p0, Landroidx/recyclerview/widget/ZfxDd;->eyqo:Z

    if-eqz p2, :cond_5

    int-to-float p1, p1

    int-to-float p2, v5

    div-float v0, p2, v3

    add-float/2addr p1, v0

    mul-float/2addr p2, p1

    int-to-float p1, v2

    div-float/2addr p2, p1

    float-to-int p1, p2

    iput p1, p0, Landroidx/recyclerview/widget/ZfxDd;->rkYL:I

    mul-int p1, v5, v5

    div-int/2addr p1, v2

    invoke-static {v5, p1}, Ljava/lang/Math;->min(II)I

    move-result p1

    iput p1, p0, Landroidx/recyclerview/widget/ZfxDd;->YoKzxo:I

    :cond_5
    iget p1, p0, Landroidx/recyclerview/widget/ZfxDd;->Ucbh:I

    if-eqz p1, :cond_6

    if-ne p1, v4, :cond_7

    :cond_6
    invoke-virtual {p0, v4}, Landroidx/recyclerview/widget/ZfxDd;->HGpJ(I)V

    :cond_7
    return-void
.end method

.method public Dt(Landroidx/recyclerview/widget/RecyclerView;)V
    .locals 1

    iget-object v0, p0, Landroidx/recyclerview/widget/ZfxDd;->Pq:Landroidx/recyclerview/widget/RecyclerView;

    if-ne v0, p1, :cond_0

    return-void

    :cond_0
    if-eqz v0, :cond_1

    invoke-virtual {p0}, Landroidx/recyclerview/widget/ZfxDd;->VA()V

    :cond_1
    iput-object p1, p0, Landroidx/recyclerview/widget/ZfxDd;->Pq:Landroidx/recyclerview/widget/RecyclerView;

    if-eqz p1, :cond_2

    invoke-virtual {p0}, Landroidx/recyclerview/widget/ZfxDd;->vI()V

    :cond_2
    return-void
.end method

.method public final ETF()V
    .locals 1

    iget-object v0, p0, Landroidx/recyclerview/widget/ZfxDd;->Pq:Landroidx/recyclerview/widget/RecyclerView;

    iget-object p0, p0, Landroidx/recyclerview/widget/ZfxDd;->BAnRFn:Ljava/lang/Runnable;

    invoke-virtual {v0, p0}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    return-void
.end method

.method public final Gd(FF[IIII)I
    .locals 1

    const/4 p0, 0x1

    aget p0, p3, p0

    const/4 v0, 0x0

    aget p3, p3, v0

    sub-int/2addr p0, p3

    if-nez p0, :cond_0

    return v0

    :cond_0
    sub-float/2addr p2, p1

    int-to-float p0, p0

    div-float/2addr p2, p0

    sub-int/2addr p4, p6

    int-to-float p0, p4

    mul-float/2addr p2, p0

    float-to-int p0, p2

    add-int/2addr p5, p0

    if-ge p5, p4, :cond_1

    if-ltz p5, :cond_1

    return p0

    :cond_1
    return v0
.end method

.method public HGpJ(I)V
    .locals 3

    const/4 v0, 0x2

    if-ne p1, v0, :cond_0

    iget v1, p0, Landroidx/recyclerview/widget/ZfxDd;->Ucbh:I

    if-eq v1, v0, :cond_0

    iget-object v1, p0, Landroidx/recyclerview/widget/ZfxDd;->wA:Landroid/graphics/drawable/StateListDrawable;

    sget-object v2, Landroidx/recyclerview/widget/ZfxDd;->wJVbdd:[I

    invoke-virtual {v1, v2}, Landroid/graphics/drawable/Drawable;->setState([I)Z

    invoke-virtual {p0}, Landroidx/recyclerview/widget/ZfxDd;->ETF()V

    :cond_0
    if-nez p1, :cond_1

    invoke-virtual {p0}, Landroidx/recyclerview/widget/ZfxDd;->Ucbh()V

    goto :goto_0

    :cond_1
    invoke-virtual {p0}, Landroidx/recyclerview/widget/ZfxDd;->VocHEe()V

    :goto_0
    iget v1, p0, Landroidx/recyclerview/widget/ZfxDd;->Ucbh:I

    if-ne v1, v0, :cond_2

    if-eq p1, v0, :cond_2

    iget-object v0, p0, Landroidx/recyclerview/widget/ZfxDd;->wA:Landroid/graphics/drawable/StateListDrawable;

    sget-object v1, Landroidx/recyclerview/widget/ZfxDd;->mByQ:[I

    invoke-virtual {v0, v1}, Landroid/graphics/drawable/Drawable;->setState([I)Z

    const/16 v0, 0x4b0

    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/ZfxDd;->huTpC(I)V

    goto :goto_1

    :cond_2
    const/4 v0, 0x1

    if-ne p1, v0, :cond_3

    const/16 v0, 0x5dc

    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/ZfxDd;->huTpC(I)V

    :cond_3
    :goto_1
    iput p1, p0, Landroidx/recyclerview/widget/ZfxDd;->Ucbh:I

    return-void
.end method

.method public final IEE(F)V
    .locals 8

    invoke-virtual {p0}, Landroidx/recyclerview/widget/ZfxDd;->rkYL()[I

    move-result-object v3

    const/4 v7, 0x0

    aget v0, v3, v7

    int-to-float v0, v0

    const/4 v1, 0x1

    aget v1, v3, v1

    int-to-float v1, v1

    invoke-static {v1, p1}, Ljava/lang/Math;->min(FF)F

    move-result p1

    invoke-static {v0, p1}, Ljava/lang/Math;->max(FF)F

    move-result p1

    iget v0, p0, Landroidx/recyclerview/widget/ZfxDd;->rkYL:I

    int-to-float v0, v0

    sub-float/2addr v0, p1

    invoke-static {v0}, Ljava/lang/Math;->abs(F)F

    move-result v0

    const/high16 v1, 0x40000000    # 2.0f

    cmpg-float v0, v0, v1

    if-gez v0, :cond_0

    return-void

    :cond_0
    iget v1, p0, Landroidx/recyclerview/widget/ZfxDd;->qGY:F

    iget-object v0, p0, Landroidx/recyclerview/widget/ZfxDd;->Pq:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {v0}, Landroidx/recyclerview/widget/RecyclerView;->computeHorizontalScrollRange()I

    move-result v4

    iget-object v0, p0, Landroidx/recyclerview/widget/ZfxDd;->Pq:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {v0}, Landroidx/recyclerview/widget/RecyclerView;->computeHorizontalScrollOffset()I

    move-result v5

    iget v6, p0, Landroidx/recyclerview/widget/ZfxDd;->fehf:I

    move-object v0, p0

    move v2, p1

    invoke-virtual/range {v0 .. v6}, Landroidx/recyclerview/widget/ZfxDd;->Gd(FF[IIII)I

    move-result v0

    if-eqz v0, :cond_1

    iget-object v1, p0, Landroidx/recyclerview/widget/ZfxDd;->Pq:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {v1, v0, v7}, Landroidx/recyclerview/widget/RecyclerView;->scrollBy(II)V

    :cond_1
    iput p1, p0, Landroidx/recyclerview/widget/ZfxDd;->qGY:F

    return-void
.end method

.method public final MiMN(Landroid/graphics/Canvas;)V
    .locals 6

    iget v0, p0, Landroidx/recyclerview/widget/ZfxDd;->IEE:I

    iget v1, p0, Landroidx/recyclerview/widget/ZfxDd;->qdMbNW:I

    sub-int/2addr v0, v1

    iget v2, p0, Landroidx/recyclerview/widget/ZfxDd;->rkYL:I

    iget v3, p0, Landroidx/recyclerview/widget/ZfxDd;->YoKzxo:I

    div-int/lit8 v4, v3, 0x2

    sub-int/2addr v2, v4

    iget-object v4, p0, Landroidx/recyclerview/widget/ZfxDd;->xJ:Landroid/graphics/drawable/StateListDrawable;

    const/4 v5, 0x0

    invoke-virtual {v4, v5, v5, v3, v1}, Landroid/graphics/drawable/Drawable;->setBounds(IIII)V

    iget-object v1, p0, Landroidx/recyclerview/widget/ZfxDd;->lgHUyS:Landroid/graphics/drawable/Drawable;

    iget v3, p0, Landroidx/recyclerview/widget/ZfxDd;->fehf:I

    iget v4, p0, Landroidx/recyclerview/widget/ZfxDd;->Dt:I

    invoke-virtual {v1, v5, v5, v3, v4}, Landroid/graphics/drawable/Drawable;->setBounds(IIII)V

    int-to-float v1, v0

    const/4 v3, 0x0

    invoke-virtual {p1, v3, v1}, Landroid/graphics/Canvas;->translate(FF)V

    iget-object v1, p0, Landroidx/recyclerview/widget/ZfxDd;->lgHUyS:Landroid/graphics/drawable/Drawable;

    invoke-virtual {v1, p1}, Landroid/graphics/drawable/Drawable;->draw(Landroid/graphics/Canvas;)V

    int-to-float v1, v2

    invoke-virtual {p1, v1, v3}, Landroid/graphics/Canvas;->translate(FF)V

    iget-object p0, p0, Landroidx/recyclerview/widget/ZfxDd;->xJ:Landroid/graphics/drawable/StateListDrawable;

    invoke-virtual {p0, p1}, Landroid/graphics/drawable/Drawable;->draw(Landroid/graphics/Canvas;)V

    neg-int p0, v2

    int-to-float p0, p0

    neg-int v0, v0

    int-to-float v0, v0

    invoke-virtual {p1, p0, v0}, Landroid/graphics/Canvas;->translate(FF)V

    return-void
.end method

.method public final Pq()Z
    .locals 1

    iget-object p0, p0, Landroidx/recyclerview/widget/ZfxDd;->Pq:Landroidx/recyclerview/widget/RecyclerView;

    invoke-static {p0}, Lo/T9;->huTpC(Landroid/view/View;)I

    move-result p0

    const/4 v0, 0x1

    if-ne p0, v0, :cond_0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public Ucbh()V
    .locals 0

    iget-object p0, p0, Landroidx/recyclerview/widget/ZfxDd;->Pq:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {p0}, Landroid/view/View;->invalidate()V

    return-void
.end method

.method public final VA()V
    .locals 2

    iget-object v0, p0, Landroidx/recyclerview/widget/ZfxDd;->Pq:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {v0, p0}, Landroidx/recyclerview/widget/RecyclerView;->Jk(Landroidx/recyclerview/widget/RecyclerView$rkYL;)V

    iget-object v0, p0, Landroidx/recyclerview/widget/ZfxDd;->Pq:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {v0, p0}, Landroidx/recyclerview/widget/RecyclerView;->KRckQg(Landroidx/recyclerview/widget/RecyclerView$Pq;)V

    iget-object v0, p0, Landroidx/recyclerview/widget/ZfxDd;->Pq:Landroidx/recyclerview/widget/RecyclerView;

    iget-object v1, p0, Landroidx/recyclerview/widget/ZfxDd;->lB:Landroidx/recyclerview/widget/RecyclerView$diqgf;

    invoke-virtual {v0, v1}, Landroidx/recyclerview/widget/RecyclerView;->mPWV(Landroidx/recyclerview/widget/RecyclerView$diqgf;)V

    invoke-virtual {p0}, Landroidx/recyclerview/widget/ZfxDd;->ETF()V

    return-void
.end method

.method public VocHEe()V
    .locals 5

    const/4 v0, 0x1

    iget v1, p0, Landroidx/recyclerview/widget/ZfxDd;->VocHEe:I

    if-eqz v1, :cond_1

    const/4 v2, 0x3

    if-eq v1, v2, :cond_0

    goto :goto_0

    :cond_0
    iget-object v1, p0, Landroidx/recyclerview/widget/ZfxDd;->vI:Landroid/animation/ValueAnimator;

    invoke-virtual {v1}, Landroid/animation/ValueAnimator;->cancel()V

    :cond_1
    iput v0, p0, Landroidx/recyclerview/widget/ZfxDd;->VocHEe:I

    iget-object v1, p0, Landroidx/recyclerview/widget/ZfxDd;->vI:Landroid/animation/ValueAnimator;

    invoke-virtual {v1}, Landroid/animation/ValueAnimator;->getAnimatedValue()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/Float;

    invoke-virtual {v2}, Ljava/lang/Float;->floatValue()F

    move-result v2

    const/4 v3, 0x2

    new-array v3, v3, [F

    const/4 v4, 0x0

    aput v2, v3, v4

    const/high16 v2, 0x3f800000    # 1.0f

    aput v2, v3, v0

    invoke-virtual {v1, v3}, Landroid/animation/ValueAnimator;->setFloatValues([F)V

    iget-object v0, p0, Landroidx/recyclerview/widget/ZfxDd;->vI:Landroid/animation/ValueAnimator;

    const-wide/16 v1, 0x1f4

    invoke-virtual {v0, v1, v2}, Landroid/animation/ValueAnimator;->setDuration(J)Landroid/animation/ValueAnimator;

    iget-object v0, p0, Landroidx/recyclerview/widget/ZfxDd;->vI:Landroid/animation/ValueAnimator;

    const-wide/16 v1, 0x0

    invoke-virtual {v0, v1, v2}, Landroid/animation/ValueAnimator;->setStartDelay(J)V

    iget-object p0, p0, Landroidx/recyclerview/widget/ZfxDd;->vI:Landroid/animation/ValueAnimator;

    invoke-virtual {p0}, Landroid/animation/ValueAnimator;->start()V

    :goto_0
    return-void
.end method

.method public final YoKzxo(Landroid/graphics/Canvas;)V
    .locals 6

    iget v0, p0, Landroidx/recyclerview/widget/ZfxDd;->fehf:I

    iget v1, p0, Landroidx/recyclerview/widget/ZfxDd;->KLFTb:I

    sub-int/2addr v0, v1

    iget v2, p0, Landroidx/recyclerview/widget/ZfxDd;->VA:I

    iget v3, p0, Landroidx/recyclerview/widget/ZfxDd;->ETF:I

    div-int/lit8 v4, v3, 0x2

    sub-int/2addr v2, v4

    iget-object v4, p0, Landroidx/recyclerview/widget/ZfxDd;->wA:Landroid/graphics/drawable/StateListDrawable;

    const/4 v5, 0x0

    invoke-virtual {v4, v5, v5, v1, v3}, Landroid/graphics/drawable/Drawable;->setBounds(IIII)V

    iget-object v1, p0, Landroidx/recyclerview/widget/ZfxDd;->ZfxDd:Landroid/graphics/drawable/Drawable;

    iget v3, p0, Landroidx/recyclerview/widget/ZfxDd;->JHa:I

    iget v4, p0, Landroidx/recyclerview/widget/ZfxDd;->IEE:I

    invoke-virtual {v1, v5, v5, v3, v4}, Landroid/graphics/drawable/Drawable;->setBounds(IIII)V

    invoke-virtual {p0}, Landroidx/recyclerview/widget/ZfxDd;->Pq()Z

    move-result v1

    if-eqz v1, :cond_0

    iget-object v0, p0, Landroidx/recyclerview/widget/ZfxDd;->ZfxDd:Landroid/graphics/drawable/Drawable;

    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->draw(Landroid/graphics/Canvas;)V

    iget v0, p0, Landroidx/recyclerview/widget/ZfxDd;->KLFTb:I

    int-to-float v0, v0

    int-to-float v1, v2

    invoke-virtual {p1, v0, v1}, Landroid/graphics/Canvas;->translate(FF)V

    const/high16 v0, -0x40800000    # -1.0f

    const/high16 v1, 0x3f800000    # 1.0f

    invoke-virtual {p1, v0, v1}, Landroid/graphics/Canvas;->scale(FF)V

    iget-object v3, p0, Landroidx/recyclerview/widget/ZfxDd;->wA:Landroid/graphics/drawable/StateListDrawable;

    invoke-virtual {v3, p1}, Landroid/graphics/drawable/Drawable;->draw(Landroid/graphics/Canvas;)V

    invoke-virtual {p1, v0, v1}, Landroid/graphics/Canvas;->scale(FF)V

    iget p0, p0, Landroidx/recyclerview/widget/ZfxDd;->KLFTb:I

    neg-int p0, p0

    int-to-float p0, p0

    neg-int v0, v2

    int-to-float v0, v0

    invoke-virtual {p1, p0, v0}, Landroid/graphics/Canvas;->translate(FF)V

    goto :goto_0

    :cond_0
    int-to-float v1, v0

    const/4 v3, 0x0

    invoke-virtual {p1, v1, v3}, Landroid/graphics/Canvas;->translate(FF)V

    iget-object v1, p0, Landroidx/recyclerview/widget/ZfxDd;->ZfxDd:Landroid/graphics/drawable/Drawable;

    invoke-virtual {v1, p1}, Landroid/graphics/drawable/Drawable;->draw(Landroid/graphics/Canvas;)V

    int-to-float v1, v2

    invoke-virtual {p1, v3, v1}, Landroid/graphics/Canvas;->translate(FF)V

    iget-object p0, p0, Landroidx/recyclerview/widget/ZfxDd;->wA:Landroid/graphics/drawable/StateListDrawable;

    invoke-virtual {p0, p1}, Landroid/graphics/drawable/Drawable;->draw(Landroid/graphics/Canvas;)V

    neg-int p0, v0

    int-to-float p0, p0

    neg-int v0, v2

    int-to-float v0, v0

    invoke-virtual {p1, p0, v0}, Landroid/graphics/Canvas;->translate(FF)V

    :goto_0
    return-void
.end method

.method public diqgf(FF)Z
    .locals 2

    iget v0, p0, Landroidx/recyclerview/widget/ZfxDd;->IEE:I

    iget v1, p0, Landroidx/recyclerview/widget/ZfxDd;->qdMbNW:I

    sub-int/2addr v0, v1

    int-to-float v0, v0

    cmpl-float p2, p2, v0

    if-ltz p2, :cond_0

    iget p2, p0, Landroidx/recyclerview/widget/ZfxDd;->rkYL:I

    iget p0, p0, Landroidx/recyclerview/widget/ZfxDd;->YoKzxo:I

    div-int/lit8 v0, p0, 0x2

    sub-int v0, p2, v0

    int-to-float v0, v0

    cmpl-float v0, p1, v0

    if-ltz v0, :cond_0

    div-int/lit8 p0, p0, 0x2

    add-int/2addr p2, p0

    int-to-float p0, p2

    cmpg-float p0, p1, p0

    if-gtz p0, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method

.method public eyqo(FF)Z
    .locals 2

    invoke-virtual {p0}, Landroidx/recyclerview/widget/ZfxDd;->Pq()Z

    move-result v0

    if-eqz v0, :cond_0

    iget v0, p0, Landroidx/recyclerview/widget/ZfxDd;->KLFTb:I

    int-to-float v0, v0

    cmpg-float p1, p1, v0

    if-gtz p1, :cond_1

    goto :goto_0

    :cond_0
    iget v0, p0, Landroidx/recyclerview/widget/ZfxDd;->fehf:I

    iget v1, p0, Landroidx/recyclerview/widget/ZfxDd;->KLFTb:I

    sub-int/2addr v0, v1

    int-to-float v0, v0

    cmpl-float p1, p1, v0

    if-ltz p1, :cond_1

    :goto_0
    iget p1, p0, Landroidx/recyclerview/widget/ZfxDd;->VA:I

    iget p0, p0, Landroidx/recyclerview/widget/ZfxDd;->ETF:I

    div-int/lit8 v0, p0, 0x2

    sub-int v0, p1, v0

    int-to-float v0, v0

    cmpl-float v0, p2, v0

    if-ltz v0, :cond_1

    div-int/lit8 p0, p0, 0x2

    add-int/2addr p1, p0

    int-to-float p0, p1

    cmpg-float p0, p2, p0

    if-gtz p0, :cond_1

    const/4 p0, 0x1

    goto :goto_1

    :cond_1
    const/4 p0, 0x0

    :goto_1
    return p0
.end method

.method public fehf(I)V
    .locals 5

    const/4 v0, 0x2

    const/4 v1, 0x1

    iget v2, p0, Landroidx/recyclerview/widget/ZfxDd;->VocHEe:I

    if-eq v2, v1, :cond_0

    if-eq v2, v0, :cond_1

    goto :goto_0

    :cond_0
    iget-object v2, p0, Landroidx/recyclerview/widget/ZfxDd;->vI:Landroid/animation/ValueAnimator;

    invoke-virtual {v2}, Landroid/animation/ValueAnimator;->cancel()V

    :cond_1
    const/4 v2, 0x3

    iput v2, p0, Landroidx/recyclerview/widget/ZfxDd;->VocHEe:I

    iget-object v2, p0, Landroidx/recyclerview/widget/ZfxDd;->vI:Landroid/animation/ValueAnimator;

    invoke-virtual {v2}, Landroid/animation/ValueAnimator;->getAnimatedValue()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Float;

    invoke-virtual {v3}, Ljava/lang/Float;->floatValue()F

    move-result v3

    new-array v0, v0, [F

    const/4 v4, 0x0

    aput v3, v0, v4

    const/4 v3, 0x0

    aput v3, v0, v1

    invoke-virtual {v2, v0}, Landroid/animation/ValueAnimator;->setFloatValues([F)V

    iget-object v0, p0, Landroidx/recyclerview/widget/ZfxDd;->vI:Landroid/animation/ValueAnimator;

    int-to-long v1, p1

    invoke-virtual {v0, v1, v2}, Landroid/animation/ValueAnimator;->setDuration(J)Landroid/animation/ValueAnimator;

    iget-object p0, p0, Landroidx/recyclerview/widget/ZfxDd;->vI:Landroid/animation/ValueAnimator;

    invoke-virtual {p0}, Landroid/animation/ValueAnimator;->start()V

    :goto_0
    return-void
.end method

.method public final huTpC(I)V
    .locals 3

    invoke-virtual {p0}, Landroidx/recyclerview/widget/ZfxDd;->ETF()V

    iget-object v0, p0, Landroidx/recyclerview/widget/ZfxDd;->Pq:Landroidx/recyclerview/widget/RecyclerView;

    iget-object p0, p0, Landroidx/recyclerview/widget/ZfxDd;->BAnRFn:Ljava/lang/Runnable;

    int-to-long v1, p1

    invoke-virtual {v0, p0, v1, v2}, Landroid/view/View;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void
.end method

.method public final lB(F)V
    .locals 8

    invoke-virtual {p0}, Landroidx/recyclerview/widget/ZfxDd;->qGY()[I

    move-result-object v3

    const/4 v7, 0x0

    aget v0, v3, v7

    int-to-float v0, v0

    const/4 v1, 0x1

    aget v1, v3, v1

    int-to-float v1, v1

    invoke-static {v1, p1}, Ljava/lang/Math;->min(FF)F

    move-result p1

    invoke-static {v0, p1}, Ljava/lang/Math;->max(FF)F

    move-result p1

    iget v0, p0, Landroidx/recyclerview/widget/ZfxDd;->VA:I

    int-to-float v0, v0

    sub-float/2addr v0, p1

    invoke-static {v0}, Ljava/lang/Math;->abs(F)F

    move-result v0

    const/high16 v1, 0x40000000    # 2.0f

    cmpg-float v0, v0, v1

    if-gez v0, :cond_0

    return-void

    :cond_0
    iget v1, p0, Landroidx/recyclerview/widget/ZfxDd;->MiMN:F

    iget-object v0, p0, Landroidx/recyclerview/widget/ZfxDd;->Pq:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {v0}, Landroidx/recyclerview/widget/RecyclerView;->computeVerticalScrollRange()I

    move-result v4

    iget-object v0, p0, Landroidx/recyclerview/widget/ZfxDd;->Pq:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {v0}, Landroidx/recyclerview/widget/RecyclerView;->computeVerticalScrollOffset()I

    move-result v5

    iget v6, p0, Landroidx/recyclerview/widget/ZfxDd;->IEE:I

    move-object v0, p0

    move v2, p1

    invoke-virtual/range {v0 .. v6}, Landroidx/recyclerview/widget/ZfxDd;->Gd(FF[IIII)I

    move-result v0

    if-eqz v0, :cond_1

    iget-object v1, p0, Landroidx/recyclerview/widget/ZfxDd;->Pq:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {v1, v7, v0}, Landroidx/recyclerview/widget/RecyclerView;->scrollBy(II)V

    :cond_1
    iput p1, p0, Landroidx/recyclerview/widget/ZfxDd;->MiMN:F

    return-void
.end method

.method public mjFkc(Landroidx/recyclerview/widget/RecyclerView;Landroid/view/MotionEvent;)Z
    .locals 5

    iget p1, p0, Landroidx/recyclerview/widget/ZfxDd;->Ucbh:I

    const/4 v0, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x1

    if-ne p1, v2, :cond_3

    invoke-virtual {p2}, Landroid/view/MotionEvent;->getX()F

    move-result p1

    invoke-virtual {p2}, Landroid/view/MotionEvent;->getY()F

    move-result v3

    invoke-virtual {p0, p1, v3}, Landroidx/recyclerview/widget/ZfxDd;->eyqo(FF)Z

    move-result p1

    invoke-virtual {p2}, Landroid/view/MotionEvent;->getX()F

    move-result v3

    invoke-virtual {p2}, Landroid/view/MotionEvent;->getY()F

    move-result v4

    invoke-virtual {p0, v3, v4}, Landroidx/recyclerview/widget/ZfxDd;->diqgf(FF)Z

    move-result v3

    invoke-virtual {p2}, Landroid/view/MotionEvent;->getAction()I

    move-result v4

    if-nez v4, :cond_4

    if-nez p1, :cond_0

    if-eqz v3, :cond_4

    :cond_0
    if-eqz v3, :cond_1

    iput v2, p0, Landroidx/recyclerview/widget/ZfxDd;->huTpC:I

    invoke-virtual {p2}, Landroid/view/MotionEvent;->getX()F

    move-result p1

    float-to-int p1, p1

    int-to-float p1, p1

    iput p1, p0, Landroidx/recyclerview/widget/ZfxDd;->qGY:F

    goto :goto_0

    :cond_1
    if-eqz p1, :cond_2

    iput v1, p0, Landroidx/recyclerview/widget/ZfxDd;->huTpC:I

    invoke-virtual {p2}, Landroid/view/MotionEvent;->getY()F

    move-result p1

    float-to-int p1, p1

    int-to-float p1, p1

    iput p1, p0, Landroidx/recyclerview/widget/ZfxDd;->MiMN:F

    :cond_2
    :goto_0
    invoke-virtual {p0, v1}, Landroidx/recyclerview/widget/ZfxDd;->HGpJ(I)V

    goto :goto_1

    :cond_3
    if-ne p1, v1, :cond_4

    :goto_1
    move v0, v2

    :cond_4
    return v0
.end method

.method public final qGY()[I
    .locals 3

    iget-object v0, p0, Landroidx/recyclerview/widget/ZfxDd;->Gd:[I

    iget v1, p0, Landroidx/recyclerview/widget/ZfxDd;->AZxh:I

    const/4 v2, 0x0

    aput v1, v0, v2

    iget p0, p0, Landroidx/recyclerview/widget/ZfxDd;->IEE:I

    sub-int/2addr p0, v1

    const/4 v1, 0x1

    aput p0, v0, v1

    return-object v0
.end method

.method public qdMbNW(Landroid/graphics/Canvas;Landroidx/recyclerview/widget/RecyclerView;Landroidx/recyclerview/widget/RecyclerView$VocHEe;)V
    .locals 0

    iget p2, p0, Landroidx/recyclerview/widget/ZfxDd;->fehf:I

    iget-object p3, p0, Landroidx/recyclerview/widget/ZfxDd;->Pq:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {p3}, Landroid/view/View;->getWidth()I

    move-result p3

    if-ne p2, p3, :cond_3

    iget p2, p0, Landroidx/recyclerview/widget/ZfxDd;->IEE:I

    iget-object p3, p0, Landroidx/recyclerview/widget/ZfxDd;->Pq:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {p3}, Landroid/view/View;->getHeight()I

    move-result p3

    if-eq p2, p3, :cond_0

    goto :goto_0

    :cond_0
    iget p2, p0, Landroidx/recyclerview/widget/ZfxDd;->VocHEe:I

    if-eqz p2, :cond_2

    iget-boolean p2, p0, Landroidx/recyclerview/widget/ZfxDd;->diqgf:Z

    if-eqz p2, :cond_1

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/ZfxDd;->YoKzxo(Landroid/graphics/Canvas;)V

    :cond_1
    iget-boolean p2, p0, Landroidx/recyclerview/widget/ZfxDd;->eyqo:Z

    if-eqz p2, :cond_2

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/ZfxDd;->MiMN(Landroid/graphics/Canvas;)V

    :cond_2
    return-void

    :cond_3
    :goto_0
    iget-object p1, p0, Landroidx/recyclerview/widget/ZfxDd;->Pq:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {p1}, Landroid/view/View;->getWidth()I

    move-result p1

    iput p1, p0, Landroidx/recyclerview/widget/ZfxDd;->fehf:I

    iget-object p1, p0, Landroidx/recyclerview/widget/ZfxDd;->Pq:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {p1}, Landroid/view/View;->getHeight()I

    move-result p1

    iput p1, p0, Landroidx/recyclerview/widget/ZfxDd;->IEE:I

    const/4 p1, 0x0

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/ZfxDd;->HGpJ(I)V

    return-void
.end method

.method public final rkYL()[I
    .locals 3

    iget-object v0, p0, Landroidx/recyclerview/widget/ZfxDd;->HGpJ:[I

    iget v1, p0, Landroidx/recyclerview/widget/ZfxDd;->AZxh:I

    const/4 v2, 0x0

    aput v1, v0, v2

    iget p0, p0, Landroidx/recyclerview/widget/ZfxDd;->fehf:I

    sub-int/2addr p0, v1

    const/4 v1, 0x1

    aput p0, v0, v1

    return-object v0
.end method

.method public final vI()V
    .locals 1

    iget-object v0, p0, Landroidx/recyclerview/widget/ZfxDd;->Pq:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {v0, p0}, Landroidx/recyclerview/widget/RecyclerView;->qdMbNW(Landroidx/recyclerview/widget/RecyclerView$rkYL;)V

    iget-object v0, p0, Landroidx/recyclerview/widget/ZfxDd;->Pq:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {v0, p0}, Landroidx/recyclerview/widget/RecyclerView;->ETF(Landroidx/recyclerview/widget/RecyclerView$Pq;)V

    iget-object v0, p0, Landroidx/recyclerview/widget/ZfxDd;->Pq:Landroidx/recyclerview/widget/RecyclerView;

    iget-object p0, p0, Landroidx/recyclerview/widget/ZfxDd;->lB:Landroidx/recyclerview/widget/RecyclerView$diqgf;

    invoke-virtual {v0, p0}, Landroidx/recyclerview/widget/RecyclerView;->VA(Landroidx/recyclerview/widget/RecyclerView$diqgf;)V

    return-void
.end method

.method public wA(Z)V
    .locals 0

    return-void
.end method
