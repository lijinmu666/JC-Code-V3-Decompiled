.class public Landroidx/recyclerview/widget/wA$lgHUyS;
.super Landroid/animation/AnimatorListenerAdapter;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Landroidx/recyclerview/widget/wA;->aqHPIZ(Landroidx/recyclerview/widget/wA$qdMbNW;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic AZxh:Landroid/view/ViewPropertyAnimator;

.field public final synthetic ZfxDd:Landroidx/recyclerview/widget/wA;

.field public final synthetic mjFkc:Landroidx/recyclerview/widget/wA$qdMbNW;

.field public final synthetic wA:Landroid/view/View;


# direct methods
.method public constructor <init>(Landroidx/recyclerview/widget/wA;Landroidx/recyclerview/widget/wA$qdMbNW;Landroid/view/ViewPropertyAnimator;Landroid/view/View;)V
    .locals 0

    iput-object p1, p0, Landroidx/recyclerview/widget/wA$lgHUyS;->ZfxDd:Landroidx/recyclerview/widget/wA;

    iput-object p2, p0, Landroidx/recyclerview/widget/wA$lgHUyS;->mjFkc:Landroidx/recyclerview/widget/wA$qdMbNW;

    iput-object p3, p0, Landroidx/recyclerview/widget/wA$lgHUyS;->AZxh:Landroid/view/ViewPropertyAnimator;

    iput-object p4, p0, Landroidx/recyclerview/widget/wA$lgHUyS;->wA:Landroid/view/View;

    invoke-direct {p0}, Landroid/animation/AnimatorListenerAdapter;-><init>()V

    return-void
.end method


# virtual methods
.method public onAnimationEnd(Landroid/animation/Animator;)V
    .locals 2

    iget-object p1, p0, Landroidx/recyclerview/widget/wA$lgHUyS;->AZxh:Landroid/view/ViewPropertyAnimator;

    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Landroid/view/ViewPropertyAnimator;->setListener(Landroid/animation/Animator$AnimatorListener;)Landroid/view/ViewPropertyAnimator;

    iget-object p1, p0, Landroidx/recyclerview/widget/wA$lgHUyS;->wA:Landroid/view/View;

    const/high16 v0, 0x3f800000    # 1.0f

    invoke-virtual {p1, v0}, Landroid/view/View;->setAlpha(F)V

    iget-object p1, p0, Landroidx/recyclerview/widget/wA$lgHUyS;->wA:Landroid/view/View;

    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Landroid/view/View;->setTranslationX(F)V

    iget-object p1, p0, Landroidx/recyclerview/widget/wA$lgHUyS;->wA:Landroid/view/View;

    invoke-virtual {p1, v0}, Landroid/view/View;->setTranslationY(F)V

    iget-object p1, p0, Landroidx/recyclerview/widget/wA$lgHUyS;->ZfxDd:Landroidx/recyclerview/widget/wA;

    iget-object v0, p0, Landroidx/recyclerview/widget/wA$lgHUyS;->mjFkc:Landroidx/recyclerview/widget/wA$qdMbNW;

    iget-object v0, v0, Landroidx/recyclerview/widget/wA$qdMbNW;->AZxh:Landroidx/recyclerview/widget/RecyclerView$mByQ;

    const/4 v1, 0x0

    invoke-virtual {p1, v0, v1}, Landroidx/recyclerview/widget/MiMN;->lB(Landroidx/recyclerview/widget/RecyclerView$mByQ;Z)V

    iget-object p1, p0, Landroidx/recyclerview/widget/wA$lgHUyS;->ZfxDd:Landroidx/recyclerview/widget/wA;

    iget-object p1, p1, Landroidx/recyclerview/widget/wA;->IEE:Ljava/util/ArrayList;

    iget-object v0, p0, Landroidx/recyclerview/widget/wA$lgHUyS;->mjFkc:Landroidx/recyclerview/widget/wA$qdMbNW;

    iget-object v0, v0, Landroidx/recyclerview/widget/wA$qdMbNW;->AZxh:Landroidx/recyclerview/widget/RecyclerView$mByQ;

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    iget-object p0, p0, Landroidx/recyclerview/widget/wA$lgHUyS;->ZfxDd:Landroidx/recyclerview/widget/wA;

    invoke-virtual {p0}, Landroidx/recyclerview/widget/wA;->uHVRx()V

    return-void
.end method

.method public onAnimationStart(Landroid/animation/Animator;)V
    .locals 1

    iget-object p1, p0, Landroidx/recyclerview/widget/wA$lgHUyS;->ZfxDd:Landroidx/recyclerview/widget/wA;

    iget-object p0, p0, Landroidx/recyclerview/widget/wA$lgHUyS;->mjFkc:Landroidx/recyclerview/widget/wA$qdMbNW;

    iget-object p0, p0, Landroidx/recyclerview/widget/wA$qdMbNW;->AZxh:Landroidx/recyclerview/widget/RecyclerView$mByQ;

    const/4 v0, 0x0

    invoke-virtual {p1, p0, v0}, Landroidx/recyclerview/widget/MiMN;->wJVbdd(Landroidx/recyclerview/widget/RecyclerView$mByQ;Z)V

    return-void
.end method
