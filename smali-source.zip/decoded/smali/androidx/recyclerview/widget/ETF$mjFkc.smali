.class public Landroidx/recyclerview/widget/ETF$mjFkc;
.super Lo/MiMN;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/recyclerview/widget/ETF;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "mjFkc"
.end annotation


# instance fields
.field public KLFTb:Ljava/util/Map;

.field public final ZfxDd:Landroidx/recyclerview/widget/ETF;


# direct methods
.method public constructor <init>(Landroidx/recyclerview/widget/ETF;)V
    .locals 1

    invoke-direct {p0}, Lo/MiMN;-><init>()V

    new-instance v0, Ljava/util/WeakHashMap;

    invoke-direct {v0}, Ljava/util/WeakHashMap;-><init>()V

    iput-object v0, p0, Landroidx/recyclerview/widget/ETF$mjFkc;->KLFTb:Ljava/util/Map;

    iput-object p1, p0, Landroidx/recyclerview/widget/ETF$mjFkc;->ZfxDd:Landroidx/recyclerview/widget/ETF;

    return-void
.end method


# virtual methods
.method public AZxh(Landroid/view/View;)Lo/huTpC;
    .locals 1

    iget-object v0, p0, Landroidx/recyclerview/widget/ETF$mjFkc;->KLFTb:Ljava/util/Map;

    invoke-interface {v0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lo/MiMN;

    if-eqz v0, :cond_0

    invoke-virtual {v0, p1}, Lo/MiMN;->AZxh(Landroid/view/View;)Lo/huTpC;

    move-result-object p0

    return-object p0

    :cond_0
    invoke-super {p0, p1}, Lo/MiMN;->AZxh(Landroid/view/View;)Lo/huTpC;

    move-result-object p0

    return-object p0
.end method

.method public Dt(Landroid/view/View;ILandroid/os/Bundle;)Z
    .locals 2

    iget-object v0, p0, Landroidx/recyclerview/widget/ETF$mjFkc;->ZfxDd:Landroidx/recyclerview/widget/ETF;

    invoke-virtual {v0}, Landroidx/recyclerview/widget/ETF;->rkYL()Z

    move-result v0

    if-nez v0, :cond_2

    iget-object v0, p0, Landroidx/recyclerview/widget/ETF$mjFkc;->ZfxDd:Landroidx/recyclerview/widget/ETF;

    iget-object v0, v0, Landroidx/recyclerview/widget/ETF;->ZfxDd:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {v0}, Landroidx/recyclerview/widget/RecyclerView;->getLayoutManager()Landroidx/recyclerview/widget/RecyclerView$qGY;

    move-result-object v0

    if-eqz v0, :cond_2

    iget-object v0, p0, Landroidx/recyclerview/widget/ETF$mjFkc;->KLFTb:Ljava/util/Map;

    invoke-interface {v0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lo/MiMN;

    const/4 v1, 0x1

    if-eqz v0, :cond_0

    invoke-virtual {v0, p1, p2, p3}, Lo/MiMN;->Dt(Landroid/view/View;ILandroid/os/Bundle;)Z

    move-result v0

    if-eqz v0, :cond_1

    return v1

    :cond_0
    invoke-super {p0, p1, p2, p3}, Lo/MiMN;->Dt(Landroid/view/View;ILandroid/os/Bundle;)Z

    move-result v0

    if-eqz v0, :cond_1

    return v1

    :cond_1
    iget-object p0, p0, Landroidx/recyclerview/widget/ETF$mjFkc;->ZfxDd:Landroidx/recyclerview/widget/ETF;

    iget-object p0, p0, Landroidx/recyclerview/widget/ETF;->ZfxDd:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView;->getLayoutManager()Landroidx/recyclerview/widget/RecyclerView$qGY;

    move-result-object p0

    invoke-virtual {p0, p1, p2, p3}, Landroidx/recyclerview/widget/RecyclerView$qGY;->knzZ(Landroid/view/View;ILandroid/os/Bundle;)Z

    move-result p0

    return p0

    :cond_2
    invoke-super {p0, p1, p2, p3}, Lo/MiMN;->Dt(Landroid/view/View;ILandroid/os/Bundle;)Z

    move-result p0

    return p0
.end method

.method public JHa(Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)V
    .locals 1

    iget-object v0, p0, Landroidx/recyclerview/widget/ETF$mjFkc;->KLFTb:Ljava/util/Map;

    invoke-interface {v0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lo/MiMN;

    if-eqz v0, :cond_0

    invoke-virtual {v0, p1, p2}, Lo/MiMN;->JHa(Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)V

    goto :goto_0

    :cond_0
    invoke-super {p0, p1, p2}, Lo/MiMN;->JHa(Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)V

    :goto_0
    return-void
.end method

.method public MiMN(Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)V
    .locals 1

    iget-object v0, p0, Landroidx/recyclerview/widget/ETF$mjFkc;->KLFTb:Ljava/util/Map;

    invoke-interface {v0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lo/MiMN;

    if-eqz v0, :cond_0

    invoke-virtual {v0, p1, p2}, Lo/MiMN;->MiMN(Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)V

    goto :goto_0

    :cond_0
    invoke-super {p0, p1, p2}, Lo/MiMN;->MiMN(Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)V

    :goto_0
    return-void
.end method

.method public VA(Landroid/view/View;I)V
    .locals 1

    iget-object v0, p0, Landroidx/recyclerview/widget/ETF$mjFkc;->KLFTb:Ljava/util/Map;

    invoke-interface {v0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lo/MiMN;

    if-eqz v0, :cond_0

    invoke-virtual {v0, p1, p2}, Lo/MiMN;->VA(Landroid/view/View;I)V

    goto :goto_0

    :cond_0
    invoke-super {p0, p1, p2}, Lo/MiMN;->VA(Landroid/view/View;I)V

    :goto_0
    return-void
.end method

.method public YoKzxo(Landroid/view/View;)Lo/MiMN;
    .locals 0

    iget-object p0, p0, Landroidx/recyclerview/widget/ETF$mjFkc;->KLFTb:Ljava/util/Map;

    invoke-interface {p0, p1}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lo/MiMN;

    return-object p0
.end method

.method public lgHUyS(Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)V
    .locals 1

    iget-object v0, p0, Landroidx/recyclerview/widget/ETF$mjFkc;->KLFTb:Ljava/util/Map;

    invoke-interface {v0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lo/MiMN;

    if-eqz v0, :cond_0

    invoke-virtual {v0, p1, p2}, Lo/MiMN;->lgHUyS(Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)V

    goto :goto_0

    :cond_0
    invoke-super {p0, p1, p2}, Lo/MiMN;->lgHUyS(Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)V

    :goto_0
    return-void
.end method

.method public mjFkc(Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)Z
    .locals 1

    iget-object v0, p0, Landroidx/recyclerview/widget/ETF$mjFkc;->KLFTb:Ljava/util/Map;

    invoke-interface {v0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lo/MiMN;

    if-eqz v0, :cond_0

    invoke-virtual {v0, p1, p2}, Lo/MiMN;->mjFkc(Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)Z

    move-result p0

    return p0

    :cond_0
    invoke-super {p0, p1, p2}, Lo/MiMN;->mjFkc(Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)Z

    move-result p0

    return p0
.end method

.method public qdMbNW(Landroid/view/ViewGroup;Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)Z
    .locals 1

    iget-object v0, p0, Landroidx/recyclerview/widget/ETF$mjFkc;->KLFTb:Ljava/util/Map;

    invoke-interface {v0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lo/MiMN;

    if-eqz v0, :cond_0

    invoke-virtual {v0, p1, p2, p3}, Lo/MiMN;->qdMbNW(Landroid/view/ViewGroup;Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)Z

    move-result p0

    return p0

    :cond_0
    invoke-super {p0, p1, p2, p3}, Lo/MiMN;->qdMbNW(Landroid/view/ViewGroup;Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)Z

    move-result p0

    return p0
.end method

.method public rkYL(Landroid/view/View;)V
    .locals 1

    invoke-static {p1}, Lo/T9;->qdMbNW(Landroid/view/View;)Lo/MiMN;

    move-result-object v0

    if-eqz v0, :cond_0

    if-eq v0, p0, :cond_0

    iget-object p0, p0, Landroidx/recyclerview/widget/ETF$mjFkc;->KLFTb:Ljava/util/Map;

    invoke-interface {p0, p1, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_0
    return-void
.end method

.method public xJ(Landroid/view/View;Lo/Ucbh;)V
    .locals 1

    iget-object v0, p0, Landroidx/recyclerview/widget/ETF$mjFkc;->ZfxDd:Landroidx/recyclerview/widget/ETF;

    invoke-virtual {v0}, Landroidx/recyclerview/widget/ETF;->rkYL()Z

    move-result v0

    if-nez v0, :cond_1

    iget-object v0, p0, Landroidx/recyclerview/widget/ETF$mjFkc;->ZfxDd:Landroidx/recyclerview/widget/ETF;

    iget-object v0, v0, Landroidx/recyclerview/widget/ETF;->ZfxDd:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {v0}, Landroidx/recyclerview/widget/RecyclerView;->getLayoutManager()Landroidx/recyclerview/widget/RecyclerView$qGY;

    move-result-object v0

    if-eqz v0, :cond_1

    iget-object v0, p0, Landroidx/recyclerview/widget/ETF$mjFkc;->ZfxDd:Landroidx/recyclerview/widget/ETF;

    iget-object v0, v0, Landroidx/recyclerview/widget/ETF;->ZfxDd:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {v0}, Landroidx/recyclerview/widget/RecyclerView;->getLayoutManager()Landroidx/recyclerview/widget/RecyclerView$qGY;

    move-result-object v0

    invoke-virtual {v0, p1, p2}, Landroidx/recyclerview/widget/RecyclerView$qGY;->SKTn(Landroid/view/View;Lo/Ucbh;)V

    iget-object v0, p0, Landroidx/recyclerview/widget/ETF$mjFkc;->KLFTb:Ljava/util/Map;

    invoke-interface {v0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lo/MiMN;

    if-eqz v0, :cond_0

    invoke-virtual {v0, p1, p2}, Lo/MiMN;->xJ(Landroid/view/View;Lo/Ucbh;)V

    goto :goto_0

    :cond_0
    invoke-super {p0, p1, p2}, Lo/MiMN;->xJ(Landroid/view/View;Lo/Ucbh;)V

    goto :goto_0

    :cond_1
    invoke-super {p0, p1, p2}, Lo/MiMN;->xJ(Landroid/view/View;Lo/Ucbh;)V

    :goto_0
    return-void
.end method
