.class public Landroidx/recyclerview/widget/ZfxDd$ZfxDd;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/animation/ValueAnimator$AnimatorUpdateListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/recyclerview/widget/ZfxDd;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "ZfxDd"
.end annotation


# instance fields
.field public final synthetic mjFkc:Landroidx/recyclerview/widget/ZfxDd;


# direct methods
.method public constructor <init>(Landroidx/recyclerview/widget/ZfxDd;)V
    .locals 0

    iput-object p1, p0, Landroidx/recyclerview/widget/ZfxDd$ZfxDd;->mjFkc:Landroidx/recyclerview/widget/ZfxDd;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onAnimationUpdate(Landroid/animation/ValueAnimator;)V
    .locals 1

    invoke-virtual {p1}, Landroid/animation/ValueAnimator;->getAnimatedValue()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Float;

    invoke-virtual {p1}, Ljava/lang/Float;->floatValue()F

    move-result p1

    const/high16 v0, 0x437f0000    # 255.0f

    mul-float/2addr p1, v0

    float-to-int p1, p1

    iget-object v0, p0, Landroidx/recyclerview/widget/ZfxDd$ZfxDd;->mjFkc:Landroidx/recyclerview/widget/ZfxDd;

    iget-object v0, v0, Landroidx/recyclerview/widget/ZfxDd;->wA:Landroid/graphics/drawable/StateListDrawable;

    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->setAlpha(I)V

    iget-object v0, p0, Landroidx/recyclerview/widget/ZfxDd$ZfxDd;->mjFkc:Landroidx/recyclerview/widget/ZfxDd;

    iget-object v0, v0, Landroidx/recyclerview/widget/ZfxDd;->ZfxDd:Landroid/graphics/drawable/Drawable;

    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->setAlpha(I)V

    iget-object p0, p0, Landroidx/recyclerview/widget/ZfxDd$ZfxDd;->mjFkc:Landroidx/recyclerview/widget/ZfxDd;

    invoke-virtual {p0}, Landroidx/recyclerview/widget/ZfxDd;->Ucbh()V

    return-void
.end method
