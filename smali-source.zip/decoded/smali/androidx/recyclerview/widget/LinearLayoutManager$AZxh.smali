.class public Landroidx/recyclerview/widget/LinearLayoutManager$AZxh;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/recyclerview/widget/LinearLayoutManager;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "AZxh"
.end annotation


# instance fields
.field public AZxh:Z

.field public ZfxDd:Z

.field public mjFkc:I

.field public wA:Z


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public mjFkc()V
    .locals 1

    const/4 v0, 0x0

    iput v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager$AZxh;->mjFkc:I

    iput-boolean v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager$AZxh;->AZxh:Z

    iput-boolean v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager$AZxh;->wA:Z

    iput-boolean v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager$AZxh;->ZfxDd:Z

    return-void
.end method
