.class public Landroidx/recyclerview/widget/StaggeredGridLayoutManager$KLFTb$mjFkc;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/os/Parcelable$Creator;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/recyclerview/widget/StaggeredGridLayoutManager$KLFTb;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public AZxh(I)[Landroidx/recyclerview/widget/StaggeredGridLayoutManager$KLFTb;
    .locals 0

    new-array p0, p1, [Landroidx/recyclerview/widget/StaggeredGridLayoutManager$KLFTb;

    return-object p0
.end method

.method public bridge synthetic createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;
    .locals 0

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$KLFTb$mjFkc;->mjFkc(Landroid/os/Parcel;)Landroidx/recyclerview/widget/StaggeredGridLayoutManager$KLFTb;

    move-result-object p0

    return-object p0
.end method

.method public mjFkc(Landroid/os/Parcel;)Landroidx/recyclerview/widget/StaggeredGridLayoutManager$KLFTb;
    .locals 0

    new-instance p0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$KLFTb;

    invoke-direct {p0, p1}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$KLFTb;-><init>(Landroid/os/Parcel;)V

    return-object p0
.end method

.method public bridge synthetic newArray(I)[Ljava/lang/Object;
    .locals 0

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager$KLFTb$mjFkc;->AZxh(I)[Landroidx/recyclerview/widget/StaggeredGridLayoutManager$KLFTb;

    move-result-object p0

    return-object p0
.end method
