.class public Landroidx/recyclerview/widget/wA$JHa;
.super Landroid/animation/AnimatorListenerAdapter;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Landroidx/recyclerview/widget/wA;->WrLQs(Landroidx/recyclerview/widget/RecyclerView$mByQ;IIII)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic AZxh:I

.field public final synthetic JHa:Landroidx/recyclerview/widget/wA;

.field public final synthetic KLFTb:Landroid/view/ViewPropertyAnimator;

.field public final synthetic ZfxDd:I

.field public final synthetic mjFkc:Landroidx/recyclerview/widget/RecyclerView$mByQ;

.field public final synthetic wA:Landroid/view/View;


# direct methods
.method public constructor <init>(Landroidx/recyclerview/widget/wA;Landroidx/recyclerview/widget/RecyclerView$mByQ;ILandroid/view/View;ILandroid/view/ViewPropertyAnimator;)V
    .locals 0

    iput-object p1, p0, Landroidx/recyclerview/widget/wA$JHa;->JHa:Landroidx/recyclerview/widget/wA;

    iput-object p2, p0, Landroidx/recyclerview/widget/wA$JHa;->mjFkc:Landroidx/recyclerview/widget/RecyclerView$mByQ;

    iput p3, p0, Landroidx/recyclerview/widget/wA$JHa;->AZxh:I

    iput-object p4, p0, Landroidx/recyclerview/widget/wA$JHa;->wA:Landroid/view/View;

    iput p5, p0, Landroidx/recyclerview/widget/wA$JHa;->ZfxDd:I

    iput-object p6, p0, Landroidx/recyclerview/widget/wA$JHa;->KLFTb:Landroid/view/ViewPropertyAnimator;

    invoke-direct {p0}, Landroid/animation/AnimatorListenerAdapter;-><init>()V

    return-void
.end method


# virtual methods
.method public onAnimationCancel(Landroid/animation/Animator;)V
    .locals 1

    iget p1, p0, Landroidx/recyclerview/widget/wA$JHa;->AZxh:I

    const/4 v0, 0x0

    if-eqz p1, :cond_0

    iget-object p1, p0, Landroidx/recyclerview/widget/wA$JHa;->wA:Landroid/view/View;

    invoke-virtual {p1, v0}, Landroid/view/View;->setTranslationX(F)V

    :cond_0
    iget p1, p0, Landroidx/recyclerview/widget/wA$JHa;->ZfxDd:I

    if-eqz p1, :cond_1

    iget-object p0, p0, Landroidx/recyclerview/widget/wA$JHa;->wA:Landroid/view/View;

    invoke-virtual {p0, v0}, Landroid/view/View;->setTranslationY(F)V

    :cond_1
    return-void
.end method

.method public onAnimationEnd(Landroid/animation/Animator;)V
    .locals 1

    iget-object p1, p0, Landroidx/recyclerview/widget/wA$JHa;->KLFTb:Landroid/view/ViewPropertyAnimator;

    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Landroid/view/ViewPropertyAnimator;->setListener(Landroid/animation/Animator$AnimatorListener;)Landroid/view/ViewPropertyAnimator;

    iget-object p1, p0, Landroidx/recyclerview/widget/wA$JHa;->JHa:Landroidx/recyclerview/widget/wA;

    iget-object v0, p0, Landroidx/recyclerview/widget/wA$JHa;->mjFkc:Landroidx/recyclerview/widget/RecyclerView$mByQ;

    invoke-virtual {p1, v0}, Landroidx/recyclerview/widget/MiMN;->mByQ(Landroidx/recyclerview/widget/RecyclerView$mByQ;)V

    iget-object p1, p0, Landroidx/recyclerview/widget/wA$JHa;->JHa:Landroidx/recyclerview/widget/wA;

    iget-object p1, p1, Landroidx/recyclerview/widget/wA;->qGY:Ljava/util/ArrayList;

    iget-object v0, p0, Landroidx/recyclerview/widget/wA$JHa;->mjFkc:Landroidx/recyclerview/widget/RecyclerView$mByQ;

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    iget-object p0, p0, Landroidx/recyclerview/widget/wA$JHa;->JHa:Landroidx/recyclerview/widget/wA;

    invoke-virtual {p0}, Landroidx/recyclerview/widget/wA;->uHVRx()V

    return-void
.end method

.method public onAnimationStart(Landroid/animation/Animator;)V
    .locals 0

    iget-object p1, p0, Landroidx/recyclerview/widget/wA$JHa;->JHa:Landroidx/recyclerview/widget/wA;

    iget-object p0, p0, Landroidx/recyclerview/widget/wA$JHa;->mjFkc:Landroidx/recyclerview/widget/RecyclerView$mByQ;

    invoke-virtual {p1, p0}, Landroidx/recyclerview/widget/MiMN;->OjSQV(Landroidx/recyclerview/widget/RecyclerView$mByQ;)V

    return-void
.end method
