.class public Landroidx/recyclerview/widget/Dt$mjFkc;
.super Landroidx/recyclerview/widget/xJ;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Landroidx/recyclerview/widget/Dt;->ZfxDd(Landroidx/recyclerview/widget/RecyclerView$qGY;)Landroidx/recyclerview/widget/RecyclerView$vI;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic fehf:Landroidx/recyclerview/widget/Dt;


# direct methods
.method public constructor <init>(Landroidx/recyclerview/widget/Dt;Landroid/content/Context;)V
    .locals 0

    iput-object p1, p0, Landroidx/recyclerview/widget/Dt$mjFkc;->fehf:Landroidx/recyclerview/widget/Dt;

    invoke-direct {p0, p2}, Landroidx/recyclerview/widget/xJ;-><init>(Landroid/content/Context;)V

    return-void
.end method


# virtual methods
.method public Gd(I)I
    .locals 1

    const/16 v0, 0x64

    invoke-super {p0, p1}, Landroidx/recyclerview/widget/xJ;->Gd(I)I

    move-result p0

    invoke-static {v0, p0}, Ljava/lang/Math;->min(II)I

    move-result p0

    return p0
.end method

.method public Ucbh(Landroid/util/DisplayMetrics;)F
    .locals 0

    iget p0, p1, Landroid/util/DisplayMetrics;->densityDpi:I

    int-to-float p0, p0

    const/high16 p1, 0x42c80000    # 100.0f

    div-float/2addr p1, p0

    return p1
.end method

.method public rkYL(Landroid/view/View;Landroidx/recyclerview/widget/RecyclerView$VocHEe;Landroidx/recyclerview/widget/RecyclerView$vI$mjFkc;)V
    .locals 2

    iget-object p2, p0, Landroidx/recyclerview/widget/Dt$mjFkc;->fehf:Landroidx/recyclerview/widget/Dt;

    iget-object v0, p2, Landroidx/recyclerview/widget/YoKzxo;->mjFkc:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {v0}, Landroidx/recyclerview/widget/RecyclerView;->getLayoutManager()Landroidx/recyclerview/widget/RecyclerView$qGY;

    move-result-object v0

    invoke-virtual {p2, v0, p1}, Landroidx/recyclerview/widget/Dt;->wA(Landroidx/recyclerview/widget/RecyclerView$qGY;Landroid/view/View;)[I

    move-result-object p1

    const/4 p2, 0x0

    aget p2, p1, p2

    const/4 v0, 0x1

    aget p1, p1, v0

    invoke-static {p2}, Ljava/lang/Math;->abs(I)I

    move-result v0

    invoke-static {p1}, Ljava/lang/Math;->abs(I)I

    move-result v1

    invoke-static {v0, v1}, Ljava/lang/Math;->max(II)I

    move-result v0

    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/xJ;->huTpC(I)I

    move-result v0

    if-lez v0, :cond_0

    iget-object p0, p0, Landroidx/recyclerview/widget/xJ;->Dt:Landroid/view/animation/DecelerateInterpolator;

    invoke-virtual {p3, p2, p1, v0, p0}, Landroidx/recyclerview/widget/RecyclerView$vI$mjFkc;->ZfxDd(IIILandroid/view/animation/Interpolator;)V

    :cond_0
    return-void
.end method
