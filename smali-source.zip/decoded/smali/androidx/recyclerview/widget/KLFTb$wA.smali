.class public Landroidx/recyclerview/widget/KLFTb$wA;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/recyclerview/widget/KLFTb;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "wA"
.end annotation


# instance fields
.field public AZxh:I

.field public KLFTb:I

.field public ZfxDd:Landroidx/recyclerview/widget/RecyclerView;

.field public mjFkc:Z

.field public wA:I


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public mjFkc()V
    .locals 2

    const/4 v0, 0x0

    iput-boolean v0, p0, Landroidx/recyclerview/widget/KLFTb$wA;->mjFkc:Z

    iput v0, p0, Landroidx/recyclerview/widget/KLFTb$wA;->AZxh:I

    iput v0, p0, Landroidx/recyclerview/widget/KLFTb$wA;->wA:I

    const/4 v1, 0x0

    iput-object v1, p0, Landroidx/recyclerview/widget/KLFTb$wA;->ZfxDd:Landroidx/recyclerview/widget/RecyclerView;

    iput v0, p0, Landroidx/recyclerview/widget/KLFTb$wA;->KLFTb:I

    return-void
.end method
