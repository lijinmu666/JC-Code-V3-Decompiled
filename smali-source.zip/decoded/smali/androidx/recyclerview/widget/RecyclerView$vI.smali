.class public abstract Landroidx/recyclerview/widget/RecyclerView$vI;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/recyclerview/widget/RecyclerView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "vI"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/recyclerview/widget/RecyclerView$vI$AZxh;,
        Landroidx/recyclerview/widget/RecyclerView$vI$mjFkc;
    }
.end annotation


# instance fields
.field public AZxh:Landroidx/recyclerview/widget/RecyclerView;

.field public JHa:Landroid/view/View;

.field public KLFTb:Z

.field public ZfxDd:Z

.field public lgHUyS:Z

.field public mjFkc:I

.field public wA:Landroidx/recyclerview/widget/RecyclerView$qGY;

.field public final xJ:Landroidx/recyclerview/widget/RecyclerView$vI$mjFkc;


# direct methods
.method public constructor <init>()V
    .locals 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, -0x1

    iput v0, p0, Landroidx/recyclerview/widget/RecyclerView$vI;->mjFkc:I

    new-instance v0, Landroidx/recyclerview/widget/RecyclerView$vI$mjFkc;

    const/4 v1, 0x0

    invoke-direct {v0, v1, v1}, Landroidx/recyclerview/widget/RecyclerView$vI$mjFkc;-><init>(II)V

    iput-object v0, p0, Landroidx/recyclerview/widget/RecyclerView$vI;->xJ:Landroidx/recyclerview/widget/RecyclerView$vI$mjFkc;

    return-void
.end method


# virtual methods
.method public AZxh(I)Landroid/view/View;
    .locals 0

    iget-object p0, p0, Landroidx/recyclerview/widget/RecyclerView$vI;->AZxh:Landroidx/recyclerview/widget/RecyclerView;

    iget-object p0, p0, Landroidx/recyclerview/widget/RecyclerView;->YoKzxo:Landroidx/recyclerview/widget/RecyclerView$qGY;

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/RecyclerView$qGY;->wJVbdd(I)Landroid/view/View;

    move-result-object p0

    return-object p0
.end method

.method public Dt(II)V
    .locals 6

    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView$vI;->AZxh:Landroidx/recyclerview/widget/RecyclerView;

    iget v1, p0, Landroidx/recyclerview/widget/RecyclerView$vI;->mjFkc:I

    const/4 v2, -0x1

    if-eq v1, v2, :cond_0

    if-nez v0, :cond_1

    :cond_0
    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$vI;->IEE()V

    :cond_1
    iget-boolean v1, p0, Landroidx/recyclerview/widget/RecyclerView$vI;->ZfxDd:Z

    const/4 v2, 0x0

    if-eqz v1, :cond_3

    iget-object v1, p0, Landroidx/recyclerview/widget/RecyclerView$vI;->JHa:Landroid/view/View;

    if-nez v1, :cond_3

    iget-object v1, p0, Landroidx/recyclerview/widget/RecyclerView$vI;->wA:Landroidx/recyclerview/widget/RecyclerView$qGY;

    if-eqz v1, :cond_3

    iget v1, p0, Landroidx/recyclerview/widget/RecyclerView$vI;->mjFkc:I

    invoke-virtual {p0, v1}, Landroidx/recyclerview/widget/RecyclerView$vI;->mjFkc(I)Landroid/graphics/PointF;

    move-result-object v1

    if-eqz v1, :cond_3

    iget v3, v1, Landroid/graphics/PointF;->x:F

    const/4 v4, 0x0

    cmpl-float v5, v3, v4

    if-nez v5, :cond_2

    iget v5, v1, Landroid/graphics/PointF;->y:F

    cmpl-float v4, v5, v4

    if-eqz v4, :cond_3

    :cond_2
    invoke-static {v3}, Ljava/lang/Math;->signum(F)F

    move-result v3

    float-to-int v3, v3

    iget v1, v1, Landroid/graphics/PointF;->y:F

    invoke-static {v1}, Ljava/lang/Math;->signum(F)F

    move-result v1

    float-to-int v1, v1

    invoke-virtual {v0, v3, v1, v2}, Landroidx/recyclerview/widget/RecyclerView;->sqndV(II[I)V

    :cond_3
    const/4 v1, 0x0

    iput-boolean v1, p0, Landroidx/recyclerview/widget/RecyclerView$vI;->ZfxDd:Z

    iget-object v1, p0, Landroidx/recyclerview/widget/RecyclerView$vI;->JHa:Landroid/view/View;

    if-eqz v1, :cond_5

    invoke-virtual {p0, v1}, Landroidx/recyclerview/widget/RecyclerView$vI;->ZfxDd(Landroid/view/View;)I

    move-result v1

    iget v3, p0, Landroidx/recyclerview/widget/RecyclerView$vI;->mjFkc:I

    if-ne v1, v3, :cond_4

    iget-object v1, p0, Landroidx/recyclerview/widget/RecyclerView$vI;->JHa:Landroid/view/View;

    iget-object v2, v0, Landroidx/recyclerview/widget/RecyclerView;->Vdz:Landroidx/recyclerview/widget/RecyclerView$VocHEe;

    iget-object v3, p0, Landroidx/recyclerview/widget/RecyclerView$vI;->xJ:Landroidx/recyclerview/widget/RecyclerView$vI$mjFkc;

    invoke-virtual {p0, v1, v2, v3}, Landroidx/recyclerview/widget/RecyclerView$vI;->rkYL(Landroid/view/View;Landroidx/recyclerview/widget/RecyclerView$VocHEe;Landroidx/recyclerview/widget/RecyclerView$vI$mjFkc;)V

    iget-object v1, p0, Landroidx/recyclerview/widget/RecyclerView$vI;->xJ:Landroidx/recyclerview/widget/RecyclerView$vI$mjFkc;

    invoke-virtual {v1, v0}, Landroidx/recyclerview/widget/RecyclerView$vI$mjFkc;->wA(Landroidx/recyclerview/widget/RecyclerView;)V

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$vI;->IEE()V

    goto :goto_0

    :cond_4
    const-string v1, "RecyclerView"

    const-string v3, "Passed over target position while smooth scrolling."

    invoke-static {v1, v3}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    iput-object v2, p0, Landroidx/recyclerview/widget/RecyclerView$vI;->JHa:Landroid/view/View;

    :cond_5
    :goto_0
    iget-boolean v1, p0, Landroidx/recyclerview/widget/RecyclerView$vI;->KLFTb:Z

    if-eqz v1, :cond_6

    iget-object v1, v0, Landroidx/recyclerview/widget/RecyclerView;->Vdz:Landroidx/recyclerview/widget/RecyclerView$VocHEe;

    iget-object v2, p0, Landroidx/recyclerview/widget/RecyclerView$vI;->xJ:Landroidx/recyclerview/widget/RecyclerView$vI$mjFkc;

    invoke-virtual {p0, p1, p2, v1, v2}, Landroidx/recyclerview/widget/RecyclerView$vI;->VA(IILandroidx/recyclerview/widget/RecyclerView$VocHEe;Landroidx/recyclerview/widget/RecyclerView$vI$mjFkc;)V

    iget-object p1, p0, Landroidx/recyclerview/widget/RecyclerView$vI;->xJ:Landroidx/recyclerview/widget/RecyclerView$vI$mjFkc;

    invoke-virtual {p1}, Landroidx/recyclerview/widget/RecyclerView$vI$mjFkc;->mjFkc()Z

    move-result p1

    iget-object p2, p0, Landroidx/recyclerview/widget/RecyclerView$vI;->xJ:Landroidx/recyclerview/widget/RecyclerView$vI$mjFkc;

    invoke-virtual {p2, v0}, Landroidx/recyclerview/widget/RecyclerView$vI$mjFkc;->wA(Landroidx/recyclerview/widget/RecyclerView;)V

    if-eqz p1, :cond_6

    iget-boolean p1, p0, Landroidx/recyclerview/widget/RecyclerView$vI;->KLFTb:Z

    if-eqz p1, :cond_6

    const/4 p1, 0x1

    iput-boolean p1, p0, Landroidx/recyclerview/widget/RecyclerView$vI;->ZfxDd:Z

    iget-object p0, v0, Landroidx/recyclerview/widget/RecyclerView;->bbzow:Landroidx/recyclerview/widget/RecyclerView$wJVbdd;

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$wJVbdd;->ZfxDd()V

    :cond_6
    return-void
.end method

.method public ETF(Landroid/view/View;)V
    .locals 2

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/RecyclerView$vI;->ZfxDd(Landroid/view/View;)I

    move-result v0

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$vI;->JHa()I

    move-result v1

    if-ne v0, v1, :cond_0

    iput-object p1, p0, Landroidx/recyclerview/widget/RecyclerView$vI;->JHa:Landroid/view/View;

    sget-boolean p0, Landroidx/recyclerview/widget/RecyclerView;->LREOK:Z

    if-eqz p0, :cond_0

    const-string p0, "RecyclerView"

    const-string p1, "smooth scroll target view has been attached"

    invoke-static {p0, p1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    :cond_0
    return-void
.end method

.method public final IEE()V
    .locals 3

    iget-boolean v0, p0, Landroidx/recyclerview/widget/RecyclerView$vI;->KLFTb:Z

    if-nez v0, :cond_0

    return-void

    :cond_0
    const/4 v0, 0x0

    iput-boolean v0, p0, Landroidx/recyclerview/widget/RecyclerView$vI;->KLFTb:Z

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$vI;->YoKzxo()V

    iget-object v1, p0, Landroidx/recyclerview/widget/RecyclerView$vI;->AZxh:Landroidx/recyclerview/widget/RecyclerView;

    iget-object v1, v1, Landroidx/recyclerview/widget/RecyclerView;->Vdz:Landroidx/recyclerview/widget/RecyclerView$VocHEe;

    const/4 v2, -0x1

    iput v2, v1, Landroidx/recyclerview/widget/RecyclerView$VocHEe;->mjFkc:I

    const/4 v1, 0x0

    iput-object v1, p0, Landroidx/recyclerview/widget/RecyclerView$vI;->JHa:Landroid/view/View;

    iput v2, p0, Landroidx/recyclerview/widget/RecyclerView$vI;->mjFkc:I

    iput-boolean v0, p0, Landroidx/recyclerview/widget/RecyclerView$vI;->ZfxDd:Z

    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView$vI;->wA:Landroidx/recyclerview/widget/RecyclerView$qGY;

    invoke-virtual {v0, p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->Jidt(Landroidx/recyclerview/widget/RecyclerView$vI;)V

    iput-object v1, p0, Landroidx/recyclerview/widget/RecyclerView$vI;->wA:Landroidx/recyclerview/widget/RecyclerView$qGY;

    iput-object v1, p0, Landroidx/recyclerview/widget/RecyclerView$vI;->AZxh:Landroidx/recyclerview/widget/RecyclerView;

    return-void
.end method

.method public JHa()I
    .locals 0

    iget p0, p0, Landroidx/recyclerview/widget/RecyclerView$vI;->mjFkc:I

    return p0
.end method

.method public KLFTb()Landroidx/recyclerview/widget/RecyclerView$qGY;
    .locals 0

    iget-object p0, p0, Landroidx/recyclerview/widget/RecyclerView$vI;->wA:Landroidx/recyclerview/widget/RecyclerView$qGY;

    return-object p0
.end method

.method public abstract MiMN()V
.end method

.method public abstract VA(IILandroidx/recyclerview/widget/RecyclerView$VocHEe;Landroidx/recyclerview/widget/RecyclerView$vI$mjFkc;)V
.end method

.method public abstract YoKzxo()V
.end method

.method public ZfxDd(Landroid/view/View;)I
    .locals 0

    iget-object p0, p0, Landroidx/recyclerview/widget/RecyclerView$vI;->AZxh:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/RecyclerView;->ANMGZc(Landroid/view/View;)I

    move-result p0

    return p0
.end method

.method public fehf(Landroidx/recyclerview/widget/RecyclerView;Landroidx/recyclerview/widget/RecyclerView$qGY;)V
    .locals 2

    iget-object v0, p1, Landroidx/recyclerview/widget/RecyclerView;->bbzow:Landroidx/recyclerview/widget/RecyclerView$wJVbdd;

    invoke-virtual {v0}, Landroidx/recyclerview/widget/RecyclerView$wJVbdd;->JHa()V

    iget-boolean v0, p0, Landroidx/recyclerview/widget/RecyclerView$vI;->lgHUyS:Z

    if-eqz v0, :cond_0

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "An instance of "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, " was started more than once. Each instance of"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, " is intended to only be used once. You should create a new instance for each use."

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "RecyclerView"

    invoke-static {v1, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    :cond_0
    iput-object p1, p0, Landroidx/recyclerview/widget/RecyclerView$vI;->AZxh:Landroidx/recyclerview/widget/RecyclerView;

    iput-object p2, p0, Landroidx/recyclerview/widget/RecyclerView$vI;->wA:Landroidx/recyclerview/widget/RecyclerView$qGY;

    iget p2, p0, Landroidx/recyclerview/widget/RecyclerView$vI;->mjFkc:I

    const/4 v0, -0x1

    if-eq p2, v0, :cond_1

    iget-object p1, p1, Landroidx/recyclerview/widget/RecyclerView;->Vdz:Landroidx/recyclerview/widget/RecyclerView$VocHEe;

    iput p2, p1, Landroidx/recyclerview/widget/RecyclerView$VocHEe;->mjFkc:I

    const/4 p1, 0x1

    iput-boolean p1, p0, Landroidx/recyclerview/widget/RecyclerView$vI;->KLFTb:Z

    iput-boolean p1, p0, Landroidx/recyclerview/widget/RecyclerView$vI;->ZfxDd:Z

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$vI;->JHa()I

    move-result p2

    invoke-virtual {p0, p2}, Landroidx/recyclerview/widget/RecyclerView$vI;->AZxh(I)Landroid/view/View;

    move-result-object p2

    iput-object p2, p0, Landroidx/recyclerview/widget/RecyclerView$vI;->JHa:Landroid/view/View;

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$vI;->MiMN()V

    iget-object p2, p0, Landroidx/recyclerview/widget/RecyclerView$vI;->AZxh:Landroidx/recyclerview/widget/RecyclerView;

    iget-object p2, p2, Landroidx/recyclerview/widget/RecyclerView;->bbzow:Landroidx/recyclerview/widget/RecyclerView$wJVbdd;

    invoke-virtual {p2}, Landroidx/recyclerview/widget/RecyclerView$wJVbdd;->ZfxDd()V

    iput-boolean p1, p0, Landroidx/recyclerview/widget/RecyclerView$vI;->lgHUyS:Z

    return-void

    :cond_1
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string p1, "Invalid target position"

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public lgHUyS()Z
    .locals 0

    iget-boolean p0, p0, Landroidx/recyclerview/widget/RecyclerView$vI;->KLFTb:Z

    return p0
.end method

.method public mjFkc(I)Landroid/graphics/PointF;
    .locals 1

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$vI;->KLFTb()Landroidx/recyclerview/widget/RecyclerView$qGY;

    move-result-object p0

    instance-of v0, p0, Landroidx/recyclerview/widget/RecyclerView$vI$AZxh;

    if-eqz v0, :cond_0

    check-cast p0, Landroidx/recyclerview/widget/RecyclerView$vI$AZxh;

    invoke-interface {p0, p1}, Landroidx/recyclerview/widget/RecyclerView$vI$AZxh;->AZxh(I)Landroid/graphics/PointF;

    move-result-object p0

    return-object p0

    :cond_0
    new-instance p0, Ljava/lang/StringBuilder;

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    const-string p1, "You should override computeScrollVectorForPosition when the LayoutManager does not implement "

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-class p1, Landroidx/recyclerview/widget/RecyclerView$vI$AZxh;

    invoke-virtual {p1}, Ljava/lang/Class;->getCanonicalName()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const-string p1, "RecyclerView"

    invoke-static {p1, p0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    const/4 p0, 0x0

    return-object p0
.end method

.method public qGY(I)V
    .locals 0

    iput p1, p0, Landroidx/recyclerview/widget/RecyclerView$vI;->mjFkc:I

    return-void
.end method

.method public qdMbNW(Landroid/graphics/PointF;)V
    .locals 2

    iget p0, p1, Landroid/graphics/PointF;->x:F

    mul-float/2addr p0, p0

    iget v0, p1, Landroid/graphics/PointF;->y:F

    mul-float/2addr v0, v0

    add-float/2addr p0, v0

    float-to-double v0, p0

    invoke-static {v0, v1}, Ljava/lang/Math;->sqrt(D)D

    move-result-wide v0

    double-to-float p0, v0

    iget v0, p1, Landroid/graphics/PointF;->x:F

    div-float/2addr v0, p0

    iput v0, p1, Landroid/graphics/PointF;->x:F

    iget v0, p1, Landroid/graphics/PointF;->y:F

    div-float/2addr v0, p0

    iput v0, p1, Landroid/graphics/PointF;->y:F

    return-void
.end method

.method public abstract rkYL(Landroid/view/View;Landroidx/recyclerview/widget/RecyclerView$VocHEe;Landroidx/recyclerview/widget/RecyclerView$vI$mjFkc;)V
.end method

.method public wA()I
    .locals 0

    iget-object p0, p0, Landroidx/recyclerview/widget/RecyclerView$vI;->AZxh:Landroidx/recyclerview/widget/RecyclerView;

    iget-object p0, p0, Landroidx/recyclerview/widget/RecyclerView;->YoKzxo:Landroidx/recyclerview/widget/RecyclerView$qGY;

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->zvd()I

    move-result p0

    return p0
.end method

.method public xJ()Z
    .locals 0

    iget-boolean p0, p0, Landroidx/recyclerview/widget/RecyclerView$vI;->ZfxDd:Z

    return p0
.end method
