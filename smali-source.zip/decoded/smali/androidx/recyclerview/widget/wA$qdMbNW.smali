.class public Landroidx/recyclerview/widget/wA$qdMbNW;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/recyclerview/widget/wA;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "qdMbNW"
.end annotation


# instance fields
.field public AZxh:Landroidx/recyclerview/widget/RecyclerView$mByQ;

.field public JHa:I

.field public KLFTb:I

.field public ZfxDd:I

.field public mjFkc:Landroidx/recyclerview/widget/RecyclerView$mByQ;

.field public wA:I


# direct methods
.method public constructor <init>(Landroidx/recyclerview/widget/RecyclerView$mByQ;Landroidx/recyclerview/widget/RecyclerView$mByQ;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    iput-object p1, p0, Landroidx/recyclerview/widget/wA$qdMbNW;->mjFkc:Landroidx/recyclerview/widget/RecyclerView$mByQ;

    .line 3
    iput-object p2, p0, Landroidx/recyclerview/widget/wA$qdMbNW;->AZxh:Landroidx/recyclerview/widget/RecyclerView$mByQ;

    return-void
.end method

.method public constructor <init>(Landroidx/recyclerview/widget/RecyclerView$mByQ;Landroidx/recyclerview/widget/RecyclerView$mByQ;IIII)V
    .locals 0

    .line 4
    invoke-direct {p0, p1, p2}, Landroidx/recyclerview/widget/wA$qdMbNW;-><init>(Landroidx/recyclerview/widget/RecyclerView$mByQ;Landroidx/recyclerview/widget/RecyclerView$mByQ;)V

    .line 5
    iput p3, p0, Landroidx/recyclerview/widget/wA$qdMbNW;->wA:I

    .line 6
    iput p4, p0, Landroidx/recyclerview/widget/wA$qdMbNW;->ZfxDd:I

    .line 7
    iput p5, p0, Landroidx/recyclerview/widget/wA$qdMbNW;->KLFTb:I

    .line 8
    iput p6, p0, Landroidx/recyclerview/widget/wA$qdMbNW;->JHa:I

    return-void
.end method


# virtual methods
.method public toString()Ljava/lang/String;
    .locals 2

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "ChangeInfo{oldHolder="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Landroidx/recyclerview/widget/wA$qdMbNW;->mjFkc:Landroidx/recyclerview/widget/RecyclerView$mByQ;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", newHolder="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Landroidx/recyclerview/widget/wA$qdMbNW;->AZxh:Landroidx/recyclerview/widget/RecyclerView$mByQ;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", fromX="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, Landroidx/recyclerview/widget/wA$qdMbNW;->wA:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, ", fromY="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, Landroidx/recyclerview/widget/wA$qdMbNW;->ZfxDd:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, ", toX="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, Landroidx/recyclerview/widget/wA$qdMbNW;->KLFTb:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, ", toY="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget p0, p0, Landroidx/recyclerview/widget/wA$qdMbNW;->JHa:I

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/16 p0, 0x7d

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
