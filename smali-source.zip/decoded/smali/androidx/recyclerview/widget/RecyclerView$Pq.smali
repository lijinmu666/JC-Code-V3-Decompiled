.class public interface abstract Landroidx/recyclerview/widget/RecyclerView$Pq;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/recyclerview/widget/RecyclerView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "Pq"
.end annotation


# virtual methods
.method public abstract AZxh(Landroidx/recyclerview/widget/RecyclerView;Landroid/view/MotionEvent;)V
.end method

.method public abstract mjFkc(Landroidx/recyclerview/widget/RecyclerView;Landroid/view/MotionEvent;)Z
.end method

.method public abstract wA(Z)V
.end method
