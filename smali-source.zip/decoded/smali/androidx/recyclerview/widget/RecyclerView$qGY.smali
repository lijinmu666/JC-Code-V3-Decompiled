.class public abstract Landroidx/recyclerview/widget/RecyclerView$qGY;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/recyclerview/widget/RecyclerView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "qGY"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/recyclerview/widget/RecyclerView$qGY$ZfxDd;,
        Landroidx/recyclerview/widget/RecyclerView$qGY$wA;
    }
.end annotation


# instance fields
.field public AZxh:Landroidx/recyclerview/widget/RecyclerView;

.field public Dt:Z

.field public ETF:Z

.field public IEE:I

.field public JHa:Landroidx/recyclerview/widget/rkYL;

.field public KLFTb:Landroidx/recyclerview/widget/rkYL;

.field public MiMN:I

.field public VA:Z

.field public YoKzxo:Z

.field public final ZfxDd:Landroidx/recyclerview/widget/rkYL$AZxh;

.field public fehf:I

.field public lgHUyS:Z

.field public mjFkc:Landroidx/recyclerview/widget/AZxh;

.field public qGY:I

.field public qdMbNW:Z

.field public rkYL:I

.field public final wA:Landroidx/recyclerview/widget/rkYL$AZxh;

.field public xJ:Landroidx/recyclerview/widget/RecyclerView$vI;


# direct methods
.method public constructor <init>()V
    .locals 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Landroidx/recyclerview/widget/RecyclerView$qGY$mjFkc;

    invoke-direct {v0, p0}, Landroidx/recyclerview/widget/RecyclerView$qGY$mjFkc;-><init>(Landroidx/recyclerview/widget/RecyclerView$qGY;)V

    iput-object v0, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->wA:Landroidx/recyclerview/widget/rkYL$AZxh;

    new-instance v1, Landroidx/recyclerview/widget/RecyclerView$qGY$AZxh;

    invoke-direct {v1, p0}, Landroidx/recyclerview/widget/RecyclerView$qGY$AZxh;-><init>(Landroidx/recyclerview/widget/RecyclerView$qGY;)V

    iput-object v1, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->ZfxDd:Landroidx/recyclerview/widget/rkYL$AZxh;

    new-instance v2, Landroidx/recyclerview/widget/rkYL;

    invoke-direct {v2, v0}, Landroidx/recyclerview/widget/rkYL;-><init>(Landroidx/recyclerview/widget/rkYL$AZxh;)V

    iput-object v2, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->KLFTb:Landroidx/recyclerview/widget/rkYL;

    new-instance v0, Landroidx/recyclerview/widget/rkYL;

    invoke-direct {v0, v1}, Landroidx/recyclerview/widget/rkYL;-><init>(Landroidx/recyclerview/widget/rkYL$AZxh;)V

    iput-object v0, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->JHa:Landroidx/recyclerview/widget/rkYL;

    const/4 v0, 0x0

    iput-boolean v0, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->lgHUyS:Z

    iput-boolean v0, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->qdMbNW:Z

    iput-boolean v0, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->Dt:Z

    const/4 v0, 0x1

    iput-boolean v0, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->ETF:Z

    iput-boolean v0, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->VA:Z

    return-void
.end method

.method public static LREOK(III)Z
    .locals 3

    invoke-static {p1}, Landroid/view/View$MeasureSpec;->getMode(I)I

    move-result v0

    invoke-static {p1}, Landroid/view/View$MeasureSpec;->getSize(I)I

    move-result p1

    const/4 v1, 0x0

    if-lez p2, :cond_0

    if-eq p0, p2, :cond_0

    return v1

    :cond_0
    const/high16 p2, -0x80000000

    const/4 v2, 0x1

    if-eq v0, p2, :cond_4

    if-eqz v0, :cond_3

    const/high16 p2, 0x40000000    # 2.0f

    if-eq v0, p2, :cond_1

    return v1

    :cond_1
    if-ne p1, p0, :cond_2

    move v1, v2

    :cond_2
    return v1

    :cond_3
    return v2

    :cond_4
    if-lt p1, p0, :cond_5

    move v1, v2

    :cond_5
    return v1
.end method

.method public static cMLeY(IIIIZ)I
    .locals 4

    sub-int/2addr p0, p2

    const/4 p2, 0x0

    invoke-static {p2, p0}, Ljava/lang/Math;->max(II)I

    move-result p0

    const/4 v0, -0x2

    const/4 v1, -0x1

    const/high16 v2, -0x80000000

    const/high16 v3, 0x40000000    # 2.0f

    if-eqz p4, :cond_2

    if-ltz p3, :cond_0

    :goto_0
    move p1, v3

    goto :goto_2

    :cond_0
    if-ne p3, v1, :cond_1

    if-eq p1, v2, :cond_4

    if-eqz p1, :cond_1

    if-eq p1, v3, :cond_4

    :cond_1
    move p1, p2

    move p3, p1

    goto :goto_2

    :cond_2
    if-ltz p3, :cond_3

    goto :goto_0

    :cond_3
    if-ne p3, v1, :cond_5

    :cond_4
    move p3, p0

    goto :goto_2

    :cond_5
    if-ne p3, v0, :cond_1

    if-eq p1, v2, :cond_7

    if-ne p1, v3, :cond_6

    goto :goto_1

    :cond_6
    move p3, p0

    move p1, p2

    goto :goto_2

    :cond_7
    :goto_1
    move p3, p0

    move p1, v2

    :goto_2
    invoke-static {p3, p1}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result p0

    return p0
.end method

.method public static rkYL(III)I
    .locals 2

    invoke-static {p0}, Landroid/view/View$MeasureSpec;->getMode(I)I

    move-result v0

    invoke-static {p0}, Landroid/view/View$MeasureSpec;->getSize(I)I

    move-result p0

    const/high16 v1, -0x80000000

    if-eq v0, v1, :cond_1

    const/high16 v1, 0x40000000    # 2.0f

    if-eq v0, v1, :cond_0

    invoke-static {p1, p2}, Ljava/lang/Math;->max(II)I

    move-result p0

    :cond_0
    return p0

    :cond_1
    invoke-static {p1, p2}, Ljava/lang/Math;->max(II)I

    move-result p1

    invoke-static {p0, p1}, Ljava/lang/Math;->min(II)I

    move-result p0

    return p0
.end method

.method public static yfx(Landroid/content/Context;Landroid/util/AttributeSet;II)Landroidx/recyclerview/widget/RecyclerView$qGY$ZfxDd;
    .locals 2

    new-instance v0, Landroidx/recyclerview/widget/RecyclerView$qGY$ZfxDd;

    invoke-direct {v0}, Landroidx/recyclerview/widget/RecyclerView$qGY$ZfxDd;-><init>()V

    sget-object v1, Lo/Z4;->mjFkc:[I

    invoke-virtual {p0, p1, v1, p2, p3}, Landroid/content/Context;->obtainStyledAttributes(Landroid/util/AttributeSet;[III)Landroid/content/res/TypedArray;

    move-result-object p0

    sget p1, Lo/Z4;->AZxh:I

    const/4 p2, 0x1

    invoke-virtual {p0, p1, p2}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result p1

    iput p1, v0, Landroidx/recyclerview/widget/RecyclerView$qGY$ZfxDd;->mjFkc:I

    sget p1, Lo/Z4;->VA:I

    invoke-virtual {p0, p1, p2}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result p1

    iput p1, v0, Landroidx/recyclerview/widget/RecyclerView$qGY$ZfxDd;->AZxh:I

    sget p1, Lo/Z4;->ETF:I

    const/4 p2, 0x0

    invoke-virtual {p0, p1, p2}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result p1

    iput-boolean p1, v0, Landroidx/recyclerview/widget/RecyclerView$qGY$ZfxDd;->wA:Z

    sget p1, Lo/Z4;->MiMN:I

    invoke-virtual {p0, p1, p2}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result p1

    iput-boolean p1, v0, Landroidx/recyclerview/widget/RecyclerView$qGY$ZfxDd;->ZfxDd:Z

    invoke-virtual {p0}, Landroid/content/res/TypedArray;->recycle()V

    return-object v0
.end method


# virtual methods
.method public ANMGZc()I
    .locals 0

    iget-object p0, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->AZxh:Landroidx/recyclerview/widget/RecyclerView;

    if-eqz p0, :cond_0

    invoke-virtual {p0}, Landroid/view/View;->getPaddingRight()I

    move-result p0

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method

.method public APn(Landroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;ILandroid/os/Bundle;)Z
    .locals 8

    iget-object p1, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->AZxh:Landroidx/recyclerview/widget/RecyclerView;

    const/4 p2, 0x0

    if-nez p1, :cond_0

    return p2

    :cond_0
    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->JYgkl()I

    move-result p1

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->SOS()I

    move-result p4

    new-instance v0, Landroid/graphics/Rect;

    invoke-direct {v0}, Landroid/graphics/Rect;-><init>()V

    iget-object v1, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->AZxh:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {v1}, Landroid/view/View;->getMatrix()Landroid/graphics/Matrix;

    move-result-object v1

    invoke-virtual {v1}, Landroid/graphics/Matrix;->isIdentity()Z

    move-result v1

    if-eqz v1, :cond_1

    iget-object v1, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->AZxh:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {v1, v0}, Landroid/view/View;->getGlobalVisibleRect(Landroid/graphics/Rect;)Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-virtual {v0}, Landroid/graphics/Rect;->height()I

    move-result p1

    invoke-virtual {v0}, Landroid/graphics/Rect;->width()I

    move-result p4

    :cond_1
    const/16 v0, 0x1000

    const/4 v1, 0x1

    if-eq p3, v0, :cond_5

    const/16 v0, 0x2000

    if-eq p3, v0, :cond_2

    move v3, p2

    move v4, v3

    goto :goto_3

    :cond_2
    iget-object p3, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->AZxh:Landroidx/recyclerview/widget/RecyclerView;

    const/4 v0, -0x1

    invoke-virtual {p3, v0}, Landroid/view/View;->canScrollVertically(I)Z

    move-result p3

    if-eqz p3, :cond_3

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->dm()I

    move-result p3

    sub-int/2addr p1, p3

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->JBhc()I

    move-result p3

    sub-int/2addr p1, p3

    neg-int p1, p1

    goto :goto_0

    :cond_3
    move p1, p2

    :goto_0
    iget-object p3, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->AZxh:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {p3, v0}, Landroid/view/View;->canScrollHorizontally(I)Z

    move-result p3

    if-eqz p3, :cond_4

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->jm()I

    move-result p3

    sub-int/2addr p4, p3

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->ANMGZc()I

    move-result p3

    sub-int/2addr p4, p3

    neg-int p3, p4

    :goto_1
    move v4, p1

    move v3, p3

    goto :goto_3

    :cond_4
    move v4, p1

    move v3, p2

    goto :goto_3

    :cond_5
    iget-object p3, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->AZxh:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {p3, v1}, Landroid/view/View;->canScrollVertically(I)Z

    move-result p3

    if-eqz p3, :cond_6

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->dm()I

    move-result p3

    sub-int/2addr p1, p3

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->JBhc()I

    move-result p3

    sub-int/2addr p1, p3

    goto :goto_2

    :cond_6
    move p1, p2

    :goto_2
    iget-object p3, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->AZxh:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {p3, v1}, Landroid/view/View;->canScrollHorizontally(I)Z

    move-result p3

    if-eqz p3, :cond_4

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->jm()I

    move-result p3

    sub-int/2addr p4, p3

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->ANMGZc()I

    move-result p3

    sub-int p3, p4, p3

    goto :goto_1

    :goto_3
    if-nez v4, :cond_7

    if-nez v3, :cond_7

    return p2

    :cond_7
    iget-object v2, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->AZxh:Landroidx/recyclerview/widget/RecyclerView;

    const/high16 v6, -0x80000000

    const/4 v7, 0x1

    const/4 v5, 0x0

    invoke-virtual/range {v2 .. v7}, Landroidx/recyclerview/widget/RecyclerView;->mzUGzO(IILandroid/view/animation/Interpolator;IZ)V

    return v1
.end method

.method public BAnRFn(Landroidx/recyclerview/widget/RecyclerView;Landroidx/recyclerview/widget/RecyclerView$Ucbh;)V
    .locals 1

    const/4 v0, 0x0

    iput-boolean v0, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->qdMbNW:Z

    invoke-virtual {p0, p1, p2}, Landroidx/recyclerview/widget/RecyclerView$qGY;->XD(Landroidx/recyclerview/widget/RecyclerView;Landroidx/recyclerview/widget/RecyclerView$Ucbh;)V

    return-void
.end method

.method public abstract BxruE(ILandroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;)I
.end method

.method public CTcA(I)V
    .locals 1

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/RecyclerView$qGY;->KLMXS(I)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_0

    iget-object p0, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->mjFkc:Landroidx/recyclerview/widget/AZxh;

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/AZxh;->fehf(I)V

    :cond_0
    return-void
.end method

.method public CqaNbM()I
    .locals 0

    const/4 p0, -0x1

    return p0
.end method

.method public Dp(Landroid/view/accessibility/AccessibilityEvent;)V
    .locals 2

    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->AZxh:Landroidx/recyclerview/widget/RecyclerView;

    iget-object v1, v0, Landroidx/recyclerview/widget/RecyclerView;->wA:Landroidx/recyclerview/widget/RecyclerView$Ucbh;

    iget-object v0, v0, Landroidx/recyclerview/widget/RecyclerView;->Vdz:Landroidx/recyclerview/widget/RecyclerView$VocHEe;

    invoke-virtual {p0, v1, v0, p1}, Landroidx/recyclerview/widget/RecyclerView$qGY;->fLidf(Landroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;Landroid/view/accessibility/AccessibilityEvent;)V

    return-void
.end method

.method public Dt(Landroid/view/View;ILandroidx/recyclerview/widget/RecyclerView$fehf;)V
    .locals 2

    invoke-static {p1}, Landroidx/recyclerview/widget/RecyclerView;->dm(Landroid/view/View;)Landroidx/recyclerview/widget/RecyclerView$mByQ;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/recyclerview/widget/RecyclerView$mByQ;->Ucbh()Z

    move-result v1

    if-eqz v1, :cond_0

    iget-object v1, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->AZxh:Landroidx/recyclerview/widget/RecyclerView;

    iget-object v1, v1, Landroidx/recyclerview/widget/RecyclerView;->xJ:Landroidx/recyclerview/widget/qGY;

    invoke-virtual {v1, v0}, Landroidx/recyclerview/widget/qGY;->AZxh(Landroidx/recyclerview/widget/RecyclerView$mByQ;)V

    goto :goto_0

    :cond_0
    iget-object v1, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->AZxh:Landroidx/recyclerview/widget/RecyclerView;

    iget-object v1, v1, Landroidx/recyclerview/widget/RecyclerView;->xJ:Landroidx/recyclerview/widget/qGY;

    invoke-virtual {v1, v0}, Landroidx/recyclerview/widget/qGY;->qGY(Landroidx/recyclerview/widget/RecyclerView$mByQ;)V

    :goto_0
    iget-object p0, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->mjFkc:Landroidx/recyclerview/widget/AZxh;

    invoke-virtual {v0}, Landroidx/recyclerview/widget/RecyclerView$mByQ;->Ucbh()Z

    move-result v0

    invoke-virtual {p0, p1, p2, p3, v0}, Landroidx/recyclerview/widget/AZxh;->wA(Landroid/view/View;ILandroid/view/ViewGroup$LayoutParams;Z)V

    return-void
.end method

.method public ERt()Z
    .locals 0

    const/4 p0, 0x0

    return p0
.end method

.method public ETF(Landroid/view/View;Landroid/graphics/Rect;)V
    .locals 0

    iget-object p0, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->AZxh:Landroidx/recyclerview/widget/RecyclerView;

    if-nez p0, :cond_0

    const/4 p0, 0x0

    invoke-virtual {p2, p0, p0, p0, p0}, Landroid/graphics/Rect;->set(IIII)V

    return-void

    :cond_0
    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/RecyclerView;->xROA(Landroid/view/View;)Landroid/graphics/Rect;

    move-result-object p0

    invoke-virtual {p2, p0}, Landroid/graphics/Rect;->set(Landroid/graphics/Rect;)V

    return-void
.end method

.method public FOJ()V
    .locals 0

    iget-object p0, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->xJ:Landroidx/recyclerview/widget/RecyclerView$vI;

    if-eqz p0, :cond_0

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$vI;->IEE()V

    :cond_0
    return-void
.end method

.method public FbxKQm(Landroidx/recyclerview/widget/RecyclerView;)V
    .locals 0

    return-void
.end method

.method public Fztqa(Landroidx/recyclerview/widget/RecyclerView;Landroid/view/View;Landroid/graphics/Rect;ZZ)Z
    .locals 2

    invoke-virtual {p0, p2, p3}, Landroidx/recyclerview/widget/RecyclerView$qGY;->rWxwaT(Landroid/view/View;Landroid/graphics/Rect;)[I

    move-result-object p2

    const/4 p3, 0x0

    aget v0, p2, p3

    const/4 v1, 0x1

    aget p2, p2, v1

    if-eqz p5, :cond_0

    invoke-virtual {p0, p1, v0, p2}, Landroidx/recyclerview/widget/RecyclerView$qGY;->tjSezt(Landroidx/recyclerview/widget/RecyclerView;II)Z

    move-result p0

    if-eqz p0, :cond_1

    :cond_0
    if-nez v0, :cond_2

    if-eqz p2, :cond_1

    goto :goto_0

    :cond_1
    return p3

    :cond_2
    :goto_0
    if-eqz p4, :cond_3

    invoke-virtual {p1, v0, p2}, Landroidx/recyclerview/widget/RecyclerView;->scrollBy(II)V

    goto :goto_1

    :cond_3
    invoke-virtual {p1, v0, p2}, Landroidx/recyclerview/widget/RecyclerView;->CTcA(II)V

    :goto_1
    return v1
.end method

.method public GMIER(Landroid/view/View;)I
    .locals 1

    invoke-virtual {p1}, Landroid/view/View;->getRight()I

    move-result v0

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/RecyclerView$qGY;->vjlshU(Landroid/view/View;)I

    move-result p0

    add-int/2addr v0, p0

    return v0
.end method

.method public Gd(Landroidx/recyclerview/widget/RecyclerView$Ucbh;)V
    .locals 2

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->zvd()I

    move-result v0

    add-int/lit8 v0, v0, -0x1

    :goto_0
    if-ltz v0, :cond_0

    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->KLMXS(I)Landroid/view/View;

    move-result-object v1

    invoke-virtual {p0, p1, v0, v1}, Landroidx/recyclerview/widget/RecyclerView$qGY;->Htq(Landroidx/recyclerview/widget/RecyclerView$Ucbh;ILandroid/view/View;)V

    add-int/lit8 v0, v0, -0x1

    goto :goto_0

    :cond_0
    return-void
.end method

.method public HGpJ(I)V
    .locals 1

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/RecyclerView$qGY;->KLMXS(I)Landroid/view/View;

    move-result-object v0

    invoke-virtual {p0, p1, v0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->vI(ILandroid/view/View;)V

    return-void
.end method

.method public final Htq(Landroidx/recyclerview/widget/RecyclerView$Ucbh;ILandroid/view/View;)V
    .locals 2

    invoke-static {p3}, Landroidx/recyclerview/widget/RecyclerView;->dm(Landroid/view/View;)Landroidx/recyclerview/widget/RecyclerView$mByQ;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/recyclerview/widget/RecyclerView$mByQ;->KLMXS()Z

    move-result v1

    if-eqz v1, :cond_1

    sget-boolean p0, Landroidx/recyclerview/widget/RecyclerView;->LREOK:Z

    if-eqz p0, :cond_0

    new-instance p0, Ljava/lang/StringBuilder;

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    const-string p1, "ignoring view "

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const-string p1, "RecyclerView"

    invoke-static {p1, p0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    :cond_0
    return-void

    :cond_1
    invoke-virtual {v0}, Landroidx/recyclerview/widget/RecyclerView$mByQ;->diqgf()Z

    move-result v1

    if-eqz v1, :cond_2

    invoke-virtual {v0}, Landroidx/recyclerview/widget/RecyclerView$mByQ;->Ucbh()Z

    move-result v1

    if-nez v1, :cond_2

    iget-object v1, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->AZxh:Landroidx/recyclerview/widget/RecyclerView;

    iget-object v1, v1, Landroidx/recyclerview/widget/RecyclerView;->MiMN:Landroidx/recyclerview/widget/RecyclerView$lgHUyS;

    invoke-virtual {v1}, Landroidx/recyclerview/widget/RecyclerView$lgHUyS;->lgHUyS()Z

    move-result v1

    if-nez v1, :cond_2

    invoke-virtual {p0, p2}, Landroidx/recyclerview/widget/RecyclerView$qGY;->CTcA(I)V

    invoke-virtual {p1, v0}, Landroidx/recyclerview/widget/RecyclerView$Ucbh;->CqaNbM(Landroidx/recyclerview/widget/RecyclerView$mByQ;)V

    goto :goto_0

    :cond_2
    invoke-virtual {p0, p2}, Landroidx/recyclerview/widget/RecyclerView$qGY;->HGpJ(I)V

    invoke-virtual {p1, p3}, Landroidx/recyclerview/widget/RecyclerView$Ucbh;->xrEuO(Landroid/view/View;)V

    iget-object p0, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->AZxh:Landroidx/recyclerview/widget/RecyclerView;

    iget-object p0, p0, Landroidx/recyclerview/widget/RecyclerView;->xJ:Landroidx/recyclerview/widget/qGY;

    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/qGY;->ETF(Landroidx/recyclerview/widget/RecyclerView$mByQ;)V

    :goto_0
    return-void
.end method

.method public abstract IEE(Landroidx/recyclerview/widget/RecyclerView$VocHEe;)I
.end method

.method public IVlxe(Landroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;)I
    .locals 0

    const/4 p0, 0x0

    return p0
.end method

.method public IvRQOa(ILandroid/os/Bundle;)Z
    .locals 2

    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->AZxh:Landroidx/recyclerview/widget/RecyclerView;

    iget-object v1, v0, Landroidx/recyclerview/widget/RecyclerView;->wA:Landroidx/recyclerview/widget/RecyclerView$Ucbh;

    iget-object v0, v0, Landroidx/recyclerview/widget/RecyclerView;->Vdz:Landroidx/recyclerview/widget/RecyclerView$VocHEe;

    invoke-virtual {p0, v1, v0, p1, p2}, Landroidx/recyclerview/widget/RecyclerView$qGY;->APn(Landroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;ILandroid/os/Bundle;)Z

    move-result p0

    return p0
.end method

.method public IyS(Landroidx/recyclerview/widget/RecyclerView;II)V
    .locals 0

    return-void
.end method

.method public JBhc()I
    .locals 0

    iget-object p0, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->AZxh:Landroidx/recyclerview/widget/RecyclerView;

    if-eqz p0, :cond_0

    invoke-virtual {p0}, Landroid/view/View;->getPaddingBottom()I

    move-result p0

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method

.method public JHa(Landroid/view/View;I)V
    .locals 1

    const/4 v0, 0x0

    invoke-virtual {p0, p1, p2, v0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->xJ(Landroid/view/View;IZ)V

    return-void
.end method

.method public JYgkl()I
    .locals 0

    iget p0, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->IEE:I

    return p0
.end method

.method public JYn()Landroid/view/View;
    .locals 2

    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->AZxh:Landroidx/recyclerview/widget/RecyclerView;

    const/4 v1, 0x0

    if-nez v0, :cond_0

    return-object v1

    :cond_0
    invoke-virtual {v0}, Landroid/view/ViewGroup;->getFocusedChild()Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_2

    iget-object p0, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->mjFkc:Landroidx/recyclerview/widget/AZxh;

    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/AZxh;->YoKzxo(Landroid/view/View;)Z

    move-result p0

    if-eqz p0, :cond_1

    goto :goto_0

    :cond_1
    return-object v0

    :cond_2
    :goto_0
    return-object v1
.end method

.method public Jidt(Landroidx/recyclerview/widget/RecyclerView$vI;)V
    .locals 1

    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->xJ:Landroidx/recyclerview/widget/RecyclerView$vI;

    if-ne v0, p1, :cond_0

    const/4 p1, 0x0

    iput-object p1, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->xJ:Landroidx/recyclerview/widget/RecyclerView$vI;

    :cond_0
    return-void
.end method

.method public Jk(Landroidx/recyclerview/widget/RecyclerView;Landroid/view/View;Landroid/view/View;)Z
    .locals 0

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->fFz()Z

    move-result p0

    if-nez p0, :cond_1

    invoke-virtual {p1}, Landroidx/recyclerview/widget/RecyclerView;->gYa()Z

    move-result p0

    if-eqz p0, :cond_0

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    goto :goto_1

    :cond_1
    :goto_0
    const/4 p0, 0x1

    :goto_1
    return p0
.end method

.method public JrJO()I
    .locals 0

    iget p0, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->qGY:I

    return p0
.end method

.method public KLFTb(Landroid/view/View;)V
    .locals 1

    const/4 v0, -0x1

    invoke-virtual {p0, p1, v0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->JHa(Landroid/view/View;I)V

    return-void
.end method

.method public KLMXS(I)Landroid/view/View;
    .locals 0

    iget-object p0, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->mjFkc:Landroidx/recyclerview/widget/AZxh;

    if-eqz p0, :cond_0

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/AZxh;->JHa(I)Landroid/view/View;

    move-result-object p0

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return-object p0
.end method

.method public KRTLGT(Landroid/view/View;)I
    .locals 1

    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object p0

    check-cast p0, Landroidx/recyclerview/widget/RecyclerView$fehf;

    iget-object p0, p0, Landroidx/recyclerview/widget/RecyclerView$fehf;->AZxh:Landroid/graphics/Rect;

    invoke-virtual {p1}, Landroid/view/View;->getMeasuredWidth()I

    move-result p1

    iget v0, p0, Landroid/graphics/Rect;->left:I

    add-int/2addr p1, v0

    iget p0, p0, Landroid/graphics/Rect;->right:I

    add-int/2addr p1, p0

    return p1
.end method

.method public KRckQg(Landroidx/recyclerview/widget/RecyclerView;Landroidx/recyclerview/widget/RecyclerView$VocHEe;Landroid/view/View;Landroid/view/View;)Z
    .locals 0

    invoke-virtual {p0, p1, p3, p4}, Landroidx/recyclerview/widget/RecyclerView$qGY;->Jk(Landroidx/recyclerview/widget/RecyclerView;Landroid/view/View;Landroid/view/View;)Z

    move-result p0

    return p0
.end method

.method public LeWm(Landroidx/recyclerview/widget/RecyclerView;Landroid/view/View;Landroid/graphics/Rect;Z)Z
    .locals 6

    const/4 v5, 0x0

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v3, p3

    move v4, p4

    invoke-virtual/range {v0 .. v5}, Landroidx/recyclerview/widget/RecyclerView$qGY;->Fztqa(Landroidx/recyclerview/widget/RecyclerView;Landroid/view/View;Landroid/graphics/Rect;ZZ)Z

    move-result p0

    return p0
.end method

.method public LsBneK(Landroidx/recyclerview/widget/RecyclerView;)V
    .locals 2

    invoke-virtual {p1}, Landroid/view/View;->getWidth()I

    move-result v0

    const/high16 v1, 0x40000000    # 2.0f

    invoke-static {v0, v1}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v0

    invoke-virtual {p1}, Landroid/view/View;->getHeight()I

    move-result p1

    invoke-static {p1, v1}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result p1

    invoke-virtual {p0, v0, p1}, Landroidx/recyclerview/widget/RecyclerView$qGY;->nUaNy(II)V

    return-void
.end method

.method public MiMN()Z
    .locals 0

    const/4 p0, 0x0

    return p0
.end method

.method public Moer(Landroid/view/View;)I
    .locals 0

    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object p0

    check-cast p0, Landroidx/recyclerview/widget/RecyclerView$fehf;

    iget-object p0, p0, Landroidx/recyclerview/widget/RecyclerView$fehf;->AZxh:Landroid/graphics/Rect;

    iget p0, p0, Landroid/graphics/Rect;->top:I

    return p0
.end method

.method public NKyg()Z
    .locals 5

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->zvd()I

    move-result v0

    const/4 v1, 0x0

    move v2, v1

    :goto_0
    if-ge v2, v0, :cond_1

    invoke-virtual {p0, v2}, Landroidx/recyclerview/widget/RecyclerView$qGY;->KLMXS(I)Landroid/view/View;

    move-result-object v3

    invoke-virtual {v3}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v3

    iget v4, v3, Landroid/view/ViewGroup$LayoutParams;->width:I

    if-gez v4, :cond_0

    iget v3, v3, Landroid/view/ViewGroup$LayoutParams;->height:I

    if-gez v3, :cond_0

    const/4 p0, 0x1

    return p0

    :cond_0
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_1
    return v1
.end method

.method public NPj(Landroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;)I
    .locals 0

    const/4 p0, -0x1

    return p0
.end method

.method public NV(I)V
    .locals 0

    return-void
.end method

.method public Ne(Landroid/view/ViewGroup$LayoutParams;)Landroidx/recyclerview/widget/RecyclerView$fehf;
    .locals 0

    instance-of p0, p1, Landroidx/recyclerview/widget/RecyclerView$fehf;

    if-eqz p0, :cond_0

    new-instance p0, Landroidx/recyclerview/widget/RecyclerView$fehf;

    check-cast p1, Landroidx/recyclerview/widget/RecyclerView$fehf;

    invoke-direct {p0, p1}, Landroidx/recyclerview/widget/RecyclerView$fehf;-><init>(Landroidx/recyclerview/widget/RecyclerView$fehf;)V

    return-object p0

    :cond_0
    instance-of p0, p1, Landroid/view/ViewGroup$MarginLayoutParams;

    if-eqz p0, :cond_1

    new-instance p0, Landroidx/recyclerview/widget/RecyclerView$fehf;

    check-cast p1, Landroid/view/ViewGroup$MarginLayoutParams;

    invoke-direct {p0, p1}, Landroidx/recyclerview/widget/RecyclerView$fehf;-><init>(Landroid/view/ViewGroup$MarginLayoutParams;)V

    return-object p0

    :cond_1
    new-instance p0, Landroidx/recyclerview/widget/RecyclerView$fehf;

    invoke-direct {p0, p1}, Landroidx/recyclerview/widget/RecyclerView$fehf;-><init>(Landroid/view/ViewGroup$LayoutParams;)V

    return-object p0
.end method

.method public OjSQV(Landroid/content/Context;Landroid/util/AttributeSet;)Landroidx/recyclerview/widget/RecyclerView$fehf;
    .locals 0

    new-instance p0, Landroidx/recyclerview/widget/RecyclerView$fehf;

    invoke-direct {p0, p1, p2}, Landroidx/recyclerview/widget/RecyclerView$fehf;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    return-object p0
.end method

.method public abstract Pq(Landroidx/recyclerview/widget/RecyclerView$VocHEe;)I
.end method

.method public Qr()I
    .locals 0

    iget p0, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->rkYL:I

    return p0
.end method

.method public QyqF(ILandroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;)I
    .locals 0

    const/4 p0, 0x0

    return p0
.end method

.method public RWyiuY(Landroid/view/View;Landroidx/recyclerview/widget/RecyclerView$Ucbh;)V
    .locals 0

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/RecyclerView$qGY;->oVXlhB(Landroid/view/View;)V

    invoke-virtual {p2, p1}, Landroidx/recyclerview/widget/RecyclerView$Ucbh;->Ne(Landroid/view/View;)V

    return-void
.end method

.method public Rc(Lo/Ucbh;)V
    .locals 2

    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->AZxh:Landroidx/recyclerview/widget/RecyclerView;

    iget-object v1, v0, Landroidx/recyclerview/widget/RecyclerView;->wA:Landroidx/recyclerview/widget/RecyclerView$Ucbh;

    iget-object v0, v0, Landroidx/recyclerview/widget/RecyclerView;->Vdz:Landroidx/recyclerview/widget/RecyclerView$VocHEe;

    invoke-virtual {p0, v1, v0, p1}, Landroidx/recyclerview/widget/RecyclerView$qGY;->hvGY(Landroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;Lo/Ucbh;)V

    return-void
.end method

.method public SKTn(Landroid/view/View;Lo/Ucbh;)V
    .locals 2

    invoke-static {p1}, Landroidx/recyclerview/widget/RecyclerView;->dm(Landroid/view/View;)Landroidx/recyclerview/widget/RecyclerView$mByQ;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Landroidx/recyclerview/widget/RecyclerView$mByQ;->Ucbh()Z

    move-result v1

    if-nez v1, :cond_0

    iget-object v1, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->mjFkc:Landroidx/recyclerview/widget/AZxh;

    iget-object v0, v0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->mjFkc:Landroid/view/View;

    invoke-virtual {v1, v0}, Landroidx/recyclerview/widget/AZxh;->YoKzxo(Landroid/view/View;)Z

    move-result v0

    if-nez v0, :cond_0

    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->AZxh:Landroidx/recyclerview/widget/RecyclerView;

    iget-object v1, v0, Landroidx/recyclerview/widget/RecyclerView;->wA:Landroidx/recyclerview/widget/RecyclerView$Ucbh;

    iget-object v0, v0, Landroidx/recyclerview/widget/RecyclerView;->Vdz:Landroidx/recyclerview/widget/RecyclerView$VocHEe;

    invoke-virtual {p0, v1, v0, p1, p2}, Landroidx/recyclerview/widget/RecyclerView$qGY;->rdJr(Landroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;Landroid/view/View;Lo/Ucbh;)V

    :cond_0
    return-void
.end method

.method public SOS()I
    .locals 0

    iget p0, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->fehf:I

    return p0
.end method

.method public SmIWf(Landroid/view/View;ZLandroid/graphics/Rect;)V
    .locals 4

    if-eqz p2, :cond_0

    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object p2

    check-cast p2, Landroidx/recyclerview/widget/RecyclerView$fehf;

    iget-object p2, p2, Landroidx/recyclerview/widget/RecyclerView$fehf;->AZxh:Landroid/graphics/Rect;

    iget v0, p2, Landroid/graphics/Rect;->left:I

    neg-int v0, v0

    iget v1, p2, Landroid/graphics/Rect;->top:I

    neg-int v1, v1

    invoke-virtual {p1}, Landroid/view/View;->getWidth()I

    move-result v2

    iget v3, p2, Landroid/graphics/Rect;->right:I

    add-int/2addr v2, v3

    invoke-virtual {p1}, Landroid/view/View;->getHeight()I

    move-result v3

    iget p2, p2, Landroid/graphics/Rect;->bottom:I

    add-int/2addr v3, p2

    invoke-virtual {p3, v0, v1, v2, v3}, Landroid/graphics/Rect;->set(IIII)V

    goto :goto_0

    :cond_0
    invoke-virtual {p1}, Landroid/view/View;->getWidth()I

    move-result p2

    invoke-virtual {p1}, Landroid/view/View;->getHeight()I

    move-result v0

    const/4 v1, 0x0

    invoke-virtual {p3, v1, v1, p2, v0}, Landroid/graphics/Rect;->set(IIII)V

    :goto_0
    iget-object p2, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->AZxh:Landroidx/recyclerview/widget/RecyclerView;

    if-eqz p2, :cond_1

    invoke-virtual {p1}, Landroid/view/View;->getMatrix()Landroid/graphics/Matrix;

    move-result-object p2

    if-eqz p2, :cond_1

    invoke-virtual {p2}, Landroid/graphics/Matrix;->isIdentity()Z

    move-result v0

    if-nez v0, :cond_1

    iget-object p0, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->AZxh:Landroidx/recyclerview/widget/RecyclerView;

    iget-object p0, p0, Landroidx/recyclerview/widget/RecyclerView;->VA:Landroid/graphics/RectF;

    invoke-virtual {p0, p3}, Landroid/graphics/RectF;->set(Landroid/graphics/Rect;)V

    invoke-virtual {p2, p0}, Landroid/graphics/Matrix;->mapRect(Landroid/graphics/RectF;)Z

    iget p2, p0, Landroid/graphics/RectF;->left:F

    float-to-double v0, p2

    invoke-static {v0, v1}, Ljava/lang/Math;->floor(D)D

    move-result-wide v0

    double-to-int p2, v0

    iget v0, p0, Landroid/graphics/RectF;->top:F

    float-to-double v0, v0

    invoke-static {v0, v1}, Ljava/lang/Math;->floor(D)D

    move-result-wide v0

    double-to-int v0, v0

    iget v1, p0, Landroid/graphics/RectF;->right:F

    float-to-double v1, v1

    invoke-static {v1, v2}, Ljava/lang/Math;->ceil(D)D

    move-result-wide v1

    double-to-int v1, v1

    iget p0, p0, Landroid/graphics/RectF;->bottom:F

    float-to-double v2, p0

    invoke-static {v2, v3}, Ljava/lang/Math;->ceil(D)D

    move-result-wide v2

    double-to-int p0, v2

    invoke-virtual {p3, p2, v0, v1, p0}, Landroid/graphics/Rect;->set(IIII)V

    :cond_1
    invoke-virtual {p1}, Landroid/view/View;->getLeft()I

    move-result p0

    invoke-virtual {p1}, Landroid/view/View;->getTop()I

    move-result p1

    invoke-virtual {p3, p0, p1}, Landroid/graphics/Rect;->offset(II)V

    return-void
.end method

.method public SwgkN()I
    .locals 0

    iget-object p0, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->AZxh:Landroidx/recyclerview/widget/RecyclerView;

    invoke-static {p0}, Lo/T9;->HGpJ(Landroid/view/View;)I

    move-result p0

    return p0
.end method

.method public abstract Tw(I)V
.end method

.method public Ucbh(Landroidx/recyclerview/widget/RecyclerView$VocHEe;)I
    .locals 0

    const/4 p0, 0x0

    return p0
.end method

.method public abstract VA()Z
.end method

.method public Vdz()I
    .locals 0

    iget-object p0, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->AZxh:Landroidx/recyclerview/widget/RecyclerView;

    if-eqz p0, :cond_0

    invoke-static {p0}, Lo/T9;->VocHEe(Landroid/view/View;)I

    move-result p0

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method

.method public VfB()V
    .locals 1

    const/4 v0, 0x1

    iput-boolean v0, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->lgHUyS:Z

    return-void
.end method

.method public Vgyli(Landroidx/recyclerview/widget/RecyclerView$lgHUyS;Landroidx/recyclerview/widget/RecyclerView$lgHUyS;)V
    .locals 0

    return-void
.end method

.method public Vnb()Z
    .locals 0

    iget-object p0, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->AZxh:Landroidx/recyclerview/widget/RecyclerView;

    if-eqz p0, :cond_0

    iget-boolean p0, p0, Landroidx/recyclerview/widget/RecyclerView;->lgHUyS:Z

    if-eqz p0, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method

.method public VocHEe(Landroidx/recyclerview/widget/RecyclerView;)V
    .locals 1

    const/4 v0, 0x1

    iput-boolean v0, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->qdMbNW:Z

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/RecyclerView$qGY;->giT(Landroidx/recyclerview/widget/RecyclerView;)V

    return-void
.end method

.method public Vu(ILandroidx/recyclerview/widget/RecyclerView$Ucbh;)V
    .locals 1

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/RecyclerView$qGY;->KLMXS(I)Landroid/view/View;

    move-result-object v0

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/RecyclerView$qGY;->CTcA(I)V

    invoke-virtual {p2, v0}, Landroidx/recyclerview/widget/RecyclerView$Ucbh;->Ne(Landroid/view/View;)V

    return-void
.end method

.method public WGXroI()I
    .locals 0

    iget-object p0, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->AZxh:Landroidx/recyclerview/widget/RecyclerView;

    invoke-static {p0}, Lo/T9;->huTpC(Landroid/view/View;)I

    move-result p0

    return p0
.end method

.method public WrLQs(Landroid/view/View;)I
    .locals 1

    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object p0

    check-cast p0, Landroidx/recyclerview/widget/RecyclerView$fehf;

    iget-object p0, p0, Landroidx/recyclerview/widget/RecyclerView$fehf;->AZxh:Landroid/graphics/Rect;

    invoke-virtual {p1}, Landroid/view/View;->getMeasuredHeight()I

    move-result p1

    iget v0, p0, Landroid/graphics/Rect;->top:I

    add-int/2addr p1, v0

    iget p0, p0, Landroid/graphics/Rect;->bottom:I

    add-int/2addr p1, p0

    return p1
.end method

.method public XD(Landroidx/recyclerview/widget/RecyclerView;Landroidx/recyclerview/widget/RecyclerView$Ucbh;)V
    .locals 0

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/RecyclerView$qGY;->sRqPfw(Landroidx/recyclerview/widget/RecyclerView;)V

    return-void
.end method

.method public XDdeP(Landroid/view/View;I)Landroid/view/View;
    .locals 0

    const/4 p0, 0x0

    return-object p0
.end method

.method public XFUzSY(Landroid/view/View;IIII)V
    .locals 2

    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object p0

    check-cast p0, Landroidx/recyclerview/widget/RecyclerView$fehf;

    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView$fehf;->AZxh:Landroid/graphics/Rect;

    iget v1, v0, Landroid/graphics/Rect;->left:I

    add-int/2addr p2, v1

    iget v1, p0, Landroid/view/ViewGroup$MarginLayoutParams;->leftMargin:I

    add-int/2addr p2, v1

    iget v1, v0, Landroid/graphics/Rect;->top:I

    add-int/2addr p3, v1

    iget v1, p0, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    add-int/2addr p3, v1

    iget v1, v0, Landroid/graphics/Rect;->right:I

    sub-int/2addr p4, v1

    iget v1, p0, Landroid/view/ViewGroup$MarginLayoutParams;->rightMargin:I

    sub-int/2addr p4, v1

    iget v0, v0, Landroid/graphics/Rect;->bottom:I

    sub-int/2addr p5, v0

    iget p0, p0, Landroid/view/ViewGroup$MarginLayoutParams;->bottomMargin:I

    sub-int/2addr p5, p0

    invoke-virtual {p1, p2, p3, p4, p5}, Landroid/view/View;->layout(IIII)V

    return-void
.end method

.method public XV(Landroid/view/View;)I
    .locals 0

    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object p0

    check-cast p0, Landroidx/recyclerview/widget/RecyclerView$fehf;

    iget-object p0, p0, Landroidx/recyclerview/widget/RecyclerView$fehf;->AZxh:Landroid/graphics/Rect;

    iget p0, p0, Landroid/graphics/Rect;->left:I

    return p0
.end method

.method public XbiWeM(Landroid/view/View;ZZ)Z
    .locals 2

    iget-object p3, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->KLFTb:Landroidx/recyclerview/widget/rkYL;

    const/16 v0, 0x6003

    invoke-virtual {p3, p1, v0}, Landroidx/recyclerview/widget/rkYL;->AZxh(Landroid/view/View;I)Z

    move-result p3

    const/4 v1, 0x1

    if-eqz p3, :cond_0

    iget-object p0, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->JHa:Landroidx/recyclerview/widget/rkYL;

    invoke-virtual {p0, p1, v0}, Landroidx/recyclerview/widget/rkYL;->AZxh(Landroid/view/View;I)Z

    move-result p0

    if-eqz p0, :cond_0

    move p0, v1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    if-eqz p2, :cond_1

    return p0

    :cond_1
    xor-int/2addr p0, v1

    return p0
.end method

.method public XgAT(Landroidx/recyclerview/widget/RecyclerView;II)V
    .locals 0

    return-void
.end method

.method public XtE(Landroid/view/View;II)V
    .locals 5

    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    check-cast v0, Landroidx/recyclerview/widget/RecyclerView$fehf;

    iget-object v1, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->AZxh:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {v1, p1}, Landroidx/recyclerview/widget/RecyclerView;->xROA(Landroid/view/View;)Landroid/graphics/Rect;

    move-result-object v1

    iget v2, v1, Landroid/graphics/Rect;->left:I

    iget v3, v1, Landroid/graphics/Rect;->right:I

    add-int/2addr v2, v3

    add-int/2addr p2, v2

    iget v2, v1, Landroid/graphics/Rect;->top:I

    iget v1, v1, Landroid/graphics/Rect;->bottom:I

    add-int/2addr v2, v1

    add-int/2addr p3, v2

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->SOS()I

    move-result v1

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->Qr()I

    move-result v2

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->jm()I

    move-result v3

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->ANMGZc()I

    move-result v4

    add-int/2addr v3, v4

    iget v4, v0, Landroid/view/ViewGroup$MarginLayoutParams;->leftMargin:I

    add-int/2addr v3, v4

    iget v4, v0, Landroid/view/ViewGroup$MarginLayoutParams;->rightMargin:I

    add-int/2addr v3, v4

    add-int/2addr v3, p2

    iget p2, v0, Landroid/view/ViewGroup$MarginLayoutParams;->width:I

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->VA()Z

    move-result v4

    invoke-static {v1, v2, v3, p2, v4}, Landroidx/recyclerview/widget/RecyclerView$qGY;->cMLeY(IIIIZ)I

    move-result p2

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->JYgkl()I

    move-result v1

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->JrJO()I

    move-result v2

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->dm()I

    move-result v3

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->JBhc()I

    move-result v4

    add-int/2addr v3, v4

    iget v4, v0, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    add-int/2addr v3, v4

    iget v4, v0, Landroid/view/ViewGroup$MarginLayoutParams;->bottomMargin:I

    add-int/2addr v3, v4

    add-int/2addr v3, p3

    iget p3, v0, Landroid/view/ViewGroup$MarginLayoutParams;->height:I

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->MiMN()Z

    move-result v4

    invoke-static {v1, v2, v3, p3, v4}, Landroidx/recyclerview/widget/RecyclerView$qGY;->cMLeY(IIIIZ)I

    move-result p3

    invoke-virtual {p0, p1, p2, p3, v0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->yP(Landroid/view/View;IILandroidx/recyclerview/widget/RecyclerView$fehf;)Z

    move-result p0

    if-eqz p0, :cond_0

    invoke-virtual {p1, p2, p3}, Landroid/view/View;->measure(II)V

    :cond_0
    return-void
.end method

.method public Xxz(Landroidx/recyclerview/widget/RecyclerView$VocHEe;)V
    .locals 0

    return-void
.end method

.method public YoKzxo(Landroidx/recyclerview/widget/RecyclerView$fehf;)Z
    .locals 0

    if-eqz p1, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method

.method public Zdbk(Landroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;II)V
    .locals 0

    iget-object p0, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->AZxh:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {p0, p3, p4}, Landroidx/recyclerview/widget/RecyclerView;->VocHEe(II)V

    return-void
.end method

.method public ZfxDd(Landroid/view/View;I)V
    .locals 1

    const/4 v0, 0x1

    invoke-virtual {p0, p1, p2, v0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->xJ(Landroid/view/View;IZ)V

    return-void
.end method

.method public alEkx()I
    .locals 0

    iget-object p0, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->AZxh:Landroidx/recyclerview/widget/RecyclerView;

    if-eqz p0, :cond_0

    invoke-static {p0}, Lo/T9;->BAnRFn(Landroid/view/View;)I

    move-result p0

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method

.method public aqHPIZ(Landroid/view/View;)I
    .locals 1

    invoke-virtual {p1}, Landroid/view/View;->getLeft()I

    move-result v0

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/RecyclerView$qGY;->XV(Landroid/view/View;)I

    move-result p0

    sub-int/2addr v0, p0

    return v0
.end method

.method public bbzow()I
    .locals 0

    iget-object p0, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->AZxh:Landroidx/recyclerview/widget/RecyclerView;

    invoke-static {p0}, Lo/T9;->Gd(Landroid/view/View;)I

    move-result p0

    return p0
.end method

.method public bc(II)V
    .locals 8

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->zvd()I

    move-result v0

    if-nez v0, :cond_0

    iget-object p0, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->AZxh:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {p0, p1, p2}, Landroidx/recyclerview/widget/RecyclerView;->VocHEe(II)V

    return-void

    :cond_0
    const/high16 v1, -0x80000000

    const v2, 0x7fffffff

    const/4 v3, 0x0

    move v4, v2

    move v5, v3

    move v2, v1

    move v3, v4

    :goto_0
    if-ge v5, v0, :cond_5

    invoke-virtual {p0, v5}, Landroidx/recyclerview/widget/RecyclerView$qGY;->KLMXS(I)Landroid/view/View;

    move-result-object v6

    iget-object v7, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->AZxh:Landroidx/recyclerview/widget/RecyclerView;

    iget-object v7, v7, Landroidx/recyclerview/widget/RecyclerView;->Dt:Landroid/graphics/Rect;

    invoke-virtual {p0, v6, v7}, Landroidx/recyclerview/widget/RecyclerView$qGY;->oCFDzJ(Landroid/view/View;Landroid/graphics/Rect;)V

    iget v6, v7, Landroid/graphics/Rect;->left:I

    if-ge v6, v3, :cond_1

    move v3, v6

    :cond_1
    iget v6, v7, Landroid/graphics/Rect;->right:I

    if-le v6, v1, :cond_2

    move v1, v6

    :cond_2
    iget v6, v7, Landroid/graphics/Rect;->top:I

    if-ge v6, v4, :cond_3

    move v4, v6

    :cond_3
    iget v6, v7, Landroid/graphics/Rect;->bottom:I

    if-le v6, v2, :cond_4

    move v2, v6

    :cond_4
    add-int/lit8 v5, v5, 0x1

    goto :goto_0

    :cond_5
    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->AZxh:Landroidx/recyclerview/widget/RecyclerView;

    iget-object v0, v0, Landroidx/recyclerview/widget/RecyclerView;->Dt:Landroid/graphics/Rect;

    invoke-virtual {v0, v3, v4, v1, v2}, Landroid/graphics/Rect;->set(IIII)V

    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->AZxh:Landroidx/recyclerview/widget/RecyclerView;

    iget-object v0, v0, Landroidx/recyclerview/widget/RecyclerView;->Dt:Landroid/graphics/Rect;

    invoke-virtual {p0, v0, p1, p2}, Landroidx/recyclerview/widget/RecyclerView$qGY;->xCVa(Landroid/graphics/Rect;II)V

    return-void
.end method

.method public abstract dGDT(Landroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;)V
.end method

.method public abstract diqgf(Landroidx/recyclerview/widget/RecyclerView$VocHEe;)I
.end method

.method public dkKKW()Landroid/os/Parcelable;
    .locals 0

    const/4 p0, 0x0

    return-object p0
.end method

.method public dm()I
    .locals 0

    iget-object p0, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->AZxh:Landroidx/recyclerview/widget/RecyclerView;

    if-eqz p0, :cond_0

    invoke-virtual {p0}, Landroid/view/View;->getPaddingTop()I

    move-result p0

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method

.method public eQ(Landroidx/recyclerview/widget/RecyclerView;II)V
    .locals 0

    return-void
.end method

.method public eyqo(Landroidx/recyclerview/widget/RecyclerView$VocHEe;)I
    .locals 0

    const/4 p0, 0x0

    return p0
.end method

.method public fFz()Z
    .locals 0

    iget-object p0, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->xJ:Landroidx/recyclerview/widget/RecyclerView$vI;

    if-eqz p0, :cond_0

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$vI;->lgHUyS()Z

    move-result p0

    if-eqz p0, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method

.method public fLidf(Landroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;Landroid/view/accessibility/AccessibilityEvent;)V
    .locals 1

    iget-object p1, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->AZxh:Landroidx/recyclerview/widget/RecyclerView;

    if-eqz p1, :cond_3

    if-nez p3, :cond_0

    goto :goto_1

    :cond_0
    const/4 p2, 0x1

    invoke-virtual {p1, p2}, Landroid/view/View;->canScrollVertically(I)Z

    move-result p1

    if-nez p1, :cond_2

    iget-object p1, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->AZxh:Landroidx/recyclerview/widget/RecyclerView;

    const/4 v0, -0x1

    invoke-virtual {p1, v0}, Landroid/view/View;->canScrollVertically(I)Z

    move-result p1

    if-nez p1, :cond_2

    iget-object p1, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->AZxh:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {p1, v0}, Landroid/view/View;->canScrollHorizontally(I)Z

    move-result p1

    if-nez p1, :cond_2

    iget-object p1, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->AZxh:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {p1, p2}, Landroid/view/View;->canScrollHorizontally(I)Z

    move-result p1

    if-eqz p1, :cond_1

    goto :goto_0

    :cond_1
    const/4 p2, 0x0

    :cond_2
    :goto_0
    invoke-virtual {p3, p2}, Landroid/view/accessibility/AccessibilityRecord;->setScrollable(Z)V

    iget-object p0, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->AZxh:Landroidx/recyclerview/widget/RecyclerView;

    iget-object p0, p0, Landroidx/recyclerview/widget/RecyclerView;->MiMN:Landroidx/recyclerview/widget/RecyclerView$lgHUyS;

    if-eqz p0, :cond_3

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$lgHUyS;->ZfxDd()I

    move-result p0

    invoke-virtual {p3, p0}, Landroid/view/accessibility/AccessibilityRecord;->setItemCount(I)V

    :cond_3
    :goto_1
    return-void
.end method

.method public fehf(ILandroidx/recyclerview/widget/RecyclerView$qGY$wA;)V
    .locals 0

    return-void
.end method

.method public gYa(Landroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;)Z
    .locals 0

    const/4 p0, 0x0

    return p0
.end method

.method public giT(Landroidx/recyclerview/widget/RecyclerView;)V
    .locals 0

    return-void
.end method

.method public gtIJp()Z
    .locals 0

    iget-boolean p0, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->qdMbNW:Z

    return p0
.end method

.method public gtr(Landroid/view/View;ILandroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;)Landroid/view/View;
    .locals 0

    const/4 p0, 0x0

    return-object p0
.end method

.method public huTpC(Landroidx/recyclerview/widget/RecyclerView$VocHEe;)I
    .locals 0

    const/4 p0, 0x0

    return p0
.end method

.method public hvGY(Landroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;Lo/Ucbh;)V
    .locals 3

    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->AZxh:Landroidx/recyclerview/widget/RecyclerView;

    const/4 v1, -0x1

    invoke-virtual {v0, v1}, Landroid/view/View;->canScrollVertically(I)Z

    move-result v0

    const/4 v2, 0x1

    if-nez v0, :cond_0

    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->AZxh:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {v0, v1}, Landroid/view/View;->canScrollHorizontally(I)Z

    move-result v0

    if-eqz v0, :cond_1

    :cond_0
    const/16 v0, 0x2000

    invoke-virtual {p3, v0}, Lo/Ucbh;->mjFkc(I)V

    invoke-virtual {p3, v2}, Lo/Ucbh;->kism(Z)V

    :cond_1
    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->AZxh:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {v0, v2}, Landroid/view/View;->canScrollVertically(I)Z

    move-result v0

    if-nez v0, :cond_2

    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->AZxh:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {v0, v2}, Landroid/view/View;->canScrollHorizontally(I)Z

    move-result v0

    if-eqz v0, :cond_3

    :cond_2
    const/16 v0, 0x1000

    invoke-virtual {p3, v0}, Lo/Ucbh;->mjFkc(I)V

    invoke-virtual {p3, v2}, Lo/Ucbh;->kism(Z)V

    :cond_3
    invoke-virtual {p0, p1, p2}, Landroidx/recyclerview/widget/RecyclerView$qGY;->xROA(Landroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;)I

    move-result v0

    invoke-virtual {p0, p1, p2}, Landroidx/recyclerview/widget/RecyclerView$qGY;->NPj(Landroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;)I

    move-result v1

    invoke-virtual {p0, p1, p2}, Landroidx/recyclerview/widget/RecyclerView$qGY;->gYa(Landroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;)Z

    move-result v2

    invoke-virtual {p0, p1, p2}, Landroidx/recyclerview/widget/RecyclerView$qGY;->IVlxe(Landroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;)I

    move-result p0

    invoke-static {v0, v1, v2, p0}, Lo/Ucbh$KLFTb;->mjFkc(IIZI)Lo/Ucbh$KLFTb;

    move-result-object p0

    invoke-virtual {p3, p0}, Lo/Ucbh;->JBhc(Ljava/lang/Object;)V

    return-void
.end method

.method public jm()I
    .locals 0

    iget-object p0, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->AZxh:Landroidx/recyclerview/widget/RecyclerView;

    if-eqz p0, :cond_0

    invoke-virtual {p0}, Landroid/view/View;->getPaddingLeft()I

    move-result p0

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method

.method public jtz(Landroidx/recyclerview/widget/RecyclerView;III)V
    .locals 0

    return-void
.end method

.method public jx(II)V
    .locals 2

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/RecyclerView$qGY;->KLMXS(I)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/RecyclerView$qGY;->HGpJ(I)V

    invoke-virtual {p0, v0, p2}, Landroidx/recyclerview/widget/RecyclerView$qGY;->qdMbNW(Landroid/view/View;I)V

    return-void

    :cond_0
    new-instance p2, Ljava/lang/IllegalArgumentException;

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "Cannot move a child from non-existing index:"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    iget-object p0, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->AZxh:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {p2, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p2
.end method

.method public kism()Z
    .locals 0

    iget-boolean p0, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->Dt:Z

    return p0
.end method

.method public knzZ(Landroid/view/View;ILandroid/os/Bundle;)Z
    .locals 7

    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->AZxh:Landroidx/recyclerview/widget/RecyclerView;

    iget-object v2, v0, Landroidx/recyclerview/widget/RecyclerView;->wA:Landroidx/recyclerview/widget/RecyclerView$Ucbh;

    iget-object v3, v0, Landroidx/recyclerview/widget/RecyclerView;->Vdz:Landroidx/recyclerview/widget/RecyclerView$VocHEe;

    move-object v1, p0

    move-object v4, p1

    move v5, p2

    move-object v6, p3

    invoke-virtual/range {v1 .. v6}, Landroidx/recyclerview/widget/RecyclerView$qGY;->ybBTr(Landroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;Landroid/view/View;ILandroid/os/Bundle;)Z

    move-result p0

    return p0
.end method

.method public lB(Landroid/view/View;)Landroid/view/View;
    .locals 2

    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->AZxh:Landroidx/recyclerview/widget/RecyclerView;

    const/4 v1, 0x0

    if-nez v0, :cond_0

    return-object v1

    :cond_0
    invoke-virtual {v0, p1}, Landroidx/recyclerview/widget/RecyclerView;->uHVRx(Landroid/view/View;)Landroid/view/View;

    move-result-object p1

    if-nez p1, :cond_1

    return-object v1

    :cond_1
    iget-object p0, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->mjFkc:Landroidx/recyclerview/widget/AZxh;

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/AZxh;->YoKzxo(Landroid/view/View;)Z

    move-result p0

    if-eqz p0, :cond_2

    return-object v1

    :cond_2
    return-object p1
.end method

.method public lgHUyS(Ljava/lang/String;)V
    .locals 0

    iget-object p0, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->AZxh:Landroidx/recyclerview/widget/RecyclerView;

    if-eqz p0, :cond_0

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/RecyclerView;->qGY(Ljava/lang/String;)V

    :cond_0
    return-void
.end method

.method public lti(Landroidx/recyclerview/widget/RecyclerView;Ljava/util/ArrayList;II)Z
    .locals 0

    const/4 p0, 0x0

    return p0
.end method

.method public abstract mByQ()Landroidx/recyclerview/widget/RecyclerView$fehf;
.end method

.method public mPWV(Landroid/os/Parcelable;)V
    .locals 0

    return-void
.end method

.method public mzUGzO()V
    .locals 0

    iget-object p0, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->AZxh:Landroidx/recyclerview/widget/RecyclerView;

    if-eqz p0, :cond_0

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView;->requestLayout()V

    :cond_0
    return-void
.end method

.method public nUaNy(II)V
    .locals 1

    invoke-static {p1}, Landroid/view/View$MeasureSpec;->getSize(I)I

    move-result v0

    iput v0, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->fehf:I

    invoke-static {p1}, Landroid/view/View$MeasureSpec;->getMode(I)I

    move-result p1

    iput p1, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->rkYL:I

    const/4 v0, 0x0

    if-nez p1, :cond_0

    sget-boolean p1, Landroidx/recyclerview/widget/RecyclerView;->XtE:Z

    if-nez p1, :cond_0

    iput v0, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->fehf:I

    :cond_0
    invoke-static {p2}, Landroid/view/View$MeasureSpec;->getSize(I)I

    move-result p1

    iput p1, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->IEE:I

    invoke-static {p2}, Landroid/view/View$MeasureSpec;->getMode(I)I

    move-result p1

    iput p1, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->qGY:I

    if-nez p1, :cond_1

    sget-boolean p1, Landroidx/recyclerview/widget/RecyclerView;->XtE:Z

    if-nez p1, :cond_1

    iput v0, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->IEE:I

    :cond_1
    return-void
.end method

.method public nxI()I
    .locals 0

    iget-object p0, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->AZxh:Landroidx/recyclerview/widget/RecyclerView;

    if-eqz p0, :cond_0

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView;->getAdapter()Landroidx/recyclerview/widget/RecyclerView$lgHUyS;

    move-result-object p0

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    if-eqz p0, :cond_1

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$lgHUyS;->ZfxDd()I

    move-result p0

    goto :goto_1

    :cond_1
    const/4 p0, 0x0

    :goto_1
    return p0
.end method

.method public oCFDzJ(Landroid/view/View;Landroid/graphics/Rect;)V
    .locals 0

    invoke-static {p1, p2}, Landroidx/recyclerview/widget/RecyclerView;->tQ(Landroid/view/View;Landroid/graphics/Rect;)V

    return-void
.end method

.method public oVXlhB(Landroid/view/View;)V
    .locals 0

    iget-object p0, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->mjFkc:Landroidx/recyclerview/widget/AZxh;

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/AZxh;->qGY(Landroid/view/View;)V

    return-void
.end method

.method public oaI(Landroidx/recyclerview/widget/RecyclerView$Ucbh;)V
    .locals 6

    invoke-virtual {p1}, Landroidx/recyclerview/widget/RecyclerView$Ucbh;->Dt()I

    move-result v0

    add-int/lit8 v1, v0, -0x1

    :goto_0
    if-ltz v1, :cond_3

    invoke-virtual {p1, v1}, Landroidx/recyclerview/widget/RecyclerView$Ucbh;->YoKzxo(I)Landroid/view/View;

    move-result-object v2

    invoke-static {v2}, Landroidx/recyclerview/widget/RecyclerView;->dm(Landroid/view/View;)Landroidx/recyclerview/widget/RecyclerView$mByQ;

    move-result-object v3

    invoke-virtual {v3}, Landroidx/recyclerview/widget/RecyclerView$mByQ;->KLMXS()Z

    move-result v4

    if-eqz v4, :cond_0

    goto :goto_1

    :cond_0
    const/4 v4, 0x0

    invoke-virtual {v3, v4}, Landroidx/recyclerview/widget/RecyclerView$mByQ;->Ne(Z)V

    invoke-virtual {v3}, Landroidx/recyclerview/widget/RecyclerView$mByQ;->Gd()Z

    move-result v5

    if-eqz v5, :cond_1

    iget-object v5, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->AZxh:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {v5, v2, v4}, Landroidx/recyclerview/widget/RecyclerView;->removeDetachedView(Landroid/view/View;Z)V

    :cond_1
    iget-object v4, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->AZxh:Landroidx/recyclerview/widget/RecyclerView;

    iget-object v4, v4, Landroidx/recyclerview/widget/RecyclerView;->Vnb:Landroidx/recyclerview/widget/RecyclerView$MiMN;

    if-eqz v4, :cond_2

    invoke-virtual {v4, v3}, Landroidx/recyclerview/widget/RecyclerView$MiMN;->Dt(Landroidx/recyclerview/widget/RecyclerView$mByQ;)V

    :cond_2
    const/4 v4, 0x1

    invoke-virtual {v3, v4}, Landroidx/recyclerview/widget/RecyclerView$mByQ;->Ne(Z)V

    invoke-virtual {p1, v2}, Landroidx/recyclerview/widget/RecyclerView$Ucbh;->wJVbdd(Landroid/view/View;)V

    :goto_1
    add-int/lit8 v1, v1, -0x1

    goto :goto_0

    :cond_3
    invoke-virtual {p1}, Landroidx/recyclerview/widget/RecyclerView$Ucbh;->KLFTb()V

    if-lez v0, :cond_4

    iget-object p0, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->AZxh:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {p0}, Landroid/view/View;->invalidate()V

    :cond_4
    return-void
.end method

.method public qGY(IILandroidx/recyclerview/widget/RecyclerView$VocHEe;Landroidx/recyclerview/widget/RecyclerView$qGY$wA;)V
    .locals 0

    return-void
.end method

.method public abstract qGgY(Landroidx/recyclerview/widget/RecyclerView;Landroidx/recyclerview/widget/RecyclerView$VocHEe;I)V
.end method

.method public qdMbNW(Landroid/view/View;I)V
    .locals 1

    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    check-cast v0, Landroidx/recyclerview/widget/RecyclerView$fehf;

    invoke-virtual {p0, p1, p2, v0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->Dt(Landroid/view/View;ILandroidx/recyclerview/widget/RecyclerView$fehf;)V

    return-void
.end method

.method public final rWxwaT(Landroid/view/View;Landroid/graphics/Rect;)[I
    .locals 7

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->jm()I

    move-result v0

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->dm()I

    move-result v1

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->SOS()I

    move-result v2

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->ANMGZc()I

    move-result v3

    sub-int/2addr v2, v3

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->JYgkl()I

    move-result v3

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->JBhc()I

    move-result v4

    sub-int/2addr v3, v4

    invoke-virtual {p1}, Landroid/view/View;->getLeft()I

    move-result v4

    iget v5, p2, Landroid/graphics/Rect;->left:I

    add-int/2addr v4, v5

    invoke-virtual {p1}, Landroid/view/View;->getScrollX()I

    move-result v5

    sub-int/2addr v4, v5

    invoke-virtual {p1}, Landroid/view/View;->getTop()I

    move-result v5

    iget v6, p2, Landroid/graphics/Rect;->top:I

    add-int/2addr v5, v6

    invoke-virtual {p1}, Landroid/view/View;->getScrollY()I

    move-result p1

    sub-int/2addr v5, p1

    invoke-virtual {p2}, Landroid/graphics/Rect;->width()I

    move-result p1

    add-int/2addr p1, v4

    invoke-virtual {p2}, Landroid/graphics/Rect;->height()I

    move-result p2

    add-int/2addr p2, v5

    sub-int/2addr v4, v0

    const/4 v0, 0x0

    invoke-static {v0, v4}, Ljava/lang/Math;->min(II)I

    move-result v6

    sub-int/2addr v5, v1

    invoke-static {v0, v5}, Ljava/lang/Math;->min(II)I

    move-result v1

    sub-int/2addr p1, v2

    invoke-static {v0, p1}, Ljava/lang/Math;->max(II)I

    move-result v2

    sub-int/2addr p2, v3

    invoke-static {v0, p2}, Ljava/lang/Math;->max(II)I

    move-result p2

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->WGXroI()I

    move-result p0

    const/4 v0, 0x1

    if-ne p0, v0, :cond_1

    if-eqz v2, :cond_0

    goto :goto_1

    :cond_0
    invoke-static {v6, p1}, Ljava/lang/Math;->max(II)I

    move-result v2

    goto :goto_1

    :cond_1
    if-eqz v6, :cond_2

    goto :goto_0

    :cond_2
    invoke-static {v4, v2}, Ljava/lang/Math;->min(II)I

    move-result v6

    :goto_0
    move v2, v6

    :goto_1
    if-eqz v1, :cond_3

    goto :goto_2

    :cond_3
    invoke-static {v5, p2}, Ljava/lang/Math;->min(II)I

    move-result v1

    :goto_2
    filled-new-array {v2, v1}, [I

    move-result-object p0

    return-object p0
.end method

.method public rdJr(Landroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;Landroid/view/View;Lo/Ucbh;)V
    .locals 0

    return-void
.end method

.method public sRqPfw(Landroidx/recyclerview/widget/RecyclerView;)V
    .locals 0

    return-void
.end method

.method public sqndV(Landroidx/recyclerview/widget/RecyclerView$Ucbh;)V
    .locals 2

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->zvd()I

    move-result v0

    add-int/lit8 v0, v0, -0x1

    :goto_0
    if-ltz v0, :cond_1

    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->KLMXS(I)Landroid/view/View;

    move-result-object v1

    invoke-static {v1}, Landroidx/recyclerview/widget/RecyclerView;->dm(Landroid/view/View;)Landroidx/recyclerview/widget/RecyclerView$mByQ;

    move-result-object v1

    invoke-virtual {v1}, Landroidx/recyclerview/widget/RecyclerView$mByQ;->KLMXS()Z

    move-result v1

    if-nez v1, :cond_0

    invoke-virtual {p0, v0, p1}, Landroidx/recyclerview/widget/RecyclerView$qGY;->Vu(ILandroidx/recyclerview/widget/RecyclerView$Ucbh;)V

    :cond_0
    add-int/lit8 v0, v0, -0x1

    goto :goto_0

    :cond_1
    return-void
.end method

.method public tAfC(Landroidx/recyclerview/widget/RecyclerView;IILjava/lang/Object;)V
    .locals 0

    invoke-virtual {p0, p1, p2, p3}, Landroidx/recyclerview/widget/RecyclerView$qGY;->IyS(Landroidx/recyclerview/widget/RecyclerView;II)V

    return-void
.end method

.method public tISON(I)V
    .locals 0

    iget-object p0, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->AZxh:Landroidx/recyclerview/widget/RecyclerView;

    if-eqz p0, :cond_0

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/RecyclerView;->uH(I)V

    :cond_0
    return-void
.end method

.method public tQ(Landroid/view/View;)I
    .locals 0

    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object p0

    check-cast p0, Landroidx/recyclerview/widget/RecyclerView$fehf;

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$fehf;->mjFkc()I

    move-result p0

    return p0
.end method

.method public final tjSezt(Landroidx/recyclerview/widget/RecyclerView;II)Z
    .locals 6

    invoke-virtual {p1}, Landroid/view/ViewGroup;->getFocusedChild()Landroid/view/View;

    move-result-object p1

    const/4 v0, 0x0

    if-nez p1, :cond_0

    return v0

    :cond_0
    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->jm()I

    move-result v1

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->dm()I

    move-result v2

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->SOS()I

    move-result v3

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->ANMGZc()I

    move-result v4

    sub-int/2addr v3, v4

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->JYgkl()I

    move-result v4

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->JBhc()I

    move-result v5

    sub-int/2addr v4, v5

    iget-object v5, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->AZxh:Landroidx/recyclerview/widget/RecyclerView;

    iget-object v5, v5, Landroidx/recyclerview/widget/RecyclerView;->Dt:Landroid/graphics/Rect;

    invoke-virtual {p0, p1, v5}, Landroidx/recyclerview/widget/RecyclerView$qGY;->oCFDzJ(Landroid/view/View;Landroid/graphics/Rect;)V

    iget p0, v5, Landroid/graphics/Rect;->left:I

    sub-int/2addr p0, p2

    if-ge p0, v3, :cond_2

    iget p0, v5, Landroid/graphics/Rect;->right:I

    sub-int/2addr p0, p2

    if-le p0, v1, :cond_2

    iget p0, v5, Landroid/graphics/Rect;->top:I

    sub-int/2addr p0, p3

    if-ge p0, v4, :cond_2

    iget p0, v5, Landroid/graphics/Rect;->bottom:I

    sub-int/2addr p0, p3

    if-gt p0, v2, :cond_1

    goto :goto_0

    :cond_1
    const/4 p0, 0x1

    return p0

    :cond_2
    :goto_0
    return v0
.end method

.method public tpGcn(Landroid/view/View;IILandroidx/recyclerview/widget/RecyclerView$fehf;)Z
    .locals 1

    iget-boolean p0, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->ETF:Z

    if-eqz p0, :cond_1

    invoke-virtual {p1}, Landroid/view/View;->getMeasuredWidth()I

    move-result p0

    iget v0, p4, Landroid/view/ViewGroup$MarginLayoutParams;->width:I

    invoke-static {p0, p2, v0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->LREOK(III)Z

    move-result p0

    if-eqz p0, :cond_1

    invoke-virtual {p1}, Landroid/view/View;->getMeasuredHeight()I

    move-result p0

    iget p1, p4, Landroid/view/ViewGroup$MarginLayoutParams;->height:I

    invoke-static {p0, p3, p1}, Landroidx/recyclerview/widget/RecyclerView$qGY;->LREOK(III)Z

    move-result p0

    if-nez p0, :cond_0

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    goto :goto_1

    :cond_1
    :goto_0
    const/4 p0, 0x1

    :goto_1
    return p0
.end method

.method public uH(I)V
    .locals 0

    iget-object p0, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->AZxh:Landroidx/recyclerview/widget/RecyclerView;

    if-eqz p0, :cond_0

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/RecyclerView;->jx(I)V

    :cond_0
    return-void
.end method

.method public uHVRx(Landroid/view/View;)I
    .locals 1

    invoke-virtual {p1}, Landroid/view/View;->getTop()I

    move-result v0

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/RecyclerView$qGY;->Moer(Landroid/view/View;)I

    move-result p0

    sub-int/2addr v0, p0

    return v0
.end method

.method public ub(II)V
    .locals 0

    iget-object p0, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->AZxh:Landroidx/recyclerview/widget/RecyclerView;

    invoke-static {p0, p1, p2}, Landroidx/recyclerview/widget/RecyclerView;->xJ(Landroidx/recyclerview/widget/RecyclerView;II)V

    return-void
.end method

.method public ui()Z
    .locals 0

    const/4 p0, 0x0

    return p0
.end method

.method public uxlM(Ljava/lang/Runnable;)Z
    .locals 0

    iget-object p0, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->AZxh:Landroidx/recyclerview/widget/RecyclerView;

    if-eqz p0, :cond_0

    invoke-virtual {p0, p1}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    move-result p0

    return p0

    :cond_0
    const/4 p0, 0x0

    return p0
.end method

.method public final vI(ILandroid/view/View;)V
    .locals 0

    iget-object p0, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->mjFkc:Landroidx/recyclerview/widget/AZxh;

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/AZxh;->ZfxDd(I)V

    return-void
.end method

.method public vUsV(Landroidx/recyclerview/widget/RecyclerView$vI;)V
    .locals 1

    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->xJ:Landroidx/recyclerview/widget/RecyclerView$vI;

    if-eqz v0, :cond_0

    if-eq p1, v0, :cond_0

    invoke-virtual {v0}, Landroidx/recyclerview/widget/RecyclerView$vI;->lgHUyS()Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->xJ:Landroidx/recyclerview/widget/RecyclerView$vI;

    invoke-virtual {v0}, Landroidx/recyclerview/widget/RecyclerView$vI;->IEE()V

    :cond_0
    iput-object p1, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->xJ:Landroidx/recyclerview/widget/RecyclerView$vI;

    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->AZxh:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {p1, v0, p0}, Landroidx/recyclerview/widget/RecyclerView$vI;->fehf(Landroidx/recyclerview/widget/RecyclerView;Landroidx/recyclerview/widget/RecyclerView$qGY;)V

    return-void
.end method

.method public vadzgd(Landroid/view/View;)I
    .locals 1

    invoke-virtual {p1}, Landroid/view/View;->getBottom()I

    move-result v0

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/RecyclerView$qGY;->xrEuO(Landroid/view/View;)I

    move-result p0

    add-int/2addr v0, p0

    return v0
.end method

.method public vjlshU(Landroid/view/View;)I
    .locals 0

    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object p0

    check-cast p0, Landroidx/recyclerview/widget/RecyclerView$fehf;

    iget-object p0, p0, Landroidx/recyclerview/widget/RecyclerView$fehf;->AZxh:Landroid/graphics/Rect;

    iget p0, p0, Landroid/graphics/Rect;->right:I

    return p0
.end method

.method public wA(Landroid/view/View;)V
    .locals 1

    const/4 v0, -0x1

    invoke-virtual {p0, p1, v0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->ZfxDd(Landroid/view/View;I)V

    return-void
.end method

.method public wJVbdd(I)Landroid/view/View;
    .locals 5

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->zvd()I

    move-result v0

    const/4 v1, 0x0

    :goto_0
    if-ge v1, v0, :cond_3

    invoke-virtual {p0, v1}, Landroidx/recyclerview/widget/RecyclerView$qGY;->KLMXS(I)Landroid/view/View;

    move-result-object v2

    invoke-static {v2}, Landroidx/recyclerview/widget/RecyclerView;->dm(Landroid/view/View;)Landroidx/recyclerview/widget/RecyclerView$mByQ;

    move-result-object v3

    if-nez v3, :cond_0

    goto :goto_1

    :cond_0
    invoke-virtual {v3}, Landroidx/recyclerview/widget/RecyclerView$mByQ;->MiMN()I

    move-result v4

    if-ne v4, p1, :cond_2

    invoke-virtual {v3}, Landroidx/recyclerview/widget/RecyclerView$mByQ;->KLMXS()Z

    move-result v4

    if-nez v4, :cond_2

    iget-object v4, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->AZxh:Landroidx/recyclerview/widget/RecyclerView;

    iget-object v4, v4, Landroidx/recyclerview/widget/RecyclerView;->Vdz:Landroidx/recyclerview/widget/RecyclerView$VocHEe;

    invoke-virtual {v4}, Landroidx/recyclerview/widget/RecyclerView$VocHEe;->KLFTb()Z

    move-result v4

    if-nez v4, :cond_1

    invoke-virtual {v3}, Landroidx/recyclerview/widget/RecyclerView$mByQ;->Ucbh()Z

    move-result v3

    if-nez v3, :cond_2

    :cond_1
    return-object v2

    :cond_2
    :goto_1
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_3
    const/4 p0, 0x0

    return-object p0
.end method

.method public wLtdyQ(Landroidx/recyclerview/widget/RecyclerView;)V
    .locals 1

    if-nez p1, :cond_0

    const/4 p1, 0x0

    iput-object p1, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->AZxh:Landroidx/recyclerview/widget/RecyclerView;

    iput-object p1, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->mjFkc:Landroidx/recyclerview/widget/AZxh;

    const/4 p1, 0x0

    iput p1, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->fehf:I

    iput p1, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->IEE:I

    goto :goto_0

    :cond_0
    iput-object p1, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->AZxh:Landroidx/recyclerview/widget/RecyclerView;

    iget-object v0, p1, Landroidx/recyclerview/widget/RecyclerView;->JHa:Landroidx/recyclerview/widget/AZxh;

    iput-object v0, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->mjFkc:Landroidx/recyclerview/widget/AZxh;

    invoke-virtual {p1}, Landroid/view/View;->getWidth()I

    move-result v0

    iput v0, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->fehf:I

    invoke-virtual {p1}, Landroid/view/View;->getHeight()I

    move-result p1

    iput p1, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->IEE:I

    :goto_0
    const/high16 p1, 0x40000000    # 2.0f

    iput p1, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->rkYL:I

    iput p1, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->qGY:I

    return-void
.end method

.method public xCVa(Landroid/graphics/Rect;II)V
    .locals 2

    invoke-virtual {p1}, Landroid/graphics/Rect;->width()I

    move-result v0

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->jm()I

    move-result v1

    add-int/2addr v0, v1

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->ANMGZc()I

    move-result v1

    add-int/2addr v0, v1

    invoke-virtual {p1}, Landroid/graphics/Rect;->height()I

    move-result p1

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->dm()I

    move-result v1

    add-int/2addr p1, v1

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->JBhc()I

    move-result v1

    add-int/2addr p1, v1

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->SwgkN()I

    move-result v1

    invoke-static {p2, v0, v1}, Landroidx/recyclerview/widget/RecyclerView$qGY;->rkYL(III)I

    move-result p2

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->bbzow()I

    move-result v0

    invoke-static {p3, p1, v0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->rkYL(III)I

    move-result p1

    invoke-virtual {p0, p2, p1}, Landroidx/recyclerview/widget/RecyclerView$qGY;->ub(II)V

    return-void
.end method

.method public final xJ(Landroid/view/View;IZ)V
    .locals 4

    invoke-static {p1}, Landroidx/recyclerview/widget/RecyclerView;->dm(Landroid/view/View;)Landroidx/recyclerview/widget/RecyclerView$mByQ;

    move-result-object v0

    if-nez p3, :cond_1

    invoke-virtual {v0}, Landroidx/recyclerview/widget/RecyclerView$mByQ;->Ucbh()Z

    move-result p3

    if-eqz p3, :cond_0

    goto :goto_0

    :cond_0
    iget-object p3, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->AZxh:Landroidx/recyclerview/widget/RecyclerView;

    iget-object p3, p3, Landroidx/recyclerview/widget/RecyclerView;->xJ:Landroidx/recyclerview/widget/qGY;

    invoke-virtual {p3, v0}, Landroidx/recyclerview/widget/qGY;->qGY(Landroidx/recyclerview/widget/RecyclerView$mByQ;)V

    goto :goto_1

    :cond_1
    :goto_0
    iget-object p3, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->AZxh:Landroidx/recyclerview/widget/RecyclerView;

    iget-object p3, p3, Landroidx/recyclerview/widget/RecyclerView;->xJ:Landroidx/recyclerview/widget/qGY;

    invoke-virtual {p3, v0}, Landroidx/recyclerview/widget/qGY;->AZxh(Landroidx/recyclerview/widget/RecyclerView$mByQ;)V

    :goto_1
    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object p3

    check-cast p3, Landroidx/recyclerview/widget/RecyclerView$fehf;

    invoke-virtual {v0}, Landroidx/recyclerview/widget/RecyclerView$mByQ;->cMLeY()Z

    move-result v1

    const/4 v2, 0x0

    if-nez v1, :cond_6

    invoke-virtual {v0}, Landroidx/recyclerview/widget/RecyclerView$mByQ;->huTpC()Z

    move-result v1

    if-eqz v1, :cond_2

    goto :goto_2

    :cond_2
    invoke-virtual {p1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v1

    iget-object v3, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->AZxh:Landroidx/recyclerview/widget/RecyclerView;

    if-ne v1, v3, :cond_5

    iget-object v1, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->mjFkc:Landroidx/recyclerview/widget/AZxh;

    invoke-virtual {v1, p1}, Landroidx/recyclerview/widget/AZxh;->MiMN(Landroid/view/View;)I

    move-result v1

    const/4 v3, -0x1

    if-ne p2, v3, :cond_3

    iget-object p2, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->mjFkc:Landroidx/recyclerview/widget/AZxh;

    invoke-virtual {p2}, Landroidx/recyclerview/widget/AZxh;->xJ()I

    move-result p2

    :cond_3
    if-eq v1, v3, :cond_4

    if-eq v1, p2, :cond_8

    iget-object p0, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->AZxh:Landroidx/recyclerview/widget/RecyclerView;

    iget-object p0, p0, Landroidx/recyclerview/widget/RecyclerView;->YoKzxo:Landroidx/recyclerview/widget/RecyclerView$qGY;

    invoke-virtual {p0, v1, p2}, Landroidx/recyclerview/widget/RecyclerView$qGY;->jx(II)V

    goto :goto_4

    :cond_4
    new-instance p2, Ljava/lang/IllegalStateException;

    new-instance p3, Ljava/lang/StringBuilder;

    invoke-direct {p3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v0, "Added View has RecyclerView as parent but view is not a real child. Unfiltered index:"

    invoke-virtual {p3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->AZxh:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {v0, p1}, Landroid/view/ViewGroup;->indexOfChild(Landroid/view/View;)I

    move-result p1

    invoke-virtual {p3, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    iget-object p0, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->AZxh:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView;->KRTLGT()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p3, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {p2, p0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p2

    :cond_5
    iget-object v1, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->mjFkc:Landroidx/recyclerview/widget/AZxh;

    invoke-virtual {v1, p1, p2, v2}, Landroidx/recyclerview/widget/AZxh;->mjFkc(Landroid/view/View;IZ)V

    const/4 p2, 0x1

    iput-boolean p2, p3, Landroidx/recyclerview/widget/RecyclerView$fehf;->wA:Z

    iget-object p2, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->xJ:Landroidx/recyclerview/widget/RecyclerView$vI;

    if-eqz p2, :cond_8

    invoke-virtual {p2}, Landroidx/recyclerview/widget/RecyclerView$vI;->lgHUyS()Z

    move-result p2

    if-eqz p2, :cond_8

    iget-object p0, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->xJ:Landroidx/recyclerview/widget/RecyclerView$vI;

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/RecyclerView$vI;->ETF(Landroid/view/View;)V

    goto :goto_4

    :cond_6
    :goto_2
    invoke-virtual {v0}, Landroidx/recyclerview/widget/RecyclerView$mByQ;->huTpC()Z

    move-result v1

    if-eqz v1, :cond_7

    invoke-virtual {v0}, Landroidx/recyclerview/widget/RecyclerView$mByQ;->zvd()V

    goto :goto_3

    :cond_7
    invoke-virtual {v0}, Landroidx/recyclerview/widget/RecyclerView$mByQ;->KLFTb()V

    :goto_3
    iget-object p0, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->mjFkc:Landroidx/recyclerview/widget/AZxh;

    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v1

    invoke-virtual {p0, p1, p2, v1, v2}, Landroidx/recyclerview/widget/AZxh;->wA(Landroid/view/View;ILandroid/view/ViewGroup$LayoutParams;Z)V

    :cond_8
    :goto_4
    iget-boolean p0, p3, Landroidx/recyclerview/widget/RecyclerView$fehf;->ZfxDd:Z

    if-eqz p0, :cond_a

    sget-boolean p0, Landroidx/recyclerview/widget/RecyclerView;->LREOK:Z

    if-eqz p0, :cond_9

    new-instance p0, Ljava/lang/StringBuilder;

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    const-string p1, "consuming pending invalidate on child "

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object p1, p3, Landroidx/recyclerview/widget/RecyclerView$fehf;->mjFkc:Landroidx/recyclerview/widget/RecyclerView$mByQ;

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const-string p1, "RecyclerView"

    invoke-static {p1, p0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    :cond_9
    iget-object p0, v0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->mjFkc:Landroid/view/View;

    invoke-virtual {p0}, Landroid/view/View;->invalidate()V

    iput-boolean v2, p3, Landroidx/recyclerview/widget/RecyclerView$fehf;->ZfxDd:Z

    :cond_a
    return-void
.end method

.method public xROA(Landroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;)I
    .locals 0

    const/4 p0, -0x1

    return p0
.end method

.method public xrEuO(Landroid/view/View;)I
    .locals 0

    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object p0

    check-cast p0, Landroidx/recyclerview/widget/RecyclerView$fehf;

    iget-object p0, p0, Landroidx/recyclerview/widget/RecyclerView$fehf;->AZxh:Landroid/graphics/Rect;

    iget p0, p0, Landroid/graphics/Rect;->bottom:I

    return p0
.end method

.method public yP(Landroid/view/View;IILandroidx/recyclerview/widget/RecyclerView$fehf;)Z
    .locals 1

    invoke-virtual {p1}, Landroid/view/View;->isLayoutRequested()Z

    move-result v0

    if-nez v0, :cond_1

    iget-boolean p0, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->ETF:Z

    if-eqz p0, :cond_1

    invoke-virtual {p1}, Landroid/view/View;->getWidth()I

    move-result p0

    iget v0, p4, Landroid/view/ViewGroup$MarginLayoutParams;->width:I

    invoke-static {p0, p2, v0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->LREOK(III)Z

    move-result p0

    if-eqz p0, :cond_1

    invoke-virtual {p1}, Landroid/view/View;->getHeight()I

    move-result p0

    iget p1, p4, Landroid/view/ViewGroup$MarginLayoutParams;->height:I

    invoke-static {p0, p3, p1}, Landroidx/recyclerview/widget/RecyclerView$qGY;->LREOK(III)Z

    move-result p0

    if-nez p0, :cond_0

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    goto :goto_1

    :cond_1
    :goto_0
    const/4 p0, 0x1

    :goto_1
    return p0
.end method

.method public final yX()Z
    .locals 0

    iget-boolean p0, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->VA:Z

    return p0
.end method

.method public ybBTr(Landroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;Landroid/view/View;ILandroid/os/Bundle;)Z
    .locals 0

    const/4 p0, 0x0

    return p0
.end method

.method public zvd()I
    .locals 0

    iget-object p0, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->mjFkc:Landroidx/recyclerview/widget/AZxh;

    if-eqz p0, :cond_0

    invoke-virtual {p0}, Landroidx/recyclerview/widget/AZxh;->xJ()I

    move-result p0

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method
