.class public Landroidx/recyclerview/widget/qGY$mjFkc;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/recyclerview/widget/qGY;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "mjFkc"
.end annotation


# static fields
.field public static ZfxDd:Lo/A3;


# instance fields
.field public AZxh:Landroidx/recyclerview/widget/RecyclerView$MiMN$AZxh;

.field public mjFkc:I

.field public wA:Landroidx/recyclerview/widget/RecyclerView$MiMN$AZxh;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    new-instance v0, Lo/C3;

    const/16 v1, 0x14

    invoke-direct {v0, v1}, Lo/C3;-><init>(I)V

    sput-object v0, Landroidx/recyclerview/widget/qGY$mjFkc;->ZfxDd:Lo/A3;

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static AZxh()Landroidx/recyclerview/widget/qGY$mjFkc;
    .locals 1

    sget-object v0, Landroidx/recyclerview/widget/qGY$mjFkc;->ZfxDd:Lo/A3;

    invoke-interface {v0}, Lo/A3;->AZxh()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroidx/recyclerview/widget/qGY$mjFkc;

    if-nez v0, :cond_0

    new-instance v0, Landroidx/recyclerview/widget/qGY$mjFkc;

    invoke-direct {v0}, Landroidx/recyclerview/widget/qGY$mjFkc;-><init>()V

    :cond_0
    return-object v0
.end method

.method public static mjFkc()V
    .locals 1

    :goto_0
    sget-object v0, Landroidx/recyclerview/widget/qGY$mjFkc;->ZfxDd:Lo/A3;

    invoke-interface {v0}, Lo/A3;->AZxh()Ljava/lang/Object;

    move-result-object v0

    if-eqz v0, :cond_0

    goto :goto_0

    :cond_0
    return-void
.end method

.method public static wA(Landroidx/recyclerview/widget/qGY$mjFkc;)V
    .locals 1

    const/4 v0, 0x0

    iput v0, p0, Landroidx/recyclerview/widget/qGY$mjFkc;->mjFkc:I

    const/4 v0, 0x0

    iput-object v0, p0, Landroidx/recyclerview/widget/qGY$mjFkc;->AZxh:Landroidx/recyclerview/widget/RecyclerView$MiMN$AZxh;

    iput-object v0, p0, Landroidx/recyclerview/widget/qGY$mjFkc;->wA:Landroidx/recyclerview/widget/RecyclerView$MiMN$AZxh;

    sget-object v0, Landroidx/recyclerview/widget/qGY$mjFkc;->ZfxDd:Lo/A3;

    invoke-interface {v0, p0}, Lo/A3;->mjFkc(Ljava/lang/Object;)Z

    return-void
.end method
