.class public Landroidx/recyclerview/widget/KLFTb$AZxh;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/recyclerview/widget/RecyclerView$qGY$wA;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/recyclerview/widget/KLFTb;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "AZxh"
.end annotation


# instance fields
.field public AZxh:I

.field public ZfxDd:I

.field public mjFkc:I

.field public wA:[I


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public AZxh()V
    .locals 2

    iget-object v0, p0, Landroidx/recyclerview/widget/KLFTb$AZxh;->wA:[I

    if-eqz v0, :cond_0

    const/4 v1, -0x1

    invoke-static {v0, v1}, Ljava/util/Arrays;->fill([II)V

    :cond_0
    const/4 v0, 0x0

    iput v0, p0, Landroidx/recyclerview/widget/KLFTb$AZxh;->ZfxDd:I

    return-void
.end method

.method public KLFTb(II)V
    .locals 0

    iput p1, p0, Landroidx/recyclerview/widget/KLFTb$AZxh;->mjFkc:I

    iput p2, p0, Landroidx/recyclerview/widget/KLFTb$AZxh;->AZxh:I

    return-void
.end method

.method public ZfxDd(I)Z
    .locals 4

    iget-object v0, p0, Landroidx/recyclerview/widget/KLFTb$AZxh;->wA:[I

    const/4 v1, 0x0

    if-eqz v0, :cond_1

    iget v0, p0, Landroidx/recyclerview/widget/KLFTb$AZxh;->ZfxDd:I

    mul-int/lit8 v0, v0, 0x2

    move v2, v1

    :goto_0
    if-ge v2, v0, :cond_1

    iget-object v3, p0, Landroidx/recyclerview/widget/KLFTb$AZxh;->wA:[I

    aget v3, v3, v2

    if-ne v3, p1, :cond_0

    const/4 p0, 0x1

    return p0

    :cond_0
    add-int/lit8 v2, v2, 0x2

    goto :goto_0

    :cond_1
    return v1
.end method

.method public mjFkc(II)V
    .locals 5

    if-ltz p1, :cond_3

    if-ltz p2, :cond_2

    iget v0, p0, Landroidx/recyclerview/widget/KLFTb$AZxh;->ZfxDd:I

    mul-int/lit8 v1, v0, 0x2

    iget-object v2, p0, Landroidx/recyclerview/widget/KLFTb$AZxh;->wA:[I

    const/4 v3, 0x4

    if-nez v2, :cond_0

    new-array v0, v3, [I

    iput-object v0, p0, Landroidx/recyclerview/widget/KLFTb$AZxh;->wA:[I

    const/4 v2, -0x1

    invoke-static {v0, v2}, Ljava/util/Arrays;->fill([II)V

    goto :goto_0

    :cond_0
    array-length v4, v2

    if-lt v1, v4, :cond_1

    mul-int/2addr v0, v3

    new-array v0, v0, [I

    iput-object v0, p0, Landroidx/recyclerview/widget/KLFTb$AZxh;->wA:[I

    array-length v3, v2

    const/4 v4, 0x0

    invoke-static {v2, v4, v0, v4, v3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    :cond_1
    :goto_0
    iget-object v0, p0, Landroidx/recyclerview/widget/KLFTb$AZxh;->wA:[I

    aput p1, v0, v1

    add-int/lit8 v1, v1, 0x1

    aput p2, v0, v1

    iget p1, p0, Landroidx/recyclerview/widget/KLFTb$AZxh;->ZfxDd:I

    add-int/lit8 p1, p1, 0x1

    iput p1, p0, Landroidx/recyclerview/widget/KLFTb$AZxh;->ZfxDd:I

    return-void

    :cond_2
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string p1, "Pixel distance must be non-negative"

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_3
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string p1, "Layout positions must be non-negative"

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public wA(Landroidx/recyclerview/widget/RecyclerView;Z)V
    .locals 4

    const/4 v0, 0x0

    iput v0, p0, Landroidx/recyclerview/widget/KLFTb$AZxh;->ZfxDd:I

    iget-object v0, p0, Landroidx/recyclerview/widget/KLFTb$AZxh;->wA:[I

    if-eqz v0, :cond_0

    const/4 v1, -0x1

    invoke-static {v0, v1}, Ljava/util/Arrays;->fill([II)V

    :cond_0
    iget-object v0, p1, Landroidx/recyclerview/widget/RecyclerView;->YoKzxo:Landroidx/recyclerview/widget/RecyclerView$qGY;

    iget-object v1, p1, Landroidx/recyclerview/widget/RecyclerView;->MiMN:Landroidx/recyclerview/widget/RecyclerView$lgHUyS;

    if-eqz v1, :cond_3

    if-eqz v0, :cond_3

    invoke-virtual {v0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->yX()Z

    move-result v1

    if-eqz v1, :cond_3

    if-eqz p2, :cond_1

    iget-object v1, p1, Landroidx/recyclerview/widget/RecyclerView;->KLFTb:Landroidx/recyclerview/widget/mjFkc;

    invoke-virtual {v1}, Landroidx/recyclerview/widget/mjFkc;->qGY()Z

    move-result v1

    if-nez v1, :cond_2

    iget-object v1, p1, Landroidx/recyclerview/widget/RecyclerView;->MiMN:Landroidx/recyclerview/widget/RecyclerView$lgHUyS;

    invoke-virtual {v1}, Landroidx/recyclerview/widget/RecyclerView$lgHUyS;->ZfxDd()I

    move-result v1

    invoke-virtual {v0, v1, p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->fehf(ILandroidx/recyclerview/widget/RecyclerView$qGY$wA;)V

    goto :goto_0

    :cond_1
    invoke-virtual {p1}, Landroidx/recyclerview/widget/RecyclerView;->SmIWf()Z

    move-result v1

    if-nez v1, :cond_2

    iget v1, p0, Landroidx/recyclerview/widget/KLFTb$AZxh;->mjFkc:I

    iget v2, p0, Landroidx/recyclerview/widget/KLFTb$AZxh;->AZxh:I

    iget-object v3, p1, Landroidx/recyclerview/widget/RecyclerView;->Vdz:Landroidx/recyclerview/widget/RecyclerView$VocHEe;

    invoke-virtual {v0, v1, v2, v3, p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->qGY(IILandroidx/recyclerview/widget/RecyclerView$VocHEe;Landroidx/recyclerview/widget/RecyclerView$qGY$wA;)V

    :cond_2
    :goto_0
    iget p0, p0, Landroidx/recyclerview/widget/KLFTb$AZxh;->ZfxDd:I

    iget v1, v0, Landroidx/recyclerview/widget/RecyclerView$qGY;->MiMN:I

    if-le p0, v1, :cond_3

    iput p0, v0, Landroidx/recyclerview/widget/RecyclerView$qGY;->MiMN:I

    iput-boolean p2, v0, Landroidx/recyclerview/widget/RecyclerView$qGY;->YoKzxo:Z

    iget-object p0, p1, Landroidx/recyclerview/widget/RecyclerView;->wA:Landroidx/recyclerview/widget/RecyclerView$Ucbh;

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$Ucbh;->vadzgd()V

    :cond_3
    return-void
.end method
