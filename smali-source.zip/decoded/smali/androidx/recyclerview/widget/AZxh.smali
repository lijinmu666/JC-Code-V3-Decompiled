.class public Landroidx/recyclerview/widget/AZxh;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/recyclerview/widget/AZxh$AZxh;,
        Landroidx/recyclerview/widget/AZxh$mjFkc;
    }
.end annotation


# instance fields
.field public final AZxh:Landroidx/recyclerview/widget/AZxh$mjFkc;

.field public final mjFkc:Landroidx/recyclerview/widget/AZxh$AZxh;

.field public final wA:Ljava/util/List;


# direct methods
.method public constructor <init>(Landroidx/recyclerview/widget/AZxh$AZxh;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/recyclerview/widget/AZxh;->mjFkc:Landroidx/recyclerview/widget/AZxh$AZxh;

    new-instance p1, Landroidx/recyclerview/widget/AZxh$mjFkc;

    invoke-direct {p1}, Landroidx/recyclerview/widget/AZxh$mjFkc;-><init>()V

    iput-object p1, p0, Landroidx/recyclerview/widget/AZxh;->AZxh:Landroidx/recyclerview/widget/AZxh$mjFkc;

    new-instance p1, Ljava/util/ArrayList;

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    iput-object p1, p0, Landroidx/recyclerview/widget/AZxh;->wA:Ljava/util/List;

    return-void
.end method


# virtual methods
.method public AZxh(Landroid/view/View;Z)V
    .locals 1

    const/4 v0, -0x1

    invoke-virtual {p0, p1, v0, p2}, Landroidx/recyclerview/widget/AZxh;->mjFkc(Landroid/view/View;IZ)V

    return-void
.end method

.method public Dt()I
    .locals 0

    iget-object p0, p0, Landroidx/recyclerview/widget/AZxh;->mjFkc:Landroidx/recyclerview/widget/AZxh$AZxh;

    invoke-interface {p0}, Landroidx/recyclerview/widget/AZxh$AZxh;->xJ()I

    move-result p0

    return p0
.end method

.method public ETF(Landroid/view/View;)V
    .locals 2

    iget-object v0, p0, Landroidx/recyclerview/widget/AZxh;->mjFkc:Landroidx/recyclerview/widget/AZxh$AZxh;

    invoke-interface {v0, p1}, Landroidx/recyclerview/widget/AZxh$AZxh;->ETF(Landroid/view/View;)I

    move-result v0

    if-ltz v0, :cond_0

    iget-object v1, p0, Landroidx/recyclerview/widget/AZxh;->AZxh:Landroidx/recyclerview/widget/AZxh$mjFkc;

    invoke-virtual {v1, v0}, Landroidx/recyclerview/widget/AZxh$mjFkc;->lgHUyS(I)V

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/AZxh;->VA(Landroid/view/View;)V

    return-void

    :cond_0
    new-instance p0, Ljava/lang/IllegalArgumentException;

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "view is not a child, cannot hide "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public IEE(Landroid/view/View;)Z
    .locals 3

    iget-object v0, p0, Landroidx/recyclerview/widget/AZxh;->mjFkc:Landroidx/recyclerview/widget/AZxh$AZxh;

    invoke-interface {v0, p1}, Landroidx/recyclerview/widget/AZxh$AZxh;->ETF(Landroid/view/View;)I

    move-result v0

    const/4 v1, -0x1

    const/4 v2, 0x1

    if-ne v0, v1, :cond_0

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/AZxh;->diqgf(Landroid/view/View;)Z

    return v2

    :cond_0
    iget-object v1, p0, Landroidx/recyclerview/widget/AZxh;->AZxh:Landroidx/recyclerview/widget/AZxh$mjFkc;

    invoke-virtual {v1, v0}, Landroidx/recyclerview/widget/AZxh$mjFkc;->ZfxDd(I)Z

    move-result v1

    if-eqz v1, :cond_1

    iget-object v1, p0, Landroidx/recyclerview/widget/AZxh;->AZxh:Landroidx/recyclerview/widget/AZxh$mjFkc;

    invoke-virtual {v1, v0}, Landroidx/recyclerview/widget/AZxh$mjFkc;->JHa(I)Z

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/AZxh;->diqgf(Landroid/view/View;)Z

    iget-object p0, p0, Landroidx/recyclerview/widget/AZxh;->mjFkc:Landroidx/recyclerview/widget/AZxh$AZxh;

    invoke-interface {p0, v0}, Landroidx/recyclerview/widget/AZxh$AZxh;->lgHUyS(I)V

    return v2

    :cond_1
    const/4 p0, 0x0

    return p0
.end method

.method public JHa(I)Landroid/view/View;
    .locals 0

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/AZxh;->lgHUyS(I)I

    move-result p1

    iget-object p0, p0, Landroidx/recyclerview/widget/AZxh;->mjFkc:Landroidx/recyclerview/widget/AZxh$AZxh;

    invoke-interface {p0, p1}, Landroidx/recyclerview/widget/AZxh$AZxh;->mjFkc(I)Landroid/view/View;

    move-result-object p0

    return-object p0
.end method

.method public KLFTb(I)Landroid/view/View;
    .locals 5

    iget-object v0, p0, Landroidx/recyclerview/widget/AZxh;->wA:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    const/4 v1, 0x0

    :goto_0
    if-ge v1, v0, :cond_1

    iget-object v2, p0, Landroidx/recyclerview/widget/AZxh;->wA:Ljava/util/List;

    invoke-interface {v2, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/view/View;

    iget-object v3, p0, Landroidx/recyclerview/widget/AZxh;->mjFkc:Landroidx/recyclerview/widget/AZxh$AZxh;

    invoke-interface {v3, v2}, Landroidx/recyclerview/widget/AZxh$AZxh;->wA(Landroid/view/View;)Landroidx/recyclerview/widget/RecyclerView$mByQ;

    move-result-object v3

    invoke-virtual {v3}, Landroidx/recyclerview/widget/RecyclerView$mByQ;->MiMN()I

    move-result v4

    if-ne v4, p1, :cond_0

    invoke-virtual {v3}, Landroidx/recyclerview/widget/RecyclerView$mByQ;->diqgf()Z

    move-result v4

    if-nez v4, :cond_0

    invoke-virtual {v3}, Landroidx/recyclerview/widget/RecyclerView$mByQ;->Ucbh()Z

    move-result v3

    if-nez v3, :cond_0

    return-object v2

    :cond_0
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_1
    const/4 p0, 0x0

    return-object p0
.end method

.method public MiMN(Landroid/view/View;)I
    .locals 2

    iget-object v0, p0, Landroidx/recyclerview/widget/AZxh;->mjFkc:Landroidx/recyclerview/widget/AZxh$AZxh;

    invoke-interface {v0, p1}, Landroidx/recyclerview/widget/AZxh$AZxh;->ETF(Landroid/view/View;)I

    move-result p1

    const/4 v0, -0x1

    if-ne p1, v0, :cond_0

    return v0

    :cond_0
    iget-object v1, p0, Landroidx/recyclerview/widget/AZxh;->AZxh:Landroidx/recyclerview/widget/AZxh$mjFkc;

    invoke-virtual {v1, p1}, Landroidx/recyclerview/widget/AZxh$mjFkc;->ZfxDd(I)Z

    move-result v1

    if-eqz v1, :cond_1

    return v0

    :cond_1
    iget-object p0, p0, Landroidx/recyclerview/widget/AZxh;->AZxh:Landroidx/recyclerview/widget/AZxh$mjFkc;

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/AZxh$mjFkc;->AZxh(I)I

    move-result p0

    sub-int/2addr p1, p0

    return p1
.end method

.method public Pq(Landroid/view/View;)V
    .locals 2

    iget-object v0, p0, Landroidx/recyclerview/widget/AZxh;->mjFkc:Landroidx/recyclerview/widget/AZxh$AZxh;

    invoke-interface {v0, p1}, Landroidx/recyclerview/widget/AZxh$AZxh;->ETF(Landroid/view/View;)I

    move-result v0

    if-ltz v0, :cond_1

    iget-object v1, p0, Landroidx/recyclerview/widget/AZxh;->AZxh:Landroidx/recyclerview/widget/AZxh$mjFkc;

    invoke-virtual {v1, v0}, Landroidx/recyclerview/widget/AZxh$mjFkc;->ZfxDd(I)Z

    move-result v1

    if-eqz v1, :cond_0

    iget-object v1, p0, Landroidx/recyclerview/widget/AZxh;->AZxh:Landroidx/recyclerview/widget/AZxh$mjFkc;

    invoke-virtual {v1, v0}, Landroidx/recyclerview/widget/AZxh$mjFkc;->mjFkc(I)V

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/AZxh;->diqgf(Landroid/view/View;)Z

    return-void

    :cond_0
    new-instance p0, Ljava/lang/RuntimeException;

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "trying to unhide a view that was not hidden"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_1
    new-instance p0, Ljava/lang/IllegalArgumentException;

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "view is not a child, cannot hide "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public final VA(Landroid/view/View;)V
    .locals 1

    iget-object v0, p0, Landroidx/recyclerview/widget/AZxh;->wA:Ljava/util/List;

    invoke-interface {v0, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    iget-object p0, p0, Landroidx/recyclerview/widget/AZxh;->mjFkc:Landroidx/recyclerview/widget/AZxh$AZxh;

    invoke-interface {p0, p1}, Landroidx/recyclerview/widget/AZxh$AZxh;->AZxh(Landroid/view/View;)V

    return-void
.end method

.method public YoKzxo(Landroid/view/View;)Z
    .locals 0

    iget-object p0, p0, Landroidx/recyclerview/widget/AZxh;->wA:Ljava/util/List;

    invoke-interface {p0, p1}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result p0

    return p0
.end method

.method public ZfxDd(I)V
    .locals 1

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/AZxh;->lgHUyS(I)I

    move-result p1

    iget-object v0, p0, Landroidx/recyclerview/widget/AZxh;->AZxh:Landroidx/recyclerview/widget/AZxh$mjFkc;

    invoke-virtual {v0, p1}, Landroidx/recyclerview/widget/AZxh$mjFkc;->JHa(I)Z

    iget-object p0, p0, Landroidx/recyclerview/widget/AZxh;->mjFkc:Landroidx/recyclerview/widget/AZxh$AZxh;

    invoke-interface {p0, p1}, Landroidx/recyclerview/widget/AZxh$AZxh;->ZfxDd(I)V

    return-void
.end method

.method public final diqgf(Landroid/view/View;)Z
    .locals 1

    iget-object v0, p0, Landroidx/recyclerview/widget/AZxh;->wA:Ljava/util/List;

    invoke-interface {v0, p1}, Ljava/util/List;->remove(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object p0, p0, Landroidx/recyclerview/widget/AZxh;->mjFkc:Landroidx/recyclerview/widget/AZxh$AZxh;

    invoke-interface {p0, p1}, Landroidx/recyclerview/widget/AZxh$AZxh;->KLFTb(Landroid/view/View;)V

    const/4 p0, 0x1

    return p0

    :cond_0
    const/4 p0, 0x0

    return p0
.end method

.method public fehf(I)V
    .locals 2

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/AZxh;->lgHUyS(I)I

    move-result p1

    iget-object v0, p0, Landroidx/recyclerview/widget/AZxh;->mjFkc:Landroidx/recyclerview/widget/AZxh$AZxh;

    invoke-interface {v0, p1}, Landroidx/recyclerview/widget/AZxh$AZxh;->mjFkc(I)Landroid/view/View;

    move-result-object v0

    if-nez v0, :cond_0

    return-void

    :cond_0
    iget-object v1, p0, Landroidx/recyclerview/widget/AZxh;->AZxh:Landroidx/recyclerview/widget/AZxh$mjFkc;

    invoke-virtual {v1, p1}, Landroidx/recyclerview/widget/AZxh$mjFkc;->JHa(I)Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/AZxh;->diqgf(Landroid/view/View;)Z

    :cond_1
    iget-object p0, p0, Landroidx/recyclerview/widget/AZxh;->mjFkc:Landroidx/recyclerview/widget/AZxh$AZxh;

    invoke-interface {p0, p1}, Landroidx/recyclerview/widget/AZxh$AZxh;->lgHUyS(I)V

    return-void
.end method

.method public final lgHUyS(I)I
    .locals 4

    const/4 v0, -0x1

    if-gez p1, :cond_0

    return v0

    :cond_0
    iget-object v1, p0, Landroidx/recyclerview/widget/AZxh;->mjFkc:Landroidx/recyclerview/widget/AZxh$AZxh;

    invoke-interface {v1}, Landroidx/recyclerview/widget/AZxh$AZxh;->xJ()I

    move-result v1

    move v2, p1

    :goto_0
    if-ge v2, v1, :cond_3

    iget-object v3, p0, Landroidx/recyclerview/widget/AZxh;->AZxh:Landroidx/recyclerview/widget/AZxh$mjFkc;

    invoke-virtual {v3, v2}, Landroidx/recyclerview/widget/AZxh$mjFkc;->AZxh(I)I

    move-result v3

    sub-int v3, v2, v3

    sub-int v3, p1, v3

    if-nez v3, :cond_2

    :goto_1
    iget-object p1, p0, Landroidx/recyclerview/widget/AZxh;->AZxh:Landroidx/recyclerview/widget/AZxh$mjFkc;

    invoke-virtual {p1, v2}, Landroidx/recyclerview/widget/AZxh$mjFkc;->ZfxDd(I)Z

    move-result p1

    if-eqz p1, :cond_1

    add-int/lit8 v2, v2, 0x1

    goto :goto_1

    :cond_1
    return v2

    :cond_2
    add-int/2addr v2, v3

    goto :goto_0

    :cond_3
    return v0
.end method

.method public mjFkc(Landroid/view/View;IZ)V
    .locals 1

    if-gez p2, :cond_0

    iget-object p2, p0, Landroidx/recyclerview/widget/AZxh;->mjFkc:Landroidx/recyclerview/widget/AZxh$AZxh;

    invoke-interface {p2}, Landroidx/recyclerview/widget/AZxh$AZxh;->xJ()I

    move-result p2

    goto :goto_0

    :cond_0
    invoke-virtual {p0, p2}, Landroidx/recyclerview/widget/AZxh;->lgHUyS(I)I

    move-result p2

    :goto_0
    iget-object v0, p0, Landroidx/recyclerview/widget/AZxh;->AZxh:Landroidx/recyclerview/widget/AZxh$mjFkc;

    invoke-virtual {v0, p2, p3}, Landroidx/recyclerview/widget/AZxh$mjFkc;->KLFTb(IZ)V

    if-eqz p3, :cond_1

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/AZxh;->VA(Landroid/view/View;)V

    :cond_1
    iget-object p0, p0, Landroidx/recyclerview/widget/AZxh;->mjFkc:Landroidx/recyclerview/widget/AZxh$AZxh;

    invoke-interface {p0, p1, p2}, Landroidx/recyclerview/widget/AZxh$AZxh;->JHa(Landroid/view/View;I)V

    return-void
.end method

.method public qGY(Landroid/view/View;)V
    .locals 2

    iget-object v0, p0, Landroidx/recyclerview/widget/AZxh;->mjFkc:Landroidx/recyclerview/widget/AZxh$AZxh;

    invoke-interface {v0, p1}, Landroidx/recyclerview/widget/AZxh$AZxh;->ETF(Landroid/view/View;)I

    move-result v0

    if-gez v0, :cond_0

    return-void

    :cond_0
    iget-object v1, p0, Landroidx/recyclerview/widget/AZxh;->AZxh:Landroidx/recyclerview/widget/AZxh$mjFkc;

    invoke-virtual {v1, v0}, Landroidx/recyclerview/widget/AZxh$mjFkc;->JHa(I)Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/AZxh;->diqgf(Landroid/view/View;)Z

    :cond_1
    iget-object p0, p0, Landroidx/recyclerview/widget/AZxh;->mjFkc:Landroidx/recyclerview/widget/AZxh$AZxh;

    invoke-interface {p0, v0}, Landroidx/recyclerview/widget/AZxh$AZxh;->lgHUyS(I)V

    return-void
.end method

.method public qdMbNW(I)Landroid/view/View;
    .locals 0

    iget-object p0, p0, Landroidx/recyclerview/widget/AZxh;->mjFkc:Landroidx/recyclerview/widget/AZxh$AZxh;

    invoke-interface {p0, p1}, Landroidx/recyclerview/widget/AZxh$AZxh;->mjFkc(I)Landroid/view/View;

    move-result-object p0

    return-object p0
.end method

.method public rkYL()V
    .locals 3

    iget-object v0, p0, Landroidx/recyclerview/widget/AZxh;->AZxh:Landroidx/recyclerview/widget/AZxh$mjFkc;

    invoke-virtual {v0}, Landroidx/recyclerview/widget/AZxh$mjFkc;->xJ()V

    iget-object v0, p0, Landroidx/recyclerview/widget/AZxh;->wA:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    add-int/lit8 v0, v0, -0x1

    :goto_0
    if-ltz v0, :cond_0

    iget-object v1, p0, Landroidx/recyclerview/widget/AZxh;->mjFkc:Landroidx/recyclerview/widget/AZxh$AZxh;

    iget-object v2, p0, Landroidx/recyclerview/widget/AZxh;->wA:Ljava/util/List;

    invoke-interface {v2, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/view/View;

    invoke-interface {v1, v2}, Landroidx/recyclerview/widget/AZxh$AZxh;->KLFTb(Landroid/view/View;)V

    iget-object v1, p0, Landroidx/recyclerview/widget/AZxh;->wA:Ljava/util/List;

    invoke-interface {v1, v0}, Ljava/util/List;->remove(I)Ljava/lang/Object;

    add-int/lit8 v0, v0, -0x1

    goto :goto_0

    :cond_0
    iget-object p0, p0, Landroidx/recyclerview/widget/AZxh;->mjFkc:Landroidx/recyclerview/widget/AZxh$AZxh;

    invoke-interface {p0}, Landroidx/recyclerview/widget/AZxh$AZxh;->qdMbNW()V

    return-void
.end method

.method public toString()Ljava/lang/String;
    .locals 2

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v1, p0, Landroidx/recyclerview/widget/AZxh;->AZxh:Landroidx/recyclerview/widget/AZxh$mjFkc;

    invoke-virtual {v1}, Landroidx/recyclerview/widget/AZxh$mjFkc;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, ", hidden list:"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object p0, p0, Landroidx/recyclerview/widget/AZxh;->wA:Ljava/util/List;

    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public wA(Landroid/view/View;ILandroid/view/ViewGroup$LayoutParams;Z)V
    .locals 1

    if-gez p2, :cond_0

    iget-object p2, p0, Landroidx/recyclerview/widget/AZxh;->mjFkc:Landroidx/recyclerview/widget/AZxh$AZxh;

    invoke-interface {p2}, Landroidx/recyclerview/widget/AZxh$AZxh;->xJ()I

    move-result p2

    goto :goto_0

    :cond_0
    invoke-virtual {p0, p2}, Landroidx/recyclerview/widget/AZxh;->lgHUyS(I)I

    move-result p2

    :goto_0
    iget-object v0, p0, Landroidx/recyclerview/widget/AZxh;->AZxh:Landroidx/recyclerview/widget/AZxh$mjFkc;

    invoke-virtual {v0, p2, p4}, Landroidx/recyclerview/widget/AZxh$mjFkc;->KLFTb(IZ)V

    if-eqz p4, :cond_1

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/AZxh;->VA(Landroid/view/View;)V

    :cond_1
    iget-object p0, p0, Landroidx/recyclerview/widget/AZxh;->mjFkc:Landroidx/recyclerview/widget/AZxh$AZxh;

    invoke-interface {p0, p1, p2, p3}, Landroidx/recyclerview/widget/AZxh$AZxh;->Dt(Landroid/view/View;ILandroid/view/ViewGroup$LayoutParams;)V

    return-void
.end method

.method public xJ()I
    .locals 1

    iget-object v0, p0, Landroidx/recyclerview/widget/AZxh;->mjFkc:Landroidx/recyclerview/widget/AZxh$AZxh;

    invoke-interface {v0}, Landroidx/recyclerview/widget/AZxh$AZxh;->xJ()I

    move-result v0

    iget-object p0, p0, Landroidx/recyclerview/widget/AZxh;->wA:Ljava/util/List;

    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result p0

    sub-int/2addr v0, p0

    return v0
.end method
