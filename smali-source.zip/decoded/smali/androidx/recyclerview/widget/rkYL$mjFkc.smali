.class public Landroidx/recyclerview/widget/rkYL$mjFkc;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/recyclerview/widget/rkYL;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "mjFkc"
.end annotation


# instance fields
.field public AZxh:I

.field public KLFTb:I

.field public ZfxDd:I

.field public mjFkc:I

.field public wA:I


# direct methods
.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput v0, p0, Landroidx/recyclerview/widget/rkYL$mjFkc;->mjFkc:I

    return-void
.end method


# virtual methods
.method public AZxh()Z
    .locals 4

    iget v0, p0, Landroidx/recyclerview/widget/rkYL$mjFkc;->mjFkc:I

    and-int/lit8 v1, v0, 0x7

    const/4 v2, 0x0

    if-eqz v1, :cond_0

    iget v1, p0, Landroidx/recyclerview/widget/rkYL$mjFkc;->ZfxDd:I

    iget v3, p0, Landroidx/recyclerview/widget/rkYL$mjFkc;->AZxh:I

    invoke-virtual {p0, v1, v3}, Landroidx/recyclerview/widget/rkYL$mjFkc;->wA(II)I

    move-result v1

    and-int/2addr v0, v1

    if-nez v0, :cond_0

    return v2

    :cond_0
    iget v0, p0, Landroidx/recyclerview/widget/rkYL$mjFkc;->mjFkc:I

    and-int/lit8 v1, v0, 0x70

    if-eqz v1, :cond_1

    iget v1, p0, Landroidx/recyclerview/widget/rkYL$mjFkc;->ZfxDd:I

    iget v3, p0, Landroidx/recyclerview/widget/rkYL$mjFkc;->wA:I

    invoke-virtual {p0, v1, v3}, Landroidx/recyclerview/widget/rkYL$mjFkc;->wA(II)I

    move-result v1

    shl-int/lit8 v1, v1, 0x4

    and-int/2addr v0, v1

    if-nez v0, :cond_1

    return v2

    :cond_1
    iget v0, p0, Landroidx/recyclerview/widget/rkYL$mjFkc;->mjFkc:I

    and-int/lit16 v1, v0, 0x700

    if-eqz v1, :cond_2

    iget v1, p0, Landroidx/recyclerview/widget/rkYL$mjFkc;->KLFTb:I

    iget v3, p0, Landroidx/recyclerview/widget/rkYL$mjFkc;->AZxh:I

    invoke-virtual {p0, v1, v3}, Landroidx/recyclerview/widget/rkYL$mjFkc;->wA(II)I

    move-result v1

    shl-int/lit8 v1, v1, 0x8

    and-int/2addr v0, v1

    if-nez v0, :cond_2

    return v2

    :cond_2
    iget v0, p0, Landroidx/recyclerview/widget/rkYL$mjFkc;->mjFkc:I

    and-int/lit16 v1, v0, 0x7000

    if-eqz v1, :cond_3

    iget v1, p0, Landroidx/recyclerview/widget/rkYL$mjFkc;->KLFTb:I

    iget v3, p0, Landroidx/recyclerview/widget/rkYL$mjFkc;->wA:I

    invoke-virtual {p0, v1, v3}, Landroidx/recyclerview/widget/rkYL$mjFkc;->wA(II)I

    move-result p0

    shl-int/lit8 p0, p0, 0xc

    and-int/2addr p0, v0

    if-nez p0, :cond_3

    return v2

    :cond_3
    const/4 p0, 0x1

    return p0
.end method

.method public KLFTb(IIII)V
    .locals 0

    iput p1, p0, Landroidx/recyclerview/widget/rkYL$mjFkc;->AZxh:I

    iput p2, p0, Landroidx/recyclerview/widget/rkYL$mjFkc;->wA:I

    iput p3, p0, Landroidx/recyclerview/widget/rkYL$mjFkc;->ZfxDd:I

    iput p4, p0, Landroidx/recyclerview/widget/rkYL$mjFkc;->KLFTb:I

    return-void
.end method

.method public ZfxDd()V
    .locals 1

    const/4 v0, 0x0

    iput v0, p0, Landroidx/recyclerview/widget/rkYL$mjFkc;->mjFkc:I

    return-void
.end method

.method public mjFkc(I)V
    .locals 1

    iget v0, p0, Landroidx/recyclerview/widget/rkYL$mjFkc;->mjFkc:I

    or-int/2addr p1, v0

    iput p1, p0, Landroidx/recyclerview/widget/rkYL$mjFkc;->mjFkc:I

    return-void
.end method

.method public wA(II)I
    .locals 0

    if-le p1, p2, :cond_0

    const/4 p0, 0x1

    return p0

    :cond_0
    if-ne p1, p2, :cond_1

    const/4 p0, 0x2

    return p0

    :cond_1
    const/4 p0, 0x4

    return p0
.end method
