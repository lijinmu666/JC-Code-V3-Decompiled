.class public Landroidx/recyclerview/widget/GridLayoutManager;
.super Landroidx/recyclerview/widget/LinearLayoutManager;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/recyclerview/widget/GridLayoutManager$AZxh;,
        Landroidx/recyclerview/widget/GridLayoutManager$mjFkc;,
        Landroidx/recyclerview/widget/GridLayoutManager$wA;
    }
.end annotation


# instance fields
.field public KLMXS:I

.field public NPj:Landroidx/recyclerview/widget/GridLayoutManager$wA;

.field public final Vnb:Landroid/util/SparseIntArray;

.field public cMLeY:[Landroid/view/View;

.field public oCFDzJ:Z

.field public final rWxwaT:Landroid/util/SparseIntArray;

.field public final vadzgd:Landroid/graphics/Rect;

.field public xrEuO:Z

.field public zvd:[I


# direct methods
.method public constructor <init>(Landroid/content/Context;IIZ)V
    .locals 0

    .line 10
    invoke-direct {p0, p1, p3, p4}, Landroidx/recyclerview/widget/LinearLayoutManager;-><init>(Landroid/content/Context;IZ)V

    const/4 p1, 0x0

    .line 11
    iput-boolean p1, p0, Landroidx/recyclerview/widget/GridLayoutManager;->xrEuO:Z

    const/4 p1, -0x1

    .line 12
    iput p1, p0, Landroidx/recyclerview/widget/GridLayoutManager;->KLMXS:I

    .line 13
    new-instance p1, Landroid/util/SparseIntArray;

    invoke-direct {p1}, Landroid/util/SparseIntArray;-><init>()V

    iput-object p1, p0, Landroidx/recyclerview/widget/GridLayoutManager;->rWxwaT:Landroid/util/SparseIntArray;

    .line 14
    new-instance p1, Landroid/util/SparseIntArray;

    invoke-direct {p1}, Landroid/util/SparseIntArray;-><init>()V

    iput-object p1, p0, Landroidx/recyclerview/widget/GridLayoutManager;->Vnb:Landroid/util/SparseIntArray;

    .line 15
    new-instance p1, Landroidx/recyclerview/widget/GridLayoutManager$mjFkc;

    invoke-direct {p1}, Landroidx/recyclerview/widget/GridLayoutManager$mjFkc;-><init>()V

    iput-object p1, p0, Landroidx/recyclerview/widget/GridLayoutManager;->NPj:Landroidx/recyclerview/widget/GridLayoutManager$wA;

    .line 16
    new-instance p1, Landroid/graphics/Rect;

    invoke-direct {p1}, Landroid/graphics/Rect;-><init>()V

    iput-object p1, p0, Landroidx/recyclerview/widget/GridLayoutManager;->vadzgd:Landroid/graphics/Rect;

    .line 17
    invoke-virtual {p0, p2}, Landroidx/recyclerview/widget/GridLayoutManager;->lEKdq(I)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;II)V
    .locals 1

    .line 1
    invoke-direct {p0, p1, p2, p3, p4}, Landroidx/recyclerview/widget/LinearLayoutManager;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;II)V

    const/4 v0, 0x0

    .line 2
    iput-boolean v0, p0, Landroidx/recyclerview/widget/GridLayoutManager;->xrEuO:Z

    const/4 v0, -0x1

    .line 3
    iput v0, p0, Landroidx/recyclerview/widget/GridLayoutManager;->KLMXS:I

    .line 4
    new-instance v0, Landroid/util/SparseIntArray;

    invoke-direct {v0}, Landroid/util/SparseIntArray;-><init>()V

    iput-object v0, p0, Landroidx/recyclerview/widget/GridLayoutManager;->rWxwaT:Landroid/util/SparseIntArray;

    .line 5
    new-instance v0, Landroid/util/SparseIntArray;

    invoke-direct {v0}, Landroid/util/SparseIntArray;-><init>()V

    iput-object v0, p0, Landroidx/recyclerview/widget/GridLayoutManager;->Vnb:Landroid/util/SparseIntArray;

    .line 6
    new-instance v0, Landroidx/recyclerview/widget/GridLayoutManager$mjFkc;

    invoke-direct {v0}, Landroidx/recyclerview/widget/GridLayoutManager$mjFkc;-><init>()V

    iput-object v0, p0, Landroidx/recyclerview/widget/GridLayoutManager;->NPj:Landroidx/recyclerview/widget/GridLayoutManager$wA;

    .line 7
    new-instance v0, Landroid/graphics/Rect;

    invoke-direct {v0}, Landroid/graphics/Rect;-><init>()V

    iput-object v0, p0, Landroidx/recyclerview/widget/GridLayoutManager;->vadzgd:Landroid/graphics/Rect;

    .line 8
    invoke-static {p1, p2, p3, p4}, Landroidx/recyclerview/widget/RecyclerView$qGY;->yfx(Landroid/content/Context;Landroid/util/AttributeSet;II)Landroidx/recyclerview/widget/RecyclerView$qGY$ZfxDd;

    move-result-object p1

    .line 9
    iget p1, p1, Landroidx/recyclerview/widget/RecyclerView$qGY$ZfxDd;->AZxh:I

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/GridLayoutManager;->lEKdq(I)V

    return-void
.end method

.method public static qtZIjO([III)[I
    .locals 5

    const/4 v0, 0x1

    if-eqz p0, :cond_0

    array-length v1, p0

    add-int/lit8 v2, p1, 0x1

    if-ne v1, v2, :cond_0

    array-length v1, p0

    sub-int/2addr v1, v0

    aget v1, p0, v1

    if-eq v1, p2, :cond_1

    :cond_0
    add-int/lit8 p0, p1, 0x1

    new-array p0, p0, [I

    :cond_1
    const/4 v1, 0x0

    aput v1, p0, v1

    div-int v2, p2, p1

    rem-int/2addr p2, p1

    move v3, v1

    :goto_0
    if-gt v0, p1, :cond_3

    add-int/2addr v1, p2

    if-lez v1, :cond_2

    sub-int v4, p1, v1

    if-ge v4, p2, :cond_2

    add-int/lit8 v4, v2, 0x1

    sub-int/2addr v1, p1

    goto :goto_1

    :cond_2
    move v4, v2

    :goto_1
    add-int/2addr v3, v4

    aput v3, p0, v0

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_3
    return-object p0
.end method


# virtual methods
.method public final BABY()V
    .locals 6

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->zvd()I

    move-result v0

    const/4 v1, 0x0

    :goto_0
    if-ge v1, v0, :cond_0

    invoke-virtual {p0, v1}, Landroidx/recyclerview/widget/RecyclerView$qGY;->KLMXS(I)Landroid/view/View;

    move-result-object v2

    invoke-virtual {v2}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v2

    check-cast v2, Landroidx/recyclerview/widget/GridLayoutManager$AZxh;

    invoke-virtual {v2}, Landroidx/recyclerview/widget/RecyclerView$fehf;->mjFkc()I

    move-result v3

    iget-object v4, p0, Landroidx/recyclerview/widget/GridLayoutManager;->rWxwaT:Landroid/util/SparseIntArray;

    invoke-virtual {v2}, Landroidx/recyclerview/widget/GridLayoutManager$AZxh;->JHa()I

    move-result v5

    invoke-virtual {v4, v3, v5}, Landroid/util/SparseIntArray;->put(II)V

    iget-object v4, p0, Landroidx/recyclerview/widget/GridLayoutManager;->Vnb:Landroid/util/SparseIntArray;

    invoke-virtual {v2}, Landroidx/recyclerview/widget/GridLayoutManager$AZxh;->KLFTb()I

    move-result v2

    invoke-virtual {v4, v3, v2}, Landroid/util/SparseIntArray;->put(II)V

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_0
    return-void
.end method

.method public BxruE(ILandroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;)I
    .locals 0

    invoke-virtual {p0}, Landroidx/recyclerview/widget/GridLayoutManager;->joWJO()V

    invoke-virtual {p0}, Landroidx/recyclerview/widget/GridLayoutManager;->KbE()V

    invoke-super {p0, p1, p2, p3}, Landroidx/recyclerview/widget/LinearLayoutManager;->BxruE(ILandroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;)I

    move-result p0

    return p0
.end method

.method public ERt()Z
    .locals 1

    iget-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->wJVbdd:Landroidx/recyclerview/widget/LinearLayoutManager$ZfxDd;

    if-nez v0, :cond_0

    iget-boolean p0, p0, Landroidx/recyclerview/widget/GridLayoutManager;->xrEuO:Z

    if-nez p0, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method

.method public final EcuP(Landroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;I)I
    .locals 1

    invoke-virtual {p2}, Landroidx/recyclerview/widget/RecyclerView$VocHEe;->KLFTb()Z

    move-result p2

    if-nez p2, :cond_0

    iget-object p0, p0, Landroidx/recyclerview/widget/GridLayoutManager;->NPj:Landroidx/recyclerview/widget/GridLayoutManager$wA;

    invoke-virtual {p0, p3}, Landroidx/recyclerview/widget/GridLayoutManager$wA;->JHa(I)I

    move-result p0

    return p0

    :cond_0
    iget-object p2, p0, Landroidx/recyclerview/widget/GridLayoutManager;->rWxwaT:Landroid/util/SparseIntArray;

    const/4 v0, -0x1

    invoke-virtual {p2, p3, v0}, Landroid/util/SparseIntArray;->get(II)I

    move-result p2

    if-eq p2, v0, :cond_1

    return p2

    :cond_1
    invoke-virtual {p1, p3}, Landroidx/recyclerview/widget/RecyclerView$Ucbh;->JHa(I)I

    move-result p1

    if-ne p1, v0, :cond_2

    new-instance p0, Ljava/lang/StringBuilder;

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    const-string p1, "Cannot find span size for pre layout position. It is not cached, not in the adapter. Pos:"

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0, p3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const-string p1, "GridLayoutManager"

    invoke-static {p1, p0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    const/4 p0, 0x1

    return p0

    :cond_2
    iget-object p0, p0, Landroidx/recyclerview/widget/GridLayoutManager;->NPj:Landroidx/recyclerview/widget/GridLayoutManager$wA;

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/GridLayoutManager$wA;->JHa(I)I

    move-result p0

    return p0
.end method

.method public FbxKQm(Landroidx/recyclerview/widget/RecyclerView;)V
    .locals 0

    iget-object p1, p0, Landroidx/recyclerview/widget/GridLayoutManager;->NPj:Landroidx/recyclerview/widget/GridLayoutManager$wA;

    invoke-virtual {p1}, Landroidx/recyclerview/widget/GridLayoutManager$wA;->lgHUyS()V

    iget-object p0, p0, Landroidx/recyclerview/widget/GridLayoutManager;->NPj:Landroidx/recyclerview/widget/GridLayoutManager$wA;

    invoke-virtual {p0}, Landroidx/recyclerview/widget/GridLayoutManager$wA;->xJ()V

    return-void
.end method

.method public final GEj(Landroid/view/View;IIZ)V
    .locals 1

    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    check-cast v0, Landroidx/recyclerview/widget/RecyclerView$fehf;

    if-eqz p4, :cond_0

    invoke-virtual {p0, p1, p2, p3, v0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->tpGcn(Landroid/view/View;IILandroidx/recyclerview/widget/RecyclerView$fehf;)Z

    move-result p0

    goto :goto_0

    :cond_0
    invoke-virtual {p0, p1, p2, p3, v0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->yP(Landroid/view/View;IILandroidx/recyclerview/widget/RecyclerView$fehf;)Z

    move-result p0

    :goto_0
    if-eqz p0, :cond_1

    invoke-virtual {p1, p2, p3}, Landroid/view/View;->measure(II)V

    :cond_1
    return-void
.end method

.method public final KbE()V
    .locals 2

    iget-object v0, p0, Landroidx/recyclerview/widget/GridLayoutManager;->cMLeY:[Landroid/view/View;

    if-eqz v0, :cond_0

    array-length v0, v0

    iget v1, p0, Landroidx/recyclerview/widget/GridLayoutManager;->KLMXS:I

    if-eq v0, v1, :cond_1

    :cond_0
    iget v0, p0, Landroidx/recyclerview/widget/GridLayoutManager;->KLMXS:I

    new-array v0, v0, [Landroid/view/View;

    iput-object v0, p0, Landroidx/recyclerview/widget/GridLayoutManager;->cMLeY:[Landroid/view/View;

    :cond_1
    return-void
.end method

.method public MlqoT(II)I
    .locals 2

    iget v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->Pq:I

    const/4 v1, 0x1

    if-ne v0, v1, :cond_0

    invoke-virtual {p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->jY()Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Landroidx/recyclerview/widget/GridLayoutManager;->zvd:[I

    iget p0, p0, Landroidx/recyclerview/widget/GridLayoutManager;->KLMXS:I

    sub-int v1, p0, p1

    aget v1, v0, v1

    sub-int/2addr p0, p1

    sub-int/2addr p0, p2

    aget p0, v0, p0

    sub-int/2addr v1, p0

    return v1

    :cond_0
    iget-object p0, p0, Landroidx/recyclerview/widget/GridLayoutManager;->zvd:[I

    add-int/2addr p2, p1

    aget p2, p0, p2

    aget p0, p0, p1

    sub-int/2addr p2, p0

    return p2
.end method

.method public NPj(Landroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;)I
    .locals 2

    iget v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->Pq:I

    const/4 v1, 0x1

    if-ne v0, v1, :cond_0

    iget p0, p0, Landroidx/recyclerview/widget/GridLayoutManager;->KLMXS:I

    return p0

    :cond_0
    invoke-virtual {p2}, Landroidx/recyclerview/widget/RecyclerView$VocHEe;->AZxh()I

    move-result v0

    if-ge v0, v1, :cond_1

    const/4 p0, 0x0

    return p0

    :cond_1
    invoke-virtual {p2}, Landroidx/recyclerview/widget/RecyclerView$VocHEe;->AZxh()I

    move-result v0

    sub-int/2addr v0, v1

    invoke-virtual {p0, p1, p2, v0}, Landroidx/recyclerview/widget/GridLayoutManager;->sZ(Landroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;I)I

    move-result p0

    add-int/2addr p0, v1

    return p0
.end method

.method public Ne(Landroid/view/ViewGroup$LayoutParams;)Landroidx/recyclerview/widget/RecyclerView$fehf;
    .locals 0

    instance-of p0, p1, Landroid/view/ViewGroup$MarginLayoutParams;

    if-eqz p0, :cond_0

    new-instance p0, Landroidx/recyclerview/widget/GridLayoutManager$AZxh;

    check-cast p1, Landroid/view/ViewGroup$MarginLayoutParams;

    invoke-direct {p0, p1}, Landroidx/recyclerview/widget/GridLayoutManager$AZxh;-><init>(Landroid/view/ViewGroup$MarginLayoutParams;)V

    return-object p0

    :cond_0
    new-instance p0, Landroidx/recyclerview/widget/GridLayoutManager$AZxh;

    invoke-direct {p0, p1}, Landroidx/recyclerview/widget/GridLayoutManager$AZxh;-><init>(Landroid/view/ViewGroup$LayoutParams;)V

    return-object p0
.end method

.method public OjSQV(Landroid/content/Context;Landroid/util/AttributeSet;)Landroidx/recyclerview/widget/RecyclerView$fehf;
    .locals 0

    new-instance p0, Landroidx/recyclerview/widget/GridLayoutManager$AZxh;

    invoke-direct {p0, p1, p2}, Landroidx/recyclerview/widget/GridLayoutManager$AZxh;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    return-object p0
.end method

.method public Pq(Landroidx/recyclerview/widget/RecyclerView$VocHEe;)I
    .locals 1

    iget-boolean v0, p0, Landroidx/recyclerview/widget/GridLayoutManager;->oCFDzJ:Z

    if-eqz v0, :cond_0

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/GridLayoutManager;->gjvQ(Landroidx/recyclerview/widget/RecyclerView$VocHEe;)I

    move-result p0

    return p0

    :cond_0
    invoke-super {p0, p1}, Landroidx/recyclerview/widget/LinearLayoutManager;->Pq(Landroidx/recyclerview/widget/RecyclerView$VocHEe;)I

    move-result p0

    return p0
.end method

.method public QyqF(ILandroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;)I
    .locals 0

    invoke-virtual {p0}, Landroidx/recyclerview/widget/GridLayoutManager;->joWJO()V

    invoke-virtual {p0}, Landroidx/recyclerview/widget/GridLayoutManager;->KbE()V

    invoke-super {p0, p1, p2, p3}, Landroidx/recyclerview/widget/LinearLayoutManager;->QyqF(ILandroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;)I

    move-result p0

    return p0
.end method

.method public Sx(Landroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;Landroidx/recyclerview/widget/LinearLayoutManager$wA;Landroidx/recyclerview/widget/LinearLayoutManager$AZxh;)V
    .locals 17

    move-object/from16 v6, p0

    move-object/from16 v0, p1

    move-object/from16 v1, p2

    move-object/from16 v2, p3

    move-object/from16 v7, p4

    iget-object v3, v6, Landroidx/recyclerview/widget/LinearLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v3}, Landroidx/recyclerview/widget/qdMbNW;->VA()I

    move-result v3

    const/4 v8, 0x1

    const/4 v4, 0x0

    const/high16 v5, 0x40000000    # 2.0f

    if-eq v3, v5, :cond_0

    move v9, v8

    goto :goto_0

    :cond_0
    move v9, v4

    :goto_0
    invoke-virtual/range {p0 .. p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->zvd()I

    move-result v10

    if-lez v10, :cond_1

    iget-object v10, v6, Landroidx/recyclerview/widget/GridLayoutManager;->zvd:[I

    iget v11, v6, Landroidx/recyclerview/widget/GridLayoutManager;->KLMXS:I

    aget v10, v10, v11

    goto :goto_1

    :cond_1
    move v10, v4

    :goto_1
    if-eqz v9, :cond_2

    invoke-virtual/range {p0 .. p0}, Landroidx/recyclerview/widget/GridLayoutManager;->joWJO()V

    :cond_2
    iget v11, v2, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->KLFTb:I

    if-ne v11, v8, :cond_3

    move v11, v8

    goto :goto_2

    :cond_3
    move v11, v4

    :goto_2
    iget v12, v6, Landroidx/recyclerview/widget/GridLayoutManager;->KLMXS:I

    if-nez v11, :cond_4

    iget v12, v2, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->ZfxDd:I

    invoke-virtual {v6, v0, v1, v12}, Landroidx/recyclerview/widget/GridLayoutManager;->Zerm(Landroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;I)I

    move-result v12

    iget v13, v2, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->ZfxDd:I

    invoke-virtual {v6, v0, v1, v13}, Landroidx/recyclerview/widget/GridLayoutManager;->EcuP(Landroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;I)I

    move-result v13

    add-int/2addr v12, v13

    :cond_4
    move v13, v4

    :goto_3
    iget v14, v6, Landroidx/recyclerview/widget/GridLayoutManager;->KLMXS:I

    if-ge v13, v14, :cond_8

    invoke-virtual {v2, v1}, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->wA(Landroidx/recyclerview/widget/RecyclerView$VocHEe;)Z

    move-result v14

    if-eqz v14, :cond_8

    if-lez v12, :cond_8

    iget v14, v2, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->ZfxDd:I

    invoke-virtual {v6, v0, v1, v14}, Landroidx/recyclerview/widget/GridLayoutManager;->EcuP(Landroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;I)I

    move-result v15

    iget v5, v6, Landroidx/recyclerview/widget/GridLayoutManager;->KLMXS:I

    if-gt v15, v5, :cond_7

    sub-int/2addr v12, v15

    if-gez v12, :cond_5

    goto :goto_4

    :cond_5
    invoke-virtual {v2, v0}, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->ZfxDd(Landroidx/recyclerview/widget/RecyclerView$Ucbh;)Landroid/view/View;

    move-result-object v5

    if-nez v5, :cond_6

    goto :goto_4

    :cond_6
    iget-object v14, v6, Landroidx/recyclerview/widget/GridLayoutManager;->cMLeY:[Landroid/view/View;

    aput-object v5, v14, v13

    add-int/lit8 v13, v13, 0x1

    const/high16 v5, 0x40000000    # 2.0f

    goto :goto_3

    :cond_7
    new-instance v0, Ljava/lang/IllegalArgumentException;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "Item at position "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v14}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, " requires "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v15}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, " spans but GridLayoutManager has only "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v2, v6, Landroidx/recyclerview/widget/GridLayoutManager;->KLMXS:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, " spans."

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_8
    :goto_4
    if-nez v13, :cond_9

    iput-boolean v8, v7, Landroidx/recyclerview/widget/LinearLayoutManager$AZxh;->AZxh:Z

    return-void

    :cond_9
    invoke-virtual {v6, v0, v1, v13, v11}, Landroidx/recyclerview/widget/GridLayoutManager;->eEOGOh(Landroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;IZ)V

    const/4 v0, 0x0

    move v1, v4

    move v5, v1

    :goto_5
    if-ge v1, v13, :cond_f

    iget-object v12, v6, Landroidx/recyclerview/widget/GridLayoutManager;->cMLeY:[Landroid/view/View;

    aget-object v12, v12, v1

    iget-object v14, v2, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->VA:Ljava/util/List;

    if-nez v14, :cond_b

    if-eqz v11, :cond_a

    invoke-virtual {v6, v12}, Landroidx/recyclerview/widget/RecyclerView$qGY;->KLFTb(Landroid/view/View;)V

    goto :goto_6

    :cond_a
    invoke-virtual {v6, v12, v4}, Landroidx/recyclerview/widget/RecyclerView$qGY;->JHa(Landroid/view/View;I)V

    goto :goto_6

    :cond_b
    if-eqz v11, :cond_c

    invoke-virtual {v6, v12}, Landroidx/recyclerview/widget/RecyclerView$qGY;->wA(Landroid/view/View;)V

    goto :goto_6

    :cond_c
    invoke-virtual {v6, v12, v4}, Landroidx/recyclerview/widget/RecyclerView$qGY;->ZfxDd(Landroid/view/View;I)V

    :goto_6
    iget-object v14, v6, Landroidx/recyclerview/widget/GridLayoutManager;->vadzgd:Landroid/graphics/Rect;

    invoke-virtual {v6, v12, v14}, Landroidx/recyclerview/widget/RecyclerView$qGY;->ETF(Landroid/view/View;Landroid/graphics/Rect;)V

    invoke-virtual {v6, v12, v3, v4}, Landroidx/recyclerview/widget/GridLayoutManager;->eHig(Landroid/view/View;IZ)V

    iget-object v14, v6, Landroidx/recyclerview/widget/LinearLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v14, v12}, Landroidx/recyclerview/widget/qdMbNW;->KLFTb(Landroid/view/View;)I

    move-result v14

    if-le v14, v5, :cond_d

    move v5, v14

    :cond_d
    invoke-virtual {v12}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v14

    check-cast v14, Landroidx/recyclerview/widget/GridLayoutManager$AZxh;

    iget-object v15, v6, Landroidx/recyclerview/widget/LinearLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v15, v12}, Landroidx/recyclerview/widget/qdMbNW;->JHa(Landroid/view/View;)I

    move-result v12

    int-to-float v12, v12

    const/high16 v15, 0x3f800000    # 1.0f

    mul-float/2addr v12, v15

    iget v14, v14, Landroidx/recyclerview/widget/GridLayoutManager$AZxh;->JHa:I

    int-to-float v14, v14

    div-float/2addr v12, v14

    cmpl-float v14, v12, v0

    if-lez v14, :cond_e

    move v0, v12

    :cond_e
    add-int/lit8 v1, v1, 0x1

    goto :goto_5

    :cond_f
    if-eqz v9, :cond_11

    invoke-virtual {v6, v0, v10}, Landroidx/recyclerview/widget/GridLayoutManager;->pCi(FI)V

    move v0, v4

    move v5, v0

    :goto_7
    if-ge v0, v13, :cond_11

    iget-object v1, v6, Landroidx/recyclerview/widget/GridLayoutManager;->cMLeY:[Landroid/view/View;

    aget-object v1, v1, v0

    const/high16 v3, 0x40000000    # 2.0f

    invoke-virtual {v6, v1, v3, v8}, Landroidx/recyclerview/widget/GridLayoutManager;->eHig(Landroid/view/View;IZ)V

    iget-object v3, v6, Landroidx/recyclerview/widget/LinearLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v3, v1}, Landroidx/recyclerview/widget/qdMbNW;->KLFTb(Landroid/view/View;)I

    move-result v1

    if-le v1, v5, :cond_10

    move v5, v1

    :cond_10
    add-int/lit8 v0, v0, 0x1

    goto :goto_7

    :cond_11
    move v0, v4

    :goto_8
    if-ge v0, v13, :cond_14

    iget-object v1, v6, Landroidx/recyclerview/widget/GridLayoutManager;->cMLeY:[Landroid/view/View;

    aget-object v1, v1, v0

    iget-object v3, v6, Landroidx/recyclerview/widget/LinearLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v3, v1}, Landroidx/recyclerview/widget/qdMbNW;->KLFTb(Landroid/view/View;)I

    move-result v3

    if-eq v3, v5, :cond_13

    invoke-virtual {v1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v3

    check-cast v3, Landroidx/recyclerview/widget/GridLayoutManager$AZxh;

    iget-object v9, v3, Landroidx/recyclerview/widget/RecyclerView$fehf;->AZxh:Landroid/graphics/Rect;

    iget v10, v9, Landroid/graphics/Rect;->top:I

    iget v11, v9, Landroid/graphics/Rect;->bottom:I

    add-int/2addr v10, v11

    iget v11, v3, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    add-int/2addr v10, v11

    iget v11, v3, Landroid/view/ViewGroup$MarginLayoutParams;->bottomMargin:I

    add-int/2addr v10, v11

    iget v11, v9, Landroid/graphics/Rect;->left:I

    iget v9, v9, Landroid/graphics/Rect;->right:I

    add-int/2addr v11, v9

    iget v9, v3, Landroid/view/ViewGroup$MarginLayoutParams;->leftMargin:I

    add-int/2addr v11, v9

    iget v9, v3, Landroid/view/ViewGroup$MarginLayoutParams;->rightMargin:I

    add-int/2addr v11, v9

    iget v9, v3, Landroidx/recyclerview/widget/GridLayoutManager$AZxh;->KLFTb:I

    iget v12, v3, Landroidx/recyclerview/widget/GridLayoutManager$AZxh;->JHa:I

    invoke-virtual {v6, v9, v12}, Landroidx/recyclerview/widget/GridLayoutManager;->MlqoT(II)I

    move-result v9

    iget v12, v6, Landroidx/recyclerview/widget/LinearLayoutManager;->Pq:I

    if-ne v12, v8, :cond_12

    iget v3, v3, Landroid/view/ViewGroup$MarginLayoutParams;->width:I

    const/high16 v12, 0x40000000    # 2.0f

    invoke-static {v9, v12, v11, v3, v4}, Landroidx/recyclerview/widget/RecyclerView$qGY;->cMLeY(IIIIZ)I

    move-result v3

    sub-int v9, v5, v10

    invoke-static {v9, v12}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v9

    goto :goto_9

    :cond_12
    const/high16 v12, 0x40000000    # 2.0f

    sub-int v11, v5, v11

    invoke-static {v11, v12}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v11

    iget v3, v3, Landroid/view/ViewGroup$MarginLayoutParams;->height:I

    invoke-static {v9, v12, v10, v3, v4}, Landroidx/recyclerview/widget/RecyclerView$qGY;->cMLeY(IIIIZ)I

    move-result v9

    move v3, v11

    :goto_9
    invoke-virtual {v6, v1, v3, v9, v8}, Landroidx/recyclerview/widget/GridLayoutManager;->GEj(Landroid/view/View;IIZ)V

    goto :goto_a

    :cond_13
    const/high16 v12, 0x40000000    # 2.0f

    :goto_a
    add-int/lit8 v0, v0, 0x1

    goto :goto_8

    :cond_14
    iput v5, v7, Landroidx/recyclerview/widget/LinearLayoutManager$AZxh;->mjFkc:I

    iget v0, v6, Landroidx/recyclerview/widget/LinearLayoutManager;->Pq:I

    const/4 v1, -0x1

    if-ne v0, v8, :cond_16

    iget v0, v2, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->JHa:I

    if-ne v0, v1, :cond_15

    iget v0, v2, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->AZxh:I

    sub-int v1, v0, v5

    :goto_b
    move v3, v1

    move v1, v4

    move v2, v1

    goto :goto_d

    :cond_15
    iget v1, v2, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->AZxh:I

    add-int v0, v1, v5

    goto :goto_b

    :cond_16
    iget v0, v2, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->JHa:I

    if-ne v0, v1, :cond_17

    iget v0, v2, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->AZxh:I

    sub-int v1, v0, v5

    :goto_c
    move v2, v1

    move v3, v4

    move v1, v0

    move v0, v3

    goto :goto_d

    :cond_17
    iget v1, v2, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->AZxh:I

    add-int v0, v1, v5

    goto :goto_c

    :goto_d
    move v9, v4

    :goto_e
    if-ge v9, v13, :cond_1c

    iget-object v4, v6, Landroidx/recyclerview/widget/GridLayoutManager;->cMLeY:[Landroid/view/View;

    aget-object v10, v4, v9

    invoke-virtual {v10}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v4

    move-object v11, v4

    check-cast v11, Landroidx/recyclerview/widget/GridLayoutManager$AZxh;

    iget v4, v6, Landroidx/recyclerview/widget/LinearLayoutManager;->Pq:I

    if-ne v4, v8, :cond_19

    invoke-virtual/range {p0 .. p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->jY()Z

    move-result v1

    if-eqz v1, :cond_18

    invoke-virtual/range {p0 .. p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->jm()I

    move-result v1

    iget-object v2, v6, Landroidx/recyclerview/widget/GridLayoutManager;->zvd:[I

    iget v4, v6, Landroidx/recyclerview/widget/GridLayoutManager;->KLMXS:I

    iget v5, v11, Landroidx/recyclerview/widget/GridLayoutManager$AZxh;->KLFTb:I

    sub-int/2addr v4, v5

    aget v2, v2, v4

    add-int/2addr v1, v2

    iget-object v2, v6, Landroidx/recyclerview/widget/LinearLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v2, v10}, Landroidx/recyclerview/widget/qdMbNW;->JHa(Landroid/view/View;)I

    move-result v2

    sub-int v2, v1, v2

    move v12, v0

    move v14, v1

    move v15, v2

    :goto_f
    move/from16 v16, v3

    goto :goto_10

    :cond_18
    invoke-virtual/range {p0 .. p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->jm()I

    move-result v1

    iget-object v2, v6, Landroidx/recyclerview/widget/GridLayoutManager;->zvd:[I

    iget v4, v11, Landroidx/recyclerview/widget/GridLayoutManager$AZxh;->KLFTb:I

    aget v2, v2, v4

    add-int/2addr v1, v2

    iget-object v2, v6, Landroidx/recyclerview/widget/LinearLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v2, v10}, Landroidx/recyclerview/widget/qdMbNW;->JHa(Landroid/view/View;)I

    move-result v2

    add-int/2addr v2, v1

    move v12, v0

    move v15, v1

    move v14, v2

    goto :goto_f

    :cond_19
    invoke-virtual/range {p0 .. p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->dm()I

    move-result v0

    iget-object v3, v6, Landroidx/recyclerview/widget/GridLayoutManager;->zvd:[I

    iget v4, v11, Landroidx/recyclerview/widget/GridLayoutManager$AZxh;->KLFTb:I

    aget v3, v3, v4

    add-int/2addr v0, v3

    iget-object v3, v6, Landroidx/recyclerview/widget/LinearLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v3, v10}, Landroidx/recyclerview/widget/qdMbNW;->JHa(Landroid/view/View;)I

    move-result v3

    add-int/2addr v3, v0

    move/from16 v16, v0

    move v14, v1

    move v15, v2

    move v12, v3

    :goto_10
    move-object/from16 v0, p0

    move-object v1, v10

    move v2, v15

    move/from16 v3, v16

    move v4, v14

    move v5, v12

    invoke-virtual/range {v0 .. v5}, Landroidx/recyclerview/widget/RecyclerView$qGY;->XFUzSY(Landroid/view/View;IIII)V

    invoke-virtual {v11}, Landroidx/recyclerview/widget/RecyclerView$fehf;->wA()Z

    move-result v0

    if-nez v0, :cond_1a

    invoke-virtual {v11}, Landroidx/recyclerview/widget/RecyclerView$fehf;->AZxh()Z

    move-result v0

    if-eqz v0, :cond_1b

    :cond_1a
    iput-boolean v8, v7, Landroidx/recyclerview/widget/LinearLayoutManager$AZxh;->wA:Z

    :cond_1b
    iget-boolean v0, v7, Landroidx/recyclerview/widget/LinearLayoutManager$AZxh;->ZfxDd:Z

    invoke-virtual {v10}, Landroid/view/View;->hasFocusable()Z

    move-result v1

    or-int/2addr v0, v1

    iput-boolean v0, v7, Landroidx/recyclerview/widget/LinearLayoutManager$AZxh;->ZfxDd:Z

    add-int/lit8 v9, v9, 0x1

    move v0, v12

    move v1, v14

    move v2, v15

    move/from16 v3, v16

    goto/16 :goto_e

    :cond_1c
    iget-object v0, v6, Landroidx/recyclerview/widget/GridLayoutManager;->cMLeY:[Landroid/view/View;

    const/4 v1, 0x0

    invoke-static {v0, v1}, Ljava/util/Arrays;->fill([Ljava/lang/Object;Ljava/lang/Object;)V

    return-void
.end method

.method public Ucbh(Landroidx/recyclerview/widget/RecyclerView$VocHEe;)I
    .locals 1

    iget-boolean v0, p0, Landroidx/recyclerview/widget/GridLayoutManager;->oCFDzJ:Z

    if-eqz v0, :cond_0

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/GridLayoutManager;->gjvQ(Landroidx/recyclerview/widget/RecyclerView$VocHEe;)I

    move-result p0

    return p0

    :cond_0
    invoke-super {p0, p1}, Landroidx/recyclerview/widget/LinearLayoutManager;->Ucbh(Landroidx/recyclerview/widget/RecyclerView$VocHEe;)I

    move-result p0

    return p0
.end method

.method public XgAT(Landroidx/recyclerview/widget/RecyclerView;II)V
    .locals 0

    iget-object p1, p0, Landroidx/recyclerview/widget/GridLayoutManager;->NPj:Landroidx/recyclerview/widget/GridLayoutManager$wA;

    invoke-virtual {p1}, Landroidx/recyclerview/widget/GridLayoutManager$wA;->lgHUyS()V

    iget-object p0, p0, Landroidx/recyclerview/widget/GridLayoutManager;->NPj:Landroidx/recyclerview/widget/GridLayoutManager$wA;

    invoke-virtual {p0}, Landroidx/recyclerview/widget/GridLayoutManager$wA;->xJ()V

    return-void
.end method

.method public Xxz(Landroidx/recyclerview/widget/RecyclerView$VocHEe;)V
    .locals 0

    invoke-super {p0, p1}, Landroidx/recyclerview/widget/LinearLayoutManager;->Xxz(Landroidx/recyclerview/widget/RecyclerView$VocHEe;)V

    const/4 p1, 0x0

    iput-boolean p1, p0, Landroidx/recyclerview/widget/GridLayoutManager;->xrEuO:Z

    return-void
.end method

.method public YoKzxo(Landroidx/recyclerview/widget/RecyclerView$fehf;)Z
    .locals 0

    instance-of p0, p1, Landroidx/recyclerview/widget/GridLayoutManager$AZxh;

    return p0
.end method

.method public final Zerm(Landroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;I)I
    .locals 1

    invoke-virtual {p2}, Landroidx/recyclerview/widget/RecyclerView$VocHEe;->KLFTb()Z

    move-result p2

    if-nez p2, :cond_0

    iget-object p1, p0, Landroidx/recyclerview/widget/GridLayoutManager;->NPj:Landroidx/recyclerview/widget/GridLayoutManager$wA;

    iget p0, p0, Landroidx/recyclerview/widget/GridLayoutManager;->KLMXS:I

    invoke-virtual {p1, p3, p0}, Landroidx/recyclerview/widget/GridLayoutManager$wA;->wA(II)I

    move-result p0

    return p0

    :cond_0
    iget-object p2, p0, Landroidx/recyclerview/widget/GridLayoutManager;->Vnb:Landroid/util/SparseIntArray;

    const/4 v0, -0x1

    invoke-virtual {p2, p3, v0}, Landroid/util/SparseIntArray;->get(II)I

    move-result p2

    if-eq p2, v0, :cond_1

    return p2

    :cond_1
    invoke-virtual {p1, p3}, Landroidx/recyclerview/widget/RecyclerView$Ucbh;->JHa(I)I

    move-result p1

    if-ne p1, v0, :cond_2

    new-instance p0, Ljava/lang/StringBuilder;

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    const-string p1, "Cannot find span size for pre layout position. It is not cached, not in the adapter. Pos:"

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0, p3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const-string p1, "GridLayoutManager"

    invoke-static {p1, p0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    const/4 p0, 0x0

    return p0

    :cond_2
    iget-object p2, p0, Landroidx/recyclerview/widget/GridLayoutManager;->NPj:Landroidx/recyclerview/widget/GridLayoutManager$wA;

    iget p0, p0, Landroidx/recyclerview/widget/GridLayoutManager;->KLMXS:I

    invoke-virtual {p2, p1, p0}, Landroidx/recyclerview/widget/GridLayoutManager$wA;->wA(II)I

    move-result p0

    return p0
.end method

.method public dGDT(Landroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;)V
    .locals 1

    invoke-virtual {p2}, Landroidx/recyclerview/widget/RecyclerView$VocHEe;->KLFTb()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-virtual {p0}, Landroidx/recyclerview/widget/GridLayoutManager;->BABY()V

    :cond_0
    invoke-super {p0, p1, p2}, Landroidx/recyclerview/widget/LinearLayoutManager;->dGDT(Landroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;)V

    invoke-virtual {p0}, Landroidx/recyclerview/widget/GridLayoutManager;->xVYW()V

    return-void
.end method

.method public diqgf(Landroidx/recyclerview/widget/RecyclerView$VocHEe;)I
    .locals 1

    iget-boolean v0, p0, Landroidx/recyclerview/widget/GridLayoutManager;->oCFDzJ:Z

    if-eqz v0, :cond_0

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/GridLayoutManager;->kw(Landroidx/recyclerview/widget/RecyclerView$VocHEe;)I

    move-result p0

    return p0

    :cond_0
    invoke-super {p0, p1}, Landroidx/recyclerview/widget/LinearLayoutManager;->diqgf(Landroidx/recyclerview/widget/RecyclerView$VocHEe;)I

    move-result p0

    return p0
.end method

.method public final eEOGOh(Landroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;IZ)V
    .locals 4

    const/4 v0, 0x0

    if-eqz p4, :cond_0

    const/4 p4, 0x1

    move v1, p4

    move p4, p3

    move p3, v0

    goto :goto_0

    :cond_0
    add-int/lit8 p3, p3, -0x1

    const/4 p4, -0x1

    move v1, p4

    :goto_0
    if-eq p3, p4, :cond_1

    iget-object v2, p0, Landroidx/recyclerview/widget/GridLayoutManager;->cMLeY:[Landroid/view/View;

    aget-object v2, v2, p3

    invoke-virtual {v2}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v3

    check-cast v3, Landroidx/recyclerview/widget/GridLayoutManager$AZxh;

    invoke-virtual {p0, v2}, Landroidx/recyclerview/widget/RecyclerView$qGY;->tQ(Landroid/view/View;)I

    move-result v2

    invoke-virtual {p0, p1, p2, v2}, Landroidx/recyclerview/widget/GridLayoutManager;->EcuP(Landroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;I)I

    move-result v2

    iput v2, v3, Landroidx/recyclerview/widget/GridLayoutManager$AZxh;->JHa:I

    iput v0, v3, Landroidx/recyclerview/widget/GridLayoutManager$AZxh;->KLFTb:I

    add-int/2addr v0, v2

    add-int/2addr p3, v1

    goto :goto_0

    :cond_1
    return-void
.end method

.method public final eHig(Landroid/view/View;IZ)V
    .locals 8

    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    check-cast v0, Landroidx/recyclerview/widget/GridLayoutManager$AZxh;

    iget-object v1, v0, Landroidx/recyclerview/widget/RecyclerView$fehf;->AZxh:Landroid/graphics/Rect;

    iget v2, v1, Landroid/graphics/Rect;->top:I

    iget v3, v1, Landroid/graphics/Rect;->bottom:I

    add-int/2addr v2, v3

    iget v3, v0, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    add-int/2addr v2, v3

    iget v3, v0, Landroid/view/ViewGroup$MarginLayoutParams;->bottomMargin:I

    add-int/2addr v2, v3

    iget v3, v1, Landroid/graphics/Rect;->left:I

    iget v1, v1, Landroid/graphics/Rect;->right:I

    add-int/2addr v3, v1

    iget v1, v0, Landroid/view/ViewGroup$MarginLayoutParams;->leftMargin:I

    add-int/2addr v3, v1

    iget v1, v0, Landroid/view/ViewGroup$MarginLayoutParams;->rightMargin:I

    add-int/2addr v3, v1

    iget v1, v0, Landroidx/recyclerview/widget/GridLayoutManager$AZxh;->KLFTb:I

    iget v4, v0, Landroidx/recyclerview/widget/GridLayoutManager$AZxh;->JHa:I

    invoke-virtual {p0, v1, v4}, Landroidx/recyclerview/widget/GridLayoutManager;->MlqoT(II)I

    move-result v1

    iget v4, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->Pq:I

    const/4 v5, 0x0

    const/4 v6, 0x1

    if-ne v4, v6, :cond_0

    iget v4, v0, Landroid/view/ViewGroup$MarginLayoutParams;->width:I

    invoke-static {v1, p2, v3, v4, v5}, Landroidx/recyclerview/widget/RecyclerView$qGY;->cMLeY(IIIIZ)I

    move-result p2

    iget-object v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v1}, Landroidx/recyclerview/widget/qdMbNW;->YoKzxo()I

    move-result v1

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->JrJO()I

    move-result v3

    iget v0, v0, Landroid/view/ViewGroup$MarginLayoutParams;->height:I

    invoke-static {v1, v3, v2, v0, v6}, Landroidx/recyclerview/widget/RecyclerView$qGY;->cMLeY(IIIIZ)I

    move-result v0

    goto :goto_0

    :cond_0
    iget v4, v0, Landroid/view/ViewGroup$MarginLayoutParams;->height:I

    invoke-static {v1, p2, v2, v4, v5}, Landroidx/recyclerview/widget/RecyclerView$qGY;->cMLeY(IIIIZ)I

    move-result p2

    iget-object v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v1}, Landroidx/recyclerview/widget/qdMbNW;->YoKzxo()I

    move-result v1

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->Qr()I

    move-result v2

    iget v0, v0, Landroid/view/ViewGroup$MarginLayoutParams;->width:I

    invoke-static {v1, v2, v3, v0, v6}, Landroidx/recyclerview/widget/RecyclerView$qGY;->cMLeY(IIIIZ)I

    move-result v0

    move v7, v0

    move v0, p2

    move p2, v7

    :goto_0
    invoke-virtual {p0, p1, p2, v0, p3}, Landroidx/recyclerview/widget/GridLayoutManager;->GEj(Landroid/view/View;IIZ)V

    return-void
.end method

.method public eQ(Landroidx/recyclerview/widget/RecyclerView;II)V
    .locals 0

    iget-object p1, p0, Landroidx/recyclerview/widget/GridLayoutManager;->NPj:Landroidx/recyclerview/widget/GridLayoutManager$wA;

    invoke-virtual {p1}, Landroidx/recyclerview/widget/GridLayoutManager$wA;->lgHUyS()V

    iget-object p0, p0, Landroidx/recyclerview/widget/GridLayoutManager;->NPj:Landroidx/recyclerview/widget/GridLayoutManager$wA;

    invoke-virtual {p0}, Landroidx/recyclerview/widget/GridLayoutManager$wA;->xJ()V

    return-void
.end method

.method public final gJsSk(I)V
    .locals 2

    iget-object v0, p0, Landroidx/recyclerview/widget/GridLayoutManager;->zvd:[I

    iget v1, p0, Landroidx/recyclerview/widget/GridLayoutManager;->KLMXS:I

    invoke-static {v0, v1, p1}, Landroidx/recyclerview/widget/GridLayoutManager;->qtZIjO([III)[I

    move-result-object p1

    iput-object p1, p0, Landroidx/recyclerview/widget/GridLayoutManager;->zvd:[I

    return-void
.end method

.method public final gjvQ(Landroidx/recyclerview/widget/RecyclerView$VocHEe;)I
    .locals 9

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->zvd()I

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_4

    invoke-virtual {p1}, Landroidx/recyclerview/widget/RecyclerView$VocHEe;->AZxh()I

    move-result v0

    if-nez v0, :cond_0

    goto/16 :goto_1

    :cond_0
    invoke-virtual {p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->qrxT()V

    invoke-virtual {p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->UOnCkw()Z

    move-result v0

    xor-int/lit8 v2, v0, 0x1

    const/4 v3, 0x1

    invoke-virtual {p0, v2, v3}, Landroidx/recyclerview/widget/LinearLayoutManager;->xbjHT(ZZ)Landroid/view/View;

    move-result-object v2

    xor-int/lit8 v4, v0, 0x1

    invoke-virtual {p0, v4, v3}, Landroidx/recyclerview/widget/LinearLayoutManager;->EoC(ZZ)Landroid/view/View;

    move-result-object v4

    if-eqz v2, :cond_4

    if-nez v4, :cond_1

    goto/16 :goto_1

    :cond_1
    iget-object v5, p0, Landroidx/recyclerview/widget/GridLayoutManager;->NPj:Landroidx/recyclerview/widget/GridLayoutManager$wA;

    invoke-virtual {p0, v2}, Landroidx/recyclerview/widget/RecyclerView$qGY;->tQ(Landroid/view/View;)I

    move-result v6

    iget v7, p0, Landroidx/recyclerview/widget/GridLayoutManager;->KLMXS:I

    invoke-virtual {v5, v6, v7}, Landroidx/recyclerview/widget/GridLayoutManager$wA;->AZxh(II)I

    move-result v5

    iget-object v6, p0, Landroidx/recyclerview/widget/GridLayoutManager;->NPj:Landroidx/recyclerview/widget/GridLayoutManager$wA;

    invoke-virtual {p0, v4}, Landroidx/recyclerview/widget/RecyclerView$qGY;->tQ(Landroid/view/View;)I

    move-result v7

    iget v8, p0, Landroidx/recyclerview/widget/GridLayoutManager;->KLMXS:I

    invoke-virtual {v6, v7, v8}, Landroidx/recyclerview/widget/GridLayoutManager$wA;->AZxh(II)I

    move-result v6

    invoke-static {v5, v6}, Ljava/lang/Math;->min(II)I

    move-result v7

    invoke-static {v5, v6}, Ljava/lang/Math;->max(II)I

    move-result v5

    iget-object v6, p0, Landroidx/recyclerview/widget/GridLayoutManager;->NPj:Landroidx/recyclerview/widget/GridLayoutManager$wA;

    invoke-virtual {p1}, Landroidx/recyclerview/widget/RecyclerView$VocHEe;->AZxh()I

    move-result p1

    sub-int/2addr p1, v3

    iget v8, p0, Landroidx/recyclerview/widget/GridLayoutManager;->KLMXS:I

    invoke-virtual {v6, p1, v8}, Landroidx/recyclerview/widget/GridLayoutManager$wA;->AZxh(II)I

    move-result p1

    add-int/2addr p1, v3

    iget-boolean v6, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->Gd:Z

    if-eqz v6, :cond_2

    sub-int/2addr p1, v5

    sub-int/2addr p1, v3

    invoke-static {v1, p1}, Ljava/lang/Math;->max(II)I

    move-result p1

    goto :goto_0

    :cond_2
    invoke-static {v1, v7}, Ljava/lang/Math;->max(II)I

    move-result p1

    :goto_0
    if-nez v0, :cond_3

    return p1

    :cond_3
    iget-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v0, v4}, Landroidx/recyclerview/widget/qdMbNW;->ZfxDd(Landroid/view/View;)I

    move-result v0

    iget-object v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v1, v2}, Landroidx/recyclerview/widget/qdMbNW;->xJ(Landroid/view/View;)I

    move-result v1

    sub-int/2addr v0, v1

    invoke-static {v0}, Ljava/lang/Math;->abs(I)I

    move-result v0

    iget-object v1, p0, Landroidx/recyclerview/widget/GridLayoutManager;->NPj:Landroidx/recyclerview/widget/GridLayoutManager$wA;

    invoke-virtual {p0, v2}, Landroidx/recyclerview/widget/RecyclerView$qGY;->tQ(Landroid/view/View;)I

    move-result v5

    iget v6, p0, Landroidx/recyclerview/widget/GridLayoutManager;->KLMXS:I

    invoke-virtual {v1, v5, v6}, Landroidx/recyclerview/widget/GridLayoutManager$wA;->AZxh(II)I

    move-result v1

    iget-object v5, p0, Landroidx/recyclerview/widget/GridLayoutManager;->NPj:Landroidx/recyclerview/widget/GridLayoutManager$wA;

    invoke-virtual {p0, v4}, Landroidx/recyclerview/widget/RecyclerView$qGY;->tQ(Landroid/view/View;)I

    move-result v4

    iget v6, p0, Landroidx/recyclerview/widget/GridLayoutManager;->KLMXS:I

    invoke-virtual {v5, v4, v6}, Landroidx/recyclerview/widget/GridLayoutManager$wA;->AZxh(II)I

    move-result v4

    sub-int/2addr v4, v1

    add-int/2addr v4, v3

    int-to-float v0, v0

    int-to-float v1, v4

    div-float/2addr v0, v1

    int-to-float p1, p1

    mul-float/2addr p1, v0

    iget-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v0}, Landroidx/recyclerview/widget/qdMbNW;->MiMN()I

    move-result v0

    iget-object p0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {p0, v2}, Landroidx/recyclerview/widget/qdMbNW;->xJ(Landroid/view/View;)I

    move-result p0

    sub-int/2addr v0, p0

    int-to-float p0, v0

    add-float/2addr p1, p0

    invoke-static {p1}, Ljava/lang/Math;->round(F)I

    move-result p0

    return p0

    :cond_4
    :goto_1
    return v1
.end method

.method public gtr(Landroid/view/View;ILandroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;)Landroid/view/View;
    .locals 23

    move-object/from16 v0, p0

    move-object/from16 v1, p3

    move-object/from16 v2, p4

    invoke-virtual/range {p0 .. p1}, Landroidx/recyclerview/widget/RecyclerView$qGY;->lB(Landroid/view/View;)Landroid/view/View;

    move-result-object v3

    const/4 v4, 0x0

    if-nez v3, :cond_0

    return-object v4

    :cond_0
    invoke-virtual {v3}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v5

    check-cast v5, Landroidx/recyclerview/widget/GridLayoutManager$AZxh;

    iget v6, v5, Landroidx/recyclerview/widget/GridLayoutManager$AZxh;->KLFTb:I

    iget v5, v5, Landroidx/recyclerview/widget/GridLayoutManager$AZxh;->JHa:I

    add-int/2addr v5, v6

    invoke-super/range {p0 .. p4}, Landroidx/recyclerview/widget/LinearLayoutManager;->gtr(Landroid/view/View;ILandroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;)Landroid/view/View;

    move-result-object v7

    if-nez v7, :cond_1

    return-object v4

    :cond_1
    move/from16 v7, p2

    invoke-virtual {v0, v7}, Landroidx/recyclerview/widget/LinearLayoutManager;->KSf(I)I

    move-result v7

    const/4 v9, 0x1

    if-ne v7, v9, :cond_2

    move v7, v9

    goto :goto_0

    :cond_2
    const/4 v7, 0x0

    :goto_0
    iget-boolean v10, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->Gd:Z

    const/4 v11, -0x1

    if-eq v7, v10, :cond_3

    invoke-virtual/range {p0 .. p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->zvd()I

    move-result v7

    sub-int/2addr v7, v9

    move v10, v11

    move v12, v10

    goto :goto_1

    :cond_3
    invoke-virtual/range {p0 .. p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->zvd()I

    move-result v7

    move v10, v7

    move v12, v9

    const/4 v7, 0x0

    :goto_1
    iget v13, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->Pq:I

    if-ne v13, v9, :cond_4

    invoke-virtual/range {p0 .. p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->jY()Z

    move-result v13

    if-eqz v13, :cond_4

    move v13, v9

    goto :goto_2

    :cond_4
    const/4 v13, 0x0

    :goto_2
    invoke-virtual {v0, v1, v2, v7}, Landroidx/recyclerview/widget/GridLayoutManager;->sZ(Landroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;I)I

    move-result v14

    move v15, v11

    move/from16 v16, v15

    const/4 v8, 0x0

    const/16 v17, 0x0

    move v11, v7

    move-object v7, v4

    :goto_3
    if-eq v11, v10, :cond_5

    invoke-virtual {v0, v1, v2, v11}, Landroidx/recyclerview/widget/GridLayoutManager;->sZ(Landroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;I)I

    move-result v9

    invoke-virtual {v0, v11}, Landroidx/recyclerview/widget/RecyclerView$qGY;->KLMXS(I)Landroid/view/View;

    move-result-object v1

    if-ne v1, v3, :cond_6

    :cond_5
    :goto_4
    move-object/from16 v21, v7

    goto/16 :goto_c

    :cond_6
    invoke-virtual {v1}, Landroid/view/View;->hasFocusable()Z

    move-result v18

    if-eqz v18, :cond_a

    if-eq v9, v14, :cond_a

    if-eqz v4, :cond_7

    goto :goto_4

    :cond_7
    move-object/from16 v18, v3

    move-object/from16 v21, v7

    :cond_8
    move/from16 v19, v8

    move/from16 v20, v10

    :cond_9
    move/from16 v7, v16

    move/from16 v8, v17

    goto/16 :goto_a

    :cond_a
    invoke-virtual {v1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v9

    check-cast v9, Landroidx/recyclerview/widget/GridLayoutManager$AZxh;

    iget v2, v9, Landroidx/recyclerview/widget/GridLayoutManager$AZxh;->KLFTb:I

    move-object/from16 v18, v3

    iget v3, v9, Landroidx/recyclerview/widget/GridLayoutManager$AZxh;->JHa:I

    add-int/2addr v3, v2

    invoke-virtual {v1}, Landroid/view/View;->hasFocusable()Z

    move-result v19

    if-eqz v19, :cond_b

    if-ne v2, v6, :cond_b

    if-ne v3, v5, :cond_b

    return-object v1

    :cond_b
    invoke-virtual {v1}, Landroid/view/View;->hasFocusable()Z

    move-result v19

    if-eqz v19, :cond_c

    if-eqz v4, :cond_d

    :cond_c
    invoke-virtual {v1}, Landroid/view/View;->hasFocusable()Z

    move-result v19

    if-nez v19, :cond_e

    if-nez v7, :cond_e

    :cond_d
    move-object/from16 v21, v7

    :goto_5
    move/from16 v19, v8

    move/from16 v20, v10

    move/from16 v7, v16

    move/from16 v8, v17

    goto :goto_9

    :cond_e
    invoke-static {v2, v6}, Ljava/lang/Math;->max(II)I

    move-result v19

    invoke-static {v3, v5}, Ljava/lang/Math;->min(II)I

    move-result v20

    move-object/from16 v21, v7

    sub-int v7, v20, v19

    invoke-virtual {v1}, Landroid/view/View;->hasFocusable()Z

    move-result v19

    if-eqz v19, :cond_11

    if-le v7, v8, :cond_f

    :goto_6
    goto :goto_5

    :cond_f
    if-ne v7, v8, :cond_8

    if-le v2, v15, :cond_10

    const/4 v7, 0x1

    goto :goto_7

    :cond_10
    const/4 v7, 0x0

    :goto_7
    if-ne v13, v7, :cond_8

    goto :goto_6

    :cond_11
    if-nez v4, :cond_8

    move/from16 v19, v8

    move/from16 v20, v10

    const/4 v8, 0x0

    const/4 v10, 0x1

    invoke-virtual {v0, v1, v8, v10}, Landroidx/recyclerview/widget/RecyclerView$qGY;->XbiWeM(Landroid/view/View;ZZ)Z

    move-result v22

    if-eqz v22, :cond_9

    move/from16 v8, v17

    if-le v7, v8, :cond_12

    move/from16 v7, v16

    goto :goto_9

    :cond_12
    if-ne v7, v8, :cond_15

    move/from16 v7, v16

    if-le v2, v7, :cond_13

    goto :goto_8

    :cond_13
    const/4 v10, 0x0

    :goto_8
    if-ne v13, v10, :cond_16

    :goto_9
    invoke-virtual {v1}, Landroid/view/View;->hasFocusable()Z

    move-result v10

    if-eqz v10, :cond_14

    iget v4, v9, Landroidx/recyclerview/widget/GridLayoutManager$AZxh;->KLFTb:I

    invoke-static {v3, v5}, Ljava/lang/Math;->min(II)I

    move-result v3

    invoke-static {v2, v6}, Ljava/lang/Math;->max(II)I

    move-result v2

    sub-int v2, v3, v2

    move v15, v4

    move/from16 v16, v7

    move/from16 v17, v8

    move-object/from16 v7, v21

    move-object v4, v1

    move v8, v2

    goto :goto_b

    :cond_14
    iget v7, v9, Landroidx/recyclerview/widget/GridLayoutManager$AZxh;->KLFTb:I

    invoke-static {v3, v5}, Ljava/lang/Math;->min(II)I

    move-result v3

    invoke-static {v2, v6}, Ljava/lang/Math;->max(II)I

    move-result v2

    sub-int v17, v3, v2

    move/from16 v16, v7

    move/from16 v8, v19

    move-object v7, v1

    goto :goto_b

    :cond_15
    move/from16 v7, v16

    :cond_16
    :goto_a
    move/from16 v16, v7

    move/from16 v17, v8

    move/from16 v8, v19

    move-object/from16 v7, v21

    :goto_b
    add-int/2addr v11, v12

    move-object/from16 v1, p3

    move-object/from16 v2, p4

    move-object/from16 v3, v18

    move/from16 v10, v20

    const/4 v9, 0x1

    goto/16 :goto_3

    :goto_c
    if-eqz v4, :cond_17

    goto :goto_d

    :cond_17
    move-object/from16 v4, v21

    :goto_d
    return-object v4
.end method

.method public huTpC(Landroidx/recyclerview/widget/RecyclerView$VocHEe;)I
    .locals 1

    iget-boolean v0, p0, Landroidx/recyclerview/widget/GridLayoutManager;->oCFDzJ:Z

    if-eqz v0, :cond_0

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/GridLayoutManager;->kw(Landroidx/recyclerview/widget/RecyclerView$VocHEe;)I

    move-result p0

    return p0

    :cond_0
    invoke-super {p0, p1}, Landroidx/recyclerview/widget/LinearLayoutManager;->huTpC(Landroidx/recyclerview/widget/RecyclerView$VocHEe;)I

    move-result p0

    return p0
.end method

.method public hvGY(Landroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;Lo/Ucbh;)V
    .locals 0

    invoke-super {p0, p1, p2, p3}, Landroidx/recyclerview/widget/RecyclerView$qGY;->hvGY(Landroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;Lo/Ucbh;)V

    const-class p0, Landroid/widget/GridView;

    invoke-virtual {p0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p3, p0}, Lo/Ucbh;->bbzow(Ljava/lang/CharSequence;)V

    return-void
.end method

.method public final ih(Landroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;I)V
    .locals 4

    const/4 v0, 0x1

    if-ne p4, v0, :cond_0

    move p4, v0

    goto :goto_0

    :cond_0
    const/4 p4, 0x0

    :goto_0
    iget v1, p3, Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;->AZxh:I

    invoke-virtual {p0, p1, p2, v1}, Landroidx/recyclerview/widget/GridLayoutManager;->Zerm(Landroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;I)I

    move-result v1

    if-eqz p4, :cond_1

    :goto_1
    if-lez v1, :cond_3

    iget p4, p3, Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;->AZxh:I

    if-lez p4, :cond_3

    add-int/lit8 p4, p4, -0x1

    iput p4, p3, Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;->AZxh:I

    invoke-virtual {p0, p1, p2, p4}, Landroidx/recyclerview/widget/GridLayoutManager;->Zerm(Landroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;I)I

    move-result v1

    goto :goto_1

    :cond_1
    invoke-virtual {p2}, Landroidx/recyclerview/widget/RecyclerView$VocHEe;->AZxh()I

    move-result p4

    sub-int/2addr p4, v0

    iget v0, p3, Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;->AZxh:I

    :goto_2
    if-ge v0, p4, :cond_2

    add-int/lit8 v2, v0, 0x1

    invoke-virtual {p0, p1, p2, v2}, Landroidx/recyclerview/widget/GridLayoutManager;->Zerm(Landroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;I)I

    move-result v3

    if-le v3, v1, :cond_2

    move v0, v2

    move v1, v3

    goto :goto_2

    :cond_2
    iput v0, p3, Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;->AZxh:I

    :cond_3
    return-void
.end method

.method public final joWJO()V
    .locals 2

    invoke-virtual {p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->UDcil()I

    move-result v0

    const/4 v1, 0x1

    if-ne v0, v1, :cond_0

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->SOS()I

    move-result v0

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->ANMGZc()I

    move-result v1

    sub-int/2addr v0, v1

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->jm()I

    move-result v1

    :goto_0
    sub-int/2addr v0, v1

    goto :goto_1

    :cond_0
    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->JYgkl()I

    move-result v0

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->JBhc()I

    move-result v1

    sub-int/2addr v0, v1

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->dm()I

    move-result v1

    goto :goto_0

    :goto_1
    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/GridLayoutManager;->gJsSk(I)V

    return-void
.end method

.method public jtz(Landroidx/recyclerview/widget/RecyclerView;III)V
    .locals 0

    iget-object p1, p0, Landroidx/recyclerview/widget/GridLayoutManager;->NPj:Landroidx/recyclerview/widget/GridLayoutManager$wA;

    invoke-virtual {p1}, Landroidx/recyclerview/widget/GridLayoutManager$wA;->lgHUyS()V

    iget-object p0, p0, Landroidx/recyclerview/widget/GridLayoutManager;->NPj:Landroidx/recyclerview/widget/GridLayoutManager$wA;

    invoke-virtual {p0}, Landroidx/recyclerview/widget/GridLayoutManager$wA;->xJ()V

    return-void
.end method

.method public final kw(Landroidx/recyclerview/widget/RecyclerView$VocHEe;)I
    .locals 6

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->zvd()I

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_3

    invoke-virtual {p1}, Landroidx/recyclerview/widget/RecyclerView$VocHEe;->AZxh()I

    move-result v0

    if-nez v0, :cond_0

    goto :goto_0

    :cond_0
    invoke-virtual {p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->qrxT()V

    invoke-virtual {p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->UOnCkw()Z

    move-result v0

    const/4 v2, 0x1

    xor-int/2addr v0, v2

    invoke-virtual {p0, v0, v2}, Landroidx/recyclerview/widget/LinearLayoutManager;->xbjHT(ZZ)Landroid/view/View;

    move-result-object v0

    invoke-virtual {p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->UOnCkw()Z

    move-result v3

    xor-int/2addr v3, v2

    invoke-virtual {p0, v3, v2}, Landroidx/recyclerview/widget/LinearLayoutManager;->EoC(ZZ)Landroid/view/View;

    move-result-object v3

    if-eqz v0, :cond_3

    if-nez v3, :cond_1

    goto :goto_0

    :cond_1
    invoke-virtual {p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->UOnCkw()Z

    move-result v1

    if-nez v1, :cond_2

    iget-object v0, p0, Landroidx/recyclerview/widget/GridLayoutManager;->NPj:Landroidx/recyclerview/widget/GridLayoutManager$wA;

    invoke-virtual {p1}, Landroidx/recyclerview/widget/RecyclerView$VocHEe;->AZxh()I

    move-result p1

    sub-int/2addr p1, v2

    iget p0, p0, Landroidx/recyclerview/widget/GridLayoutManager;->KLMXS:I

    invoke-virtual {v0, p1, p0}, Landroidx/recyclerview/widget/GridLayoutManager$wA;->AZxh(II)I

    move-result p0

    add-int/2addr p0, v2

    return p0

    :cond_2
    iget-object v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v1, v3}, Landroidx/recyclerview/widget/qdMbNW;->ZfxDd(Landroid/view/View;)I

    move-result v1

    iget-object v4, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v4, v0}, Landroidx/recyclerview/widget/qdMbNW;->xJ(Landroid/view/View;)I

    move-result v4

    sub-int/2addr v1, v4

    iget-object v4, p0, Landroidx/recyclerview/widget/GridLayoutManager;->NPj:Landroidx/recyclerview/widget/GridLayoutManager$wA;

    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->tQ(Landroid/view/View;)I

    move-result v0

    iget v5, p0, Landroidx/recyclerview/widget/GridLayoutManager;->KLMXS:I

    invoke-virtual {v4, v0, v5}, Landroidx/recyclerview/widget/GridLayoutManager$wA;->AZxh(II)I

    move-result v0

    iget-object v4, p0, Landroidx/recyclerview/widget/GridLayoutManager;->NPj:Landroidx/recyclerview/widget/GridLayoutManager$wA;

    invoke-virtual {p0, v3}, Landroidx/recyclerview/widget/RecyclerView$qGY;->tQ(Landroid/view/View;)I

    move-result v3

    iget v5, p0, Landroidx/recyclerview/widget/GridLayoutManager;->KLMXS:I

    invoke-virtual {v4, v3, v5}, Landroidx/recyclerview/widget/GridLayoutManager$wA;->AZxh(II)I

    move-result v3

    iget-object v4, p0, Landroidx/recyclerview/widget/GridLayoutManager;->NPj:Landroidx/recyclerview/widget/GridLayoutManager$wA;

    invoke-virtual {p1}, Landroidx/recyclerview/widget/RecyclerView$VocHEe;->AZxh()I

    move-result p1

    sub-int/2addr p1, v2

    iget p0, p0, Landroidx/recyclerview/widget/GridLayoutManager;->KLMXS:I

    invoke-virtual {v4, p1, p0}, Landroidx/recyclerview/widget/GridLayoutManager$wA;->AZxh(II)I

    move-result p0

    add-int/2addr p0, v2

    sub-int/2addr v3, v0

    add-int/2addr v3, v2

    int-to-float p1, v1

    int-to-float v0, v3

    div-float/2addr p1, v0

    int-to-float p0, p0

    mul-float/2addr p1, p0

    float-to-int p0, p1

    return p0

    :cond_3
    :goto_0
    return v1
.end method

.method public lEKdq(I)V
    .locals 2

    iget v0, p0, Landroidx/recyclerview/widget/GridLayoutManager;->KLMXS:I

    if-ne p1, v0, :cond_0

    return-void

    :cond_0
    const/4 v0, 0x1

    iput-boolean v0, p0, Landroidx/recyclerview/widget/GridLayoutManager;->xrEuO:Z

    if-lt p1, v0, :cond_1

    iput p1, p0, Landroidx/recyclerview/widget/GridLayoutManager;->KLMXS:I

    iget-object p1, p0, Landroidx/recyclerview/widget/GridLayoutManager;->NPj:Landroidx/recyclerview/widget/GridLayoutManager$wA;

    invoke-virtual {p1}, Landroidx/recyclerview/widget/GridLayoutManager$wA;->lgHUyS()V

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->mzUGzO()V

    return-void

    :cond_1
    new-instance p0, Ljava/lang/IllegalArgumentException;

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "Span count should be at least 1. Provided "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public mByQ()Landroidx/recyclerview/widget/RecyclerView$fehf;
    .locals 2

    iget p0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->Pq:I

    const/4 v0, -0x1

    const/4 v1, -0x2

    if-nez p0, :cond_0

    new-instance p0, Landroidx/recyclerview/widget/GridLayoutManager$AZxh;

    invoke-direct {p0, v1, v0}, Landroidx/recyclerview/widget/GridLayoutManager$AZxh;-><init>(II)V

    return-object p0

    :cond_0
    new-instance p0, Landroidx/recyclerview/widget/GridLayoutManager$AZxh;

    invoke-direct {p0, v0, v1}, Landroidx/recyclerview/widget/GridLayoutManager$AZxh;-><init>(II)V

    return-object p0
.end method

.method public final pCi(FI)V
    .locals 1

    iget v0, p0, Landroidx/recyclerview/widget/GridLayoutManager;->KLMXS:I

    int-to-float v0, v0

    mul-float/2addr p1, v0

    invoke-static {p1}, Ljava/lang/Math;->round(F)I

    move-result p1

    invoke-static {p1, p2}, Ljava/lang/Math;->max(II)I

    move-result p1

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/GridLayoutManager;->gJsSk(I)V

    return-void
.end method

.method public pJeaSR(Landroidx/recyclerview/widget/RecyclerView$VocHEe;Landroidx/recyclerview/widget/LinearLayoutManager$wA;Landroidx/recyclerview/widget/RecyclerView$qGY$wA;)V
    .locals 5

    iget v0, p0, Landroidx/recyclerview/widget/GridLayoutManager;->KLMXS:I

    const/4 v1, 0x0

    move v2, v1

    :goto_0
    iget v3, p0, Landroidx/recyclerview/widget/GridLayoutManager;->KLMXS:I

    if-ge v2, v3, :cond_0

    invoke-virtual {p2, p1}, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->wA(Landroidx/recyclerview/widget/RecyclerView$VocHEe;)Z

    move-result v3

    if-eqz v3, :cond_0

    if-lez v0, :cond_0

    iget v3, p2, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->ZfxDd:I

    iget v4, p2, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->xJ:I

    invoke-static {v1, v4}, Ljava/lang/Math;->max(II)I

    move-result v4

    invoke-interface {p3, v3, v4}, Landroidx/recyclerview/widget/RecyclerView$qGY$wA;->mjFkc(II)V

    iget-object v4, p0, Landroidx/recyclerview/widget/GridLayoutManager;->NPj:Landroidx/recyclerview/widget/GridLayoutManager$wA;

    invoke-virtual {v4, v3}, Landroidx/recyclerview/widget/GridLayoutManager$wA;->JHa(I)I

    move-result v3

    sub-int/2addr v0, v3

    iget v3, p2, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->ZfxDd:I

    iget v4, p2, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->KLFTb:I

    add-int/2addr v3, v4

    iput v3, p2, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->ZfxDd:I

    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_0
    return-void
.end method

.method public rdJr(Landroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;Landroid/view/View;Lo/Ucbh;)V
    .locals 7

    invoke-virtual {p3}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    instance-of v1, v0, Landroidx/recyclerview/widget/GridLayoutManager$AZxh;

    if-nez v1, :cond_0

    invoke-super {p0, p3, p4}, Landroidx/recyclerview/widget/RecyclerView$qGY;->SKTn(Landroid/view/View;Lo/Ucbh;)V

    return-void

    :cond_0
    check-cast v0, Landroidx/recyclerview/widget/GridLayoutManager$AZxh;

    invoke-virtual {v0}, Landroidx/recyclerview/widget/RecyclerView$fehf;->mjFkc()I

    move-result p3

    invoke-virtual {p0, p1, p2, p3}, Landroidx/recyclerview/widget/GridLayoutManager;->sZ(Landroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;I)I

    move-result p1

    iget p0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->Pq:I

    if-nez p0, :cond_1

    invoke-virtual {v0}, Landroidx/recyclerview/widget/GridLayoutManager$AZxh;->KLFTb()I

    move-result v1

    invoke-virtual {v0}, Landroidx/recyclerview/widget/GridLayoutManager$AZxh;->JHa()I

    move-result v2

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v4, 0x1

    move v3, p1

    invoke-static/range {v1 .. v6}, Lo/Ucbh$JHa;->mjFkc(IIIIZZ)Lo/Ucbh$JHa;

    move-result-object p0

    invoke-virtual {p4, p0}, Lo/Ucbh;->Vdz(Ljava/lang/Object;)V

    goto :goto_0

    :cond_1
    invoke-virtual {v0}, Landroidx/recyclerview/widget/GridLayoutManager$AZxh;->KLFTb()I

    move-result v3

    invoke-virtual {v0}, Landroidx/recyclerview/widget/GridLayoutManager$AZxh;->JHa()I

    move-result v4

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v2, 0x1

    move v1, p1

    invoke-static/range {v1 .. v6}, Lo/Ucbh$JHa;->mjFkc(IIIIZZ)Lo/Ucbh$JHa;

    move-result-object p0

    invoke-virtual {p4, p0}, Lo/Ucbh;->Vdz(Ljava/lang/Object;)V

    :goto_0
    return-void
.end method

.method public final sZ(Landroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;I)I
    .locals 0

    invoke-virtual {p2}, Landroidx/recyclerview/widget/RecyclerView$VocHEe;->KLFTb()Z

    move-result p2

    if-nez p2, :cond_0

    iget-object p1, p0, Landroidx/recyclerview/widget/GridLayoutManager;->NPj:Landroidx/recyclerview/widget/GridLayoutManager$wA;

    iget p0, p0, Landroidx/recyclerview/widget/GridLayoutManager;->KLMXS:I

    invoke-virtual {p1, p3, p0}, Landroidx/recyclerview/widget/GridLayoutManager$wA;->AZxh(II)I

    move-result p0

    return p0

    :cond_0
    invoke-virtual {p1, p3}, Landroidx/recyclerview/widget/RecyclerView$Ucbh;->JHa(I)I

    move-result p1

    const/4 p2, -0x1

    if-ne p1, p2, :cond_1

    new-instance p0, Ljava/lang/StringBuilder;

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    const-string p1, "Cannot find span size for pre layout position. "

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0, p3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const-string p1, "GridLayoutManager"

    invoke-static {p1, p0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    const/4 p0, 0x0

    return p0

    :cond_1
    iget-object p2, p0, Landroidx/recyclerview/widget/GridLayoutManager;->NPj:Landroidx/recyclerview/widget/GridLayoutManager$wA;

    iget p0, p0, Landroidx/recyclerview/widget/GridLayoutManager;->KLMXS:I

    invoke-virtual {p2, p1, p0}, Landroidx/recyclerview/widget/GridLayoutManager$wA;->AZxh(II)I

    move-result p0

    return p0
.end method

.method public tAfC(Landroidx/recyclerview/widget/RecyclerView;IILjava/lang/Object;)V
    .locals 0

    iget-object p1, p0, Landroidx/recyclerview/widget/GridLayoutManager;->NPj:Landroidx/recyclerview/widget/GridLayoutManager$wA;

    invoke-virtual {p1}, Landroidx/recyclerview/widget/GridLayoutManager$wA;->lgHUyS()V

    iget-object p0, p0, Landroidx/recyclerview/widget/GridLayoutManager;->NPj:Landroidx/recyclerview/widget/GridLayoutManager$wA;

    invoke-virtual {p0}, Landroidx/recyclerview/widget/GridLayoutManager$wA;->xJ()V

    return-void
.end method

.method public wGscSa(Landroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;I)V
    .locals 1

    invoke-super {p0, p1, p2, p3, p4}, Landroidx/recyclerview/widget/LinearLayoutManager;->wGscSa(Landroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;I)V

    invoke-virtual {p0}, Landroidx/recyclerview/widget/GridLayoutManager;->joWJO()V

    invoke-virtual {p2}, Landroidx/recyclerview/widget/RecyclerView$VocHEe;->AZxh()I

    move-result v0

    if-lez v0, :cond_0

    invoke-virtual {p2}, Landroidx/recyclerview/widget/RecyclerView$VocHEe;->KLFTb()Z

    move-result v0

    if-nez v0, :cond_0

    invoke-virtual {p0, p1, p2, p3, p4}, Landroidx/recyclerview/widget/GridLayoutManager;->ih(Landroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;I)V

    :cond_0
    invoke-virtual {p0}, Landroidx/recyclerview/widget/GridLayoutManager;->KbE()V

    return-void
.end method

.method public xBQUgd(Z)V
    .locals 0

    if-nez p1, :cond_0

    const/4 p1, 0x0

    invoke-super {p0, p1}, Landroidx/recyclerview/widget/LinearLayoutManager;->xBQUgd(Z)V

    return-void

    :cond_0
    new-instance p0, Ljava/lang/UnsupportedOperationException;

    const-string p1, "GridLayoutManager does not support stack from end. Consider using reverse layout"

    invoke-direct {p0, p1}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public xCVa(Landroid/graphics/Rect;II)V
    .locals 4

    iget-object v0, p0, Landroidx/recyclerview/widget/GridLayoutManager;->zvd:[I

    if-nez v0, :cond_0

    invoke-super {p0, p1, p2, p3}, Landroidx/recyclerview/widget/RecyclerView$qGY;->xCVa(Landroid/graphics/Rect;II)V

    :cond_0
    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->jm()I

    move-result v0

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->ANMGZc()I

    move-result v1

    add-int/2addr v0, v1

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->dm()I

    move-result v1

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->JBhc()I

    move-result v2

    add-int/2addr v1, v2

    iget v2, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->Pq:I

    const/4 v3, 0x1

    if-ne v2, v3, :cond_1

    invoke-virtual {p1}, Landroid/graphics/Rect;->height()I

    move-result p1

    add-int/2addr p1, v1

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->bbzow()I

    move-result v1

    invoke-static {p3, p1, v1}, Landroidx/recyclerview/widget/RecyclerView$qGY;->rkYL(III)I

    move-result p1

    iget-object p3, p0, Landroidx/recyclerview/widget/GridLayoutManager;->zvd:[I

    array-length v1, p3

    sub-int/2addr v1, v3

    aget p3, p3, v1

    add-int/2addr p3, v0

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->SwgkN()I

    move-result v0

    invoke-static {p2, p3, v0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->rkYL(III)I

    move-result p2

    goto :goto_0

    :cond_1
    invoke-virtual {p1}, Landroid/graphics/Rect;->width()I

    move-result p1

    add-int/2addr p1, v0

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->SwgkN()I

    move-result v0

    invoke-static {p2, p1, v0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->rkYL(III)I

    move-result p2

    iget-object p1, p0, Landroidx/recyclerview/widget/GridLayoutManager;->zvd:[I

    array-length v0, p1

    sub-int/2addr v0, v3

    aget p1, p1, v0

    add-int/2addr p1, v1

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->bbzow()I

    move-result v0

    invoke-static {p3, p1, v0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->rkYL(III)I

    move-result p1

    :goto_0
    invoke-virtual {p0, p2, p1}, Landroidx/recyclerview/widget/RecyclerView$qGY;->ub(II)V

    return-void
.end method

.method public xROA(Landroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;)I
    .locals 2

    iget v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->Pq:I

    if-nez v0, :cond_0

    iget p0, p0, Landroidx/recyclerview/widget/GridLayoutManager;->KLMXS:I

    return p0

    :cond_0
    invoke-virtual {p2}, Landroidx/recyclerview/widget/RecyclerView$VocHEe;->AZxh()I

    move-result v0

    const/4 v1, 0x1

    if-ge v0, v1, :cond_1

    const/4 p0, 0x0

    return p0

    :cond_1
    invoke-virtual {p2}, Landroidx/recyclerview/widget/RecyclerView$VocHEe;->AZxh()I

    move-result v0

    sub-int/2addr v0, v1

    invoke-virtual {p0, p1, p2, v0}, Landroidx/recyclerview/widget/GridLayoutManager;->sZ(Landroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;I)I

    move-result p0

    add-int/2addr p0, v1

    return p0
.end method

.method public final xVYW()V
    .locals 1

    iget-object v0, p0, Landroidx/recyclerview/widget/GridLayoutManager;->rWxwaT:Landroid/util/SparseIntArray;

    invoke-virtual {v0}, Landroid/util/SparseIntArray;->clear()V

    iget-object p0, p0, Landroidx/recyclerview/widget/GridLayoutManager;->Vnb:Landroid/util/SparseIntArray;

    invoke-virtual {p0}, Landroid/util/SparseIntArray;->clear()V

    return-void
.end method

.method public xfXeiC(Landroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;ZZ)Landroid/view/View;
    .locals 9

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->zvd()I

    move-result p3

    const/4 v0, 0x1

    if-eqz p4, :cond_0

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->zvd()I

    move-result p3

    sub-int/2addr p3, v0

    const/4 p4, -0x1

    move v0, p4

    goto :goto_0

    :cond_0
    const/4 p4, 0x0

    move v8, p4

    move p4, p3

    move p3, v8

    :goto_0
    invoke-virtual {p2}, Landroidx/recyclerview/widget/RecyclerView$VocHEe;->AZxh()I

    move-result v1

    invoke-virtual {p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->qrxT()V

    iget-object v2, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v2}, Landroidx/recyclerview/widget/qdMbNW;->MiMN()I

    move-result v2

    iget-object v3, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v3}, Landroidx/recyclerview/widget/qdMbNW;->qdMbNW()I

    move-result v3

    const/4 v4, 0x0

    move-object v5, v4

    :goto_1
    if-eq p3, p4, :cond_6

    invoke-virtual {p0, p3}, Landroidx/recyclerview/widget/RecyclerView$qGY;->KLMXS(I)Landroid/view/View;

    move-result-object v6

    invoke-virtual {p0, v6}, Landroidx/recyclerview/widget/RecyclerView$qGY;->tQ(Landroid/view/View;)I

    move-result v7

    if-ltz v7, :cond_5

    if-ge v7, v1, :cond_5

    invoke-virtual {p0, p1, p2, v7}, Landroidx/recyclerview/widget/GridLayoutManager;->Zerm(Landroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;I)I

    move-result v7

    if-eqz v7, :cond_1

    goto :goto_3

    :cond_1
    invoke-virtual {v6}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v7

    check-cast v7, Landroidx/recyclerview/widget/RecyclerView$fehf;

    invoke-virtual {v7}, Landroidx/recyclerview/widget/RecyclerView$fehf;->wA()Z

    move-result v7

    if-eqz v7, :cond_2

    if-nez v5, :cond_5

    move-object v5, v6

    goto :goto_3

    :cond_2
    iget-object v7, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v7, v6}, Landroidx/recyclerview/widget/qdMbNW;->xJ(Landroid/view/View;)I

    move-result v7

    if-ge v7, v3, :cond_4

    iget-object v7, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v7, v6}, Landroidx/recyclerview/widget/qdMbNW;->ZfxDd(Landroid/view/View;)I

    move-result v7

    if-ge v7, v2, :cond_3

    goto :goto_2

    :cond_3
    return-object v6

    :cond_4
    :goto_2
    if-nez v4, :cond_5

    move-object v4, v6

    :cond_5
    :goto_3
    add-int/2addr p3, v0

    goto :goto_1

    :cond_6
    if-eqz v4, :cond_7

    goto :goto_4

    :cond_7
    move-object v4, v5

    :goto_4
    return-object v4
.end method
