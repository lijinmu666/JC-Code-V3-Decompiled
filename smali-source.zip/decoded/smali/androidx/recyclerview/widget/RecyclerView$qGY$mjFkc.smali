.class public Landroidx/recyclerview/widget/RecyclerView$qGY$mjFkc;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/recyclerview/widget/rkYL$AZxh;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/recyclerview/widget/RecyclerView$qGY;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic mjFkc:Landroidx/recyclerview/widget/RecyclerView$qGY;


# direct methods
.method public constructor <init>(Landroidx/recyclerview/widget/RecyclerView$qGY;)V
    .locals 0

    iput-object p1, p0, Landroidx/recyclerview/widget/RecyclerView$qGY$mjFkc;->mjFkc:Landroidx/recyclerview/widget/RecyclerView$qGY;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public AZxh()I
    .locals 1

    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView$qGY$mjFkc;->mjFkc:Landroidx/recyclerview/widget/RecyclerView$qGY;

    invoke-virtual {v0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->SOS()I

    move-result v0

    iget-object p0, p0, Landroidx/recyclerview/widget/RecyclerView$qGY$mjFkc;->mjFkc:Landroidx/recyclerview/widget/RecyclerView$qGY;

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->ANMGZc()I

    move-result p0

    sub-int/2addr v0, p0

    return v0
.end method

.method public KLFTb(Landroid/view/View;)I
    .locals 1

    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    check-cast v0, Landroidx/recyclerview/widget/RecyclerView$fehf;

    iget-object p0, p0, Landroidx/recyclerview/widget/RecyclerView$qGY$mjFkc;->mjFkc:Landroidx/recyclerview/widget/RecyclerView$qGY;

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/RecyclerView$qGY;->GMIER(Landroid/view/View;)I

    move-result p0

    iget p1, v0, Landroid/view/ViewGroup$MarginLayoutParams;->rightMargin:I

    add-int/2addr p0, p1

    return p0
.end method

.method public ZfxDd()I
    .locals 0

    iget-object p0, p0, Landroidx/recyclerview/widget/RecyclerView$qGY$mjFkc;->mjFkc:Landroidx/recyclerview/widget/RecyclerView$qGY;

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->jm()I

    move-result p0

    return p0
.end method

.method public mjFkc(I)Landroid/view/View;
    .locals 0

    iget-object p0, p0, Landroidx/recyclerview/widget/RecyclerView$qGY$mjFkc;->mjFkc:Landroidx/recyclerview/widget/RecyclerView$qGY;

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/RecyclerView$qGY;->KLMXS(I)Landroid/view/View;

    move-result-object p0

    return-object p0
.end method

.method public wA(Landroid/view/View;)I
    .locals 1

    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    check-cast v0, Landroidx/recyclerview/widget/RecyclerView$fehf;

    iget-object p0, p0, Landroidx/recyclerview/widget/RecyclerView$qGY$mjFkc;->mjFkc:Landroidx/recyclerview/widget/RecyclerView$qGY;

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/RecyclerView$qGY;->aqHPIZ(Landroid/view/View;)I

    move-result p0

    iget p1, v0, Landroid/view/ViewGroup$MarginLayoutParams;->leftMargin:I

    sub-int/2addr p0, p1

    return p0
.end method
