.class public Landroidx/recyclerview/widget/RecyclerView$MiMN$AZxh;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/recyclerview/widget/RecyclerView$MiMN;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "AZxh"
.end annotation


# instance fields
.field public AZxh:I

.field public ZfxDd:I

.field public mjFkc:I

.field public wA:I


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public AZxh(Landroidx/recyclerview/widget/RecyclerView$mByQ;I)Landroidx/recyclerview/widget/RecyclerView$MiMN$AZxh;
    .locals 0

    iget-object p1, p1, Landroidx/recyclerview/widget/RecyclerView$mByQ;->mjFkc:Landroid/view/View;

    invoke-virtual {p1}, Landroid/view/View;->getLeft()I

    move-result p2

    iput p2, p0, Landroidx/recyclerview/widget/RecyclerView$MiMN$AZxh;->mjFkc:I

    invoke-virtual {p1}, Landroid/view/View;->getTop()I

    move-result p2

    iput p2, p0, Landroidx/recyclerview/widget/RecyclerView$MiMN$AZxh;->AZxh:I

    invoke-virtual {p1}, Landroid/view/View;->getRight()I

    move-result p2

    iput p2, p0, Landroidx/recyclerview/widget/RecyclerView$MiMN$AZxh;->wA:I

    invoke-virtual {p1}, Landroid/view/View;->getBottom()I

    move-result p1

    iput p1, p0, Landroidx/recyclerview/widget/RecyclerView$MiMN$AZxh;->ZfxDd:I

    return-object p0
.end method

.method public mjFkc(Landroidx/recyclerview/widget/RecyclerView$mByQ;)Landroidx/recyclerview/widget/RecyclerView$MiMN$AZxh;
    .locals 1

    const/4 v0, 0x0

    invoke-virtual {p0, p1, v0}, Landroidx/recyclerview/widget/RecyclerView$MiMN$AZxh;->AZxh(Landroidx/recyclerview/widget/RecyclerView$mByQ;I)Landroidx/recyclerview/widget/RecyclerView$MiMN$AZxh;

    move-result-object p0

    return-object p0
.end method
