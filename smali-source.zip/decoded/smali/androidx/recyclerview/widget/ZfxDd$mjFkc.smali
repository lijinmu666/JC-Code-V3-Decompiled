.class public Landroidx/recyclerview/widget/ZfxDd$mjFkc;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/recyclerview/widget/ZfxDd;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic mjFkc:Landroidx/recyclerview/widget/ZfxDd;


# direct methods
.method public constructor <init>(Landroidx/recyclerview/widget/ZfxDd;)V
    .locals 0

    iput-object p1, p0, Landroidx/recyclerview/widget/ZfxDd$mjFkc;->mjFkc:Landroidx/recyclerview/widget/ZfxDd;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 1

    iget-object p0, p0, Landroidx/recyclerview/widget/ZfxDd$mjFkc;->mjFkc:Landroidx/recyclerview/widget/ZfxDd;

    const/16 v0, 0x1f4

    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/ZfxDd;->fehf(I)V

    return-void
.end method
