.class public Landroidx/recyclerview/widget/RecyclerView$HGpJ$mjFkc;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/os/Parcelable$ClassLoaderCreator;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/recyclerview/widget/RecyclerView$HGpJ;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public AZxh(Landroid/os/Parcel;Ljava/lang/ClassLoader;)Landroidx/recyclerview/widget/RecyclerView$HGpJ;
    .locals 0

    new-instance p0, Landroidx/recyclerview/widget/RecyclerView$HGpJ;

    invoke-direct {p0, p1, p2}, Landroidx/recyclerview/widget/RecyclerView$HGpJ;-><init>(Landroid/os/Parcel;Ljava/lang/ClassLoader;)V

    return-object p0
.end method

.method public bridge synthetic createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;
    .locals 0

    .line 1
    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/RecyclerView$HGpJ$mjFkc;->mjFkc(Landroid/os/Parcel;)Landroidx/recyclerview/widget/RecyclerView$HGpJ;

    move-result-object p0

    return-object p0
.end method

.method public bridge synthetic createFromParcel(Landroid/os/Parcel;Ljava/lang/ClassLoader;)Ljava/lang/Object;
    .locals 0

    .line 2
    invoke-virtual {p0, p1, p2}, Landroidx/recyclerview/widget/RecyclerView$HGpJ$mjFkc;->AZxh(Landroid/os/Parcel;Ljava/lang/ClassLoader;)Landroidx/recyclerview/widget/RecyclerView$HGpJ;

    move-result-object p0

    return-object p0
.end method

.method public mjFkc(Landroid/os/Parcel;)Landroidx/recyclerview/widget/RecyclerView$HGpJ;
    .locals 1

    new-instance p0, Landroidx/recyclerview/widget/RecyclerView$HGpJ;

    const/4 v0, 0x0

    invoke-direct {p0, p1, v0}, Landroidx/recyclerview/widget/RecyclerView$HGpJ;-><init>(Landroid/os/Parcel;Ljava/lang/ClassLoader;)V

    return-object p0
.end method

.method public bridge synthetic newArray(I)[Ljava/lang/Object;
    .locals 0

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/RecyclerView$HGpJ$mjFkc;->wA(I)[Landroidx/recyclerview/widget/RecyclerView$HGpJ;

    move-result-object p0

    return-object p0
.end method

.method public wA(I)[Landroidx/recyclerview/widget/RecyclerView$HGpJ;
    .locals 0

    new-array p0, p1, [Landroidx/recyclerview/widget/RecyclerView$HGpJ;

    return-object p0
.end method
