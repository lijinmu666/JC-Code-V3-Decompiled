.class public interface abstract Landroidx/recyclerview/widget/RecyclerView$vI$AZxh;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/recyclerview/widget/RecyclerView$vI;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "AZxh"
.end annotation


# virtual methods
.method public abstract AZxh(I)Landroid/graphics/PointF;
.end method
