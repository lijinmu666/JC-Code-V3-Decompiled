.class public abstract Landroidx/recyclerview/widget/qdMbNW;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public AZxh:I

.field public final mjFkc:Landroidx/recyclerview/widget/RecyclerView$qGY;

.field public final wA:Landroid/graphics/Rect;


# direct methods
.method public constructor <init>(Landroidx/recyclerview/widget/RecyclerView$qGY;)V
    .locals 1

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/high16 v0, -0x80000000

    .line 3
    iput v0, p0, Landroidx/recyclerview/widget/qdMbNW;->AZxh:I

    .line 4
    new-instance v0, Landroid/graphics/Rect;

    invoke-direct {v0}, Landroid/graphics/Rect;-><init>()V

    iput-object v0, p0, Landroidx/recyclerview/widget/qdMbNW;->wA:Landroid/graphics/Rect;

    .line 5
    iput-object p1, p0, Landroidx/recyclerview/widget/qdMbNW;->mjFkc:Landroidx/recyclerview/widget/RecyclerView$qGY;

    return-void
.end method

.method public synthetic constructor <init>(Landroidx/recyclerview/widget/RecyclerView$qGY;Landroidx/recyclerview/widget/qdMbNW$mjFkc;)V
    .locals 0

    .line 1
    invoke-direct {p0, p1}, Landroidx/recyclerview/widget/qdMbNW;-><init>(Landroidx/recyclerview/widget/RecyclerView$qGY;)V

    return-void
.end method

.method public static AZxh(Landroidx/recyclerview/widget/RecyclerView$qGY;I)Landroidx/recyclerview/widget/qdMbNW;
    .locals 1

    if-eqz p1, :cond_1

    const/4 v0, 0x1

    if-ne p1, v0, :cond_0

    invoke-static {p0}, Landroidx/recyclerview/widget/qdMbNW;->wA(Landroidx/recyclerview/widget/RecyclerView$qGY;)Landroidx/recyclerview/widget/qdMbNW;

    move-result-object p0

    return-object p0

    :cond_0
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string p1, "invalid orientation"

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_1
    invoke-static {p0}, Landroidx/recyclerview/widget/qdMbNW;->mjFkc(Landroidx/recyclerview/widget/RecyclerView$qGY;)Landroidx/recyclerview/widget/qdMbNW;

    move-result-object p0

    return-object p0
.end method

.method public static mjFkc(Landroidx/recyclerview/widget/RecyclerView$qGY;)Landroidx/recyclerview/widget/qdMbNW;
    .locals 1

    new-instance v0, Landroidx/recyclerview/widget/qdMbNW$mjFkc;

    invoke-direct {v0, p0}, Landroidx/recyclerview/widget/qdMbNW$mjFkc;-><init>(Landroidx/recyclerview/widget/RecyclerView$qGY;)V

    return-object v0
.end method

.method public static wA(Landroidx/recyclerview/widget/RecyclerView$qGY;)Landroidx/recyclerview/widget/qdMbNW;
    .locals 1

    new-instance v0, Landroidx/recyclerview/widget/qdMbNW$AZxh;

    invoke-direct {v0, p0}, Landroidx/recyclerview/widget/qdMbNW$AZxh;-><init>(Landroidx/recyclerview/widget/RecyclerView$qGY;)V

    return-object v0
.end method


# virtual methods
.method public abstract Dt()I
.end method

.method public abstract ETF()I
.end method

.method public abstract IEE(I)V
.end method

.method public abstract JHa(Landroid/view/View;)I
.end method

.method public abstract KLFTb(Landroid/view/View;)I
.end method

.method public abstract MiMN()I
.end method

.method public Pq()V
    .locals 1

    invoke-virtual {p0}, Landroidx/recyclerview/widget/qdMbNW;->YoKzxo()I

    move-result v0

    iput v0, p0, Landroidx/recyclerview/widget/qdMbNW;->AZxh:I

    return-void
.end method

.method public abstract VA()I
.end method

.method public abstract YoKzxo()I
.end method

.method public abstract ZfxDd(Landroid/view/View;)I
.end method

.method public abstract fehf(Landroid/view/View;)I
.end method

.method public abstract lgHUyS()I
.end method

.method public abstract qGY(Landroid/view/View;)I
.end method

.method public abstract qdMbNW()I
.end method

.method public rkYL()I
    .locals 2

    const/high16 v0, -0x80000000

    iget v1, p0, Landroidx/recyclerview/widget/qdMbNW;->AZxh:I

    if-ne v0, v1, :cond_0

    const/4 p0, 0x0

    goto :goto_0

    :cond_0
    invoke-virtual {p0}, Landroidx/recyclerview/widget/qdMbNW;->YoKzxo()I

    move-result v0

    iget p0, p0, Landroidx/recyclerview/widget/qdMbNW;->AZxh:I

    sub-int p0, v0, p0

    :goto_0
    return p0
.end method

.method public abstract xJ(Landroid/view/View;)I
.end method
