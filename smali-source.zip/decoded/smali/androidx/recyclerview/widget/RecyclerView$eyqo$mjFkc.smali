.class public Landroidx/recyclerview/widget/RecyclerView$eyqo$mjFkc;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/recyclerview/widget/RecyclerView$eyqo;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "mjFkc"
.end annotation


# instance fields
.field public AZxh:I

.field public ZfxDd:J

.field public final mjFkc:Ljava/util/ArrayList;

.field public wA:J


# direct methods
.method public constructor <init>()V
    .locals 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Landroidx/recyclerview/widget/RecyclerView$eyqo$mjFkc;->mjFkc:Ljava/util/ArrayList;

    const/4 v0, 0x5

    iput v0, p0, Landroidx/recyclerview/widget/RecyclerView$eyqo$mjFkc;->AZxh:I

    const-wide/16 v0, 0x0

    iput-wide v0, p0, Landroidx/recyclerview/widget/RecyclerView$eyqo$mjFkc;->wA:J

    iput-wide v0, p0, Landroidx/recyclerview/widget/RecyclerView$eyqo$mjFkc;->ZfxDd:J

    return-void
.end method
