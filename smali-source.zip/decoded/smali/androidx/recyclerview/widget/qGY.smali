.class public Landroidx/recyclerview/widget/qGY;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/recyclerview/widget/qGY$mjFkc;,
        Landroidx/recyclerview/widget/qGY$AZxh;
    }
.end annotation


# instance fields
.field public final AZxh:Lo/o1;

.field public final mjFkc:Lo/W6;


# direct methods
.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Lo/W6;

    invoke-direct {v0}, Lo/W6;-><init>()V

    iput-object v0, p0, Landroidx/recyclerview/widget/qGY;->mjFkc:Lo/W6;

    new-instance v0, Lo/o1;

    invoke-direct {v0}, Lo/o1;-><init>()V

    iput-object v0, p0, Landroidx/recyclerview/widget/qGY;->AZxh:Lo/o1;

    return-void
.end method


# virtual methods
.method public AZxh(Landroidx/recyclerview/widget/RecyclerView$mByQ;)V
    .locals 1

    iget-object v0, p0, Landroidx/recyclerview/widget/qGY;->mjFkc:Lo/W6;

    invoke-virtual {v0, p1}, Lo/W6;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroidx/recyclerview/widget/qGY$mjFkc;

    if-nez v0, :cond_0

    invoke-static {}, Landroidx/recyclerview/widget/qGY$mjFkc;->AZxh()Landroidx/recyclerview/widget/qGY$mjFkc;

    move-result-object v0

    iget-object p0, p0, Landroidx/recyclerview/widget/qGY;->mjFkc:Lo/W6;

    invoke-virtual {p0, p1, v0}, Lo/W6;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_0
    iget p0, v0, Landroidx/recyclerview/widget/qGY$mjFkc;->mjFkc:I

    or-int/lit8 p0, p0, 0x1

    iput p0, v0, Landroidx/recyclerview/widget/qGY$mjFkc;->mjFkc:I

    return-void
.end method

.method public Dt()V
    .locals 0

    invoke-static {}, Landroidx/recyclerview/widget/qGY$mjFkc;->mjFkc()V

    return-void
.end method

.method public ETF(Landroidx/recyclerview/widget/RecyclerView$mByQ;)V
    .locals 0

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/qGY;->qGY(Landroidx/recyclerview/widget/RecyclerView$mByQ;)V

    return-void
.end method

.method public JHa()V
    .locals 1

    iget-object v0, p0, Landroidx/recyclerview/widget/qGY;->mjFkc:Lo/W6;

    invoke-virtual {v0}, Lo/W6;->clear()V

    iget-object p0, p0, Landroidx/recyclerview/widget/qGY;->AZxh:Lo/o1;

    invoke-virtual {p0}, Lo/o1;->mjFkc()V

    return-void
.end method

.method public KLFTb(Landroidx/recyclerview/widget/RecyclerView$mByQ;Landroidx/recyclerview/widget/RecyclerView$MiMN$AZxh;)V
    .locals 1

    iget-object v0, p0, Landroidx/recyclerview/widget/qGY;->mjFkc:Lo/W6;

    invoke-virtual {v0, p1}, Lo/W6;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroidx/recyclerview/widget/qGY$mjFkc;

    if-nez v0, :cond_0

    invoke-static {}, Landroidx/recyclerview/widget/qGY$mjFkc;->AZxh()Landroidx/recyclerview/widget/qGY$mjFkc;

    move-result-object v0

    iget-object p0, p0, Landroidx/recyclerview/widget/qGY;->mjFkc:Lo/W6;

    invoke-virtual {p0, p1, v0}, Lo/W6;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_0
    iput-object p2, v0, Landroidx/recyclerview/widget/qGY$mjFkc;->AZxh:Landroidx/recyclerview/widget/RecyclerView$MiMN$AZxh;

    iget p0, v0, Landroidx/recyclerview/widget/qGY$mjFkc;->mjFkc:I

    or-int/lit8 p0, p0, 0x4

    iput p0, v0, Landroidx/recyclerview/widget/qGY$mjFkc;->mjFkc:I

    return-void
.end method

.method public MiMN(Landroidx/recyclerview/widget/RecyclerView$mByQ;)Landroidx/recyclerview/widget/RecyclerView$MiMN$AZxh;
    .locals 1

    const/16 v0, 0x8

    invoke-virtual {p0, p1, v0}, Landroidx/recyclerview/widget/qGY;->VA(Landroidx/recyclerview/widget/RecyclerView$mByQ;I)Landroidx/recyclerview/widget/RecyclerView$MiMN$AZxh;

    move-result-object p0

    return-object p0
.end method

.method public final VA(Landroidx/recyclerview/widget/RecyclerView$mByQ;I)Landroidx/recyclerview/widget/RecyclerView$MiMN$AZxh;
    .locals 4

    iget-object v0, p0, Landroidx/recyclerview/widget/qGY;->mjFkc:Lo/W6;

    invoke-virtual {v0, p1}, Lo/W6;->JHa(Ljava/lang/Object;)I

    move-result p1

    const/4 v0, 0x0

    if-gez p1, :cond_0

    return-object v0

    :cond_0
    iget-object v1, p0, Landroidx/recyclerview/widget/qGY;->mjFkc:Lo/W6;

    invoke-virtual {v1, p1}, Lo/W6;->MiMN(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroidx/recyclerview/widget/qGY$mjFkc;

    if-eqz v1, :cond_4

    iget v2, v1, Landroidx/recyclerview/widget/qGY$mjFkc;->mjFkc:I

    and-int v3, v2, p2

    if-eqz v3, :cond_4

    not-int v0, p2

    and-int/2addr v0, v2

    iput v0, v1, Landroidx/recyclerview/widget/qGY$mjFkc;->mjFkc:I

    const/4 v2, 0x4

    if-ne p2, v2, :cond_1

    iget-object p2, v1, Landroidx/recyclerview/widget/qGY$mjFkc;->AZxh:Landroidx/recyclerview/widget/RecyclerView$MiMN$AZxh;

    goto :goto_0

    :cond_1
    const/16 v2, 0x8

    if-ne p2, v2, :cond_3

    iget-object p2, v1, Landroidx/recyclerview/widget/qGY$mjFkc;->wA:Landroidx/recyclerview/widget/RecyclerView$MiMN$AZxh;

    :goto_0
    and-int/lit8 v0, v0, 0xc

    if-nez v0, :cond_2

    iget-object p0, p0, Landroidx/recyclerview/widget/qGY;->mjFkc:Lo/W6;

    invoke-virtual {p0, p1}, Lo/W6;->ETF(I)Ljava/lang/Object;

    invoke-static {v1}, Landroidx/recyclerview/widget/qGY$mjFkc;->wA(Landroidx/recyclerview/widget/qGY$mjFkc;)V

    :cond_2
    return-object p2

    :cond_3
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string p1, "Must provide flag PRE or POST"

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_4
    return-object v0
.end method

.method public YoKzxo(Landroidx/recyclerview/widget/RecyclerView$mByQ;)Landroidx/recyclerview/widget/RecyclerView$MiMN$AZxh;
    .locals 1

    const/4 v0, 0x4

    invoke-virtual {p0, p1, v0}, Landroidx/recyclerview/widget/qGY;->VA(Landroidx/recyclerview/widget/RecyclerView$mByQ;I)Landroidx/recyclerview/widget/RecyclerView$MiMN$AZxh;

    move-result-object p0

    return-object p0
.end method

.method public ZfxDd(Landroidx/recyclerview/widget/RecyclerView$mByQ;Landroidx/recyclerview/widget/RecyclerView$MiMN$AZxh;)V
    .locals 1

    iget-object v0, p0, Landroidx/recyclerview/widget/qGY;->mjFkc:Lo/W6;

    invoke-virtual {v0, p1}, Lo/W6;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroidx/recyclerview/widget/qGY$mjFkc;

    if-nez v0, :cond_0

    invoke-static {}, Landroidx/recyclerview/widget/qGY$mjFkc;->AZxh()Landroidx/recyclerview/widget/qGY$mjFkc;

    move-result-object v0

    iget-object p0, p0, Landroidx/recyclerview/widget/qGY;->mjFkc:Lo/W6;

    invoke-virtual {p0, p1, v0}, Lo/W6;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_0
    iput-object p2, v0, Landroidx/recyclerview/widget/qGY$mjFkc;->wA:Landroidx/recyclerview/widget/RecyclerView$MiMN$AZxh;

    iget p0, v0, Landroidx/recyclerview/widget/qGY$mjFkc;->mjFkc:I

    or-int/lit8 p0, p0, 0x8

    iput p0, v0, Landroidx/recyclerview/widget/qGY$mjFkc;->mjFkc:I

    return-void
.end method

.method public fehf(Landroidx/recyclerview/widget/RecyclerView$mByQ;)V
    .locals 2

    iget-object v0, p0, Landroidx/recyclerview/widget/qGY;->AZxh:Lo/o1;

    invoke-virtual {v0}, Lo/o1;->MiMN()I

    move-result v0

    add-int/lit8 v0, v0, -0x1

    :goto_0
    if-ltz v0, :cond_1

    iget-object v1, p0, Landroidx/recyclerview/widget/qGY;->AZxh:Lo/o1;

    invoke-virtual {v1, v0}, Lo/o1;->YoKzxo(I)Ljava/lang/Object;

    move-result-object v1

    if-ne p1, v1, :cond_0

    iget-object v1, p0, Landroidx/recyclerview/widget/qGY;->AZxh:Lo/o1;

    invoke-virtual {v1, v0}, Lo/o1;->VA(I)V

    goto :goto_1

    :cond_0
    add-int/lit8 v0, v0, -0x1

    goto :goto_0

    :cond_1
    :goto_1
    iget-object p0, p0, Landroidx/recyclerview/widget/qGY;->mjFkc:Lo/W6;

    invoke-virtual {p0, p1}, Lo/W6;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroidx/recyclerview/widget/qGY$mjFkc;

    if-eqz p0, :cond_2

    invoke-static {p0}, Landroidx/recyclerview/widget/qGY$mjFkc;->wA(Landroidx/recyclerview/widget/qGY$mjFkc;)V

    :cond_2
    return-void
.end method

.method public lgHUyS(Landroidx/recyclerview/widget/RecyclerView$mByQ;)Z
    .locals 0

    iget-object p0, p0, Landroidx/recyclerview/widget/qGY;->mjFkc:Lo/W6;

    invoke-virtual {p0, p1}, Lo/W6;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroidx/recyclerview/widget/qGY$mjFkc;

    if-eqz p0, :cond_0

    iget p0, p0, Landroidx/recyclerview/widget/qGY$mjFkc;->mjFkc:I

    const/4 p1, 0x1

    and-int/2addr p0, p1

    if-eqz p0, :cond_0

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    :goto_0
    return p1
.end method

.method public mjFkc(Landroidx/recyclerview/widget/RecyclerView$mByQ;Landroidx/recyclerview/widget/RecyclerView$MiMN$AZxh;)V
    .locals 1

    iget-object v0, p0, Landroidx/recyclerview/widget/qGY;->mjFkc:Lo/W6;

    invoke-virtual {v0, p1}, Lo/W6;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroidx/recyclerview/widget/qGY$mjFkc;

    if-nez v0, :cond_0

    invoke-static {}, Landroidx/recyclerview/widget/qGY$mjFkc;->AZxh()Landroidx/recyclerview/widget/qGY$mjFkc;

    move-result-object v0

    iget-object p0, p0, Landroidx/recyclerview/widget/qGY;->mjFkc:Lo/W6;

    invoke-virtual {p0, p1, v0}, Lo/W6;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_0
    iget p0, v0, Landroidx/recyclerview/widget/qGY$mjFkc;->mjFkc:I

    or-int/lit8 p0, p0, 0x2

    iput p0, v0, Landroidx/recyclerview/widget/qGY$mjFkc;->mjFkc:I

    iput-object p2, v0, Landroidx/recyclerview/widget/qGY$mjFkc;->AZxh:Landroidx/recyclerview/widget/RecyclerView$MiMN$AZxh;

    return-void
.end method

.method public qGY(Landroidx/recyclerview/widget/RecyclerView$mByQ;)V
    .locals 0

    iget-object p0, p0, Landroidx/recyclerview/widget/qGY;->mjFkc:Lo/W6;

    invoke-virtual {p0, p1}, Lo/W6;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroidx/recyclerview/widget/qGY$mjFkc;

    if-nez p0, :cond_0

    return-void

    :cond_0
    iget p1, p0, Landroidx/recyclerview/widget/qGY$mjFkc;->mjFkc:I

    and-int/lit8 p1, p1, -0x2

    iput p1, p0, Landroidx/recyclerview/widget/qGY$mjFkc;->mjFkc:I

    return-void
.end method

.method public qdMbNW(Landroidx/recyclerview/widget/RecyclerView$mByQ;)Z
    .locals 0

    iget-object p0, p0, Landroidx/recyclerview/widget/qGY;->mjFkc:Lo/W6;

    invoke-virtual {p0, p1}, Lo/W6;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroidx/recyclerview/widget/qGY$mjFkc;

    if-eqz p0, :cond_0

    iget p0, p0, Landroidx/recyclerview/widget/qGY$mjFkc;->mjFkc:I

    and-int/lit8 p0, p0, 0x4

    if-eqz p0, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method

.method public rkYL(Landroidx/recyclerview/widget/qGY$AZxh;)V
    .locals 6

    iget-object v0, p0, Landroidx/recyclerview/widget/qGY;->mjFkc:Lo/W6;

    invoke-virtual {v0}, Lo/W6;->size()I

    move-result v0

    add-int/lit8 v0, v0, -0x1

    :goto_0
    if-ltz v0, :cond_7

    iget-object v1, p0, Landroidx/recyclerview/widget/qGY;->mjFkc:Lo/W6;

    invoke-virtual {v1, v0}, Lo/W6;->qdMbNW(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroidx/recyclerview/widget/RecyclerView$mByQ;

    iget-object v2, p0, Landroidx/recyclerview/widget/qGY;->mjFkc:Lo/W6;

    invoke-virtual {v2, v0}, Lo/W6;->ETF(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroidx/recyclerview/widget/qGY$mjFkc;

    iget v3, v2, Landroidx/recyclerview/widget/qGY$mjFkc;->mjFkc:I

    and-int/lit8 v4, v3, 0x3

    const/4 v5, 0x3

    if-ne v4, v5, :cond_0

    invoke-interface {p1, v1}, Landroidx/recyclerview/widget/qGY$AZxh;->mjFkc(Landroidx/recyclerview/widget/RecyclerView$mByQ;)V

    goto :goto_1

    :cond_0
    and-int/lit8 v4, v3, 0x1

    if-eqz v4, :cond_2

    iget-object v3, v2, Landroidx/recyclerview/widget/qGY$mjFkc;->AZxh:Landroidx/recyclerview/widget/RecyclerView$MiMN$AZxh;

    if-nez v3, :cond_1

    invoke-interface {p1, v1}, Landroidx/recyclerview/widget/qGY$AZxh;->mjFkc(Landroidx/recyclerview/widget/RecyclerView$mByQ;)V

    goto :goto_1

    :cond_1
    iget-object v4, v2, Landroidx/recyclerview/widget/qGY$mjFkc;->wA:Landroidx/recyclerview/widget/RecyclerView$MiMN$AZxh;

    invoke-interface {p1, v1, v3, v4}, Landroidx/recyclerview/widget/qGY$AZxh;->wA(Landroidx/recyclerview/widget/RecyclerView$mByQ;Landroidx/recyclerview/widget/RecyclerView$MiMN$AZxh;Landroidx/recyclerview/widget/RecyclerView$MiMN$AZxh;)V

    goto :goto_1

    :cond_2
    and-int/lit8 v4, v3, 0xe

    const/16 v5, 0xe

    if-ne v4, v5, :cond_3

    iget-object v3, v2, Landroidx/recyclerview/widget/qGY$mjFkc;->AZxh:Landroidx/recyclerview/widget/RecyclerView$MiMN$AZxh;

    iget-object v4, v2, Landroidx/recyclerview/widget/qGY$mjFkc;->wA:Landroidx/recyclerview/widget/RecyclerView$MiMN$AZxh;

    invoke-interface {p1, v1, v3, v4}, Landroidx/recyclerview/widget/qGY$AZxh;->AZxh(Landroidx/recyclerview/widget/RecyclerView$mByQ;Landroidx/recyclerview/widget/RecyclerView$MiMN$AZxh;Landroidx/recyclerview/widget/RecyclerView$MiMN$AZxh;)V

    goto :goto_1

    :cond_3
    and-int/lit8 v4, v3, 0xc

    const/16 v5, 0xc

    if-ne v4, v5, :cond_4

    iget-object v3, v2, Landroidx/recyclerview/widget/qGY$mjFkc;->AZxh:Landroidx/recyclerview/widget/RecyclerView$MiMN$AZxh;

    iget-object v4, v2, Landroidx/recyclerview/widget/qGY$mjFkc;->wA:Landroidx/recyclerview/widget/RecyclerView$MiMN$AZxh;

    invoke-interface {p1, v1, v3, v4}, Landroidx/recyclerview/widget/qGY$AZxh;->ZfxDd(Landroidx/recyclerview/widget/RecyclerView$mByQ;Landroidx/recyclerview/widget/RecyclerView$MiMN$AZxh;Landroidx/recyclerview/widget/RecyclerView$MiMN$AZxh;)V

    goto :goto_1

    :cond_4
    and-int/lit8 v4, v3, 0x4

    if-eqz v4, :cond_5

    iget-object v3, v2, Landroidx/recyclerview/widget/qGY$mjFkc;->AZxh:Landroidx/recyclerview/widget/RecyclerView$MiMN$AZxh;

    const/4 v4, 0x0

    invoke-interface {p1, v1, v3, v4}, Landroidx/recyclerview/widget/qGY$AZxh;->wA(Landroidx/recyclerview/widget/RecyclerView$mByQ;Landroidx/recyclerview/widget/RecyclerView$MiMN$AZxh;Landroidx/recyclerview/widget/RecyclerView$MiMN$AZxh;)V

    goto :goto_1

    :cond_5
    and-int/lit8 v3, v3, 0x8

    if-eqz v3, :cond_6

    iget-object v3, v2, Landroidx/recyclerview/widget/qGY$mjFkc;->AZxh:Landroidx/recyclerview/widget/RecyclerView$MiMN$AZxh;

    iget-object v4, v2, Landroidx/recyclerview/widget/qGY$mjFkc;->wA:Landroidx/recyclerview/widget/RecyclerView$MiMN$AZxh;

    invoke-interface {p1, v1, v3, v4}, Landroidx/recyclerview/widget/qGY$AZxh;->AZxh(Landroidx/recyclerview/widget/RecyclerView$mByQ;Landroidx/recyclerview/widget/RecyclerView$MiMN$AZxh;Landroidx/recyclerview/widget/RecyclerView$MiMN$AZxh;)V

    :cond_6
    :goto_1
    invoke-static {v2}, Landroidx/recyclerview/widget/qGY$mjFkc;->wA(Landroidx/recyclerview/widget/qGY$mjFkc;)V

    add-int/lit8 v0, v0, -0x1

    goto :goto_0

    :cond_7
    return-void
.end method

.method public wA(JLandroidx/recyclerview/widget/RecyclerView$mByQ;)V
    .locals 0

    iget-object p0, p0, Landroidx/recyclerview/widget/qGY;->AZxh:Lo/o1;

    invoke-virtual {p0, p1, p2, p3}, Lo/o1;->Dt(JLjava/lang/Object;)V

    return-void
.end method

.method public xJ(J)Landroidx/recyclerview/widget/RecyclerView$mByQ;
    .locals 0

    iget-object p0, p0, Landroidx/recyclerview/widget/qGY;->AZxh:Lo/o1;

    invoke-virtual {p0, p1, p2}, Lo/o1;->KLFTb(J)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;

    return-object p0
.end method
