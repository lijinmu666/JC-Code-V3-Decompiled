.class public abstract Landroidx/recyclerview/widget/YoKzxo;
.super Landroidx/recyclerview/widget/RecyclerView$IEE;
.source "SourceFile"


# instance fields
.field public AZxh:Landroid/widget/Scroller;

.field public mjFkc:Landroidx/recyclerview/widget/RecyclerView;

.field public final wA:Landroidx/recyclerview/widget/RecyclerView$diqgf;


# direct methods
.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Landroidx/recyclerview/widget/RecyclerView$IEE;-><init>()V

    new-instance v0, Landroidx/recyclerview/widget/YoKzxo$mjFkc;

    invoke-direct {v0, p0}, Landroidx/recyclerview/widget/YoKzxo$mjFkc;-><init>(Landroidx/recyclerview/widget/YoKzxo;)V

    iput-object v0, p0, Landroidx/recyclerview/widget/YoKzxo;->wA:Landroidx/recyclerview/widget/RecyclerView$diqgf;

    return-void
.end method


# virtual methods
.method public AZxh(Landroidx/recyclerview/widget/RecyclerView;)V
    .locals 2

    iget-object v0, p0, Landroidx/recyclerview/widget/YoKzxo;->mjFkc:Landroidx/recyclerview/widget/RecyclerView;

    if-ne v0, p1, :cond_0

    return-void

    :cond_0
    if-eqz v0, :cond_1

    invoke-virtual {p0}, Landroidx/recyclerview/widget/YoKzxo;->KLFTb()V

    :cond_1
    iput-object p1, p0, Landroidx/recyclerview/widget/YoKzxo;->mjFkc:Landroidx/recyclerview/widget/RecyclerView;

    if-eqz p1, :cond_2

    invoke-virtual {p0}, Landroidx/recyclerview/widget/YoKzxo;->lgHUyS()V

    new-instance p1, Landroid/widget/Scroller;

    iget-object v0, p0, Landroidx/recyclerview/widget/YoKzxo;->mjFkc:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    new-instance v1, Landroid/view/animation/DecelerateInterpolator;

    invoke-direct {v1}, Landroid/view/animation/DecelerateInterpolator;-><init>()V

    invoke-direct {p1, v0, v1}, Landroid/widget/Scroller;-><init>(Landroid/content/Context;Landroid/view/animation/Interpolator;)V

    iput-object p1, p0, Landroidx/recyclerview/widget/YoKzxo;->AZxh:Landroid/widget/Scroller;

    invoke-virtual {p0}, Landroidx/recyclerview/widget/YoKzxo;->Dt()V

    :cond_2
    return-void
.end method

.method public Dt()V
    .locals 4

    iget-object v0, p0, Landroidx/recyclerview/widget/YoKzxo;->mjFkc:Landroidx/recyclerview/widget/RecyclerView;

    if-nez v0, :cond_0

    return-void

    :cond_0
    invoke-virtual {v0}, Landroidx/recyclerview/widget/RecyclerView;->getLayoutManager()Landroidx/recyclerview/widget/RecyclerView$qGY;

    move-result-object v0

    if-nez v0, :cond_1

    return-void

    :cond_1
    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/YoKzxo;->JHa(Landroidx/recyclerview/widget/RecyclerView$qGY;)Landroid/view/View;

    move-result-object v1

    if-nez v1, :cond_2

    return-void

    :cond_2
    invoke-virtual {p0, v0, v1}, Landroidx/recyclerview/widget/YoKzxo;->wA(Landroidx/recyclerview/widget/RecyclerView$qGY;Landroid/view/View;)[I

    move-result-object v0

    const/4 v1, 0x0

    aget v1, v0, v1

    const/4 v2, 0x1

    if-nez v1, :cond_3

    aget v3, v0, v2

    if-eqz v3, :cond_4

    :cond_3
    iget-object p0, p0, Landroidx/recyclerview/widget/YoKzxo;->mjFkc:Landroidx/recyclerview/widget/RecyclerView;

    aget v0, v0, v2

    invoke-virtual {p0, v1, v0}, Landroidx/recyclerview/widget/RecyclerView;->CTcA(II)V

    :cond_4
    return-void
.end method

.method public abstract JHa(Landroidx/recyclerview/widget/RecyclerView$qGY;)Landroid/view/View;
.end method

.method public final KLFTb()V
    .locals 2

    iget-object v0, p0, Landroidx/recyclerview/widget/YoKzxo;->mjFkc:Landroidx/recyclerview/widget/RecyclerView;

    iget-object v1, p0, Landroidx/recyclerview/widget/YoKzxo;->wA:Landroidx/recyclerview/widget/RecyclerView$diqgf;

    invoke-virtual {v0, v1}, Landroidx/recyclerview/widget/RecyclerView;->mPWV(Landroidx/recyclerview/widget/RecyclerView$diqgf;)V

    iget-object p0, p0, Landroidx/recyclerview/widget/YoKzxo;->mjFkc:Landroidx/recyclerview/widget/RecyclerView;

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/RecyclerView;->setOnFlingListener(Landroidx/recyclerview/widget/RecyclerView$IEE;)V

    return-void
.end method

.method public abstract ZfxDd(Landroidx/recyclerview/widget/RecyclerView$qGY;)Landroidx/recyclerview/widget/RecyclerView$vI;
.end method

.method public final lgHUyS()V
    .locals 2

    iget-object v0, p0, Landroidx/recyclerview/widget/YoKzxo;->mjFkc:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {v0}, Landroidx/recyclerview/widget/RecyclerView;->getOnFlingListener()Landroidx/recyclerview/widget/RecyclerView$IEE;

    move-result-object v0

    if-nez v0, :cond_0

    iget-object v0, p0, Landroidx/recyclerview/widget/YoKzxo;->mjFkc:Landroidx/recyclerview/widget/RecyclerView;

    iget-object v1, p0, Landroidx/recyclerview/widget/YoKzxo;->wA:Landroidx/recyclerview/widget/RecyclerView$diqgf;

    invoke-virtual {v0, v1}, Landroidx/recyclerview/widget/RecyclerView;->VA(Landroidx/recyclerview/widget/RecyclerView$diqgf;)V

    iget-object v0, p0, Landroidx/recyclerview/widget/YoKzxo;->mjFkc:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {v0, p0}, Landroidx/recyclerview/widget/RecyclerView;->setOnFlingListener(Landroidx/recyclerview/widget/RecyclerView$IEE;)V

    return-void

    :cond_0
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string v0, "An instance of OnFlingListener already set."

    invoke-direct {p0, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public mjFkc(II)Z
    .locals 4

    iget-object v0, p0, Landroidx/recyclerview/widget/YoKzxo;->mjFkc:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {v0}, Landroidx/recyclerview/widget/RecyclerView;->getLayoutManager()Landroidx/recyclerview/widget/RecyclerView$qGY;

    move-result-object v0

    const/4 v1, 0x0

    if-nez v0, :cond_0

    return v1

    :cond_0
    iget-object v2, p0, Landroidx/recyclerview/widget/YoKzxo;->mjFkc:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {v2}, Landroidx/recyclerview/widget/RecyclerView;->getAdapter()Landroidx/recyclerview/widget/RecyclerView$lgHUyS;

    move-result-object v2

    if-nez v2, :cond_1

    return v1

    :cond_1
    iget-object v2, p0, Landroidx/recyclerview/widget/YoKzxo;->mjFkc:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {v2}, Landroidx/recyclerview/widget/RecyclerView;->getMinFlingVelocity()I

    move-result v2

    invoke-static {p2}, Ljava/lang/Math;->abs(I)I

    move-result v3

    if-gt v3, v2, :cond_2

    invoke-static {p1}, Ljava/lang/Math;->abs(I)I

    move-result v3

    if-le v3, v2, :cond_3

    :cond_2
    invoke-virtual {p0, v0, p1, p2}, Landroidx/recyclerview/widget/YoKzxo;->qdMbNW(Landroidx/recyclerview/widget/RecyclerView$qGY;II)Z

    move-result p0

    if-eqz p0, :cond_3

    const/4 v1, 0x1

    :cond_3
    return v1
.end method

.method public final qdMbNW(Landroidx/recyclerview/widget/RecyclerView$qGY;II)Z
    .locals 2

    instance-of v0, p1, Landroidx/recyclerview/widget/RecyclerView$vI$AZxh;

    const/4 v1, 0x0

    if-nez v0, :cond_0

    return v1

    :cond_0
    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/YoKzxo;->ZfxDd(Landroidx/recyclerview/widget/RecyclerView$qGY;)Landroidx/recyclerview/widget/RecyclerView$vI;

    move-result-object v0

    if-nez v0, :cond_1

    return v1

    :cond_1
    invoke-virtual {p0, p1, p2, p3}, Landroidx/recyclerview/widget/YoKzxo;->xJ(Landroidx/recyclerview/widget/RecyclerView$qGY;II)I

    move-result p0

    const/4 p2, -0x1

    if-ne p0, p2, :cond_2

    return v1

    :cond_2
    invoke-virtual {v0, p0}, Landroidx/recyclerview/widget/RecyclerView$vI;->qGY(I)V

    invoke-virtual {p1, v0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->vUsV(Landroidx/recyclerview/widget/RecyclerView$vI;)V

    const/4 p0, 0x1

    return p0
.end method

.method public abstract wA(Landroidx/recyclerview/widget/RecyclerView$qGY;Landroid/view/View;)[I
.end method

.method public abstract xJ(Landroidx/recyclerview/widget/RecyclerView$qGY;II)I
.end method
