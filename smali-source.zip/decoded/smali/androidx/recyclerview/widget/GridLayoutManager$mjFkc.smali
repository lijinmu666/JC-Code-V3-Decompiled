.class public final Landroidx/recyclerview/widget/GridLayoutManager$mjFkc;
.super Landroidx/recyclerview/widget/GridLayoutManager$wA;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/recyclerview/widget/GridLayoutManager;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "mjFkc"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Landroidx/recyclerview/widget/GridLayoutManager$wA;-><init>()V

    return-void
.end method


# virtual methods
.method public JHa(I)I
    .locals 0

    const/4 p0, 0x1

    return p0
.end method

.method public KLFTb(II)I
    .locals 0

    rem-int/2addr p1, p2

    return p1
.end method
