.class public Landroidx/recyclerview/widget/LinearLayoutManager;
.super Landroidx/recyclerview/widget/RecyclerView$qGY;
.source "SourceFile"

# interfaces
.implements Landroidx/recyclerview/widget/RecyclerView$vI$AZxh;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/recyclerview/widget/LinearLayoutManager$AZxh;,
        Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;,
        Landroidx/recyclerview/widget/LinearLayoutManager$ZfxDd;,
        Landroidx/recyclerview/widget/LinearLayoutManager$wA;
    }
.end annotation


# instance fields
.field public BAnRFn:I

.field public CqaNbM:[I

.field public Gd:Z

.field public HGpJ:Z

.field public Ne:I

.field public final OjSQV:Landroidx/recyclerview/widget/LinearLayoutManager$AZxh;

.field public Pq:I

.field public Ucbh:Z

.field public VocHEe:I

.field public diqgf:Landroidx/recyclerview/widget/LinearLayoutManager$wA;

.field public eyqo:Landroidx/recyclerview/widget/qdMbNW;

.field public huTpC:Z

.field public lB:Z

.field public final mByQ:Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;

.field public vI:Z

.field public wJVbdd:Landroidx/recyclerview/widget/LinearLayoutManager$ZfxDd;


# direct methods
.method public constructor <init>(Landroid/content/Context;IZ)V
    .locals 1

    .line 1
    invoke-direct {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;-><init>()V

    const/4 p1, 0x1

    .line 2
    iput p1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->Pq:I

    const/4 v0, 0x0

    .line 3
    iput-boolean v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->huTpC:Z

    .line 4
    iput-boolean v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->Gd:Z

    .line 5
    iput-boolean v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->HGpJ:Z

    .line 6
    iput-boolean p1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->vI:Z

    const/4 p1, -0x1

    .line 7
    iput p1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->VocHEe:I

    const/high16 p1, -0x80000000

    .line 8
    iput p1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->BAnRFn:I

    const/4 p1, 0x0

    .line 9
    iput-object p1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->wJVbdd:Landroidx/recyclerview/widget/LinearLayoutManager$ZfxDd;

    .line 10
    new-instance p1, Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;

    invoke-direct {p1}, Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;-><init>()V

    iput-object p1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->mByQ:Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;

    .line 11
    new-instance p1, Landroidx/recyclerview/widget/LinearLayoutManager$AZxh;

    invoke-direct {p1}, Landroidx/recyclerview/widget/LinearLayoutManager$AZxh;-><init>()V

    iput-object p1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->OjSQV:Landroidx/recyclerview/widget/LinearLayoutManager$AZxh;

    const/4 p1, 0x2

    .line 12
    iput p1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->Ne:I

    .line 13
    new-array p1, p1, [I

    iput-object p1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->CqaNbM:[I

    .line 14
    invoke-virtual {p0, p2}, Landroidx/recyclerview/widget/LinearLayoutManager;->EeoThB(I)V

    .line 15
    invoke-virtual {p0, p3}, Landroidx/recyclerview/widget/LinearLayoutManager;->cdjp(Z)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;II)V
    .locals 2
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "UnknownNullness"
        }
    .end annotation

    .line 16
    invoke-direct {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;-><init>()V

    const/4 v0, 0x1

    .line 17
    iput v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->Pq:I

    const/4 v1, 0x0

    .line 18
    iput-boolean v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->huTpC:Z

    .line 19
    iput-boolean v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->Gd:Z

    .line 20
    iput-boolean v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->HGpJ:Z

    .line 21
    iput-boolean v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->vI:Z

    const/4 v0, -0x1

    .line 22
    iput v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->VocHEe:I

    const/high16 v0, -0x80000000

    .line 23
    iput v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->BAnRFn:I

    const/4 v0, 0x0

    .line 24
    iput-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->wJVbdd:Landroidx/recyclerview/widget/LinearLayoutManager$ZfxDd;

    .line 25
    new-instance v0, Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;

    invoke-direct {v0}, Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;-><init>()V

    iput-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->mByQ:Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;

    .line 26
    new-instance v0, Landroidx/recyclerview/widget/LinearLayoutManager$AZxh;

    invoke-direct {v0}, Landroidx/recyclerview/widget/LinearLayoutManager$AZxh;-><init>()V

    iput-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->OjSQV:Landroidx/recyclerview/widget/LinearLayoutManager$AZxh;

    const/4 v0, 0x2

    .line 27
    iput v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->Ne:I

    .line 28
    new-array v0, v0, [I

    iput-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->CqaNbM:[I

    .line 29
    invoke-static {p1, p2, p3, p4}, Landroidx/recyclerview/widget/RecyclerView$qGY;->yfx(Landroid/content/Context;Landroid/util/AttributeSet;II)Landroidx/recyclerview/widget/RecyclerView$qGY$ZfxDd;

    move-result-object p1

    .line 30
    iget p2, p1, Landroidx/recyclerview/widget/RecyclerView$qGY$ZfxDd;->mjFkc:I

    invoke-virtual {p0, p2}, Landroidx/recyclerview/widget/LinearLayoutManager;->EeoThB(I)V

    .line 31
    iget-boolean p2, p1, Landroidx/recyclerview/widget/RecyclerView$qGY$ZfxDd;->wA:Z

    invoke-virtual {p0, p2}, Landroidx/recyclerview/widget/LinearLayoutManager;->cdjp(Z)V

    .line 32
    iget-boolean p1, p1, Landroidx/recyclerview/widget/RecyclerView$qGY$ZfxDd;->ZfxDd:Z

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/LinearLayoutManager;->xBQUgd(Z)V

    return-void
.end method


# virtual methods
.method public AZxh(I)Landroid/graphics/PointF;
    .locals 3

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->zvd()I

    move-result v0

    if-nez v0, :cond_0

    const/4 p0, 0x0

    return-object p0

    :cond_0
    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->KLMXS(I)Landroid/view/View;

    move-result-object v1

    invoke-virtual {p0, v1}, Landroidx/recyclerview/widget/RecyclerView$qGY;->tQ(Landroid/view/View;)I

    move-result v1

    const/4 v2, 0x1

    if-ge p1, v1, :cond_1

    move v0, v2

    :cond_1
    iget-boolean p1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->Gd:Z

    if-eq v0, p1, :cond_2

    const/4 v2, -0x1

    :cond_2
    iget p0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->Pq:I

    const/4 p1, 0x0

    if-nez p0, :cond_3

    new-instance p0, Landroid/graphics/PointF;

    int-to-float v0, v2

    invoke-direct {p0, v0, p1}, Landroid/graphics/PointF;-><init>(FF)V

    return-object p0

    :cond_3
    new-instance p0, Landroid/graphics/PointF;

    int-to-float v0, v2

    invoke-direct {p0, p1, v0}, Landroid/graphics/PointF;-><init>(FF)V

    return-object p0
.end method

.method public ArO()Z
    .locals 1

    iget-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v0}, Landroidx/recyclerview/widget/qdMbNW;->ETF()I

    move-result v0

    if-nez v0, :cond_0

    iget-object p0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {p0}, Landroidx/recyclerview/widget/qdMbNW;->lgHUyS()I

    move-result p0

    if-nez p0, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method

.method public BxruE(ILandroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;)I
    .locals 2

    iget v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->Pq:I

    const/4 v1, 0x1

    if-ne v0, v1, :cond_0

    const/4 p0, 0x0

    return p0

    :cond_0
    invoke-virtual {p0, p1, p2, p3}, Landroidx/recyclerview/widget/LinearLayoutManager;->jTNPnW(ILandroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;)I

    move-result p0

    return p0
.end method

.method public CcoH(Landroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/LinearLayoutManager$wA;Landroidx/recyclerview/widget/RecyclerView$VocHEe;Z)I
    .locals 7

    iget v0, p2, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->wA:I

    iget v1, p2, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->xJ:I

    const/high16 v2, -0x80000000

    if-eq v1, v2, :cond_1

    if-gez v0, :cond_0

    add-int/2addr v1, v0

    iput v1, p2, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->xJ:I

    :cond_0
    invoke-virtual {p0, p1, p2}, Landroidx/recyclerview/widget/LinearLayoutManager;->tPvjn(Landroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/LinearLayoutManager$wA;)V

    :cond_1
    iget v1, p2, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->wA:I

    iget v3, p2, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->lgHUyS:I

    add-int/2addr v1, v3

    iget-object v3, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->OjSQV:Landroidx/recyclerview/widget/LinearLayoutManager$AZxh;

    :cond_2
    iget-boolean v4, p2, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->MiMN:Z

    if-nez v4, :cond_3

    if-lez v1, :cond_9

    :cond_3
    invoke-virtual {p2, p3}, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->wA(Landroidx/recyclerview/widget/RecyclerView$VocHEe;)Z

    move-result v4

    if-eqz v4, :cond_9

    invoke-virtual {v3}, Landroidx/recyclerview/widget/LinearLayoutManager$AZxh;->mjFkc()V

    invoke-virtual {p0, p1, p3, p2, v3}, Landroidx/recyclerview/widget/LinearLayoutManager;->Sx(Landroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;Landroidx/recyclerview/widget/LinearLayoutManager$wA;Landroidx/recyclerview/widget/LinearLayoutManager$AZxh;)V

    iget-boolean v4, v3, Landroidx/recyclerview/widget/LinearLayoutManager$AZxh;->AZxh:Z

    if-eqz v4, :cond_4

    goto :goto_0

    :cond_4
    iget v4, p2, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->AZxh:I

    iget v5, v3, Landroidx/recyclerview/widget/LinearLayoutManager$AZxh;->mjFkc:I

    iget v6, p2, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->JHa:I

    mul-int/2addr v5, v6

    add-int/2addr v4, v5

    iput v4, p2, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->AZxh:I

    iget-boolean v4, v3, Landroidx/recyclerview/widget/LinearLayoutManager$AZxh;->wA:Z

    if-eqz v4, :cond_5

    iget-object v4, p2, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->VA:Ljava/util/List;

    if-nez v4, :cond_5

    invoke-virtual {p3}, Landroidx/recyclerview/widget/RecyclerView$VocHEe;->KLFTb()Z

    move-result v4

    if-nez v4, :cond_6

    :cond_5
    iget v4, p2, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->wA:I

    iget v5, v3, Landroidx/recyclerview/widget/LinearLayoutManager$AZxh;->mjFkc:I

    sub-int/2addr v4, v5

    iput v4, p2, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->wA:I

    sub-int/2addr v1, v5

    :cond_6
    iget v4, p2, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->xJ:I

    if-eq v4, v2, :cond_8

    iget v5, v3, Landroidx/recyclerview/widget/LinearLayoutManager$AZxh;->mjFkc:I

    add-int/2addr v4, v5

    iput v4, p2, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->xJ:I

    iget v5, p2, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->wA:I

    if-gez v5, :cond_7

    add-int/2addr v4, v5

    iput v4, p2, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->xJ:I

    :cond_7
    invoke-virtual {p0, p1, p2}, Landroidx/recyclerview/widget/LinearLayoutManager;->tPvjn(Landroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/LinearLayoutManager$wA;)V

    :cond_8
    if-eqz p4, :cond_2

    iget-boolean v4, v3, Landroidx/recyclerview/widget/LinearLayoutManager$AZxh;->ZfxDd:Z

    if-eqz v4, :cond_2

    :cond_9
    :goto_0
    iget p0, p2, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->wA:I

    sub-int/2addr v0, p0

    return v0
.end method

.method public final CqAnRZ()Landroid/view/View;
    .locals 1

    iget-boolean v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->Gd:Z

    if-eqz v0, :cond_0

    invoke-virtual {p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->HX()Landroid/view/View;

    move-result-object p0

    goto :goto_0

    :cond_0
    invoke-virtual {p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->MC()Landroid/view/View;

    move-result-object p0

    :goto_0
    return-object p0
.end method

.method public Dp(Landroid/view/accessibility/AccessibilityEvent;)V
    .locals 1

    invoke-super {p0, p1}, Landroidx/recyclerview/widget/RecyclerView$qGY;->Dp(Landroid/view/accessibility/AccessibilityEvent;)V

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->zvd()I

    move-result v0

    if-lez v0, :cond_0

    invoke-virtual {p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->zPp()I

    move-result v0

    invoke-virtual {p1, v0}, Landroid/view/accessibility/AccessibilityRecord;->setFromIndex(I)V

    invoke-virtual {p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->aDq()I

    move-result p0

    invoke-virtual {p1, p0}, Landroid/view/accessibility/AccessibilityRecord;->setToIndex(I)V

    :cond_0
    return-void
.end method

.method public ERt()Z
    .locals 1

    iget-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->wJVbdd:Landroidx/recyclerview/widget/LinearLayoutManager$ZfxDd;

    if-nez v0, :cond_0

    iget-boolean v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->Ucbh:Z

    iget-boolean p0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->HGpJ:Z

    if-ne v0, p0, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method

.method public EeoThB(I)V
    .locals 2

    if-eqz p1, :cond_1

    const/4 v0, 0x1

    if-ne p1, v0, :cond_0

    goto :goto_0

    :cond_0
    new-instance p0, Ljava/lang/IllegalArgumentException;

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "invalid orientation:"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_1
    :goto_0
    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/LinearLayoutManager;->lgHUyS(Ljava/lang/String;)V

    iget v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->Pq:I

    if-ne p1, v0, :cond_2

    iget-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    if-nez v0, :cond_3

    :cond_2
    invoke-static {p0, p1}, Landroidx/recyclerview/widget/qdMbNW;->AZxh(Landroidx/recyclerview/widget/RecyclerView$qGY;I)Landroidx/recyclerview/widget/qdMbNW;

    move-result-object v0

    iput-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    iget-object v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->mByQ:Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;

    iput-object v0, v1, Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;->mjFkc:Landroidx/recyclerview/widget/qdMbNW;

    iput p1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->Pq:I

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->mzUGzO()V

    :cond_3
    return-void
.end method

.method public EoC(ZZ)Landroid/view/View;
    .locals 2

    iget-boolean v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->Gd:Z

    if-eqz v0, :cond_0

    const/4 v0, 0x0

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->zvd()I

    move-result v1

    invoke-virtual {p0, v0, v1, p1, p2}, Landroidx/recyclerview/widget/LinearLayoutManager;->TvfBiy(IIZZ)Landroid/view/View;

    move-result-object p0

    return-object p0

    :cond_0
    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->zvd()I

    move-result v0

    add-int/lit8 v0, v0, -0x1

    const/4 v1, -0x1

    invoke-virtual {p0, v0, v1, p1, p2}, Landroidx/recyclerview/widget/LinearLayoutManager;->TvfBiy(IIZZ)Landroid/view/View;

    move-result-object p0

    return-object p0
.end method

.method public final Es(Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;)V
    .locals 1

    iget v0, p1, Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;->AZxh:I

    iget p1, p1, Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;->wA:I

    invoke-virtual {p0, v0, p1}, Landroidx/recyclerview/widget/LinearLayoutManager;->LlB(II)V

    return-void
.end method

.method public final HExgdj(Landroidx/recyclerview/widget/RecyclerView$VocHEe;)I
    .locals 6

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->zvd()I

    move-result v0

    if-nez v0, :cond_0

    const/4 p0, 0x0

    return p0

    :cond_0
    invoke-virtual {p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->qrxT()V

    iget-object v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    iget-boolean v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->vI:Z

    const/4 v2, 0x1

    xor-int/2addr v0, v2

    invoke-virtual {p0, v0, v2}, Landroidx/recyclerview/widget/LinearLayoutManager;->xbjHT(ZZ)Landroid/view/View;

    move-result-object v3

    iget-boolean v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->vI:Z

    xor-int/2addr v0, v2

    invoke-virtual {p0, v0, v2}, Landroidx/recyclerview/widget/LinearLayoutManager;->EoC(ZZ)Landroid/view/View;

    move-result-object v4

    iget-boolean v5, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->vI:Z

    move-object v0, p1

    move-object v2, v3

    move-object v3, v4

    move-object v4, p0

    invoke-static/range {v0 .. v5}, Landroidx/recyclerview/widget/VA;->wA(Landroidx/recyclerview/widget/RecyclerView$VocHEe;Landroidx/recyclerview/widget/qdMbNW;Landroid/view/View;Landroid/view/View;Landroidx/recyclerview/widget/RecyclerView$qGY;Z)I

    move-result p0

    return p0
.end method

.method public final HX()Landroid/view/View;
    .locals 2

    const/4 v0, 0x0

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->zvd()I

    move-result v1

    invoke-virtual {p0, v0, v1}, Landroidx/recyclerview/widget/LinearLayoutManager;->vZ(II)Landroid/view/View;

    move-result-object p0

    return-object p0
.end method

.method public final Hk(ILandroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;Z)I
    .locals 1

    iget-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v0}, Landroidx/recyclerview/widget/qdMbNW;->MiMN()I

    move-result v0

    sub-int v0, p1, v0

    if-lez v0, :cond_1

    invoke-virtual {p0, v0, p2, p3}, Landroidx/recyclerview/widget/LinearLayoutManager;->jTNPnW(ILandroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;)I

    move-result p2

    neg-int p2, p2

    add-int/2addr p1, p2

    if-eqz p4, :cond_0

    iget-object p3, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {p3}, Landroidx/recyclerview/widget/qdMbNW;->MiMN()I

    move-result p3

    sub-int/2addr p1, p3

    if-lez p1, :cond_0

    iget-object p0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    neg-int p3, p1

    invoke-virtual {p0, p3}, Landroidx/recyclerview/widget/qdMbNW;->IEE(I)V

    sub-int/2addr p2, p1

    :cond_0
    return p2

    :cond_1
    const/4 p0, 0x0

    return p0
.end method

.method public IEE(Landroidx/recyclerview/widget/RecyclerView$VocHEe;)I
    .locals 0

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/LinearLayoutManager;->np(Landroidx/recyclerview/widget/RecyclerView$VocHEe;)I

    move-result p0

    return p0
.end method

.method public final IPpyV(Landroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;)V
    .locals 1

    invoke-virtual {p0, p2, p3}, Landroidx/recyclerview/widget/LinearLayoutManager;->UPU(Landroidx/recyclerview/widget/RecyclerView$VocHEe;Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;)Z

    move-result v0

    if-eqz v0, :cond_0

    return-void

    :cond_0
    invoke-virtual {p0, p1, p2, p3}, Landroidx/recyclerview/widget/LinearLayoutManager;->MFekjo(Landroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;)Z

    move-result p1

    if-eqz p1, :cond_1

    return-void

    :cond_1
    invoke-virtual {p3}, Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;->mjFkc()V

    iget-boolean p0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->HGpJ:Z

    if-eqz p0, :cond_2

    invoke-virtual {p2}, Landroidx/recyclerview/widget/RecyclerView$VocHEe;->AZxh()I

    move-result p0

    add-int/lit8 p0, p0, -0x1

    goto :goto_0

    :cond_2
    const/4 p0, 0x0

    :goto_0
    iput p0, p3, Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;->AZxh:I

    return-void
.end method

.method public JOe(Landroidx/recyclerview/widget/RecyclerView$VocHEe;[I)V
    .locals 2

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/LinearLayoutManager;->XyP(Landroidx/recyclerview/widget/RecyclerView$VocHEe;)I

    move-result p1

    iget-object p0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->diqgf:Landroidx/recyclerview/widget/LinearLayoutManager$wA;

    iget p0, p0, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->JHa:I

    const/4 v0, -0x1

    const/4 v1, 0x0

    if-ne p0, v0, :cond_0

    move p0, v1

    goto :goto_0

    :cond_0
    move p0, p1

    move p1, v1

    :goto_0
    aput p1, p2, v1

    const/4 p1, 0x1

    aput p0, p2, p1

    return-void
.end method

.method public KSf(I)I
    .locals 4

    const/4 v0, -0x1

    const/4 v1, 0x1

    if-eq p1, v1, :cond_b

    const/4 v2, 0x2

    if-eq p1, v2, :cond_8

    const/16 v2, 0x11

    const/high16 v3, -0x80000000

    if-eq p1, v2, :cond_6

    const/16 v2, 0x21

    if-eq p1, v2, :cond_4

    const/16 v0, 0x42

    if-eq p1, v0, :cond_2

    const/16 v0, 0x82

    if-eq p1, v0, :cond_0

    return v3

    :cond_0
    iget p0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->Pq:I

    if-ne p0, v1, :cond_1

    goto :goto_0

    :cond_1
    move v1, v3

    :goto_0
    return v1

    :cond_2
    iget p0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->Pq:I

    if-nez p0, :cond_3

    goto :goto_1

    :cond_3
    move v1, v3

    :goto_1
    return v1

    :cond_4
    iget p0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->Pq:I

    if-ne p0, v1, :cond_5

    goto :goto_2

    :cond_5
    move v0, v3

    :goto_2
    return v0

    :cond_6
    iget p0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->Pq:I

    if-nez p0, :cond_7

    goto :goto_3

    :cond_7
    move v0, v3

    :goto_3
    return v0

    :cond_8
    iget p1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->Pq:I

    if-ne p1, v1, :cond_9

    return v1

    :cond_9
    invoke-virtual {p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->jY()Z

    move-result p0

    if-eqz p0, :cond_a

    return v0

    :cond_a
    return v1

    :cond_b
    iget p1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->Pq:I

    if-ne p1, v1, :cond_c

    return v0

    :cond_c
    invoke-virtual {p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->jY()Z

    move-result p0

    if-eqz p0, :cond_d

    return v1

    :cond_d
    return v0
.end method

.method public final LlB(II)V
    .locals 2

    iget-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->diqgf:Landroidx/recyclerview/widget/LinearLayoutManager$wA;

    iget-object v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v1}, Landroidx/recyclerview/widget/qdMbNW;->qdMbNW()I

    move-result v1

    sub-int/2addr v1, p2

    iput v1, v0, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->wA:I

    iget-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->diqgf:Landroidx/recyclerview/widget/LinearLayoutManager$wA;

    iget-boolean p0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->Gd:Z

    const/4 v1, 0x1

    if-eqz p0, :cond_0

    const/4 p0, -0x1

    goto :goto_0

    :cond_0
    move p0, v1

    :goto_0
    iput p0, v0, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->KLFTb:I

    iput p1, v0, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->ZfxDd:I

    iput v1, v0, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->JHa:I

    iput p2, v0, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->AZxh:I

    const/high16 p0, -0x80000000

    iput p0, v0, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->xJ:I

    return-void
.end method

.method public final MC()Landroid/view/View;
    .locals 2

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->zvd()I

    move-result v0

    add-int/lit8 v0, v0, -0x1

    const/4 v1, -0x1

    invoke-virtual {p0, v0, v1}, Landroidx/recyclerview/widget/LinearLayoutManager;->vZ(II)Landroid/view/View;

    move-result-object p0

    return-object p0
.end method

.method public final MFekjo(Landroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;)Z
    .locals 4

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->zvd()I

    move-result v0

    const/4 v1, 0x0

    if-nez v0, :cond_0

    return v1

    :cond_0
    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->JYn()Landroid/view/View;

    move-result-object v0

    const/4 v2, 0x1

    if-eqz v0, :cond_1

    invoke-virtual {p3, v0, p2}, Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;->ZfxDd(Landroid/view/View;Landroidx/recyclerview/widget/RecyclerView$VocHEe;)Z

    move-result v3

    if-eqz v3, :cond_1

    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->tQ(Landroid/view/View;)I

    move-result p0

    invoke-virtual {p3, v0, p0}, Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;->wA(Landroid/view/View;I)V

    return v2

    :cond_1
    iget-boolean v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->Ucbh:Z

    iget-boolean v3, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->HGpJ:Z

    if-eq v0, v3, :cond_2

    return v1

    :cond_2
    iget-boolean v0, p3, Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;->ZfxDd:Z

    invoke-virtual {p0, p1, p2, v0, v3}, Landroidx/recyclerview/widget/LinearLayoutManager;->xfXeiC(Landroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;ZZ)Landroid/view/View;

    move-result-object p1

    if-eqz p1, :cond_8

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/RecyclerView$qGY;->tQ(Landroid/view/View;)I

    move-result v0

    invoke-virtual {p3, p1, v0}, Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;->AZxh(Landroid/view/View;I)V

    invoke-virtual {p2}, Landroidx/recyclerview/widget/RecyclerView$VocHEe;->KLFTb()Z

    move-result p2

    if-nez p2, :cond_7

    invoke-virtual {p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->ERt()Z

    move-result p2

    if-eqz p2, :cond_7

    iget-object p2, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {p2, p1}, Landroidx/recyclerview/widget/qdMbNW;->xJ(Landroid/view/View;)I

    move-result p2

    iget-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v0, p1}, Landroidx/recyclerview/widget/qdMbNW;->ZfxDd(Landroid/view/View;)I

    move-result p1

    iget-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v0}, Landroidx/recyclerview/widget/qdMbNW;->MiMN()I

    move-result v0

    iget-object p0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {p0}, Landroidx/recyclerview/widget/qdMbNW;->qdMbNW()I

    move-result p0

    if-gt p1, v0, :cond_3

    if-ge p2, v0, :cond_3

    move v3, v2

    goto :goto_0

    :cond_3
    move v3, v1

    :goto_0
    if-lt p2, p0, :cond_4

    if-le p1, p0, :cond_4

    move v1, v2

    :cond_4
    if-nez v3, :cond_5

    if-eqz v1, :cond_7

    :cond_5
    iget-boolean p1, p3, Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;->ZfxDd:Z

    if-eqz p1, :cond_6

    move v0, p0

    :cond_6
    iput v0, p3, Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;->wA:I

    :cond_7
    return v2

    :cond_8
    return v1
.end method

.method public MiMN()Z
    .locals 1

    iget p0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->Pq:I

    const/4 v0, 0x1

    if-ne p0, v0, :cond_0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public final Mpf(ILandroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;Z)I
    .locals 1

    iget-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v0}, Landroidx/recyclerview/widget/qdMbNW;->qdMbNW()I

    move-result v0

    sub-int/2addr v0, p1

    if-lez v0, :cond_1

    neg-int v0, v0

    invoke-virtual {p0, v0, p2, p3}, Landroidx/recyclerview/widget/LinearLayoutManager;->jTNPnW(ILandroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;)I

    move-result p2

    neg-int p2, p2

    add-int/2addr p1, p2

    if-eqz p4, :cond_0

    iget-object p3, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {p3}, Landroidx/recyclerview/widget/qdMbNW;->qdMbNW()I

    move-result p3

    sub-int/2addr p3, p1

    if-lez p3, :cond_0

    iget-object p0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {p0, p3}, Landroidx/recyclerview/widget/qdMbNW;->IEE(I)V

    add-int/2addr p3, p2

    return p3

    :cond_0
    return p2

    :cond_1
    const/4 p0, 0x0

    return p0
.end method

.method public final Otxclu(Landroidx/recyclerview/widget/RecyclerView$Ucbh;II)V
    .locals 4

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->zvd()I

    move-result v0

    if-gez p2, :cond_0

    return-void

    :cond_0
    iget-object v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v1}, Landroidx/recyclerview/widget/qdMbNW;->lgHUyS()I

    move-result v1

    sub-int/2addr v1, p2

    add-int/2addr v1, p3

    iget-boolean p2, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->Gd:Z

    if-eqz p2, :cond_3

    const/4 p2, 0x0

    move p3, p2

    :goto_0
    if-ge p3, v0, :cond_6

    invoke-virtual {p0, p3}, Landroidx/recyclerview/widget/RecyclerView$qGY;->KLMXS(I)Landroid/view/View;

    move-result-object v2

    iget-object v3, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v3, v2}, Landroidx/recyclerview/widget/qdMbNW;->xJ(Landroid/view/View;)I

    move-result v3

    if-lt v3, v1, :cond_2

    iget-object v3, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v3, v2}, Landroidx/recyclerview/widget/qdMbNW;->fehf(Landroid/view/View;)I

    move-result v2

    if-ge v2, v1, :cond_1

    goto :goto_1

    :cond_1
    add-int/lit8 p3, p3, 0x1

    goto :goto_0

    :cond_2
    :goto_1
    invoke-virtual {p0, p1, p2, p3}, Landroidx/recyclerview/widget/LinearLayoutManager;->TFbkuO(Landroidx/recyclerview/widget/RecyclerView$Ucbh;II)V

    return-void

    :cond_3
    add-int/lit8 v0, v0, -0x1

    move p2, v0

    :goto_2
    if-ltz p2, :cond_6

    invoke-virtual {p0, p2}, Landroidx/recyclerview/widget/RecyclerView$qGY;->KLMXS(I)Landroid/view/View;

    move-result-object p3

    iget-object v2, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v2, p3}, Landroidx/recyclerview/widget/qdMbNW;->xJ(Landroid/view/View;)I

    move-result v2

    if-lt v2, v1, :cond_5

    iget-object v2, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v2, p3}, Landroidx/recyclerview/widget/qdMbNW;->fehf(Landroid/view/View;)I

    move-result p3

    if-ge p3, v1, :cond_4

    goto :goto_3

    :cond_4
    add-int/lit8 p2, p2, -0x1

    goto :goto_2

    :cond_5
    :goto_3
    invoke-virtual {p0, p1, v0, p2}, Landroidx/recyclerview/widget/LinearLayoutManager;->TFbkuO(Landroidx/recyclerview/widget/RecyclerView$Ucbh;II)V

    :cond_6
    return-void
.end method

.method public final OzIs(Landroidx/recyclerview/widget/RecyclerView$Ucbh;II)V
    .locals 4

    if-gez p2, :cond_0

    return-void

    :cond_0
    sub-int/2addr p2, p3

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->zvd()I

    move-result p3

    iget-boolean v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->Gd:Z

    if-eqz v0, :cond_3

    add-int/lit8 p3, p3, -0x1

    move v0, p3

    :goto_0
    if-ltz v0, :cond_6

    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->KLMXS(I)Landroid/view/View;

    move-result-object v1

    iget-object v2, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v2, v1}, Landroidx/recyclerview/widget/qdMbNW;->ZfxDd(Landroid/view/View;)I

    move-result v2

    if-gt v2, p2, :cond_2

    iget-object v2, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v2, v1}, Landroidx/recyclerview/widget/qdMbNW;->qGY(Landroid/view/View;)I

    move-result v1

    if-le v1, p2, :cond_1

    goto :goto_1

    :cond_1
    add-int/lit8 v0, v0, -0x1

    goto :goto_0

    :cond_2
    :goto_1
    invoke-virtual {p0, p1, p3, v0}, Landroidx/recyclerview/widget/LinearLayoutManager;->TFbkuO(Landroidx/recyclerview/widget/RecyclerView$Ucbh;II)V

    return-void

    :cond_3
    const/4 v0, 0x0

    move v1, v0

    :goto_2
    if-ge v1, p3, :cond_6

    invoke-virtual {p0, v1}, Landroidx/recyclerview/widget/RecyclerView$qGY;->KLMXS(I)Landroid/view/View;

    move-result-object v2

    iget-object v3, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v3, v2}, Landroidx/recyclerview/widget/qdMbNW;->ZfxDd(Landroid/view/View;)I

    move-result v3

    if-gt v3, p2, :cond_5

    iget-object v3, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v3, v2}, Landroidx/recyclerview/widget/qdMbNW;->qGY(Landroid/view/View;)I

    move-result v2

    if-le v2, p2, :cond_4

    goto :goto_3

    :cond_4
    add-int/lit8 v1, v1, 0x1

    goto :goto_2

    :cond_5
    :goto_3
    invoke-virtual {p0, p1, v0, v1}, Landroidx/recyclerview/widget/LinearLayoutManager;->TFbkuO(Landroidx/recyclerview/widget/RecyclerView$Ucbh;II)V

    :cond_6
    return-void
.end method

.method public Pq(Landroidx/recyclerview/widget/RecyclerView$VocHEe;)I
    .locals 0

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/LinearLayoutManager;->QyMqpM(Landroidx/recyclerview/widget/RecyclerView$VocHEe;)I

    move-result p0

    return p0
.end method

.method public final QyMqpM(Landroidx/recyclerview/widget/RecyclerView$VocHEe;)I
    .locals 7

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->zvd()I

    move-result v0

    if-nez v0, :cond_0

    const/4 p0, 0x0

    return p0

    :cond_0
    invoke-virtual {p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->qrxT()V

    iget-object v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    iget-boolean v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->vI:Z

    const/4 v2, 0x1

    xor-int/2addr v0, v2

    invoke-virtual {p0, v0, v2}, Landroidx/recyclerview/widget/LinearLayoutManager;->xbjHT(ZZ)Landroid/view/View;

    move-result-object v3

    iget-boolean v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->vI:Z

    xor-int/2addr v0, v2

    invoke-virtual {p0, v0, v2}, Landroidx/recyclerview/widget/LinearLayoutManager;->EoC(ZZ)Landroid/view/View;

    move-result-object v4

    iget-boolean v5, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->vI:Z

    iget-boolean v6, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->Gd:Z

    move-object v0, p1

    move-object v2, v3

    move-object v3, v4

    move-object v4, p0

    invoke-static/range {v0 .. v6}, Landroidx/recyclerview/widget/VA;->AZxh(Landroidx/recyclerview/widget/RecyclerView$VocHEe;Landroidx/recyclerview/widget/qdMbNW;Landroid/view/View;Landroid/view/View;Landroidx/recyclerview/widget/RecyclerView$qGY;ZZ)I

    move-result p0

    return p0
.end method

.method public QyqF(ILandroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;)I
    .locals 1

    iget v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->Pq:I

    if-nez v0, :cond_0

    const/4 p0, 0x0

    return p0

    :cond_0
    invoke-virtual {p0, p1, p2, p3}, Landroidx/recyclerview/widget/LinearLayoutManager;->jTNPnW(ILandroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;)I

    move-result p0

    return p0
.end method

.method public final RWb()V
    .locals 2

    iget v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->Pq:I

    const/4 v1, 0x1

    if-eq v0, v1, :cond_1

    invoke-virtual {p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->jY()Z

    move-result v0

    if-nez v0, :cond_0

    goto :goto_0

    :cond_0
    iget-boolean v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->huTpC:Z

    xor-int/2addr v0, v1

    iput-boolean v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->Gd:Z

    goto :goto_1

    :cond_1
    :goto_0
    iget-boolean v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->huTpC:Z

    iput-boolean v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->Gd:Z

    :goto_1
    return-void
.end method

.method public final Rsp()Landroid/view/View;
    .locals 1

    iget-boolean v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->Gd:Z

    if-eqz v0, :cond_0

    invoke-virtual {p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->MC()Landroid/view/View;

    move-result-object p0

    goto :goto_0

    :cond_0
    invoke-virtual {p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->HX()Landroid/view/View;

    move-result-object p0

    :goto_0
    return-object p0
.end method

.method public Sx(Landroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;Landroidx/recyclerview/widget/LinearLayoutManager$wA;Landroidx/recyclerview/widget/LinearLayoutManager$AZxh;)V
    .locals 7

    invoke-virtual {p3, p1}, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->ZfxDd(Landroidx/recyclerview/widget/RecyclerView$Ucbh;)Landroid/view/View;

    move-result-object p1

    const/4 p2, 0x1

    if-nez p1, :cond_0

    iput-boolean p2, p4, Landroidx/recyclerview/widget/LinearLayoutManager$AZxh;->AZxh:Z

    return-void

    :cond_0
    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    move-object v6, v0

    check-cast v6, Landroidx/recyclerview/widget/RecyclerView$fehf;

    iget-object v0, p3, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->VA:Ljava/util/List;

    const/4 v1, -0x1

    const/4 v2, 0x0

    if-nez v0, :cond_3

    iget-boolean v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->Gd:Z

    iget v3, p3, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->JHa:I

    if-ne v3, v1, :cond_1

    move v3, p2

    goto :goto_0

    :cond_1
    move v3, v2

    :goto_0
    if-ne v0, v3, :cond_2

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/RecyclerView$qGY;->KLFTb(Landroid/view/View;)V

    goto :goto_2

    :cond_2
    invoke-virtual {p0, p1, v2}, Landroidx/recyclerview/widget/RecyclerView$qGY;->JHa(Landroid/view/View;I)V

    goto :goto_2

    :cond_3
    iget-boolean v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->Gd:Z

    iget v3, p3, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->JHa:I

    if-ne v3, v1, :cond_4

    move v3, p2

    goto :goto_1

    :cond_4
    move v3, v2

    :goto_1
    if-ne v0, v3, :cond_5

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/RecyclerView$qGY;->wA(Landroid/view/View;)V

    goto :goto_2

    :cond_5
    invoke-virtual {p0, p1, v2}, Landroidx/recyclerview/widget/RecyclerView$qGY;->ZfxDd(Landroid/view/View;I)V

    :goto_2
    invoke-virtual {p0, p1, v2, v2}, Landroidx/recyclerview/widget/RecyclerView$qGY;->XtE(Landroid/view/View;II)V

    iget-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v0, p1}, Landroidx/recyclerview/widget/qdMbNW;->KLFTb(Landroid/view/View;)I

    move-result v0

    iput v0, p4, Landroidx/recyclerview/widget/LinearLayoutManager$AZxh;->mjFkc:I

    iget v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->Pq:I

    if-ne v0, p2, :cond_8

    invoke-virtual {p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->jY()Z

    move-result v0

    if-eqz v0, :cond_6

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->SOS()I

    move-result v0

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->ANMGZc()I

    move-result v2

    sub-int/2addr v0, v2

    iget-object v2, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v2, p1}, Landroidx/recyclerview/widget/qdMbNW;->JHa(Landroid/view/View;)I

    move-result v2

    sub-int v2, v0, v2

    goto :goto_3

    :cond_6
    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->jm()I

    move-result v2

    iget-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v0, p1}, Landroidx/recyclerview/widget/qdMbNW;->JHa(Landroid/view/View;)I

    move-result v0

    add-int/2addr v0, v2

    :goto_3
    iget v3, p3, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->JHa:I

    if-ne v3, v1, :cond_7

    iget p3, p3, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->AZxh:I

    iget v1, p4, Landroidx/recyclerview/widget/LinearLayoutManager$AZxh;->mjFkc:I

    sub-int v1, p3, v1

    move v5, p3

    move v4, v0

    move v3, v1

    goto :goto_4

    :cond_7
    iget p3, p3, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->AZxh:I

    iget v1, p4, Landroidx/recyclerview/widget/LinearLayoutManager$AZxh;->mjFkc:I

    add-int/2addr v1, p3

    move v3, p3

    move v4, v0

    move v5, v1

    goto :goto_4

    :cond_8
    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->dm()I

    move-result v0

    iget-object v2, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v2, p1}, Landroidx/recyclerview/widget/qdMbNW;->JHa(Landroid/view/View;)I

    move-result v2

    add-int/2addr v2, v0

    iget v3, p3, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->JHa:I

    if-ne v3, v1, :cond_9

    iget p3, p3, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->AZxh:I

    iget v1, p4, Landroidx/recyclerview/widget/LinearLayoutManager$AZxh;->mjFkc:I

    sub-int v1, p3, v1

    move v4, p3

    move v3, v0

    move v5, v2

    move v2, v1

    goto :goto_4

    :cond_9
    iget p3, p3, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->AZxh:I

    iget v1, p4, Landroidx/recyclerview/widget/LinearLayoutManager$AZxh;->mjFkc:I

    add-int/2addr v1, p3

    move v3, v0

    move v4, v1

    move v5, v2

    move v2, p3

    :goto_4
    move-object v0, p0

    move-object v1, p1

    invoke-virtual/range {v0 .. v5}, Landroidx/recyclerview/widget/RecyclerView$qGY;->XFUzSY(Landroid/view/View;IIII)V

    invoke-virtual {v6}, Landroidx/recyclerview/widget/RecyclerView$fehf;->wA()Z

    move-result p0

    if-nez p0, :cond_a

    invoke-virtual {v6}, Landroidx/recyclerview/widget/RecyclerView$fehf;->AZxh()Z

    move-result p0

    if-eqz p0, :cond_b

    :cond_a
    iput-boolean p2, p4, Landroidx/recyclerview/widget/LinearLayoutManager$AZxh;->wA:Z

    :cond_b
    invoke-virtual {p1}, Landroid/view/View;->hasFocusable()Z

    move-result p0

    iput-boolean p0, p4, Landroidx/recyclerview/widget/LinearLayoutManager$AZxh;->ZfxDd:Z

    return-void
.end method

.method public final TFbkuO(Landroidx/recyclerview/widget/RecyclerView$Ucbh;II)V
    .locals 0

    if-ne p2, p3, :cond_0

    return-void

    :cond_0
    if-le p3, p2, :cond_1

    add-int/lit8 p3, p3, -0x1

    :goto_0
    if-lt p3, p2, :cond_2

    invoke-virtual {p0, p3, p1}, Landroidx/recyclerview/widget/RecyclerView$qGY;->Vu(ILandroidx/recyclerview/widget/RecyclerView$Ucbh;)V

    add-int/lit8 p3, p3, -0x1

    goto :goto_0

    :cond_1
    :goto_1
    if-le p2, p3, :cond_2

    invoke-virtual {p0, p2, p1}, Landroidx/recyclerview/widget/RecyclerView$qGY;->Vu(ILandroidx/recyclerview/widget/RecyclerView$Ucbh;)V

    add-int/lit8 p2, p2, -0x1

    goto :goto_1

    :cond_2
    return-void
.end method

.method public TvfBiy(IIZZ)Landroid/view/View;
    .locals 1

    invoke-virtual {p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->qrxT()V

    const/16 v0, 0x140

    if-eqz p3, :cond_0

    const/16 p3, 0x6003

    goto :goto_0

    :cond_0
    move p3, v0

    :goto_0
    if-eqz p4, :cond_1

    goto :goto_1

    :cond_1
    const/4 v0, 0x0

    :goto_1
    iget p4, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->Pq:I

    if-nez p4, :cond_2

    iget-object p0, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->KLFTb:Landroidx/recyclerview/widget/rkYL;

    invoke-virtual {p0, p1, p2, p3, v0}, Landroidx/recyclerview/widget/rkYL;->mjFkc(IIII)Landroid/view/View;

    move-result-object p0

    goto :goto_2

    :cond_2
    iget-object p0, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->JHa:Landroidx/recyclerview/widget/rkYL;

    invoke-virtual {p0, p1, p2, p3, v0}, Landroidx/recyclerview/widget/rkYL;->mjFkc(IIII)Landroid/view/View;

    move-result-object p0

    :goto_2
    return-object p0
.end method

.method public Tw(I)V
    .locals 0

    iput p1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->VocHEe:I

    const/high16 p1, -0x80000000

    iput p1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->BAnRFn:I

    iget-object p1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->wJVbdd:Landroidx/recyclerview/widget/LinearLayoutManager$ZfxDd;

    if-eqz p1, :cond_0

    invoke-virtual {p1}, Landroidx/recyclerview/widget/LinearLayoutManager$ZfxDd;->AZxh()V

    :cond_0
    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->mzUGzO()V

    return-void
.end method

.method public UDcil()I
    .locals 0

    iget p0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->Pq:I

    return p0
.end method

.method public UOnCkw()Z
    .locals 0

    iget-boolean p0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->vI:Z

    return p0
.end method

.method public final UPU(Landroidx/recyclerview/widget/RecyclerView$VocHEe;Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;)Z
    .locals 4

    invoke-virtual {p1}, Landroidx/recyclerview/widget/RecyclerView$VocHEe;->KLFTb()Z

    move-result v0

    const/4 v1, 0x0

    if-nez v0, :cond_f

    iget v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->VocHEe:I

    const/4 v2, -0x1

    if-ne v0, v2, :cond_0

    goto/16 :goto_6

    :cond_0
    const/high16 v3, -0x80000000

    if-ltz v0, :cond_e

    invoke-virtual {p1}, Landroidx/recyclerview/widget/RecyclerView$VocHEe;->AZxh()I

    move-result p1

    if-lt v0, p1, :cond_1

    goto/16 :goto_5

    :cond_1
    iget p1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->VocHEe:I

    iput p1, p2, Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;->AZxh:I

    iget-object p1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->wJVbdd:Landroidx/recyclerview/widget/LinearLayoutManager$ZfxDd;

    const/4 v0, 0x1

    if-eqz p1, :cond_3

    invoke-virtual {p1}, Landroidx/recyclerview/widget/LinearLayoutManager$ZfxDd;->mjFkc()Z

    move-result p1

    if-eqz p1, :cond_3

    iget-object p1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->wJVbdd:Landroidx/recyclerview/widget/LinearLayoutManager$ZfxDd;

    iget-boolean p1, p1, Landroidx/recyclerview/widget/LinearLayoutManager$ZfxDd;->wA:Z

    iput-boolean p1, p2, Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;->ZfxDd:Z

    if-eqz p1, :cond_2

    iget-object p1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {p1}, Landroidx/recyclerview/widget/qdMbNW;->qdMbNW()I

    move-result p1

    iget-object p0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->wJVbdd:Landroidx/recyclerview/widget/LinearLayoutManager$ZfxDd;

    iget p0, p0, Landroidx/recyclerview/widget/LinearLayoutManager$ZfxDd;->AZxh:I

    sub-int/2addr p1, p0

    iput p1, p2, Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;->wA:I

    goto :goto_0

    :cond_2
    iget-object p1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {p1}, Landroidx/recyclerview/widget/qdMbNW;->MiMN()I

    move-result p1

    iget-object p0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->wJVbdd:Landroidx/recyclerview/widget/LinearLayoutManager$ZfxDd;

    iget p0, p0, Landroidx/recyclerview/widget/LinearLayoutManager$ZfxDd;->AZxh:I

    add-int/2addr p1, p0

    iput p1, p2, Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;->wA:I

    :goto_0
    return v0

    :cond_3
    iget p1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->BAnRFn:I

    if-ne p1, v3, :cond_c

    iget p1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->VocHEe:I

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/LinearLayoutManager;->wJVbdd(I)Landroid/view/View;

    move-result-object p1

    if-eqz p1, :cond_8

    iget-object v2, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v2, p1}, Landroidx/recyclerview/widget/qdMbNW;->KLFTb(Landroid/view/View;)I

    move-result v2

    iget-object v3, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v3}, Landroidx/recyclerview/widget/qdMbNW;->YoKzxo()I

    move-result v3

    if-le v2, v3, :cond_4

    invoke-virtual {p2}, Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;->mjFkc()V

    return v0

    :cond_4
    iget-object v2, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v2, p1}, Landroidx/recyclerview/widget/qdMbNW;->xJ(Landroid/view/View;)I

    move-result v2

    iget-object v3, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v3}, Landroidx/recyclerview/widget/qdMbNW;->MiMN()I

    move-result v3

    sub-int/2addr v2, v3

    if-gez v2, :cond_5

    iget-object p0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {p0}, Landroidx/recyclerview/widget/qdMbNW;->MiMN()I

    move-result p0

    iput p0, p2, Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;->wA:I

    iput-boolean v1, p2, Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;->ZfxDd:Z

    return v0

    :cond_5
    iget-object v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v1}, Landroidx/recyclerview/widget/qdMbNW;->qdMbNW()I

    move-result v1

    iget-object v2, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v2, p1}, Landroidx/recyclerview/widget/qdMbNW;->ZfxDd(Landroid/view/View;)I

    move-result v2

    sub-int/2addr v1, v2

    if-gez v1, :cond_6

    iget-object p0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {p0}, Landroidx/recyclerview/widget/qdMbNW;->qdMbNW()I

    move-result p0

    iput p0, p2, Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;->wA:I

    iput-boolean v0, p2, Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;->ZfxDd:Z

    return v0

    :cond_6
    iget-boolean v1, p2, Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;->ZfxDd:Z

    if-eqz v1, :cond_7

    iget-object v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v1, p1}, Landroidx/recyclerview/widget/qdMbNW;->ZfxDd(Landroid/view/View;)I

    move-result p1

    iget-object p0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {p0}, Landroidx/recyclerview/widget/qdMbNW;->rkYL()I

    move-result p0

    add-int/2addr p1, p0

    goto :goto_1

    :cond_7
    iget-object p0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/qdMbNW;->xJ(Landroid/view/View;)I

    move-result p1

    :goto_1
    iput p1, p2, Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;->wA:I

    goto :goto_3

    :cond_8
    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->zvd()I

    move-result p1

    if-lez p1, :cond_b

    invoke-virtual {p0, v1}, Landroidx/recyclerview/widget/RecyclerView$qGY;->KLMXS(I)Landroid/view/View;

    move-result-object p1

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/RecyclerView$qGY;->tQ(Landroid/view/View;)I

    move-result p1

    iget v2, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->VocHEe:I

    if-ge v2, p1, :cond_9

    move p1, v0

    goto :goto_2

    :cond_9
    move p1, v1

    :goto_2
    iget-boolean p0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->Gd:Z

    if-ne p1, p0, :cond_a

    move v1, v0

    :cond_a
    iput-boolean v1, p2, Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;->ZfxDd:Z

    :cond_b
    invoke-virtual {p2}, Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;->mjFkc()V

    :goto_3
    return v0

    :cond_c
    iget-boolean p1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->Gd:Z

    iput-boolean p1, p2, Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;->ZfxDd:Z

    if-eqz p1, :cond_d

    iget-object p1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {p1}, Landroidx/recyclerview/widget/qdMbNW;->qdMbNW()I

    move-result p1

    iget p0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->BAnRFn:I

    sub-int/2addr p1, p0

    iput p1, p2, Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;->wA:I

    goto :goto_4

    :cond_d
    iget-object p1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {p1}, Landroidx/recyclerview/widget/qdMbNW;->MiMN()I

    move-result p1

    iget p0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->BAnRFn:I

    add-int/2addr p1, p0

    iput p1, p2, Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;->wA:I

    :goto_4
    return v0

    :cond_e
    :goto_5
    iput v2, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->VocHEe:I

    iput v3, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->BAnRFn:I

    :cond_f
    :goto_6
    return v1
.end method

.method public Ucbh(Landroidx/recyclerview/widget/RecyclerView$VocHEe;)I
    .locals 0

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/LinearLayoutManager;->QyMqpM(Landroidx/recyclerview/widget/RecyclerView$VocHEe;)I

    move-result p0

    return p0
.end method

.method public VA()Z
    .locals 0

    iget p0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->Pq:I

    if-nez p0, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method

.method public Vptz()Landroidx/recyclerview/widget/LinearLayoutManager$wA;
    .locals 0

    new-instance p0, Landroidx/recyclerview/widget/LinearLayoutManager$wA;

    invoke-direct {p0}, Landroidx/recyclerview/widget/LinearLayoutManager$wA;-><init>()V

    return-object p0
.end method

.method public XD(Landroidx/recyclerview/widget/RecyclerView;Landroidx/recyclerview/widget/RecyclerView$Ucbh;)V
    .locals 0

    invoke-super {p0, p1, p2}, Landroidx/recyclerview/widget/RecyclerView$qGY;->XD(Landroidx/recyclerview/widget/RecyclerView;Landroidx/recyclerview/widget/RecyclerView$Ucbh;)V

    iget-boolean p1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->lB:Z

    if-eqz p1, :cond_0

    invoke-virtual {p0, p2}, Landroidx/recyclerview/widget/RecyclerView$qGY;->sqndV(Landroidx/recyclerview/widget/RecyclerView$Ucbh;)V

    invoke-virtual {p2}, Landroidx/recyclerview/widget/RecyclerView$Ucbh;->wA()V

    :cond_0
    return-void
.end method

.method public Xxz(Landroidx/recyclerview/widget/RecyclerView$VocHEe;)V
    .locals 0

    invoke-super {p0, p1}, Landroidx/recyclerview/widget/RecyclerView$qGY;->Xxz(Landroidx/recyclerview/widget/RecyclerView$VocHEe;)V

    const/4 p1, 0x0

    iput-object p1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->wJVbdd:Landroidx/recyclerview/widget/LinearLayoutManager$ZfxDd;

    const/4 p1, -0x1

    iput p1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->VocHEe:I

    const/high16 p1, -0x80000000

    iput p1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->BAnRFn:I

    iget-object p0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->mByQ:Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;

    invoke-virtual {p0}, Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;->KLFTb()V

    return-void
.end method

.method public XyP(Landroidx/recyclerview/widget/RecyclerView$VocHEe;)I
    .locals 0

    invoke-virtual {p1}, Landroidx/recyclerview/widget/RecyclerView$VocHEe;->ZfxDd()Z

    move-result p1

    if-eqz p1, :cond_0

    iget-object p0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {p0}, Landroidx/recyclerview/widget/qdMbNW;->YoKzxo()I

    move-result p0

    return p0

    :cond_0
    const/4 p0, 0x0

    return p0
.end method

.method public final ZGL(II)V
    .locals 2

    iget-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->diqgf:Landroidx/recyclerview/widget/LinearLayoutManager$wA;

    iget-object v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v1}, Landroidx/recyclerview/widget/qdMbNW;->MiMN()I

    move-result v1

    sub-int v1, p2, v1

    iput v1, v0, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->wA:I

    iget-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->diqgf:Landroidx/recyclerview/widget/LinearLayoutManager$wA;

    iput p1, v0, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->ZfxDd:I

    iget-boolean p0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->Gd:Z

    const/4 p1, -0x1

    if-eqz p0, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    move p0, p1

    :goto_0
    iput p0, v0, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->KLFTb:I

    iput p1, v0, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->JHa:I

    iput p2, v0, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->AZxh:I

    const/high16 p0, -0x80000000

    iput p0, v0, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->xJ:I

    return-void
.end method

.method public aDq()I
    .locals 4

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->zvd()I

    move-result v0

    const/4 v1, 0x1

    sub-int/2addr v0, v1

    const/4 v2, 0x0

    const/4 v3, -0x1

    invoke-virtual {p0, v0, v3, v2, v1}, Landroidx/recyclerview/widget/LinearLayoutManager;->TvfBiy(IIZZ)Landroid/view/View;

    move-result-object v0

    if-nez v0, :cond_0

    goto :goto_0

    :cond_0
    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->tQ(Landroid/view/View;)I

    move-result v3

    :goto_0
    return v3
.end method

.method public final bWIyu()Landroid/view/View;
    .locals 1

    iget-boolean v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->Gd:Z

    if-eqz v0, :cond_0

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->zvd()I

    move-result v0

    add-int/lit8 v0, v0, -0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->KLMXS(I)Landroid/view/View;

    move-result-object p0

    return-object p0
.end method

.method public cdjp(Z)V
    .locals 1

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/LinearLayoutManager;->lgHUyS(Ljava/lang/String;)V

    iget-boolean v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->huTpC:Z

    if-ne p1, v0, :cond_0

    return-void

    :cond_0
    iput-boolean p1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->huTpC:Z

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->mzUGzO()V

    return-void
.end method

.method public dGDT(Landroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;)V
    .locals 8

    iget-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->wJVbdd:Landroidx/recyclerview/widget/LinearLayoutManager$ZfxDd;

    const/4 v1, -0x1

    if-nez v0, :cond_0

    iget v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->VocHEe:I

    if-eq v0, v1, :cond_1

    :cond_0
    invoke-virtual {p2}, Landroidx/recyclerview/widget/RecyclerView$VocHEe;->AZxh()I

    move-result v0

    if-nez v0, :cond_1

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/RecyclerView$qGY;->sqndV(Landroidx/recyclerview/widget/RecyclerView$Ucbh;)V

    return-void

    :cond_1
    iget-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->wJVbdd:Landroidx/recyclerview/widget/LinearLayoutManager$ZfxDd;

    if-eqz v0, :cond_2

    invoke-virtual {v0}, Landroidx/recyclerview/widget/LinearLayoutManager$ZfxDd;->mjFkc()Z

    move-result v0

    if-eqz v0, :cond_2

    iget-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->wJVbdd:Landroidx/recyclerview/widget/LinearLayoutManager$ZfxDd;

    iget v0, v0, Landroidx/recyclerview/widget/LinearLayoutManager$ZfxDd;->mjFkc:I

    iput v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->VocHEe:I

    :cond_2
    invoke-virtual {p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->qrxT()V

    iget-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->diqgf:Landroidx/recyclerview/widget/LinearLayoutManager$wA;

    const/4 v2, 0x0

    iput-boolean v2, v0, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->mjFkc:Z

    invoke-virtual {p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->RWb()V

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->JYn()Landroid/view/View;

    move-result-object v0

    iget-object v3, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->mByQ:Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;

    iget-boolean v4, v3, Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;->KLFTb:Z

    const/4 v5, 0x1

    if-eqz v4, :cond_5

    iget v4, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->VocHEe:I

    if-ne v4, v1, :cond_5

    iget-object v4, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->wJVbdd:Landroidx/recyclerview/widget/LinearLayoutManager$ZfxDd;

    if-eqz v4, :cond_3

    goto :goto_0

    :cond_3
    if-eqz v0, :cond_6

    iget-object v3, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v3, v0}, Landroidx/recyclerview/widget/qdMbNW;->xJ(Landroid/view/View;)I

    move-result v3

    iget-object v4, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v4}, Landroidx/recyclerview/widget/qdMbNW;->qdMbNW()I

    move-result v4

    if-ge v3, v4, :cond_4

    iget-object v3, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v3, v0}, Landroidx/recyclerview/widget/qdMbNW;->ZfxDd(Landroid/view/View;)I

    move-result v3

    iget-object v4, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v4}, Landroidx/recyclerview/widget/qdMbNW;->MiMN()I

    move-result v4

    if-gt v3, v4, :cond_6

    :cond_4
    iget-object v3, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->mByQ:Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;

    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->tQ(Landroid/view/View;)I

    move-result v4

    invoke-virtual {v3, v0, v4}, Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;->wA(Landroid/view/View;I)V

    goto :goto_1

    :cond_5
    :goto_0
    invoke-virtual {v3}, Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;->KLFTb()V

    iget-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->mByQ:Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;

    iget-boolean v3, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->Gd:Z

    iget-boolean v4, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->HGpJ:Z

    xor-int/2addr v3, v4

    iput-boolean v3, v0, Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;->ZfxDd:Z

    invoke-virtual {p0, p1, p2, v0}, Landroidx/recyclerview/widget/LinearLayoutManager;->IPpyV(Landroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;)V

    iget-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->mByQ:Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;

    iput-boolean v5, v0, Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;->KLFTb:Z

    :cond_6
    :goto_1
    iget-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->diqgf:Landroidx/recyclerview/widget/LinearLayoutManager$wA;

    iget v3, v0, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->ETF:I

    if-ltz v3, :cond_7

    move v3, v5

    goto :goto_2

    :cond_7
    move v3, v1

    :goto_2
    iput v3, v0, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->JHa:I

    iget-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->CqaNbM:[I

    aput v2, v0, v2

    aput v2, v0, v5

    invoke-virtual {p0, p2, v0}, Landroidx/recyclerview/widget/LinearLayoutManager;->JOe(Landroidx/recyclerview/widget/RecyclerView$VocHEe;[I)V

    iget-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->CqaNbM:[I

    aget v0, v0, v2

    invoke-static {v2, v0}, Ljava/lang/Math;->max(II)I

    move-result v0

    iget-object v3, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v3}, Landroidx/recyclerview/widget/qdMbNW;->MiMN()I

    move-result v3

    add-int/2addr v0, v3

    iget-object v3, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->CqaNbM:[I

    aget v3, v3, v5

    invoke-static {v2, v3}, Ljava/lang/Math;->max(II)I

    move-result v3

    iget-object v4, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v4}, Landroidx/recyclerview/widget/qdMbNW;->Dt()I

    move-result v4

    add-int/2addr v3, v4

    invoke-virtual {p2}, Landroidx/recyclerview/widget/RecyclerView$VocHEe;->KLFTb()Z

    move-result v4

    if-eqz v4, :cond_a

    iget v4, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->VocHEe:I

    if-eq v4, v1, :cond_a

    iget v6, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->BAnRFn:I

    const/high16 v7, -0x80000000

    if-eq v6, v7, :cond_a

    invoke-virtual {p0, v4}, Landroidx/recyclerview/widget/LinearLayoutManager;->wJVbdd(I)Landroid/view/View;

    move-result-object v4

    if-eqz v4, :cond_a

    iget-boolean v6, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->Gd:Z

    if-eqz v6, :cond_8

    iget-object v6, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v6}, Landroidx/recyclerview/widget/qdMbNW;->qdMbNW()I

    move-result v6

    iget-object v7, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v7, v4}, Landroidx/recyclerview/widget/qdMbNW;->ZfxDd(Landroid/view/View;)I

    move-result v4

    sub-int/2addr v6, v4

    iget v4, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->BAnRFn:I

    :goto_3
    sub-int/2addr v6, v4

    goto :goto_4

    :cond_8
    iget-object v6, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v6, v4}, Landroidx/recyclerview/widget/qdMbNW;->xJ(Landroid/view/View;)I

    move-result v4

    iget-object v6, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v6}, Landroidx/recyclerview/widget/qdMbNW;->MiMN()I

    move-result v6

    sub-int/2addr v4, v6

    iget v6, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->BAnRFn:I

    goto :goto_3

    :goto_4
    if-lez v6, :cond_9

    add-int/2addr v0, v6

    goto :goto_5

    :cond_9
    sub-int/2addr v3, v6

    :cond_a
    :goto_5
    iget-object v4, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->mByQ:Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;

    iget-boolean v6, v4, Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;->ZfxDd:Z

    if-eqz v6, :cond_c

    iget-boolean v6, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->Gd:Z

    if-eqz v6, :cond_d

    :cond_b
    move v1, v5

    goto :goto_6

    :cond_c
    iget-boolean v6, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->Gd:Z

    if-eqz v6, :cond_b

    :cond_d
    :goto_6
    invoke-virtual {p0, p1, p2, v4, v1}, Landroidx/recyclerview/widget/LinearLayoutManager;->wGscSa(Landroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;I)V

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/RecyclerView$qGY;->Gd(Landroidx/recyclerview/widget/RecyclerView$Ucbh;)V

    iget-object v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->diqgf:Landroidx/recyclerview/widget/LinearLayoutManager$wA;

    invoke-virtual {p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->ArO()Z

    move-result v4

    iput-boolean v4, v1, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->MiMN:Z

    iget-object v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->diqgf:Landroidx/recyclerview/widget/LinearLayoutManager$wA;

    invoke-virtual {p2}, Landroidx/recyclerview/widget/RecyclerView$VocHEe;->KLFTb()Z

    move-result v4

    iput-boolean v4, v1, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->Dt:Z

    iget-object v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->diqgf:Landroidx/recyclerview/widget/LinearLayoutManager$wA;

    iput v2, v1, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->qdMbNW:I

    iget-object v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->mByQ:Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;

    iget-boolean v4, v1, Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;->ZfxDd:Z

    if-eqz v4, :cond_f

    invoke-virtual {p0, v1}, Landroidx/recyclerview/widget/LinearLayoutManager;->jpz(Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;)V

    iget-object v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->diqgf:Landroidx/recyclerview/widget/LinearLayoutManager$wA;

    iput v0, v1, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->lgHUyS:I

    invoke-virtual {p0, p1, v1, p2, v2}, Landroidx/recyclerview/widget/LinearLayoutManager;->CcoH(Landroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/LinearLayoutManager$wA;Landroidx/recyclerview/widget/RecyclerView$VocHEe;Z)I

    iget-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->diqgf:Landroidx/recyclerview/widget/LinearLayoutManager$wA;

    iget v1, v0, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->AZxh:I

    iget v4, v0, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->ZfxDd:I

    iget v0, v0, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->wA:I

    if-lez v0, :cond_e

    add-int/2addr v3, v0

    :cond_e
    iget-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->mByQ:Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;

    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/LinearLayoutManager;->Es(Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;)V

    iget-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->diqgf:Landroidx/recyclerview/widget/LinearLayoutManager$wA;

    iput v3, v0, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->lgHUyS:I

    iget v3, v0, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->ZfxDd:I

    iget v6, v0, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->KLFTb:I

    add-int/2addr v3, v6

    iput v3, v0, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->ZfxDd:I

    invoke-virtual {p0, p1, v0, p2, v2}, Landroidx/recyclerview/widget/LinearLayoutManager;->CcoH(Landroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/LinearLayoutManager$wA;Landroidx/recyclerview/widget/RecyclerView$VocHEe;Z)I

    iget-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->diqgf:Landroidx/recyclerview/widget/LinearLayoutManager$wA;

    iget v3, v0, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->AZxh:I

    iget v0, v0, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->wA:I

    if-lez v0, :cond_11

    invoke-virtual {p0, v4, v1}, Landroidx/recyclerview/widget/LinearLayoutManager;->ZGL(II)V

    iget-object v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->diqgf:Landroidx/recyclerview/widget/LinearLayoutManager$wA;

    iput v0, v1, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->lgHUyS:I

    invoke-virtual {p0, p1, v1, p2, v2}, Landroidx/recyclerview/widget/LinearLayoutManager;->CcoH(Landroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/LinearLayoutManager$wA;Landroidx/recyclerview/widget/RecyclerView$VocHEe;Z)I

    iget-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->diqgf:Landroidx/recyclerview/widget/LinearLayoutManager$wA;

    iget v1, v0, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->AZxh:I

    goto :goto_7

    :cond_f
    invoke-virtual {p0, v1}, Landroidx/recyclerview/widget/LinearLayoutManager;->Es(Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;)V

    iget-object v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->diqgf:Landroidx/recyclerview/widget/LinearLayoutManager$wA;

    iput v3, v1, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->lgHUyS:I

    invoke-virtual {p0, p1, v1, p2, v2}, Landroidx/recyclerview/widget/LinearLayoutManager;->CcoH(Landroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/LinearLayoutManager$wA;Landroidx/recyclerview/widget/RecyclerView$VocHEe;Z)I

    iget-object v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->diqgf:Landroidx/recyclerview/widget/LinearLayoutManager$wA;

    iget v3, v1, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->AZxh:I

    iget v4, v1, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->ZfxDd:I

    iget v1, v1, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->wA:I

    if-lez v1, :cond_10

    add-int/2addr v0, v1

    :cond_10
    iget-object v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->mByQ:Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;

    invoke-virtual {p0, v1}, Landroidx/recyclerview/widget/LinearLayoutManager;->jpz(Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;)V

    iget-object v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->diqgf:Landroidx/recyclerview/widget/LinearLayoutManager$wA;

    iput v0, v1, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->lgHUyS:I

    iget v0, v1, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->ZfxDd:I

    iget v6, v1, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->KLFTb:I

    add-int/2addr v0, v6

    iput v0, v1, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->ZfxDd:I

    invoke-virtual {p0, p1, v1, p2, v2}, Landroidx/recyclerview/widget/LinearLayoutManager;->CcoH(Landroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/LinearLayoutManager$wA;Landroidx/recyclerview/widget/RecyclerView$VocHEe;Z)I

    iget-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->diqgf:Landroidx/recyclerview/widget/LinearLayoutManager$wA;

    iget v1, v0, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->AZxh:I

    iget v0, v0, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->wA:I

    if-lez v0, :cond_11

    invoke-virtual {p0, v4, v3}, Landroidx/recyclerview/widget/LinearLayoutManager;->LlB(II)V

    iget-object v3, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->diqgf:Landroidx/recyclerview/widget/LinearLayoutManager$wA;

    iput v0, v3, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->lgHUyS:I

    invoke-virtual {p0, p1, v3, p2, v2}, Landroidx/recyclerview/widget/LinearLayoutManager;->CcoH(Landroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/LinearLayoutManager$wA;Landroidx/recyclerview/widget/RecyclerView$VocHEe;Z)I

    iget-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->diqgf:Landroidx/recyclerview/widget/LinearLayoutManager$wA;

    iget v3, v0, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->AZxh:I

    :cond_11
    :goto_7
    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->zvd()I

    move-result v0

    if-lez v0, :cond_13

    iget-boolean v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->Gd:Z

    iget-boolean v4, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->HGpJ:Z

    xor-int/2addr v0, v4

    if-eqz v0, :cond_12

    invoke-virtual {p0, v3, p1, p2, v5}, Landroidx/recyclerview/widget/LinearLayoutManager;->Mpf(ILandroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;Z)I

    move-result v0

    add-int/2addr v1, v0

    add-int/2addr v3, v0

    invoke-virtual {p0, v1, p1, p2, v2}, Landroidx/recyclerview/widget/LinearLayoutManager;->Hk(ILandroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;Z)I

    move-result v0

    :goto_8
    add-int/2addr v1, v0

    add-int/2addr v3, v0

    goto :goto_9

    :cond_12
    invoke-virtual {p0, v1, p1, p2, v5}, Landroidx/recyclerview/widget/LinearLayoutManager;->Hk(ILandroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;Z)I

    move-result v0

    add-int/2addr v1, v0

    add-int/2addr v3, v0

    invoke-virtual {p0, v3, p1, p2, v2}, Landroidx/recyclerview/widget/LinearLayoutManager;->Mpf(ILandroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;Z)I

    move-result v0

    goto :goto_8

    :cond_13
    :goto_9
    invoke-virtual {p0, p1, p2, v1, v3}, Landroidx/recyclerview/widget/LinearLayoutManager;->peCqC(Landroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;II)V

    invoke-virtual {p2}, Landroidx/recyclerview/widget/RecyclerView$VocHEe;->KLFTb()Z

    move-result p1

    if-nez p1, :cond_14

    iget-object p1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {p1}, Landroidx/recyclerview/widget/qdMbNW;->Pq()V

    goto :goto_a

    :cond_14
    iget-object p1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->mByQ:Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;

    invoke-virtual {p1}, Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;->KLFTb()V

    :goto_a
    iget-boolean p1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->HGpJ:Z

    iput-boolean p1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->Ucbh:Z

    return-void
.end method

.method public diqgf(Landroidx/recyclerview/widget/RecyclerView$VocHEe;)I
    .locals 0

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/LinearLayoutManager;->HExgdj(Landroidx/recyclerview/widget/RecyclerView$VocHEe;)I

    move-result p0

    return p0
.end method

.method public dkKKW()Landroid/os/Parcelable;
    .locals 4

    iget-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->wJVbdd:Landroidx/recyclerview/widget/LinearLayoutManager$ZfxDd;

    if-eqz v0, :cond_0

    new-instance v0, Landroidx/recyclerview/widget/LinearLayoutManager$ZfxDd;

    iget-object p0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->wJVbdd:Landroidx/recyclerview/widget/LinearLayoutManager$ZfxDd;

    invoke-direct {v0, p0}, Landroidx/recyclerview/widget/LinearLayoutManager$ZfxDd;-><init>(Landroidx/recyclerview/widget/LinearLayoutManager$ZfxDd;)V

    return-object v0

    :cond_0
    new-instance v0, Landroidx/recyclerview/widget/LinearLayoutManager$ZfxDd;

    invoke-direct {v0}, Landroidx/recyclerview/widget/LinearLayoutManager$ZfxDd;-><init>()V

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->zvd()I

    move-result v1

    if-lez v1, :cond_2

    invoke-virtual {p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->qrxT()V

    iget-boolean v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->Ucbh:Z

    iget-boolean v2, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->Gd:Z

    xor-int/2addr v1, v2

    iput-boolean v1, v0, Landroidx/recyclerview/widget/LinearLayoutManager$ZfxDd;->wA:Z

    if-eqz v1, :cond_1

    invoke-virtual {p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->oJ()Landroid/view/View;

    move-result-object v1

    iget-object v2, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v2}, Landroidx/recyclerview/widget/qdMbNW;->qdMbNW()I

    move-result v2

    iget-object v3, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v3, v1}, Landroidx/recyclerview/widget/qdMbNW;->ZfxDd(Landroid/view/View;)I

    move-result v3

    sub-int/2addr v2, v3

    iput v2, v0, Landroidx/recyclerview/widget/LinearLayoutManager$ZfxDd;->AZxh:I

    invoke-virtual {p0, v1}, Landroidx/recyclerview/widget/RecyclerView$qGY;->tQ(Landroid/view/View;)I

    move-result p0

    iput p0, v0, Landroidx/recyclerview/widget/LinearLayoutManager$ZfxDd;->mjFkc:I

    goto :goto_0

    :cond_1
    invoke-virtual {p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->bWIyu()Landroid/view/View;

    move-result-object v1

    invoke-virtual {p0, v1}, Landroidx/recyclerview/widget/RecyclerView$qGY;->tQ(Landroid/view/View;)I

    move-result v2

    iput v2, v0, Landroidx/recyclerview/widget/LinearLayoutManager$ZfxDd;->mjFkc:I

    iget-object v2, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v2, v1}, Landroidx/recyclerview/widget/qdMbNW;->xJ(Landroid/view/View;)I

    move-result v1

    iget-object p0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {p0}, Landroidx/recyclerview/widget/qdMbNW;->MiMN()I

    move-result p0

    sub-int/2addr v1, p0

    iput v1, v0, Landroidx/recyclerview/widget/LinearLayoutManager$ZfxDd;->AZxh:I

    goto :goto_0

    :cond_2
    invoke-virtual {v0}, Landroidx/recyclerview/widget/LinearLayoutManager$ZfxDd;->AZxh()V

    :goto_0
    return-object v0
.end method

.method public eyqo(Landroidx/recyclerview/widget/RecyclerView$VocHEe;)I
    .locals 0

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/LinearLayoutManager;->np(Landroidx/recyclerview/widget/RecyclerView$VocHEe;)I

    move-result p0

    return p0
.end method

.method public fehf(ILandroidx/recyclerview/widget/RecyclerView$qGY$wA;)V
    .locals 5

    iget-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->wJVbdd:Landroidx/recyclerview/widget/LinearLayoutManager$ZfxDd;

    const/4 v1, -0x1

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Landroidx/recyclerview/widget/LinearLayoutManager$ZfxDd;->mjFkc()Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->wJVbdd:Landroidx/recyclerview/widget/LinearLayoutManager$ZfxDd;

    iget-boolean v3, v0, Landroidx/recyclerview/widget/LinearLayoutManager$ZfxDd;->wA:Z

    iget v0, v0, Landroidx/recyclerview/widget/LinearLayoutManager$ZfxDd;->mjFkc:I

    goto :goto_0

    :cond_0
    invoke-virtual {p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->RWb()V

    iget-boolean v3, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->Gd:Z

    iget v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->VocHEe:I

    if-ne v0, v1, :cond_2

    if-eqz v3, :cond_1

    add-int/lit8 v0, p1, -0x1

    goto :goto_0

    :cond_1
    move v0, v2

    :cond_2
    :goto_0
    if-eqz v3, :cond_3

    goto :goto_1

    :cond_3
    const/4 v1, 0x1

    :goto_1
    move v3, v2

    :goto_2
    iget v4, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->Ne:I

    if-ge v3, v4, :cond_4

    if-ltz v0, :cond_4

    if-ge v0, p1, :cond_4

    invoke-interface {p2, v0, v2}, Landroidx/recyclerview/widget/RecyclerView$qGY$wA;->mjFkc(II)V

    add-int/2addr v0, v1

    add-int/lit8 v3, v3, 0x1

    goto :goto_2

    :cond_4
    return-void
.end method

.method public gtr(Landroid/view/View;ILandroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;)Landroid/view/View;
    .locals 3

    invoke-virtual {p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->RWb()V

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->zvd()I

    move-result p1

    const/4 v0, 0x0

    if-nez p1, :cond_0

    return-object v0

    :cond_0
    invoke-virtual {p0, p2}, Landroidx/recyclerview/widget/LinearLayoutManager;->KSf(I)I

    move-result p1

    const/high16 p2, -0x80000000

    if-ne p1, p2, :cond_1

    return-object v0

    :cond_1
    invoke-virtual {p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->qrxT()V

    iget-object v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v1}, Landroidx/recyclerview/widget/qdMbNW;->YoKzxo()I

    move-result v1

    int-to-float v1, v1

    const v2, 0x3eaaaaab

    mul-float/2addr v1, v2

    float-to-int v1, v1

    const/4 v2, 0x0

    invoke-virtual {p0, p1, v1, v2, p4}, Landroidx/recyclerview/widget/LinearLayoutManager;->kOlLW(IIZLandroidx/recyclerview/widget/RecyclerView$VocHEe;)V

    iget-object v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->diqgf:Landroidx/recyclerview/widget/LinearLayoutManager$wA;

    iput p2, v1, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->xJ:I

    iput-boolean v2, v1, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->mjFkc:Z

    const/4 p2, 0x1

    invoke-virtual {p0, p3, v1, p4, p2}, Landroidx/recyclerview/widget/LinearLayoutManager;->CcoH(Landroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/LinearLayoutManager$wA;Landroidx/recyclerview/widget/RecyclerView$VocHEe;Z)I

    const/4 p2, -0x1

    if-ne p1, p2, :cond_2

    invoke-virtual {p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->Rsp()Landroid/view/View;

    move-result-object p3

    goto :goto_0

    :cond_2
    invoke-virtual {p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->CqAnRZ()Landroid/view/View;

    move-result-object p3

    :goto_0
    if-ne p1, p2, :cond_3

    invoke-virtual {p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->bWIyu()Landroid/view/View;

    move-result-object p0

    goto :goto_1

    :cond_3
    invoke-virtual {p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->oJ()Landroid/view/View;

    move-result-object p0

    :goto_1
    invoke-virtual {p0}, Landroid/view/View;->hasFocusable()Z

    move-result p1

    if-eqz p1, :cond_5

    if-nez p3, :cond_4

    return-object v0

    :cond_4
    return-object p0

    :cond_5
    return-object p3
.end method

.method public huTpC(Landroidx/recyclerview/widget/RecyclerView$VocHEe;)I
    .locals 0

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/LinearLayoutManager;->HExgdj(Landroidx/recyclerview/widget/RecyclerView$VocHEe;)I

    move-result p0

    return p0
.end method

.method public jTNPnW(ILandroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;)I
    .locals 5

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->zvd()I

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_4

    if-nez p1, :cond_0

    goto :goto_1

    :cond_0
    invoke-virtual {p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->qrxT()V

    iget-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->diqgf:Landroidx/recyclerview/widget/LinearLayoutManager$wA;

    const/4 v2, 0x1

    iput-boolean v2, v0, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->mjFkc:Z

    if-lez p1, :cond_1

    move v0, v2

    goto :goto_0

    :cond_1
    const/4 v0, -0x1

    :goto_0
    invoke-static {p1}, Ljava/lang/Math;->abs(I)I

    move-result v3

    invoke-virtual {p0, v0, v3, v2, p3}, Landroidx/recyclerview/widget/LinearLayoutManager;->kOlLW(IIZLandroidx/recyclerview/widget/RecyclerView$VocHEe;)V

    iget-object v2, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->diqgf:Landroidx/recyclerview/widget/LinearLayoutManager$wA;

    iget v4, v2, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->xJ:I

    invoke-virtual {p0, p2, v2, p3, v1}, Landroidx/recyclerview/widget/LinearLayoutManager;->CcoH(Landroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/LinearLayoutManager$wA;Landroidx/recyclerview/widget/RecyclerView$VocHEe;Z)I

    move-result p2

    add-int/2addr v4, p2

    if-gez v4, :cond_2

    return v1

    :cond_2
    if-le v3, v4, :cond_3

    mul-int p1, v0, v4

    :cond_3
    iget-object p2, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    neg-int p3, p1

    invoke-virtual {p2, p3}, Landroidx/recyclerview/widget/qdMbNW;->IEE(I)V

    iget-object p0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->diqgf:Landroidx/recyclerview/widget/LinearLayoutManager$wA;

    iput p1, p0, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->ETF:I

    return p1

    :cond_4
    :goto_1
    return v1
.end method

.method public jY()Z
    .locals 1

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->WGXroI()I

    move-result p0

    const/4 v0, 0x1

    if-ne p0, v0, :cond_0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public final jpz(Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;)V
    .locals 1

    iget v0, p1, Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;->AZxh:I

    iget p1, p1, Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;->wA:I

    invoke-virtual {p0, v0, p1}, Landroidx/recyclerview/widget/LinearLayoutManager;->ZGL(II)V

    return-void
.end method

.method public final kOlLW(IIZLandroidx/recyclerview/widget/RecyclerView$VocHEe;)V
    .locals 4

    iget-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->diqgf:Landroidx/recyclerview/widget/LinearLayoutManager$wA;

    invoke-virtual {p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->ArO()Z

    move-result v1

    iput-boolean v1, v0, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->MiMN:Z

    iget-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->diqgf:Landroidx/recyclerview/widget/LinearLayoutManager$wA;

    iput p1, v0, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->JHa:I

    iget-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->CqaNbM:[I

    const/4 v1, 0x0

    aput v1, v0, v1

    const/4 v2, 0x1

    aput v1, v0, v2

    invoke-virtual {p0, p4, v0}, Landroidx/recyclerview/widget/LinearLayoutManager;->JOe(Landroidx/recyclerview/widget/RecyclerView$VocHEe;[I)V

    iget-object p4, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->CqaNbM:[I

    aget p4, p4, v1

    invoke-static {v1, p4}, Ljava/lang/Math;->max(II)I

    move-result p4

    iget-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->CqaNbM:[I

    aget v0, v0, v2

    invoke-static {v1, v0}, Ljava/lang/Math;->max(II)I

    move-result v0

    if-ne p1, v2, :cond_0

    move v1, v2

    :cond_0
    iget-object p1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->diqgf:Landroidx/recyclerview/widget/LinearLayoutManager$wA;

    if-eqz v1, :cond_1

    move v3, v0

    goto :goto_0

    :cond_1
    move v3, p4

    :goto_0
    iput v3, p1, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->lgHUyS:I

    if-eqz v1, :cond_2

    goto :goto_1

    :cond_2
    move p4, v0

    :goto_1
    iput p4, p1, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->qdMbNW:I

    const/4 p4, -0x1

    if-eqz v1, :cond_4

    iget-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v0}, Landroidx/recyclerview/widget/qdMbNW;->Dt()I

    move-result v0

    add-int/2addr v3, v0

    iput v3, p1, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->lgHUyS:I

    invoke-virtual {p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->oJ()Landroid/view/View;

    move-result-object p1

    iget-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->diqgf:Landroidx/recyclerview/widget/LinearLayoutManager$wA;

    iget-boolean v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->Gd:Z

    if-eqz v1, :cond_3

    move v2, p4

    :cond_3
    iput v2, v0, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->KLFTb:I

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/RecyclerView$qGY;->tQ(Landroid/view/View;)I

    move-result p4

    iget-object v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->diqgf:Landroidx/recyclerview/widget/LinearLayoutManager$wA;

    iget v2, v1, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->KLFTb:I

    add-int/2addr p4, v2

    iput p4, v0, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->ZfxDd:I

    iget-object p4, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {p4, p1}, Landroidx/recyclerview/widget/qdMbNW;->ZfxDd(Landroid/view/View;)I

    move-result p4

    iput p4, v1, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->AZxh:I

    iget-object p4, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {p4, p1}, Landroidx/recyclerview/widget/qdMbNW;->ZfxDd(Landroid/view/View;)I

    move-result p1

    iget-object p4, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {p4}, Landroidx/recyclerview/widget/qdMbNW;->qdMbNW()I

    move-result p4

    sub-int/2addr p1, p4

    goto :goto_3

    :cond_4
    invoke-virtual {p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->bWIyu()Landroid/view/View;

    move-result-object p1

    iget-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->diqgf:Landroidx/recyclerview/widget/LinearLayoutManager$wA;

    iget v1, v0, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->lgHUyS:I

    iget-object v3, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v3}, Landroidx/recyclerview/widget/qdMbNW;->MiMN()I

    move-result v3

    add-int/2addr v1, v3

    iput v1, v0, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->lgHUyS:I

    iget-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->diqgf:Landroidx/recyclerview/widget/LinearLayoutManager$wA;

    iget-boolean v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->Gd:Z

    if-eqz v1, :cond_5

    goto :goto_2

    :cond_5
    move v2, p4

    :goto_2
    iput v2, v0, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->KLFTb:I

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/RecyclerView$qGY;->tQ(Landroid/view/View;)I

    move-result p4

    iget-object v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->diqgf:Landroidx/recyclerview/widget/LinearLayoutManager$wA;

    iget v2, v1, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->KLFTb:I

    add-int/2addr p4, v2

    iput p4, v0, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->ZfxDd:I

    iget-object p4, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {p4, p1}, Landroidx/recyclerview/widget/qdMbNW;->xJ(Landroid/view/View;)I

    move-result p4

    iput p4, v1, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->AZxh:I

    iget-object p4, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {p4, p1}, Landroidx/recyclerview/widget/qdMbNW;->xJ(Landroid/view/View;)I

    move-result p1

    neg-int p1, p1

    iget-object p4, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {p4}, Landroidx/recyclerview/widget/qdMbNW;->MiMN()I

    move-result p4

    add-int/2addr p1, p4

    :goto_3
    iget-object p0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->diqgf:Landroidx/recyclerview/widget/LinearLayoutManager$wA;

    iput p2, p0, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->wA:I

    if-eqz p3, :cond_6

    sub-int/2addr p2, p1

    iput p2, p0, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->wA:I

    :cond_6
    iput p1, p0, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->xJ:I

    return-void
.end method

.method public kism()Z
    .locals 0

    const/4 p0, 0x1

    return p0
.end method

.method public lgHUyS(Ljava/lang/String;)V
    .locals 1

    iget-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->wJVbdd:Landroidx/recyclerview/widget/LinearLayoutManager$ZfxDd;

    if-nez v0, :cond_0

    invoke-super {p0, p1}, Landroidx/recyclerview/widget/RecyclerView$qGY;->lgHUyS(Ljava/lang/String;)V

    :cond_0
    return-void
.end method

.method public mByQ()Landroidx/recyclerview/widget/RecyclerView$fehf;
    .locals 1

    new-instance p0, Landroidx/recyclerview/widget/RecyclerView$fehf;

    const/4 v0, -0x2

    invoke-direct {p0, v0, v0}, Landroidx/recyclerview/widget/RecyclerView$fehf;-><init>(II)V

    return-object p0
.end method

.method public mPWV(Landroid/os/Parcelable;)V
    .locals 2

    instance-of v0, p1, Landroidx/recyclerview/widget/LinearLayoutManager$ZfxDd;

    if-eqz v0, :cond_1

    check-cast p1, Landroidx/recyclerview/widget/LinearLayoutManager$ZfxDd;

    iput-object p1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->wJVbdd:Landroidx/recyclerview/widget/LinearLayoutManager$ZfxDd;

    iget v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->VocHEe:I

    const/4 v1, -0x1

    if-eq v0, v1, :cond_0

    invoke-virtual {p1}, Landroidx/recyclerview/widget/LinearLayoutManager$ZfxDd;->AZxh()V

    :cond_0
    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->mzUGzO()V

    :cond_1
    return-void
.end method

.method public final np(Landroidx/recyclerview/widget/RecyclerView$VocHEe;)I
    .locals 6

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->zvd()I

    move-result v0

    if-nez v0, :cond_0

    const/4 p0, 0x0

    return p0

    :cond_0
    invoke-virtual {p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->qrxT()V

    iget-object v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    iget-boolean v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->vI:Z

    const/4 v2, 0x1

    xor-int/2addr v0, v2

    invoke-virtual {p0, v0, v2}, Landroidx/recyclerview/widget/LinearLayoutManager;->xbjHT(ZZ)Landroid/view/View;

    move-result-object v3

    iget-boolean v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->vI:Z

    xor-int/2addr v0, v2

    invoke-virtual {p0, v0, v2}, Landroidx/recyclerview/widget/LinearLayoutManager;->EoC(ZZ)Landroid/view/View;

    move-result-object v4

    iget-boolean v5, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->vI:Z

    move-object v0, p1

    move-object v2, v3

    move-object v3, v4

    move-object v4, p0

    invoke-static/range {v0 .. v5}, Landroidx/recyclerview/widget/VA;->mjFkc(Landroidx/recyclerview/widget/RecyclerView$VocHEe;Landroidx/recyclerview/widget/qdMbNW;Landroid/view/View;Landroid/view/View;Landroidx/recyclerview/widget/RecyclerView$qGY;Z)I

    move-result p0

    return p0
.end method

.method public final oJ()Landroid/view/View;
    .locals 1

    iget-boolean v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->Gd:Z

    if-eqz v0, :cond_0

    const/4 v0, 0x0

    goto :goto_0

    :cond_0
    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->zvd()I

    move-result v0

    add-int/lit8 v0, v0, -0x1

    :goto_0
    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->KLMXS(I)Landroid/view/View;

    move-result-object p0

    return-object p0
.end method

.method public pJeaSR(Landroidx/recyclerview/widget/RecyclerView$VocHEe;Landroidx/recyclerview/widget/LinearLayoutManager$wA;Landroidx/recyclerview/widget/RecyclerView$qGY$wA;)V
    .locals 0

    iget p0, p2, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->ZfxDd:I

    if-ltz p0, :cond_0

    invoke-virtual {p1}, Landroidx/recyclerview/widget/RecyclerView$VocHEe;->AZxh()I

    move-result p1

    if-ge p0, p1, :cond_0

    const/4 p1, 0x0

    iget p2, p2, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->xJ:I

    invoke-static {p1, p2}, Ljava/lang/Math;->max(II)I

    move-result p1

    invoke-interface {p3, p0, p1}, Landroidx/recyclerview/widget/RecyclerView$qGY$wA;->mjFkc(II)V

    :cond_0
    return-void
.end method

.method public final peCqC(Landroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;II)V
    .locals 10

    invoke-virtual {p2}, Landroidx/recyclerview/widget/RecyclerView$VocHEe;->xJ()Z

    move-result v0

    if-eqz v0, :cond_7

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->zvd()I

    move-result v0

    if-eqz v0, :cond_7

    invoke-virtual {p2}, Landroidx/recyclerview/widget/RecyclerView$VocHEe;->KLFTb()Z

    move-result v0

    if-nez v0, :cond_7

    invoke-virtual {p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->ERt()Z

    move-result v0

    if-nez v0, :cond_0

    goto/16 :goto_3

    :cond_0
    invoke-virtual {p1}, Landroidx/recyclerview/widget/RecyclerView$Ucbh;->ETF()Ljava/util/List;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v1

    const/4 v2, 0x0

    invoke-virtual {p0, v2}, Landroidx/recyclerview/widget/RecyclerView$qGY;->KLMXS(I)Landroid/view/View;

    move-result-object v3

    invoke-virtual {p0, v3}, Landroidx/recyclerview/widget/RecyclerView$qGY;->tQ(Landroid/view/View;)I

    move-result v3

    move v4, v2

    move v5, v4

    move v6, v5

    :goto_0
    if-ge v4, v1, :cond_4

    invoke-interface {v0, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Landroidx/recyclerview/widget/RecyclerView$mByQ;

    invoke-virtual {v7}, Landroidx/recyclerview/widget/RecyclerView$mByQ;->Ucbh()Z

    move-result v8

    if-eqz v8, :cond_1

    goto :goto_2

    :cond_1
    invoke-virtual {v7}, Landroidx/recyclerview/widget/RecyclerView$mByQ;->MiMN()I

    move-result v8

    if-ge v8, v3, :cond_2

    const/4 v8, 0x1

    goto :goto_1

    :cond_2
    move v8, v2

    :goto_1
    iget-boolean v9, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->Gd:Z

    if-eq v8, v9, :cond_3

    iget-object v8, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    iget-object v7, v7, Landroidx/recyclerview/widget/RecyclerView$mByQ;->mjFkc:Landroid/view/View;

    invoke-virtual {v8, v7}, Landroidx/recyclerview/widget/qdMbNW;->KLFTb(Landroid/view/View;)I

    move-result v7

    add-int/2addr v5, v7

    goto :goto_2

    :cond_3
    iget-object v8, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    iget-object v7, v7, Landroidx/recyclerview/widget/RecyclerView$mByQ;->mjFkc:Landroid/view/View;

    invoke-virtual {v8, v7}, Landroidx/recyclerview/widget/qdMbNW;->KLFTb(Landroid/view/View;)I

    move-result v7

    add-int/2addr v6, v7

    :goto_2
    add-int/lit8 v4, v4, 0x1

    goto :goto_0

    :cond_4
    iget-object v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->diqgf:Landroidx/recyclerview/widget/LinearLayoutManager$wA;

    iput-object v0, v1, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->VA:Ljava/util/List;

    if-lez v5, :cond_5

    invoke-virtual {p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->bWIyu()Landroid/view/View;

    move-result-object v0

    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->tQ(Landroid/view/View;)I

    move-result v0

    invoke-virtual {p0, v0, p3}, Landroidx/recyclerview/widget/LinearLayoutManager;->ZGL(II)V

    iget-object p3, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->diqgf:Landroidx/recyclerview/widget/LinearLayoutManager$wA;

    iput v5, p3, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->lgHUyS:I

    iput v2, p3, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->wA:I

    invoke-virtual {p3}, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->mjFkc()V

    iget-object p3, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->diqgf:Landroidx/recyclerview/widget/LinearLayoutManager$wA;

    invoke-virtual {p0, p1, p3, p2, v2}, Landroidx/recyclerview/widget/LinearLayoutManager;->CcoH(Landroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/LinearLayoutManager$wA;Landroidx/recyclerview/widget/RecyclerView$VocHEe;Z)I

    :cond_5
    if-lez v6, :cond_6

    invoke-virtual {p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->oJ()Landroid/view/View;

    move-result-object p3

    invoke-virtual {p0, p3}, Landroidx/recyclerview/widget/RecyclerView$qGY;->tQ(Landroid/view/View;)I

    move-result p3

    invoke-virtual {p0, p3, p4}, Landroidx/recyclerview/widget/LinearLayoutManager;->LlB(II)V

    iget-object p3, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->diqgf:Landroidx/recyclerview/widget/LinearLayoutManager$wA;

    iput v6, p3, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->lgHUyS:I

    iput v2, p3, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->wA:I

    invoke-virtual {p3}, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->mjFkc()V

    iget-object p3, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->diqgf:Landroidx/recyclerview/widget/LinearLayoutManager$wA;

    invoke-virtual {p0, p1, p3, p2, v2}, Landroidx/recyclerview/widget/LinearLayoutManager;->CcoH(Landroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/LinearLayoutManager$wA;Landroidx/recyclerview/widget/RecyclerView$VocHEe;Z)I

    :cond_6
    iget-object p0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->diqgf:Landroidx/recyclerview/widget/LinearLayoutManager$wA;

    const/4 p1, 0x0

    iput-object p1, p0, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->VA:Ljava/util/List;

    :cond_7
    :goto_3
    return-void
.end method

.method public qGY(IILandroidx/recyclerview/widget/RecyclerView$VocHEe;Landroidx/recyclerview/widget/RecyclerView$qGY$wA;)V
    .locals 1

    iget v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->Pq:I

    if-nez v0, :cond_0

    goto :goto_0

    :cond_0
    move p1, p2

    :goto_0
    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->zvd()I

    move-result p2

    if-eqz p2, :cond_3

    if-nez p1, :cond_1

    goto :goto_2

    :cond_1
    invoke-virtual {p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->qrxT()V

    const/4 p2, 0x1

    if-lez p1, :cond_2

    move v0, p2

    goto :goto_1

    :cond_2
    const/4 v0, -0x1

    :goto_1
    invoke-static {p1}, Ljava/lang/Math;->abs(I)I

    move-result p1

    invoke-virtual {p0, v0, p1, p2, p3}, Landroidx/recyclerview/widget/LinearLayoutManager;->kOlLW(IIZLandroidx/recyclerview/widget/RecyclerView$VocHEe;)V

    iget-object p1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->diqgf:Landroidx/recyclerview/widget/LinearLayoutManager$wA;

    invoke-virtual {p0, p3, p1, p4}, Landroidx/recyclerview/widget/LinearLayoutManager;->pJeaSR(Landroidx/recyclerview/widget/RecyclerView$VocHEe;Landroidx/recyclerview/widget/LinearLayoutManager$wA;Landroidx/recyclerview/widget/RecyclerView$qGY$wA;)V

    :cond_3
    :goto_2
    return-void
.end method

.method public qGgY(Landroidx/recyclerview/widget/RecyclerView;Landroidx/recyclerview/widget/RecyclerView$VocHEe;I)V
    .locals 0

    new-instance p2, Landroidx/recyclerview/widget/xJ;

    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p1

    invoke-direct {p2, p1}, Landroidx/recyclerview/widget/xJ;-><init>(Landroid/content/Context;)V

    invoke-virtual {p2, p3}, Landroidx/recyclerview/widget/RecyclerView$vI;->qGY(I)V

    invoke-virtual {p0, p2}, Landroidx/recyclerview/widget/RecyclerView$qGY;->vUsV(Landroidx/recyclerview/widget/RecyclerView$vI;)V

    return-void
.end method

.method public qrxT()V
    .locals 1

    iget-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->diqgf:Landroidx/recyclerview/widget/LinearLayoutManager$wA;

    if-nez v0, :cond_0

    invoke-virtual {p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->Vptz()Landroidx/recyclerview/widget/LinearLayoutManager$wA;

    move-result-object v0

    iput-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->diqgf:Landroidx/recyclerview/widget/LinearLayoutManager$wA;

    :cond_0
    return-void
.end method

.method public final tPvjn(Landroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/LinearLayoutManager$wA;)V
    .locals 3

    iget-boolean v0, p2, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->mjFkc:Z

    if-eqz v0, :cond_2

    iget-boolean v0, p2, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->MiMN:Z

    if-eqz v0, :cond_0

    goto :goto_0

    :cond_0
    iget v0, p2, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->xJ:I

    iget v1, p2, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->qdMbNW:I

    iget p2, p2, Landroidx/recyclerview/widget/LinearLayoutManager$wA;->JHa:I

    const/4 v2, -0x1

    if-ne p2, v2, :cond_1

    invoke-virtual {p0, p1, v0, v1}, Landroidx/recyclerview/widget/LinearLayoutManager;->Otxclu(Landroidx/recyclerview/widget/RecyclerView$Ucbh;II)V

    goto :goto_0

    :cond_1
    invoke-virtual {p0, p1, v0, v1}, Landroidx/recyclerview/widget/LinearLayoutManager;->OzIs(Landroidx/recyclerview/widget/RecyclerView$Ucbh;II)V

    :cond_2
    :goto_0
    return-void
.end method

.method public ui()Z
    .locals 2

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->JrJO()I

    move-result v0

    const/high16 v1, 0x40000000    # 2.0f

    if-eq v0, v1, :cond_0

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->Qr()I

    move-result v0

    if-eq v0, v1, :cond_0

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->NKyg()Z

    move-result p0

    if-eqz p0, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method

.method public vZ(II)Landroid/view/View;
    .locals 3

    invoke-virtual {p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->qrxT()V

    if-le p2, p1, :cond_0

    goto :goto_0

    :cond_0
    if-ge p2, p1, :cond_3

    :goto_0
    iget-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/RecyclerView$qGY;->KLMXS(I)Landroid/view/View;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroidx/recyclerview/widget/qdMbNW;->xJ(Landroid/view/View;)I

    move-result v0

    iget-object v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v1}, Landroidx/recyclerview/widget/qdMbNW;->MiMN()I

    move-result v1

    if-ge v0, v1, :cond_1

    const/16 v0, 0x4104

    const/16 v1, 0x4004

    goto :goto_1

    :cond_1
    const/16 v0, 0x1041

    const/16 v1, 0x1001

    :goto_1
    iget v2, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->Pq:I

    if-nez v2, :cond_2

    iget-object p0, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->KLFTb:Landroidx/recyclerview/widget/rkYL;

    invoke-virtual {p0, p1, p2, v0, v1}, Landroidx/recyclerview/widget/rkYL;->mjFkc(IIII)Landroid/view/View;

    move-result-object p0

    goto :goto_2

    :cond_2
    iget-object p0, p0, Landroidx/recyclerview/widget/RecyclerView$qGY;->JHa:Landroidx/recyclerview/widget/rkYL;

    invoke-virtual {p0, p1, p2, v0, v1}, Landroidx/recyclerview/widget/rkYL;->mjFkc(IIII)Landroid/view/View;

    move-result-object p0

    :goto_2
    return-object p0

    :cond_3
    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/RecyclerView$qGY;->KLMXS(I)Landroid/view/View;

    move-result-object p0

    return-object p0
.end method

.method public wGscSa(Landroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;Landroidx/recyclerview/widget/LinearLayoutManager$mjFkc;I)V
    .locals 0

    return-void
.end method

.method public wJVbdd(I)Landroid/view/View;
    .locals 2

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->zvd()I

    move-result v0

    if-nez v0, :cond_0

    const/4 p0, 0x0

    return-object p0

    :cond_0
    const/4 v1, 0x0

    invoke-virtual {p0, v1}, Landroidx/recyclerview/widget/RecyclerView$qGY;->KLMXS(I)Landroid/view/View;

    move-result-object v1

    invoke-virtual {p0, v1}, Landroidx/recyclerview/widget/RecyclerView$qGY;->tQ(Landroid/view/View;)I

    move-result v1

    sub-int v1, p1, v1

    if-ltz v1, :cond_1

    if-ge v1, v0, :cond_1

    invoke-virtual {p0, v1}, Landroidx/recyclerview/widget/RecyclerView$qGY;->KLMXS(I)Landroid/view/View;

    move-result-object v0

    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->tQ(Landroid/view/View;)I

    move-result v1

    if-ne v1, p1, :cond_1

    return-object v0

    :cond_1
    invoke-super {p0, p1}, Landroidx/recyclerview/widget/RecyclerView$qGY;->wJVbdd(I)Landroid/view/View;

    move-result-object p0

    return-object p0
.end method

.method public xBQUgd(Z)V
    .locals 1

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/LinearLayoutManager;->lgHUyS(Ljava/lang/String;)V

    iget-boolean v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->HGpJ:Z

    if-ne v0, p1, :cond_0

    return-void

    :cond_0
    iput-boolean p1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->HGpJ:Z

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->mzUGzO()V

    return-void
.end method

.method public xbjHT(ZZ)Landroid/view/View;
    .locals 2

    iget-boolean v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->Gd:Z

    if-eqz v0, :cond_0

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->zvd()I

    move-result v0

    add-int/lit8 v0, v0, -0x1

    const/4 v1, -0x1

    invoke-virtual {p0, v0, v1, p1, p2}, Landroidx/recyclerview/widget/LinearLayoutManager;->TvfBiy(IIZZ)Landroid/view/View;

    move-result-object p0

    return-object p0

    :cond_0
    const/4 v0, 0x0

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->zvd()I

    move-result v1

    invoke-virtual {p0, v0, v1, p1, p2}, Landroidx/recyclerview/widget/LinearLayoutManager;->TvfBiy(IIZZ)Landroid/view/View;

    move-result-object p0

    return-object p0
.end method

.method public xfXeiC(Landroidx/recyclerview/widget/RecyclerView$Ucbh;Landroidx/recyclerview/widget/RecyclerView$VocHEe;ZZ)Landroid/view/View;
    .locals 16

    move-object/from16 v0, p0

    invoke-virtual/range {p0 .. p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->qrxT()V

    invoke-virtual/range {p0 .. p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->zvd()I

    move-result v1

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-eqz p4, :cond_0

    invoke-virtual/range {p0 .. p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->zvd()I

    move-result v1

    sub-int/2addr v1, v3

    const/4 v4, -0x1

    move v5, v4

    goto :goto_0

    :cond_0
    move v4, v1

    move v1, v2

    move v5, v3

    :goto_0
    invoke-virtual/range {p2 .. p2}, Landroidx/recyclerview/widget/RecyclerView$VocHEe;->AZxh()I

    move-result v6

    iget-object v7, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v7}, Landroidx/recyclerview/widget/qdMbNW;->MiMN()I

    move-result v7

    iget-object v8, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v8}, Landroidx/recyclerview/widget/qdMbNW;->qdMbNW()I

    move-result v8

    const/4 v9, 0x0

    move-object v10, v9

    move-object v11, v10

    :goto_1
    if-eq v1, v4, :cond_a

    invoke-virtual {v0, v1}, Landroidx/recyclerview/widget/RecyclerView$qGY;->KLMXS(I)Landroid/view/View;

    move-result-object v12

    invoke-virtual {v0, v12}, Landroidx/recyclerview/widget/RecyclerView$qGY;->tQ(Landroid/view/View;)I

    move-result v13

    iget-object v14, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v14, v12}, Landroidx/recyclerview/widget/qdMbNW;->xJ(Landroid/view/View;)I

    move-result v14

    iget-object v15, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->eyqo:Landroidx/recyclerview/widget/qdMbNW;

    invoke-virtual {v15, v12}, Landroidx/recyclerview/widget/qdMbNW;->ZfxDd(Landroid/view/View;)I

    move-result v15

    if-ltz v13, :cond_9

    if-ge v13, v6, :cond_9

    invoke-virtual {v12}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v13

    check-cast v13, Landroidx/recyclerview/widget/RecyclerView$fehf;

    invoke-virtual {v13}, Landroidx/recyclerview/widget/RecyclerView$fehf;->wA()Z

    move-result v13

    if-eqz v13, :cond_1

    if-nez v11, :cond_9

    move-object v11, v12

    goto :goto_7

    :cond_1
    if-gt v15, v7, :cond_2

    if-ge v14, v7, :cond_2

    move v13, v3

    goto :goto_2

    :cond_2
    move v13, v2

    :goto_2
    if-lt v14, v8, :cond_3

    if-le v15, v8, :cond_3

    move v14, v3

    goto :goto_3

    :cond_3
    move v14, v2

    :goto_3
    if-nez v13, :cond_5

    if-eqz v14, :cond_4

    goto :goto_4

    :cond_4
    return-object v12

    :cond_5
    :goto_4
    if-eqz p3, :cond_7

    if-eqz v14, :cond_6

    goto :goto_5

    :cond_6
    if-nez v9, :cond_9

    goto :goto_6

    :cond_7
    if-eqz v13, :cond_8

    :goto_5
    move-object v10, v12

    goto :goto_7

    :cond_8
    if-nez v9, :cond_9

    :goto_6
    move-object v9, v12

    :cond_9
    :goto_7
    add-int/2addr v1, v5

    goto :goto_1

    :cond_a
    if-eqz v9, :cond_b

    goto :goto_8

    :cond_b
    if-eqz v10, :cond_c

    move-object v9, v10

    goto :goto_8

    :cond_c
    move-object v9, v11

    :goto_8
    return-object v9
.end method

.method public zPp()I
    .locals 3

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->zvd()I

    move-result v0

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-virtual {p0, v2, v0, v2, v1}, Landroidx/recyclerview/widget/LinearLayoutManager;->TvfBiy(IIZZ)Landroid/view/View;

    move-result-object v0

    if-nez v0, :cond_0

    const/4 p0, -0x1

    goto :goto_0

    :cond_0
    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->tQ(Landroid/view/View;)I

    move-result p0

    :goto_0
    return p0
.end method
