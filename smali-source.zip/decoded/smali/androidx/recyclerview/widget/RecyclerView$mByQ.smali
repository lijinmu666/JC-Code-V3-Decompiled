.class public abstract Landroidx/recyclerview/widget/RecyclerView$mByQ;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/recyclerview/widget/RecyclerView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "mByQ"
.end annotation


# static fields
.field public static final diqgf:Ljava/util/List;


# instance fields
.field public AZxh:Ljava/lang/ref/WeakReference;

.field public Dt:I

.field public ETF:Ljava/util/List;

.field public IEE:Landroidx/recyclerview/widget/RecyclerView;

.field public JHa:I

.field public KLFTb:J

.field public MiMN:I

.field public Pq:Landroidx/recyclerview/widget/RecyclerView$lgHUyS;

.field public VA:Ljava/util/List;

.field public YoKzxo:Landroidx/recyclerview/widget/RecyclerView$Ucbh;

.field public ZfxDd:I

.field public fehf:I

.field public lgHUyS:Landroidx/recyclerview/widget/RecyclerView$mByQ;

.field public final mjFkc:Landroid/view/View;

.field public qGY:I

.field public qdMbNW:Landroidx/recyclerview/widget/RecyclerView$mByQ;

.field public rkYL:Z

.field public wA:I

.field public xJ:I


# direct methods
.method static constructor <clinit>()V
    .locals 1

    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v0

    sput-object v0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->diqgf:Ljava/util/List;

    return-void
.end method

.method public constructor <init>(Landroid/view/View;)V
    .locals 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, -0x1

    iput v0, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->wA:I

    iput v0, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->ZfxDd:I

    const-wide/16 v1, -0x1

    iput-wide v1, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->KLFTb:J

    iput v0, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->JHa:I

    iput v0, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->xJ:I

    const/4 v1, 0x0

    iput-object v1, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->lgHUyS:Landroidx/recyclerview/widget/RecyclerView$mByQ;

    iput-object v1, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->qdMbNW:Landroidx/recyclerview/widget/RecyclerView$mByQ;

    iput-object v1, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->ETF:Ljava/util/List;

    iput-object v1, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->VA:Ljava/util/List;

    const/4 v2, 0x0

    iput v2, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->MiMN:I

    iput-object v1, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->YoKzxo:Landroidx/recyclerview/widget/RecyclerView$Ucbh;

    iput-boolean v2, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->rkYL:Z

    iput v2, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->qGY:I

    iput v0, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->fehf:I

    if-eqz p1, :cond_0

    iput-object p1, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->mjFkc:Landroid/view/View;

    return-void

    :cond_0
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string p1, "itemView may not be null"

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0
.end method


# virtual methods
.method public AZxh(I)V
    .locals 1

    iget v0, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->Dt:I

    or-int/2addr p1, v0

    iput p1, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->Dt:I

    return-void
.end method

.method public BAnRFn(Landroidx/recyclerview/widget/RecyclerView;)V
    .locals 2

    iget v0, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->fehf:I

    const/4 v1, -0x1

    if-eq v0, v1, :cond_0

    iput v0, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->qGY:I

    goto :goto_0

    :cond_0
    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->mjFkc:Landroid/view/View;

    invoke-static {v0}, Lo/T9;->eyqo(Landroid/view/View;)I

    move-result v0

    iput v0, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->qGY:I

    :goto_0
    const/4 v0, 0x4

    invoke-virtual {p1, p0, v0}, Landroidx/recyclerview/widget/RecyclerView;->Vu(Landroidx/recyclerview/widget/RecyclerView$mByQ;I)Z

    return-void
.end method

.method public CqaNbM(Landroidx/recyclerview/widget/RecyclerView$Ucbh;Z)V
    .locals 0

    iput-object p1, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->YoKzxo:Landroidx/recyclerview/widget/RecyclerView$Ucbh;

    iput-boolean p2, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->rkYL:Z

    return-void
.end method

.method public final Dt()I
    .locals 1

    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->IEE:Landroidx/recyclerview/widget/RecyclerView;

    if-nez v0, :cond_0

    const/4 p0, -0x1

    return p0

    :cond_0
    invoke-virtual {v0, p0}, Landroidx/recyclerview/widget/RecyclerView;->Vdz(Landroidx/recyclerview/widget/RecyclerView$mByQ;)I

    move-result p0

    return p0
.end method

.method public final ETF()J
    .locals 2

    iget-wide v0, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->KLFTb:J

    return-wide v0
.end method

.method public Gd()Z
    .locals 0

    iget p0, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->Dt:I

    and-int/lit16 p0, p0, 0x100

    if-eqz p0, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method

.method public HGpJ()Z
    .locals 0

    iget p0, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->Dt:I

    and-int/lit8 p0, p0, 0x2

    if-eqz p0, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method

.method public IEE()Z
    .locals 1

    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->mjFkc:Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->mjFkc:Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    iget-object p0, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->IEE:Landroidx/recyclerview/widget/RecyclerView;

    if-eq v0, p0, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method

.method public JHa()V
    .locals 1

    iget v0, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->Dt:I

    and-int/lit16 v0, v0, -0x101

    iput v0, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->Dt:I

    return-void
.end method

.method public KLFTb()V
    .locals 1

    iget v0, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->Dt:I

    and-int/lit8 v0, v0, -0x21

    iput v0, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->Dt:I

    return-void
.end method

.method public KLMXS()Z
    .locals 0

    iget p0, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->Dt:I

    and-int/lit16 p0, p0, 0x80

    if-eqz p0, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method

.method public final MiMN()I
    .locals 2

    iget v0, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->xJ:I

    const/4 v1, -0x1

    if-ne v0, v1, :cond_0

    iget v0, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->wA:I

    :cond_0
    return v0
.end method

.method public final Ne(Z)V
    .locals 2

    const/4 v0, 0x1

    iget v1, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->MiMN:I

    if-eqz p1, :cond_0

    sub-int/2addr v1, v0

    goto :goto_0

    :cond_0
    add-int/2addr v1, v0

    :goto_0
    iput v1, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->MiMN:I

    if-gez v1, :cond_2

    const/4 v0, 0x0

    iput v0, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->MiMN:I

    sget-boolean v0, Landroidx/recyclerview/widget/RecyclerView;->gYa:Z

    const-string v1, "isRecyclable decremented below 0: unmatched pair of setIsRecyable() calls for "

    if-nez v0, :cond_1

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "View"

    invoke-static {v1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_1

    :cond_1
    new-instance p1, Ljava/lang/RuntimeException;

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {p1, p0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_2
    if-nez p1, :cond_3

    if-ne v1, v0, :cond_3

    iget v0, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->Dt:I

    or-int/lit8 v0, v0, 0x10

    iput v0, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->Dt:I

    goto :goto_1

    :cond_3
    if-eqz p1, :cond_4

    if-nez v1, :cond_4

    iget v0, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->Dt:I

    and-int/lit8 v0, v0, -0x11

    iput v0, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->Dt:I

    :cond_4
    :goto_1
    sget-boolean v0, Landroidx/recyclerview/widget/RecyclerView;->LREOK:Z

    if-eqz v0, :cond_5

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "setIsRecyclable val:"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const-string p1, ":"

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const-string p1, "RecyclerView"

    invoke-static {p1, p0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    :cond_5
    return-void
.end method

.method public OjSQV(II)V
    .locals 2

    iget v0, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->Dt:I

    not-int v1, p2

    and-int/2addr v0, v1

    and-int/2addr p1, p2

    or-int/2addr p1, v0

    iput p1, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->Dt:I

    return-void
.end method

.method public Pq()Z
    .locals 1

    iget p0, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->Dt:I

    const/4 v0, 0x1

    and-int/2addr p0, v0

    if-eqz p0, :cond_0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public Ucbh()Z
    .locals 0

    iget p0, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->Dt:I

    and-int/lit8 p0, p0, 0x8

    if-eqz p0, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method

.method public final VA()I
    .locals 0

    iget p0, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->JHa:I

    return p0
.end method

.method public VocHEe(IZ)V
    .locals 2

    iget v0, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->ZfxDd:I

    const/4 v1, -0x1

    if-ne v0, v1, :cond_0

    iget v0, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->wA:I

    iput v0, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->ZfxDd:I

    :cond_0
    iget v0, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->xJ:I

    if-ne v0, v1, :cond_1

    iget v0, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->wA:I

    iput v0, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->xJ:I

    :cond_1
    if-eqz p2, :cond_2

    iget p2, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->xJ:I

    add-int/2addr p2, p1

    iput p2, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->xJ:I

    :cond_2
    iget p2, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->wA:I

    add-int/2addr p2, p1

    iput p2, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->wA:I

    iget-object p1, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->mjFkc:Landroid/view/View;

    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object p1

    if-eqz p1, :cond_3

    iget-object p0, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->mjFkc:Landroid/view/View;

    invoke-virtual {p0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object p0

    check-cast p0, Landroidx/recyclerview/widget/RecyclerView$fehf;

    const/4 p1, 0x1

    iput-boolean p1, p0, Landroidx/recyclerview/widget/RecyclerView$fehf;->wA:Z

    :cond_3
    return-void
.end method

.method public final YoKzxo()I
    .locals 0

    iget p0, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->ZfxDd:I

    return p0
.end method

.method public ZfxDd()V
    .locals 1

    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->ETF:Ljava/util/List;

    if-eqz v0, :cond_0

    invoke-interface {v0}, Ljava/util/List;->clear()V

    :cond_0
    iget v0, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->Dt:I

    and-int/lit16 v0, v0, -0x401

    iput v0, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->Dt:I

    return-void
.end method

.method public cMLeY()Z
    .locals 0

    iget p0, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->Dt:I

    and-int/lit8 p0, p0, 0x20

    if-eqz p0, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method

.method public diqgf()Z
    .locals 0

    iget p0, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->Dt:I

    and-int/lit8 p0, p0, 0x4

    if-eqz p0, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method

.method public final eyqo()Z
    .locals 1

    iget v0, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->Dt:I

    and-int/lit8 v0, v0, 0x10

    if-nez v0, :cond_0

    iget-object p0, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->mjFkc:Landroid/view/View;

    invoke-static {p0}, Lo/T9;->KLMXS(Landroid/view/View;)Z

    move-result p0

    if-nez p0, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method

.method public fehf()Z
    .locals 1

    iget v0, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->Dt:I

    and-int/lit16 v0, v0, 0x200

    if-nez v0, :cond_1

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$mByQ;->diqgf()Z

    move-result p0

    if-eqz p0, :cond_0

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    goto :goto_1

    :cond_1
    :goto_0
    const/4 p0, 0x1

    :goto_1
    return p0
.end method

.method public huTpC()Z
    .locals 0

    iget-object p0, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->YoKzxo:Landroidx/recyclerview/widget/RecyclerView$Ucbh;

    if-eqz p0, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method

.method public lB(Landroidx/recyclerview/widget/RecyclerView;)V
    .locals 1

    iget v0, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->qGY:I

    invoke-virtual {p1, p0, v0}, Landroidx/recyclerview/widget/RecyclerView;->Vu(Landroidx/recyclerview/widget/RecyclerView$mByQ;I)Z

    const/4 p1, 0x0

    iput p1, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->qGY:I

    return-void
.end method

.method public lgHUyS()Z
    .locals 1

    iget v0, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->Dt:I

    and-int/lit8 v0, v0, 0x10

    if-nez v0, :cond_0

    iget-object p0, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->mjFkc:Landroid/view/View;

    invoke-static {p0}, Lo/T9;->KLMXS(Landroid/view/View;)Z

    move-result p0

    if-eqz p0, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method

.method public mByQ()V
    .locals 2

    iget v0, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->ZfxDd:I

    const/4 v1, -0x1

    if-ne v0, v1, :cond_0

    iget v0, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->wA:I

    iput v0, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->ZfxDd:I

    :cond_0
    return-void
.end method

.method public mjFkc(Ljava/lang/Object;)V
    .locals 2

    const/16 v0, 0x400

    if-nez p1, :cond_0

    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/RecyclerView$mByQ;->AZxh(I)V

    goto :goto_0

    :cond_0
    iget v1, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->Dt:I

    and-int/2addr v0, v1

    if-nez v0, :cond_1

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$mByQ;->xJ()V

    iget-object p0, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->ETF:Ljava/util/List;

    invoke-interface {p0, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_1
    :goto_0
    return-void
.end method

.method public qGY(I)Z
    .locals 0

    iget p0, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->Dt:I

    and-int/2addr p0, p1

    if-eqz p0, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method

.method public qdMbNW(IIZ)V
    .locals 1

    const/16 v0, 0x8

    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/RecyclerView$mByQ;->AZxh(I)V

    invoke-virtual {p0, p2, p3}, Landroidx/recyclerview/widget/RecyclerView$mByQ;->VocHEe(IZ)V

    iput p1, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->wA:I

    return-void
.end method

.method public rkYL()Ljava/util/List;
    .locals 1

    iget v0, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->Dt:I

    and-int/lit16 v0, v0, 0x400

    if-nez v0, :cond_2

    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->ETF:Ljava/util/List;

    if-eqz v0, :cond_1

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    if-nez v0, :cond_0

    goto :goto_0

    :cond_0
    iget-object p0, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->VA:Ljava/util/List;

    return-object p0

    :cond_1
    :goto_0
    sget-object p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->diqgf:Ljava/util/List;

    return-object p0

    :cond_2
    sget-object p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->diqgf:Ljava/util/List;

    return-object p0
.end method

.method public toString()Ljava/lang/String;
    .locals 5

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Class;->isAnonymousClass()Z

    move-result v0

    if-eqz v0, :cond_0

    const-string v0, "ViewHolder"

    goto :goto_0

    :cond_0
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v0

    :goto_0
    new-instance v1, Ljava/lang/StringBuilder;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, "{"

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    invoke-static {v0}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, " position="

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v0, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->wA:I

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v0, " id="

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-wide v3, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->KLFTb:J

    invoke-virtual {v2, v3, v4}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v0, ", oldPos="

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v0, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->ZfxDd:I

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v0, ", pLpos:"

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v0, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->xJ:I

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v1, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$mByQ;->huTpC()Z

    move-result v0

    if-eqz v0, :cond_2

    const-string v0, " scrap "

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-boolean v0, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->rkYL:Z

    if-eqz v0, :cond_1

    const-string v0, "[changeScrap]"

    goto :goto_1

    :cond_1
    const-string v0, "[attachedScrap]"

    :goto_1
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_2
    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$mByQ;->diqgf()Z

    move-result v0

    if-eqz v0, :cond_3

    const-string v0, " invalid"

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_3
    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$mByQ;->Pq()Z

    move-result v0

    if-nez v0, :cond_4

    const-string v0, " unbound"

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_4
    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$mByQ;->vI()Z

    move-result v0

    if-eqz v0, :cond_5

    const-string v0, " update"

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_5
    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$mByQ;->Ucbh()Z

    move-result v0

    if-eqz v0, :cond_6

    const-string v0, " removed"

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_6
    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$mByQ;->KLMXS()Z

    move-result v0

    if-eqz v0, :cond_7

    const-string v0, " ignored"

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_7
    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$mByQ;->Gd()Z

    move-result v0

    if-eqz v0, :cond_8

    const-string v0, " tmpDetached"

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_8
    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$mByQ;->eyqo()Z

    move-result v0

    if-nez v0, :cond_9

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, " not recyclable("

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v2, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->MiMN:I

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, ")"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_9
    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$mByQ;->fehf()Z

    move-result v0

    if-eqz v0, :cond_a

    const-string v0, " undefined adapter position"

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_a
    iget-object p0, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->mjFkc:Landroid/view/View;

    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object p0

    if-nez p0, :cond_b

    const-string p0, " no parent"

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_b
    const-string p0, "}"

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public vI()Z
    .locals 0

    iget p0, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->Dt:I

    and-int/lit8 p0, p0, 0x2

    if-eqz p0, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method

.method public wA()V
    .locals 1

    const/4 v0, -0x1

    iput v0, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->ZfxDd:I

    iput v0, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->xJ:I

    return-void
.end method

.method public wJVbdd()V
    .locals 4

    sget-boolean v0, Landroidx/recyclerview/widget/RecyclerView;->gYa:Z

    if-eqz v0, :cond_1

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$mByQ;->Gd()Z

    move-result v0

    if-nez v0, :cond_0

    goto :goto_0

    :cond_0
    new-instance v0, Ljava/lang/IllegalStateException;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "Attempting to reset temp-detached ViewHolder: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p0, ". ViewHolders should be fully detached before resetting."

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_1
    :goto_0
    const/4 v0, 0x0

    iput v0, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->Dt:I

    const/4 v1, -0x1

    iput v1, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->wA:I

    iput v1, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->ZfxDd:I

    const-wide/16 v2, -0x1

    iput-wide v2, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->KLFTb:J

    iput v1, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->xJ:I

    iput v0, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->MiMN:I

    const/4 v2, 0x0

    iput-object v2, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->lgHUyS:Landroidx/recyclerview/widget/RecyclerView$mByQ;

    iput-object v2, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->qdMbNW:Landroidx/recyclerview/widget/RecyclerView$mByQ;

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$mByQ;->ZfxDd()V

    iput v0, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->qGY:I

    iput v1, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->fehf:I

    invoke-static {p0}, Landroidx/recyclerview/widget/RecyclerView;->Pq(Landroidx/recyclerview/widget/RecyclerView$mByQ;)V

    return-void
.end method

.method public final xJ()V
    .locals 1

    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->ETF:Ljava/util/List;

    if-nez v0, :cond_0

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->ETF:Ljava/util/List;

    invoke-static {v0}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object v0

    iput-object v0, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->VA:Ljava/util/List;

    :cond_0
    return-void
.end method

.method public xrEuO()Z
    .locals 0

    iget p0, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->Dt:I

    and-int/lit8 p0, p0, 0x10

    if-eqz p0, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method

.method public zvd()V
    .locals 1

    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView$mByQ;->YoKzxo:Landroidx/recyclerview/widget/RecyclerView$Ucbh;

    invoke-virtual {v0, p0}, Landroidx/recyclerview/widget/RecyclerView$Ucbh;->NPj(Landroidx/recyclerview/widget/RecyclerView$mByQ;)V

    return-void
.end method
