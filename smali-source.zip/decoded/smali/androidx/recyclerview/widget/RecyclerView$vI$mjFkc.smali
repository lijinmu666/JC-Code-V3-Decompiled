.class public Landroidx/recyclerview/widget/RecyclerView$vI$mjFkc;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/recyclerview/widget/RecyclerView$vI;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "mjFkc"
.end annotation


# instance fields
.field public AZxh:I

.field public JHa:Z

.field public KLFTb:Landroid/view/animation/Interpolator;

.field public ZfxDd:I

.field public mjFkc:I

.field public wA:I

.field public xJ:I


# direct methods
.method public constructor <init>(II)V
    .locals 2

    const/high16 v0, -0x80000000

    const/4 v1, 0x0

    .line 1
    invoke-direct {p0, p1, p2, v0, v1}, Landroidx/recyclerview/widget/RecyclerView$vI$mjFkc;-><init>(IIILandroid/view/animation/Interpolator;)V

    return-void
.end method

.method public constructor <init>(IIILandroid/view/animation/Interpolator;)V
    .locals 1

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, -0x1

    .line 3
    iput v0, p0, Landroidx/recyclerview/widget/RecyclerView$vI$mjFkc;->ZfxDd:I

    const/4 v0, 0x0

    .line 4
    iput-boolean v0, p0, Landroidx/recyclerview/widget/RecyclerView$vI$mjFkc;->JHa:Z

    .line 5
    iput v0, p0, Landroidx/recyclerview/widget/RecyclerView$vI$mjFkc;->xJ:I

    .line 6
    iput p1, p0, Landroidx/recyclerview/widget/RecyclerView$vI$mjFkc;->mjFkc:I

    .line 7
    iput p2, p0, Landroidx/recyclerview/widget/RecyclerView$vI$mjFkc;->AZxh:I

    .line 8
    iput p3, p0, Landroidx/recyclerview/widget/RecyclerView$vI$mjFkc;->wA:I

    .line 9
    iput-object p4, p0, Landroidx/recyclerview/widget/RecyclerView$vI$mjFkc;->KLFTb:Landroid/view/animation/Interpolator;

    return-void
.end method


# virtual methods
.method public AZxh(I)V
    .locals 0

    iput p1, p0, Landroidx/recyclerview/widget/RecyclerView$vI$mjFkc;->ZfxDd:I

    return-void
.end method

.method public final KLFTb()V
    .locals 2

    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView$vI$mjFkc;->KLFTb:Landroid/view/animation/Interpolator;

    const/4 v1, 0x1

    if-eqz v0, :cond_1

    iget v0, p0, Landroidx/recyclerview/widget/RecyclerView$vI$mjFkc;->wA:I

    if-lt v0, v1, :cond_0

    goto :goto_0

    :cond_0
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string v0, "If you provide an interpolator, you must set a positive duration"

    invoke-direct {p0, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_1
    :goto_0
    iget p0, p0, Landroidx/recyclerview/widget/RecyclerView$vI$mjFkc;->wA:I

    if-lt p0, v1, :cond_2

    return-void

    :cond_2
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string v0, "Scroll duration must be a positive number"

    invoke-direct {p0, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public ZfxDd(IIILandroid/view/animation/Interpolator;)V
    .locals 0

    iput p1, p0, Landroidx/recyclerview/widget/RecyclerView$vI$mjFkc;->mjFkc:I

    iput p2, p0, Landroidx/recyclerview/widget/RecyclerView$vI$mjFkc;->AZxh:I

    iput p3, p0, Landroidx/recyclerview/widget/RecyclerView$vI$mjFkc;->wA:I

    iput-object p4, p0, Landroidx/recyclerview/widget/RecyclerView$vI$mjFkc;->KLFTb:Landroid/view/animation/Interpolator;

    const/4 p1, 0x1

    iput-boolean p1, p0, Landroidx/recyclerview/widget/RecyclerView$vI$mjFkc;->JHa:Z

    return-void
.end method

.method public mjFkc()Z
    .locals 0

    iget p0, p0, Landroidx/recyclerview/widget/RecyclerView$vI$mjFkc;->ZfxDd:I

    if-ltz p0, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method

.method public wA(Landroidx/recyclerview/widget/RecyclerView;)V
    .locals 5

    iget v0, p0, Landroidx/recyclerview/widget/RecyclerView$vI$mjFkc;->ZfxDd:I

    const/4 v1, 0x0

    if-ltz v0, :cond_0

    const/4 v2, -0x1

    iput v2, p0, Landroidx/recyclerview/widget/RecyclerView$vI$mjFkc;->ZfxDd:I

    invoke-virtual {p1, v0}, Landroidx/recyclerview/widget/RecyclerView;->fFz(I)V

    iput-boolean v1, p0, Landroidx/recyclerview/widget/RecyclerView$vI$mjFkc;->JHa:Z

    return-void

    :cond_0
    iget-boolean v0, p0, Landroidx/recyclerview/widget/RecyclerView$vI$mjFkc;->JHa:Z

    if-eqz v0, :cond_2

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$vI$mjFkc;->KLFTb()V

    iget-object p1, p1, Landroidx/recyclerview/widget/RecyclerView;->bbzow:Landroidx/recyclerview/widget/RecyclerView$wJVbdd;

    iget v0, p0, Landroidx/recyclerview/widget/RecyclerView$vI$mjFkc;->mjFkc:I

    iget v2, p0, Landroidx/recyclerview/widget/RecyclerView$vI$mjFkc;->AZxh:I

    iget v3, p0, Landroidx/recyclerview/widget/RecyclerView$vI$mjFkc;->wA:I

    iget-object v4, p0, Landroidx/recyclerview/widget/RecyclerView$vI$mjFkc;->KLFTb:Landroid/view/animation/Interpolator;

    invoke-virtual {p1, v0, v2, v3, v4}, Landroidx/recyclerview/widget/RecyclerView$wJVbdd;->KLFTb(IIILandroid/view/animation/Interpolator;)V

    iget p1, p0, Landroidx/recyclerview/widget/RecyclerView$vI$mjFkc;->xJ:I

    add-int/lit8 p1, p1, 0x1

    iput p1, p0, Landroidx/recyclerview/widget/RecyclerView$vI$mjFkc;->xJ:I

    const/16 v0, 0xa

    if-le p1, v0, :cond_1

    const-string p1, "RecyclerView"

    const-string v0, "Smooth Scroll action is being updated too frequently. Make sure you are not changing it unless necessary"

    invoke-static {p1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    :cond_1
    iput-boolean v1, p0, Landroidx/recyclerview/widget/RecyclerView$vI$mjFkc;->JHa:Z

    goto :goto_0

    :cond_2
    iput v1, p0, Landroidx/recyclerview/widget/RecyclerView$vI$mjFkc;->xJ:I

    :goto_0
    return-void
.end method
