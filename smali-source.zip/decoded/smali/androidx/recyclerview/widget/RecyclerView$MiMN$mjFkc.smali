.class public interface abstract Landroidx/recyclerview/widget/RecyclerView$MiMN$mjFkc;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/recyclerview/widget/RecyclerView$MiMN;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "mjFkc"
.end annotation


# virtual methods
.method public abstract mjFkc(Landroidx/recyclerview/widget/RecyclerView$mByQ;)V
.end method
