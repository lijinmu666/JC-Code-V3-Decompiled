.class public Landroidx/recyclerview/widget/RecyclerView$VocHEe;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/recyclerview/widget/RecyclerView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "VocHEe"
.end annotation


# instance fields
.field public AZxh:Landroid/util/SparseArray;

.field public Dt:Z

.field public ETF:Z

.field public JHa:I

.field public KLFTb:I

.field public MiMN:I

.field public VA:Z

.field public YoKzxo:J

.field public ZfxDd:I

.field public fehf:I

.field public lgHUyS:Z

.field public mjFkc:I

.field public qGY:I

.field public qdMbNW:Z

.field public rkYL:I

.field public wA:I

.field public xJ:Z


# direct methods
.method public constructor <init>()V
    .locals 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, -0x1

    iput v0, p0, Landroidx/recyclerview/widget/RecyclerView$VocHEe;->mjFkc:I

    const/4 v0, 0x0

    iput v0, p0, Landroidx/recyclerview/widget/RecyclerView$VocHEe;->wA:I

    iput v0, p0, Landroidx/recyclerview/widget/RecyclerView$VocHEe;->ZfxDd:I

    const/4 v1, 0x1

    iput v1, p0, Landroidx/recyclerview/widget/RecyclerView$VocHEe;->KLFTb:I

    iput v0, p0, Landroidx/recyclerview/widget/RecyclerView$VocHEe;->JHa:I

    iput-boolean v0, p0, Landroidx/recyclerview/widget/RecyclerView$VocHEe;->xJ:Z

    iput-boolean v0, p0, Landroidx/recyclerview/widget/RecyclerView$VocHEe;->lgHUyS:Z

    iput-boolean v0, p0, Landroidx/recyclerview/widget/RecyclerView$VocHEe;->qdMbNW:Z

    iput-boolean v0, p0, Landroidx/recyclerview/widget/RecyclerView$VocHEe;->Dt:Z

    iput-boolean v0, p0, Landroidx/recyclerview/widget/RecyclerView$VocHEe;->ETF:Z

    iput-boolean v0, p0, Landroidx/recyclerview/widget/RecyclerView$VocHEe;->VA:Z

    return-void
.end method


# virtual methods
.method public AZxh()I
    .locals 1

    iget-boolean v0, p0, Landroidx/recyclerview/widget/RecyclerView$VocHEe;->lgHUyS:Z

    if-eqz v0, :cond_0

    iget v0, p0, Landroidx/recyclerview/widget/RecyclerView$VocHEe;->wA:I

    iget p0, p0, Landroidx/recyclerview/widget/RecyclerView$VocHEe;->ZfxDd:I

    sub-int/2addr v0, p0

    goto :goto_0

    :cond_0
    iget v0, p0, Landroidx/recyclerview/widget/RecyclerView$VocHEe;->JHa:I

    :goto_0
    return v0
.end method

.method public JHa(Landroidx/recyclerview/widget/RecyclerView$lgHUyS;)V
    .locals 1

    const/4 v0, 0x1

    iput v0, p0, Landroidx/recyclerview/widget/RecyclerView$VocHEe;->KLFTb:I

    invoke-virtual {p1}, Landroidx/recyclerview/widget/RecyclerView$lgHUyS;->ZfxDd()I

    move-result p1

    iput p1, p0, Landroidx/recyclerview/widget/RecyclerView$VocHEe;->JHa:I

    const/4 p1, 0x0

    iput-boolean p1, p0, Landroidx/recyclerview/widget/RecyclerView$VocHEe;->lgHUyS:Z

    iput-boolean p1, p0, Landroidx/recyclerview/widget/RecyclerView$VocHEe;->qdMbNW:Z

    iput-boolean p1, p0, Landroidx/recyclerview/widget/RecyclerView$VocHEe;->Dt:Z

    return-void
.end method

.method public KLFTb()Z
    .locals 0

    iget-boolean p0, p0, Landroidx/recyclerview/widget/RecyclerView$VocHEe;->lgHUyS:Z

    return p0
.end method

.method public ZfxDd()Z
    .locals 1

    iget p0, p0, Landroidx/recyclerview/widget/RecyclerView$VocHEe;->mjFkc:I

    const/4 v0, -0x1

    if-eq p0, v0, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method

.method public mjFkc(I)V
    .locals 3

    iget v0, p0, Landroidx/recyclerview/widget/RecyclerView$VocHEe;->KLFTb:I

    and-int/2addr v0, p1

    if-eqz v0, :cond_0

    return-void

    :cond_0
    new-instance v0, Ljava/lang/IllegalStateException;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "Layout state should be one of "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {p1}, Ljava/lang/Integer;->toBinaryString(I)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p1, " but it is "

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget p0, p0, Landroidx/recyclerview/widget/RecyclerView$VocHEe;->KLFTb:I

    invoke-static {p0}, Ljava/lang/Integer;->toBinaryString(I)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public toString()Ljava/lang/String;
    .locals 2

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "State{mTargetPosition="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, Landroidx/recyclerview/widget/RecyclerView$VocHEe;->mjFkc:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, ", mData="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Landroidx/recyclerview/widget/RecyclerView$VocHEe;->AZxh:Landroid/util/SparseArray;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", mItemCount="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, Landroidx/recyclerview/widget/RecyclerView$VocHEe;->JHa:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, ", mIsMeasuring="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-boolean v1, p0, Landroidx/recyclerview/widget/RecyclerView$VocHEe;->Dt:Z

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const-string v1, ", mPreviousLayoutItemCount="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, Landroidx/recyclerview/widget/RecyclerView$VocHEe;->wA:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, ", mDeletedInvisibleItemCountSincePreviousLayout="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, Landroidx/recyclerview/widget/RecyclerView$VocHEe;->ZfxDd:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, ", mStructureChanged="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-boolean v1, p0, Landroidx/recyclerview/widget/RecyclerView$VocHEe;->xJ:Z

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const-string v1, ", mInPreLayout="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-boolean v1, p0, Landroidx/recyclerview/widget/RecyclerView$VocHEe;->lgHUyS:Z

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const-string v1, ", mRunSimpleAnimations="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-boolean v1, p0, Landroidx/recyclerview/widget/RecyclerView$VocHEe;->ETF:Z

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const-string v1, ", mRunPredictiveAnimations="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-boolean p0, p0, Landroidx/recyclerview/widget/RecyclerView$VocHEe;->VA:Z

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const/16 p0, 0x7d

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public wA()I
    .locals 0

    iget p0, p0, Landroidx/recyclerview/widget/RecyclerView$VocHEe;->mjFkc:I

    return p0
.end method

.method public xJ()Z
    .locals 0

    iget-boolean p0, p0, Landroidx/recyclerview/widget/RecyclerView$VocHEe;->VA:Z

    return p0
.end method
