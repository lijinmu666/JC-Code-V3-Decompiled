.class public Landroidx/recyclerview/widget/RecyclerView$ZfxDd;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/recyclerview/widget/qGY$AZxh;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/recyclerview/widget/RecyclerView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic mjFkc:Landroidx/recyclerview/widget/RecyclerView;


# direct methods
.method public constructor <init>(Landroidx/recyclerview/widget/RecyclerView;)V
    .locals 0

    iput-object p1, p0, Landroidx/recyclerview/widget/RecyclerView$ZfxDd;->mjFkc:Landroidx/recyclerview/widget/RecyclerView;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public AZxh(Landroidx/recyclerview/widget/RecyclerView$mByQ;Landroidx/recyclerview/widget/RecyclerView$MiMN$AZxh;Landroidx/recyclerview/widget/RecyclerView$MiMN$AZxh;)V
    .locals 0

    iget-object p0, p0, Landroidx/recyclerview/widget/RecyclerView$ZfxDd;->mjFkc:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {p0, p1, p2, p3}, Landroidx/recyclerview/widget/RecyclerView;->MiMN(Landroidx/recyclerview/widget/RecyclerView$mByQ;Landroidx/recyclerview/widget/RecyclerView$MiMN$AZxh;Landroidx/recyclerview/widget/RecyclerView$MiMN$AZxh;)V

    return-void
.end method

.method public ZfxDd(Landroidx/recyclerview/widget/RecyclerView$mByQ;Landroidx/recyclerview/widget/RecyclerView$MiMN$AZxh;Landroidx/recyclerview/widget/RecyclerView$MiMN$AZxh;)V
    .locals 2

    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Landroidx/recyclerview/widget/RecyclerView$mByQ;->Ne(Z)V

    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView$ZfxDd;->mjFkc:Landroidx/recyclerview/widget/RecyclerView;

    iget-boolean v1, v0, Landroidx/recyclerview/widget/RecyclerView;->mByQ:Z

    if-eqz v1, :cond_0

    iget-object v0, v0, Landroidx/recyclerview/widget/RecyclerView;->Vnb:Landroidx/recyclerview/widget/RecyclerView$MiMN;

    invoke-virtual {v0, p1, p1, p2, p3}, Landroidx/recyclerview/widget/RecyclerView$MiMN;->AZxh(Landroidx/recyclerview/widget/RecyclerView$mByQ;Landroidx/recyclerview/widget/RecyclerView$mByQ;Landroidx/recyclerview/widget/RecyclerView$MiMN$AZxh;Landroidx/recyclerview/widget/RecyclerView$MiMN$AZxh;)Z

    move-result p1

    if-eqz p1, :cond_1

    iget-object p0, p0, Landroidx/recyclerview/widget/RecyclerView$ZfxDd;->mjFkc:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView;->SKTn()V

    goto :goto_0

    :cond_0
    iget-object v0, v0, Landroidx/recyclerview/widget/RecyclerView;->Vnb:Landroidx/recyclerview/widget/RecyclerView$MiMN;

    invoke-virtual {v0, p1, p2, p3}, Landroidx/recyclerview/widget/RecyclerView$MiMN;->ZfxDd(Landroidx/recyclerview/widget/RecyclerView$mByQ;Landroidx/recyclerview/widget/RecyclerView$MiMN$AZxh;Landroidx/recyclerview/widget/RecyclerView$MiMN$AZxh;)Z

    move-result p1

    if-eqz p1, :cond_1

    iget-object p0, p0, Landroidx/recyclerview/widget/RecyclerView$ZfxDd;->mjFkc:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView;->SKTn()V

    :cond_1
    :goto_0
    return-void
.end method

.method public mjFkc(Landroidx/recyclerview/widget/RecyclerView$mByQ;)V
    .locals 1

    iget-object p0, p0, Landroidx/recyclerview/widget/RecyclerView$ZfxDd;->mjFkc:Landroidx/recyclerview/widget/RecyclerView;

    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->YoKzxo:Landroidx/recyclerview/widget/RecyclerView$qGY;

    iget-object p1, p1, Landroidx/recyclerview/widget/RecyclerView$mByQ;->mjFkc:Landroid/view/View;

    iget-object p0, p0, Landroidx/recyclerview/widget/RecyclerView;->wA:Landroidx/recyclerview/widget/RecyclerView$Ucbh;

    invoke-virtual {v0, p1, p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->RWyiuY(Landroid/view/View;Landroidx/recyclerview/widget/RecyclerView$Ucbh;)V

    return-void
.end method

.method public wA(Landroidx/recyclerview/widget/RecyclerView$mByQ;Landroidx/recyclerview/widget/RecyclerView$MiMN$AZxh;Landroidx/recyclerview/widget/RecyclerView$MiMN$AZxh;)V
    .locals 1

    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView$ZfxDd;->mjFkc:Landroidx/recyclerview/widget/RecyclerView;

    iget-object v0, v0, Landroidx/recyclerview/widget/RecyclerView;->wA:Landroidx/recyclerview/widget/RecyclerView$Ucbh;

    invoke-virtual {v0, p1}, Landroidx/recyclerview/widget/RecyclerView$Ucbh;->NPj(Landroidx/recyclerview/widget/RecyclerView$mByQ;)V

    iget-object p0, p0, Landroidx/recyclerview/widget/RecyclerView$ZfxDd;->mjFkc:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {p0, p1, p2, p3}, Landroidx/recyclerview/widget/RecyclerView;->rkYL(Landroidx/recyclerview/widget/RecyclerView$mByQ;Landroidx/recyclerview/widget/RecyclerView$MiMN$AZxh;Landroidx/recyclerview/widget/RecyclerView$MiMN$AZxh;)V

    return-void
.end method
