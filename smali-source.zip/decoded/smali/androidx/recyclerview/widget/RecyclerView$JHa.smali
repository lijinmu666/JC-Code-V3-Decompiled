.class public Landroidx/recyclerview/widget/RecyclerView$JHa;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/recyclerview/widget/mjFkc$mjFkc;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Landroidx/recyclerview/widget/RecyclerView;->Qr()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic mjFkc:Landroidx/recyclerview/widget/RecyclerView;


# direct methods
.method public constructor <init>(Landroidx/recyclerview/widget/RecyclerView;)V
    .locals 0

    iput-object p1, p0, Landroidx/recyclerview/widget/RecyclerView$JHa;->mjFkc:Landroidx/recyclerview/widget/RecyclerView;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public AZxh(Landroidx/recyclerview/widget/mjFkc$AZxh;)V
    .locals 0

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/RecyclerView$JHa;->qdMbNW(Landroidx/recyclerview/widget/mjFkc$AZxh;)V

    return-void
.end method

.method public JHa(II)V
    .locals 2

    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView$JHa;->mjFkc:Landroidx/recyclerview/widget/RecyclerView;

    const/4 v1, 0x1

    invoke-virtual {v0, p1, p2, v1}, Landroidx/recyclerview/widget/RecyclerView;->lti(IIZ)V

    iget-object p0, p0, Landroidx/recyclerview/widget/RecyclerView$JHa;->mjFkc:Landroidx/recyclerview/widget/RecyclerView;

    iput-boolean v1, p0, Landroidx/recyclerview/widget/RecyclerView;->alEkx:Z

    iget-object p0, p0, Landroidx/recyclerview/widget/RecyclerView;->Vdz:Landroidx/recyclerview/widget/RecyclerView$VocHEe;

    iget p1, p0, Landroidx/recyclerview/widget/RecyclerView$VocHEe;->ZfxDd:I

    add-int/2addr p1, p2

    iput p1, p0, Landroidx/recyclerview/widget/RecyclerView$VocHEe;->ZfxDd:I

    return-void
.end method

.method public KLFTb(II)V
    .locals 1

    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView$JHa;->mjFkc:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {v0, p1, p2}, Landroidx/recyclerview/widget/RecyclerView;->tISON(II)V

    iget-object p0, p0, Landroidx/recyclerview/widget/RecyclerView$JHa;->mjFkc:Landroidx/recyclerview/widget/RecyclerView;

    const/4 p1, 0x1

    iput-boolean p1, p0, Landroidx/recyclerview/widget/RecyclerView;->alEkx:Z

    return-void
.end method

.method public ZfxDd(II)V
    .locals 2

    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView$JHa;->mjFkc:Landroidx/recyclerview/widget/RecyclerView;

    const/4 v1, 0x0

    invoke-virtual {v0, p1, p2, v1}, Landroidx/recyclerview/widget/RecyclerView;->lti(IIZ)V

    iget-object p0, p0, Landroidx/recyclerview/widget/RecyclerView$JHa;->mjFkc:Landroidx/recyclerview/widget/RecyclerView;

    const/4 p1, 0x1

    iput-boolean p1, p0, Landroidx/recyclerview/widget/RecyclerView;->alEkx:Z

    return-void
.end method

.method public lgHUyS(IILjava/lang/Object;)V
    .locals 1

    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView$JHa;->mjFkc:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {v0, p1, p2, p3}, Landroidx/recyclerview/widget/RecyclerView;->xCVa(IILjava/lang/Object;)V

    iget-object p0, p0, Landroidx/recyclerview/widget/RecyclerView$JHa;->mjFkc:Landroidx/recyclerview/widget/RecyclerView;

    const/4 p1, 0x1

    iput-boolean p1, p0, Landroidx/recyclerview/widget/RecyclerView;->dm:Z

    return-void
.end method

.method public mjFkc(II)V
    .locals 1

    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView$JHa;->mjFkc:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {v0, p1, p2}, Landroidx/recyclerview/widget/RecyclerView;->Vgyli(II)V

    iget-object p0, p0, Landroidx/recyclerview/widget/RecyclerView$JHa;->mjFkc:Landroidx/recyclerview/widget/RecyclerView;

    const/4 p1, 0x1

    iput-boolean p1, p0, Landroidx/recyclerview/widget/RecyclerView;->alEkx:Z

    return-void
.end method

.method public qdMbNW(Landroidx/recyclerview/widget/mjFkc$AZxh;)V
    .locals 3

    iget v0, p1, Landroidx/recyclerview/widget/mjFkc$AZxh;->mjFkc:I

    const/4 v1, 0x1

    if-eq v0, v1, :cond_3

    const/4 v2, 0x2

    if-eq v0, v2, :cond_2

    const/4 v2, 0x4

    if-eq v0, v2, :cond_1

    const/16 v2, 0x8

    if-eq v0, v2, :cond_0

    goto :goto_0

    :cond_0
    iget-object p0, p0, Landroidx/recyclerview/widget/RecyclerView$JHa;->mjFkc:Landroidx/recyclerview/widget/RecyclerView;

    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->YoKzxo:Landroidx/recyclerview/widget/RecyclerView$qGY;

    iget v2, p1, Landroidx/recyclerview/widget/mjFkc$AZxh;->AZxh:I

    iget p1, p1, Landroidx/recyclerview/widget/mjFkc$AZxh;->ZfxDd:I

    invoke-virtual {v0, p0, v2, p1, v1}, Landroidx/recyclerview/widget/RecyclerView$qGY;->jtz(Landroidx/recyclerview/widget/RecyclerView;III)V

    goto :goto_0

    :cond_1
    iget-object p0, p0, Landroidx/recyclerview/widget/RecyclerView$JHa;->mjFkc:Landroidx/recyclerview/widget/RecyclerView;

    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->YoKzxo:Landroidx/recyclerview/widget/RecyclerView$qGY;

    iget v1, p1, Landroidx/recyclerview/widget/mjFkc$AZxh;->AZxh:I

    iget v2, p1, Landroidx/recyclerview/widget/mjFkc$AZxh;->ZfxDd:I

    iget-object p1, p1, Landroidx/recyclerview/widget/mjFkc$AZxh;->wA:Ljava/lang/Object;

    invoke-virtual {v0, p0, v1, v2, p1}, Landroidx/recyclerview/widget/RecyclerView$qGY;->tAfC(Landroidx/recyclerview/widget/RecyclerView;IILjava/lang/Object;)V

    goto :goto_0

    :cond_2
    iget-object p0, p0, Landroidx/recyclerview/widget/RecyclerView$JHa;->mjFkc:Landroidx/recyclerview/widget/RecyclerView;

    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->YoKzxo:Landroidx/recyclerview/widget/RecyclerView$qGY;

    iget v1, p1, Landroidx/recyclerview/widget/mjFkc$AZxh;->AZxh:I

    iget p1, p1, Landroidx/recyclerview/widget/mjFkc$AZxh;->ZfxDd:I

    invoke-virtual {v0, p0, v1, p1}, Landroidx/recyclerview/widget/RecyclerView$qGY;->XgAT(Landroidx/recyclerview/widget/RecyclerView;II)V

    goto :goto_0

    :cond_3
    iget-object p0, p0, Landroidx/recyclerview/widget/RecyclerView$JHa;->mjFkc:Landroidx/recyclerview/widget/RecyclerView;

    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->YoKzxo:Landroidx/recyclerview/widget/RecyclerView$qGY;

    iget v1, p1, Landroidx/recyclerview/widget/mjFkc$AZxh;->AZxh:I

    iget p1, p1, Landroidx/recyclerview/widget/mjFkc$AZxh;->ZfxDd:I

    invoke-virtual {v0, p0, v1, p1}, Landroidx/recyclerview/widget/RecyclerView$qGY;->eQ(Landroidx/recyclerview/widget/RecyclerView;II)V

    :goto_0
    return-void
.end method

.method public wA(I)Landroidx/recyclerview/widget/RecyclerView$mByQ;
    .locals 2

    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView$JHa;->mjFkc:Landroidx/recyclerview/widget/RecyclerView;

    const/4 v1, 0x1

    invoke-virtual {v0, p1, v1}, Landroidx/recyclerview/widget/RecyclerView;->SwgkN(IZ)Landroidx/recyclerview/widget/RecyclerView$mByQ;

    move-result-object p1

    const/4 v0, 0x0

    if-nez p1, :cond_0

    return-object v0

    :cond_0
    iget-object p0, p0, Landroidx/recyclerview/widget/RecyclerView$JHa;->mjFkc:Landroidx/recyclerview/widget/RecyclerView;

    iget-object p0, p0, Landroidx/recyclerview/widget/RecyclerView;->JHa:Landroidx/recyclerview/widget/AZxh;

    iget-object v1, p1, Landroidx/recyclerview/widget/RecyclerView$mByQ;->mjFkc:Landroid/view/View;

    invoke-virtual {p0, v1}, Landroidx/recyclerview/widget/AZxh;->YoKzxo(Landroid/view/View;)Z

    move-result p0

    if-eqz p0, :cond_2

    sget-boolean p0, Landroidx/recyclerview/widget/RecyclerView;->LREOK:Z

    if-eqz p0, :cond_1

    const-string p0, "RecyclerView"

    const-string p1, "assuming view holder cannot be find because it is hidden"

    invoke-static {p0, p1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    :cond_1
    return-object v0

    :cond_2
    return-object p1
.end method

.method public xJ(Landroidx/recyclerview/widget/mjFkc$AZxh;)V
    .locals 0

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/RecyclerView$JHa;->qdMbNW(Landroidx/recyclerview/widget/mjFkc$AZxh;)V

    return-void
.end method
