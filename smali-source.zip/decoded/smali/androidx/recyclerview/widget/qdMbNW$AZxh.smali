.class public Landroidx/recyclerview/widget/qdMbNW$AZxh;
.super Landroidx/recyclerview/widget/qdMbNW;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Landroidx/recyclerview/widget/qdMbNW;->wA(Landroidx/recyclerview/widget/RecyclerView$qGY;)Landroidx/recyclerview/widget/qdMbNW;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>(Landroidx/recyclerview/widget/RecyclerView$qGY;)V
    .locals 1

    const/4 v0, 0x0

    invoke-direct {p0, p1, v0}, Landroidx/recyclerview/widget/qdMbNW;-><init>(Landroidx/recyclerview/widget/RecyclerView$qGY;Landroidx/recyclerview/widget/qdMbNW$mjFkc;)V

    return-void
.end method


# virtual methods
.method public Dt()I
    .locals 0

    iget-object p0, p0, Landroidx/recyclerview/widget/qdMbNW;->mjFkc:Landroidx/recyclerview/widget/RecyclerView$qGY;

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->JBhc()I

    move-result p0

    return p0
.end method

.method public ETF()I
    .locals 0

    iget-object p0, p0, Landroidx/recyclerview/widget/qdMbNW;->mjFkc:Landroidx/recyclerview/widget/RecyclerView$qGY;

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->JrJO()I

    move-result p0

    return p0
.end method

.method public IEE(I)V
    .locals 0

    iget-object p0, p0, Landroidx/recyclerview/widget/qdMbNW;->mjFkc:Landroidx/recyclerview/widget/RecyclerView$qGY;

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/RecyclerView$qGY;->tISON(I)V

    return-void
.end method

.method public JHa(Landroid/view/View;)I
    .locals 1

    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    check-cast v0, Landroidx/recyclerview/widget/RecyclerView$fehf;

    iget-object p0, p0, Landroidx/recyclerview/widget/qdMbNW;->mjFkc:Landroidx/recyclerview/widget/RecyclerView$qGY;

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/RecyclerView$qGY;->KRTLGT(Landroid/view/View;)I

    move-result p0

    iget p1, v0, Landroid/view/ViewGroup$MarginLayoutParams;->leftMargin:I

    add-int/2addr p0, p1

    iget p1, v0, Landroid/view/ViewGroup$MarginLayoutParams;->rightMargin:I

    add-int/2addr p0, p1

    return p0
.end method

.method public KLFTb(Landroid/view/View;)I
    .locals 1

    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    check-cast v0, Landroidx/recyclerview/widget/RecyclerView$fehf;

    iget-object p0, p0, Landroidx/recyclerview/widget/qdMbNW;->mjFkc:Landroidx/recyclerview/widget/RecyclerView$qGY;

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/RecyclerView$qGY;->WrLQs(Landroid/view/View;)I

    move-result p0

    iget p1, v0, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    add-int/2addr p0, p1

    iget p1, v0, Landroid/view/ViewGroup$MarginLayoutParams;->bottomMargin:I

    add-int/2addr p0, p1

    return p0
.end method

.method public MiMN()I
    .locals 0

    iget-object p0, p0, Landroidx/recyclerview/widget/qdMbNW;->mjFkc:Landroidx/recyclerview/widget/RecyclerView$qGY;

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->dm()I

    move-result p0

    return p0
.end method

.method public VA()I
    .locals 0

    iget-object p0, p0, Landroidx/recyclerview/widget/qdMbNW;->mjFkc:Landroidx/recyclerview/widget/RecyclerView$qGY;

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->Qr()I

    move-result p0

    return p0
.end method

.method public YoKzxo()I
    .locals 2

    iget-object v0, p0, Landroidx/recyclerview/widget/qdMbNW;->mjFkc:Landroidx/recyclerview/widget/RecyclerView$qGY;

    invoke-virtual {v0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->JYgkl()I

    move-result v0

    iget-object v1, p0, Landroidx/recyclerview/widget/qdMbNW;->mjFkc:Landroidx/recyclerview/widget/RecyclerView$qGY;

    invoke-virtual {v1}, Landroidx/recyclerview/widget/RecyclerView$qGY;->dm()I

    move-result v1

    sub-int/2addr v0, v1

    iget-object p0, p0, Landroidx/recyclerview/widget/qdMbNW;->mjFkc:Landroidx/recyclerview/widget/RecyclerView$qGY;

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->JBhc()I

    move-result p0

    sub-int/2addr v0, p0

    return v0
.end method

.method public ZfxDd(Landroid/view/View;)I
    .locals 1

    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    check-cast v0, Landroidx/recyclerview/widget/RecyclerView$fehf;

    iget-object p0, p0, Landroidx/recyclerview/widget/qdMbNW;->mjFkc:Landroidx/recyclerview/widget/RecyclerView$qGY;

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/RecyclerView$qGY;->vadzgd(Landroid/view/View;)I

    move-result p0

    iget p1, v0, Landroid/view/ViewGroup$MarginLayoutParams;->bottomMargin:I

    add-int/2addr p0, p1

    return p0
.end method

.method public fehf(Landroid/view/View;)I
    .locals 3

    iget-object v0, p0, Landroidx/recyclerview/widget/qdMbNW;->mjFkc:Landroidx/recyclerview/widget/RecyclerView$qGY;

    const/4 v1, 0x1

    iget-object v2, p0, Landroidx/recyclerview/widget/qdMbNW;->wA:Landroid/graphics/Rect;

    invoke-virtual {v0, p1, v1, v2}, Landroidx/recyclerview/widget/RecyclerView$qGY;->SmIWf(Landroid/view/View;ZLandroid/graphics/Rect;)V

    iget-object p0, p0, Landroidx/recyclerview/widget/qdMbNW;->wA:Landroid/graphics/Rect;

    iget p0, p0, Landroid/graphics/Rect;->top:I

    return p0
.end method

.method public lgHUyS()I
    .locals 0

    iget-object p0, p0, Landroidx/recyclerview/widget/qdMbNW;->mjFkc:Landroidx/recyclerview/widget/RecyclerView$qGY;

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->JYgkl()I

    move-result p0

    return p0
.end method

.method public qGY(Landroid/view/View;)I
    .locals 3

    iget-object v0, p0, Landroidx/recyclerview/widget/qdMbNW;->mjFkc:Landroidx/recyclerview/widget/RecyclerView$qGY;

    const/4 v1, 0x1

    iget-object v2, p0, Landroidx/recyclerview/widget/qdMbNW;->wA:Landroid/graphics/Rect;

    invoke-virtual {v0, p1, v1, v2}, Landroidx/recyclerview/widget/RecyclerView$qGY;->SmIWf(Landroid/view/View;ZLandroid/graphics/Rect;)V

    iget-object p0, p0, Landroidx/recyclerview/widget/qdMbNW;->wA:Landroid/graphics/Rect;

    iget p0, p0, Landroid/graphics/Rect;->bottom:I

    return p0
.end method

.method public qdMbNW()I
    .locals 1

    iget-object v0, p0, Landroidx/recyclerview/widget/qdMbNW;->mjFkc:Landroidx/recyclerview/widget/RecyclerView$qGY;

    invoke-virtual {v0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->JYgkl()I

    move-result v0

    iget-object p0, p0, Landroidx/recyclerview/widget/qdMbNW;->mjFkc:Landroidx/recyclerview/widget/RecyclerView$qGY;

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$qGY;->JBhc()I

    move-result p0

    sub-int/2addr v0, p0

    return v0
.end method

.method public xJ(Landroid/view/View;)I
    .locals 1

    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    check-cast v0, Landroidx/recyclerview/widget/RecyclerView$fehf;

    iget-object p0, p0, Landroidx/recyclerview/widget/qdMbNW;->mjFkc:Landroidx/recyclerview/widget/RecyclerView$qGY;

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/RecyclerView$qGY;->uHVRx(Landroid/view/View;)I

    move-result p0

    iget p1, v0, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    sub-int/2addr p0, p1

    return p0
.end method
