.class public abstract synthetic Landroidx/recyclerview/widget/RecyclerView$xJ;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/recyclerview/widget/RecyclerView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1009
    name = null
.end annotation


# static fields
.field public static final synthetic mjFkc:[I


# direct methods
.method static constructor <clinit>()V
    .locals 3

    invoke-static {}, Landroidx/recyclerview/widget/RecyclerView$lgHUyS$mjFkc;->values()[Landroidx/recyclerview/widget/RecyclerView$lgHUyS$mjFkc;

    move-result-object v0

    array-length v0, v0

    new-array v0, v0, [I

    sput-object v0, Landroidx/recyclerview/widget/RecyclerView$xJ;->mjFkc:[I

    :try_start_0
    sget-object v1, Landroidx/recyclerview/widget/RecyclerView$lgHUyS$mjFkc;->wA:Landroidx/recyclerview/widget/RecyclerView$lgHUyS$mjFkc;

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    const/4 v2, 0x1

    aput v2, v0, v1
    :try_end_0
    .catch Ljava/lang/NoSuchFieldError; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :try_start_1
    sget-object v0, Landroidx/recyclerview/widget/RecyclerView$xJ;->mjFkc:[I

    sget-object v1, Landroidx/recyclerview/widget/RecyclerView$lgHUyS$mjFkc;->AZxh:Landroidx/recyclerview/widget/RecyclerView$lgHUyS$mjFkc;

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    const/4 v2, 0x2

    aput v2, v0, v1
    :try_end_1
    .catch Ljava/lang/NoSuchFieldError; {:try_start_1 .. :try_end_1} :catch_1

    :catch_1
    return-void
.end method
