.class public Landroidx/recyclerview/widget/wA$Dt;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/recyclerview/widget/wA;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "Dt"
.end annotation


# instance fields
.field public AZxh:I

.field public KLFTb:I

.field public ZfxDd:I

.field public mjFkc:Landroidx/recyclerview/widget/RecyclerView$mByQ;

.field public wA:I


# direct methods
.method public constructor <init>(Landroidx/recyclerview/widget/RecyclerView$mByQ;IIII)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/recyclerview/widget/wA$Dt;->mjFkc:Landroidx/recyclerview/widget/RecyclerView$mByQ;

    iput p2, p0, Landroidx/recyclerview/widget/wA$Dt;->AZxh:I

    iput p3, p0, Landroidx/recyclerview/widget/wA$Dt;->wA:I

    iput p4, p0, Landroidx/recyclerview/widget/wA$Dt;->ZfxDd:I

    iput p5, p0, Landroidx/recyclerview/widget/wA$Dt;->KLFTb:I

    return-void
.end method
