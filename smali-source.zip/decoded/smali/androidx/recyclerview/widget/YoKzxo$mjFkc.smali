.class public Landroidx/recyclerview/widget/YoKzxo$mjFkc;
.super Landroidx/recyclerview/widget/RecyclerView$diqgf;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/recyclerview/widget/YoKzxo;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic AZxh:Landroidx/recyclerview/widget/YoKzxo;

.field public mjFkc:Z


# direct methods
.method public constructor <init>(Landroidx/recyclerview/widget/YoKzxo;)V
    .locals 0

    iput-object p1, p0, Landroidx/recyclerview/widget/YoKzxo$mjFkc;->AZxh:Landroidx/recyclerview/widget/YoKzxo;

    invoke-direct {p0}, Landroidx/recyclerview/widget/RecyclerView$diqgf;-><init>()V

    const/4 p1, 0x0

    iput-boolean p1, p0, Landroidx/recyclerview/widget/YoKzxo$mjFkc;->mjFkc:Z

    return-void
.end method


# virtual methods
.method public AZxh(Landroidx/recyclerview/widget/RecyclerView;II)V
    .locals 0

    if-nez p2, :cond_0

    if-eqz p3, :cond_1

    :cond_0
    const/4 p1, 0x1

    iput-boolean p1, p0, Landroidx/recyclerview/widget/YoKzxo$mjFkc;->mjFkc:Z

    :cond_1
    return-void
.end method

.method public mjFkc(Landroidx/recyclerview/widget/RecyclerView;I)V
    .locals 0

    invoke-super {p0, p1, p2}, Landroidx/recyclerview/widget/RecyclerView$diqgf;->mjFkc(Landroidx/recyclerview/widget/RecyclerView;I)V

    if-nez p2, :cond_0

    iget-boolean p1, p0, Landroidx/recyclerview/widget/YoKzxo$mjFkc;->mjFkc:Z

    if-eqz p1, :cond_0

    const/4 p1, 0x0

    iput-boolean p1, p0, Landroidx/recyclerview/widget/YoKzxo$mjFkc;->mjFkc:Z

    iget-object p0, p0, Landroidx/recyclerview/widget/YoKzxo$mjFkc;->AZxh:Landroidx/recyclerview/widget/YoKzxo;

    invoke-virtual {p0}, Landroidx/recyclerview/widget/YoKzxo;->Dt()V

    :cond_0
    return-void
.end method
