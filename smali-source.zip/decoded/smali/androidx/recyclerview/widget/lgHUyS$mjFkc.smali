.class public interface abstract Landroidx/recyclerview/widget/lgHUyS$mjFkc;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/recyclerview/widget/lgHUyS;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "mjFkc"
.end annotation


# virtual methods
.method public abstract AZxh(IIILjava/lang/Object;)Landroidx/recyclerview/widget/mjFkc$AZxh;
.end method

.method public abstract mjFkc(Landroidx/recyclerview/widget/mjFkc$AZxh;)V
.end method
