.class public interface abstract Landroidx/savedstate/mjFkc$wA;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/savedstate/mjFkc;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "wA"
.end annotation


# virtual methods
.method public abstract mjFkc()Landroid/os/Bundle;
.end method
