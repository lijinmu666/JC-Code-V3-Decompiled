.class public interface abstract Landroidx/savedstate/mjFkc$mjFkc;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/savedstate/mjFkc;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "mjFkc"
.end annotation


# virtual methods
.method public abstract mjFkc(Lo/n6;)V
.end method
