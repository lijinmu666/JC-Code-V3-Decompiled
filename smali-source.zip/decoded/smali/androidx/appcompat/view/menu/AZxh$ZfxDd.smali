.class public Landroidx/appcompat/view/menu/AZxh$ZfxDd;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/appcompat/view/menu/AZxh;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "ZfxDd"
.end annotation


# instance fields
.field public final AZxh:Landroidx/appcompat/view/menu/ZfxDd;

.field public final mjFkc:Lo/Z1;

.field public final wA:I


# direct methods
.method public constructor <init>(Lo/Z1;Landroidx/appcompat/view/menu/ZfxDd;I)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/appcompat/view/menu/AZxh$ZfxDd;->mjFkc:Lo/Z1;

    iput-object p2, p0, Landroidx/appcompat/view/menu/AZxh$ZfxDd;->AZxh:Landroidx/appcompat/view/menu/ZfxDd;

    iput p3, p0, Landroidx/appcompat/view/menu/AZxh$ZfxDd;->wA:I

    return-void
.end method


# virtual methods
.method public mjFkc()Landroid/widget/ListView;
    .locals 0

    iget-object p0, p0, Landroidx/appcompat/view/menu/AZxh$ZfxDd;->mjFkc:Lo/Z1;

    invoke-virtual {p0}, Lo/a1;->KLFTb()Landroid/widget/ListView;

    move-result-object p0

    return-object p0
.end method
