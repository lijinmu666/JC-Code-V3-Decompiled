.class public interface abstract Landroidx/appcompat/view/menu/ZfxDd$AZxh;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/appcompat/view/menu/ZfxDd;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "AZxh"
.end annotation


# virtual methods
.method public abstract mjFkc(Landroidx/appcompat/view/menu/KLFTb;)Z
.end method
