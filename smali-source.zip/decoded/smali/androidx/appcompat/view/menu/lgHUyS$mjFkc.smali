.class public interface abstract Landroidx/appcompat/view/menu/lgHUyS$mjFkc;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/appcompat/view/menu/lgHUyS;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "mjFkc"
.end annotation


# virtual methods
.method public abstract ZfxDd(Landroidx/appcompat/view/menu/KLFTb;I)V
.end method

.method public abstract getItemData()Landroidx/appcompat/view/menu/KLFTb;
.end method

.method public abstract wA()Z
.end method
