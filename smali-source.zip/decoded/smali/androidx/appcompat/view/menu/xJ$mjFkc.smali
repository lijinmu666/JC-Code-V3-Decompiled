.class public interface abstract Landroidx/appcompat/view/menu/xJ$mjFkc;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/appcompat/view/menu/xJ;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "mjFkc"
.end annotation


# virtual methods
.method public abstract AZxh(Landroidx/appcompat/view/menu/ZfxDd;Z)V
.end method

.method public abstract wA(Landroidx/appcompat/view/menu/ZfxDd;)Z
.end method
