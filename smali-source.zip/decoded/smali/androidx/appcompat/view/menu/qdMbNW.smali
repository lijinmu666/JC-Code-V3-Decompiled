.class public final Landroidx/appcompat/view/menu/qdMbNW;
.super Lo/Y1;
.source "SourceFile"

# interfaces
.implements Landroid/widget/PopupWindow$OnDismissListener;
.implements Landroid/widget/AdapterView$OnItemClickListener;
.implements Landroidx/appcompat/view/menu/xJ;
.implements Landroid/view/View$OnKeyListener;


# static fields
.field public static final Ucbh:I


# instance fields
.field public final AZxh:Landroid/content/Context;

.field public final Dt:Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;

.field public final ETF:Landroid/view/View$OnAttachStateChangeListener;

.field public IEE:Z

.field public final JHa:I

.field public final KLFTb:Z

.field public MiMN:Landroid/view/View;

.field public Pq:I

.field public VA:Landroid/widget/PopupWindow$OnDismissListener;

.field public YoKzxo:Landroid/view/View;

.field public final ZfxDd:Landroidx/appcompat/view/menu/wA;

.field public diqgf:I

.field public eyqo:Z

.field public fehf:Z

.field public final lgHUyS:I

.field public qGY:Landroid/view/ViewTreeObserver;

.field public final qdMbNW:Lo/Z1;

.field public rkYL:Landroidx/appcompat/view/menu/xJ$mjFkc;

.field public final wA:Landroidx/appcompat/view/menu/ZfxDd;

.field public final xJ:I


# direct methods
.method static constructor <clinit>()V
    .locals 1

    sget v0, Lo/I4;->Dt:I

    sput v0, Landroidx/appcompat/view/menu/qdMbNW;->Ucbh:I

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroidx/appcompat/view/menu/ZfxDd;Landroid/view/View;IIZ)V
    .locals 3

    invoke-direct {p0}, Lo/Y1;-><init>()V

    new-instance v0, Landroidx/appcompat/view/menu/qdMbNW$mjFkc;

    invoke-direct {v0, p0}, Landroidx/appcompat/view/menu/qdMbNW$mjFkc;-><init>(Landroidx/appcompat/view/menu/qdMbNW;)V

    iput-object v0, p0, Landroidx/appcompat/view/menu/qdMbNW;->Dt:Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;

    new-instance v0, Landroidx/appcompat/view/menu/qdMbNW$AZxh;

    invoke-direct {v0, p0}, Landroidx/appcompat/view/menu/qdMbNW$AZxh;-><init>(Landroidx/appcompat/view/menu/qdMbNW;)V

    iput-object v0, p0, Landroidx/appcompat/view/menu/qdMbNW;->ETF:Landroid/view/View$OnAttachStateChangeListener;

    const/4 v0, 0x0

    iput v0, p0, Landroidx/appcompat/view/menu/qdMbNW;->diqgf:I

    iput-object p1, p0, Landroidx/appcompat/view/menu/qdMbNW;->AZxh:Landroid/content/Context;

    iput-object p2, p0, Landroidx/appcompat/view/menu/qdMbNW;->wA:Landroidx/appcompat/view/menu/ZfxDd;

    iput-boolean p6, p0, Landroidx/appcompat/view/menu/qdMbNW;->KLFTb:Z

    invoke-static {p1}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object v0

    new-instance v1, Landroidx/appcompat/view/menu/wA;

    sget v2, Landroidx/appcompat/view/menu/qdMbNW;->Ucbh:I

    invoke-direct {v1, p2, v0, p6, v2}, Landroidx/appcompat/view/menu/wA;-><init>(Landroidx/appcompat/view/menu/ZfxDd;Landroid/view/LayoutInflater;ZI)V

    iput-object v1, p0, Landroidx/appcompat/view/menu/qdMbNW;->ZfxDd:Landroidx/appcompat/view/menu/wA;

    iput p4, p0, Landroidx/appcompat/view/menu/qdMbNW;->xJ:I

    iput p5, p0, Landroidx/appcompat/view/menu/qdMbNW;->lgHUyS:I

    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p6

    invoke-virtual {p6}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v0

    iget v0, v0, Landroid/util/DisplayMetrics;->widthPixels:I

    div-int/lit8 v0, v0, 0x2

    sget v1, Lo/o4;->AZxh:I

    invoke-virtual {p6, v1}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    move-result p6

    invoke-static {v0, p6}, Ljava/lang/Math;->max(II)I

    move-result p6

    iput p6, p0, Landroidx/appcompat/view/menu/qdMbNW;->JHa:I

    iput-object p3, p0, Landroidx/appcompat/view/menu/qdMbNW;->MiMN:Landroid/view/View;

    new-instance p3, Lo/Z1;

    const/4 p6, 0x0

    invoke-direct {p3, p1, p6, p4, p5}, Lo/Z1;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;II)V

    iput-object p3, p0, Landroidx/appcompat/view/menu/qdMbNW;->qdMbNW:Lo/Z1;

    invoke-virtual {p2, p0, p1}, Landroidx/appcompat/view/menu/ZfxDd;->AZxh(Landroidx/appcompat/view/menu/xJ;Landroid/content/Context;)V

    return-void
.end method


# virtual methods
.method public AZxh(Landroidx/appcompat/view/menu/ZfxDd;Z)V
    .locals 1

    iget-object v0, p0, Landroidx/appcompat/view/menu/qdMbNW;->wA:Landroidx/appcompat/view/menu/ZfxDd;

    if-eq p1, v0, :cond_0

    return-void

    :cond_0
    invoke-virtual {p0}, Landroidx/appcompat/view/menu/qdMbNW;->ZfxDd()V

    iget-object p0, p0, Landroidx/appcompat/view/menu/qdMbNW;->rkYL:Landroidx/appcompat/view/menu/xJ$mjFkc;

    if-eqz p0, :cond_1

    invoke-interface {p0, p1, p2}, Landroidx/appcompat/view/menu/xJ$mjFkc;->AZxh(Landroidx/appcompat/view/menu/ZfxDd;Z)V

    :cond_1
    return-void
.end method

.method public Dt()Z
    .locals 1

    iget-boolean v0, p0, Landroidx/appcompat/view/menu/qdMbNW;->fehf:Z

    if-nez v0, :cond_0

    iget-object p0, p0, Landroidx/appcompat/view/menu/qdMbNW;->qdMbNW:Lo/Z1;

    invoke-virtual {p0}, Lo/a1;->Dt()Z

    move-result p0

    if-eqz p0, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method

.method public Gd(I)V
    .locals 0

    iget-object p0, p0, Landroidx/appcompat/view/menu/qdMbNW;->qdMbNW:Lo/Z1;

    invoke-virtual {p0, p1}, Lo/a1;->wJVbdd(I)V

    return-void
.end method

.method public JHa(Landroidx/appcompat/view/menu/Dt;)Z
    .locals 9

    invoke-virtual {p1}, Landroidx/appcompat/view/menu/ZfxDd;->hasVisibleItems()Z

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_2

    new-instance v0, Landroidx/appcompat/view/menu/JHa;

    iget-object v3, p0, Landroidx/appcompat/view/menu/qdMbNW;->AZxh:Landroid/content/Context;

    iget-object v5, p0, Landroidx/appcompat/view/menu/qdMbNW;->YoKzxo:Landroid/view/View;

    iget-boolean v6, p0, Landroidx/appcompat/view/menu/qdMbNW;->KLFTb:Z

    iget v7, p0, Landroidx/appcompat/view/menu/qdMbNW;->xJ:I

    iget v8, p0, Landroidx/appcompat/view/menu/qdMbNW;->lgHUyS:I

    move-object v2, v0

    move-object v4, p1

    invoke-direct/range {v2 .. v8}, Landroidx/appcompat/view/menu/JHa;-><init>(Landroid/content/Context;Landroidx/appcompat/view/menu/ZfxDd;Landroid/view/View;ZII)V

    iget-object v2, p0, Landroidx/appcompat/view/menu/qdMbNW;->rkYL:Landroidx/appcompat/view/menu/xJ$mjFkc;

    invoke-virtual {v0, v2}, Landroidx/appcompat/view/menu/JHa;->Dt(Landroidx/appcompat/view/menu/xJ$mjFkc;)V

    invoke-static {p1}, Lo/Y1;->HGpJ(Landroidx/appcompat/view/menu/ZfxDd;)Z

    move-result v2

    invoke-virtual {v0, v2}, Landroidx/appcompat/view/menu/JHa;->xJ(Z)V

    iget-object v2, p0, Landroidx/appcompat/view/menu/qdMbNW;->VA:Landroid/widget/PopupWindow$OnDismissListener;

    invoke-virtual {v0, v2}, Landroidx/appcompat/view/menu/JHa;->qdMbNW(Landroid/widget/PopupWindow$OnDismissListener;)V

    const/4 v2, 0x0

    iput-object v2, p0, Landroidx/appcompat/view/menu/qdMbNW;->VA:Landroid/widget/PopupWindow$OnDismissListener;

    iget-object v2, p0, Landroidx/appcompat/view/menu/qdMbNW;->wA:Landroidx/appcompat/view/menu/ZfxDd;

    invoke-virtual {v2, v1}, Landroidx/appcompat/view/menu/ZfxDd;->ZfxDd(Z)V

    iget-object v2, p0, Landroidx/appcompat/view/menu/qdMbNW;->qdMbNW:Lo/Z1;

    invoke-virtual {v2}, Lo/a1;->ETF()I

    move-result v2

    iget-object v3, p0, Landroidx/appcompat/view/menu/qdMbNW;->qdMbNW:Lo/Z1;

    invoke-virtual {v3}, Lo/a1;->MiMN()I

    move-result v3

    iget v4, p0, Landroidx/appcompat/view/menu/qdMbNW;->diqgf:I

    iget-object v5, p0, Landroidx/appcompat/view/menu/qdMbNW;->MiMN:Landroid/view/View;

    invoke-static {v5}, Lo/T9;->huTpC(Landroid/view/View;)I

    move-result v5

    invoke-static {v4, v5}, Landroid/view/Gravity;->getAbsoluteGravity(II)I

    move-result v4

    and-int/lit8 v4, v4, 0x7

    const/4 v5, 0x5

    if-ne v4, v5, :cond_0

    iget-object v4, p0, Landroidx/appcompat/view/menu/qdMbNW;->MiMN:Landroid/view/View;

    invoke-virtual {v4}, Landroid/view/View;->getWidth()I

    move-result v4

    add-int/2addr v2, v4

    :cond_0
    invoke-virtual {v0, v2, v3}, Landroidx/appcompat/view/menu/JHa;->YoKzxo(II)Z

    move-result v0

    if-eqz v0, :cond_2

    iget-object p0, p0, Landroidx/appcompat/view/menu/qdMbNW;->rkYL:Landroidx/appcompat/view/menu/xJ$mjFkc;

    if-eqz p0, :cond_1

    invoke-interface {p0, p1}, Landroidx/appcompat/view/menu/xJ$mjFkc;->wA(Landroidx/appcompat/view/menu/ZfxDd;)Z

    :cond_1
    const/4 p0, 0x1

    return p0

    :cond_2
    return v1
.end method

.method public KLFTb()Landroid/widget/ListView;
    .locals 0

    iget-object p0, p0, Landroidx/appcompat/view/menu/qdMbNW;->qdMbNW:Lo/Z1;

    invoke-virtual {p0}, Lo/a1;->KLFTb()Landroid/widget/ListView;

    move-result-object p0

    return-object p0
.end method

.method public MiMN(Landroidx/appcompat/view/menu/ZfxDd;)V
    .locals 0

    return-void
.end method

.method public Pq(Z)V
    .locals 0

    iget-object p0, p0, Landroidx/appcompat/view/menu/qdMbNW;->ZfxDd:Landroidx/appcompat/view/menu/wA;

    invoke-virtual {p0, p1}, Landroidx/appcompat/view/menu/wA;->ZfxDd(Z)V

    return-void
.end method

.method public Ucbh(Landroid/widget/PopupWindow$OnDismissListener;)V
    .locals 0

    iput-object p1, p0, Landroidx/appcompat/view/menu/qdMbNW;->VA:Landroid/widget/PopupWindow$OnDismissListener;

    return-void
.end method

.method public VA(Landroidx/appcompat/view/menu/xJ$mjFkc;)V
    .locals 0

    iput-object p1, p0, Landroidx/appcompat/view/menu/qdMbNW;->rkYL:Landroidx/appcompat/view/menu/xJ$mjFkc;

    return-void
.end method

.method public final VocHEe()Z
    .locals 7

    invoke-virtual {p0}, Landroidx/appcompat/view/menu/qdMbNW;->Dt()Z

    move-result v0

    const/4 v1, 0x1

    if-eqz v0, :cond_0

    return v1

    :cond_0
    iget-boolean v0, p0, Landroidx/appcompat/view/menu/qdMbNW;->fehf:Z

    const/4 v2, 0x0

    if-nez v0, :cond_7

    iget-object v0, p0, Landroidx/appcompat/view/menu/qdMbNW;->MiMN:Landroid/view/View;

    if-nez v0, :cond_1

    goto/16 :goto_1

    :cond_1
    iput-object v0, p0, Landroidx/appcompat/view/menu/qdMbNW;->YoKzxo:Landroid/view/View;

    iget-object v0, p0, Landroidx/appcompat/view/menu/qdMbNW;->qdMbNW:Lo/Z1;

    invoke-virtual {v0, p0}, Lo/a1;->vI(Landroid/widget/PopupWindow$OnDismissListener;)V

    iget-object v0, p0, Landroidx/appcompat/view/menu/qdMbNW;->qdMbNW:Lo/Z1;

    invoke-virtual {v0, p0}, Lo/a1;->VocHEe(Landroid/widget/AdapterView$OnItemClickListener;)V

    iget-object v0, p0, Landroidx/appcompat/view/menu/qdMbNW;->qdMbNW:Lo/Z1;

    invoke-virtual {v0, v1}, Lo/a1;->HGpJ(Z)V

    iget-object v0, p0, Landroidx/appcompat/view/menu/qdMbNW;->YoKzxo:Landroid/view/View;

    iget-object v3, p0, Landroidx/appcompat/view/menu/qdMbNW;->qGY:Landroid/view/ViewTreeObserver;

    if-nez v3, :cond_2

    move v3, v1

    goto :goto_0

    :cond_2
    move v3, v2

    :goto_0
    invoke-virtual {v0}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    move-result-object v4

    iput-object v4, p0, Landroidx/appcompat/view/menu/qdMbNW;->qGY:Landroid/view/ViewTreeObserver;

    if-eqz v3, :cond_3

    iget-object v3, p0, Landroidx/appcompat/view/menu/qdMbNW;->Dt:Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;

    invoke-virtual {v4, v3}, Landroid/view/ViewTreeObserver;->addOnGlobalLayoutListener(Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;)V

    :cond_3
    iget-object v3, p0, Landroidx/appcompat/view/menu/qdMbNW;->ETF:Landroid/view/View$OnAttachStateChangeListener;

    invoke-virtual {v0, v3}, Landroid/view/View;->addOnAttachStateChangeListener(Landroid/view/View$OnAttachStateChangeListener;)V

    iget-object v3, p0, Landroidx/appcompat/view/menu/qdMbNW;->qdMbNW:Lo/Z1;

    invoke-virtual {v3, v0}, Lo/a1;->IEE(Landroid/view/View;)V

    iget-object v0, p0, Landroidx/appcompat/view/menu/qdMbNW;->qdMbNW:Lo/Z1;

    iget v3, p0, Landroidx/appcompat/view/menu/qdMbNW;->diqgf:I

    invoke-virtual {v0, v3}, Lo/a1;->eyqo(I)V

    iget-boolean v0, p0, Landroidx/appcompat/view/menu/qdMbNW;->IEE:Z

    const/4 v3, 0x0

    if-nez v0, :cond_4

    iget-object v0, p0, Landroidx/appcompat/view/menu/qdMbNW;->ZfxDd:Landroidx/appcompat/view/menu/wA;

    iget-object v4, p0, Landroidx/appcompat/view/menu/qdMbNW;->AZxh:Landroid/content/Context;

    iget v5, p0, Landroidx/appcompat/view/menu/qdMbNW;->JHa:I

    invoke-static {v0, v3, v4, v5}, Lo/Y1;->qGY(Landroid/widget/ListAdapter;Landroid/view/ViewGroup;Landroid/content/Context;I)I

    move-result v0

    iput v0, p0, Landroidx/appcompat/view/menu/qdMbNW;->Pq:I

    iput-boolean v1, p0, Landroidx/appcompat/view/menu/qdMbNW;->IEE:Z

    :cond_4
    iget-object v0, p0, Landroidx/appcompat/view/menu/qdMbNW;->qdMbNW:Lo/Z1;

    iget v4, p0, Landroidx/appcompat/view/menu/qdMbNW;->Pq:I

    invoke-virtual {v0, v4}, Lo/a1;->diqgf(I)V

    iget-object v0, p0, Landroidx/appcompat/view/menu/qdMbNW;->qdMbNW:Lo/Z1;

    const/4 v4, 0x2

    invoke-virtual {v0, v4}, Lo/a1;->Gd(I)V

    iget-object v0, p0, Landroidx/appcompat/view/menu/qdMbNW;->qdMbNW:Lo/Z1;

    invoke-virtual {p0}, Lo/Y1;->rkYL()Landroid/graphics/Rect;

    move-result-object v4

    invoke-virtual {v0, v4}, Lo/a1;->Ucbh(Landroid/graphics/Rect;)V

    iget-object v0, p0, Landroidx/appcompat/view/menu/qdMbNW;->qdMbNW:Lo/Z1;

    invoke-virtual {v0}, Lo/a1;->mjFkc()V

    iget-object v0, p0, Landroidx/appcompat/view/menu/qdMbNW;->qdMbNW:Lo/Z1;

    invoke-virtual {v0}, Lo/a1;->KLFTb()Landroid/widget/ListView;

    move-result-object v0

    invoke-virtual {v0, p0}, Landroid/view/View;->setOnKeyListener(Landroid/view/View$OnKeyListener;)V

    iget-boolean v4, p0, Landroidx/appcompat/view/menu/qdMbNW;->eyqo:Z

    if-eqz v4, :cond_6

    iget-object v4, p0, Landroidx/appcompat/view/menu/qdMbNW;->wA:Landroidx/appcompat/view/menu/ZfxDd;

    invoke-virtual {v4}, Landroidx/appcompat/view/menu/ZfxDd;->eyqo()Ljava/lang/CharSequence;

    move-result-object v4

    if-eqz v4, :cond_6

    iget-object v4, p0, Landroidx/appcompat/view/menu/qdMbNW;->AZxh:Landroid/content/Context;

    invoke-static {v4}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object v4

    sget v5, Lo/I4;->qdMbNW:I

    invoke-virtual {v4, v5, v0, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object v4

    check-cast v4, Landroid/widget/FrameLayout;

    const v5, 0x1020016

    invoke-virtual {v4, v5}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v5

    check-cast v5, Landroid/widget/TextView;

    if-eqz v5, :cond_5

    iget-object v6, p0, Landroidx/appcompat/view/menu/qdMbNW;->wA:Landroidx/appcompat/view/menu/ZfxDd;

    invoke-virtual {v6}, Landroidx/appcompat/view/menu/ZfxDd;->eyqo()Ljava/lang/CharSequence;

    move-result-object v6

    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :cond_5
    invoke-virtual {v4, v2}, Landroid/view/View;->setEnabled(Z)V

    invoke-virtual {v0, v4, v3, v2}, Landroid/widget/ListView;->addHeaderView(Landroid/view/View;Ljava/lang/Object;Z)V

    :cond_6
    iget-object v0, p0, Landroidx/appcompat/view/menu/qdMbNW;->qdMbNW:Lo/Z1;

    iget-object v2, p0, Landroidx/appcompat/view/menu/qdMbNW;->ZfxDd:Landroidx/appcompat/view/menu/wA;

    invoke-virtual {v0, v2}, Lo/a1;->fehf(Landroid/widget/ListAdapter;)V

    iget-object p0, p0, Landroidx/appcompat/view/menu/qdMbNW;->qdMbNW:Lo/Z1;

    invoke-virtual {p0}, Lo/a1;->mjFkc()V

    return v1

    :cond_7
    :goto_1
    return v2
.end method

.method public ZfxDd()V
    .locals 1

    invoke-virtual {p0}, Landroidx/appcompat/view/menu/qdMbNW;->Dt()Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object p0, p0, Landroidx/appcompat/view/menu/qdMbNW;->qdMbNW:Lo/Z1;

    invoke-virtual {p0}, Lo/a1;->ZfxDd()V

    :cond_0
    return-void
.end method

.method public diqgf(I)V
    .locals 0

    iput p1, p0, Landroidx/appcompat/view/menu/qdMbNW;->diqgf:I

    return-void
.end method

.method public eyqo(I)V
    .locals 0

    iget-object p0, p0, Landroidx/appcompat/view/menu/qdMbNW;->qdMbNW:Lo/Z1;

    invoke-virtual {p0, p1}, Lo/a1;->huTpC(I)V

    return-void
.end method

.method public fehf(Landroid/view/View;)V
    .locals 0

    iput-object p1, p0, Landroidx/appcompat/view/menu/qdMbNW;->MiMN:Landroid/view/View;

    return-void
.end method

.method public huTpC(Z)V
    .locals 0

    iput-boolean p1, p0, Landroidx/appcompat/view/menu/qdMbNW;->eyqo:Z

    return-void
.end method

.method public lgHUyS()Z
    .locals 0

    const/4 p0, 0x0

    return p0
.end method

.method public mjFkc()V
    .locals 1

    invoke-virtual {p0}, Landroidx/appcompat/view/menu/qdMbNW;->VocHEe()Z

    move-result p0

    if-eqz p0, :cond_0

    return-void

    :cond_0
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string v0, "StandardMenuPopup cannot be used without an anchor"

    invoke-direct {p0, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public onDismiss()V
    .locals 2

    const/4 v0, 0x1

    iput-boolean v0, p0, Landroidx/appcompat/view/menu/qdMbNW;->fehf:Z

    iget-object v0, p0, Landroidx/appcompat/view/menu/qdMbNW;->wA:Landroidx/appcompat/view/menu/ZfxDd;

    invoke-virtual {v0}, Landroidx/appcompat/view/menu/ZfxDd;->close()V

    iget-object v0, p0, Landroidx/appcompat/view/menu/qdMbNW;->qGY:Landroid/view/ViewTreeObserver;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Landroid/view/ViewTreeObserver;->isAlive()Z

    move-result v0

    if-nez v0, :cond_0

    iget-object v0, p0, Landroidx/appcompat/view/menu/qdMbNW;->YoKzxo:Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    move-result-object v0

    iput-object v0, p0, Landroidx/appcompat/view/menu/qdMbNW;->qGY:Landroid/view/ViewTreeObserver;

    :cond_0
    iget-object v0, p0, Landroidx/appcompat/view/menu/qdMbNW;->qGY:Landroid/view/ViewTreeObserver;

    iget-object v1, p0, Landroidx/appcompat/view/menu/qdMbNW;->Dt:Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;

    invoke-virtual {v0, v1}, Landroid/view/ViewTreeObserver;->removeGlobalOnLayoutListener(Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;)V

    const/4 v0, 0x0

    iput-object v0, p0, Landroidx/appcompat/view/menu/qdMbNW;->qGY:Landroid/view/ViewTreeObserver;

    :cond_1
    iget-object v0, p0, Landroidx/appcompat/view/menu/qdMbNW;->YoKzxo:Landroid/view/View;

    iget-object v1, p0, Landroidx/appcompat/view/menu/qdMbNW;->ETF:Landroid/view/View$OnAttachStateChangeListener;

    invoke-virtual {v0, v1}, Landroid/view/View;->removeOnAttachStateChangeListener(Landroid/view/View$OnAttachStateChangeListener;)V

    iget-object p0, p0, Landroidx/appcompat/view/menu/qdMbNW;->VA:Landroid/widget/PopupWindow$OnDismissListener;

    if-eqz p0, :cond_2

    invoke-interface {p0}, Landroid/widget/PopupWindow$OnDismissListener;->onDismiss()V

    :cond_2
    return-void
.end method

.method public onKey(Landroid/view/View;ILandroid/view/KeyEvent;)Z
    .locals 0

    invoke-virtual {p3}, Landroid/view/KeyEvent;->getAction()I

    move-result p1

    const/4 p3, 0x1

    if-ne p1, p3, :cond_0

    const/16 p1, 0x52

    if-ne p2, p1, :cond_0

    invoke-virtual {p0}, Landroidx/appcompat/view/menu/qdMbNW;->ZfxDd()V

    return p3

    :cond_0
    const/4 p0, 0x0

    return p0
.end method

.method public xJ(Z)V
    .locals 0

    const/4 p1, 0x0

    iput-boolean p1, p0, Landroidx/appcompat/view/menu/qdMbNW;->IEE:Z

    iget-object p0, p0, Landroidx/appcompat/view/menu/qdMbNW;->ZfxDd:Landroidx/appcompat/view/menu/wA;

    if-eqz p0, :cond_0

    invoke-virtual {p0}, Landroidx/appcompat/view/menu/wA;->notifyDataSetChanged()V

    :cond_0
    return-void
.end method
