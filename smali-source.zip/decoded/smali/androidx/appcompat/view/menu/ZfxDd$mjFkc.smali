.class public interface abstract Landroidx/appcompat/view/menu/ZfxDd$mjFkc;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/appcompat/view/menu/ZfxDd;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "mjFkc"
.end annotation


# virtual methods
.method public abstract AZxh(Landroidx/appcompat/view/menu/ZfxDd;)V
.end method

.method public abstract mjFkc(Landroidx/appcompat/view/menu/ZfxDd;Landroid/view/MenuItem;)Z
.end method
