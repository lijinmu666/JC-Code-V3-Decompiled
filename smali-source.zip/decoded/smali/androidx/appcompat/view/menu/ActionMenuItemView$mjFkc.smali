.class public Landroidx/appcompat/view/menu/ActionMenuItemView$mjFkc;
.super Lo/prww;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/appcompat/view/menu/ActionMenuItemView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "mjFkc"
.end annotation


# instance fields
.field public final synthetic Dt:Landroidx/appcompat/view/menu/ActionMenuItemView;


# direct methods
.method public constructor <init>(Landroidx/appcompat/view/menu/ActionMenuItemView;)V
    .locals 0

    iput-object p1, p0, Landroidx/appcompat/view/menu/ActionMenuItemView$mjFkc;->Dt:Landroidx/appcompat/view/menu/ActionMenuItemView;

    invoke-direct {p0, p1}, Lo/prww;-><init>(Landroid/view/View;)V

    return-void
.end method


# virtual methods
.method public AZxh()Lo/Q6;
    .locals 0

    iget-object p0, p0, Landroidx/appcompat/view/menu/ActionMenuItemView$mjFkc;->Dt:Landroidx/appcompat/view/menu/ActionMenuItemView;

    iget-object p0, p0, Landroidx/appcompat/view/menu/ActionMenuItemView;->MiMN:Landroidx/appcompat/view/menu/ActionMenuItemView$AZxh;

    if-eqz p0, :cond_0

    invoke-virtual {p0}, Landroidx/appcompat/view/menu/ActionMenuItemView$AZxh;->mjFkc()Lo/Q6;

    move-result-object p0

    return-object p0

    :cond_0
    const/4 p0, 0x0

    return-object p0
.end method

.method public wA()Z
    .locals 3

    iget-object v0, p0, Landroidx/appcompat/view/menu/ActionMenuItemView$mjFkc;->Dt:Landroidx/appcompat/view/menu/ActionMenuItemView;

    iget-object v1, v0, Landroidx/appcompat/view/menu/ActionMenuItemView;->ETF:Landroidx/appcompat/view/menu/ZfxDd$AZxh;

    const/4 v2, 0x0

    if-eqz v1, :cond_0

    iget-object v0, v0, Landroidx/appcompat/view/menu/ActionMenuItemView;->lgHUyS:Landroidx/appcompat/view/menu/KLFTb;

    invoke-interface {v1, v0}, Landroidx/appcompat/view/menu/ZfxDd$AZxh;->mjFkc(Landroidx/appcompat/view/menu/KLFTb;)Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-virtual {p0}, Landroidx/appcompat/view/menu/ActionMenuItemView$mjFkc;->AZxh()Lo/Q6;

    move-result-object p0

    if-eqz p0, :cond_0

    invoke-interface {p0}, Lo/Q6;->Dt()Z

    move-result p0

    if-eqz p0, :cond_0

    const/4 v2, 0x1

    :cond_0
    return v2
.end method
