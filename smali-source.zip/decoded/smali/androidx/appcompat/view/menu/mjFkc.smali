.class public abstract Landroidx/appcompat/view/menu/mjFkc;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/appcompat/view/menu/xJ;


# instance fields
.field public AZxh:Landroid/content/Context;

.field public JHa:Landroidx/appcompat/view/menu/xJ$mjFkc;

.field public KLFTb:Landroid/view/LayoutInflater;

.field public ZfxDd:Landroid/view/LayoutInflater;

.field public lgHUyS:I

.field public mjFkc:Landroid/content/Context;

.field public qdMbNW:Landroidx/appcompat/view/menu/lgHUyS;

.field public wA:Landroidx/appcompat/view/menu/ZfxDd;

.field public xJ:I


# direct methods
.method public constructor <init>(Landroid/content/Context;II)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/appcompat/view/menu/mjFkc;->mjFkc:Landroid/content/Context;

    invoke-static {p1}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object p1

    iput-object p1, p0, Landroidx/appcompat/view/menu/mjFkc;->ZfxDd:Landroid/view/LayoutInflater;

    iput p2, p0, Landroidx/appcompat/view/menu/mjFkc;->xJ:I

    iput p3, p0, Landroidx/appcompat/view/menu/mjFkc;->lgHUyS:I

    return-void
.end method


# virtual methods
.method public AZxh(Landroidx/appcompat/view/menu/ZfxDd;Z)V
    .locals 0

    iget-object p0, p0, Landroidx/appcompat/view/menu/mjFkc;->JHa:Landroidx/appcompat/view/menu/xJ$mjFkc;

    if-eqz p0, :cond_0

    invoke-interface {p0, p1, p2}, Landroidx/appcompat/view/menu/xJ$mjFkc;->AZxh(Landroidx/appcompat/view/menu/ZfxDd;Z)V

    :cond_0
    return-void
.end method

.method public Dt(Landroid/view/ViewGroup;I)Z
    .locals 0

    invoke-virtual {p1, p2}, Landroid/view/ViewGroup;->removeViewAt(I)V

    const/4 p0, 0x1

    return p0
.end method

.method public ETF(Landroidx/appcompat/view/menu/ZfxDd;Landroidx/appcompat/view/menu/KLFTb;)Z
    .locals 0

    const/4 p0, 0x0

    return p0
.end method

.method public JHa(Landroidx/appcompat/view/menu/Dt;)Z
    .locals 1

    iget-object v0, p0, Landroidx/appcompat/view/menu/mjFkc;->JHa:Landroidx/appcompat/view/menu/xJ$mjFkc;

    if-eqz v0, :cond_1

    if-eqz p1, :cond_0

    goto :goto_0

    :cond_0
    iget-object p1, p0, Landroidx/appcompat/view/menu/mjFkc;->wA:Landroidx/appcompat/view/menu/ZfxDd;

    :goto_0
    invoke-interface {v0, p1}, Landroidx/appcompat/view/menu/xJ$mjFkc;->wA(Landroidx/appcompat/view/menu/ZfxDd;)Z

    move-result p0

    return p0

    :cond_1
    const/4 p0, 0x0

    return p0
.end method

.method public KLFTb(Landroid/view/ViewGroup;)Landroidx/appcompat/view/menu/lgHUyS$mjFkc;
    .locals 2

    iget-object v0, p0, Landroidx/appcompat/view/menu/mjFkc;->ZfxDd:Landroid/view/LayoutInflater;

    iget p0, p0, Landroidx/appcompat/view/menu/mjFkc;->lgHUyS:I

    const/4 v1, 0x0

    invoke-virtual {v0, p0, p1, v1}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object p0

    check-cast p0, Landroidx/appcompat/view/menu/lgHUyS$mjFkc;

    return-object p0
.end method

.method public MiMN()Landroidx/appcompat/view/menu/xJ$mjFkc;
    .locals 0

    iget-object p0, p0, Landroidx/appcompat/view/menu/mjFkc;->JHa:Landroidx/appcompat/view/menu/xJ$mjFkc;

    return-object p0
.end method

.method public VA(Landroidx/appcompat/view/menu/xJ$mjFkc;)V
    .locals 0

    iput-object p1, p0, Landroidx/appcompat/view/menu/mjFkc;->JHa:Landroidx/appcompat/view/menu/xJ$mjFkc;

    return-void
.end method

.method public YoKzxo(Landroidx/appcompat/view/menu/KLFTb;Landroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;
    .locals 1

    instance-of v0, p2, Landroidx/appcompat/view/menu/lgHUyS$mjFkc;

    if-eqz v0, :cond_0

    check-cast p2, Landroidx/appcompat/view/menu/lgHUyS$mjFkc;

    goto :goto_0

    :cond_0
    invoke-virtual {p0, p3}, Landroidx/appcompat/view/menu/mjFkc;->KLFTb(Landroid/view/ViewGroup;)Landroidx/appcompat/view/menu/lgHUyS$mjFkc;

    move-result-object p2

    :goto_0
    invoke-virtual {p0, p1, p2}, Landroidx/appcompat/view/menu/mjFkc;->ZfxDd(Landroidx/appcompat/view/menu/KLFTb;Landroidx/appcompat/view/menu/lgHUyS$mjFkc;)V

    check-cast p2, Landroid/view/View;

    return-object p2
.end method

.method public abstract ZfxDd(Landroidx/appcompat/view/menu/KLFTb;Landroidx/appcompat/view/menu/lgHUyS$mjFkc;)V
.end method

.method public mjFkc(Landroid/view/View;I)V
    .locals 1

    invoke-virtual {p1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    check-cast v0, Landroid/view/ViewGroup;

    if-eqz v0, :cond_0

    invoke-virtual {v0, p1}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    :cond_0
    iget-object p0, p0, Landroidx/appcompat/view/menu/mjFkc;->qdMbNW:Landroidx/appcompat/view/menu/lgHUyS;

    check-cast p0, Landroid/view/ViewGroup;

    invoke-virtual {p0, p1, p2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;I)V

    return-void
.end method

.method public qdMbNW(Landroidx/appcompat/view/menu/ZfxDd;Landroidx/appcompat/view/menu/KLFTb;)Z
    .locals 0

    const/4 p0, 0x0

    return p0
.end method

.method public abstract rkYL(ILandroidx/appcompat/view/menu/KLFTb;)Z
.end method

.method public wA(Landroid/content/Context;Landroidx/appcompat/view/menu/ZfxDd;)V
    .locals 0

    iput-object p1, p0, Landroidx/appcompat/view/menu/mjFkc;->AZxh:Landroid/content/Context;

    invoke-static {p1}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object p1

    iput-object p1, p0, Landroidx/appcompat/view/menu/mjFkc;->KLFTb:Landroid/view/LayoutInflater;

    iput-object p2, p0, Landroidx/appcompat/view/menu/mjFkc;->wA:Landroidx/appcompat/view/menu/ZfxDd;

    return-void
.end method

.method public xJ(Z)V
    .locals 9

    iget-object p1, p0, Landroidx/appcompat/view/menu/mjFkc;->qdMbNW:Landroidx/appcompat/view/menu/lgHUyS;

    check-cast p1, Landroid/view/ViewGroup;

    if-nez p1, :cond_0

    return-void

    :cond_0
    iget-object v0, p0, Landroidx/appcompat/view/menu/mjFkc;->wA:Landroidx/appcompat/view/menu/ZfxDd;

    const/4 v1, 0x0

    if-eqz v0, :cond_6

    invoke-virtual {v0}, Landroidx/appcompat/view/menu/ZfxDd;->fehf()V

    iget-object v0, p0, Landroidx/appcompat/view/menu/mjFkc;->wA:Landroidx/appcompat/view/menu/ZfxDd;

    invoke-virtual {v0}, Landroidx/appcompat/view/menu/ZfxDd;->VocHEe()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v2

    move v3, v1

    move v4, v3

    :goto_0
    if-ge v3, v2, :cond_5

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Landroidx/appcompat/view/menu/KLFTb;

    invoke-virtual {p0, v4, v5}, Landroidx/appcompat/view/menu/mjFkc;->rkYL(ILandroidx/appcompat/view/menu/KLFTb;)Z

    move-result v6

    if-eqz v6, :cond_4

    invoke-virtual {p1, v4}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v6

    instance-of v7, v6, Landroidx/appcompat/view/menu/lgHUyS$mjFkc;

    if-eqz v7, :cond_1

    move-object v7, v6

    check-cast v7, Landroidx/appcompat/view/menu/lgHUyS$mjFkc;

    invoke-interface {v7}, Landroidx/appcompat/view/menu/lgHUyS$mjFkc;->getItemData()Landroidx/appcompat/view/menu/KLFTb;

    move-result-object v7

    goto :goto_1

    :cond_1
    const/4 v7, 0x0

    :goto_1
    invoke-virtual {p0, v5, v6, p1}, Landroidx/appcompat/view/menu/mjFkc;->YoKzxo(Landroidx/appcompat/view/menu/KLFTb;Landroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;

    move-result-object v8

    if-eq v5, v7, :cond_2

    invoke-virtual {v8, v1}, Landroid/view/View;->setPressed(Z)V

    invoke-virtual {v8}, Landroid/view/View;->jumpDrawablesToCurrentState()V

    :cond_2
    if-eq v8, v6, :cond_3

    invoke-virtual {p0, v8, v4}, Landroidx/appcompat/view/menu/mjFkc;->mjFkc(Landroid/view/View;I)V

    :cond_3
    add-int/lit8 v4, v4, 0x1

    :cond_4
    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    :cond_5
    move v1, v4

    :cond_6
    :goto_2
    invoke-virtual {p1}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v0

    if-ge v1, v0, :cond_7

    invoke-virtual {p0, p1, v1}, Landroidx/appcompat/view/menu/mjFkc;->Dt(Landroid/view/ViewGroup;I)Z

    move-result v0

    if-nez v0, :cond_6

    add-int/lit8 v1, v1, 0x1

    goto :goto_2

    :cond_7
    return-void
.end method
