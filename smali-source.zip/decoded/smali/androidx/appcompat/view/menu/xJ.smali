.class public interface abstract Landroidx/appcompat/view/menu/xJ;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/appcompat/view/menu/xJ$mjFkc;
    }
.end annotation


# virtual methods
.method public abstract AZxh(Landroidx/appcompat/view/menu/ZfxDd;Z)V
.end method

.method public abstract ETF(Landroidx/appcompat/view/menu/ZfxDd;Landroidx/appcompat/view/menu/KLFTb;)Z
.end method

.method public abstract JHa(Landroidx/appcompat/view/menu/Dt;)Z
.end method

.method public abstract VA(Landroidx/appcompat/view/menu/xJ$mjFkc;)V
.end method

.method public abstract lgHUyS()Z
.end method

.method public abstract qdMbNW(Landroidx/appcompat/view/menu/ZfxDd;Landroidx/appcompat/view/menu/KLFTb;)Z
.end method

.method public abstract wA(Landroid/content/Context;Landroidx/appcompat/view/menu/ZfxDd;)V
.end method

.method public abstract xJ(Z)V
.end method
