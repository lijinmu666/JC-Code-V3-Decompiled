.class public Landroidx/appcompat/view/menu/JHa$mjFkc;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/widget/PopupWindow$OnDismissListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/appcompat/view/menu/JHa;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic mjFkc:Landroidx/appcompat/view/menu/JHa;


# direct methods
.method public constructor <init>(Landroidx/appcompat/view/menu/JHa;)V
    .locals 0

    iput-object p1, p0, Landroidx/appcompat/view/menu/JHa$mjFkc;->mjFkc:Landroidx/appcompat/view/menu/JHa;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onDismiss()V
    .locals 0

    iget-object p0, p0, Landroidx/appcompat/view/menu/JHa$mjFkc;->mjFkc:Landroidx/appcompat/view/menu/JHa;

    invoke-virtual {p0}, Landroidx/appcompat/view/menu/JHa;->KLFTb()V

    return-void
.end method
