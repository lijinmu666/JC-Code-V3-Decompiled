.class public Landroidx/appcompat/view/menu/AZxh$wA$mjFkc;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Landroidx/appcompat/view/menu/AZxh$wA;->AZxh(Landroidx/appcompat/view/menu/ZfxDd;Landroid/view/MenuItem;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic AZxh:Landroid/view/MenuItem;

.field public final synthetic ZfxDd:Landroidx/appcompat/view/menu/AZxh$wA;

.field public final synthetic mjFkc:Landroidx/appcompat/view/menu/AZxh$ZfxDd;

.field public final synthetic wA:Landroidx/appcompat/view/menu/ZfxDd;


# direct methods
.method public constructor <init>(Landroidx/appcompat/view/menu/AZxh$wA;Landroidx/appcompat/view/menu/AZxh$ZfxDd;Landroid/view/MenuItem;Landroidx/appcompat/view/menu/ZfxDd;)V
    .locals 0

    iput-object p1, p0, Landroidx/appcompat/view/menu/AZxh$wA$mjFkc;->ZfxDd:Landroidx/appcompat/view/menu/AZxh$wA;

    iput-object p2, p0, Landroidx/appcompat/view/menu/AZxh$wA$mjFkc;->mjFkc:Landroidx/appcompat/view/menu/AZxh$ZfxDd;

    iput-object p3, p0, Landroidx/appcompat/view/menu/AZxh$wA$mjFkc;->AZxh:Landroid/view/MenuItem;

    iput-object p4, p0, Landroidx/appcompat/view/menu/AZxh$wA$mjFkc;->wA:Landroidx/appcompat/view/menu/ZfxDd;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 3

    iget-object v0, p0, Landroidx/appcompat/view/menu/AZxh$wA$mjFkc;->mjFkc:Landroidx/appcompat/view/menu/AZxh$ZfxDd;

    if-eqz v0, :cond_0

    iget-object v1, p0, Landroidx/appcompat/view/menu/AZxh$wA$mjFkc;->ZfxDd:Landroidx/appcompat/view/menu/AZxh$wA;

    iget-object v1, v1, Landroidx/appcompat/view/menu/AZxh$wA;->mjFkc:Landroidx/appcompat/view/menu/AZxh;

    const/4 v2, 0x1

    iput-boolean v2, v1, Landroidx/appcompat/view/menu/AZxh;->VocHEe:Z

    iget-object v0, v0, Landroidx/appcompat/view/menu/AZxh$ZfxDd;->AZxh:Landroidx/appcompat/view/menu/ZfxDd;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroidx/appcompat/view/menu/ZfxDd;->ZfxDd(Z)V

    iget-object v0, p0, Landroidx/appcompat/view/menu/AZxh$wA$mjFkc;->ZfxDd:Landroidx/appcompat/view/menu/AZxh$wA;

    iget-object v0, v0, Landroidx/appcompat/view/menu/AZxh$wA;->mjFkc:Landroidx/appcompat/view/menu/AZxh;

    iput-boolean v1, v0, Landroidx/appcompat/view/menu/AZxh;->VocHEe:Z

    :cond_0
    iget-object v0, p0, Landroidx/appcompat/view/menu/AZxh$wA$mjFkc;->AZxh:Landroid/view/MenuItem;

    invoke-interface {v0}, Landroid/view/MenuItem;->isEnabled()Z

    move-result v0

    if-eqz v0, :cond_1

    iget-object v0, p0, Landroidx/appcompat/view/menu/AZxh$wA$mjFkc;->AZxh:Landroid/view/MenuItem;

    invoke-interface {v0}, Landroid/view/MenuItem;->hasSubMenu()Z

    move-result v0

    if-eqz v0, :cond_1

    iget-object v0, p0, Landroidx/appcompat/view/menu/AZxh$wA$mjFkc;->wA:Landroidx/appcompat/view/menu/ZfxDd;

    iget-object p0, p0, Landroidx/appcompat/view/menu/AZxh$wA$mjFkc;->AZxh:Landroid/view/MenuItem;

    const/4 v1, 0x4

    invoke-virtual {v0, p0, v1}, Landroidx/appcompat/view/menu/ZfxDd;->CqaNbM(Landroid/view/MenuItem;I)Z

    :cond_1
    return-void
.end method
