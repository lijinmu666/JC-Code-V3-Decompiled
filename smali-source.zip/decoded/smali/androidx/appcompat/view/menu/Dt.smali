.class public Landroidx/appcompat/view/menu/Dt;
.super Landroidx/appcompat/view/menu/ZfxDd;
.source "SourceFile"

# interfaces
.implements Landroid/view/SubMenu;


# instance fields
.field public BAnRFn:Landroidx/appcompat/view/menu/ZfxDd;

.field public lB:Landroidx/appcompat/view/menu/KLFTb;


# direct methods
.method public constructor <init>(Landroid/content/Context;Landroidx/appcompat/view/menu/ZfxDd;Landroidx/appcompat/view/menu/KLFTb;)V
    .locals 0

    invoke-direct {p0, p1}, Landroidx/appcompat/view/menu/ZfxDd;-><init>(Landroid/content/Context;)V

    iput-object p2, p0, Landroidx/appcompat/view/menu/Dt;->BAnRFn:Landroidx/appcompat/view/menu/ZfxDd;

    iput-object p3, p0, Landroidx/appcompat/view/menu/Dt;->lB:Landroidx/appcompat/view/menu/KLFTb;

    return-void
.end method


# virtual methods
.method public BAnRFn()Z
    .locals 0

    iget-object p0, p0, Landroidx/appcompat/view/menu/Dt;->BAnRFn:Landroidx/appcompat/view/menu/ZfxDd;

    invoke-virtual {p0}, Landroidx/appcompat/view/menu/ZfxDd;->BAnRFn()Z

    move-result p0

    return p0
.end method

.method public Dt(Landroidx/appcompat/view/menu/KLFTb;)Z
    .locals 0

    iget-object p0, p0, Landroidx/appcompat/view/menu/Dt;->BAnRFn:Landroidx/appcompat/view/menu/ZfxDd;

    invoke-virtual {p0, p1}, Landroidx/appcompat/view/menu/ZfxDd;->Dt(Landroidx/appcompat/view/menu/KLFTb;)Z

    move-result p0

    return p0
.end method

.method public JYn()Landroid/view/Menu;
    .locals 0

    iget-object p0, p0, Landroidx/appcompat/view/menu/Dt;->BAnRFn:Landroidx/appcompat/view/menu/ZfxDd;

    return-object p0
.end method

.method public KLFTb(Landroidx/appcompat/view/menu/KLFTb;)Z
    .locals 0

    iget-object p0, p0, Landroidx/appcompat/view/menu/Dt;->BAnRFn:Landroidx/appcompat/view/menu/ZfxDd;

    invoke-virtual {p0, p1}, Landroidx/appcompat/view/menu/ZfxDd;->KLFTb(Landroidx/appcompat/view/menu/KLFTb;)Z

    move-result p0

    return p0
.end method

.method public cMLeY(Landroidx/appcompat/view/menu/ZfxDd$mjFkc;)V
    .locals 0

    iget-object p0, p0, Landroidx/appcompat/view/menu/Dt;->BAnRFn:Landroidx/appcompat/view/menu/ZfxDd;

    invoke-virtual {p0, p1}, Landroidx/appcompat/view/menu/ZfxDd;->cMLeY(Landroidx/appcompat/view/menu/ZfxDd$mjFkc;)V

    return-void
.end method

.method public getItem()Landroid/view/MenuItem;
    .locals 0

    iget-object p0, p0, Landroidx/appcompat/view/menu/Dt;->lB:Landroidx/appcompat/view/menu/KLFTb;

    return-object p0
.end method

.method public lB()Z
    .locals 0

    iget-object p0, p0, Landroidx/appcompat/view/menu/Dt;->BAnRFn:Landroidx/appcompat/view/menu/ZfxDd;

    invoke-virtual {p0}, Landroidx/appcompat/view/menu/ZfxDd;->lB()Z

    move-result p0

    return p0
.end method

.method public setGroupDividerEnabled(Z)V
    .locals 0

    iget-object p0, p0, Landroidx/appcompat/view/menu/Dt;->BAnRFn:Landroidx/appcompat/view/menu/ZfxDd;

    invoke-virtual {p0, p1}, Landroidx/appcompat/view/menu/ZfxDd;->setGroupDividerEnabled(Z)V

    return-void
.end method

.method public setHeaderIcon(I)Landroid/view/SubMenu;
    .locals 0

    .line 2
    invoke-super {p0, p1}, Landroidx/appcompat/view/menu/ZfxDd;->Vnb(I)Landroidx/appcompat/view/menu/ZfxDd;

    move-result-object p0

    check-cast p0, Landroid/view/SubMenu;

    return-object p0
.end method

.method public setHeaderIcon(Landroid/graphics/drawable/Drawable;)Landroid/view/SubMenu;
    .locals 0

    .line 1
    invoke-super {p0, p1}, Landroidx/appcompat/view/menu/ZfxDd;->NPj(Landroid/graphics/drawable/Drawable;)Landroidx/appcompat/view/menu/ZfxDd;

    move-result-object p0

    check-cast p0, Landroid/view/SubMenu;

    return-object p0
.end method

.method public setHeaderTitle(I)Landroid/view/SubMenu;
    .locals 0

    .line 2
    invoke-super {p0, p1}, Landroidx/appcompat/view/menu/ZfxDd;->oCFDzJ(I)Landroidx/appcompat/view/menu/ZfxDd;

    move-result-object p0

    check-cast p0, Landroid/view/SubMenu;

    return-object p0
.end method

.method public setHeaderTitle(Ljava/lang/CharSequence;)Landroid/view/SubMenu;
    .locals 0

    .line 1
    invoke-super {p0, p1}, Landroidx/appcompat/view/menu/ZfxDd;->aqHPIZ(Ljava/lang/CharSequence;)Landroidx/appcompat/view/menu/ZfxDd;

    move-result-object p0

    check-cast p0, Landroid/view/SubMenu;

    return-object p0
.end method

.method public setHeaderView(Landroid/view/View;)Landroid/view/SubMenu;
    .locals 0

    invoke-super {p0, p1}, Landroidx/appcompat/view/menu/ZfxDd;->WrLQs(Landroid/view/View;)Landroidx/appcompat/view/menu/ZfxDd;

    move-result-object p0

    check-cast p0, Landroid/view/SubMenu;

    return-object p0
.end method

.method public setIcon(I)Landroid/view/SubMenu;
    .locals 1

    .line 2
    iget-object v0, p0, Landroidx/appcompat/view/menu/Dt;->lB:Landroidx/appcompat/view/menu/KLFTb;

    invoke-virtual {v0, p1}, Landroidx/appcompat/view/menu/KLFTb;->setIcon(I)Landroid/view/MenuItem;

    return-object p0
.end method

.method public setIcon(Landroid/graphics/drawable/Drawable;)Landroid/view/SubMenu;
    .locals 1

    .line 1
    iget-object v0, p0, Landroidx/appcompat/view/menu/Dt;->lB:Landroidx/appcompat/view/menu/KLFTb;

    invoke-virtual {v0, p1}, Landroidx/appcompat/view/menu/KLFTb;->setIcon(Landroid/graphics/drawable/Drawable;)Landroid/view/MenuItem;

    return-object p0
.end method

.method public setQwertyMode(Z)V
    .locals 0

    iget-object p0, p0, Landroidx/appcompat/view/menu/Dt;->BAnRFn:Landroidx/appcompat/view/menu/ZfxDd;

    invoke-virtual {p0, p1}, Landroidx/appcompat/view/menu/ZfxDd;->setQwertyMode(Z)V

    return-void
.end method

.method public vI()Landroidx/appcompat/view/menu/ZfxDd;
    .locals 0

    iget-object p0, p0, Landroidx/appcompat/view/menu/Dt;->BAnRFn:Landroidx/appcompat/view/menu/ZfxDd;

    invoke-virtual {p0}, Landroidx/appcompat/view/menu/ZfxDd;->vI()Landroidx/appcompat/view/menu/ZfxDd;

    move-result-object p0

    return-object p0
.end method

.method public wJVbdd()Z
    .locals 0

    iget-object p0, p0, Landroidx/appcompat/view/menu/Dt;->BAnRFn:Landroidx/appcompat/view/menu/ZfxDd;

    invoke-virtual {p0}, Landroidx/appcompat/view/menu/ZfxDd;->wJVbdd()Z

    move-result p0

    return p0
.end method

.method public xJ(Landroidx/appcompat/view/menu/ZfxDd;Landroid/view/MenuItem;)Z
    .locals 1

    invoke-super {p0, p1, p2}, Landroidx/appcompat/view/menu/ZfxDd;->xJ(Landroidx/appcompat/view/menu/ZfxDd;Landroid/view/MenuItem;)Z

    move-result v0

    if-nez v0, :cond_1

    iget-object p0, p0, Landroidx/appcompat/view/menu/Dt;->BAnRFn:Landroidx/appcompat/view/menu/ZfxDd;

    invoke-virtual {p0, p1, p2}, Landroidx/appcompat/view/menu/ZfxDd;->xJ(Landroidx/appcompat/view/menu/ZfxDd;Landroid/view/MenuItem;)Z

    move-result p0

    if-eqz p0, :cond_0

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    goto :goto_1

    :cond_1
    :goto_0
    const/4 p0, 0x1

    :goto_1
    return p0
.end method
