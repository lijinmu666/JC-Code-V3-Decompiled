.class public Landroidx/appcompat/view/menu/qdMbNW$mjFkc;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/appcompat/view/menu/qdMbNW;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic mjFkc:Landroidx/appcompat/view/menu/qdMbNW;


# direct methods
.method public constructor <init>(Landroidx/appcompat/view/menu/qdMbNW;)V
    .locals 0

    iput-object p1, p0, Landroidx/appcompat/view/menu/qdMbNW$mjFkc;->mjFkc:Landroidx/appcompat/view/menu/qdMbNW;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onGlobalLayout()V
    .locals 1

    iget-object v0, p0, Landroidx/appcompat/view/menu/qdMbNW$mjFkc;->mjFkc:Landroidx/appcompat/view/menu/qdMbNW;

    invoke-virtual {v0}, Landroidx/appcompat/view/menu/qdMbNW;->Dt()Z

    move-result v0

    if-eqz v0, :cond_2

    iget-object v0, p0, Landroidx/appcompat/view/menu/qdMbNW$mjFkc;->mjFkc:Landroidx/appcompat/view/menu/qdMbNW;

    iget-object v0, v0, Landroidx/appcompat/view/menu/qdMbNW;->qdMbNW:Lo/Z1;

    invoke-virtual {v0}, Lo/a1;->rkYL()Z

    move-result v0

    if-nez v0, :cond_2

    iget-object v0, p0, Landroidx/appcompat/view/menu/qdMbNW$mjFkc;->mjFkc:Landroidx/appcompat/view/menu/qdMbNW;

    iget-object v0, v0, Landroidx/appcompat/view/menu/qdMbNW;->YoKzxo:Landroid/view/View;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Landroid/view/View;->isShown()Z

    move-result v0

    if-nez v0, :cond_0

    goto :goto_0

    :cond_0
    iget-object p0, p0, Landroidx/appcompat/view/menu/qdMbNW$mjFkc;->mjFkc:Landroidx/appcompat/view/menu/qdMbNW;

    iget-object p0, p0, Landroidx/appcompat/view/menu/qdMbNW;->qdMbNW:Lo/Z1;

    invoke-virtual {p0}, Lo/a1;->mjFkc()V

    goto :goto_1

    :cond_1
    :goto_0
    iget-object p0, p0, Landroidx/appcompat/view/menu/qdMbNW$mjFkc;->mjFkc:Landroidx/appcompat/view/menu/qdMbNW;

    invoke-virtual {p0}, Landroidx/appcompat/view/menu/qdMbNW;->ZfxDd()V

    :cond_2
    :goto_1
    return-void
.end method
