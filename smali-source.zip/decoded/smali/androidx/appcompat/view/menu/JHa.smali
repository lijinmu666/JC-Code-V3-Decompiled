.class public Landroidx/appcompat/view/menu/JHa;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/appcompat/view/menu/JHa$AZxh;
    }
.end annotation


# instance fields
.field public final AZxh:Landroidx/appcompat/view/menu/ZfxDd;

.field public Dt:Lo/Y1;

.field public ETF:Landroid/widget/PopupWindow$OnDismissListener;

.field public JHa:Landroid/view/View;

.field public final KLFTb:I

.field public final VA:Landroid/widget/PopupWindow$OnDismissListener;

.field public final ZfxDd:I

.field public lgHUyS:Z

.field public final mjFkc:Landroid/content/Context;

.field public qdMbNW:Landroidx/appcompat/view/menu/xJ$mjFkc;

.field public final wA:Z

.field public xJ:I


# direct methods
.method public constructor <init>(Landroid/content/Context;Landroidx/appcompat/view/menu/ZfxDd;Landroid/view/View;ZI)V
    .locals 7

    const/4 v6, 0x0

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v3, p3

    move v4, p4

    move v5, p5

    .line 1
    invoke-direct/range {v0 .. v6}, Landroidx/appcompat/view/menu/JHa;-><init>(Landroid/content/Context;Landroidx/appcompat/view/menu/ZfxDd;Landroid/view/View;ZII)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroidx/appcompat/view/menu/ZfxDd;Landroid/view/View;ZII)V
    .locals 1

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const v0, 0x800003

    .line 3
    iput v0, p0, Landroidx/appcompat/view/menu/JHa;->xJ:I

    .line 4
    new-instance v0, Landroidx/appcompat/view/menu/JHa$mjFkc;

    invoke-direct {v0, p0}, Landroidx/appcompat/view/menu/JHa$mjFkc;-><init>(Landroidx/appcompat/view/menu/JHa;)V

    iput-object v0, p0, Landroidx/appcompat/view/menu/JHa;->VA:Landroid/widget/PopupWindow$OnDismissListener;

    .line 5
    iput-object p1, p0, Landroidx/appcompat/view/menu/JHa;->mjFkc:Landroid/content/Context;

    .line 6
    iput-object p2, p0, Landroidx/appcompat/view/menu/JHa;->AZxh:Landroidx/appcompat/view/menu/ZfxDd;

    .line 7
    iput-object p3, p0, Landroidx/appcompat/view/menu/JHa;->JHa:Landroid/view/View;

    .line 8
    iput-boolean p4, p0, Landroidx/appcompat/view/menu/JHa;->wA:Z

    .line 9
    iput p5, p0, Landroidx/appcompat/view/menu/JHa;->ZfxDd:I

    .line 10
    iput p6, p0, Landroidx/appcompat/view/menu/JHa;->KLFTb:I

    return-void
.end method


# virtual methods
.method public AZxh()V
    .locals 1

    invoke-virtual {p0}, Landroidx/appcompat/view/menu/JHa;->ZfxDd()Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object p0, p0, Landroidx/appcompat/view/menu/JHa;->Dt:Lo/Y1;

    invoke-interface {p0}, Lo/Q6;->ZfxDd()V

    :cond_0
    return-void
.end method

.method public Dt(Landroidx/appcompat/view/menu/xJ$mjFkc;)V
    .locals 0

    iput-object p1, p0, Landroidx/appcompat/view/menu/JHa;->qdMbNW:Landroidx/appcompat/view/menu/xJ$mjFkc;

    iget-object p0, p0, Landroidx/appcompat/view/menu/JHa;->Dt:Lo/Y1;

    if-eqz p0, :cond_0

    invoke-interface {p0, p1}, Landroidx/appcompat/view/menu/xJ;->VA(Landroidx/appcompat/view/menu/xJ$mjFkc;)V

    :cond_0
    return-void
.end method

.method public ETF()V
    .locals 1

    invoke-virtual {p0}, Landroidx/appcompat/view/menu/JHa;->MiMN()Z

    move-result p0

    if-eqz p0, :cond_0

    return-void

    :cond_0
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string v0, "MenuPopupHelper cannot be used without an anchor"

    invoke-direct {p0, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public JHa(Landroid/view/View;)V
    .locals 0

    iput-object p1, p0, Landroidx/appcompat/view/menu/JHa;->JHa:Landroid/view/View;

    return-void
.end method

.method public KLFTb()V
    .locals 1

    const/4 v0, 0x0

    iput-object v0, p0, Landroidx/appcompat/view/menu/JHa;->Dt:Lo/Y1;

    iget-object p0, p0, Landroidx/appcompat/view/menu/JHa;->ETF:Landroid/widget/PopupWindow$OnDismissListener;

    if-eqz p0, :cond_0

    invoke-interface {p0}, Landroid/widget/PopupWindow$OnDismissListener;->onDismiss()V

    :cond_0
    return-void
.end method

.method public MiMN()Z
    .locals 3

    invoke-virtual {p0}, Landroidx/appcompat/view/menu/JHa;->ZfxDd()Z

    move-result v0

    const/4 v1, 0x1

    if-eqz v0, :cond_0

    return v1

    :cond_0
    iget-object v0, p0, Landroidx/appcompat/view/menu/JHa;->JHa:Landroid/view/View;

    const/4 v2, 0x0

    if-nez v0, :cond_1

    return v2

    :cond_1
    invoke-virtual {p0, v2, v2, v2, v2}, Landroidx/appcompat/view/menu/JHa;->VA(IIZZ)V

    return v1
.end method

.method public final VA(IIZZ)V
    .locals 2

    invoke-virtual {p0}, Landroidx/appcompat/view/menu/JHa;->wA()Lo/Y1;

    move-result-object v0

    invoke-virtual {v0, p4}, Lo/Y1;->huTpC(Z)V

    if-eqz p3, :cond_1

    iget p3, p0, Landroidx/appcompat/view/menu/JHa;->xJ:I

    iget-object p4, p0, Landroidx/appcompat/view/menu/JHa;->JHa:Landroid/view/View;

    invoke-static {p4}, Lo/T9;->huTpC(Landroid/view/View;)I

    move-result p4

    invoke-static {p3, p4}, Lo/l;->AZxh(II)I

    move-result p3

    and-int/lit8 p3, p3, 0x7

    const/4 p4, 0x5

    if-ne p3, p4, :cond_0

    iget-object p3, p0, Landroidx/appcompat/view/menu/JHa;->JHa:Landroid/view/View;

    invoke-virtual {p3}, Landroid/view/View;->getWidth()I

    move-result p3

    sub-int/2addr p1, p3

    :cond_0
    invoke-virtual {v0, p1}, Lo/Y1;->eyqo(I)V

    invoke-virtual {v0, p2}, Lo/Y1;->Gd(I)V

    iget-object p0, p0, Landroidx/appcompat/view/menu/JHa;->mjFkc:Landroid/content/Context;

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    invoke-virtual {p0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object p0

    iget p0, p0, Landroid/util/DisplayMetrics;->density:F

    const/high16 p3, 0x42400000    # 48.0f

    mul-float/2addr p0, p3

    const/high16 p3, 0x40000000    # 2.0f

    div-float/2addr p0, p3

    float-to-int p0, p0

    new-instance p3, Landroid/graphics/Rect;

    sub-int p4, p1, p0

    sub-int v1, p2, p0

    add-int/2addr p1, p0

    add-int/2addr p2, p0

    invoke-direct {p3, p4, v1, p1, p2}, Landroid/graphics/Rect;-><init>(IIII)V

    invoke-virtual {v0, p3}, Lo/Y1;->IEE(Landroid/graphics/Rect;)V

    :cond_1
    invoke-interface {v0}, Lo/Q6;->mjFkc()V

    return-void
.end method

.method public YoKzxo(II)Z
    .locals 2

    invoke-virtual {p0}, Landroidx/appcompat/view/menu/JHa;->ZfxDd()Z

    move-result v0

    const/4 v1, 0x1

    if-eqz v0, :cond_0

    return v1

    :cond_0
    iget-object v0, p0, Landroidx/appcompat/view/menu/JHa;->JHa:Landroid/view/View;

    if-nez v0, :cond_1

    const/4 p0, 0x0

    return p0

    :cond_1
    invoke-virtual {p0, p1, p2, v1, v1}, Landroidx/appcompat/view/menu/JHa;->VA(IIZZ)V

    return v1
.end method

.method public ZfxDd()Z
    .locals 0

    iget-object p0, p0, Landroidx/appcompat/view/menu/JHa;->Dt:Lo/Y1;

    if-eqz p0, :cond_0

    invoke-interface {p0}, Lo/Q6;->Dt()Z

    move-result p0

    if-eqz p0, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method

.method public lgHUyS(I)V
    .locals 0

    iput p1, p0, Landroidx/appcompat/view/menu/JHa;->xJ:I

    return-void
.end method

.method public final mjFkc()Lo/Y1;
    .locals 15

    iget-object v0, p0, Landroidx/appcompat/view/menu/JHa;->mjFkc:Landroid/content/Context;

    const-string v1, "window"

    invoke-virtual {v0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/view/WindowManager;

    invoke-interface {v0}, Landroid/view/WindowManager;->getDefaultDisplay()Landroid/view/Display;

    move-result-object v0

    new-instance v1, Landroid/graphics/Point;

    invoke-direct {v1}, Landroid/graphics/Point;-><init>()V

    invoke-static {v0, v1}, Landroidx/appcompat/view/menu/JHa$AZxh;->mjFkc(Landroid/view/Display;Landroid/graphics/Point;)V

    iget v0, v1, Landroid/graphics/Point;->x:I

    iget v1, v1, Landroid/graphics/Point;->y:I

    invoke-static {v0, v1}, Ljava/lang/Math;->min(II)I

    move-result v0

    iget-object v1, p0, Landroidx/appcompat/view/menu/JHa;->mjFkc:Landroid/content/Context;

    invoke-virtual {v1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    sget v2, Lo/o4;->mjFkc:I

    invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    move-result v1

    if-lt v0, v1, :cond_0

    new-instance v0, Landroidx/appcompat/view/menu/AZxh;

    iget-object v3, p0, Landroidx/appcompat/view/menu/JHa;->mjFkc:Landroid/content/Context;

    iget-object v4, p0, Landroidx/appcompat/view/menu/JHa;->JHa:Landroid/view/View;

    iget v5, p0, Landroidx/appcompat/view/menu/JHa;->ZfxDd:I

    iget v6, p0, Landroidx/appcompat/view/menu/JHa;->KLFTb:I

    iget-boolean v7, p0, Landroidx/appcompat/view/menu/JHa;->wA:Z

    move-object v2, v0

    invoke-direct/range {v2 .. v7}, Landroidx/appcompat/view/menu/AZxh;-><init>(Landroid/content/Context;Landroid/view/View;IIZ)V

    goto :goto_0

    :cond_0
    new-instance v0, Landroidx/appcompat/view/menu/qdMbNW;

    iget-object v9, p0, Landroidx/appcompat/view/menu/JHa;->mjFkc:Landroid/content/Context;

    iget-object v10, p0, Landroidx/appcompat/view/menu/JHa;->AZxh:Landroidx/appcompat/view/menu/ZfxDd;

    iget-object v11, p0, Landroidx/appcompat/view/menu/JHa;->JHa:Landroid/view/View;

    iget v12, p0, Landroidx/appcompat/view/menu/JHa;->ZfxDd:I

    iget v13, p0, Landroidx/appcompat/view/menu/JHa;->KLFTb:I

    iget-boolean v14, p0, Landroidx/appcompat/view/menu/JHa;->wA:Z

    move-object v8, v0

    invoke-direct/range {v8 .. v14}, Landroidx/appcompat/view/menu/qdMbNW;-><init>(Landroid/content/Context;Landroidx/appcompat/view/menu/ZfxDd;Landroid/view/View;IIZ)V

    :goto_0
    iget-object v1, p0, Landroidx/appcompat/view/menu/JHa;->AZxh:Landroidx/appcompat/view/menu/ZfxDd;

    invoke-virtual {v0, v1}, Lo/Y1;->MiMN(Landroidx/appcompat/view/menu/ZfxDd;)V

    iget-object v1, p0, Landroidx/appcompat/view/menu/JHa;->VA:Landroid/widget/PopupWindow$OnDismissListener;

    invoke-virtual {v0, v1}, Lo/Y1;->Ucbh(Landroid/widget/PopupWindow$OnDismissListener;)V

    iget-object v1, p0, Landroidx/appcompat/view/menu/JHa;->JHa:Landroid/view/View;

    invoke-virtual {v0, v1}, Lo/Y1;->fehf(Landroid/view/View;)V

    iget-object v1, p0, Landroidx/appcompat/view/menu/JHa;->qdMbNW:Landroidx/appcompat/view/menu/xJ$mjFkc;

    invoke-interface {v0, v1}, Landroidx/appcompat/view/menu/xJ;->VA(Landroidx/appcompat/view/menu/xJ$mjFkc;)V

    iget-boolean v1, p0, Landroidx/appcompat/view/menu/JHa;->lgHUyS:Z

    invoke-virtual {v0, v1}, Lo/Y1;->Pq(Z)V

    iget p0, p0, Landroidx/appcompat/view/menu/JHa;->xJ:I

    invoke-virtual {v0, p0}, Lo/Y1;->diqgf(I)V

    return-object v0
.end method

.method public qdMbNW(Landroid/widget/PopupWindow$OnDismissListener;)V
    .locals 0

    iput-object p1, p0, Landroidx/appcompat/view/menu/JHa;->ETF:Landroid/widget/PopupWindow$OnDismissListener;

    return-void
.end method

.method public wA()Lo/Y1;
    .locals 1

    iget-object v0, p0, Landroidx/appcompat/view/menu/JHa;->Dt:Lo/Y1;

    if-nez v0, :cond_0

    invoke-virtual {p0}, Landroidx/appcompat/view/menu/JHa;->mjFkc()Lo/Y1;

    move-result-object v0

    iput-object v0, p0, Landroidx/appcompat/view/menu/JHa;->Dt:Lo/Y1;

    :cond_0
    iget-object p0, p0, Landroidx/appcompat/view/menu/JHa;->Dt:Lo/Y1;

    return-object p0
.end method

.method public xJ(Z)V
    .locals 0

    iput-boolean p1, p0, Landroidx/appcompat/view/menu/JHa;->lgHUyS:Z

    iget-object p0, p0, Landroidx/appcompat/view/menu/JHa;->Dt:Lo/Y1;

    if-eqz p0, :cond_0

    invoke-virtual {p0, p1}, Lo/Y1;->Pq(Z)V

    :cond_0
    return-void
.end method
