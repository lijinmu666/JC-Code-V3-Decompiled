.class public final Landroidx/appcompat/view/menu/AZxh;
.super Lo/Y1;
.source "SourceFile"

# interfaces
.implements Landroidx/appcompat/view/menu/xJ;
.implements Landroid/view/View$OnKeyListener;
.implements Landroid/widget/PopupWindow$OnDismissListener;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/appcompat/view/menu/AZxh$ZfxDd;
    }
.end annotation


# static fields
.field public static final BAnRFn:I


# instance fields
.field public final AZxh:Landroid/content/Context;

.field public final Dt:Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;

.field public final ETF:Landroid/view/View$OnAttachStateChangeListener;

.field public Gd:Landroidx/appcompat/view/menu/xJ$mjFkc;

.field public HGpJ:Landroid/view/ViewTreeObserver;

.field public IEE:Z

.field public final JHa:Z

.field public final KLFTb:I

.field public MiMN:I

.field public Pq:Z

.field public Ucbh:Z

.field public final VA:Lo/X1;

.field public VocHEe:Z

.field public YoKzxo:I

.field public final ZfxDd:I

.field public diqgf:I

.field public eyqo:I

.field public fehf:I

.field public huTpC:Z

.field public final lgHUyS:Ljava/util/List;

.field public qGY:Landroid/view/View;

.field public final qdMbNW:Ljava/util/List;

.field public rkYL:Landroid/view/View;

.field public vI:Landroid/widget/PopupWindow$OnDismissListener;

.field public final wA:I

.field public final xJ:Landroid/os/Handler;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    sget v0, Lo/I4;->KLFTb:I

    sput v0, Landroidx/appcompat/view/menu/AZxh;->BAnRFn:I

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/view/View;IIZ)V
    .locals 1

    invoke-direct {p0}, Lo/Y1;-><init>()V

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Landroidx/appcompat/view/menu/AZxh;->lgHUyS:Ljava/util/List;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Landroidx/appcompat/view/menu/AZxh;->qdMbNW:Ljava/util/List;

    new-instance v0, Landroidx/appcompat/view/menu/AZxh$mjFkc;

    invoke-direct {v0, p0}, Landroidx/appcompat/view/menu/AZxh$mjFkc;-><init>(Landroidx/appcompat/view/menu/AZxh;)V

    iput-object v0, p0, Landroidx/appcompat/view/menu/AZxh;->Dt:Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;

    new-instance v0, Landroidx/appcompat/view/menu/AZxh$AZxh;

    invoke-direct {v0, p0}, Landroidx/appcompat/view/menu/AZxh$AZxh;-><init>(Landroidx/appcompat/view/menu/AZxh;)V

    iput-object v0, p0, Landroidx/appcompat/view/menu/AZxh;->ETF:Landroid/view/View$OnAttachStateChangeListener;

    new-instance v0, Landroidx/appcompat/view/menu/AZxh$wA;

    invoke-direct {v0, p0}, Landroidx/appcompat/view/menu/AZxh$wA;-><init>(Landroidx/appcompat/view/menu/AZxh;)V

    iput-object v0, p0, Landroidx/appcompat/view/menu/AZxh;->VA:Lo/X1;

    const/4 v0, 0x0

    iput v0, p0, Landroidx/appcompat/view/menu/AZxh;->MiMN:I

    iput v0, p0, Landroidx/appcompat/view/menu/AZxh;->YoKzxo:I

    iput-object p1, p0, Landroidx/appcompat/view/menu/AZxh;->AZxh:Landroid/content/Context;

    iput-object p2, p0, Landroidx/appcompat/view/menu/AZxh;->rkYL:Landroid/view/View;

    iput p3, p0, Landroidx/appcompat/view/menu/AZxh;->ZfxDd:I

    iput p4, p0, Landroidx/appcompat/view/menu/AZxh;->KLFTb:I

    iput-boolean p5, p0, Landroidx/appcompat/view/menu/AZxh;->JHa:Z

    iput-boolean v0, p0, Landroidx/appcompat/view/menu/AZxh;->Ucbh:Z

    invoke-virtual {p0}, Landroidx/appcompat/view/menu/AZxh;->mByQ()I

    move-result p2

    iput p2, p0, Landroidx/appcompat/view/menu/AZxh;->fehf:I

    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p1

    invoke-virtual {p1}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object p2

    iget p2, p2, Landroid/util/DisplayMetrics;->widthPixels:I

    div-int/lit8 p2, p2, 0x2

    sget p3, Lo/o4;->AZxh:I

    invoke-virtual {p1, p3}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    move-result p1

    invoke-static {p2, p1}, Ljava/lang/Math;->max(II)I

    move-result p1

    iput p1, p0, Landroidx/appcompat/view/menu/AZxh;->wA:I

    new-instance p1, Landroid/os/Handler;

    invoke-direct {p1}, Landroid/os/Handler;-><init>()V

    iput-object p1, p0, Landroidx/appcompat/view/menu/AZxh;->xJ:Landroid/os/Handler;

    return-void
.end method


# virtual methods
.method public AZxh(Landroidx/appcompat/view/menu/ZfxDd;Z)V
    .locals 5

    invoke-virtual {p0, p1}, Landroidx/appcompat/view/menu/AZxh;->BAnRFn(Landroidx/appcompat/view/menu/ZfxDd;)I

    move-result v0

    if-gez v0, :cond_0

    return-void

    :cond_0
    add-int/lit8 v1, v0, 0x1

    iget-object v2, p0, Landroidx/appcompat/view/menu/AZxh;->qdMbNW:Ljava/util/List;

    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result v2

    const/4 v3, 0x0

    if-ge v1, v2, :cond_1

    iget-object v2, p0, Landroidx/appcompat/view/menu/AZxh;->qdMbNW:Ljava/util/List;

    invoke-interface {v2, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroidx/appcompat/view/menu/AZxh$ZfxDd;

    iget-object v1, v1, Landroidx/appcompat/view/menu/AZxh$ZfxDd;->AZxh:Landroidx/appcompat/view/menu/ZfxDd;

    invoke-virtual {v1, v3}, Landroidx/appcompat/view/menu/ZfxDd;->ZfxDd(Z)V

    :cond_1
    iget-object v1, p0, Landroidx/appcompat/view/menu/AZxh;->qdMbNW:Ljava/util/List;

    invoke-interface {v1, v0}, Ljava/util/List;->remove(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroidx/appcompat/view/menu/AZxh$ZfxDd;

    iget-object v1, v0, Landroidx/appcompat/view/menu/AZxh$ZfxDd;->AZxh:Landroidx/appcompat/view/menu/ZfxDd;

    invoke-virtual {v1, p0}, Landroidx/appcompat/view/menu/ZfxDd;->zvd(Landroidx/appcompat/view/menu/xJ;)V

    iget-boolean v1, p0, Landroidx/appcompat/view/menu/AZxh;->VocHEe:Z

    const/4 v2, 0x0

    if-eqz v1, :cond_2

    iget-object v1, v0, Landroidx/appcompat/view/menu/AZxh$ZfxDd;->mjFkc:Lo/Z1;

    invoke-virtual {v1, v2}, Lo/Z1;->Ne(Ljava/lang/Object;)V

    iget-object v1, v0, Landroidx/appcompat/view/menu/AZxh$ZfxDd;->mjFkc:Lo/Z1;

    invoke-virtual {v1, v3}, Lo/a1;->Pq(I)V

    :cond_2
    iget-object v0, v0, Landroidx/appcompat/view/menu/AZxh$ZfxDd;->mjFkc:Lo/Z1;

    invoke-virtual {v0}, Lo/a1;->ZfxDd()V

    iget-object v0, p0, Landroidx/appcompat/view/menu/AZxh;->qdMbNW:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    if-lez v0, :cond_3

    iget-object v1, p0, Landroidx/appcompat/view/menu/AZxh;->qdMbNW:Ljava/util/List;

    add-int/lit8 v4, v0, -0x1

    invoke-interface {v1, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroidx/appcompat/view/menu/AZxh$ZfxDd;

    iget v1, v1, Landroidx/appcompat/view/menu/AZxh$ZfxDd;->wA:I

    iput v1, p0, Landroidx/appcompat/view/menu/AZxh;->fehf:I

    goto :goto_0

    :cond_3
    invoke-virtual {p0}, Landroidx/appcompat/view/menu/AZxh;->mByQ()I

    move-result v1

    iput v1, p0, Landroidx/appcompat/view/menu/AZxh;->fehf:I

    :goto_0
    if-nez v0, :cond_7

    invoke-virtual {p0}, Landroidx/appcompat/view/menu/AZxh;->ZfxDd()V

    iget-object p2, p0, Landroidx/appcompat/view/menu/AZxh;->Gd:Landroidx/appcompat/view/menu/xJ$mjFkc;

    if-eqz p2, :cond_4

    const/4 v0, 0x1

    invoke-interface {p2, p1, v0}, Landroidx/appcompat/view/menu/xJ$mjFkc;->AZxh(Landroidx/appcompat/view/menu/ZfxDd;Z)V

    :cond_4
    iget-object p1, p0, Landroidx/appcompat/view/menu/AZxh;->HGpJ:Landroid/view/ViewTreeObserver;

    if-eqz p1, :cond_6

    invoke-virtual {p1}, Landroid/view/ViewTreeObserver;->isAlive()Z

    move-result p1

    if-eqz p1, :cond_5

    iget-object p1, p0, Landroidx/appcompat/view/menu/AZxh;->HGpJ:Landroid/view/ViewTreeObserver;

    iget-object p2, p0, Landroidx/appcompat/view/menu/AZxh;->Dt:Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;

    invoke-virtual {p1, p2}, Landroid/view/ViewTreeObserver;->removeGlobalOnLayoutListener(Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;)V

    :cond_5
    iput-object v2, p0, Landroidx/appcompat/view/menu/AZxh;->HGpJ:Landroid/view/ViewTreeObserver;

    :cond_6
    iget-object p1, p0, Landroidx/appcompat/view/menu/AZxh;->qGY:Landroid/view/View;

    iget-object p2, p0, Landroidx/appcompat/view/menu/AZxh;->ETF:Landroid/view/View$OnAttachStateChangeListener;

    invoke-virtual {p1, p2}, Landroid/view/View;->removeOnAttachStateChangeListener(Landroid/view/View$OnAttachStateChangeListener;)V

    iget-object p0, p0, Landroidx/appcompat/view/menu/AZxh;->vI:Landroid/widget/PopupWindow$OnDismissListener;

    invoke-interface {p0}, Landroid/widget/PopupWindow$OnDismissListener;->onDismiss()V

    goto :goto_1

    :cond_7
    if-eqz p2, :cond_8

    iget-object p0, p0, Landroidx/appcompat/view/menu/AZxh;->qdMbNW:Ljava/util/List;

    invoke-interface {p0, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroidx/appcompat/view/menu/AZxh$ZfxDd;

    iget-object p0, p0, Landroidx/appcompat/view/menu/AZxh$ZfxDd;->AZxh:Landroidx/appcompat/view/menu/ZfxDd;

    invoke-virtual {p0, v3}, Landroidx/appcompat/view/menu/ZfxDd;->ZfxDd(Z)V

    :cond_8
    :goto_1
    return-void
.end method

.method public final BAnRFn(Landroidx/appcompat/view/menu/ZfxDd;)I
    .locals 3

    iget-object v0, p0, Landroidx/appcompat/view/menu/AZxh;->qdMbNW:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    const/4 v1, 0x0

    :goto_0
    if-ge v1, v0, :cond_1

    iget-object v2, p0, Landroidx/appcompat/view/menu/AZxh;->qdMbNW:Ljava/util/List;

    invoke-interface {v2, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroidx/appcompat/view/menu/AZxh$ZfxDd;

    iget-object v2, v2, Landroidx/appcompat/view/menu/AZxh$ZfxDd;->AZxh:Landroidx/appcompat/view/menu/ZfxDd;

    if-ne p1, v2, :cond_0

    return v1

    :cond_0
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_1
    const/4 p0, -0x1

    return p0
.end method

.method public Dt()Z
    .locals 2

    iget-object v0, p0, Landroidx/appcompat/view/menu/AZxh;->qdMbNW:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    const/4 v1, 0x0

    if-lez v0, :cond_0

    iget-object p0, p0, Landroidx/appcompat/view/menu/AZxh;->qdMbNW:Ljava/util/List;

    invoke-interface {p0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroidx/appcompat/view/menu/AZxh$ZfxDd;

    iget-object p0, p0, Landroidx/appcompat/view/menu/AZxh$ZfxDd;->mjFkc:Lo/Z1;

    invoke-virtual {p0}, Lo/a1;->Dt()Z

    move-result p0

    if-eqz p0, :cond_0

    const/4 v1, 0x1

    :cond_0
    return v1
.end method

.method public Gd(I)V
    .locals 1

    const/4 v0, 0x1

    iput-boolean v0, p0, Landroidx/appcompat/view/menu/AZxh;->Pq:Z

    iput p1, p0, Landroidx/appcompat/view/menu/AZxh;->eyqo:I

    return-void
.end method

.method public JHa(Landroidx/appcompat/view/menu/Dt;)Z
    .locals 4

    iget-object v0, p0, Landroidx/appcompat/view/menu/AZxh;->qdMbNW:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v2, 0x1

    if-eqz v1, :cond_1

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroidx/appcompat/view/menu/AZxh$ZfxDd;

    iget-object v3, v1, Landroidx/appcompat/view/menu/AZxh$ZfxDd;->AZxh:Landroidx/appcompat/view/menu/ZfxDd;

    if-ne p1, v3, :cond_0

    invoke-virtual {v1}, Landroidx/appcompat/view/menu/AZxh$ZfxDd;->mjFkc()Landroid/widget/ListView;

    move-result-object p0

    invoke-virtual {p0}, Landroid/view/View;->requestFocus()Z

    return v2

    :cond_1
    invoke-virtual {p1}, Landroidx/appcompat/view/menu/ZfxDd;->hasVisibleItems()Z

    move-result v0

    if-eqz v0, :cond_3

    invoke-virtual {p0, p1}, Landroidx/appcompat/view/menu/AZxh;->MiMN(Landroidx/appcompat/view/menu/ZfxDd;)V

    iget-object p0, p0, Landroidx/appcompat/view/menu/AZxh;->Gd:Landroidx/appcompat/view/menu/xJ$mjFkc;

    if-eqz p0, :cond_2

    invoke-interface {p0, p1}, Landroidx/appcompat/view/menu/xJ$mjFkc;->wA(Landroidx/appcompat/view/menu/ZfxDd;)Z

    :cond_2
    return v2

    :cond_3
    const/4 p0, 0x0

    return p0
.end method

.method public KLFTb()Landroid/widget/ListView;
    .locals 1

    iget-object v0, p0, Landroidx/appcompat/view/menu/AZxh;->qdMbNW:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 p0, 0x0

    goto :goto_0

    :cond_0
    iget-object p0, p0, Landroidx/appcompat/view/menu/AZxh;->qdMbNW:Ljava/util/List;

    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v0

    add-int/lit8 v0, v0, -0x1

    invoke-interface {p0, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroidx/appcompat/view/menu/AZxh$ZfxDd;

    invoke-virtual {p0}, Landroidx/appcompat/view/menu/AZxh$ZfxDd;->mjFkc()Landroid/widget/ListView;

    move-result-object p0

    :goto_0
    return-object p0
.end method

.method public MiMN(Landroidx/appcompat/view/menu/ZfxDd;)V
    .locals 1

    iget-object v0, p0, Landroidx/appcompat/view/menu/AZxh;->AZxh:Landroid/content/Context;

    invoke-virtual {p1, p0, v0}, Landroidx/appcompat/view/menu/ZfxDd;->AZxh(Landroidx/appcompat/view/menu/xJ;Landroid/content/Context;)V

    invoke-virtual {p0}, Landroidx/appcompat/view/menu/AZxh;->Dt()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-virtual {p0, p1}, Landroidx/appcompat/view/menu/AZxh;->Ne(Landroidx/appcompat/view/menu/ZfxDd;)V

    goto :goto_0

    :cond_0
    iget-object p0, p0, Landroidx/appcompat/view/menu/AZxh;->lgHUyS:Ljava/util/List;

    invoke-interface {p0, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :goto_0
    return-void
.end method

.method public final Ne(Landroidx/appcompat/view/menu/ZfxDd;)V
    .locals 11

    iget-object v0, p0, Landroidx/appcompat/view/menu/AZxh;->AZxh:Landroid/content/Context;

    invoke-static {v0}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object v0

    new-instance v1, Landroidx/appcompat/view/menu/wA;

    iget-boolean v2, p0, Landroidx/appcompat/view/menu/AZxh;->JHa:Z

    sget v3, Landroidx/appcompat/view/menu/AZxh;->BAnRFn:I

    invoke-direct {v1, p1, v0, v2, v3}, Landroidx/appcompat/view/menu/wA;-><init>(Landroidx/appcompat/view/menu/ZfxDd;Landroid/view/LayoutInflater;ZI)V

    invoke-virtual {p0}, Landroidx/appcompat/view/menu/AZxh;->Dt()Z

    move-result v2

    const/4 v3, 0x1

    if-nez v2, :cond_0

    iget-boolean v2, p0, Landroidx/appcompat/view/menu/AZxh;->Ucbh:Z

    if-eqz v2, :cond_0

    invoke-virtual {v1, v3}, Landroidx/appcompat/view/menu/wA;->ZfxDd(Z)V

    goto :goto_0

    :cond_0
    invoke-virtual {p0}, Landroidx/appcompat/view/menu/AZxh;->Dt()Z

    move-result v2

    if-eqz v2, :cond_1

    invoke-static {p1}, Lo/Y1;->HGpJ(Landroidx/appcompat/view/menu/ZfxDd;)Z

    move-result v2

    invoke-virtual {v1, v2}, Landroidx/appcompat/view/menu/wA;->ZfxDd(Z)V

    :cond_1
    :goto_0
    iget-object v2, p0, Landroidx/appcompat/view/menu/AZxh;->AZxh:Landroid/content/Context;

    iget v4, p0, Landroidx/appcompat/view/menu/AZxh;->wA:I

    const/4 v5, 0x0

    invoke-static {v1, v5, v2, v4}, Lo/Y1;->qGY(Landroid/widget/ListAdapter;Landroid/view/ViewGroup;Landroid/content/Context;I)I

    move-result v2

    invoke-virtual {p0}, Landroidx/appcompat/view/menu/AZxh;->VocHEe()Lo/Z1;

    move-result-object v4

    invoke-virtual {v4, v1}, Lo/a1;->fehf(Landroid/widget/ListAdapter;)V

    invoke-virtual {v4, v2}, Lo/a1;->diqgf(I)V

    iget v1, p0, Landroidx/appcompat/view/menu/AZxh;->YoKzxo:I

    invoke-virtual {v4, v1}, Lo/a1;->eyqo(I)V

    iget-object v1, p0, Landroidx/appcompat/view/menu/AZxh;->qdMbNW:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v1

    if-lez v1, :cond_2

    iget-object v1, p0, Landroidx/appcompat/view/menu/AZxh;->qdMbNW:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v6

    sub-int/2addr v6, v3

    invoke-interface {v1, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroidx/appcompat/view/menu/AZxh$ZfxDd;

    invoke-virtual {p0, v1, p1}, Landroidx/appcompat/view/menu/AZxh;->wJVbdd(Landroidx/appcompat/view/menu/AZxh$ZfxDd;Landroidx/appcompat/view/menu/ZfxDd;)Landroid/view/View;

    move-result-object v6

    goto :goto_1

    :cond_2
    move-object v1, v5

    move-object v6, v1

    :goto_1
    const/4 v7, 0x0

    if-eqz v6, :cond_7

    invoke-virtual {v4, v7}, Lo/Z1;->xrEuO(Z)V

    invoke-virtual {v4, v5}, Lo/Z1;->OjSQV(Ljava/lang/Object;)V

    invoke-virtual {p0, v2}, Landroidx/appcompat/view/menu/AZxh;->OjSQV(I)I

    move-result v8

    if-ne v8, v3, :cond_3

    move v9, v3

    goto :goto_2

    :cond_3
    move v9, v7

    :goto_2
    iput v8, p0, Landroidx/appcompat/view/menu/AZxh;->fehf:I

    invoke-virtual {v4, v6}, Lo/a1;->IEE(Landroid/view/View;)V

    iget v8, p0, Landroidx/appcompat/view/menu/AZxh;->YoKzxo:I

    const/4 v10, 0x5

    and-int/2addr v8, v10

    if-ne v8, v10, :cond_5

    if-eqz v9, :cond_4

    goto :goto_3

    :cond_4
    invoke-virtual {v6}, Landroid/view/View;->getWidth()I

    move-result v2

    rsub-int/lit8 v2, v2, 0x0

    goto :goto_3

    :cond_5
    if-eqz v9, :cond_6

    invoke-virtual {v6}, Landroid/view/View;->getWidth()I

    move-result v2

    goto :goto_3

    :cond_6
    rsub-int/lit8 v2, v2, 0x0

    :goto_3
    invoke-virtual {v4, v2}, Lo/a1;->huTpC(I)V

    invoke-virtual {v4, v3}, Lo/a1;->BAnRFn(Z)V

    invoke-virtual {v4, v7}, Lo/a1;->wJVbdd(I)V

    goto :goto_4

    :cond_7
    iget-boolean v2, p0, Landroidx/appcompat/view/menu/AZxh;->IEE:Z

    if-eqz v2, :cond_8

    iget v2, p0, Landroidx/appcompat/view/menu/AZxh;->diqgf:I

    invoke-virtual {v4, v2}, Lo/a1;->huTpC(I)V

    :cond_8
    iget-boolean v2, p0, Landroidx/appcompat/view/menu/AZxh;->Pq:Z

    if-eqz v2, :cond_9

    iget v2, p0, Landroidx/appcompat/view/menu/AZxh;->eyqo:I

    invoke-virtual {v4, v2}, Lo/a1;->wJVbdd(I)V

    :cond_9
    invoke-virtual {p0}, Lo/Y1;->rkYL()Landroid/graphics/Rect;

    move-result-object v2

    invoke-virtual {v4, v2}, Lo/a1;->Ucbh(Landroid/graphics/Rect;)V

    :goto_4
    new-instance v2, Landroidx/appcompat/view/menu/AZxh$ZfxDd;

    iget v3, p0, Landroidx/appcompat/view/menu/AZxh;->fehf:I

    invoke-direct {v2, v4, p1, v3}, Landroidx/appcompat/view/menu/AZxh$ZfxDd;-><init>(Lo/Z1;Landroidx/appcompat/view/menu/ZfxDd;I)V

    iget-object v3, p0, Landroidx/appcompat/view/menu/AZxh;->qdMbNW:Ljava/util/List;

    invoke-interface {v3, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    invoke-virtual {v4}, Lo/a1;->mjFkc()V

    invoke-virtual {v4}, Lo/a1;->KLFTb()Landroid/widget/ListView;

    move-result-object v2

    invoke-virtual {v2, p0}, Landroid/view/View;->setOnKeyListener(Landroid/view/View$OnKeyListener;)V

    if-nez v1, :cond_a

    iget-boolean p0, p0, Landroidx/appcompat/view/menu/AZxh;->huTpC:Z

    if-eqz p0, :cond_a

    invoke-virtual {p1}, Landroidx/appcompat/view/menu/ZfxDd;->eyqo()Ljava/lang/CharSequence;

    move-result-object p0

    if-eqz p0, :cond_a

    sget p0, Lo/I4;->qdMbNW:I

    invoke-virtual {v0, p0, v2, v7}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object p0

    check-cast p0, Landroid/widget/FrameLayout;

    const v0, 0x1020016

    invoke-virtual {p0, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    invoke-virtual {p0, v7}, Landroid/view/View;->setEnabled(Z)V

    invoke-virtual {p1}, Landroidx/appcompat/view/menu/ZfxDd;->eyqo()Ljava/lang/CharSequence;

    move-result-object p1

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-virtual {v2, p0, v5, v7}, Landroid/widget/ListView;->addHeaderView(Landroid/view/View;Ljava/lang/Object;Z)V

    invoke-virtual {v4}, Lo/a1;->mjFkc()V

    :cond_a
    return-void
.end method

.method public final OjSQV(I)I
    .locals 5

    iget-object v0, p0, Landroidx/appcompat/view/menu/AZxh;->qdMbNW:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v1

    const/4 v2, 0x1

    sub-int/2addr v1, v2

    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroidx/appcompat/view/menu/AZxh$ZfxDd;

    invoke-virtual {v0}, Landroidx/appcompat/view/menu/AZxh$ZfxDd;->mjFkc()Landroid/widget/ListView;

    move-result-object v0

    const/4 v1, 0x2

    new-array v1, v1, [I

    invoke-virtual {v0, v1}, Landroid/view/View;->getLocationOnScreen([I)V

    new-instance v3, Landroid/graphics/Rect;

    invoke-direct {v3}, Landroid/graphics/Rect;-><init>()V

    iget-object v4, p0, Landroidx/appcompat/view/menu/AZxh;->qGY:Landroid/view/View;

    invoke-virtual {v4, v3}, Landroid/view/View;->getWindowVisibleDisplayFrame(Landroid/graphics/Rect;)V

    iget p0, p0, Landroidx/appcompat/view/menu/AZxh;->fehf:I

    const/4 v4, 0x0

    if-ne p0, v2, :cond_1

    aget p0, v1, v4

    invoke-virtual {v0}, Landroid/view/View;->getWidth()I

    move-result v0

    add-int/2addr p0, v0

    add-int/2addr p0, p1

    iget p1, v3, Landroid/graphics/Rect;->right:I

    if-le p0, p1, :cond_0

    return v4

    :cond_0
    return v2

    :cond_1
    aget p0, v1, v4

    sub-int/2addr p0, p1

    if-gez p0, :cond_2

    return v2

    :cond_2
    return v4
.end method

.method public Pq(Z)V
    .locals 0

    iput-boolean p1, p0, Landroidx/appcompat/view/menu/AZxh;->Ucbh:Z

    return-void
.end method

.method public Ucbh(Landroid/widget/PopupWindow$OnDismissListener;)V
    .locals 0

    iput-object p1, p0, Landroidx/appcompat/view/menu/AZxh;->vI:Landroid/widget/PopupWindow$OnDismissListener;

    return-void
.end method

.method public VA(Landroidx/appcompat/view/menu/xJ$mjFkc;)V
    .locals 0

    iput-object p1, p0, Landroidx/appcompat/view/menu/AZxh;->Gd:Landroidx/appcompat/view/menu/xJ$mjFkc;

    return-void
.end method

.method public final VocHEe()Lo/Z1;
    .locals 5

    new-instance v0, Lo/Z1;

    iget-object v1, p0, Landroidx/appcompat/view/menu/AZxh;->AZxh:Landroid/content/Context;

    iget v2, p0, Landroidx/appcompat/view/menu/AZxh;->ZfxDd:I

    iget v3, p0, Landroidx/appcompat/view/menu/AZxh;->KLFTb:I

    const/4 v4, 0x0

    invoke-direct {v0, v1, v4, v2, v3}, Lo/Z1;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;II)V

    iget-object v1, p0, Landroidx/appcompat/view/menu/AZxh;->VA:Lo/X1;

    invoke-virtual {v0, v1}, Lo/Z1;->CqaNbM(Lo/X1;)V

    invoke-virtual {v0, p0}, Lo/a1;->VocHEe(Landroid/widget/AdapterView$OnItemClickListener;)V

    invoke-virtual {v0, p0}, Lo/a1;->vI(Landroid/widget/PopupWindow$OnDismissListener;)V

    iget-object v1, p0, Landroidx/appcompat/view/menu/AZxh;->rkYL:Landroid/view/View;

    invoke-virtual {v0, v1}, Lo/a1;->IEE(Landroid/view/View;)V

    iget p0, p0, Landroidx/appcompat/view/menu/AZxh;->YoKzxo:I

    invoke-virtual {v0, p0}, Lo/a1;->eyqo(I)V

    const/4 p0, 0x1

    invoke-virtual {v0, p0}, Lo/a1;->HGpJ(Z)V

    const/4 p0, 0x2

    invoke-virtual {v0, p0}, Lo/a1;->Gd(I)V

    return-object v0
.end method

.method public YoKzxo()Z
    .locals 0

    const/4 p0, 0x0

    return p0
.end method

.method public ZfxDd()V
    .locals 3

    iget-object v0, p0, Landroidx/appcompat/view/menu/AZxh;->qdMbNW:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    if-lez v0, :cond_1

    iget-object p0, p0, Landroidx/appcompat/view/menu/AZxh;->qdMbNW:Ljava/util/List;

    new-array v1, v0, [Landroidx/appcompat/view/menu/AZxh$ZfxDd;

    invoke-interface {p0, v1}, Ljava/util/List;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object p0

    check-cast p0, [Landroidx/appcompat/view/menu/AZxh$ZfxDd;

    add-int/lit8 v0, v0, -0x1

    :goto_0
    if-ltz v0, :cond_1

    aget-object v1, p0, v0

    iget-object v2, v1, Landroidx/appcompat/view/menu/AZxh$ZfxDd;->mjFkc:Lo/Z1;

    invoke-virtual {v2}, Lo/a1;->Dt()Z

    move-result v2

    if-eqz v2, :cond_0

    iget-object v1, v1, Landroidx/appcompat/view/menu/AZxh$ZfxDd;->mjFkc:Lo/Z1;

    invoke-virtual {v1}, Lo/a1;->ZfxDd()V

    :cond_0
    add-int/lit8 v0, v0, -0x1

    goto :goto_0

    :cond_1
    return-void
.end method

.method public diqgf(I)V
    .locals 1

    iget v0, p0, Landroidx/appcompat/view/menu/AZxh;->MiMN:I

    if-eq v0, p1, :cond_0

    iput p1, p0, Landroidx/appcompat/view/menu/AZxh;->MiMN:I

    iget-object v0, p0, Landroidx/appcompat/view/menu/AZxh;->rkYL:Landroid/view/View;

    invoke-static {v0}, Lo/T9;->huTpC(Landroid/view/View;)I

    move-result v0

    invoke-static {p1, v0}, Lo/l;->AZxh(II)I

    move-result p1

    iput p1, p0, Landroidx/appcompat/view/menu/AZxh;->YoKzxo:I

    :cond_0
    return-void
.end method

.method public eyqo(I)V
    .locals 1

    const/4 v0, 0x1

    iput-boolean v0, p0, Landroidx/appcompat/view/menu/AZxh;->IEE:Z

    iput p1, p0, Landroidx/appcompat/view/menu/AZxh;->diqgf:I

    return-void
.end method

.method public fehf(Landroid/view/View;)V
    .locals 1

    iget-object v0, p0, Landroidx/appcompat/view/menu/AZxh;->rkYL:Landroid/view/View;

    if-eq v0, p1, :cond_0

    iput-object p1, p0, Landroidx/appcompat/view/menu/AZxh;->rkYL:Landroid/view/View;

    iget v0, p0, Landroidx/appcompat/view/menu/AZxh;->MiMN:I

    invoke-static {p1}, Lo/T9;->huTpC(Landroid/view/View;)I

    move-result p1

    invoke-static {v0, p1}, Lo/l;->AZxh(II)I

    move-result p1

    iput p1, p0, Landroidx/appcompat/view/menu/AZxh;->YoKzxo:I

    :cond_0
    return-void
.end method

.method public huTpC(Z)V
    .locals 0

    iput-boolean p1, p0, Landroidx/appcompat/view/menu/AZxh;->huTpC:Z

    return-void
.end method

.method public final lB(Landroidx/appcompat/view/menu/ZfxDd;Landroidx/appcompat/view/menu/ZfxDd;)Landroid/view/MenuItem;
    .locals 3

    invoke-virtual {p1}, Landroidx/appcompat/view/menu/ZfxDd;->size()I

    move-result p0

    const/4 v0, 0x0

    :goto_0
    if-ge v0, p0, :cond_1

    invoke-virtual {p1, v0}, Landroidx/appcompat/view/menu/ZfxDd;->getItem(I)Landroid/view/MenuItem;

    move-result-object v1

    invoke-interface {v1}, Landroid/view/MenuItem;->hasSubMenu()Z

    move-result v2

    if-eqz v2, :cond_0

    invoke-interface {v1}, Landroid/view/MenuItem;->getSubMenu()Landroid/view/SubMenu;

    move-result-object v2

    if-ne p2, v2, :cond_0

    return-object v1

    :cond_0
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    const/4 p0, 0x0

    return-object p0
.end method

.method public lgHUyS()Z
    .locals 0

    const/4 p0, 0x0

    return p0
.end method

.method public final mByQ()I
    .locals 1

    iget-object p0, p0, Landroidx/appcompat/view/menu/AZxh;->rkYL:Landroid/view/View;

    invoke-static {p0}, Lo/T9;->huTpC(Landroid/view/View;)I

    move-result p0

    const/4 v0, 0x1

    if-ne p0, v0, :cond_0

    const/4 v0, 0x0

    :cond_0
    return v0
.end method

.method public mjFkc()V
    .locals 2

    invoke-virtual {p0}, Landroidx/appcompat/view/menu/AZxh;->Dt()Z

    move-result v0

    if-eqz v0, :cond_0

    return-void

    :cond_0
    iget-object v0, p0, Landroidx/appcompat/view/menu/AZxh;->lgHUyS:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroidx/appcompat/view/menu/ZfxDd;

    invoke-virtual {p0, v1}, Landroidx/appcompat/view/menu/AZxh;->Ne(Landroidx/appcompat/view/menu/ZfxDd;)V

    goto :goto_0

    :cond_1
    iget-object v0, p0, Landroidx/appcompat/view/menu/AZxh;->lgHUyS:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->clear()V

    iget-object v0, p0, Landroidx/appcompat/view/menu/AZxh;->rkYL:Landroid/view/View;

    iput-object v0, p0, Landroidx/appcompat/view/menu/AZxh;->qGY:Landroid/view/View;

    if-eqz v0, :cond_4

    iget-object v1, p0, Landroidx/appcompat/view/menu/AZxh;->HGpJ:Landroid/view/ViewTreeObserver;

    if-nez v1, :cond_2

    const/4 v1, 0x1

    goto :goto_1

    :cond_2
    const/4 v1, 0x0

    :goto_1
    invoke-virtual {v0}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    move-result-object v0

    iput-object v0, p0, Landroidx/appcompat/view/menu/AZxh;->HGpJ:Landroid/view/ViewTreeObserver;

    if-eqz v1, :cond_3

    iget-object v1, p0, Landroidx/appcompat/view/menu/AZxh;->Dt:Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;

    invoke-virtual {v0, v1}, Landroid/view/ViewTreeObserver;->addOnGlobalLayoutListener(Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;)V

    :cond_3
    iget-object v0, p0, Landroidx/appcompat/view/menu/AZxh;->qGY:Landroid/view/View;

    iget-object p0, p0, Landroidx/appcompat/view/menu/AZxh;->ETF:Landroid/view/View$OnAttachStateChangeListener;

    invoke-virtual {v0, p0}, Landroid/view/View;->addOnAttachStateChangeListener(Landroid/view/View$OnAttachStateChangeListener;)V

    :cond_4
    return-void
.end method

.method public onDismiss()V
    .locals 5

    iget-object v0, p0, Landroidx/appcompat/view/menu/AZxh;->qdMbNW:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    const/4 v1, 0x0

    move v2, v1

    :goto_0
    if-ge v2, v0, :cond_1

    iget-object v3, p0, Landroidx/appcompat/view/menu/AZxh;->qdMbNW:Ljava/util/List;

    invoke-interface {v3, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroidx/appcompat/view/menu/AZxh$ZfxDd;

    iget-object v4, v3, Landroidx/appcompat/view/menu/AZxh$ZfxDd;->mjFkc:Lo/Z1;

    invoke-virtual {v4}, Lo/a1;->Dt()Z

    move-result v4

    if-nez v4, :cond_0

    goto :goto_1

    :cond_0
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_1
    const/4 v3, 0x0

    :goto_1
    if-eqz v3, :cond_2

    iget-object p0, v3, Landroidx/appcompat/view/menu/AZxh$ZfxDd;->AZxh:Landroidx/appcompat/view/menu/ZfxDd;

    invoke-virtual {p0, v1}, Landroidx/appcompat/view/menu/ZfxDd;->ZfxDd(Z)V

    :cond_2
    return-void
.end method

.method public onKey(Landroid/view/View;ILandroid/view/KeyEvent;)Z
    .locals 0

    invoke-virtual {p3}, Landroid/view/KeyEvent;->getAction()I

    move-result p1

    const/4 p3, 0x1

    if-ne p1, p3, :cond_0

    const/16 p1, 0x52

    if-ne p2, p1, :cond_0

    invoke-virtual {p0}, Landroidx/appcompat/view/menu/AZxh;->ZfxDd()V

    return p3

    :cond_0
    const/4 p0, 0x0

    return p0
.end method

.method public final wJVbdd(Landroidx/appcompat/view/menu/AZxh$ZfxDd;Landroidx/appcompat/view/menu/ZfxDd;)Landroid/view/View;
    .locals 6

    iget-object v0, p1, Landroidx/appcompat/view/menu/AZxh$ZfxDd;->AZxh:Landroidx/appcompat/view/menu/ZfxDd;

    invoke-virtual {p0, v0, p2}, Landroidx/appcompat/view/menu/AZxh;->lB(Landroidx/appcompat/view/menu/ZfxDd;Landroidx/appcompat/view/menu/ZfxDd;)Landroid/view/MenuItem;

    move-result-object p0

    const/4 p2, 0x0

    if-nez p0, :cond_0

    return-object p2

    :cond_0
    invoke-virtual {p1}, Landroidx/appcompat/view/menu/AZxh$ZfxDd;->mjFkc()Landroid/widget/ListView;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/ListView;->getAdapter()Landroid/widget/ListAdapter;

    move-result-object v0

    instance-of v1, v0, Landroid/widget/HeaderViewListAdapter;

    const/4 v2, 0x0

    if-eqz v1, :cond_1

    check-cast v0, Landroid/widget/HeaderViewListAdapter;

    invoke-virtual {v0}, Landroid/widget/HeaderViewListAdapter;->getHeadersCount()I

    move-result v1

    invoke-virtual {v0}, Landroid/widget/HeaderViewListAdapter;->getWrappedAdapter()Landroid/widget/ListAdapter;

    move-result-object v0

    check-cast v0, Landroidx/appcompat/view/menu/wA;

    goto :goto_0

    :cond_1
    check-cast v0, Landroidx/appcompat/view/menu/wA;

    move v1, v2

    :goto_0
    invoke-virtual {v0}, Landroidx/appcompat/view/menu/wA;->getCount()I

    move-result v3

    :goto_1
    const/4 v4, -0x1

    if-ge v2, v3, :cond_3

    invoke-virtual {v0, v2}, Landroidx/appcompat/view/menu/wA;->wA(I)Landroidx/appcompat/view/menu/KLFTb;

    move-result-object v5

    if-ne p0, v5, :cond_2

    goto :goto_2

    :cond_2
    add-int/lit8 v2, v2, 0x1

    goto :goto_1

    :cond_3
    move v2, v4

    :goto_2
    if-ne v2, v4, :cond_4

    return-object p2

    :cond_4
    add-int/2addr v2, v1

    invoke-virtual {p1}, Landroid/widget/AdapterView;->getFirstVisiblePosition()I

    move-result p0

    sub-int/2addr v2, p0

    if-ltz v2, :cond_6

    invoke-virtual {p1}, Landroid/view/ViewGroup;->getChildCount()I

    move-result p0

    if-lt v2, p0, :cond_5

    goto :goto_3

    :cond_5
    invoke-virtual {p1, v2}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object p0

    return-object p0

    :cond_6
    :goto_3
    return-object p2
.end method

.method public xJ(Z)V
    .locals 0

    iget-object p0, p0, Landroidx/appcompat/view/menu/AZxh;->qdMbNW:Ljava/util/List;

    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result p1

    if-eqz p1, :cond_0

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroidx/appcompat/view/menu/AZxh$ZfxDd;

    invoke-virtual {p1}, Landroidx/appcompat/view/menu/AZxh$ZfxDd;->mjFkc()Landroid/widget/ListView;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/ListView;->getAdapter()Landroid/widget/ListAdapter;

    move-result-object p1

    invoke-static {p1}, Lo/Y1;->vI(Landroid/widget/ListAdapter;)Landroidx/appcompat/view/menu/wA;

    move-result-object p1

    invoke-virtual {p1}, Landroidx/appcompat/view/menu/wA;->notifyDataSetChanged()V

    goto :goto_0

    :cond_0
    return-void
.end method
