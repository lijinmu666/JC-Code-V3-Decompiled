.class public final Landroidx/appcompat/view/menu/KLFTb;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lo/x7;


# instance fields
.field public final AZxh:I

.field public BAnRFn:Landroid/view/MenuItem$OnActionExpandListener;

.field public Dt:C

.field public ETF:I

.field public Gd:Z

.field public HGpJ:I

.field public IEE:Ljava/lang/CharSequence;

.field public JHa:Ljava/lang/CharSequence;

.field public KLFTb:Ljava/lang/CharSequence;

.field public MiMN:I

.field public Pq:Ljava/lang/CharSequence;

.field public Ucbh:Z

.field public VA:Landroid/graphics/drawable/Drawable;

.field public VocHEe:Landroid/view/View;

.field public YoKzxo:Landroidx/appcompat/view/menu/ZfxDd;

.field public final ZfxDd:I

.field public diqgf:Landroid/content/res/ColorStateList;

.field public eyqo:Landroid/graphics/PorterDuff$Mode;

.field public fehf:Landroid/view/MenuItem$OnMenuItemClickListener;

.field public huTpC:Z

.field public lB:Z

.field public lgHUyS:C

.field public final mjFkc:I

.field public qGY:Ljava/lang/Runnable;

.field public qdMbNW:I

.field public rkYL:Landroidx/appcompat/view/menu/Dt;

.field public vI:I

.field public final wA:I

.field public wJVbdd:Landroid/view/ContextMenu$ContextMenuInfo;

.field public xJ:Landroid/content/Intent;


# direct methods
.method public constructor <init>(Landroidx/appcompat/view/menu/ZfxDd;IIIILjava/lang/CharSequence;I)V
    .locals 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/16 v0, 0x1000

    iput v0, p0, Landroidx/appcompat/view/menu/KLFTb;->qdMbNW:I

    iput v0, p0, Landroidx/appcompat/view/menu/KLFTb;->ETF:I

    const/4 v0, 0x0

    iput v0, p0, Landroidx/appcompat/view/menu/KLFTb;->MiMN:I

    const/4 v1, 0x0

    iput-object v1, p0, Landroidx/appcompat/view/menu/KLFTb;->diqgf:Landroid/content/res/ColorStateList;

    iput-object v1, p0, Landroidx/appcompat/view/menu/KLFTb;->eyqo:Landroid/graphics/PorterDuff$Mode;

    iput-boolean v0, p0, Landroidx/appcompat/view/menu/KLFTb;->Ucbh:Z

    iput-boolean v0, p0, Landroidx/appcompat/view/menu/KLFTb;->huTpC:Z

    iput-boolean v0, p0, Landroidx/appcompat/view/menu/KLFTb;->Gd:Z

    const/16 v1, 0x10

    iput v1, p0, Landroidx/appcompat/view/menu/KLFTb;->HGpJ:I

    iput-boolean v0, p0, Landroidx/appcompat/view/menu/KLFTb;->lB:Z

    iput-object p1, p0, Landroidx/appcompat/view/menu/KLFTb;->YoKzxo:Landroidx/appcompat/view/menu/ZfxDd;

    iput p3, p0, Landroidx/appcompat/view/menu/KLFTb;->mjFkc:I

    iput p2, p0, Landroidx/appcompat/view/menu/KLFTb;->AZxh:I

    iput p4, p0, Landroidx/appcompat/view/menu/KLFTb;->wA:I

    iput p5, p0, Landroidx/appcompat/view/menu/KLFTb;->ZfxDd:I

    iput-object p6, p0, Landroidx/appcompat/view/menu/KLFTb;->KLFTb:Ljava/lang/CharSequence;

    iput p7, p0, Landroidx/appcompat/view/menu/KLFTb;->vI:I

    return-void
.end method

.method public static AZxh(Ljava/lang/StringBuilder;IILjava/lang/String;)V
    .locals 0

    and-int/2addr p1, p2

    if-ne p1, p2, :cond_0

    invoke-virtual {p0, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_0
    return-void
.end method


# virtual methods
.method public Dt()Z
    .locals 2

    iget-object v0, p0, Landroidx/appcompat/view/menu/KLFTb;->fehf:Landroid/view/MenuItem$OnMenuItemClickListener;

    const/4 v1, 0x1

    if-eqz v0, :cond_0

    invoke-interface {v0, p0}, Landroid/view/MenuItem$OnMenuItemClickListener;->onMenuItemClick(Landroid/view/MenuItem;)Z

    move-result v0

    if-eqz v0, :cond_0

    return v1

    :cond_0
    iget-object v0, p0, Landroidx/appcompat/view/menu/KLFTb;->YoKzxo:Landroidx/appcompat/view/menu/ZfxDd;

    invoke-virtual {v0, v0, p0}, Landroidx/appcompat/view/menu/ZfxDd;->xJ(Landroidx/appcompat/view/menu/ZfxDd;Landroid/view/MenuItem;)Z

    move-result v0

    if-eqz v0, :cond_1

    return v1

    :cond_1
    iget-object v0, p0, Landroidx/appcompat/view/menu/KLFTb;->qGY:Ljava/lang/Runnable;

    if-eqz v0, :cond_2

    invoke-interface {v0}, Ljava/lang/Runnable;->run()V

    return v1

    :cond_2
    iget-object v0, p0, Landroidx/appcompat/view/menu/KLFTb;->xJ:Landroid/content/Intent;

    if-eqz v0, :cond_3

    :try_start_0
    iget-object v0, p0, Landroidx/appcompat/view/menu/KLFTb;->YoKzxo:Landroidx/appcompat/view/menu/ZfxDd;

    invoke-virtual {v0}, Landroidx/appcompat/view/menu/ZfxDd;->Pq()Landroid/content/Context;

    move-result-object v0

    iget-object p0, p0, Landroidx/appcompat/view/menu/KLFTb;->xJ:Landroid/content/Intent;

    invoke-virtual {v0, p0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V
    :try_end_0
    .catch Landroid/content/ActivityNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    return v1

    :catch_0
    move-exception p0

    const-string v0, "MenuItemImpl"

    const-string v1, "Can\'t find activity to handle intent; ignoring"

    invoke-static {v0, v1, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :cond_3
    const/4 p0, 0x0

    return p0
.end method

.method public ETF()Z
    .locals 1

    iget p0, p0, Landroidx/appcompat/view/menu/KLFTb;->HGpJ:I

    const/16 v0, 0x20

    and-int/2addr p0, v0

    if-ne p0, v0, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method

.method public Gd(Z)Z
    .locals 3

    iget v0, p0, Landroidx/appcompat/view/menu/KLFTb;->HGpJ:I

    and-int/lit8 v1, v0, -0x9

    const/4 v2, 0x0

    if-eqz p1, :cond_0

    move p1, v2

    goto :goto_0

    :cond_0
    const/16 p1, 0x8

    :goto_0
    or-int/2addr p1, v1

    iput p1, p0, Landroidx/appcompat/view/menu/KLFTb;->HGpJ:I

    if-eq v0, p1, :cond_1

    const/4 v2, 0x1

    :cond_1
    return v2
.end method

.method public HGpJ()Z
    .locals 0

    iget-object p0, p0, Landroidx/appcompat/view/menu/KLFTb;->YoKzxo:Landroidx/appcompat/view/menu/ZfxDd;

    invoke-virtual {p0}, Landroidx/appcompat/view/menu/ZfxDd;->huTpC()Z

    move-result p0

    return p0
.end method

.method public IEE(Z)V
    .locals 3

    iget v0, p0, Landroidx/appcompat/view/menu/KLFTb;->HGpJ:I

    and-int/lit8 v1, v0, -0x3

    const/4 v2, 0x0

    if-eqz p1, :cond_0

    const/4 p1, 0x2

    goto :goto_0

    :cond_0
    move p1, v2

    :goto_0
    or-int/2addr p1, v1

    iput p1, p0, Landroidx/appcompat/view/menu/KLFTb;->HGpJ:I

    if-eq v0, p1, :cond_1

    iget-object p0, p0, Landroidx/appcompat/view/menu/KLFTb;->YoKzxo:Landroidx/appcompat/view/menu/ZfxDd;

    invoke-virtual {p0, v2}, Landroidx/appcompat/view/menu/ZfxDd;->Ne(Z)V

    :cond_1
    return-void
.end method

.method public JHa()Ljava/lang/String;
    .locals 5

    invoke-virtual {p0}, Landroidx/appcompat/view/menu/KLFTb;->KLFTb()C

    move-result v0

    if-nez v0, :cond_0

    const-string p0, ""

    return-object p0

    :cond_0
    iget-object v1, p0, Landroidx/appcompat/view/menu/KLFTb;->YoKzxo:Landroidx/appcompat/view/menu/ZfxDd;

    invoke-virtual {v1}, Landroidx/appcompat/view/menu/ZfxDd;->Pq()Landroid/content/Context;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v3, p0, Landroidx/appcompat/view/menu/KLFTb;->YoKzxo:Landroidx/appcompat/view/menu/ZfxDd;

    invoke-virtual {v3}, Landroidx/appcompat/view/menu/ZfxDd;->Pq()Landroid/content/Context;

    move-result-object v3

    invoke-static {v3}, Landroid/view/ViewConfiguration;->get(Landroid/content/Context;)Landroid/view/ViewConfiguration;

    move-result-object v3

    invoke-virtual {v3}, Landroid/view/ViewConfiguration;->hasPermanentMenuKey()Z

    move-result v3

    if-eqz v3, :cond_1

    sget v3, Lo/O4;->ETF:I

    invoke-virtual {v1, v3}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_1
    iget-object v3, p0, Landroidx/appcompat/view/menu/KLFTb;->YoKzxo:Landroidx/appcompat/view/menu/ZfxDd;

    invoke-virtual {v3}, Landroidx/appcompat/view/menu/ZfxDd;->lB()Z

    move-result v3

    if-eqz v3, :cond_2

    iget p0, p0, Landroidx/appcompat/view/menu/KLFTb;->ETF:I

    goto :goto_0

    :cond_2
    iget p0, p0, Landroidx/appcompat/view/menu/KLFTb;->qdMbNW:I

    :goto_0
    sget v3, Lo/O4;->xJ:I

    invoke-virtual {v1, v3}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v3

    const/high16 v4, 0x10000

    invoke-static {v2, p0, v4, v3}, Landroidx/appcompat/view/menu/KLFTb;->AZxh(Ljava/lang/StringBuilder;IILjava/lang/String;)V

    sget v3, Lo/O4;->wA:I

    invoke-virtual {v1, v3}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v3

    const/16 v4, 0x1000

    invoke-static {v2, p0, v4, v3}, Landroidx/appcompat/view/menu/KLFTb;->AZxh(Ljava/lang/StringBuilder;IILjava/lang/String;)V

    sget v3, Lo/O4;->AZxh:I

    invoke-virtual {v1, v3}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v3

    const/4 v4, 0x2

    invoke-static {v2, p0, v4, v3}, Landroidx/appcompat/view/menu/KLFTb;->AZxh(Ljava/lang/StringBuilder;IILjava/lang/String;)V

    sget v3, Lo/O4;->lgHUyS:I

    invoke-virtual {v1, v3}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v3

    const/4 v4, 0x1

    invoke-static {v2, p0, v4, v3}, Landroidx/appcompat/view/menu/KLFTb;->AZxh(Ljava/lang/StringBuilder;IILjava/lang/String;)V

    sget v3, Lo/O4;->Dt:I

    invoke-virtual {v1, v3}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v3

    const/4 v4, 0x4

    invoke-static {v2, p0, v4, v3}, Landroidx/appcompat/view/menu/KLFTb;->AZxh(Ljava/lang/StringBuilder;IILjava/lang/String;)V

    sget v3, Lo/O4;->JHa:I

    invoke-virtual {v1, v3}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v3

    const/16 v4, 0x8

    invoke-static {v2, p0, v4, v3}, Landroidx/appcompat/view/menu/KLFTb;->AZxh(Ljava/lang/StringBuilder;IILjava/lang/String;)V

    if-eq v0, v4, :cond_5

    const/16 p0, 0xa

    if-eq v0, p0, :cond_4

    const/16 p0, 0x20

    if-eq v0, p0, :cond_3

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    goto :goto_1

    :cond_3
    sget p0, Lo/O4;->qdMbNW:I

    invoke-virtual {v1, p0}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_1

    :cond_4
    sget p0, Lo/O4;->KLFTb:I

    invoke-virtual {v1, p0}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_1

    :cond_5
    sget p0, Lo/O4;->ZfxDd:I

    invoke-virtual {v1, p0}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :goto_1
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public KLFTb()C
    .locals 1

    iget-object v0, p0, Landroidx/appcompat/view/menu/KLFTb;->YoKzxo:Landroidx/appcompat/view/menu/ZfxDd;

    invoke-virtual {v0}, Landroidx/appcompat/view/menu/ZfxDd;->lB()Z

    move-result v0

    if-eqz v0, :cond_0

    iget-char p0, p0, Landroidx/appcompat/view/menu/KLFTb;->Dt:C

    goto :goto_0

    :cond_0
    iget-char p0, p0, Landroidx/appcompat/view/menu/KLFTb;->lgHUyS:C

    :goto_0
    return p0
.end method

.method public MiMN()Z
    .locals 1

    iget p0, p0, Landroidx/appcompat/view/menu/KLFTb;->vI:I

    const/4 v0, 0x1

    and-int/2addr p0, v0

    if-ne p0, v0, :cond_0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public Pq(Z)V
    .locals 1

    iget v0, p0, Landroidx/appcompat/view/menu/KLFTb;->HGpJ:I

    and-int/lit8 v0, v0, -0x5

    if-eqz p1, :cond_0

    const/4 p1, 0x4

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    :goto_0
    or-int/2addr p1, v0

    iput p1, p0, Landroidx/appcompat/view/menu/KLFTb;->HGpJ:I

    return-void
.end method

.method public Ucbh(I)Lo/x7;
    .locals 0

    invoke-virtual {p0, p1}, Landroidx/appcompat/view/menu/KLFTb;->setShowAsAction(I)V

    return-object p0
.end method

.method public VA()Z
    .locals 0

    iget p0, p0, Landroidx/appcompat/view/menu/KLFTb;->HGpJ:I

    and-int/lit8 p0, p0, 0x4

    if-eqz p0, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method

.method public VocHEe()Z
    .locals 1

    iget p0, p0, Landroidx/appcompat/view/menu/KLFTb;->vI:I

    const/4 v0, 0x4

    and-int/2addr p0, v0

    if-ne p0, v0, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method

.method public YoKzxo()Z
    .locals 1

    iget p0, p0, Landroidx/appcompat/view/menu/KLFTb;->vI:I

    const/4 v0, 0x2

    and-int/2addr p0, v0

    if-ne p0, v0, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method

.method public ZfxDd()I
    .locals 0

    iget p0, p0, Landroidx/appcompat/view/menu/KLFTb;->ZfxDd:I

    return p0
.end method

.method public collapseActionView()Z
    .locals 2

    iget v0, p0, Landroidx/appcompat/view/menu/KLFTb;->vI:I

    and-int/lit8 v0, v0, 0x8

    const/4 v1, 0x0

    if-nez v0, :cond_0

    return v1

    :cond_0
    iget-object v0, p0, Landroidx/appcompat/view/menu/KLFTb;->VocHEe:Landroid/view/View;

    if-nez v0, :cond_1

    const/4 p0, 0x1

    return p0

    :cond_1
    iget-object v0, p0, Landroidx/appcompat/view/menu/KLFTb;->BAnRFn:Landroid/view/MenuItem$OnActionExpandListener;

    if-eqz v0, :cond_3

    invoke-interface {v0, p0}, Landroid/view/MenuItem$OnActionExpandListener;->onMenuItemActionCollapse(Landroid/view/MenuItem;)Z

    move-result v0

    if-eqz v0, :cond_2

    goto :goto_0

    :cond_2
    return v1

    :cond_3
    :goto_0
    iget-object v0, p0, Landroidx/appcompat/view/menu/KLFTb;->YoKzxo:Landroidx/appcompat/view/menu/ZfxDd;

    invoke-virtual {v0, p0}, Landroidx/appcompat/view/menu/ZfxDd;->KLFTb(Landroidx/appcompat/view/menu/KLFTb;)Z

    move-result p0

    return p0
.end method

.method public diqgf(Z)V
    .locals 0

    if-eqz p1, :cond_0

    iget p1, p0, Landroidx/appcompat/view/menu/KLFTb;->HGpJ:I

    or-int/lit8 p1, p1, 0x20

    iput p1, p0, Landroidx/appcompat/view/menu/KLFTb;->HGpJ:I

    goto :goto_0

    :cond_0
    iget p1, p0, Landroidx/appcompat/view/menu/KLFTb;->HGpJ:I

    and-int/lit8 p1, p1, -0x21

    iput p1, p0, Landroidx/appcompat/view/menu/KLFTb;->HGpJ:I

    :goto_0
    return-void
.end method

.method public expandActionView()Z
    .locals 2

    invoke-virtual {p0}, Landroidx/appcompat/view/menu/KLFTb;->qdMbNW()Z

    move-result v0

    const/4 v1, 0x0

    if-nez v0, :cond_0

    return v1

    :cond_0
    iget-object v0, p0, Landroidx/appcompat/view/menu/KLFTb;->BAnRFn:Landroid/view/MenuItem$OnActionExpandListener;

    if-eqz v0, :cond_2

    invoke-interface {v0, p0}, Landroid/view/MenuItem$OnActionExpandListener;->onMenuItemActionExpand(Landroid/view/MenuItem;)Z

    move-result v0

    if-eqz v0, :cond_1

    goto :goto_0

    :cond_1
    return v1

    :cond_2
    :goto_0
    iget-object v0, p0, Landroidx/appcompat/view/menu/KLFTb;->YoKzxo:Landroidx/appcompat/view/menu/ZfxDd;

    invoke-virtual {v0, p0}, Landroidx/appcompat/view/menu/ZfxDd;->Dt(Landroidx/appcompat/view/menu/KLFTb;)Z

    move-result p0

    return p0
.end method

.method public eyqo(Landroid/view/ContextMenu$ContextMenuInfo;)V
    .locals 0

    iput-object p1, p0, Landroidx/appcompat/view/menu/KLFTb;->wJVbdd:Landroid/view/ContextMenu$ContextMenuInfo;

    return-void
.end method

.method public fehf(Z)V
    .locals 0

    iput-boolean p1, p0, Landroidx/appcompat/view/menu/KLFTb;->lB:Z

    iget-object p0, p0, Landroidx/appcompat/view/menu/KLFTb;->YoKzxo:Landroidx/appcompat/view/menu/ZfxDd;

    const/4 p1, 0x0

    invoke-virtual {p0, p1}, Landroidx/appcompat/view/menu/ZfxDd;->Ne(Z)V

    return-void
.end method

.method public getActionProvider()Landroid/view/ActionProvider;
    .locals 1

    new-instance p0, Ljava/lang/UnsupportedOperationException;

    const-string v0, "This is not supported, use MenuItemCompat.getActionProvider()"

    invoke-direct {p0, v0}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public getActionView()Landroid/view/View;
    .locals 0

    iget-object p0, p0, Landroidx/appcompat/view/menu/KLFTb;->VocHEe:Landroid/view/View;

    if-eqz p0, :cond_0

    return-object p0

    :cond_0
    const/4 p0, 0x0

    return-object p0
.end method

.method public getAlphabeticModifiers()I
    .locals 0

    iget p0, p0, Landroidx/appcompat/view/menu/KLFTb;->ETF:I

    return p0
.end method

.method public getAlphabeticShortcut()C
    .locals 0

    iget-char p0, p0, Landroidx/appcompat/view/menu/KLFTb;->Dt:C

    return p0
.end method

.method public getContentDescription()Ljava/lang/CharSequence;
    .locals 0

    iget-object p0, p0, Landroidx/appcompat/view/menu/KLFTb;->IEE:Ljava/lang/CharSequence;

    return-object p0
.end method

.method public getGroupId()I
    .locals 0

    iget p0, p0, Landroidx/appcompat/view/menu/KLFTb;->AZxh:I

    return p0
.end method

.method public getIcon()Landroid/graphics/drawable/Drawable;
    .locals 2

    iget-object v0, p0, Landroidx/appcompat/view/menu/KLFTb;->VA:Landroid/graphics/drawable/Drawable;

    if-eqz v0, :cond_0

    invoke-virtual {p0, v0}, Landroidx/appcompat/view/menu/KLFTb;->wA(Landroid/graphics/drawable/Drawable;)Landroid/graphics/drawable/Drawable;

    move-result-object p0

    return-object p0

    :cond_0
    iget v0, p0, Landroidx/appcompat/view/menu/KLFTb;->MiMN:I

    if-eqz v0, :cond_1

    iget-object v0, p0, Landroidx/appcompat/view/menu/KLFTb;->YoKzxo:Landroidx/appcompat/view/menu/ZfxDd;

    invoke-virtual {v0}, Landroidx/appcompat/view/menu/ZfxDd;->Pq()Landroid/content/Context;

    move-result-object v0

    iget v1, p0, Landroidx/appcompat/view/menu/KLFTb;->MiMN:I

    invoke-static {v0, v1}, Lo/vjlshU;->AZxh(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    move-result-object v0

    const/4 v1, 0x0

    iput v1, p0, Landroidx/appcompat/view/menu/KLFTb;->MiMN:I

    iput-object v0, p0, Landroidx/appcompat/view/menu/KLFTb;->VA:Landroid/graphics/drawable/Drawable;

    invoke-virtual {p0, v0}, Landroidx/appcompat/view/menu/KLFTb;->wA(Landroid/graphics/drawable/Drawable;)Landroid/graphics/drawable/Drawable;

    move-result-object p0

    return-object p0

    :cond_1
    const/4 p0, 0x0

    return-object p0
.end method

.method public getIconTintList()Landroid/content/res/ColorStateList;
    .locals 0

    iget-object p0, p0, Landroidx/appcompat/view/menu/KLFTb;->diqgf:Landroid/content/res/ColorStateList;

    return-object p0
.end method

.method public getIconTintMode()Landroid/graphics/PorterDuff$Mode;
    .locals 0

    iget-object p0, p0, Landroidx/appcompat/view/menu/KLFTb;->eyqo:Landroid/graphics/PorterDuff$Mode;

    return-object p0
.end method

.method public getIntent()Landroid/content/Intent;
    .locals 0

    iget-object p0, p0, Landroidx/appcompat/view/menu/KLFTb;->xJ:Landroid/content/Intent;

    return-object p0
.end method

.method public getItemId()I
    .locals 0

    iget p0, p0, Landroidx/appcompat/view/menu/KLFTb;->mjFkc:I

    return p0
.end method

.method public getMenuInfo()Landroid/view/ContextMenu$ContextMenuInfo;
    .locals 0

    iget-object p0, p0, Landroidx/appcompat/view/menu/KLFTb;->wJVbdd:Landroid/view/ContextMenu$ContextMenuInfo;

    return-object p0
.end method

.method public getNumericModifiers()I
    .locals 0

    iget p0, p0, Landroidx/appcompat/view/menu/KLFTb;->qdMbNW:I

    return p0
.end method

.method public getNumericShortcut()C
    .locals 0

    iget-char p0, p0, Landroidx/appcompat/view/menu/KLFTb;->lgHUyS:C

    return p0
.end method

.method public getOrder()I
    .locals 0

    iget p0, p0, Landroidx/appcompat/view/menu/KLFTb;->wA:I

    return p0
.end method

.method public getSubMenu()Landroid/view/SubMenu;
    .locals 0

    iget-object p0, p0, Landroidx/appcompat/view/menu/KLFTb;->rkYL:Landroidx/appcompat/view/menu/Dt;

    return-object p0
.end method

.method public getTitle()Ljava/lang/CharSequence;
    .locals 0

    iget-object p0, p0, Landroidx/appcompat/view/menu/KLFTb;->KLFTb:Ljava/lang/CharSequence;

    return-object p0
.end method

.method public getTitleCondensed()Ljava/lang/CharSequence;
    .locals 1

    iget-object v0, p0, Landroidx/appcompat/view/menu/KLFTb;->JHa:Ljava/lang/CharSequence;

    if-eqz v0, :cond_0

    goto :goto_0

    :cond_0
    iget-object v0, p0, Landroidx/appcompat/view/menu/KLFTb;->KLFTb:Ljava/lang/CharSequence;

    :goto_0
    return-object v0
.end method

.method public getTooltipText()Ljava/lang/CharSequence;
    .locals 0

    iget-object p0, p0, Landroidx/appcompat/view/menu/KLFTb;->Pq:Ljava/lang/CharSequence;

    return-object p0
.end method

.method public hasSubMenu()Z
    .locals 0

    iget-object p0, p0, Landroidx/appcompat/view/menu/KLFTb;->rkYL:Landroidx/appcompat/view/menu/Dt;

    if-eqz p0, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method

.method public huTpC(Landroidx/appcompat/view/menu/Dt;)V
    .locals 0

    iput-object p1, p0, Landroidx/appcompat/view/menu/KLFTb;->rkYL:Landroidx/appcompat/view/menu/Dt;

    invoke-virtual {p0}, Landroidx/appcompat/view/menu/KLFTb;->getTitle()Ljava/lang/CharSequence;

    move-result-object p0

    invoke-virtual {p1, p0}, Landroidx/appcompat/view/menu/Dt;->setHeaderTitle(Ljava/lang/CharSequence;)Landroid/view/SubMenu;

    return-void
.end method

.method public isActionViewExpanded()Z
    .locals 0

    iget-boolean p0, p0, Landroidx/appcompat/view/menu/KLFTb;->lB:Z

    return p0
.end method

.method public isCheckable()Z
    .locals 1

    iget p0, p0, Landroidx/appcompat/view/menu/KLFTb;->HGpJ:I

    const/4 v0, 0x1

    and-int/2addr p0, v0

    if-ne p0, v0, :cond_0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public isChecked()Z
    .locals 1

    iget p0, p0, Landroidx/appcompat/view/menu/KLFTb;->HGpJ:I

    const/4 v0, 0x2

    and-int/2addr p0, v0

    if-ne p0, v0, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method

.method public isEnabled()Z
    .locals 0

    iget p0, p0, Landroidx/appcompat/view/menu/KLFTb;->HGpJ:I

    and-int/lit8 p0, p0, 0x10

    if-eqz p0, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method

.method public isVisible()Z
    .locals 0

    iget p0, p0, Landroidx/appcompat/view/menu/KLFTb;->HGpJ:I

    and-int/lit8 p0, p0, 0x8

    if-nez p0, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method

.method public lgHUyS(Landroidx/appcompat/view/menu/lgHUyS$mjFkc;)Ljava/lang/CharSequence;
    .locals 0

    if-eqz p1, :cond_0

    invoke-interface {p1}, Landroidx/appcompat/view/menu/lgHUyS$mjFkc;->wA()Z

    move-result p1

    if-eqz p1, :cond_0

    invoke-virtual {p0}, Landroidx/appcompat/view/menu/KLFTb;->getTitleCondensed()Ljava/lang/CharSequence;

    move-result-object p0

    goto :goto_0

    :cond_0
    invoke-virtual {p0}, Landroidx/appcompat/view/menu/KLFTb;->getTitle()Ljava/lang/CharSequence;

    move-result-object p0

    :goto_0
    return-object p0
.end method

.method public mjFkc()V
    .locals 1

    iget-object v0, p0, Landroidx/appcompat/view/menu/KLFTb;->YoKzxo:Landroidx/appcompat/view/menu/ZfxDd;

    invoke-virtual {v0, p0}, Landroidx/appcompat/view/menu/ZfxDd;->mByQ(Landroidx/appcompat/view/menu/KLFTb;)V

    return-void
.end method

.method public qGY(Landroid/view/View;)Lo/x7;
    .locals 2

    iput-object p1, p0, Landroidx/appcompat/view/menu/KLFTb;->VocHEe:Landroid/view/View;

    if-eqz p1, :cond_0

    invoke-virtual {p1}, Landroid/view/View;->getId()I

    move-result v0

    const/4 v1, -0x1

    if-ne v0, v1, :cond_0

    iget v0, p0, Landroidx/appcompat/view/menu/KLFTb;->mjFkc:I

    if-lez v0, :cond_0

    invoke-virtual {p1, v0}, Landroid/view/View;->setId(I)V

    :cond_0
    iget-object p1, p0, Landroidx/appcompat/view/menu/KLFTb;->YoKzxo:Landroidx/appcompat/view/menu/ZfxDd;

    invoke-virtual {p1, p0}, Landroidx/appcompat/view/menu/ZfxDd;->mByQ(Landroidx/appcompat/view/menu/KLFTb;)V

    return-object p0
.end method

.method public qdMbNW()Z
    .locals 2

    iget v0, p0, Landroidx/appcompat/view/menu/KLFTb;->vI:I

    and-int/lit8 v0, v0, 0x8

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    iget-object p0, p0, Landroidx/appcompat/view/menu/KLFTb;->VocHEe:Landroid/view/View;

    if-eqz p0, :cond_0

    const/4 v1, 0x1

    :cond_0
    return v1
.end method

.method public rkYL(I)Lo/x7;
    .locals 3

    iget-object v0, p0, Landroidx/appcompat/view/menu/KLFTb;->YoKzxo:Landroidx/appcompat/view/menu/ZfxDd;

    invoke-virtual {v0}, Landroidx/appcompat/view/menu/ZfxDd;->Pq()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object v1

    new-instance v2, Landroid/widget/LinearLayout;

    invoke-direct {v2, v0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v0, 0x0

    invoke-virtual {v1, p1, v2, v0}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object p1

    invoke-virtual {p0, p1}, Landroidx/appcompat/view/menu/KLFTb;->qGY(Landroid/view/View;)Lo/x7;

    return-object p0
.end method

.method public setActionProvider(Landroid/view/ActionProvider;)Landroid/view/MenuItem;
    .locals 0

    new-instance p0, Ljava/lang/UnsupportedOperationException;

    const-string p1, "This is not supported, use MenuItemCompat.setActionProvider()"

    invoke-direct {p0, p1}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public bridge synthetic setActionView(I)Landroid/view/MenuItem;
    .locals 0

    .line 1
    invoke-virtual {p0, p1}, Landroidx/appcompat/view/menu/KLFTb;->rkYL(I)Lo/x7;

    move-result-object p0

    return-object p0
.end method

.method public bridge synthetic setActionView(Landroid/view/View;)Landroid/view/MenuItem;
    .locals 0

    .line 2
    invoke-virtual {p0, p1}, Landroidx/appcompat/view/menu/KLFTb;->qGY(Landroid/view/View;)Lo/x7;

    move-result-object p0

    return-object p0
.end method

.method public setAlphabeticShortcut(C)Landroid/view/MenuItem;
    .locals 1

    .line 1
    iget-char v0, p0, Landroidx/appcompat/view/menu/KLFTb;->Dt:C

    if-ne v0, p1, :cond_0

    return-object p0

    .line 2
    :cond_0
    invoke-static {p1}, Ljava/lang/Character;->toLowerCase(C)C

    move-result p1

    iput-char p1, p0, Landroidx/appcompat/view/menu/KLFTb;->Dt:C

    .line 3
    iget-object p1, p0, Landroidx/appcompat/view/menu/KLFTb;->YoKzxo:Landroidx/appcompat/view/menu/ZfxDd;

    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Landroidx/appcompat/view/menu/ZfxDd;->Ne(Z)V

    return-object p0
.end method

.method public setAlphabeticShortcut(CI)Landroid/view/MenuItem;
    .locals 1

    .line 4
    iget-char v0, p0, Landroidx/appcompat/view/menu/KLFTb;->Dt:C

    if-ne v0, p1, :cond_0

    iget v0, p0, Landroidx/appcompat/view/menu/KLFTb;->ETF:I

    if-ne v0, p2, :cond_0

    return-object p0

    .line 5
    :cond_0
    invoke-static {p1}, Ljava/lang/Character;->toLowerCase(C)C

    move-result p1

    iput-char p1, p0, Landroidx/appcompat/view/menu/KLFTb;->Dt:C

    .line 6
    invoke-static {p2}, Landroid/view/KeyEvent;->normalizeMetaState(I)I

    move-result p1

    iput p1, p0, Landroidx/appcompat/view/menu/KLFTb;->ETF:I

    .line 7
    iget-object p1, p0, Landroidx/appcompat/view/menu/KLFTb;->YoKzxo:Landroidx/appcompat/view/menu/ZfxDd;

    const/4 p2, 0x0

    invoke-virtual {p1, p2}, Landroidx/appcompat/view/menu/ZfxDd;->Ne(Z)V

    return-object p0
.end method

.method public setCheckable(Z)Landroid/view/MenuItem;
    .locals 2

    iget v0, p0, Landroidx/appcompat/view/menu/KLFTb;->HGpJ:I

    and-int/lit8 v1, v0, -0x2

    or-int/2addr p1, v1

    iput p1, p0, Landroidx/appcompat/view/menu/KLFTb;->HGpJ:I

    if-eq v0, p1, :cond_0

    iget-object p1, p0, Landroidx/appcompat/view/menu/KLFTb;->YoKzxo:Landroidx/appcompat/view/menu/ZfxDd;

    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Landroidx/appcompat/view/menu/ZfxDd;->Ne(Z)V

    :cond_0
    return-object p0
.end method

.method public setChecked(Z)Landroid/view/MenuItem;
    .locals 1

    iget v0, p0, Landroidx/appcompat/view/menu/KLFTb;->HGpJ:I

    and-int/lit8 v0, v0, 0x4

    if-eqz v0, :cond_0

    iget-object p1, p0, Landroidx/appcompat/view/menu/KLFTb;->YoKzxo:Landroidx/appcompat/view/menu/ZfxDd;

    invoke-virtual {p1, p0}, Landroidx/appcompat/view/menu/ZfxDd;->rWxwaT(Landroid/view/MenuItem;)V

    goto :goto_0

    :cond_0
    invoke-virtual {p0, p1}, Landroidx/appcompat/view/menu/KLFTb;->IEE(Z)V

    :goto_0
    return-object p0
.end method

.method public bridge synthetic setContentDescription(Ljava/lang/CharSequence;)Landroid/view/MenuItem;
    .locals 0

    .line 1
    invoke-virtual {p0, p1}, Landroidx/appcompat/view/menu/KLFTb;->setContentDescription(Ljava/lang/CharSequence;)Lo/x7;

    move-result-object p0

    return-object p0
.end method

.method public setContentDescription(Ljava/lang/CharSequence;)Lo/x7;
    .locals 1

    .line 2
    iput-object p1, p0, Landroidx/appcompat/view/menu/KLFTb;->IEE:Ljava/lang/CharSequence;

    .line 3
    iget-object p1, p0, Landroidx/appcompat/view/menu/KLFTb;->YoKzxo:Landroidx/appcompat/view/menu/ZfxDd;

    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Landroidx/appcompat/view/menu/ZfxDd;->Ne(Z)V

    return-object p0
.end method

.method public setEnabled(Z)Landroid/view/MenuItem;
    .locals 1

    if-eqz p1, :cond_0

    iget p1, p0, Landroidx/appcompat/view/menu/KLFTb;->HGpJ:I

    or-int/lit8 p1, p1, 0x10

    iput p1, p0, Landroidx/appcompat/view/menu/KLFTb;->HGpJ:I

    goto :goto_0

    :cond_0
    iget p1, p0, Landroidx/appcompat/view/menu/KLFTb;->HGpJ:I

    and-int/lit8 p1, p1, -0x11

    iput p1, p0, Landroidx/appcompat/view/menu/KLFTb;->HGpJ:I

    :goto_0
    iget-object p1, p0, Landroidx/appcompat/view/menu/KLFTb;->YoKzxo:Landroidx/appcompat/view/menu/ZfxDd;

    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Landroidx/appcompat/view/menu/ZfxDd;->Ne(Z)V

    return-object p0
.end method

.method public setIcon(I)Landroid/view/MenuItem;
    .locals 1

    const/4 v0, 0x0

    .line 5
    iput-object v0, p0, Landroidx/appcompat/view/menu/KLFTb;->VA:Landroid/graphics/drawable/Drawable;

    .line 6
    iput p1, p0, Landroidx/appcompat/view/menu/KLFTb;->MiMN:I

    const/4 p1, 0x1

    .line 7
    iput-boolean p1, p0, Landroidx/appcompat/view/menu/KLFTb;->Gd:Z

    .line 8
    iget-object p1, p0, Landroidx/appcompat/view/menu/KLFTb;->YoKzxo:Landroidx/appcompat/view/menu/ZfxDd;

    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Landroidx/appcompat/view/menu/ZfxDd;->Ne(Z)V

    return-object p0
.end method

.method public setIcon(Landroid/graphics/drawable/Drawable;)Landroid/view/MenuItem;
    .locals 1

    const/4 v0, 0x0

    .line 1
    iput v0, p0, Landroidx/appcompat/view/menu/KLFTb;->MiMN:I

    .line 2
    iput-object p1, p0, Landroidx/appcompat/view/menu/KLFTb;->VA:Landroid/graphics/drawable/Drawable;

    const/4 p1, 0x1

    .line 3
    iput-boolean p1, p0, Landroidx/appcompat/view/menu/KLFTb;->Gd:Z

    .line 4
    iget-object p1, p0, Landroidx/appcompat/view/menu/KLFTb;->YoKzxo:Landroidx/appcompat/view/menu/ZfxDd;

    invoke-virtual {p1, v0}, Landroidx/appcompat/view/menu/ZfxDd;->Ne(Z)V

    return-object p0
.end method

.method public setIconTintList(Landroid/content/res/ColorStateList;)Landroid/view/MenuItem;
    .locals 1

    iput-object p1, p0, Landroidx/appcompat/view/menu/KLFTb;->diqgf:Landroid/content/res/ColorStateList;

    const/4 p1, 0x1

    iput-boolean p1, p0, Landroidx/appcompat/view/menu/KLFTb;->Ucbh:Z

    iput-boolean p1, p0, Landroidx/appcompat/view/menu/KLFTb;->Gd:Z

    iget-object p1, p0, Landroidx/appcompat/view/menu/KLFTb;->YoKzxo:Landroidx/appcompat/view/menu/ZfxDd;

    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Landroidx/appcompat/view/menu/ZfxDd;->Ne(Z)V

    return-object p0
.end method

.method public setIconTintMode(Landroid/graphics/PorterDuff$Mode;)Landroid/view/MenuItem;
    .locals 1

    iput-object p1, p0, Landroidx/appcompat/view/menu/KLFTb;->eyqo:Landroid/graphics/PorterDuff$Mode;

    const/4 p1, 0x1

    iput-boolean p1, p0, Landroidx/appcompat/view/menu/KLFTb;->huTpC:Z

    iput-boolean p1, p0, Landroidx/appcompat/view/menu/KLFTb;->Gd:Z

    iget-object p1, p0, Landroidx/appcompat/view/menu/KLFTb;->YoKzxo:Landroidx/appcompat/view/menu/ZfxDd;

    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Landroidx/appcompat/view/menu/ZfxDd;->Ne(Z)V

    return-object p0
.end method

.method public setIntent(Landroid/content/Intent;)Landroid/view/MenuItem;
    .locals 0

    iput-object p1, p0, Landroidx/appcompat/view/menu/KLFTb;->xJ:Landroid/content/Intent;

    return-object p0
.end method

.method public setNumericShortcut(C)Landroid/view/MenuItem;
    .locals 1

    .line 1
    iget-char v0, p0, Landroidx/appcompat/view/menu/KLFTb;->lgHUyS:C

    if-ne v0, p1, :cond_0

    return-object p0

    .line 2
    :cond_0
    iput-char p1, p0, Landroidx/appcompat/view/menu/KLFTb;->lgHUyS:C

    .line 3
    iget-object p1, p0, Landroidx/appcompat/view/menu/KLFTb;->YoKzxo:Landroidx/appcompat/view/menu/ZfxDd;

    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Landroidx/appcompat/view/menu/ZfxDd;->Ne(Z)V

    return-object p0
.end method

.method public setNumericShortcut(CI)Landroid/view/MenuItem;
    .locals 1

    .line 4
    iget-char v0, p0, Landroidx/appcompat/view/menu/KLFTb;->lgHUyS:C

    if-ne v0, p1, :cond_0

    iget v0, p0, Landroidx/appcompat/view/menu/KLFTb;->qdMbNW:I

    if-ne v0, p2, :cond_0

    return-object p0

    .line 5
    :cond_0
    iput-char p1, p0, Landroidx/appcompat/view/menu/KLFTb;->lgHUyS:C

    .line 6
    invoke-static {p2}, Landroid/view/KeyEvent;->normalizeMetaState(I)I

    move-result p1

    iput p1, p0, Landroidx/appcompat/view/menu/KLFTb;->qdMbNW:I

    .line 7
    iget-object p1, p0, Landroidx/appcompat/view/menu/KLFTb;->YoKzxo:Landroidx/appcompat/view/menu/ZfxDd;

    const/4 p2, 0x0

    invoke-virtual {p1, p2}, Landroidx/appcompat/view/menu/ZfxDd;->Ne(Z)V

    return-object p0
.end method

.method public setOnActionExpandListener(Landroid/view/MenuItem$OnActionExpandListener;)Landroid/view/MenuItem;
    .locals 0

    iput-object p1, p0, Landroidx/appcompat/view/menu/KLFTb;->BAnRFn:Landroid/view/MenuItem$OnActionExpandListener;

    return-object p0
.end method

.method public setOnMenuItemClickListener(Landroid/view/MenuItem$OnMenuItemClickListener;)Landroid/view/MenuItem;
    .locals 0

    iput-object p1, p0, Landroidx/appcompat/view/menu/KLFTb;->fehf:Landroid/view/MenuItem$OnMenuItemClickListener;

    return-object p0
.end method

.method public setShortcut(CC)Landroid/view/MenuItem;
    .locals 0

    .line 1
    iput-char p1, p0, Landroidx/appcompat/view/menu/KLFTb;->lgHUyS:C

    .line 2
    invoke-static {p2}, Ljava/lang/Character;->toLowerCase(C)C

    move-result p1

    iput-char p1, p0, Landroidx/appcompat/view/menu/KLFTb;->Dt:C

    .line 3
    iget-object p1, p0, Landroidx/appcompat/view/menu/KLFTb;->YoKzxo:Landroidx/appcompat/view/menu/ZfxDd;

    const/4 p2, 0x0

    invoke-virtual {p1, p2}, Landroidx/appcompat/view/menu/ZfxDd;->Ne(Z)V

    return-object p0
.end method

.method public setShortcut(CCII)Landroid/view/MenuItem;
    .locals 0

    .line 4
    iput-char p1, p0, Landroidx/appcompat/view/menu/KLFTb;->lgHUyS:C

    .line 5
    invoke-static {p3}, Landroid/view/KeyEvent;->normalizeMetaState(I)I

    move-result p1

    iput p1, p0, Landroidx/appcompat/view/menu/KLFTb;->qdMbNW:I

    .line 6
    invoke-static {p2}, Ljava/lang/Character;->toLowerCase(C)C

    move-result p1

    iput-char p1, p0, Landroidx/appcompat/view/menu/KLFTb;->Dt:C

    .line 7
    invoke-static {p4}, Landroid/view/KeyEvent;->normalizeMetaState(I)I

    move-result p1

    iput p1, p0, Landroidx/appcompat/view/menu/KLFTb;->ETF:I

    .line 8
    iget-object p1, p0, Landroidx/appcompat/view/menu/KLFTb;->YoKzxo:Landroidx/appcompat/view/menu/ZfxDd;

    const/4 p2, 0x0

    invoke-virtual {p1, p2}, Landroidx/appcompat/view/menu/ZfxDd;->Ne(Z)V

    return-object p0
.end method

.method public setShowAsAction(I)V
    .locals 2

    and-int/lit8 v0, p1, 0x3

    if-eqz v0, :cond_1

    const/4 v1, 0x1

    if-eq v0, v1, :cond_1

    const/4 v1, 0x2

    if-ne v0, v1, :cond_0

    goto :goto_0

    :cond_0
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string p1, "SHOW_AS_ACTION_ALWAYS, SHOW_AS_ACTION_IF_ROOM, and SHOW_AS_ACTION_NEVER are mutually exclusive."

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_1
    :goto_0
    iput p1, p0, Landroidx/appcompat/view/menu/KLFTb;->vI:I

    iget-object p1, p0, Landroidx/appcompat/view/menu/KLFTb;->YoKzxo:Landroidx/appcompat/view/menu/ZfxDd;

    invoke-virtual {p1, p0}, Landroidx/appcompat/view/menu/ZfxDd;->mByQ(Landroidx/appcompat/view/menu/KLFTb;)V

    return-void
.end method

.method public bridge synthetic setShowAsActionFlags(I)Landroid/view/MenuItem;
    .locals 0

    invoke-virtual {p0, p1}, Landroidx/appcompat/view/menu/KLFTb;->Ucbh(I)Lo/x7;

    move-result-object p0

    return-object p0
.end method

.method public setTitle(I)Landroid/view/MenuItem;
    .locals 1

    .line 5
    iget-object v0, p0, Landroidx/appcompat/view/menu/KLFTb;->YoKzxo:Landroidx/appcompat/view/menu/ZfxDd;

    invoke-virtual {v0}, Landroidx/appcompat/view/menu/ZfxDd;->Pq()Landroid/content/Context;

    move-result-object v0

    invoke-virtual {v0, p1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Landroidx/appcompat/view/menu/KLFTb;->setTitle(Ljava/lang/CharSequence;)Landroid/view/MenuItem;

    move-result-object p0

    return-object p0
.end method

.method public setTitle(Ljava/lang/CharSequence;)Landroid/view/MenuItem;
    .locals 2

    .line 1
    iput-object p1, p0, Landroidx/appcompat/view/menu/KLFTb;->KLFTb:Ljava/lang/CharSequence;

    .line 2
    iget-object v0, p0, Landroidx/appcompat/view/menu/KLFTb;->YoKzxo:Landroidx/appcompat/view/menu/ZfxDd;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroidx/appcompat/view/menu/ZfxDd;->Ne(Z)V

    .line 3
    iget-object v0, p0, Landroidx/appcompat/view/menu/KLFTb;->rkYL:Landroidx/appcompat/view/menu/Dt;

    if-eqz v0, :cond_0

    .line 4
    invoke-virtual {v0, p1}, Landroidx/appcompat/view/menu/Dt;->setHeaderTitle(Ljava/lang/CharSequence;)Landroid/view/SubMenu;

    :cond_0
    return-object p0
.end method

.method public setTitleCondensed(Ljava/lang/CharSequence;)Landroid/view/MenuItem;
    .locals 1

    iput-object p1, p0, Landroidx/appcompat/view/menu/KLFTb;->JHa:Ljava/lang/CharSequence;

    iget-object p1, p0, Landroidx/appcompat/view/menu/KLFTb;->YoKzxo:Landroidx/appcompat/view/menu/ZfxDd;

    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Landroidx/appcompat/view/menu/ZfxDd;->Ne(Z)V

    return-object p0
.end method

.method public bridge synthetic setTooltipText(Ljava/lang/CharSequence;)Landroid/view/MenuItem;
    .locals 0

    .line 1
    invoke-virtual {p0, p1}, Landroidx/appcompat/view/menu/KLFTb;->setTooltipText(Ljava/lang/CharSequence;)Lo/x7;

    move-result-object p0

    return-object p0
.end method

.method public setTooltipText(Ljava/lang/CharSequence;)Lo/x7;
    .locals 1

    .line 2
    iput-object p1, p0, Landroidx/appcompat/view/menu/KLFTb;->Pq:Ljava/lang/CharSequence;

    .line 3
    iget-object p1, p0, Landroidx/appcompat/view/menu/KLFTb;->YoKzxo:Landroidx/appcompat/view/menu/ZfxDd;

    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Landroidx/appcompat/view/menu/ZfxDd;->Ne(Z)V

    return-object p0
.end method

.method public setVisible(Z)Landroid/view/MenuItem;
    .locals 0

    invoke-virtual {p0, p1}, Landroidx/appcompat/view/menu/KLFTb;->Gd(Z)Z

    move-result p1

    if-eqz p1, :cond_0

    iget-object p1, p0, Landroidx/appcompat/view/menu/KLFTb;->YoKzxo:Landroidx/appcompat/view/menu/ZfxDd;

    invoke-virtual {p1, p0}, Landroidx/appcompat/view/menu/ZfxDd;->OjSQV(Landroidx/appcompat/view/menu/KLFTb;)V

    :cond_0
    return-object p0
.end method

.method public toString()Ljava/lang/String;
    .locals 0

    iget-object p0, p0, Landroidx/appcompat/view/menu/KLFTb;->KLFTb:Ljava/lang/CharSequence;

    if-eqz p0, :cond_0

    invoke-interface {p0}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object p0

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return-object p0
.end method

.method public vI()Z
    .locals 1

    iget-object v0, p0, Landroidx/appcompat/view/menu/KLFTb;->YoKzxo:Landroidx/appcompat/view/menu/ZfxDd;

    invoke-virtual {v0}, Landroidx/appcompat/view/menu/ZfxDd;->wJVbdd()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-virtual {p0}, Landroidx/appcompat/view/menu/KLFTb;->KLFTb()C

    move-result p0

    if-eqz p0, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method

.method public final wA(Landroid/graphics/drawable/Drawable;)Landroid/graphics/drawable/Drawable;
    .locals 1

    if-eqz p1, :cond_3

    iget-boolean v0, p0, Landroidx/appcompat/view/menu/KLFTb;->Gd:Z

    if-eqz v0, :cond_3

    iget-boolean v0, p0, Landroidx/appcompat/view/menu/KLFTb;->Ucbh:Z

    if-nez v0, :cond_0

    iget-boolean v0, p0, Landroidx/appcompat/view/menu/KLFTb;->huTpC:Z

    if-eqz v0, :cond_3

    :cond_0
    invoke-static {p1}, Lo/pCk;->VA(Landroid/graphics/drawable/Drawable;)Landroid/graphics/drawable/Drawable;

    move-result-object p1

    invoke-virtual {p1}, Landroid/graphics/drawable/Drawable;->mutate()Landroid/graphics/drawable/Drawable;

    move-result-object p1

    iget-boolean v0, p0, Landroidx/appcompat/view/menu/KLFTb;->Ucbh:Z

    if-eqz v0, :cond_1

    iget-object v0, p0, Landroidx/appcompat/view/menu/KLFTb;->diqgf:Landroid/content/res/ColorStateList;

    invoke-static {p1, v0}, Lo/pCk;->qdMbNW(Landroid/graphics/drawable/Drawable;Landroid/content/res/ColorStateList;)V

    :cond_1
    iget-boolean v0, p0, Landroidx/appcompat/view/menu/KLFTb;->huTpC:Z

    if-eqz v0, :cond_2

    iget-object v0, p0, Landroidx/appcompat/view/menu/KLFTb;->eyqo:Landroid/graphics/PorterDuff$Mode;

    invoke-static {p1, v0}, Lo/pCk;->Dt(Landroid/graphics/drawable/Drawable;Landroid/graphics/PorterDuff$Mode;)V

    :cond_2
    const/4 v0, 0x0

    iput-boolean v0, p0, Landroidx/appcompat/view/menu/KLFTb;->Gd:Z

    :cond_3
    return-object p1
.end method

.method public xJ()Lo/mByQ;
    .locals 0

    const/4 p0, 0x0

    return-object p0
.end method
