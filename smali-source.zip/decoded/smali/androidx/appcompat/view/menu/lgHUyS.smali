.class public interface abstract Landroidx/appcompat/view/menu/lgHUyS;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/appcompat/view/menu/lgHUyS$mjFkc;
    }
.end annotation
