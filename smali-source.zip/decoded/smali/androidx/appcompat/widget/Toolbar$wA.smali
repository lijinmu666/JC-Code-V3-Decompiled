.class public Landroidx/appcompat/widget/Toolbar$wA;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/appcompat/view/menu/ZfxDd$mjFkc;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Landroidx/appcompat/widget/Toolbar;->qdMbNW()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic mjFkc:Landroidx/appcompat/widget/Toolbar;


# direct methods
.method public constructor <init>(Landroidx/appcompat/widget/Toolbar;)V
    .locals 0

    iput-object p1, p0, Landroidx/appcompat/widget/Toolbar$wA;->mjFkc:Landroidx/appcompat/widget/Toolbar;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public AZxh(Landroidx/appcompat/view/menu/ZfxDd;)V
    .locals 1

    iget-object v0, p0, Landroidx/appcompat/widget/Toolbar$wA;->mjFkc:Landroidx/appcompat/widget/Toolbar;

    iget-object v0, v0, Landroidx/appcompat/widget/Toolbar;->mjFkc:Landroidx/appcompat/widget/ActionMenuView;

    invoke-virtual {v0}, Landroidx/appcompat/widget/ActionMenuView;->CqaNbM()Z

    move-result v0

    if-nez v0, :cond_0

    iget-object v0, p0, Landroidx/appcompat/widget/Toolbar$wA;->mjFkc:Landroidx/appcompat/widget/Toolbar;

    iget-object v0, v0, Landroidx/appcompat/widget/Toolbar;->Ne:Lo/V1;

    invoke-virtual {v0, p1}, Lo/V1;->wA(Landroid/view/Menu;)V

    :cond_0
    iget-object p0, p0, Landroidx/appcompat/widget/Toolbar$wA;->mjFkc:Landroidx/appcompat/widget/Toolbar;

    iget-object p0, p0, Landroidx/appcompat/widget/Toolbar;->Vnb:Landroidx/appcompat/view/menu/ZfxDd$mjFkc;

    if-eqz p0, :cond_1

    invoke-interface {p0, p1}, Landroidx/appcompat/view/menu/ZfxDd$mjFkc;->AZxh(Landroidx/appcompat/view/menu/ZfxDd;)V

    :cond_1
    return-void
.end method

.method public mjFkc(Landroidx/appcompat/view/menu/ZfxDd;Landroid/view/MenuItem;)Z
    .locals 0

    iget-object p0, p0, Landroidx/appcompat/widget/Toolbar$wA;->mjFkc:Landroidx/appcompat/widget/Toolbar;

    iget-object p0, p0, Landroidx/appcompat/widget/Toolbar;->Vnb:Landroidx/appcompat/view/menu/ZfxDd$mjFkc;

    if-eqz p0, :cond_0

    invoke-interface {p0, p1, p2}, Landroidx/appcompat/view/menu/ZfxDd$mjFkc;->mjFkc(Landroidx/appcompat/view/menu/ZfxDd;Landroid/view/MenuItem;)Z

    move-result p0

    if-eqz p0, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method
