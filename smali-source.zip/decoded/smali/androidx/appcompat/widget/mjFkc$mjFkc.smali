.class public Landroidx/appcompat/widget/mjFkc$mjFkc;
.super Landroidx/appcompat/view/menu/JHa;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/appcompat/widget/mjFkc;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "mjFkc"
.end annotation


# instance fields
.field public final synthetic MiMN:Landroidx/appcompat/widget/mjFkc;


# direct methods
.method public constructor <init>(Landroidx/appcompat/widget/mjFkc;Landroid/content/Context;Landroidx/appcompat/view/menu/Dt;Landroid/view/View;)V
    .locals 6

    iput-object p1, p0, Landroidx/appcompat/widget/mjFkc$mjFkc;->MiMN:Landroidx/appcompat/widget/mjFkc;

    const/4 v4, 0x0

    sget v5, Lo/i4;->JHa:I

    move-object v0, p0

    move-object v1, p2

    move-object v2, p3

    move-object v3, p4

    invoke-direct/range {v0 .. v5}, Landroidx/appcompat/view/menu/JHa;-><init>(Landroid/content/Context;Landroidx/appcompat/view/menu/ZfxDd;Landroid/view/View;ZI)V

    invoke-virtual {p3}, Landroidx/appcompat/view/menu/Dt;->getItem()Landroid/view/MenuItem;

    move-result-object p2

    check-cast p2, Landroidx/appcompat/view/menu/KLFTb;

    invoke-virtual {p2}, Landroidx/appcompat/view/menu/KLFTb;->ETF()Z

    move-result p2

    if-nez p2, :cond_1

    iget-object p2, p1, Landroidx/appcompat/widget/mjFkc;->Dt:Landroidx/appcompat/widget/mjFkc$ZfxDd;

    if-nez p2, :cond_0

    invoke-static {p1}, Landroidx/appcompat/widget/mjFkc;->IEE(Landroidx/appcompat/widget/mjFkc;)Landroidx/appcompat/view/menu/lgHUyS;

    move-result-object p2

    check-cast p2, Landroid/view/View;

    :cond_0
    invoke-virtual {p0, p2}, Landroidx/appcompat/view/menu/JHa;->JHa(Landroid/view/View;)V

    :cond_1
    iget-object p1, p1, Landroidx/appcompat/widget/mjFkc;->BAnRFn:Landroidx/appcompat/widget/mjFkc$JHa;

    invoke-virtual {p0, p1}, Landroidx/appcompat/view/menu/JHa;->Dt(Landroidx/appcompat/view/menu/xJ$mjFkc;)V

    return-void
.end method


# virtual methods
.method public KLFTb()V
    .locals 2

    iget-object v0, p0, Landroidx/appcompat/widget/mjFkc$mjFkc;->MiMN:Landroidx/appcompat/widget/mjFkc;

    const/4 v1, 0x0

    iput-object v1, v0, Landroidx/appcompat/widget/mjFkc;->HGpJ:Landroidx/appcompat/widget/mjFkc$mjFkc;

    const/4 v1, 0x0

    iput v1, v0, Landroidx/appcompat/widget/mjFkc;->lB:I

    invoke-super {p0}, Landroidx/appcompat/view/menu/JHa;->KLFTb()V

    return-void
.end method
