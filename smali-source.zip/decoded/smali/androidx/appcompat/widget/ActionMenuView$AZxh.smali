.class public Landroidx/appcompat/widget/ActionMenuView$AZxh;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/appcompat/view/menu/xJ$mjFkc;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/appcompat/widget/ActionMenuView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "AZxh"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public AZxh(Landroidx/appcompat/view/menu/ZfxDd;Z)V
    .locals 0

    return-void
.end method

.method public wA(Landroidx/appcompat/view/menu/ZfxDd;)Z
    .locals 0

    const/4 p0, 0x0

    return p0
.end method
