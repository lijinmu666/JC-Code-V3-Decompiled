.class public Landroidx/appcompat/widget/ZfxDd;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lo/VzXmn;


# instance fields
.field public AZxh:I

.field public Dt:Ljava/lang/CharSequence;

.field public ETF:Landroid/view/Window$Callback;

.field public JHa:Landroid/graphics/drawable/Drawable;

.field public KLFTb:Landroid/graphics/drawable/Drawable;

.field public MiMN:I

.field public VA:Z

.field public YoKzxo:I

.field public ZfxDd:Landroid/graphics/drawable/Drawable;

.field public lgHUyS:Ljava/lang/CharSequence;

.field public mjFkc:Landroidx/appcompat/widget/Toolbar;

.field public qdMbNW:Ljava/lang/CharSequence;

.field public rkYL:Landroid/graphics/drawable/Drawable;

.field public wA:Landroid/view/View;

.field public xJ:Z


# direct methods
.method public constructor <init>(Landroidx/appcompat/widget/Toolbar;Z)V
    .locals 2

    .line 1
    sget v0, Lo/O4;->mjFkc:I

    sget v1, Lo/t4;->YoKzxo:I

    invoke-direct {p0, p1, p2, v0, v1}, Landroidx/appcompat/widget/ZfxDd;-><init>(Landroidx/appcompat/widget/Toolbar;ZII)V

    return-void
.end method

.method public constructor <init>(Landroidx/appcompat/widget/Toolbar;ZII)V
    .locals 3

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 p4, 0x0

    .line 3
    iput p4, p0, Landroidx/appcompat/widget/ZfxDd;->MiMN:I

    .line 4
    iput p4, p0, Landroidx/appcompat/widget/ZfxDd;->YoKzxo:I

    .line 5
    iput-object p1, p0, Landroidx/appcompat/widget/ZfxDd;->mjFkc:Landroidx/appcompat/widget/Toolbar;

    .line 6
    invoke-virtual {p1}, Landroidx/appcompat/widget/Toolbar;->getTitle()Ljava/lang/CharSequence;

    move-result-object v0

    iput-object v0, p0, Landroidx/appcompat/widget/ZfxDd;->lgHUyS:Ljava/lang/CharSequence;

    .line 7
    invoke-virtual {p1}, Landroidx/appcompat/widget/Toolbar;->getSubtitle()Ljava/lang/CharSequence;

    move-result-object v0

    iput-object v0, p0, Landroidx/appcompat/widget/ZfxDd;->qdMbNW:Ljava/lang/CharSequence;

    .line 8
    iget-object v0, p0, Landroidx/appcompat/widget/ZfxDd;->lgHUyS:Ljava/lang/CharSequence;

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    move v0, p4

    :goto_0
    iput-boolean v0, p0, Landroidx/appcompat/widget/ZfxDd;->xJ:Z

    .line 9
    invoke-virtual {p1}, Landroidx/appcompat/widget/Toolbar;->getNavigationIcon()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    iput-object v0, p0, Landroidx/appcompat/widget/ZfxDd;->JHa:Landroid/graphics/drawable/Drawable;

    .line 10
    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p1

    sget-object v0, Lo/b5;->mjFkc:[I

    sget v1, Lo/i4;->wA:I

    const/4 v2, 0x0

    invoke-static {p1, v2, v0, v1, p4}, Lo/A8;->diqgf(Landroid/content/Context;Landroid/util/AttributeSet;[III)Lo/A8;

    move-result-object p1

    .line 11
    sget v0, Lo/b5;->Dt:I

    invoke-virtual {p1, v0}, Lo/A8;->xJ(I)Landroid/graphics/drawable/Drawable;

    move-result-object v0

    iput-object v0, p0, Landroidx/appcompat/widget/ZfxDd;->rkYL:Landroid/graphics/drawable/Drawable;

    if-eqz p2, :cond_c

    .line 12
    sget p2, Lo/b5;->qGY:I

    invoke-virtual {p1, p2}, Lo/A8;->rkYL(I)Ljava/lang/CharSequence;

    move-result-object p2

    .line 13
    invoke-static {p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_1

    .line 14
    invoke-virtual {p0, p2}, Landroidx/appcompat/widget/ZfxDd;->YoKzxo(Ljava/lang/CharSequence;)V

    .line 15
    :cond_1
    sget p2, Lo/b5;->YoKzxo:I

    invoke-virtual {p1, p2}, Lo/A8;->rkYL(I)Ljava/lang/CharSequence;

    move-result-object p2

    .line 16
    invoke-static {p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_2

    .line 17
    invoke-virtual {p0, p2}, Landroidx/appcompat/widget/ZfxDd;->MiMN(Ljava/lang/CharSequence;)V

    .line 18
    :cond_2
    sget p2, Lo/b5;->VA:I

    invoke-virtual {p1, p2}, Lo/A8;->xJ(I)Landroid/graphics/drawable/Drawable;

    move-result-object p2

    if-eqz p2, :cond_3

    .line 19
    invoke-virtual {p0, p2}, Landroidx/appcompat/widget/ZfxDd;->qdMbNW(Landroid/graphics/drawable/Drawable;)V

    .line 20
    :cond_3
    sget p2, Lo/b5;->ETF:I

    invoke-virtual {p1, p2}, Lo/A8;->xJ(I)Landroid/graphics/drawable/Drawable;

    move-result-object p2

    if-eqz p2, :cond_4

    .line 21
    invoke-virtual {p0, p2}, Landroidx/appcompat/widget/ZfxDd;->setIcon(Landroid/graphics/drawable/Drawable;)V

    .line 22
    :cond_4
    iget-object p2, p0, Landroidx/appcompat/widget/ZfxDd;->JHa:Landroid/graphics/drawable/Drawable;

    if-nez p2, :cond_5

    iget-object p2, p0, Landroidx/appcompat/widget/ZfxDd;->rkYL:Landroid/graphics/drawable/Drawable;

    if-eqz p2, :cond_5

    .line 23
    invoke-virtual {p0, p2}, Landroidx/appcompat/widget/ZfxDd;->VA(Landroid/graphics/drawable/Drawable;)V

    .line 24
    :cond_5
    sget p2, Lo/b5;->lgHUyS:I

    invoke-virtual {p1, p2, p4}, Lo/A8;->Dt(II)I

    move-result p2

    invoke-virtual {p0, p2}, Landroidx/appcompat/widget/ZfxDd;->lgHUyS(I)V

    .line 25
    sget p2, Lo/b5;->xJ:I

    invoke-virtual {p1, p2, p4}, Lo/A8;->MiMN(II)I

    move-result p2

    if-eqz p2, :cond_6

    .line 26
    iget-object v0, p0, Landroidx/appcompat/widget/ZfxDd;->mjFkc:Landroidx/appcompat/widget/Toolbar;

    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object v0

    iget-object v1, p0, Landroidx/appcompat/widget/ZfxDd;->mjFkc:Landroidx/appcompat/widget/Toolbar;

    invoke-virtual {v0, p2, v1, p4}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object p2

    invoke-virtual {p0, p2}, Landroidx/appcompat/widget/ZfxDd;->JHa(Landroid/view/View;)V

    .line 27
    iget p2, p0, Landroidx/appcompat/widget/ZfxDd;->AZxh:I

    or-int/lit8 p2, p2, 0x10

    invoke-virtual {p0, p2}, Landroidx/appcompat/widget/ZfxDd;->lgHUyS(I)V

    .line 28
    :cond_6
    sget p2, Lo/b5;->qdMbNW:I

    invoke-virtual {p1, p2, p4}, Lo/A8;->VA(II)I

    move-result p2

    if-lez p2, :cond_7

    .line 29
    iget-object v0, p0, Landroidx/appcompat/widget/ZfxDd;->mjFkc:Landroidx/appcompat/widget/Toolbar;

    invoke-virtual {v0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    .line 30
    iput p2, v0, Landroid/view/ViewGroup$LayoutParams;->height:I

    .line 31
    iget-object p2, p0, Landroidx/appcompat/widget/ZfxDd;->mjFkc:Landroidx/appcompat/widget/Toolbar;

    invoke-virtual {p2, v0}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 32
    :cond_7
    sget p2, Lo/b5;->JHa:I

    const/4 v0, -0x1

    invoke-virtual {p1, p2, v0}, Lo/A8;->KLFTb(II)I

    move-result p2

    .line 33
    sget v1, Lo/b5;->KLFTb:I

    invoke-virtual {p1, v1, v0}, Lo/A8;->KLFTb(II)I

    move-result v0

    if-gez p2, :cond_8

    if-ltz v0, :cond_9

    .line 34
    :cond_8
    iget-object v1, p0, Landroidx/appcompat/widget/ZfxDd;->mjFkc:Landroidx/appcompat/widget/Toolbar;

    invoke-static {p2, p4}, Ljava/lang/Math;->max(II)I

    move-result p2

    .line 35
    invoke-static {v0, p4}, Ljava/lang/Math;->max(II)I

    move-result v0

    .line 36
    invoke-virtual {v1, p2, v0}, Landroidx/appcompat/widget/Toolbar;->OjSQV(II)V

    .line 37
    :cond_9
    sget p2, Lo/b5;->fehf:I

    invoke-virtual {p1, p2, p4}, Lo/A8;->MiMN(II)I

    move-result p2

    if-eqz p2, :cond_a

    .line 38
    iget-object v0, p0, Landroidx/appcompat/widget/ZfxDd;->mjFkc:Landroidx/appcompat/widget/Toolbar;

    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-virtual {v0, v1, p2}, Landroidx/appcompat/widget/Toolbar;->CqaNbM(Landroid/content/Context;I)V

    .line 39
    :cond_a
    sget p2, Lo/b5;->rkYL:I

    invoke-virtual {p1, p2, p4}, Lo/A8;->MiMN(II)I

    move-result p2

    if-eqz p2, :cond_b

    .line 40
    iget-object v0, p0, Landroidx/appcompat/widget/ZfxDd;->mjFkc:Landroidx/appcompat/widget/Toolbar;

    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-virtual {v0, v1, p2}, Landroidx/appcompat/widget/Toolbar;->Ne(Landroid/content/Context;I)V

    .line 41
    :cond_b
    sget p2, Lo/b5;->MiMN:I

    invoke-virtual {p1, p2, p4}, Lo/A8;->MiMN(II)I

    move-result p2

    if-eqz p2, :cond_d

    .line 42
    iget-object p4, p0, Landroidx/appcompat/widget/ZfxDd;->mjFkc:Landroidx/appcompat/widget/Toolbar;

    invoke-virtual {p4, p2}, Landroidx/appcompat/widget/Toolbar;->setPopupTheme(I)V

    goto :goto_1

    .line 43
    :cond_c
    invoke-virtual {p0}, Landroidx/appcompat/widget/ZfxDd;->ZfxDd()I

    move-result p2

    iput p2, p0, Landroidx/appcompat/widget/ZfxDd;->AZxh:I

    .line 44
    :cond_d
    :goto_1
    invoke-virtual {p1}, Lo/A8;->eyqo()V

    .line 45
    invoke-virtual {p0, p3}, Landroidx/appcompat/widget/ZfxDd;->xJ(I)V

    .line 46
    iget-object p1, p0, Landroidx/appcompat/widget/ZfxDd;->mjFkc:Landroidx/appcompat/widget/Toolbar;

    invoke-virtual {p1}, Landroidx/appcompat/widget/Toolbar;->getNavigationContentDescription()Ljava/lang/CharSequence;

    move-result-object p1

    iput-object p1, p0, Landroidx/appcompat/widget/ZfxDd;->Dt:Ljava/lang/CharSequence;

    .line 47
    iget-object p1, p0, Landroidx/appcompat/widget/ZfxDd;->mjFkc:Landroidx/appcompat/widget/Toolbar;

    new-instance p2, Landroidx/appcompat/widget/ZfxDd$mjFkc;

    invoke-direct {p2, p0}, Landroidx/appcompat/widget/ZfxDd$mjFkc;-><init>(Landroidx/appcompat/widget/ZfxDd;)V

    invoke-virtual {p1, p2}, Landroidx/appcompat/widget/Toolbar;->setNavigationOnClickListener(Landroid/view/View$OnClickListener;)V

    return-void
.end method


# virtual methods
.method public AZxh(Landroid/view/Window$Callback;)V
    .locals 0

    iput-object p1, p0, Landroidx/appcompat/widget/ZfxDd;->ETF:Landroid/view/Window$Callback;

    return-void
.end method

.method public Dt(I)V
    .locals 1

    if-nez p1, :cond_0

    const/4 p1, 0x0

    goto :goto_0

    :cond_0
    invoke-virtual {p0}, Landroidx/appcompat/widget/ZfxDd;->KLFTb()Landroid/content/Context;

    move-result-object v0

    invoke-virtual {v0, p1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object p1

    :goto_0
    invoke-virtual {p0, p1}, Landroidx/appcompat/widget/ZfxDd;->ETF(Ljava/lang/CharSequence;)V

    return-void
.end method

.method public ETF(Ljava/lang/CharSequence;)V
    .locals 0

    iput-object p1, p0, Landroidx/appcompat/widget/ZfxDd;->Dt:Ljava/lang/CharSequence;

    invoke-virtual {p0}, Landroidx/appcompat/widget/ZfxDd;->qGY()V

    return-void
.end method

.method public final IEE()V
    .locals 2

    iget v0, p0, Landroidx/appcompat/widget/ZfxDd;->AZxh:I

    and-int/lit8 v1, v0, 0x2

    if-eqz v1, :cond_2

    and-int/lit8 v0, v0, 0x1

    if-eqz v0, :cond_1

    iget-object v0, p0, Landroidx/appcompat/widget/ZfxDd;->KLFTb:Landroid/graphics/drawable/Drawable;

    if-eqz v0, :cond_0

    goto :goto_0

    :cond_0
    iget-object v0, p0, Landroidx/appcompat/widget/ZfxDd;->ZfxDd:Landroid/graphics/drawable/Drawable;

    goto :goto_0

    :cond_1
    iget-object v0, p0, Landroidx/appcompat/widget/ZfxDd;->ZfxDd:Landroid/graphics/drawable/Drawable;

    goto :goto_0

    :cond_2
    const/4 v0, 0x0

    :goto_0
    iget-object p0, p0, Landroidx/appcompat/widget/ZfxDd;->mjFkc:Landroidx/appcompat/widget/Toolbar;

    invoke-virtual {p0, v0}, Landroidx/appcompat/widget/Toolbar;->setLogo(Landroid/graphics/drawable/Drawable;)V

    return-void
.end method

.method public JHa(Landroid/view/View;)V
    .locals 2

    iget-object v0, p0, Landroidx/appcompat/widget/ZfxDd;->wA:Landroid/view/View;

    if-eqz v0, :cond_0

    iget v1, p0, Landroidx/appcompat/widget/ZfxDd;->AZxh:I

    and-int/lit8 v1, v1, 0x10

    if-eqz v1, :cond_0

    iget-object v1, p0, Landroidx/appcompat/widget/ZfxDd;->mjFkc:Landroidx/appcompat/widget/Toolbar;

    invoke-virtual {v1, v0}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    :cond_0
    iput-object p1, p0, Landroidx/appcompat/widget/ZfxDd;->wA:Landroid/view/View;

    if-eqz p1, :cond_1

    iget v0, p0, Landroidx/appcompat/widget/ZfxDd;->AZxh:I

    and-int/lit8 v0, v0, 0x10

    if-eqz v0, :cond_1

    iget-object p0, p0, Landroidx/appcompat/widget/ZfxDd;->mjFkc:Landroidx/appcompat/widget/Toolbar;

    invoke-virtual {p0, p1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    :cond_1
    return-void
.end method

.method public KLFTb()Landroid/content/Context;
    .locals 0

    iget-object p0, p0, Landroidx/appcompat/widget/ZfxDd;->mjFkc:Landroidx/appcompat/widget/Toolbar;

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p0

    return-object p0
.end method

.method public MiMN(Ljava/lang/CharSequence;)V
    .locals 1

    iput-object p1, p0, Landroidx/appcompat/widget/ZfxDd;->qdMbNW:Ljava/lang/CharSequence;

    iget v0, p0, Landroidx/appcompat/widget/ZfxDd;->AZxh:I

    and-int/lit8 v0, v0, 0x8

    if-eqz v0, :cond_0

    iget-object p0, p0, Landroidx/appcompat/widget/ZfxDd;->mjFkc:Landroidx/appcompat/widget/Toolbar;

    invoke-virtual {p0, p1}, Landroidx/appcompat/widget/Toolbar;->setSubtitle(Ljava/lang/CharSequence;)V

    :cond_0
    return-void
.end method

.method public VA(Landroid/graphics/drawable/Drawable;)V
    .locals 0

    iput-object p1, p0, Landroidx/appcompat/widget/ZfxDd;->JHa:Landroid/graphics/drawable/Drawable;

    invoke-virtual {p0}, Landroidx/appcompat/widget/ZfxDd;->fehf()V

    return-void
.end method

.method public YoKzxo(Ljava/lang/CharSequence;)V
    .locals 1

    const/4 v0, 0x1

    iput-boolean v0, p0, Landroidx/appcompat/widget/ZfxDd;->xJ:Z

    invoke-virtual {p0, p1}, Landroidx/appcompat/widget/ZfxDd;->rkYL(Ljava/lang/CharSequence;)V

    return-void
.end method

.method public final ZfxDd()I
    .locals 1

    iget-object v0, p0, Landroidx/appcompat/widget/ZfxDd;->mjFkc:Landroidx/appcompat/widget/Toolbar;

    invoke-virtual {v0}, Landroidx/appcompat/widget/Toolbar;->getNavigationIcon()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Landroidx/appcompat/widget/ZfxDd;->mjFkc:Landroidx/appcompat/widget/Toolbar;

    invoke-virtual {v0}, Landroidx/appcompat/widget/Toolbar;->getNavigationIcon()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    iput-object v0, p0, Landroidx/appcompat/widget/ZfxDd;->rkYL:Landroid/graphics/drawable/Drawable;

    const/16 p0, 0xf

    goto :goto_0

    :cond_0
    const/16 p0, 0xb

    :goto_0
    return p0
.end method

.method public final fehf()V
    .locals 2

    iget v0, p0, Landroidx/appcompat/widget/ZfxDd;->AZxh:I

    and-int/lit8 v0, v0, 0x4

    if-eqz v0, :cond_1

    iget-object v0, p0, Landroidx/appcompat/widget/ZfxDd;->mjFkc:Landroidx/appcompat/widget/Toolbar;

    iget-object v1, p0, Landroidx/appcompat/widget/ZfxDd;->JHa:Landroid/graphics/drawable/Drawable;

    if-eqz v1, :cond_0

    goto :goto_0

    :cond_0
    iget-object v1, p0, Landroidx/appcompat/widget/ZfxDd;->rkYL:Landroid/graphics/drawable/Drawable;

    :goto_0
    invoke-virtual {v0, v1}, Landroidx/appcompat/widget/Toolbar;->setNavigationIcon(Landroid/graphics/drawable/Drawable;)V

    goto :goto_1

    :cond_1
    iget-object p0, p0, Landroidx/appcompat/widget/ZfxDd;->mjFkc:Landroidx/appcompat/widget/Toolbar;

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Landroidx/appcompat/widget/Toolbar;->setNavigationIcon(Landroid/graphics/drawable/Drawable;)V

    :goto_1
    return-void
.end method

.method public getTitle()Ljava/lang/CharSequence;
    .locals 0

    iget-object p0, p0, Landroidx/appcompat/widget/ZfxDd;->mjFkc:Landroidx/appcompat/widget/Toolbar;

    invoke-virtual {p0}, Landroidx/appcompat/widget/Toolbar;->getTitle()Ljava/lang/CharSequence;

    move-result-object p0

    return-object p0
.end method

.method public lgHUyS(I)V
    .locals 3

    iget v0, p0, Landroidx/appcompat/widget/ZfxDd;->AZxh:I

    xor-int/2addr v0, p1

    iput p1, p0, Landroidx/appcompat/widget/ZfxDd;->AZxh:I

    if-eqz v0, :cond_6

    and-int/lit8 v1, v0, 0x4

    if-eqz v1, :cond_1

    and-int/lit8 v1, p1, 0x4

    if-eqz v1, :cond_0

    invoke-virtual {p0}, Landroidx/appcompat/widget/ZfxDd;->qGY()V

    :cond_0
    invoke-virtual {p0}, Landroidx/appcompat/widget/ZfxDd;->fehf()V

    :cond_1
    and-int/lit8 v1, v0, 0x3

    if-eqz v1, :cond_2

    invoke-virtual {p0}, Landroidx/appcompat/widget/ZfxDd;->IEE()V

    :cond_2
    and-int/lit8 v1, v0, 0x8

    if-eqz v1, :cond_4

    and-int/lit8 v1, p1, 0x8

    if-eqz v1, :cond_3

    iget-object v1, p0, Landroidx/appcompat/widget/ZfxDd;->mjFkc:Landroidx/appcompat/widget/Toolbar;

    iget-object v2, p0, Landroidx/appcompat/widget/ZfxDd;->lgHUyS:Ljava/lang/CharSequence;

    invoke-virtual {v1, v2}, Landroidx/appcompat/widget/Toolbar;->setTitle(Ljava/lang/CharSequence;)V

    iget-object v1, p0, Landroidx/appcompat/widget/ZfxDd;->mjFkc:Landroidx/appcompat/widget/Toolbar;

    iget-object v2, p0, Landroidx/appcompat/widget/ZfxDd;->qdMbNW:Ljava/lang/CharSequence;

    invoke-virtual {v1, v2}, Landroidx/appcompat/widget/Toolbar;->setSubtitle(Ljava/lang/CharSequence;)V

    goto :goto_0

    :cond_3
    iget-object v1, p0, Landroidx/appcompat/widget/ZfxDd;->mjFkc:Landroidx/appcompat/widget/Toolbar;

    const/4 v2, 0x0

    invoke-virtual {v1, v2}, Landroidx/appcompat/widget/Toolbar;->setTitle(Ljava/lang/CharSequence;)V

    iget-object v1, p0, Landroidx/appcompat/widget/ZfxDd;->mjFkc:Landroidx/appcompat/widget/Toolbar;

    invoke-virtual {v1, v2}, Landroidx/appcompat/widget/Toolbar;->setSubtitle(Ljava/lang/CharSequence;)V

    :cond_4
    :goto_0
    and-int/lit8 v0, v0, 0x10

    if-eqz v0, :cond_6

    iget-object v0, p0, Landroidx/appcompat/widget/ZfxDd;->wA:Landroid/view/View;

    if-eqz v0, :cond_6

    and-int/lit8 p1, p1, 0x10

    if-eqz p1, :cond_5

    iget-object p0, p0, Landroidx/appcompat/widget/ZfxDd;->mjFkc:Landroidx/appcompat/widget/Toolbar;

    invoke-virtual {p0, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    goto :goto_1

    :cond_5
    iget-object p0, p0, Landroidx/appcompat/widget/ZfxDd;->mjFkc:Landroidx/appcompat/widget/Toolbar;

    invoke-virtual {p0, v0}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    :cond_6
    :goto_1
    return-void
.end method

.method public mjFkc(Ljava/lang/CharSequence;)V
    .locals 1

    iget-boolean v0, p0, Landroidx/appcompat/widget/ZfxDd;->xJ:Z

    if-nez v0, :cond_0

    invoke-virtual {p0, p1}, Landroidx/appcompat/widget/ZfxDd;->rkYL(Ljava/lang/CharSequence;)V

    :cond_0
    return-void
.end method

.method public final qGY()V
    .locals 1

    iget v0, p0, Landroidx/appcompat/widget/ZfxDd;->AZxh:I

    and-int/lit8 v0, v0, 0x4

    if-eqz v0, :cond_1

    iget-object v0, p0, Landroidx/appcompat/widget/ZfxDd;->Dt:Ljava/lang/CharSequence;

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Landroidx/appcompat/widget/ZfxDd;->mjFkc:Landroidx/appcompat/widget/Toolbar;

    iget p0, p0, Landroidx/appcompat/widget/ZfxDd;->YoKzxo:I

    invoke-virtual {v0, p0}, Landroidx/appcompat/widget/Toolbar;->setNavigationContentDescription(I)V

    goto :goto_0

    :cond_0
    iget-object v0, p0, Landroidx/appcompat/widget/ZfxDd;->mjFkc:Landroidx/appcompat/widget/Toolbar;

    iget-object p0, p0, Landroidx/appcompat/widget/ZfxDd;->Dt:Ljava/lang/CharSequence;

    invoke-virtual {v0, p0}, Landroidx/appcompat/widget/Toolbar;->setNavigationContentDescription(Ljava/lang/CharSequence;)V

    :cond_1
    :goto_0
    return-void
.end method

.method public qdMbNW(Landroid/graphics/drawable/Drawable;)V
    .locals 0

    iput-object p1, p0, Landroidx/appcompat/widget/ZfxDd;->KLFTb:Landroid/graphics/drawable/Drawable;

    invoke-virtual {p0}, Landroidx/appcompat/widget/ZfxDd;->IEE()V

    return-void
.end method

.method public final rkYL(Ljava/lang/CharSequence;)V
    .locals 1

    iput-object p1, p0, Landroidx/appcompat/widget/ZfxDd;->lgHUyS:Ljava/lang/CharSequence;

    iget v0, p0, Landroidx/appcompat/widget/ZfxDd;->AZxh:I

    and-int/lit8 v0, v0, 0x8

    if-eqz v0, :cond_0

    iget-object v0, p0, Landroidx/appcompat/widget/ZfxDd;->mjFkc:Landroidx/appcompat/widget/Toolbar;

    invoke-virtual {v0, p1}, Landroidx/appcompat/widget/Toolbar;->setTitle(Ljava/lang/CharSequence;)V

    iget-boolean v0, p0, Landroidx/appcompat/widget/ZfxDd;->xJ:Z

    if-eqz v0, :cond_0

    iget-object p0, p0, Landroidx/appcompat/widget/ZfxDd;->mjFkc:Landroidx/appcompat/widget/Toolbar;

    invoke-virtual {p0}, Landroid/view/View;->getRootView()Landroid/view/View;

    move-result-object p0

    invoke-static {p0, p1}, Lo/T9;->yfx(Landroid/view/View;Ljava/lang/CharSequence;)V

    :cond_0
    return-void
.end method

.method public setIcon(I)V
    .locals 1

    if-eqz p1, :cond_0

    .line 1
    invoke-virtual {p0}, Landroidx/appcompat/widget/ZfxDd;->KLFTb()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0, p1}, Lo/vjlshU;->AZxh(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    move-result-object p1

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    :goto_0
    invoke-virtual {p0, p1}, Landroidx/appcompat/widget/ZfxDd;->setIcon(Landroid/graphics/drawable/Drawable;)V

    return-void
.end method

.method public setIcon(Landroid/graphics/drawable/Drawable;)V
    .locals 0

    .line 2
    iput-object p1, p0, Landroidx/appcompat/widget/ZfxDd;->ZfxDd:Landroid/graphics/drawable/Drawable;

    .line 3
    invoke-virtual {p0}, Landroidx/appcompat/widget/ZfxDd;->IEE()V

    return-void
.end method

.method public wA(I)V
    .locals 1

    if-eqz p1, :cond_0

    invoke-virtual {p0}, Landroidx/appcompat/widget/ZfxDd;->KLFTb()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0, p1}, Lo/vjlshU;->AZxh(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    move-result-object p1

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    :goto_0
    invoke-virtual {p0, p1}, Landroidx/appcompat/widget/ZfxDd;->qdMbNW(Landroid/graphics/drawable/Drawable;)V

    return-void
.end method

.method public xJ(I)V
    .locals 1

    iget v0, p0, Landroidx/appcompat/widget/ZfxDd;->YoKzxo:I

    if-ne p1, v0, :cond_0

    return-void

    :cond_0
    iput p1, p0, Landroidx/appcompat/widget/ZfxDd;->YoKzxo:I

    iget-object p1, p0, Landroidx/appcompat/widget/ZfxDd;->mjFkc:Landroidx/appcompat/widget/Toolbar;

    invoke-virtual {p1}, Landroidx/appcompat/widget/Toolbar;->getNavigationContentDescription()Ljava/lang/CharSequence;

    move-result-object p1

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p1

    if-eqz p1, :cond_1

    iget p1, p0, Landroidx/appcompat/widget/ZfxDd;->YoKzxo:I

    invoke-virtual {p0, p1}, Landroidx/appcompat/widget/ZfxDd;->Dt(I)V

    :cond_1
    return-void
.end method
