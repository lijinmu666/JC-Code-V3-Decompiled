.class public Landroidx/appcompat/widget/mjFkc$ZfxDd$mjFkc;
.super Lo/prww;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Landroidx/appcompat/widget/mjFkc$ZfxDd;-><init>(Landroidx/appcompat/widget/mjFkc;Landroid/content/Context;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic Dt:Landroidx/appcompat/widget/mjFkc;

.field public final synthetic ETF:Landroidx/appcompat/widget/mjFkc$ZfxDd;


# direct methods
.method public constructor <init>(Landroidx/appcompat/widget/mjFkc$ZfxDd;Landroid/view/View;Landroidx/appcompat/widget/mjFkc;)V
    .locals 0

    iput-object p1, p0, Landroidx/appcompat/widget/mjFkc$ZfxDd$mjFkc;->ETF:Landroidx/appcompat/widget/mjFkc$ZfxDd;

    iput-object p3, p0, Landroidx/appcompat/widget/mjFkc$ZfxDd$mjFkc;->Dt:Landroidx/appcompat/widget/mjFkc;

    invoke-direct {p0, p2}, Lo/prww;-><init>(Landroid/view/View;)V

    return-void
.end method


# virtual methods
.method public AZxh()Lo/Q6;
    .locals 0

    iget-object p0, p0, Landroidx/appcompat/widget/mjFkc$ZfxDd$mjFkc;->ETF:Landroidx/appcompat/widget/mjFkc$ZfxDd;

    iget-object p0, p0, Landroidx/appcompat/widget/mjFkc$ZfxDd;->ZfxDd:Landroidx/appcompat/widget/mjFkc;

    iget-object p0, p0, Landroidx/appcompat/widget/mjFkc;->Gd:Landroidx/appcompat/widget/mjFkc$KLFTb;

    if-nez p0, :cond_0

    const/4 p0, 0x0

    return-object p0

    :cond_0
    invoke-virtual {p0}, Landroidx/appcompat/view/menu/JHa;->wA()Lo/Y1;

    move-result-object p0

    return-object p0
.end method

.method public ZfxDd()Z
    .locals 1

    iget-object p0, p0, Landroidx/appcompat/widget/mjFkc$ZfxDd$mjFkc;->ETF:Landroidx/appcompat/widget/mjFkc$ZfxDd;

    iget-object p0, p0, Landroidx/appcompat/widget/mjFkc$ZfxDd;->ZfxDd:Landroidx/appcompat/widget/mjFkc;

    iget-object v0, p0, Landroidx/appcompat/widget/mjFkc;->vI:Landroidx/appcompat/widget/mjFkc$wA;

    if-eqz v0, :cond_0

    const/4 p0, 0x0

    return p0

    :cond_0
    invoke-virtual {p0}, Landroidx/appcompat/widget/mjFkc;->vI()Z

    const/4 p0, 0x1

    return p0
.end method

.method public wA()Z
    .locals 0

    iget-object p0, p0, Landroidx/appcompat/widget/mjFkc$ZfxDd$mjFkc;->ETF:Landroidx/appcompat/widget/mjFkc$ZfxDd;

    iget-object p0, p0, Landroidx/appcompat/widget/mjFkc$ZfxDd;->ZfxDd:Landroidx/appcompat/widget/mjFkc;

    invoke-virtual {p0}, Landroidx/appcompat/widget/mjFkc;->CqaNbM()Z

    const/4 p0, 0x1

    return p0
.end method
