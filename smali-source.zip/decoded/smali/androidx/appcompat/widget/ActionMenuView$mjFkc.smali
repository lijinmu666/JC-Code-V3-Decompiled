.class public interface abstract Landroidx/appcompat/widget/ActionMenuView$mjFkc;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/appcompat/widget/ActionMenuView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "mjFkc"
.end annotation


# virtual methods
.method public abstract AZxh()Z
.end method

.method public abstract mjFkc()Z
.end method
