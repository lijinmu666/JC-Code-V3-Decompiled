.class public Landroidx/appcompat/widget/mjFkc$KLFTb;
.super Landroidx/appcompat/view/menu/JHa;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/appcompat/widget/mjFkc;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "KLFTb"
.end annotation


# instance fields
.field public final synthetic MiMN:Landroidx/appcompat/widget/mjFkc;


# direct methods
.method public constructor <init>(Landroidx/appcompat/widget/mjFkc;Landroid/content/Context;Landroidx/appcompat/view/menu/ZfxDd;Landroid/view/View;Z)V
    .locals 6

    iput-object p1, p0, Landroidx/appcompat/widget/mjFkc$KLFTb;->MiMN:Landroidx/appcompat/widget/mjFkc;

    sget v5, Lo/i4;->JHa:I

    move-object v0, p0

    move-object v1, p2

    move-object v2, p3

    move-object v3, p4

    move v4, p5

    invoke-direct/range {v0 .. v5}, Landroidx/appcompat/view/menu/JHa;-><init>(Landroid/content/Context;Landroidx/appcompat/view/menu/ZfxDd;Landroid/view/View;ZI)V

    const p2, 0x800005

    invoke-virtual {p0, p2}, Landroidx/appcompat/view/menu/JHa;->lgHUyS(I)V

    iget-object p1, p1, Landroidx/appcompat/widget/mjFkc;->BAnRFn:Landroidx/appcompat/widget/mjFkc$JHa;

    invoke-virtual {p0, p1}, Landroidx/appcompat/view/menu/JHa;->Dt(Landroidx/appcompat/view/menu/xJ$mjFkc;)V

    return-void
.end method


# virtual methods
.method public KLFTb()V
    .locals 2

    iget-object v0, p0, Landroidx/appcompat/widget/mjFkc$KLFTb;->MiMN:Landroidx/appcompat/widget/mjFkc;

    invoke-static {v0}, Landroidx/appcompat/widget/mjFkc;->qGY(Landroidx/appcompat/widget/mjFkc;)Landroidx/appcompat/view/menu/ZfxDd;

    move-result-object v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Landroidx/appcompat/widget/mjFkc$KLFTb;->MiMN:Landroidx/appcompat/widget/mjFkc;

    invoke-static {v0}, Landroidx/appcompat/widget/mjFkc;->fehf(Landroidx/appcompat/widget/mjFkc;)Landroidx/appcompat/view/menu/ZfxDd;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/appcompat/view/menu/ZfxDd;->close()V

    :cond_0
    iget-object v0, p0, Landroidx/appcompat/widget/mjFkc$KLFTb;->MiMN:Landroidx/appcompat/widget/mjFkc;

    const/4 v1, 0x0

    iput-object v1, v0, Landroidx/appcompat/widget/mjFkc;->Gd:Landroidx/appcompat/widget/mjFkc$KLFTb;

    invoke-super {p0}, Landroidx/appcompat/view/menu/JHa;->KLFTb()V

    return-void
.end method
