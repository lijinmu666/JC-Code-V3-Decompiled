.class public Landroidx/appcompat/widget/mjFkc$JHa;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/appcompat/view/menu/xJ$mjFkc;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/appcompat/widget/mjFkc;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "JHa"
.end annotation


# instance fields
.field public final synthetic mjFkc:Landroidx/appcompat/widget/mjFkc;


# direct methods
.method public constructor <init>(Landroidx/appcompat/widget/mjFkc;)V
    .locals 0

    iput-object p1, p0, Landroidx/appcompat/widget/mjFkc$JHa;->mjFkc:Landroidx/appcompat/widget/mjFkc;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public AZxh(Landroidx/appcompat/view/menu/ZfxDd;Z)V
    .locals 2

    instance-of v0, p1, Landroidx/appcompat/view/menu/Dt;

    if-eqz v0, :cond_0

    invoke-virtual {p1}, Landroidx/appcompat/view/menu/ZfxDd;->vI()Landroidx/appcompat/view/menu/ZfxDd;

    move-result-object v0

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroidx/appcompat/view/menu/ZfxDd;->ZfxDd(Z)V

    :cond_0
    iget-object p0, p0, Landroidx/appcompat/widget/mjFkc$JHa;->mjFkc:Landroidx/appcompat/widget/mjFkc;

    invoke-virtual {p0}, Landroidx/appcompat/view/menu/mjFkc;->MiMN()Landroidx/appcompat/view/menu/xJ$mjFkc;

    move-result-object p0

    if-eqz p0, :cond_1

    invoke-interface {p0, p1, p2}, Landroidx/appcompat/view/menu/xJ$mjFkc;->AZxh(Landroidx/appcompat/view/menu/ZfxDd;Z)V

    :cond_1
    return-void
.end method

.method public wA(Landroidx/appcompat/view/menu/ZfxDd;)Z
    .locals 3

    iget-object v0, p0, Landroidx/appcompat/widget/mjFkc$JHa;->mjFkc:Landroidx/appcompat/widget/mjFkc;

    invoke-static {v0}, Landroidx/appcompat/widget/mjFkc;->Pq(Landroidx/appcompat/widget/mjFkc;)Landroidx/appcompat/view/menu/ZfxDd;

    move-result-object v0

    const/4 v1, 0x0

    if-ne p1, v0, :cond_0

    return v1

    :cond_0
    iget-object v0, p0, Landroidx/appcompat/widget/mjFkc$JHa;->mjFkc:Landroidx/appcompat/widget/mjFkc;

    move-object v2, p1

    check-cast v2, Landroidx/appcompat/view/menu/Dt;

    invoke-virtual {v2}, Landroidx/appcompat/view/menu/Dt;->getItem()Landroid/view/MenuItem;

    move-result-object v2

    invoke-interface {v2}, Landroid/view/MenuItem;->getItemId()I

    move-result v2

    iput v2, v0, Landroidx/appcompat/widget/mjFkc;->lB:I

    iget-object p0, p0, Landroidx/appcompat/widget/mjFkc$JHa;->mjFkc:Landroidx/appcompat/widget/mjFkc;

    invoke-virtual {p0}, Landroidx/appcompat/view/menu/mjFkc;->MiMN()Landroidx/appcompat/view/menu/xJ$mjFkc;

    move-result-object p0

    if-eqz p0, :cond_1

    invoke-interface {p0, p1}, Landroidx/appcompat/view/menu/xJ$mjFkc;->wA(Landroidx/appcompat/view/menu/ZfxDd;)Z

    move-result v1

    :cond_1
    return v1
.end method
