.class public Landroidx/appcompat/widget/mjFkc$AZxh;
.super Landroidx/appcompat/view/menu/ActionMenuItemView$AZxh;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/appcompat/widget/mjFkc;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "AZxh"
.end annotation


# instance fields
.field public final synthetic mjFkc:Landroidx/appcompat/widget/mjFkc;


# direct methods
.method public constructor <init>(Landroidx/appcompat/widget/mjFkc;)V
    .locals 0

    iput-object p1, p0, Landroidx/appcompat/widget/mjFkc$AZxh;->mjFkc:Landroidx/appcompat/widget/mjFkc;

    invoke-direct {p0}, Landroidx/appcompat/view/menu/ActionMenuItemView$AZxh;-><init>()V

    return-void
.end method


# virtual methods
.method public mjFkc()Lo/Q6;
    .locals 0

    iget-object p0, p0, Landroidx/appcompat/widget/mjFkc$AZxh;->mjFkc:Landroidx/appcompat/widget/mjFkc;

    iget-object p0, p0, Landroidx/appcompat/widget/mjFkc;->HGpJ:Landroidx/appcompat/widget/mjFkc$mjFkc;

    if-eqz p0, :cond_0

    invoke-virtual {p0}, Landroidx/appcompat/view/menu/JHa;->wA()Lo/Y1;

    move-result-object p0

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return-object p0
.end method
