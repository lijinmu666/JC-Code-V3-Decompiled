.class public Landroidx/appcompat/widget/SearchView$qdMbNW;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/widget/AdapterView$OnItemClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/appcompat/widget/SearchView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic mjFkc:Landroidx/appcompat/widget/SearchView;


# direct methods
.method public constructor <init>(Landroidx/appcompat/widget/SearchView;)V
    .locals 0

    iput-object p1, p0, Landroidx/appcompat/widget/SearchView$qdMbNW;->mjFkc:Landroidx/appcompat/widget/SearchView;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onItemClick(Landroid/widget/AdapterView;Landroid/view/View;IJ)V
    .locals 0

    iget-object p0, p0, Landroidx/appcompat/widget/SearchView$qdMbNW;->mjFkc:Landroidx/appcompat/widget/SearchView;

    const/4 p1, 0x0

    const/4 p2, 0x0

    invoke-virtual {p0, p3, p1, p2}, Landroidx/appcompat/widget/SearchView;->aqHPIZ(IILjava/lang/String;)Z

    return-void
.end method
