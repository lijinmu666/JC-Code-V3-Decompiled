.class public Landroidx/appcompat/widget/Toolbar$qdMbNW$mjFkc;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/os/Parcelable$ClassLoaderCreator;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/appcompat/widget/Toolbar$qdMbNW;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public AZxh(Landroid/os/Parcel;Ljava/lang/ClassLoader;)Landroidx/appcompat/widget/Toolbar$qdMbNW;
    .locals 0

    new-instance p0, Landroidx/appcompat/widget/Toolbar$qdMbNW;

    invoke-direct {p0, p1, p2}, Landroidx/appcompat/widget/Toolbar$qdMbNW;-><init>(Landroid/os/Parcel;Ljava/lang/ClassLoader;)V

    return-object p0
.end method

.method public bridge synthetic createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;
    .locals 0

    .line 1
    invoke-virtual {p0, p1}, Landroidx/appcompat/widget/Toolbar$qdMbNW$mjFkc;->mjFkc(Landroid/os/Parcel;)Landroidx/appcompat/widget/Toolbar$qdMbNW;

    move-result-object p0

    return-object p0
.end method

.method public bridge synthetic createFromParcel(Landroid/os/Parcel;Ljava/lang/ClassLoader;)Ljava/lang/Object;
    .locals 0

    .line 2
    invoke-virtual {p0, p1, p2}, Landroidx/appcompat/widget/Toolbar$qdMbNW$mjFkc;->AZxh(Landroid/os/Parcel;Ljava/lang/ClassLoader;)Landroidx/appcompat/widget/Toolbar$qdMbNW;

    move-result-object p0

    return-object p0
.end method

.method public mjFkc(Landroid/os/Parcel;)Landroidx/appcompat/widget/Toolbar$qdMbNW;
    .locals 1

    new-instance p0, Landroidx/appcompat/widget/Toolbar$qdMbNW;

    const/4 v0, 0x0

    invoke-direct {p0, p1, v0}, Landroidx/appcompat/widget/Toolbar$qdMbNW;-><init>(Landroid/os/Parcel;Ljava/lang/ClassLoader;)V

    return-object p0
.end method

.method public bridge synthetic newArray(I)[Ljava/lang/Object;
    .locals 0

    invoke-virtual {p0, p1}, Landroidx/appcompat/widget/Toolbar$qdMbNW$mjFkc;->wA(I)[Landroidx/appcompat/widget/Toolbar$qdMbNW;

    move-result-object p0

    return-object p0
.end method

.method public wA(I)[Landroidx/appcompat/widget/Toolbar$qdMbNW;
    .locals 0

    new-array p0, p1, [Landroidx/appcompat/widget/Toolbar$qdMbNW;

    return-object p0
.end method
