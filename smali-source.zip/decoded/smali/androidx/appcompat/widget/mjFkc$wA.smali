.class public Landroidx/appcompat/widget/mjFkc$wA;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/appcompat/widget/mjFkc;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "wA"
.end annotation


# instance fields
.field public final synthetic AZxh:Landroidx/appcompat/widget/mjFkc;

.field public mjFkc:Landroidx/appcompat/widget/mjFkc$KLFTb;


# direct methods
.method public constructor <init>(Landroidx/appcompat/widget/mjFkc;Landroidx/appcompat/widget/mjFkc$KLFTb;)V
    .locals 0

    iput-object p1, p0, Landroidx/appcompat/widget/mjFkc$wA;->AZxh:Landroidx/appcompat/widget/mjFkc;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p2, p0, Landroidx/appcompat/widget/mjFkc$wA;->mjFkc:Landroidx/appcompat/widget/mjFkc$KLFTb;

    return-void
.end method


# virtual methods
.method public run()V
    .locals 2

    iget-object v0, p0, Landroidx/appcompat/widget/mjFkc$wA;->AZxh:Landroidx/appcompat/widget/mjFkc;

    invoke-static {v0}, Landroidx/appcompat/widget/mjFkc;->diqgf(Landroidx/appcompat/widget/mjFkc;)Landroidx/appcompat/view/menu/ZfxDd;

    move-result-object v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Landroidx/appcompat/widget/mjFkc$wA;->AZxh:Landroidx/appcompat/widget/mjFkc;

    invoke-static {v0}, Landroidx/appcompat/widget/mjFkc;->eyqo(Landroidx/appcompat/widget/mjFkc;)Landroidx/appcompat/view/menu/ZfxDd;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/appcompat/view/menu/ZfxDd;->wA()V

    :cond_0
    iget-object v0, p0, Landroidx/appcompat/widget/mjFkc$wA;->AZxh:Landroidx/appcompat/widget/mjFkc;

    invoke-static {v0}, Landroidx/appcompat/widget/mjFkc;->Ucbh(Landroidx/appcompat/widget/mjFkc;)Landroidx/appcompat/view/menu/lgHUyS;

    move-result-object v0

    check-cast v0, Landroid/view/View;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Landroid/view/View;->getWindowToken()Landroid/os/IBinder;

    move-result-object v0

    if-eqz v0, :cond_1

    iget-object v0, p0, Landroidx/appcompat/widget/mjFkc$wA;->mjFkc:Landroidx/appcompat/widget/mjFkc$KLFTb;

    invoke-virtual {v0}, Landroidx/appcompat/view/menu/JHa;->MiMN()Z

    move-result v0

    if-eqz v0, :cond_1

    iget-object v0, p0, Landroidx/appcompat/widget/mjFkc$wA;->AZxh:Landroidx/appcompat/widget/mjFkc;

    iget-object v1, p0, Landroidx/appcompat/widget/mjFkc$wA;->mjFkc:Landroidx/appcompat/widget/mjFkc$KLFTb;

    iput-object v1, v0, Landroidx/appcompat/widget/mjFkc;->Gd:Landroidx/appcompat/widget/mjFkc$KLFTb;

    :cond_1
    iget-object p0, p0, Landroidx/appcompat/widget/mjFkc$wA;->AZxh:Landroidx/appcompat/widget/mjFkc;

    const/4 v0, 0x0

    iput-object v0, p0, Landroidx/appcompat/widget/mjFkc;->vI:Landroidx/appcompat/widget/mjFkc$wA;

    return-void
.end method
