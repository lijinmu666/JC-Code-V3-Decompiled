.class public Landroidx/appcompat/widget/Toolbar$JHa;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/appcompat/view/menu/xJ;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/appcompat/widget/Toolbar;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "JHa"
.end annotation


# instance fields
.field public AZxh:Landroidx/appcompat/view/menu/KLFTb;

.field public mjFkc:Landroidx/appcompat/view/menu/ZfxDd;

.field public final synthetic wA:Landroidx/appcompat/widget/Toolbar;


# direct methods
.method public constructor <init>(Landroidx/appcompat/widget/Toolbar;)V
    .locals 0

    iput-object p1, p0, Landroidx/appcompat/widget/Toolbar$JHa;->wA:Landroidx/appcompat/widget/Toolbar;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public AZxh(Landroidx/appcompat/view/menu/ZfxDd;Z)V
    .locals 0

    return-void
.end method

.method public ETF(Landroidx/appcompat/view/menu/ZfxDd;Landroidx/appcompat/view/menu/KLFTb;)Z
    .locals 3

    iget-object p1, p0, Landroidx/appcompat/widget/Toolbar$JHa;->wA:Landroidx/appcompat/widget/Toolbar;

    invoke-virtual {p1}, Landroidx/appcompat/widget/Toolbar;->KLFTb()V

    iget-object p1, p0, Landroidx/appcompat/widget/Toolbar$JHa;->wA:Landroidx/appcompat/widget/Toolbar;

    iget-object p1, p1, Landroidx/appcompat/widget/Toolbar;->lgHUyS:Landroid/widget/ImageButton;

    invoke-virtual {p1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object p1

    iget-object v0, p0, Landroidx/appcompat/widget/Toolbar$JHa;->wA:Landroidx/appcompat/widget/Toolbar;

    if-eq p1, v0, :cond_1

    instance-of v1, p1, Landroid/view/ViewGroup;

    if-eqz v1, :cond_0

    check-cast p1, Landroid/view/ViewGroup;

    iget-object v0, v0, Landroidx/appcompat/widget/Toolbar;->lgHUyS:Landroid/widget/ImageButton;

    invoke-virtual {p1, v0}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    :cond_0
    iget-object p1, p0, Landroidx/appcompat/widget/Toolbar$JHa;->wA:Landroidx/appcompat/widget/Toolbar;

    iget-object v0, p1, Landroidx/appcompat/widget/Toolbar;->lgHUyS:Landroid/widget/ImageButton;

    invoke-virtual {p1, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    :cond_1
    iget-object p1, p0, Landroidx/appcompat/widget/Toolbar$JHa;->wA:Landroidx/appcompat/widget/Toolbar;

    invoke-virtual {p2}, Landroidx/appcompat/view/menu/KLFTb;->getActionView()Landroid/view/View;

    move-result-object v0

    iput-object v0, p1, Landroidx/appcompat/widget/Toolbar;->qdMbNW:Landroid/view/View;

    iput-object p2, p0, Landroidx/appcompat/widget/Toolbar$JHa;->AZxh:Landroidx/appcompat/view/menu/KLFTb;

    iget-object p1, p0, Landroidx/appcompat/widget/Toolbar$JHa;->wA:Landroidx/appcompat/widget/Toolbar;

    iget-object p1, p1, Landroidx/appcompat/widget/Toolbar;->qdMbNW:Landroid/view/View;

    invoke-virtual {p1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object p1

    iget-object v0, p0, Landroidx/appcompat/widget/Toolbar$JHa;->wA:Landroidx/appcompat/widget/Toolbar;

    if-eq p1, v0, :cond_3

    instance-of v1, p1, Landroid/view/ViewGroup;

    if-eqz v1, :cond_2

    check-cast p1, Landroid/view/ViewGroup;

    iget-object v0, v0, Landroidx/appcompat/widget/Toolbar;->qdMbNW:Landroid/view/View;

    invoke-virtual {p1, v0}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    :cond_2
    iget-object p1, p0, Landroidx/appcompat/widget/Toolbar$JHa;->wA:Landroidx/appcompat/widget/Toolbar;

    invoke-virtual {p1}, Landroidx/appcompat/widget/Toolbar;->ETF()Landroidx/appcompat/widget/Toolbar$xJ;

    move-result-object p1

    iget-object v0, p0, Landroidx/appcompat/widget/Toolbar$JHa;->wA:Landroidx/appcompat/widget/Toolbar;

    iget v1, v0, Landroidx/appcompat/widget/Toolbar;->YoKzxo:I

    and-int/lit8 v1, v1, 0x70

    const v2, 0x800003

    or-int/2addr v1, v2

    iput v1, p1, Lo/VocHEe;->mjFkc:I

    const/4 v1, 0x2

    iput v1, p1, Landroidx/appcompat/widget/Toolbar$xJ;->AZxh:I

    iget-object v0, v0, Landroidx/appcompat/widget/Toolbar;->qdMbNW:Landroid/view/View;

    invoke-virtual {v0, p1}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    iget-object p1, p0, Landroidx/appcompat/widget/Toolbar$JHa;->wA:Landroidx/appcompat/widget/Toolbar;

    iget-object v0, p1, Landroidx/appcompat/widget/Toolbar;->qdMbNW:Landroid/view/View;

    invoke-virtual {p1, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    :cond_3
    iget-object p1, p0, Landroidx/appcompat/widget/Toolbar$JHa;->wA:Landroidx/appcompat/widget/Toolbar;

    invoke-virtual {p1}, Landroidx/appcompat/widget/Toolbar;->mByQ()V

    iget-object p1, p0, Landroidx/appcompat/widget/Toolbar$JHa;->wA:Landroidx/appcompat/widget/Toolbar;

    invoke-virtual {p1}, Landroid/view/View;->requestLayout()V

    const/4 p1, 0x1

    invoke-virtual {p2, p1}, Landroidx/appcompat/view/menu/KLFTb;->fehf(Z)V

    iget-object p2, p0, Landroidx/appcompat/widget/Toolbar$JHa;->wA:Landroidx/appcompat/widget/Toolbar;

    iget-object p2, p2, Landroidx/appcompat/widget/Toolbar;->qdMbNW:Landroid/view/View;

    instance-of v0, p2, Lo/TvfBiy;

    if-eqz v0, :cond_4

    check-cast p2, Lo/TvfBiy;

    invoke-interface {p2}, Lo/TvfBiy;->AZxh()V

    :cond_4
    iget-object p0, p0, Landroidx/appcompat/widget/Toolbar$JHa;->wA:Landroidx/appcompat/widget/Toolbar;

    invoke-virtual {p0}, Landroidx/appcompat/widget/Toolbar;->cMLeY()V

    return p1
.end method

.method public JHa(Landroidx/appcompat/view/menu/Dt;)Z
    .locals 0

    const/4 p0, 0x0

    return p0
.end method

.method public lgHUyS()Z
    .locals 0

    const/4 p0, 0x0

    return p0
.end method

.method public qdMbNW(Landroidx/appcompat/view/menu/ZfxDd;Landroidx/appcompat/view/menu/KLFTb;)Z
    .locals 1

    iget-object p1, p0, Landroidx/appcompat/widget/Toolbar$JHa;->wA:Landroidx/appcompat/widget/Toolbar;

    iget-object p1, p1, Landroidx/appcompat/widget/Toolbar;->qdMbNW:Landroid/view/View;

    instance-of v0, p1, Lo/TvfBiy;

    if-eqz v0, :cond_0

    check-cast p1, Lo/TvfBiy;

    invoke-interface {p1}, Lo/TvfBiy;->KLFTb()V

    :cond_0
    iget-object p1, p0, Landroidx/appcompat/widget/Toolbar$JHa;->wA:Landroidx/appcompat/widget/Toolbar;

    iget-object v0, p1, Landroidx/appcompat/widget/Toolbar;->qdMbNW:Landroid/view/View;

    invoke-virtual {p1, v0}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    iget-object p1, p0, Landroidx/appcompat/widget/Toolbar$JHa;->wA:Landroidx/appcompat/widget/Toolbar;

    iget-object v0, p1, Landroidx/appcompat/widget/Toolbar;->lgHUyS:Landroid/widget/ImageButton;

    invoke-virtual {p1, v0}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    iget-object p1, p0, Landroidx/appcompat/widget/Toolbar$JHa;->wA:Landroidx/appcompat/widget/Toolbar;

    const/4 v0, 0x0

    iput-object v0, p1, Landroidx/appcompat/widget/Toolbar;->qdMbNW:Landroid/view/View;

    invoke-virtual {p1}, Landroidx/appcompat/widget/Toolbar;->mjFkc()V

    iput-object v0, p0, Landroidx/appcompat/widget/Toolbar$JHa;->AZxh:Landroidx/appcompat/view/menu/KLFTb;

    iget-object p1, p0, Landroidx/appcompat/widget/Toolbar$JHa;->wA:Landroidx/appcompat/widget/Toolbar;

    invoke-virtual {p1}, Landroid/view/View;->requestLayout()V

    const/4 p1, 0x0

    invoke-virtual {p2, p1}, Landroidx/appcompat/view/menu/KLFTb;->fehf(Z)V

    iget-object p0, p0, Landroidx/appcompat/widget/Toolbar$JHa;->wA:Landroidx/appcompat/widget/Toolbar;

    invoke-virtual {p0}, Landroidx/appcompat/widget/Toolbar;->cMLeY()V

    const/4 p0, 0x1

    return p0
.end method

.method public wA(Landroid/content/Context;Landroidx/appcompat/view/menu/ZfxDd;)V
    .locals 1

    iget-object p1, p0, Landroidx/appcompat/widget/Toolbar$JHa;->mjFkc:Landroidx/appcompat/view/menu/ZfxDd;

    if-eqz p1, :cond_0

    iget-object v0, p0, Landroidx/appcompat/widget/Toolbar$JHa;->AZxh:Landroidx/appcompat/view/menu/KLFTb;

    if-eqz v0, :cond_0

    invoke-virtual {p1, v0}, Landroidx/appcompat/view/menu/ZfxDd;->KLFTb(Landroidx/appcompat/view/menu/KLFTb;)Z

    :cond_0
    iput-object p2, p0, Landroidx/appcompat/widget/Toolbar$JHa;->mjFkc:Landroidx/appcompat/view/menu/ZfxDd;

    return-void
.end method

.method public xJ(Z)V
    .locals 3

    iget-object p1, p0, Landroidx/appcompat/widget/Toolbar$JHa;->AZxh:Landroidx/appcompat/view/menu/KLFTb;

    if-eqz p1, :cond_2

    iget-object p1, p0, Landroidx/appcompat/widget/Toolbar$JHa;->mjFkc:Landroidx/appcompat/view/menu/ZfxDd;

    if-eqz p1, :cond_1

    invoke-virtual {p1}, Landroidx/appcompat/view/menu/ZfxDd;->size()I

    move-result p1

    const/4 v0, 0x0

    :goto_0
    if-ge v0, p1, :cond_1

    iget-object v1, p0, Landroidx/appcompat/widget/Toolbar$JHa;->mjFkc:Landroidx/appcompat/view/menu/ZfxDd;

    invoke-virtual {v1, v0}, Landroidx/appcompat/view/menu/ZfxDd;->getItem(I)Landroid/view/MenuItem;

    move-result-object v1

    iget-object v2, p0, Landroidx/appcompat/widget/Toolbar$JHa;->AZxh:Landroidx/appcompat/view/menu/KLFTb;

    if-ne v1, v2, :cond_0

    goto :goto_1

    :cond_0
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    iget-object p1, p0, Landroidx/appcompat/widget/Toolbar$JHa;->mjFkc:Landroidx/appcompat/view/menu/ZfxDd;

    iget-object v0, p0, Landroidx/appcompat/widget/Toolbar$JHa;->AZxh:Landroidx/appcompat/view/menu/KLFTb;

    invoke-virtual {p0, p1, v0}, Landroidx/appcompat/widget/Toolbar$JHa;->qdMbNW(Landroidx/appcompat/view/menu/ZfxDd;Landroidx/appcompat/view/menu/KLFTb;)Z

    :cond_2
    :goto_1
    return-void
.end method
