.class public Landroidx/appcompat/widget/mjFkc;
.super Landroidx/appcompat/view/menu/mjFkc;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/appcompat/widget/mjFkc$AZxh;,
        Landroidx/appcompat/widget/mjFkc$wA;,
        Landroidx/appcompat/widget/mjFkc$JHa;,
        Landroidx/appcompat/widget/mjFkc$mjFkc;,
        Landroidx/appcompat/widget/mjFkc$KLFTb;,
        Landroidx/appcompat/widget/mjFkc$ZfxDd;
    }
.end annotation


# instance fields
.field public final BAnRFn:Landroidx/appcompat/widget/mjFkc$JHa;

.field public Dt:Landroidx/appcompat/widget/mjFkc$ZfxDd;

.field public ETF:Landroid/graphics/drawable/Drawable;

.field public Gd:Landroidx/appcompat/widget/mjFkc$KLFTb;

.field public HGpJ:Landroidx/appcompat/widget/mjFkc$mjFkc;

.field public IEE:Z

.field public MiMN:Z

.field public Pq:Z

.field public Ucbh:I

.field public VA:Z

.field public VocHEe:Landroidx/appcompat/widget/mjFkc$AZxh;

.field public YoKzxo:Z

.field public diqgf:Z

.field public eyqo:Z

.field public fehf:I

.field public final huTpC:Landroid/util/SparseBooleanArray;

.field public lB:I

.field public qGY:I

.field public rkYL:I

.field public vI:Landroidx/appcompat/widget/mjFkc$wA;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 2

    sget v0, Lo/I4;->wA:I

    sget v1, Lo/I4;->AZxh:I

    invoke-direct {p0, p1, v0, v1}, Landroidx/appcompat/view/menu/mjFkc;-><init>(Landroid/content/Context;II)V

    new-instance p1, Landroid/util/SparseBooleanArray;

    invoke-direct {p1}, Landroid/util/SparseBooleanArray;-><init>()V

    iput-object p1, p0, Landroidx/appcompat/widget/mjFkc;->huTpC:Landroid/util/SparseBooleanArray;

    new-instance p1, Landroidx/appcompat/widget/mjFkc$JHa;

    invoke-direct {p1, p0}, Landroidx/appcompat/widget/mjFkc$JHa;-><init>(Landroidx/appcompat/widget/mjFkc;)V

    iput-object p1, p0, Landroidx/appcompat/widget/mjFkc;->BAnRFn:Landroidx/appcompat/widget/mjFkc$JHa;

    return-void
.end method

.method public static synthetic IEE(Landroidx/appcompat/widget/mjFkc;)Landroidx/appcompat/view/menu/lgHUyS;
    .locals 0

    iget-object p0, p0, Landroidx/appcompat/view/menu/mjFkc;->qdMbNW:Landroidx/appcompat/view/menu/lgHUyS;

    return-object p0
.end method

.method public static synthetic Pq(Landroidx/appcompat/widget/mjFkc;)Landroidx/appcompat/view/menu/ZfxDd;
    .locals 0

    iget-object p0, p0, Landroidx/appcompat/view/menu/mjFkc;->wA:Landroidx/appcompat/view/menu/ZfxDd;

    return-object p0
.end method

.method public static synthetic Ucbh(Landroidx/appcompat/widget/mjFkc;)Landroidx/appcompat/view/menu/lgHUyS;
    .locals 0

    iget-object p0, p0, Landroidx/appcompat/view/menu/mjFkc;->qdMbNW:Landroidx/appcompat/view/menu/lgHUyS;

    return-object p0
.end method

.method public static synthetic diqgf(Landroidx/appcompat/widget/mjFkc;)Landroidx/appcompat/view/menu/ZfxDd;
    .locals 0

    iget-object p0, p0, Landroidx/appcompat/view/menu/mjFkc;->wA:Landroidx/appcompat/view/menu/ZfxDd;

    return-object p0
.end method

.method public static synthetic eyqo(Landroidx/appcompat/widget/mjFkc;)Landroidx/appcompat/view/menu/ZfxDd;
    .locals 0

    iget-object p0, p0, Landroidx/appcompat/view/menu/mjFkc;->wA:Landroidx/appcompat/view/menu/ZfxDd;

    return-object p0
.end method

.method public static synthetic fehf(Landroidx/appcompat/widget/mjFkc;)Landroidx/appcompat/view/menu/ZfxDd;
    .locals 0

    iget-object p0, p0, Landroidx/appcompat/view/menu/mjFkc;->wA:Landroidx/appcompat/view/menu/ZfxDd;

    return-object p0
.end method

.method public static synthetic qGY(Landroidx/appcompat/widget/mjFkc;)Landroidx/appcompat/view/menu/ZfxDd;
    .locals 0

    iget-object p0, p0, Landroidx/appcompat/view/menu/mjFkc;->wA:Landroidx/appcompat/view/menu/ZfxDd;

    return-object p0
.end method


# virtual methods
.method public AZxh(Landroidx/appcompat/view/menu/ZfxDd;Z)V
    .locals 0

    invoke-virtual {p0}, Landroidx/appcompat/widget/mjFkc;->huTpC()Z

    invoke-super {p0, p1, p2}, Landroidx/appcompat/view/menu/mjFkc;->AZxh(Landroidx/appcompat/view/menu/ZfxDd;Z)V

    return-void
.end method

.method public BAnRFn()Z
    .locals 0

    iget-object p0, p0, Landroidx/appcompat/widget/mjFkc;->Gd:Landroidx/appcompat/widget/mjFkc$KLFTb;

    if-eqz p0, :cond_0

    invoke-virtual {p0}, Landroidx/appcompat/view/menu/JHa;->ZfxDd()Z

    move-result p0

    if-eqz p0, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method

.method public CqaNbM()Z
    .locals 7

    iget-boolean v0, p0, Landroidx/appcompat/widget/mjFkc;->MiMN:Z

    if-eqz v0, :cond_0

    invoke-virtual {p0}, Landroidx/appcompat/widget/mjFkc;->BAnRFn()Z

    move-result v0

    if-nez v0, :cond_0

    iget-object v0, p0, Landroidx/appcompat/view/menu/mjFkc;->wA:Landroidx/appcompat/view/menu/ZfxDd;

    if-eqz v0, :cond_0

    iget-object v1, p0, Landroidx/appcompat/view/menu/mjFkc;->qdMbNW:Landroidx/appcompat/view/menu/lgHUyS;

    if-eqz v1, :cond_0

    iget-object v1, p0, Landroidx/appcompat/widget/mjFkc;->vI:Landroidx/appcompat/widget/mjFkc$wA;

    if-nez v1, :cond_0

    invoke-virtual {v0}, Landroidx/appcompat/view/menu/ZfxDd;->Ucbh()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_0

    new-instance v0, Landroidx/appcompat/widget/mjFkc$KLFTb;

    iget-object v3, p0, Landroidx/appcompat/view/menu/mjFkc;->AZxh:Landroid/content/Context;

    iget-object v4, p0, Landroidx/appcompat/view/menu/mjFkc;->wA:Landroidx/appcompat/view/menu/ZfxDd;

    iget-object v5, p0, Landroidx/appcompat/widget/mjFkc;->Dt:Landroidx/appcompat/widget/mjFkc$ZfxDd;

    const/4 v6, 0x1

    move-object v1, v0

    move-object v2, p0

    invoke-direct/range {v1 .. v6}, Landroidx/appcompat/widget/mjFkc$KLFTb;-><init>(Landroidx/appcompat/widget/mjFkc;Landroid/content/Context;Landroidx/appcompat/view/menu/ZfxDd;Landroid/view/View;Z)V

    new-instance v1, Landroidx/appcompat/widget/mjFkc$wA;

    invoke-direct {v1, p0, v0}, Landroidx/appcompat/widget/mjFkc$wA;-><init>(Landroidx/appcompat/widget/mjFkc;Landroidx/appcompat/widget/mjFkc$KLFTb;)V

    iput-object v1, p0, Landroidx/appcompat/widget/mjFkc;->vI:Landroidx/appcompat/widget/mjFkc$wA;

    iget-object p0, p0, Landroidx/appcompat/view/menu/mjFkc;->qdMbNW:Landroidx/appcompat/view/menu/lgHUyS;

    check-cast p0, Landroid/view/View;

    invoke-virtual {p0, v1}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    const/4 p0, 0x1

    return p0

    :cond_0
    const/4 p0, 0x0

    return p0
.end method

.method public Dt(Landroid/view/ViewGroup;I)Z
    .locals 2

    invoke-virtual {p1, p2}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v0

    iget-object v1, p0, Landroidx/appcompat/widget/mjFkc;->Dt:Landroidx/appcompat/widget/mjFkc$ZfxDd;

    if-ne v0, v1, :cond_0

    const/4 p0, 0x0

    return p0

    :cond_0
    invoke-super {p0, p1, p2}, Landroidx/appcompat/view/menu/mjFkc;->Dt(Landroid/view/ViewGroup;I)Z

    move-result p0

    return p0
.end method

.method public final Gd(Landroid/view/MenuItem;)Landroid/view/View;
    .locals 5

    iget-object p0, p0, Landroidx/appcompat/view/menu/mjFkc;->qdMbNW:Landroidx/appcompat/view/menu/lgHUyS;

    check-cast p0, Landroid/view/ViewGroup;

    const/4 v0, 0x0

    if-nez p0, :cond_0

    return-object v0

    :cond_0
    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v1

    const/4 v2, 0x0

    :goto_0
    if-ge v2, v1, :cond_2

    invoke-virtual {p0, v2}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v3

    instance-of v4, v3, Landroidx/appcompat/view/menu/lgHUyS$mjFkc;

    if-eqz v4, :cond_1

    move-object v4, v3

    check-cast v4, Landroidx/appcompat/view/menu/lgHUyS$mjFkc;

    invoke-interface {v4}, Landroidx/appcompat/view/menu/lgHUyS$mjFkc;->getItemData()Landroidx/appcompat/view/menu/KLFTb;

    move-result-object v4

    if-ne v4, p1, :cond_1

    return-object v3

    :cond_1
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_2
    return-object v0
.end method

.method public HGpJ()Landroid/graphics/drawable/Drawable;
    .locals 1

    iget-object v0, p0, Landroidx/appcompat/widget/mjFkc;->Dt:Landroidx/appcompat/widget/mjFkc$ZfxDd;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Landroid/widget/ImageView;->getDrawable()Landroid/graphics/drawable/Drawable;

    move-result-object p0

    return-object p0

    :cond_0
    iget-boolean v0, p0, Landroidx/appcompat/widget/mjFkc;->VA:Z

    if-eqz v0, :cond_1

    iget-object p0, p0, Landroidx/appcompat/widget/mjFkc;->ETF:Landroid/graphics/drawable/Drawable;

    return-object p0

    :cond_1
    const/4 p0, 0x0

    return-object p0
.end method

.method public JHa(Landroidx/appcompat/view/menu/Dt;)Z
    .locals 7

    invoke-virtual {p1}, Landroidx/appcompat/view/menu/ZfxDd;->hasVisibleItems()Z

    move-result v0

    const/4 v1, 0x0

    if-nez v0, :cond_0

    return v1

    :cond_0
    move-object v0, p1

    :goto_0
    invoke-virtual {v0}, Landroidx/appcompat/view/menu/Dt;->JYn()Landroid/view/Menu;

    move-result-object v2

    iget-object v3, p0, Landroidx/appcompat/view/menu/mjFkc;->wA:Landroidx/appcompat/view/menu/ZfxDd;

    if-eq v2, v3, :cond_1

    invoke-virtual {v0}, Landroidx/appcompat/view/menu/Dt;->JYn()Landroid/view/Menu;

    move-result-object v0

    check-cast v0, Landroidx/appcompat/view/menu/Dt;

    goto :goto_0

    :cond_1
    invoke-virtual {v0}, Landroidx/appcompat/view/menu/Dt;->getItem()Landroid/view/MenuItem;

    move-result-object v0

    invoke-virtual {p0, v0}, Landroidx/appcompat/widget/mjFkc;->Gd(Landroid/view/MenuItem;)Landroid/view/View;

    move-result-object v0

    if-nez v0, :cond_2

    return v1

    :cond_2
    invoke-virtual {p1}, Landroidx/appcompat/view/menu/Dt;->getItem()Landroid/view/MenuItem;

    move-result-object v2

    invoke-interface {v2}, Landroid/view/MenuItem;->getItemId()I

    move-result v2

    iput v2, p0, Landroidx/appcompat/widget/mjFkc;->lB:I

    invoke-virtual {p1}, Landroidx/appcompat/view/menu/ZfxDd;->size()I

    move-result v2

    move v3, v1

    :goto_1
    const/4 v4, 0x1

    if-ge v3, v2, :cond_4

    invoke-virtual {p1, v3}, Landroidx/appcompat/view/menu/ZfxDd;->getItem(I)Landroid/view/MenuItem;

    move-result-object v5

    invoke-interface {v5}, Landroid/view/MenuItem;->isVisible()Z

    move-result v6

    if-eqz v6, :cond_3

    invoke-interface {v5}, Landroid/view/MenuItem;->getIcon()Landroid/graphics/drawable/Drawable;

    move-result-object v5

    if-eqz v5, :cond_3

    move v1, v4

    goto :goto_2

    :cond_3
    add-int/lit8 v3, v3, 0x1

    goto :goto_1

    :cond_4
    :goto_2
    new-instance v2, Landroidx/appcompat/widget/mjFkc$mjFkc;

    iget-object v3, p0, Landroidx/appcompat/view/menu/mjFkc;->AZxh:Landroid/content/Context;

    invoke-direct {v2, p0, v3, p1, v0}, Landroidx/appcompat/widget/mjFkc$mjFkc;-><init>(Landroidx/appcompat/widget/mjFkc;Landroid/content/Context;Landroidx/appcompat/view/menu/Dt;Landroid/view/View;)V

    iput-object v2, p0, Landroidx/appcompat/widget/mjFkc;->HGpJ:Landroidx/appcompat/widget/mjFkc$mjFkc;

    invoke-virtual {v2, v1}, Landroidx/appcompat/view/menu/JHa;->xJ(Z)V

    iget-object v0, p0, Landroidx/appcompat/widget/mjFkc;->HGpJ:Landroidx/appcompat/widget/mjFkc$mjFkc;

    invoke-virtual {v0}, Landroidx/appcompat/view/menu/JHa;->ETF()V

    invoke-super {p0, p1}, Landroidx/appcompat/view/menu/mjFkc;->JHa(Landroidx/appcompat/view/menu/Dt;)Z

    return v4
.end method

.method public Ne(Z)V
    .locals 0

    iput-boolean p1, p0, Landroidx/appcompat/widget/mjFkc;->MiMN:Z

    const/4 p1, 0x1

    iput-boolean p1, p0, Landroidx/appcompat/widget/mjFkc;->YoKzxo:Z

    return-void
.end method

.method public OjSQV(Landroid/graphics/drawable/Drawable;)V
    .locals 1

    iget-object v0, p0, Landroidx/appcompat/widget/mjFkc;->Dt:Landroidx/appcompat/widget/mjFkc$ZfxDd;

    if-eqz v0, :cond_0

    invoke-virtual {v0, p1}, Lo/dm;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    goto :goto_0

    :cond_0
    const/4 v0, 0x1

    iput-boolean v0, p0, Landroidx/appcompat/widget/mjFkc;->VA:Z

    iput-object p1, p0, Landroidx/appcompat/widget/mjFkc;->ETF:Landroid/graphics/drawable/Drawable;

    :goto_0
    return-void
.end method

.method public VocHEe()Z
    .locals 0

    iget-object p0, p0, Landroidx/appcompat/widget/mjFkc;->HGpJ:Landroidx/appcompat/widget/mjFkc$mjFkc;

    if-eqz p0, :cond_0

    invoke-virtual {p0}, Landroidx/appcompat/view/menu/JHa;->AZxh()V

    const/4 p0, 0x1

    return p0

    :cond_0
    const/4 p0, 0x0

    return p0
.end method

.method public YoKzxo(Landroidx/appcompat/view/menu/KLFTb;Landroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;
    .locals 2

    invoke-virtual {p1}, Landroidx/appcompat/view/menu/KLFTb;->getActionView()Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-virtual {p1}, Landroidx/appcompat/view/menu/KLFTb;->qdMbNW()Z

    move-result v1

    if-eqz v1, :cond_1

    :cond_0
    invoke-super {p0, p1, p2, p3}, Landroidx/appcompat/view/menu/mjFkc;->YoKzxo(Landroidx/appcompat/view/menu/KLFTb;Landroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;

    move-result-object v0

    :cond_1
    invoke-virtual {p1}, Landroidx/appcompat/view/menu/KLFTb;->isActionViewExpanded()Z

    move-result p0

    if-eqz p0, :cond_2

    const/16 p0, 0x8

    goto :goto_0

    :cond_2
    const/4 p0, 0x0

    :goto_0
    invoke-virtual {v0, p0}, Landroid/view/View;->setVisibility(I)V

    check-cast p3, Landroidx/appcompat/widget/ActionMenuView;

    invoke-virtual {v0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object p0

    invoke-virtual {p3, p0}, Landroidx/appcompat/widget/ActionMenuView;->checkLayoutParams(Landroid/view/ViewGroup$LayoutParams;)Z

    move-result p1

    if-nez p1, :cond_3

    invoke-virtual {p3, p0}, Landroidx/appcompat/widget/ActionMenuView;->wJVbdd(Landroid/view/ViewGroup$LayoutParams;)Landroidx/appcompat/widget/ActionMenuView$wA;

    move-result-object p0

    invoke-virtual {v0, p0}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    :cond_3
    return-object v0
.end method

.method public ZfxDd(Landroidx/appcompat/view/menu/KLFTb;Landroidx/appcompat/view/menu/lgHUyS$mjFkc;)V
    .locals 1

    const/4 v0, 0x0

    invoke-interface {p2, p1, v0}, Landroidx/appcompat/view/menu/lgHUyS$mjFkc;->ZfxDd(Landroidx/appcompat/view/menu/KLFTb;I)V

    iget-object p1, p0, Landroidx/appcompat/view/menu/mjFkc;->qdMbNW:Landroidx/appcompat/view/menu/lgHUyS;

    check-cast p1, Landroidx/appcompat/widget/ActionMenuView;

    check-cast p2, Landroidx/appcompat/view/menu/ActionMenuItemView;

    invoke-virtual {p2, p1}, Landroidx/appcompat/view/menu/ActionMenuItemView;->setItemInvoker(Landroidx/appcompat/view/menu/ZfxDd$AZxh;)V

    iget-object p1, p0, Landroidx/appcompat/widget/mjFkc;->VocHEe:Landroidx/appcompat/widget/mjFkc$AZxh;

    if-nez p1, :cond_0

    new-instance p1, Landroidx/appcompat/widget/mjFkc$AZxh;

    invoke-direct {p1, p0}, Landroidx/appcompat/widget/mjFkc$AZxh;-><init>(Landroidx/appcompat/widget/mjFkc;)V

    iput-object p1, p0, Landroidx/appcompat/widget/mjFkc;->VocHEe:Landroidx/appcompat/widget/mjFkc$AZxh;

    :cond_0
    iget-object p0, p0, Landroidx/appcompat/widget/mjFkc;->VocHEe:Landroidx/appcompat/widget/mjFkc$AZxh;

    invoke-virtual {p2, p0}, Landroidx/appcompat/view/menu/ActionMenuItemView;->setPopupCallback(Landroidx/appcompat/view/menu/ActionMenuItemView$AZxh;)V

    return-void
.end method

.method public huTpC()Z
    .locals 1

    invoke-virtual {p0}, Landroidx/appcompat/widget/mjFkc;->vI()Z

    move-result v0

    invoke-virtual {p0}, Landroidx/appcompat/widget/mjFkc;->VocHEe()Z

    move-result p0

    or-int/2addr p0, v0

    return p0
.end method

.method public lB(Landroid/content/res/Configuration;)V
    .locals 0

    iget-boolean p1, p0, Landroidx/appcompat/widget/mjFkc;->IEE:Z

    if-nez p1, :cond_0

    iget-object p1, p0, Landroidx/appcompat/view/menu/mjFkc;->AZxh:Landroid/content/Context;

    invoke-static {p1}, Lo/lB;->mjFkc(Landroid/content/Context;)Lo/lB;

    move-result-object p1

    invoke-virtual {p1}, Lo/lB;->wA()I

    move-result p1

    iput p1, p0, Landroidx/appcompat/widget/mjFkc;->fehf:I

    :cond_0
    iget-object p0, p0, Landroidx/appcompat/view/menu/mjFkc;->wA:Landroidx/appcompat/view/menu/ZfxDd;

    if-eqz p0, :cond_1

    const/4 p1, 0x1

    invoke-virtual {p0, p1}, Landroidx/appcompat/view/menu/ZfxDd;->Ne(Z)V

    :cond_1
    return-void
.end method

.method public lgHUyS()Z
    .locals 20

    move-object/from16 v0, p0

    iget-object v1, v0, Landroidx/appcompat/view/menu/mjFkc;->wA:Landroidx/appcompat/view/menu/ZfxDd;

    const/4 v2, 0x0

    const/4 v3, 0x0

    if-eqz v1, :cond_0

    invoke-virtual {v1}, Landroidx/appcompat/view/menu/ZfxDd;->VocHEe()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v4

    goto :goto_0

    :cond_0
    move-object v1, v2

    move v4, v3

    :goto_0
    iget v5, v0, Landroidx/appcompat/widget/mjFkc;->fehf:I

    iget v6, v0, Landroidx/appcompat/widget/mjFkc;->qGY:I

    invoke-static {v3, v3}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v7

    iget-object v8, v0, Landroidx/appcompat/view/menu/mjFkc;->qdMbNW:Landroidx/appcompat/view/menu/lgHUyS;

    check-cast v8, Landroid/view/ViewGroup;

    move v9, v3

    move v10, v9

    move v11, v10

    move v12, v11

    :goto_1
    if-ge v9, v4, :cond_4

    invoke-virtual {v1, v9}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v14

    check-cast v14, Landroidx/appcompat/view/menu/KLFTb;

    invoke-virtual {v14}, Landroidx/appcompat/view/menu/KLFTb;->YoKzxo()Z

    move-result v15

    if-eqz v15, :cond_1

    add-int/lit8 v11, v11, 0x1

    goto :goto_2

    :cond_1
    invoke-virtual {v14}, Landroidx/appcompat/view/menu/KLFTb;->MiMN()Z

    move-result v15

    if-eqz v15, :cond_2

    add-int/lit8 v12, v12, 0x1

    goto :goto_2

    :cond_2
    const/4 v10, 0x1

    :goto_2
    iget-boolean v13, v0, Landroidx/appcompat/widget/mjFkc;->eyqo:Z

    if-eqz v13, :cond_3

    invoke-virtual {v14}, Landroidx/appcompat/view/menu/KLFTb;->isActionViewExpanded()Z

    move-result v13

    if-eqz v13, :cond_3

    move v5, v3

    :cond_3
    add-int/lit8 v9, v9, 0x1

    goto :goto_1

    :cond_4
    iget-boolean v9, v0, Landroidx/appcompat/widget/mjFkc;->MiMN:Z

    if-eqz v9, :cond_6

    if-nez v10, :cond_5

    add-int/2addr v12, v11

    if-le v12, v5, :cond_6

    :cond_5
    add-int/lit8 v5, v5, -0x1

    :cond_6
    sub-int/2addr v5, v11

    iget-object v9, v0, Landroidx/appcompat/widget/mjFkc;->huTpC:Landroid/util/SparseBooleanArray;

    invoke-virtual {v9}, Landroid/util/SparseBooleanArray;->clear()V

    iget-boolean v10, v0, Landroidx/appcompat/widget/mjFkc;->Pq:Z

    if-eqz v10, :cond_7

    iget v10, v0, Landroidx/appcompat/widget/mjFkc;->Ucbh:I

    div-int v11, v6, v10

    rem-int v12, v6, v10

    div-int/2addr v12, v11

    add-int/2addr v10, v12

    goto :goto_3

    :cond_7
    move v10, v3

    move v11, v10

    :goto_3
    move v12, v3

    move v14, v12

    :goto_4
    if-ge v12, v4, :cond_1b

    invoke-virtual {v1, v12}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v15

    check-cast v15, Landroidx/appcompat/view/menu/KLFTb;

    invoke-virtual {v15}, Landroidx/appcompat/view/menu/KLFTb;->YoKzxo()Z

    move-result v16

    if-eqz v16, :cond_b

    invoke-virtual {v0, v15, v2, v8}, Landroidx/appcompat/widget/mjFkc;->YoKzxo(Landroidx/appcompat/view/menu/KLFTb;Landroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;

    move-result-object v13

    iget-boolean v2, v0, Landroidx/appcompat/widget/mjFkc;->Pq:Z

    if-eqz v2, :cond_8

    invoke-static {v13, v10, v11, v7, v3}, Landroidx/appcompat/widget/ActionMenuView;->xrEuO(Landroid/view/View;IIII)I

    move-result v2

    sub-int/2addr v11, v2

    goto :goto_5

    :cond_8
    invoke-virtual {v13, v7, v7}, Landroid/view/View;->measure(II)V

    :goto_5
    invoke-virtual {v13}, Landroid/view/View;->getMeasuredWidth()I

    move-result v2

    sub-int/2addr v6, v2

    if-nez v14, :cond_9

    move v14, v2

    :cond_9
    invoke-virtual {v15}, Landroidx/appcompat/view/menu/KLFTb;->getGroupId()I

    move-result v2

    const/4 v13, 0x1

    if-eqz v2, :cond_a

    invoke-virtual {v9, v2, v13}, Landroid/util/SparseBooleanArray;->put(IZ)V

    :cond_a
    invoke-virtual {v15, v13}, Landroidx/appcompat/view/menu/KLFTb;->diqgf(Z)V

    move v0, v3

    move/from16 v17, v4

    goto/16 :goto_e

    :cond_b
    invoke-virtual {v15}, Landroidx/appcompat/view/menu/KLFTb;->MiMN()Z

    move-result v2

    if-eqz v2, :cond_1a

    invoke-virtual {v15}, Landroidx/appcompat/view/menu/KLFTb;->getGroupId()I

    move-result v2

    invoke-virtual {v9, v2}, Landroid/util/SparseBooleanArray;->get(I)Z

    move-result v13

    if-gtz v5, :cond_c

    if-eqz v13, :cond_e

    :cond_c
    if-lez v6, :cond_e

    iget-boolean v3, v0, Landroidx/appcompat/widget/mjFkc;->Pq:Z

    if-eqz v3, :cond_d

    if-lez v11, :cond_e

    :cond_d
    const/4 v3, 0x1

    goto :goto_6

    :cond_e
    const/4 v3, 0x0

    :goto_6
    move/from16 v18, v3

    move/from16 v17, v4

    if-eqz v3, :cond_14

    const/4 v3, 0x0

    invoke-virtual {v0, v15, v3, v8}, Landroidx/appcompat/widget/mjFkc;->YoKzxo(Landroidx/appcompat/view/menu/KLFTb;Landroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;

    move-result-object v4

    iget-boolean v3, v0, Landroidx/appcompat/widget/mjFkc;->Pq:Z

    if-eqz v3, :cond_10

    const/4 v3, 0x0

    invoke-static {v4, v10, v11, v7, v3}, Landroidx/appcompat/widget/ActionMenuView;->xrEuO(Landroid/view/View;IIII)I

    move-result v19

    sub-int v11, v11, v19

    if-nez v19, :cond_f

    const/16 v18, 0x0

    :cond_f
    :goto_7
    move/from16 v3, v18

    goto :goto_8

    :cond_10
    invoke-virtual {v4, v7, v7}, Landroid/view/View;->measure(II)V

    goto :goto_7

    :goto_8
    invoke-virtual {v4}, Landroid/view/View;->getMeasuredWidth()I

    move-result v4

    sub-int/2addr v6, v4

    if-nez v14, :cond_11

    move v14, v4

    :cond_11
    iget-boolean v4, v0, Landroidx/appcompat/widget/mjFkc;->Pq:Z

    if-eqz v4, :cond_13

    if-ltz v6, :cond_12

    :goto_9
    const/4 v4, 0x1

    goto :goto_a

    :cond_12
    const/4 v4, 0x0

    :goto_a
    and-int/2addr v3, v4

    goto :goto_b

    :cond_13
    add-int v4, v6, v14

    if-lez v4, :cond_12

    goto :goto_9

    :cond_14
    :goto_b
    if-eqz v3, :cond_15

    if-eqz v2, :cond_15

    const/4 v4, 0x1

    invoke-virtual {v9, v2, v4}, Landroid/util/SparseBooleanArray;->put(IZ)V

    goto :goto_d

    :cond_15
    if-eqz v13, :cond_18

    const/4 v4, 0x0

    invoke-virtual {v9, v2, v4}, Landroid/util/SparseBooleanArray;->put(IZ)V

    const/4 v4, 0x0

    :goto_c
    if-ge v4, v12, :cond_18

    invoke-virtual {v1, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v13

    check-cast v13, Landroidx/appcompat/view/menu/KLFTb;

    invoke-virtual {v13}, Landroidx/appcompat/view/menu/KLFTb;->getGroupId()I

    move-result v0

    if-ne v0, v2, :cond_17

    invoke-virtual {v13}, Landroidx/appcompat/view/menu/KLFTb;->ETF()Z

    move-result v0

    if-eqz v0, :cond_16

    add-int/lit8 v5, v5, 0x1

    :cond_16
    const/4 v0, 0x0

    invoke-virtual {v13, v0}, Landroidx/appcompat/view/menu/KLFTb;->diqgf(Z)V

    :cond_17
    add-int/lit8 v4, v4, 0x1

    move-object/from16 v0, p0

    goto :goto_c

    :cond_18
    :goto_d
    if-eqz v3, :cond_19

    add-int/lit8 v5, v5, -0x1

    :cond_19
    invoke-virtual {v15, v3}, Landroidx/appcompat/view/menu/KLFTb;->diqgf(Z)V

    const/4 v0, 0x0

    goto :goto_e

    :cond_1a
    move v0, v3

    move/from16 v17, v4

    invoke-virtual {v15, v0}, Landroidx/appcompat/view/menu/KLFTb;->diqgf(Z)V

    :goto_e
    add-int/lit8 v12, v12, 0x1

    move v3, v0

    move/from16 v4, v17

    const/4 v2, 0x0

    move-object/from16 v0, p0

    goto/16 :goto_4

    :cond_1b
    const/4 v2, 0x1

    return v2
.end method

.method public mByQ(Landroidx/appcompat/widget/ActionMenuView;)V
    .locals 0

    iput-object p1, p0, Landroidx/appcompat/view/menu/mjFkc;->qdMbNW:Landroidx/appcompat/view/menu/lgHUyS;

    iget-object p0, p0, Landroidx/appcompat/view/menu/mjFkc;->wA:Landroidx/appcompat/view/menu/ZfxDd;

    invoke-virtual {p1, p0}, Landroidx/appcompat/widget/ActionMenuView;->Ne(Landroidx/appcompat/view/menu/ZfxDd;)V

    return-void
.end method

.method public rkYL(ILandroidx/appcompat/view/menu/KLFTb;)Z
    .locals 0

    invoke-virtual {p2}, Landroidx/appcompat/view/menu/KLFTb;->ETF()Z

    move-result p0

    return p0
.end method

.method public vI()Z
    .locals 3

    iget-object v0, p0, Landroidx/appcompat/widget/mjFkc;->vI:Landroidx/appcompat/widget/mjFkc$wA;

    const/4 v1, 0x1

    if-eqz v0, :cond_0

    iget-object v2, p0, Landroidx/appcompat/view/menu/mjFkc;->qdMbNW:Landroidx/appcompat/view/menu/lgHUyS;

    if-eqz v2, :cond_0

    check-cast v2, Landroid/view/View;

    invoke-virtual {v2, v0}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    const/4 v0, 0x0

    iput-object v0, p0, Landroidx/appcompat/widget/mjFkc;->vI:Landroidx/appcompat/widget/mjFkc$wA;

    return v1

    :cond_0
    iget-object p0, p0, Landroidx/appcompat/widget/mjFkc;->Gd:Landroidx/appcompat/widget/mjFkc$KLFTb;

    if-eqz p0, :cond_1

    invoke-virtual {p0}, Landroidx/appcompat/view/menu/JHa;->AZxh()V

    return v1

    :cond_1
    const/4 p0, 0x0

    return p0
.end method

.method public wA(Landroid/content/Context;Landroidx/appcompat/view/menu/ZfxDd;)V
    .locals 4

    invoke-super {p0, p1, p2}, Landroidx/appcompat/view/menu/mjFkc;->wA(Landroid/content/Context;Landroidx/appcompat/view/menu/ZfxDd;)V

    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p2

    invoke-static {p1}, Lo/lB;->mjFkc(Landroid/content/Context;)Lo/lB;

    move-result-object p1

    iget-boolean v0, p0, Landroidx/appcompat/widget/mjFkc;->YoKzxo:Z

    if-nez v0, :cond_0

    invoke-virtual {p1}, Lo/lB;->ZfxDd()Z

    move-result v0

    iput-boolean v0, p0, Landroidx/appcompat/widget/mjFkc;->MiMN:Z

    :cond_0
    iget-boolean v0, p0, Landroidx/appcompat/widget/mjFkc;->diqgf:Z

    if-nez v0, :cond_1

    invoke-virtual {p1}, Lo/lB;->AZxh()I

    move-result v0

    iput v0, p0, Landroidx/appcompat/widget/mjFkc;->rkYL:I

    :cond_1
    iget-boolean v0, p0, Landroidx/appcompat/widget/mjFkc;->IEE:Z

    if-nez v0, :cond_2

    invoke-virtual {p1}, Lo/lB;->wA()I

    move-result p1

    iput p1, p0, Landroidx/appcompat/widget/mjFkc;->fehf:I

    :cond_2
    iget p1, p0, Landroidx/appcompat/widget/mjFkc;->rkYL:I

    iget-boolean v0, p0, Landroidx/appcompat/widget/mjFkc;->MiMN:Z

    const/4 v1, 0x0

    if-eqz v0, :cond_5

    iget-object v0, p0, Landroidx/appcompat/widget/mjFkc;->Dt:Landroidx/appcompat/widget/mjFkc$ZfxDd;

    if-nez v0, :cond_4

    new-instance v0, Landroidx/appcompat/widget/mjFkc$ZfxDd;

    iget-object v2, p0, Landroidx/appcompat/view/menu/mjFkc;->mjFkc:Landroid/content/Context;

    invoke-direct {v0, p0, v2}, Landroidx/appcompat/widget/mjFkc$ZfxDd;-><init>(Landroidx/appcompat/widget/mjFkc;Landroid/content/Context;)V

    iput-object v0, p0, Landroidx/appcompat/widget/mjFkc;->Dt:Landroidx/appcompat/widget/mjFkc$ZfxDd;

    iget-boolean v2, p0, Landroidx/appcompat/widget/mjFkc;->VA:Z

    const/4 v3, 0x0

    if-eqz v2, :cond_3

    iget-object v2, p0, Landroidx/appcompat/widget/mjFkc;->ETF:Landroid/graphics/drawable/Drawable;

    invoke-virtual {v0, v2}, Lo/dm;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    iput-object v1, p0, Landroidx/appcompat/widget/mjFkc;->ETF:Landroid/graphics/drawable/Drawable;

    iput-boolean v3, p0, Landroidx/appcompat/widget/mjFkc;->VA:Z

    :cond_3
    invoke-static {v3, v3}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v0

    iget-object v1, p0, Landroidx/appcompat/widget/mjFkc;->Dt:Landroidx/appcompat/widget/mjFkc$ZfxDd;

    invoke-virtual {v1, v0, v0}, Landroid/view/View;->measure(II)V

    :cond_4
    iget-object v0, p0, Landroidx/appcompat/widget/mjFkc;->Dt:Landroidx/appcompat/widget/mjFkc$ZfxDd;

    invoke-virtual {v0}, Landroid/view/View;->getMeasuredWidth()I

    move-result v0

    sub-int/2addr p1, v0

    goto :goto_0

    :cond_5
    iput-object v1, p0, Landroidx/appcompat/widget/mjFkc;->Dt:Landroidx/appcompat/widget/mjFkc$ZfxDd;

    :goto_0
    iput p1, p0, Landroidx/appcompat/widget/mjFkc;->qGY:I

    invoke-virtual {p2}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object p1

    iget p1, p1, Landroid/util/DisplayMetrics;->density:F

    const/high16 p2, 0x42600000    # 56.0f

    mul-float/2addr p1, p2

    float-to-int p1, p1

    iput p1, p0, Landroidx/appcompat/widget/mjFkc;->Ucbh:I

    return-void
.end method

.method public wJVbdd(Z)V
    .locals 0

    iput-boolean p1, p0, Landroidx/appcompat/widget/mjFkc;->eyqo:Z

    return-void
.end method

.method public xJ(Z)V
    .locals 4

    invoke-super {p0, p1}, Landroidx/appcompat/view/menu/mjFkc;->xJ(Z)V

    iget-object p1, p0, Landroidx/appcompat/view/menu/mjFkc;->qdMbNW:Landroidx/appcompat/view/menu/lgHUyS;

    check-cast p1, Landroid/view/View;

    invoke-virtual {p1}, Landroid/view/View;->requestLayout()V

    iget-object p1, p0, Landroidx/appcompat/view/menu/mjFkc;->wA:Landroidx/appcompat/view/menu/ZfxDd;

    const/4 v0, 0x0

    if-eqz p1, :cond_0

    invoke-virtual {p1}, Landroidx/appcompat/view/menu/ZfxDd;->IEE()Ljava/util/ArrayList;

    move-result-object p1

    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result v1

    move v2, v0

    :goto_0
    if-ge v2, v1, :cond_0

    invoke-virtual {p1, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroidx/appcompat/view/menu/KLFTb;

    invoke-virtual {v3}, Landroidx/appcompat/view/menu/KLFTb;->xJ()Lo/mByQ;

    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_0
    iget-object p1, p0, Landroidx/appcompat/view/menu/mjFkc;->wA:Landroidx/appcompat/view/menu/ZfxDd;

    if-eqz p1, :cond_1

    invoke-virtual {p1}, Landroidx/appcompat/view/menu/ZfxDd;->Ucbh()Ljava/util/ArrayList;

    move-result-object p1

    goto :goto_1

    :cond_1
    const/4 p1, 0x0

    :goto_1
    iget-boolean v1, p0, Landroidx/appcompat/widget/mjFkc;->MiMN:Z

    if-eqz v1, :cond_3

    if-eqz p1, :cond_3

    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result v1

    const/4 v2, 0x1

    if-ne v1, v2, :cond_2

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroidx/appcompat/view/menu/KLFTb;

    invoke-virtual {p1}, Landroidx/appcompat/view/menu/KLFTb;->isActionViewExpanded()Z

    move-result p1

    xor-int/lit8 v0, p1, 0x1

    goto :goto_2

    :cond_2
    if-lez v1, :cond_3

    move v0, v2

    :cond_3
    :goto_2
    if-eqz v0, :cond_6

    iget-object p1, p0, Landroidx/appcompat/widget/mjFkc;->Dt:Landroidx/appcompat/widget/mjFkc$ZfxDd;

    if-nez p1, :cond_4

    new-instance p1, Landroidx/appcompat/widget/mjFkc$ZfxDd;

    iget-object v0, p0, Landroidx/appcompat/view/menu/mjFkc;->mjFkc:Landroid/content/Context;

    invoke-direct {p1, p0, v0}, Landroidx/appcompat/widget/mjFkc$ZfxDd;-><init>(Landroidx/appcompat/widget/mjFkc;Landroid/content/Context;)V

    iput-object p1, p0, Landroidx/appcompat/widget/mjFkc;->Dt:Landroidx/appcompat/widget/mjFkc$ZfxDd;

    :cond_4
    iget-object p1, p0, Landroidx/appcompat/widget/mjFkc;->Dt:Landroidx/appcompat/widget/mjFkc$ZfxDd;

    invoke-virtual {p1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object p1

    check-cast p1, Landroid/view/ViewGroup;

    iget-object v0, p0, Landroidx/appcompat/view/menu/mjFkc;->qdMbNW:Landroidx/appcompat/view/menu/lgHUyS;

    if-eq p1, v0, :cond_7

    if-eqz p1, :cond_5

    iget-object v0, p0, Landroidx/appcompat/widget/mjFkc;->Dt:Landroidx/appcompat/widget/mjFkc$ZfxDd;

    invoke-virtual {p1, v0}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    :cond_5
    iget-object p1, p0, Landroidx/appcompat/view/menu/mjFkc;->qdMbNW:Landroidx/appcompat/view/menu/lgHUyS;

    check-cast p1, Landroidx/appcompat/widget/ActionMenuView;

    iget-object v0, p0, Landroidx/appcompat/widget/mjFkc;->Dt:Landroidx/appcompat/widget/mjFkc$ZfxDd;

    invoke-virtual {p1}, Landroidx/appcompat/widget/ActionMenuView;->mByQ()Landroidx/appcompat/widget/ActionMenuView$wA;

    move-result-object v1

    invoke-virtual {p1, v0, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    goto :goto_3

    :cond_6
    iget-object p1, p0, Landroidx/appcompat/widget/mjFkc;->Dt:Landroidx/appcompat/widget/mjFkc$ZfxDd;

    if-eqz p1, :cond_7

    invoke-virtual {p1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object p1

    iget-object v0, p0, Landroidx/appcompat/view/menu/mjFkc;->qdMbNW:Landroidx/appcompat/view/menu/lgHUyS;

    if-ne p1, v0, :cond_7

    check-cast v0, Landroid/view/ViewGroup;

    iget-object p1, p0, Landroidx/appcompat/widget/mjFkc;->Dt:Landroidx/appcompat/widget/mjFkc$ZfxDd;

    invoke-virtual {v0, p1}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    :cond_7
    :goto_3
    iget-object p1, p0, Landroidx/appcompat/view/menu/mjFkc;->qdMbNW:Landroidx/appcompat/view/menu/lgHUyS;

    check-cast p1, Landroidx/appcompat/widget/ActionMenuView;

    iget-boolean p0, p0, Landroidx/appcompat/widget/mjFkc;->MiMN:Z

    invoke-virtual {p1, p0}, Landroidx/appcompat/widget/ActionMenuView;->setOverflowReserved(Z)V

    return-void
.end method
