.class public Landroidx/fragment/app/wA$ZfxDd;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lo/BxruE$mjFkc;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Landroidx/fragment/app/wA;->Ucbh(Ljava/util/List;Ljava/util/List;ZLjava/util/Map;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic AZxh:Landroidx/fragment/app/wA;

.field public final synthetic mjFkc:Landroid/animation/Animator;


# direct methods
.method public constructor <init>(Landroidx/fragment/app/wA;Landroid/animation/Animator;)V
    .locals 0

    iput-object p1, p0, Landroidx/fragment/app/wA$ZfxDd;->AZxh:Landroidx/fragment/app/wA;

    iput-object p2, p0, Landroidx/fragment/app/wA$ZfxDd;->mjFkc:Landroid/animation/Animator;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public mjFkc()V
    .locals 0

    iget-object p0, p0, Landroidx/fragment/app/wA$ZfxDd;->mjFkc:Landroid/animation/Animator;

    invoke-virtual {p0}, Landroid/animation/Animator;->end()V

    return-void
.end method
