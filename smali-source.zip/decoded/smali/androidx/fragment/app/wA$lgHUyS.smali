.class public Landroidx/fragment/app/wA$lgHUyS;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Landroidx/fragment/app/wA;->huTpC(Ljava/util/List;Ljava/util/List;ZLandroidx/fragment/app/Dt$KLFTb;Landroidx/fragment/app/Dt$KLFTb;)Ljava/util/Map;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic AZxh:Landroid/view/View;

.field public final synthetic ZfxDd:Landroidx/fragment/app/wA;

.field public final synthetic mjFkc:Lo/KbpP;

.field public final synthetic wA:Landroid/graphics/Rect;


# direct methods
.method public constructor <init>(Landroidx/fragment/app/wA;Lo/KbpP;Landroid/view/View;Landroid/graphics/Rect;)V
    .locals 0

    iput-object p1, p0, Landroidx/fragment/app/wA$lgHUyS;->ZfxDd:Landroidx/fragment/app/wA;

    iput-object p2, p0, Landroidx/fragment/app/wA$lgHUyS;->mjFkc:Lo/KbpP;

    iput-object p3, p0, Landroidx/fragment/app/wA$lgHUyS;->AZxh:Landroid/view/View;

    iput-object p4, p0, Landroidx/fragment/app/wA$lgHUyS;->wA:Landroid/graphics/Rect;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 2

    iget-object v0, p0, Landroidx/fragment/app/wA$lgHUyS;->mjFkc:Lo/KbpP;

    iget-object v1, p0, Landroidx/fragment/app/wA$lgHUyS;->AZxh:Landroid/view/View;

    iget-object p0, p0, Landroidx/fragment/app/wA$lgHUyS;->wA:Landroid/graphics/Rect;

    invoke-virtual {v0, v1, p0}, Lo/KbpP;->lgHUyS(Landroid/view/View;Landroid/graphics/Rect;)V

    return-void
.end method
