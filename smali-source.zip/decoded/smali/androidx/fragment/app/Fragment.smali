.class public abstract Landroidx/fragment/app/Fragment;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/content/ComponentCallbacks;
.implements Landroid/view/View$OnCreateContextMenuListener;
.implements Lo/W0;
.implements Lo/ja;
.implements Lo/n6;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/fragment/app/Fragment$wA;,
        Landroidx/fragment/app/Fragment$ZfxDd;
    }
.end annotation


# static fields
.field public static final JYgkl:Ljava/lang/Object;


# instance fields
.field public AZxh:Landroid/os/Bundle;

.field public BAnRFn:Z

.field public CqaNbM:Landroidx/fragment/app/Fragment$wA;

.field public Dt:Z

.field public ETF:Z

.field public GMIER:I

.field public Gd:Z

.field public HGpJ:Z

.field public IEE:Landroidx/fragment/app/KLFTb;

.field public JHa:Landroid/os/Bundle;

.field public final JYn:Ljava/util/ArrayList;

.field public KLFTb:Ljava/lang/String;

.field public KLMXS:Z

.field public KRTLGT:Lo/m6;

.field public MiMN:Z

.field public NPj:Landroidx/lifecycle/wA$AZxh;

.field public Ne:Z

.field public OjSQV:Z

.field public Pq:Landroidx/fragment/app/Fragment;

.field public Ucbh:Ljava/lang/String;

.field public VA:Z

.field public Vnb:Z

.field public VocHEe:Z

.field public WrLQs:Lo/ha$mjFkc;

.field public YoKzxo:Z

.field public ZfxDd:Landroid/os/Bundle;

.field public aqHPIZ:Lo/A2;

.field public cMLeY:F

.field public diqgf:I

.field public eyqo:I

.field public fehf:Landroidx/fragment/app/KLFTb;

.field public huTpC:Z

.field public lB:Z

.field public lgHUyS:Ljava/lang/String;

.field public mByQ:Landroid/view/View;

.field public mjFkc:I

.field public oCFDzJ:Lo/BEUaYa;

.field public qGY:I

.field public qdMbNW:Ljava/lang/Boolean;

.field public rWxwaT:Landroid/view/LayoutInflater;

.field public rkYL:Z

.field public final uHVRx:Ljava/util/concurrent/atomic/AtomicInteger;

.field public vI:Z

.field public vadzgd:Landroidx/lifecycle/JHa;

.field public wA:Landroid/util/SparseArray;

.field public wJVbdd:Landroid/view/ViewGroup;

.field public xJ:Landroidx/fragment/app/Fragment;

.field public xrEuO:Ljava/lang/Runnable;

.field public zvd:Z


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Landroidx/fragment/app/Fragment;->JYgkl:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, -0x1

    iput v0, p0, Landroidx/fragment/app/Fragment;->mjFkc:I

    invoke-static {}, Ljava/util/UUID;->randomUUID()Ljava/util/UUID;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/UUID;->toString()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Landroidx/fragment/app/Fragment;->KLFTb:Ljava/lang/String;

    const/4 v0, 0x0

    iput-object v0, p0, Landroidx/fragment/app/Fragment;->lgHUyS:Ljava/lang/String;

    iput-object v0, p0, Landroidx/fragment/app/Fragment;->qdMbNW:Ljava/lang/Boolean;

    new-instance v0, Lo/RleMQT;

    invoke-direct {v0}, Lo/RleMQT;-><init>()V

    iput-object v0, p0, Landroidx/fragment/app/Fragment;->IEE:Landroidx/fragment/app/KLFTb;

    const/4 v0, 0x1

    iput-boolean v0, p0, Landroidx/fragment/app/Fragment;->BAnRFn:Z

    iput-boolean v0, p0, Landroidx/fragment/app/Fragment;->Ne:Z

    new-instance v0, Landroidx/fragment/app/Fragment$mjFkc;

    invoke-direct {v0, p0}, Landroidx/fragment/app/Fragment$mjFkc;-><init>(Landroidx/fragment/app/Fragment;)V

    iput-object v0, p0, Landroidx/fragment/app/Fragment;->xrEuO:Ljava/lang/Runnable;

    sget-object v0, Landroidx/lifecycle/wA$AZxh;->KLFTb:Landroidx/lifecycle/wA$AZxh;

    iput-object v0, p0, Landroidx/fragment/app/Fragment;->NPj:Landroidx/lifecycle/wA$AZxh;

    new-instance v0, Lo/A2;

    invoke-direct {v0}, Lo/A2;-><init>()V

    iput-object v0, p0, Landroidx/fragment/app/Fragment;->aqHPIZ:Lo/A2;

    new-instance v0, Ljava/util/concurrent/atomic/AtomicInteger;

    invoke-direct {v0}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>()V

    iput-object v0, p0, Landroidx/fragment/app/Fragment;->uHVRx:Ljava/util/concurrent/atomic/AtomicInteger;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Landroidx/fragment/app/Fragment;->JYn:Ljava/util/ArrayList;

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->NPj()V

    return-void
.end method


# virtual methods
.method public ANMGZc()V
    .locals 1

    const/4 v0, 0x1

    iput-boolean v0, p0, Landroidx/fragment/app/Fragment;->lB:Z

    return-void
.end method

.method public BAnRFn()I
    .locals 0

    iget-object p0, p0, Landroidx/fragment/app/Fragment;->CqaNbM:Landroidx/fragment/app/Fragment$wA;

    if-nez p0, :cond_0

    const/4 p0, 0x0

    return p0

    :cond_0
    iget p0, p0, Landroidx/fragment/app/Fragment$wA;->ZfxDd:I

    return p0
.end method

.method public CqaNbM()Ljava/lang/Object;
    .locals 0

    iget-object p0, p0, Landroidx/fragment/app/Fragment;->CqaNbM:Landroidx/fragment/app/Fragment$wA;

    if-nez p0, :cond_0

    const/4 p0, 0x0

    return-object p0

    :cond_0
    iget-object p0, p0, Landroidx/fragment/app/Fragment$wA;->MiMN:Ljava/lang/Object;

    return-object p0
.end method

.method public Dp(Landroid/content/Intent;ILandroid/os/Bundle;)V
    .locals 0

    new-instance p1, Ljava/lang/IllegalStateException;

    new-instance p2, Ljava/lang/StringBuilder;

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const-string p3, "Fragment "

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p0, " not attached to Activity"

    invoke-virtual {p2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {p1, p0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public Dt()Z
    .locals 0

    iget-object p0, p0, Landroidx/fragment/app/Fragment;->CqaNbM:Landroidx/fragment/app/Fragment$wA;

    if-eqz p0, :cond_1

    iget-object p0, p0, Landroidx/fragment/app/Fragment$wA;->qGY:Ljava/lang/Boolean;

    if-nez p0, :cond_0

    goto :goto_0

    :cond_0
    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    goto :goto_1

    :cond_1
    :goto_0
    const/4 p0, 0x1

    :goto_1
    return p0
.end method

.method public ETF()Z
    .locals 0

    iget-object p0, p0, Landroidx/fragment/app/Fragment;->CqaNbM:Landroidx/fragment/app/Fragment$wA;

    if-eqz p0, :cond_1

    iget-object p0, p0, Landroidx/fragment/app/Fragment$wA;->rkYL:Ljava/lang/Boolean;

    if-nez p0, :cond_0

    goto :goto_0

    :cond_0
    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    goto :goto_1

    :cond_1
    :goto_0
    const/4 p0, 0x1

    :goto_1
    return p0
.end method

.method public final GMIER()Z
    .locals 0

    iget-object p0, p0, Landroidx/fragment/app/Fragment;->fehf:Landroidx/fragment/app/KLFTb;

    if-nez p0, :cond_0

    const/4 p0, 0x0

    return p0

    :cond_0
    invoke-virtual {p0}, Landroidx/fragment/app/KLFTb;->xROA()Z

    move-result p0

    return p0
.end method

.method public Gd()I
    .locals 0

    iget-object p0, p0, Landroidx/fragment/app/Fragment;->CqaNbM:Landroidx/fragment/app/Fragment$wA;

    if-nez p0, :cond_0

    const/4 p0, 0x0

    return p0

    :cond_0
    iget p0, p0, Landroidx/fragment/app/Fragment$wA;->JHa:I

    return p0
.end method

.method public final HGpJ()Landroidx/fragment/app/Fragment;
    .locals 0

    iget-object p0, p0, Landroidx/fragment/app/Fragment;->Pq:Landroidx/fragment/app/Fragment;

    return-object p0
.end method

.method public IEE()I
    .locals 0

    iget-object p0, p0, Landroidx/fragment/app/Fragment;->CqaNbM:Landroidx/fragment/app/Fragment$wA;

    if-nez p0, :cond_0

    const/4 p0, 0x0

    return p0

    :cond_0
    iget p0, p0, Landroidx/fragment/app/Fragment$wA;->wA:I

    return p0
.end method

.method public IVlxe(Landroid/os/Bundle;)V
    .locals 3

    iget-object v0, p0, Landroidx/fragment/app/Fragment;->IEE:Landroidx/fragment/app/KLFTb;

    invoke-virtual {v0}, Landroidx/fragment/app/KLFTb;->NKyg()V

    const/4 v0, 0x1

    iput v0, p0, Landroidx/fragment/app/Fragment;->mjFkc:I

    const/4 v1, 0x0

    iput-boolean v1, p0, Landroidx/fragment/app/Fragment;->lB:Z

    iget-object v1, p0, Landroidx/fragment/app/Fragment;->vadzgd:Landroidx/lifecycle/JHa;

    new-instance v2, Landroidx/fragment/app/Fragment$5;

    invoke-direct {v2, p0}, Landroidx/fragment/app/Fragment$5;-><init>(Landroidx/fragment/app/Fragment;)V

    invoke-virtual {v1, v2}, Landroidx/lifecycle/JHa;->mjFkc(Lo/V0;)V

    iget-object v1, p0, Landroidx/fragment/app/Fragment;->KRTLGT:Lo/m6;

    invoke-virtual {v1, p1}, Lo/m6;->ZfxDd(Landroid/os/Bundle;)V

    invoke-virtual {p0, p1}, Landroidx/fragment/app/Fragment;->JYn(Landroid/os/Bundle;)V

    iput-boolean v0, p0, Landroidx/fragment/app/Fragment;->Vnb:Z

    iget-boolean p1, p0, Landroidx/fragment/app/Fragment;->lB:Z

    if-eqz p1, :cond_0

    iget-object p0, p0, Landroidx/fragment/app/Fragment;->vadzgd:Landroidx/lifecycle/JHa;

    sget-object p1, Landroidx/lifecycle/wA$mjFkc;->ON_CREATE:Landroidx/lifecycle/wA$mjFkc;

    invoke-virtual {p0, p1}, Landroidx/lifecycle/JHa;->lgHUyS(Landroidx/lifecycle/wA$mjFkc;)V

    return-void

    :cond_0
    new-instance p1, Lo/s7;

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "Fragment "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p0, " did not call through to super.onCreate()"

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {p1, p0}, Lo/s7;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public JBhc(Landroid/content/Context;Landroid/util/AttributeSet;Landroid/os/Bundle;)V
    .locals 0

    const/4 p1, 0x1

    iput-boolean p1, p0, Landroidx/fragment/app/Fragment;->lB:Z

    return-void
.end method

.method public JHa()Landroidx/lifecycle/wA;
    .locals 0

    iget-object p0, p0, Landroidx/fragment/app/Fragment;->vadzgd:Landroidx/lifecycle/JHa;

    return-object p0
.end method

.method public JYgkl(IZI)Landroid/view/animation/Animation;
    .locals 0

    const/4 p0, 0x0

    return-object p0
.end method

.method public JYn(Landroid/os/Bundle;)V
    .locals 1

    const/4 v0, 0x1

    iput-boolean v0, p0, Landroidx/fragment/app/Fragment;->lB:Z

    invoke-virtual {p0, p1}, Landroidx/fragment/app/Fragment;->XFUzSY(Landroid/os/Bundle;)V

    iget-object p1, p0, Landroidx/fragment/app/Fragment;->IEE:Landroidx/fragment/app/KLFTb;

    invoke-virtual {p1, v0}, Landroidx/fragment/app/KLFTb;->vjlshU(I)Z

    move-result p1

    if-nez p1, :cond_0

    iget-object p0, p0, Landroidx/fragment/app/Fragment;->IEE:Landroidx/fragment/app/KLFTb;

    invoke-virtual {p0}, Landroidx/fragment/app/KLFTb;->Ucbh()V

    :cond_0
    return-void
.end method

.method public JrJO(IZI)Landroid/animation/Animator;
    .locals 0

    const/4 p0, 0x0

    return-object p0
.end method

.method public KLMXS()Ljava/util/ArrayList;
    .locals 0

    iget-object p0, p0, Landroidx/fragment/app/Fragment;->CqaNbM:Landroidx/fragment/app/Fragment$wA;

    if-eqz p0, :cond_1

    iget-object p0, p0, Landroidx/fragment/app/Fragment$wA;->xJ:Ljava/util/ArrayList;

    if-nez p0, :cond_0

    goto :goto_0

    :cond_0
    return-object p0

    :cond_1
    :goto_0
    new-instance p0, Ljava/util/ArrayList;

    invoke-direct {p0}, Ljava/util/ArrayList;-><init>()V

    return-object p0
.end method

.method public final KRTLGT()Z
    .locals 1

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->HGpJ()Landroidx/fragment/app/Fragment;

    move-result-object p0

    if-eqz p0, :cond_1

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->WrLQs()Z

    move-result v0

    if-nez v0, :cond_0

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->KRTLGT()Z

    move-result p0

    if-eqz p0, :cond_1

    :cond_0
    const/4 p0, 0x1

    goto :goto_0

    :cond_1
    const/4 p0, 0x0

    :goto_0
    return p0
.end method

.method public final LREOK()Lo/RnaHj;
    .locals 3

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->qdMbNW()Lo/RnaHj;

    new-instance v0, Ljava/lang/IllegalStateException;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "Fragment "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p0, " not attached to an activity."

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public final MiMN()Landroidx/fragment/app/KLFTb;
    .locals 3

    new-instance v0, Ljava/lang/IllegalStateException;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "Fragment "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p0, " has not been attached yet."

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public Moer(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Landroid/os/Bundle;)V
    .locals 2

    iget-object v0, p0, Landroidx/fragment/app/Fragment;->IEE:Landroidx/fragment/app/KLFTb;

    invoke-virtual {v0}, Landroidx/fragment/app/KLFTb;->NKyg()V

    const/4 v0, 0x1

    iput-boolean v0, p0, Landroidx/fragment/app/Fragment;->rkYL:Z

    new-instance v0, Lo/BEUaYa;

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->wA()Lo/ia;

    move-result-object v1

    invoke-direct {v0, p0, v1}, Lo/BEUaYa;-><init>(Landroidx/fragment/app/Fragment;Lo/ia;)V

    iput-object v0, p0, Landroidx/fragment/app/Fragment;->oCFDzJ:Lo/BEUaYa;

    invoke-virtual {p0, p1, p2, p3}, Landroidx/fragment/app/Fragment;->nxI(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Landroid/os/Bundle;)Landroid/view/View;

    move-result-object p1

    iput-object p1, p0, Landroidx/fragment/app/Fragment;->mByQ:Landroid/view/View;

    if-eqz p1, :cond_0

    iget-object p1, p0, Landroidx/fragment/app/Fragment;->oCFDzJ:Lo/BEUaYa;

    invoke-virtual {p1}, Lo/BEUaYa;->ZfxDd()V

    iget-object p1, p0, Landroidx/fragment/app/Fragment;->mByQ:Landroid/view/View;

    iget-object p2, p0, Landroidx/fragment/app/Fragment;->oCFDzJ:Lo/BEUaYa;

    invoke-static {p1, p2}, Lo/pa;->mjFkc(Landroid/view/View;Lo/W0;)V

    iget-object p1, p0, Landroidx/fragment/app/Fragment;->mByQ:Landroid/view/View;

    iget-object p2, p0, Landroidx/fragment/app/Fragment;->oCFDzJ:Lo/BEUaYa;

    invoke-static {p1, p2}, Lo/ra;->mjFkc(Landroid/view/View;Lo/ja;)V

    iget-object p1, p0, Landroidx/fragment/app/Fragment;->mByQ:Landroid/view/View;

    iget-object p2, p0, Landroidx/fragment/app/Fragment;->oCFDzJ:Lo/BEUaYa;

    invoke-static {p1, p2}, Lo/qa;->mjFkc(Landroid/view/View;Lo/n6;)V

    iget-object p1, p0, Landroidx/fragment/app/Fragment;->aqHPIZ:Lo/A2;

    iget-object p0, p0, Landroidx/fragment/app/Fragment;->oCFDzJ:Lo/BEUaYa;

    invoke-virtual {p1, p0}, Lo/A2;->lgHUyS(Ljava/lang/Object;)V

    goto :goto_0

    :cond_0
    iget-object p1, p0, Landroidx/fragment/app/Fragment;->oCFDzJ:Lo/BEUaYa;

    invoke-virtual {p1}, Lo/BEUaYa;->KLFTb()Z

    move-result p1

    if-nez p1, :cond_1

    const/4 p1, 0x0

    iput-object p1, p0, Landroidx/fragment/app/Fragment;->oCFDzJ:Lo/BEUaYa;

    :goto_0
    return-void

    :cond_1
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string p1, "Called getViewLifecycleOwner() but onCreateView() returned null"

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public NKyg()V
    .locals 3

    iget-object v0, p0, Landroidx/fragment/app/Fragment;->IEE:Landroidx/fragment/app/KLFTb;

    invoke-virtual {v0}, Landroidx/fragment/app/KLFTb;->vI()V

    iget-object v0, p0, Landroidx/fragment/app/Fragment;->mByQ:Landroid/view/View;

    if-eqz v0, :cond_0

    iget-object v0, p0, Landroidx/fragment/app/Fragment;->oCFDzJ:Lo/BEUaYa;

    sget-object v1, Landroidx/lifecycle/wA$mjFkc;->ON_PAUSE:Landroidx/lifecycle/wA$mjFkc;

    invoke-virtual {v0, v1}, Lo/BEUaYa;->AZxh(Landroidx/lifecycle/wA$mjFkc;)V

    :cond_0
    iget-object v0, p0, Landroidx/fragment/app/Fragment;->vadzgd:Landroidx/lifecycle/JHa;

    sget-object v1, Landroidx/lifecycle/wA$mjFkc;->ON_PAUSE:Landroidx/lifecycle/wA$mjFkc;

    invoke-virtual {v0, v1}, Landroidx/lifecycle/JHa;->lgHUyS(Landroidx/lifecycle/wA$mjFkc;)V

    const/4 v0, 0x6

    iput v0, p0, Landroidx/fragment/app/Fragment;->mjFkc:I

    const/4 v0, 0x0

    iput-boolean v0, p0, Landroidx/fragment/app/Fragment;->lB:Z

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->Vdz()V

    iget-boolean v0, p0, Landroidx/fragment/app/Fragment;->lB:Z

    if-eqz v0, :cond_1

    return-void

    :cond_1
    new-instance v0, Lo/s7;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "Fragment "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p0, " did not call through to super.onPause()"

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Lo/s7;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public final NPj()V
    .locals 1

    new-instance v0, Landroidx/lifecycle/JHa;

    invoke-direct {v0, p0}, Landroidx/lifecycle/JHa;-><init>(Lo/W0;)V

    iput-object v0, p0, Landroidx/fragment/app/Fragment;->vadzgd:Landroidx/lifecycle/JHa;

    invoke-static {p0}, Lo/m6;->mjFkc(Lo/n6;)Lo/m6;

    move-result-object v0

    iput-object v0, p0, Landroidx/fragment/app/Fragment;->KRTLGT:Lo/m6;

    const/4 v0, 0x0

    iput-object v0, p0, Landroidx/fragment/app/Fragment;->WrLQs:Lo/ha$mjFkc;

    return-void
.end method

.method public Ne()Ljava/lang/Object;
    .locals 2

    iget-object v0, p0, Landroidx/fragment/app/Fragment;->CqaNbM:Landroidx/fragment/app/Fragment$wA;

    if-nez v0, :cond_0

    const/4 p0, 0x0

    return-object p0

    :cond_0
    iget-object v0, v0, Landroidx/fragment/app/Fragment$wA;->Dt:Ljava/lang/Object;

    sget-object v1, Landroidx/fragment/app/Fragment;->JYgkl:Ljava/lang/Object;

    if-ne v0, v1, :cond_1

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->qGY()Ljava/lang/Object;

    move-result-object v0

    :cond_1
    return-object v0
.end method

.method public final OjSQV()Landroid/content/res/Resources;
    .locals 0

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->fFz()Landroid/content/Context;

    move-result-object p0

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    return-object p0
.end method

.method public Pq()Ljava/lang/Object;
    .locals 0

    iget-object p0, p0, Landroidx/fragment/app/Fragment;->CqaNbM:Landroidx/fragment/app/Fragment$wA;

    if-nez p0, :cond_0

    const/4 p0, 0x0

    return-object p0

    :cond_0
    iget-object p0, p0, Landroidx/fragment/app/Fragment$wA;->ETF:Ljava/lang/Object;

    return-object p0
.end method

.method public Qr(Landroid/os/Bundle;)Landroid/view/LayoutInflater;
    .locals 0

    invoke-virtual {p0, p1}, Landroidx/fragment/app/Fragment;->bbzow(Landroid/os/Bundle;)Landroid/view/LayoutInflater;

    move-result-object p1

    iput-object p1, p0, Landroidx/fragment/app/Fragment;->rWxwaT:Landroid/view/LayoutInflater;

    return-object p1
.end method

.method public SOS()V
    .locals 3

    const/4 v0, -0x1

    iput v0, p0, Landroidx/fragment/app/Fragment;->mjFkc:I

    const/4 v0, 0x0

    iput-boolean v0, p0, Landroidx/fragment/app/Fragment;->lB:Z

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->XV()V

    const/4 v0, 0x0

    iput-object v0, p0, Landroidx/fragment/app/Fragment;->rWxwaT:Landroid/view/LayoutInflater;

    iget-boolean v0, p0, Landroidx/fragment/app/Fragment;->lB:Z

    if-eqz v0, :cond_1

    iget-object v0, p0, Landroidx/fragment/app/Fragment;->IEE:Landroidx/fragment/app/KLFTb;

    invoke-virtual {v0}, Landroidx/fragment/app/KLFTb;->alEkx()Z

    move-result v0

    if-nez v0, :cond_0

    iget-object v0, p0, Landroidx/fragment/app/Fragment;->IEE:Landroidx/fragment/app/KLFTb;

    invoke-virtual {v0}, Landroidx/fragment/app/KLFTb;->huTpC()V

    new-instance v0, Lo/RleMQT;

    invoke-direct {v0}, Lo/RleMQT;-><init>()V

    iput-object v0, p0, Landroidx/fragment/app/Fragment;->IEE:Landroidx/fragment/app/KLFTb;

    :cond_0
    return-void

    :cond_1
    new-instance v0, Lo/s7;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "Fragment "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p0, " did not call through to super.onDetach()"

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Lo/s7;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public SmIWf()V
    .locals 3

    iget-object v0, p0, Landroidx/fragment/app/Fragment;->IEE:Landroidx/fragment/app/KLFTb;

    invoke-virtual {v0}, Landroidx/fragment/app/KLFTb;->Gd()V

    iget-object v0, p0, Landroidx/fragment/app/Fragment;->mByQ:Landroid/view/View;

    if-eqz v0, :cond_0

    iget-object v0, p0, Landroidx/fragment/app/Fragment;->oCFDzJ:Lo/BEUaYa;

    invoke-virtual {v0}, Lo/BEUaYa;->JHa()Landroidx/lifecycle/wA;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/lifecycle/wA;->AZxh()Landroidx/lifecycle/wA$AZxh;

    move-result-object v0

    sget-object v1, Landroidx/lifecycle/wA$AZxh;->wA:Landroidx/lifecycle/wA$AZxh;

    invoke-virtual {v0, v1}, Landroidx/lifecycle/wA$AZxh;->lgHUyS(Landroidx/lifecycle/wA$AZxh;)Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Landroidx/fragment/app/Fragment;->oCFDzJ:Lo/BEUaYa;

    sget-object v1, Landroidx/lifecycle/wA$mjFkc;->ON_DESTROY:Landroidx/lifecycle/wA$mjFkc;

    invoke-virtual {v0, v1}, Lo/BEUaYa;->AZxh(Landroidx/lifecycle/wA$mjFkc;)V

    :cond_0
    const/4 v0, 0x1

    iput v0, p0, Landroidx/fragment/app/Fragment;->mjFkc:I

    const/4 v0, 0x0

    iput-boolean v0, p0, Landroidx/fragment/app/Fragment;->lB:Z

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->WGXroI()V

    iget-boolean v1, p0, Landroidx/fragment/app/Fragment;->lB:Z

    if-eqz v1, :cond_1

    invoke-static {p0}, Lo/d1;->mjFkc(Lo/W0;)Lo/d1;

    move-result-object v1

    invoke-virtual {v1}, Lo/d1;->AZxh()V

    iput-boolean v0, p0, Landroidx/fragment/app/Fragment;->rkYL:Z

    return-void

    :cond_1
    new-instance v0, Lo/s7;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "Fragment "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p0, " did not call through to super.onDestroyView()"

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Lo/s7;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public SwgkN(Z)V
    .locals 0

    return-void
.end method

.method public Ucbh(Landroid/os/Bundle;)Landroid/view/LayoutInflater;
    .locals 0

    new-instance p0, Ljava/lang/IllegalStateException;

    const-string p1, "onGetLayoutInflater() cannot be executed until the Fragment is attached to the FragmentManager."

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public final VA()Landroid/os/Bundle;
    .locals 0

    iget-object p0, p0, Landroidx/fragment/app/Fragment;->JHa:Landroid/os/Bundle;

    return-object p0
.end method

.method public Vdz()V
    .locals 1

    const/4 v0, 0x1

    iput-boolean v0, p0, Landroidx/fragment/app/Fragment;->lB:Z

    return-void
.end method

.method public Vgyli(Landroid/view/View;)V
    .locals 0

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->lgHUyS()Landroidx/fragment/app/Fragment$wA;

    move-result-object p0

    iput-object p1, p0, Landroidx/fragment/app/Fragment$wA;->IEE:Landroid/view/View;

    return-void
.end method

.method public Vnb()Landroidx/lifecycle/LiveData;
    .locals 0

    iget-object p0, p0, Landroidx/fragment/app/Fragment;->aqHPIZ:Lo/A2;

    return-object p0
.end method

.method public VocHEe()Z
    .locals 0

    iget-object p0, p0, Landroidx/fragment/app/Fragment;->CqaNbM:Landroidx/fragment/app/Fragment$wA;

    if-nez p0, :cond_0

    const/4 p0, 0x0

    return p0

    :cond_0
    iget-boolean p0, p0, Landroidx/fragment/app/Fragment$wA;->mjFkc:Z

    return p0
.end method

.method public WGXroI()V
    .locals 1

    const/4 v0, 0x1

    iput-boolean v0, p0, Landroidx/fragment/app/Fragment;->lB:Z

    return-void
.end method

.method public final WrLQs()Z
    .locals 0

    iget-boolean p0, p0, Landroidx/fragment/app/Fragment;->ETF:Z

    return p0
.end method

.method public XD(F)V
    .locals 0

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->lgHUyS()Landroidx/fragment/app/Fragment$wA;

    move-result-object p0

    iput p1, p0, Landroidx/fragment/app/Fragment$wA;->fehf:F

    return-void
.end method

.method public XFUzSY(Landroid/os/Bundle;)V
    .locals 1

    if-eqz p1, :cond_0

    const-string v0, "android:support:fragments"

    invoke-virtual {p1, v0}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object p1

    if-eqz p1, :cond_0

    iget-object v0, p0, Landroidx/fragment/app/Fragment;->IEE:Landroidx/fragment/app/KLFTb;

    invoke-virtual {v0, p1}, Landroidx/fragment/app/KLFTb;->jx(Landroid/os/Parcelable;)V

    iget-object p0, p0, Landroidx/fragment/app/Fragment;->IEE:Landroidx/fragment/app/KLFTb;

    invoke-virtual {p0}, Landroidx/fragment/app/KLFTb;->Ucbh()V

    :cond_0
    return-void
.end method

.method public XV()V
    .locals 1

    const/4 v0, 0x1

    iput-boolean v0, p0, Landroidx/fragment/app/Fragment;->lB:Z

    return-void
.end method

.method public final XbiWeM()Landroid/view/View;
    .locals 3

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->rWxwaT()Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_0

    return-object v0

    :cond_0
    new-instance v0, Ljava/lang/IllegalStateException;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "Fragment "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p0, " did not return a View from onCreateView() or this was called before onCreateView()."

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public final XtE()V
    .locals 2

    const/4 v0, 0x3

    invoke-static {v0}, Landroidx/fragment/app/KLFTb;->dm(I)Z

    move-result v0

    if-eqz v0, :cond_0

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "moveto RESTORE_VIEW_STATE: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "FragmentManager"

    invoke-static {v1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    :cond_0
    iget-object v0, p0, Landroidx/fragment/app/Fragment;->mByQ:Landroid/view/View;

    if-eqz v0, :cond_1

    iget-object v0, p0, Landroidx/fragment/app/Fragment;->AZxh:Landroid/os/Bundle;

    invoke-virtual {p0, v0}, Landroidx/fragment/app/Fragment;->jx(Landroid/os/Bundle;)V

    :cond_1
    const/4 v0, 0x0

    iput-object v0, p0, Landroidx/fragment/app/Fragment;->AZxh:Landroid/os/Bundle;

    return-void
.end method

.method public YoKzxo()Landroid/content/Context;
    .locals 0

    const/4 p0, 0x0

    return-object p0
.end method

.method public alEkx()V
    .locals 1

    const/4 v0, 0x1

    iput-boolean v0, p0, Landroidx/fragment/app/Fragment;->lB:Z

    return-void
.end method

.method public aqHPIZ()Z
    .locals 0

    iget-object p0, p0, Landroidx/fragment/app/Fragment;->CqaNbM:Landroidx/fragment/app/Fragment$wA;

    if-nez p0, :cond_0

    const/4 p0, 0x0

    return p0

    :cond_0
    iget-boolean p0, p0, Landroidx/fragment/app/Fragment$wA;->Pq:Z

    return p0
.end method

.method public bbzow(Landroid/os/Bundle;)Landroid/view/LayoutInflater;
    .locals 0

    invoke-virtual {p0, p1}, Landroidx/fragment/app/Fragment;->Ucbh(Landroid/os/Bundle;)Landroid/view/LayoutInflater;

    move-result-object p0

    return-object p0
.end method

.method public final cMLeY(I)Ljava/lang/String;
    .locals 0

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->OjSQV()Landroid/content/res/Resources;

    move-result-object p0

    invoke-virtual {p0, p1}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public diqgf()Lo/M6;
    .locals 1

    iget-object p0, p0, Landroidx/fragment/app/Fragment;->CqaNbM:Landroidx/fragment/app/Fragment$wA;

    const/4 v0, 0x0

    if-nez p0, :cond_0

    return-object v0

    :cond_0
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    return-object v0
.end method

.method public dm()V
    .locals 1

    const/4 v0, 0x1

    iput-boolean v0, p0, Landroidx/fragment/app/Fragment;->lB:Z

    return-void
.end method

.method public final equals(Ljava/lang/Object;)Z
    .locals 0

    invoke-super {p0, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result p0

    return p0
.end method

.method public eyqo()Landroid/view/View;
    .locals 0

    iget-object p0, p0, Landroidx/fragment/app/Fragment;->CqaNbM:Landroidx/fragment/app/Fragment$wA;

    if-nez p0, :cond_0

    const/4 p0, 0x0

    return-object p0

    :cond_0
    iget-object p0, p0, Landroidx/fragment/app/Fragment$wA;->IEE:Landroid/view/View;

    return-object p0
.end method

.method public final fFz()Landroid/content/Context;
    .locals 3

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->YoKzxo()Landroid/content/Context;

    move-result-object v0

    if-eqz v0, :cond_0

    return-object v0

    :cond_0
    new-instance v0, Ljava/lang/IllegalStateException;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "Fragment "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p0, " not attached to a context."

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public fLidf()V
    .locals 1

    iget-object v0, p0, Landroidx/fragment/app/Fragment;->CqaNbM:Landroidx/fragment/app/Fragment$wA;

    if-eqz v0, :cond_1

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->lgHUyS()Landroidx/fragment/app/Fragment$wA;

    move-result-object v0

    iget-boolean v0, v0, Landroidx/fragment/app/Fragment$wA;->Pq:Z

    if-nez v0, :cond_0

    goto :goto_0

    :cond_0
    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->lgHUyS()Landroidx/fragment/app/Fragment$wA;

    move-result-object p0

    const/4 v0, 0x0

    iput-boolean v0, p0, Landroidx/fragment/app/Fragment$wA;->Pq:Z

    :cond_1
    :goto_0
    return-void
.end method

.method public fehf()Lo/M6;
    .locals 1

    iget-object p0, p0, Landroidx/fragment/app/Fragment;->CqaNbM:Landroidx/fragment/app/Fragment$wA;

    const/4 v0, 0x0

    if-nez p0, :cond_0

    return-object v0

    :cond_0
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    return-object v0
.end method

.method public gYa()V
    .locals 2

    iget-object v0, p0, Landroidx/fragment/app/Fragment;->mByQ:Landroid/view/View;

    iget-object v1, p0, Landroidx/fragment/app/Fragment;->AZxh:Landroid/os/Bundle;

    invoke-virtual {p0, v0, v1}, Landroidx/fragment/app/Fragment;->tQ(Landroid/view/View;Landroid/os/Bundle;)V

    iget-object p0, p0, Landroidx/fragment/app/Fragment;->IEE:Landroidx/fragment/app/KLFTb;

    invoke-virtual {p0}, Landroidx/fragment/app/KLFTb;->OjSQV()V

    return-void
.end method

.method public giT(Landroidx/fragment/app/Fragment$ZfxDd;)V
    .locals 2

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->lgHUyS()Landroidx/fragment/app/Fragment$wA;

    iget-object v0, p0, Landroidx/fragment/app/Fragment;->CqaNbM:Landroidx/fragment/app/Fragment$wA;

    iget-object v1, v0, Landroidx/fragment/app/Fragment$wA;->diqgf:Landroidx/fragment/app/Fragment$ZfxDd;

    if-ne p1, v1, :cond_0

    return-void

    :cond_0
    if-eqz p1, :cond_2

    if-nez v1, :cond_1

    goto :goto_0

    :cond_1
    new-instance p1, Ljava/lang/IllegalStateException;

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "Trying to set a replacement startPostponedEnterTransition on "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {p1, p0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_2
    :goto_0
    iget-boolean p0, v0, Landroidx/fragment/app/Fragment$wA;->Pq:Z

    if-eqz p0, :cond_3

    iput-object p1, v0, Landroidx/fragment/app/Fragment$wA;->diqgf:Landroidx/fragment/app/Fragment$ZfxDd;

    :cond_3
    if-eqz p1, :cond_4

    invoke-interface {p1}, Landroidx/fragment/app/Fragment$ZfxDd;->mjFkc()V

    :cond_4
    return-void
.end method

.method public gtIJp()V
    .locals 2

    iget-object v0, p0, Landroidx/fragment/app/Fragment;->fehf:Landroidx/fragment/app/KLFTb;

    invoke-virtual {v0, p0}, Landroidx/fragment/app/KLFTb;->yfx(Landroidx/fragment/app/Fragment;)Z

    move-result v0

    iget-object v1, p0, Landroidx/fragment/app/Fragment;->qdMbNW:Ljava/lang/Boolean;

    if-eqz v1, :cond_0

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    if-eq v1, v0, :cond_1

    :cond_0
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v1

    iput-object v1, p0, Landroidx/fragment/app/Fragment;->qdMbNW:Ljava/lang/Boolean;

    invoke-virtual {p0, v0}, Landroidx/fragment/app/Fragment;->jm(Z)V

    iget-object p0, p0, Landroidx/fragment/app/Fragment;->IEE:Landroidx/fragment/app/KLFTb;

    invoke-virtual {p0}, Landroidx/fragment/app/KLFTb;->VocHEe()V

    :cond_1
    return-void
.end method

.method public gtr(Ljava/util/ArrayList;Ljava/util/ArrayList;)V
    .locals 0

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->lgHUyS()Landroidx/fragment/app/Fragment$wA;

    iget-object p0, p0, Landroidx/fragment/app/Fragment;->CqaNbM:Landroidx/fragment/app/Fragment$wA;

    iput-object p1, p0, Landroidx/fragment/app/Fragment$wA;->xJ:Ljava/util/ArrayList;

    iput-object p2, p0, Landroidx/fragment/app/Fragment$wA;->lgHUyS:Ljava/util/ArrayList;

    return-void
.end method

.method public final hashCode()I
    .locals 0

    invoke-super {p0}, Ljava/lang/Object;->hashCode()I

    move-result p0

    return p0
.end method

.method public final huTpC()I
    .locals 2

    iget-object v0, p0, Landroidx/fragment/app/Fragment;->NPj:Landroidx/lifecycle/wA$AZxh;

    sget-object v1, Landroidx/lifecycle/wA$AZxh;->AZxh:Landroidx/lifecycle/wA$AZxh;

    if-eq v0, v1, :cond_1

    iget-object v1, p0, Landroidx/fragment/app/Fragment;->Pq:Landroidx/fragment/app/Fragment;

    if-nez v1, :cond_0

    goto :goto_0

    :cond_0
    invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I

    move-result v0

    iget-object p0, p0, Landroidx/fragment/app/Fragment;->Pq:Landroidx/fragment/app/Fragment;

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->huTpC()I

    move-result p0

    invoke-static {v0, p0}, Ljava/lang/Math;->min(II)I

    move-result p0

    return p0

    :cond_1
    :goto_0
    invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I

    move-result p0

    return p0
.end method

.method public jm(Z)V
    .locals 0

    return-void
.end method

.method public final jx(Landroid/os/Bundle;)V
    .locals 3

    iget-object v0, p0, Landroidx/fragment/app/Fragment;->wA:Landroid/util/SparseArray;

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    iget-object v2, p0, Landroidx/fragment/app/Fragment;->mByQ:Landroid/view/View;

    invoke-virtual {v2, v0}, Landroid/view/View;->restoreHierarchyState(Landroid/util/SparseArray;)V

    iput-object v1, p0, Landroidx/fragment/app/Fragment;->wA:Landroid/util/SparseArray;

    :cond_0
    iget-object v0, p0, Landroidx/fragment/app/Fragment;->mByQ:Landroid/view/View;

    if-eqz v0, :cond_1

    iget-object v0, p0, Landroidx/fragment/app/Fragment;->oCFDzJ:Lo/BEUaYa;

    iget-object v2, p0, Landroidx/fragment/app/Fragment;->ZfxDd:Landroid/os/Bundle;

    invoke-virtual {v0, v2}, Lo/BEUaYa;->xJ(Landroid/os/Bundle;)V

    iput-object v1, p0, Landroidx/fragment/app/Fragment;->ZfxDd:Landroid/os/Bundle;

    :cond_1
    const/4 v0, 0x0

    iput-boolean v0, p0, Landroidx/fragment/app/Fragment;->lB:Z

    invoke-virtual {p0, p1}, Landroidx/fragment/app/Fragment;->yfx(Landroid/os/Bundle;)V

    iget-boolean p1, p0, Landroidx/fragment/app/Fragment;->lB:Z

    if-eqz p1, :cond_3

    iget-object p1, p0, Landroidx/fragment/app/Fragment;->mByQ:Landroid/view/View;

    if-eqz p1, :cond_2

    iget-object p0, p0, Landroidx/fragment/app/Fragment;->oCFDzJ:Lo/BEUaYa;

    sget-object p1, Landroidx/lifecycle/wA$mjFkc;->ON_CREATE:Landroidx/lifecycle/wA$mjFkc;

    invoke-virtual {p0, p1}, Lo/BEUaYa;->AZxh(Landroidx/lifecycle/wA$mjFkc;)V

    :cond_2
    return-void

    :cond_3
    new-instance p1, Lo/s7;

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "Fragment "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p0, " did not call through to super.onViewStateRestored()"

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {p1, p0}, Lo/s7;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public kism()V
    .locals 3

    iget-object v0, p0, Landroidx/fragment/app/Fragment;->IEE:Landroidx/fragment/app/KLFTb;

    invoke-virtual {v0}, Landroidx/fragment/app/KLFTb;->NKyg()V

    iget-object v0, p0, Landroidx/fragment/app/Fragment;->IEE:Landroidx/fragment/app/KLFTb;

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroidx/fragment/app/KLFTb;->zvd(Z)Z

    const/4 v0, 0x7

    iput v0, p0, Landroidx/fragment/app/Fragment;->mjFkc:I

    const/4 v0, 0x0

    iput-boolean v0, p0, Landroidx/fragment/app/Fragment;->lB:Z

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->ANMGZc()V

    iget-boolean v0, p0, Landroidx/fragment/app/Fragment;->lB:Z

    if-eqz v0, :cond_1

    iget-object v0, p0, Landroidx/fragment/app/Fragment;->vadzgd:Landroidx/lifecycle/JHa;

    sget-object v1, Landroidx/lifecycle/wA$mjFkc;->ON_RESUME:Landroidx/lifecycle/wA$mjFkc;

    invoke-virtual {v0, v1}, Landroidx/lifecycle/JHa;->lgHUyS(Landroidx/lifecycle/wA$mjFkc;)V

    iget-object v0, p0, Landroidx/fragment/app/Fragment;->mByQ:Landroid/view/View;

    if-eqz v0, :cond_0

    iget-object v0, p0, Landroidx/fragment/app/Fragment;->oCFDzJ:Lo/BEUaYa;

    invoke-virtual {v0, v1}, Lo/BEUaYa;->AZxh(Landroidx/lifecycle/wA$mjFkc;)V

    :cond_0
    iget-object p0, p0, Landroidx/fragment/app/Fragment;->IEE:Landroidx/fragment/app/KLFTb;

    invoke-virtual {p0}, Landroidx/fragment/app/KLFTb;->BAnRFn()V

    return-void

    :cond_1
    new-instance v0, Lo/s7;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "Fragment "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p0, " did not call through to super.onResume()"

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Lo/s7;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public lB()I
    .locals 0

    iget-object p0, p0, Landroidx/fragment/app/Fragment;->CqaNbM:Landroidx/fragment/app/Fragment$wA;

    if-nez p0, :cond_0

    const/4 p0, 0x0

    return p0

    :cond_0
    iget p0, p0, Landroidx/fragment/app/Fragment$wA;->KLFTb:I

    return p0
.end method

.method public final lgHUyS()Landroidx/fragment/app/Fragment$wA;
    .locals 1

    iget-object v0, p0, Landroidx/fragment/app/Fragment;->CqaNbM:Landroidx/fragment/app/Fragment$wA;

    if-nez v0, :cond_0

    new-instance v0, Landroidx/fragment/app/Fragment$wA;

    invoke-direct {v0}, Landroidx/fragment/app/Fragment$wA;-><init>()V

    iput-object v0, p0, Landroidx/fragment/app/Fragment;->CqaNbM:Landroidx/fragment/app/Fragment$wA;

    :cond_0
    iget-object p0, p0, Landroidx/fragment/app/Fragment;->CqaNbM:Landroidx/fragment/app/Fragment$wA;

    return-object p0
.end method

.method public lti(I)V
    .locals 1

    iget-object v0, p0, Landroidx/fragment/app/Fragment;->CqaNbM:Landroidx/fragment/app/Fragment$wA;

    if-nez v0, :cond_0

    if-nez p1, :cond_0

    return-void

    :cond_0
    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->lgHUyS()Landroidx/fragment/app/Fragment$wA;

    iget-object p0, p0, Landroidx/fragment/app/Fragment;->CqaNbM:Landroidx/fragment/app/Fragment$wA;

    iput p1, p0, Landroidx/fragment/app/Fragment$wA;->JHa:I

    return-void
.end method

.method public mByQ()Ljava/lang/Object;
    .locals 2

    iget-object v0, p0, Landroidx/fragment/app/Fragment;->CqaNbM:Landroidx/fragment/app/Fragment$wA;

    if-nez v0, :cond_0

    const/4 p0, 0x0

    return-object p0

    :cond_0
    iget-object v0, v0, Landroidx/fragment/app/Fragment$wA;->VA:Ljava/lang/Object;

    sget-object v1, Landroidx/fragment/app/Fragment;->JYgkl:Ljava/lang/Object;

    if-ne v0, v1, :cond_1

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->Pq()Ljava/lang/Object;

    move-result-object v0

    :cond_1
    return-object v0
.end method

.method public final mjFkc()Landroidx/savedstate/mjFkc;
    .locals 0

    iget-object p0, p0, Landroidx/fragment/app/Fragment;->KRTLGT:Lo/m6;

    invoke-virtual {p0}, Lo/m6;->AZxh()Landroidx/savedstate/mjFkc;

    move-result-object p0

    return-object p0
.end method

.method public nxI(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Landroid/os/Bundle;)Landroid/view/View;
    .locals 0

    iget p0, p0, Landroidx/fragment/app/Fragment;->GMIER:I

    if-eqz p0, :cond_0

    const/4 p3, 0x0

    invoke-virtual {p1, p0, p2, p3}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object p0

    return-object p0

    :cond_0
    const/4 p0, 0x0

    return-object p0
.end method

.method public final oCFDzJ()Z
    .locals 0

    iget p0, p0, Landroidx/fragment/app/Fragment;->qGY:I

    if-lez p0, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method

.method public onConfigurationChanged(Landroid/content/res/Configuration;)V
    .locals 0

    const/4 p1, 0x1

    iput-boolean p1, p0, Landroidx/fragment/app/Fragment;->lB:Z

    return-void
.end method

.method public onCreateContextMenu(Landroid/view/ContextMenu;Landroid/view/View;Landroid/view/ContextMenu$ContextMenuInfo;)V
    .locals 0

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->LREOK()Lo/RnaHj;

    const/4 p0, 0x0

    throw p0
.end method

.method public onLowMemory()V
    .locals 1

    const/4 v0, 0x1

    iput-boolean v0, p0, Landroidx/fragment/app/Fragment;->lB:Z

    return-void
.end method

.method public qGY()Ljava/lang/Object;
    .locals 0

    iget-object p0, p0, Landroidx/fragment/app/Fragment;->CqaNbM:Landroidx/fragment/app/Fragment$wA;

    if-nez p0, :cond_0

    const/4 p0, 0x0

    return-object p0

    :cond_0
    iget-object p0, p0, Landroidx/fragment/app/Fragment$wA;->qdMbNW:Ljava/lang/Object;

    return-object p0
.end method

.method public final qdMbNW()Lo/RnaHj;
    .locals 0

    const/4 p0, 0x0

    return-object p0
.end method

.method public rWxwaT()Landroid/view/View;
    .locals 0

    iget-object p0, p0, Landroidx/fragment/app/Fragment;->mByQ:Landroid/view/View;

    return-object p0
.end method

.method public rkYL()I
    .locals 0

    iget-object p0, p0, Landroidx/fragment/app/Fragment;->CqaNbM:Landroidx/fragment/app/Fragment$wA;

    if-nez p0, :cond_0

    const/4 p0, 0x0

    return p0

    :cond_0
    iget p0, p0, Landroidx/fragment/app/Fragment$wA;->AZxh:I

    return p0
.end method

.method public sRqPfw(Z)V
    .locals 1

    iget-object v0, p0, Landroidx/fragment/app/Fragment;->CqaNbM:Landroidx/fragment/app/Fragment$wA;

    if-nez v0, :cond_0

    return-void

    :cond_0
    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->lgHUyS()Landroidx/fragment/app/Fragment$wA;

    move-result-object p0

    iput-boolean p1, p0, Landroidx/fragment/app/Fragment$wA;->mjFkc:Z

    return-void
.end method

.method public startActivityForResult(Landroid/content/Intent;I)V
    .locals 1

    const/4 v0, 0x0

    invoke-virtual {p0, p1, p2, v0}, Landroidx/fragment/app/Fragment;->Dp(Landroid/content/Intent;ILandroid/os/Bundle;)V

    return-void
.end method

.method public tISON(Landroid/os/Bundle;)V
    .locals 1

    iget-object v0, p0, Landroidx/fragment/app/Fragment;->fehf:Landroidx/fragment/app/KLFTb;

    if-eqz v0, :cond_1

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->GMIER()Z

    move-result v0

    if-nez v0, :cond_0

    goto :goto_0

    :cond_0
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string p1, "Fragment already added and state has been saved"

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_1
    :goto_0
    iput-object p1, p0, Landroidx/fragment/app/Fragment;->JHa:Landroid/os/Bundle;

    return-void
.end method

.method public tQ(Landroid/view/View;Landroid/os/Bundle;)V
    .locals 0

    return-void
.end method

.method public tjSezt()V
    .locals 3

    iget-object v0, p0, Landroidx/fragment/app/Fragment;->IEE:Landroidx/fragment/app/KLFTb;

    invoke-virtual {v0}, Landroidx/fragment/app/KLFTb;->NKyg()V

    iget-object v0, p0, Landroidx/fragment/app/Fragment;->IEE:Landroidx/fragment/app/KLFTb;

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroidx/fragment/app/KLFTb;->zvd(Z)Z

    const/4 v0, 0x5

    iput v0, p0, Landroidx/fragment/app/Fragment;->mjFkc:I

    const/4 v0, 0x0

    iput-boolean v0, p0, Landroidx/fragment/app/Fragment;->lB:Z

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->alEkx()V

    iget-boolean v0, p0, Landroidx/fragment/app/Fragment;->lB:Z

    if-eqz v0, :cond_1

    iget-object v0, p0, Landroidx/fragment/app/Fragment;->vadzgd:Landroidx/lifecycle/JHa;

    sget-object v1, Landroidx/lifecycle/wA$mjFkc;->ON_START:Landroidx/lifecycle/wA$mjFkc;

    invoke-virtual {v0, v1}, Landroidx/lifecycle/JHa;->lgHUyS(Landroidx/lifecycle/wA$mjFkc;)V

    iget-object v0, p0, Landroidx/fragment/app/Fragment;->mByQ:Landroid/view/View;

    if-eqz v0, :cond_0

    iget-object v0, p0, Landroidx/fragment/app/Fragment;->oCFDzJ:Lo/BEUaYa;

    invoke-virtual {v0, v1}, Lo/BEUaYa;->AZxh(Landroidx/lifecycle/wA$mjFkc;)V

    :cond_0
    iget-object p0, p0, Landroidx/fragment/app/Fragment;->IEE:Landroidx/fragment/app/KLFTb;

    invoke-virtual {p0}, Landroidx/fragment/app/KLFTb;->lB()V

    return-void

    :cond_1
    new-instance v0, Lo/s7;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "Fragment "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p0, " did not call through to super.onStart()"

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Lo/s7;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public toString()Ljava/lang/String;
    .locals 2

    new-instance v0, Ljava/lang/StringBuilder;

    const/16 v1, 0x80

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(I)V

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "{"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {p0}, Ljava/lang/System;->identityHashCode(Ljava/lang/Object;)I

    move-result v1

    invoke-static {v1}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "}"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, " ("

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Landroidx/fragment/app/Fragment;->KLFTb:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, Landroidx/fragment/app/Fragment;->diqgf:I

    if-eqz v1, :cond_0

    const-string v1, " id=0x"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, Landroidx/fragment/app/Fragment;->diqgf:I

    invoke-static {v1}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_0
    iget-object v1, p0, Landroidx/fragment/app/Fragment;->Ucbh:Ljava/lang/String;

    if-eqz v1, :cond_1

    const-string v1, " tag="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object p0, p0, Landroidx/fragment/app/Fragment;->Ucbh:Ljava/lang/String;

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_1
    const-string p0, ")"

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public uH(IIII)V
    .locals 1

    iget-object v0, p0, Landroidx/fragment/app/Fragment;->CqaNbM:Landroidx/fragment/app/Fragment$wA;

    if-nez v0, :cond_0

    if-nez p1, :cond_0

    if-nez p2, :cond_0

    if-nez p3, :cond_0

    if-nez p4, :cond_0

    return-void

    :cond_0
    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->lgHUyS()Landroidx/fragment/app/Fragment$wA;

    move-result-object v0

    iput p1, v0, Landroidx/fragment/app/Fragment$wA;->AZxh:I

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->lgHUyS()Landroidx/fragment/app/Fragment$wA;

    move-result-object p1

    iput p2, p1, Landroidx/fragment/app/Fragment$wA;->wA:I

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->lgHUyS()Landroidx/fragment/app/Fragment$wA;

    move-result-object p1

    iput p3, p1, Landroidx/fragment/app/Fragment$wA;->ZfxDd:I

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->lgHUyS()Landroidx/fragment/app/Fragment$wA;

    move-result-object p0

    iput p4, p0, Landroidx/fragment/app/Fragment$wA;->KLFTb:I

    return-void
.end method

.method public uHVRx(Landroid/os/Bundle;)V
    .locals 0

    const/4 p1, 0x1

    iput-boolean p1, p0, Landroidx/fragment/app/Fragment;->lB:Z

    return-void
.end method

.method public final vI()Landroidx/fragment/app/KLFTb;
    .locals 3

    iget-object v0, p0, Landroidx/fragment/app/Fragment;->fehf:Landroidx/fragment/app/KLFTb;

    if-eqz v0, :cond_0

    return-object v0

    :cond_0
    new-instance v0, Ljava/lang/IllegalStateException;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "Fragment "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p0, " not associated with a fragment manager."

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public vadzgd()V
    .locals 3

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->NPj()V

    invoke-static {}, Ljava/util/UUID;->randomUUID()Ljava/util/UUID;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/UUID;->toString()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Landroidx/fragment/app/Fragment;->KLFTb:Ljava/lang/String;

    const/4 v0, 0x0

    iput-boolean v0, p0, Landroidx/fragment/app/Fragment;->Dt:Z

    iput-boolean v0, p0, Landroidx/fragment/app/Fragment;->ETF:Z

    iput-boolean v0, p0, Landroidx/fragment/app/Fragment;->VA:Z

    iput-boolean v0, p0, Landroidx/fragment/app/Fragment;->MiMN:Z

    iput-boolean v0, p0, Landroidx/fragment/app/Fragment;->YoKzxo:Z

    iput v0, p0, Landroidx/fragment/app/Fragment;->qGY:I

    const/4 v1, 0x0

    iput-object v1, p0, Landroidx/fragment/app/Fragment;->fehf:Landroidx/fragment/app/KLFTb;

    new-instance v2, Lo/RleMQT;

    invoke-direct {v2}, Lo/RleMQT;-><init>()V

    iput-object v2, p0, Landroidx/fragment/app/Fragment;->IEE:Landroidx/fragment/app/KLFTb;

    iput v0, p0, Landroidx/fragment/app/Fragment;->diqgf:I

    iput v0, p0, Landroidx/fragment/app/Fragment;->eyqo:I

    iput-object v1, p0, Landroidx/fragment/app/Fragment;->Ucbh:Ljava/lang/String;

    iput-boolean v0, p0, Landroidx/fragment/app/Fragment;->huTpC:Z

    iput-boolean v0, p0, Landroidx/fragment/app/Fragment;->Gd:Z

    return-void
.end method

.method public vjlshU(Landroid/os/Bundle;)V
    .locals 2

    iget-object v0, p0, Landroidx/fragment/app/Fragment;->IEE:Landroidx/fragment/app/KLFTb;

    invoke-virtual {v0}, Landroidx/fragment/app/KLFTb;->NKyg()V

    const/4 v0, 0x3

    iput v0, p0, Landroidx/fragment/app/Fragment;->mjFkc:I

    const/4 v0, 0x0

    iput-boolean v0, p0, Landroidx/fragment/app/Fragment;->lB:Z

    invoke-virtual {p0, p1}, Landroidx/fragment/app/Fragment;->uHVRx(Landroid/os/Bundle;)V

    iget-boolean p1, p0, Landroidx/fragment/app/Fragment;->lB:Z

    if-eqz p1, :cond_0

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->XtE()V

    iget-object p0, p0, Landroidx/fragment/app/Fragment;->IEE:Landroidx/fragment/app/KLFTb;

    invoke-virtual {p0}, Landroidx/fragment/app/KLFTb;->eyqo()V

    return-void

    :cond_0
    new-instance p1, Lo/s7;

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "Fragment "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p0, " did not call through to super.onActivityCreated()"

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {p1, p0}, Lo/s7;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public wA()Lo/ia;
    .locals 2

    iget-object v0, p0, Landroidx/fragment/app/Fragment;->fehf:Landroidx/fragment/app/KLFTb;

    if-eqz v0, :cond_1

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->huTpC()I

    move-result v0

    sget-object v1, Landroidx/lifecycle/wA$AZxh;->AZxh:Landroidx/lifecycle/wA$AZxh;

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    if-eq v0, v1, :cond_0

    iget-object v0, p0, Landroidx/fragment/app/Fragment;->fehf:Landroidx/fragment/app/KLFTb;

    invoke-virtual {v0, p0}, Landroidx/fragment/app/KLFTb;->Vdz(Landroidx/fragment/app/Fragment;)Lo/ia;

    move-result-object p0

    return-object p0

    :cond_0
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string v0, "Calling getViewModelStore() before a Fragment reaches onCreate() when using setMaxLifecycle(INITIALIZED) is not supported"

    invoke-direct {p0, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_1
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string v0, "Can\'t access ViewModels from detached fragment"

    invoke-direct {p0, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public wJVbdd()F
    .locals 0

    iget-object p0, p0, Landroidx/fragment/app/Fragment;->CqaNbM:Landroidx/fragment/app/Fragment$wA;

    if-nez p0, :cond_0

    const/high16 p0, 0x3f800000    # 1.0f

    return p0

    :cond_0
    iget p0, p0, Landroidx/fragment/app/Fragment$wA;->fehf:F

    return p0
.end method

.method public xJ()Lo/jeHSg;
    .locals 1

    new-instance v0, Landroidx/fragment/app/Fragment$AZxh;

    invoke-direct {v0, p0}, Landroidx/fragment/app/Fragment$AZxh;-><init>(Landroidx/fragment/app/Fragment;)V

    return-object v0
.end method

.method public xROA()V
    .locals 3

    iget-object v0, p0, Landroidx/fragment/app/Fragment;->JYn:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v2, 0x0

    if-eqz v1, :cond_0

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p0

    invoke-static {p0}, Lo/w7;->mjFkc(Ljava/lang/Object;)V

    throw v2

    :cond_0
    iget-object v0, p0, Landroidx/fragment/app/Fragment;->JYn:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    iget-object v0, p0, Landroidx/fragment/app/Fragment;->IEE:Landroidx/fragment/app/KLFTb;

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->xJ()Lo/jeHSg;

    move-result-object v1

    invoke-virtual {v0, v2, v1, p0}, Landroidx/fragment/app/KLFTb;->lgHUyS(Lo/aAlqX;Lo/jeHSg;Landroidx/fragment/app/Fragment;)V

    const/4 v0, 0x0

    iput v0, p0, Landroidx/fragment/app/Fragment;->mjFkc:I

    iput-boolean v0, p0, Landroidx/fragment/app/Fragment;->lB:Z

    throw v2
.end method

.method public xrEuO()Ljava/lang/Object;
    .locals 2

    iget-object v0, p0, Landroidx/fragment/app/Fragment;->CqaNbM:Landroidx/fragment/app/Fragment$wA;

    if-nez v0, :cond_0

    const/4 p0, 0x0

    return-object p0

    :cond_0
    iget-object v0, v0, Landroidx/fragment/app/Fragment$wA;->YoKzxo:Ljava/lang/Object;

    sget-object v1, Landroidx/fragment/app/Fragment;->JYgkl:Ljava/lang/Object;

    if-ne v0, v1, :cond_1

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->CqaNbM()Ljava/lang/Object;

    move-result-object v0

    :cond_1
    return-object v0
.end method

.method public yX()V
    .locals 3

    iget-object v0, p0, Landroidx/fragment/app/Fragment;->IEE:Landroidx/fragment/app/KLFTb;

    invoke-virtual {v0}, Landroidx/fragment/app/KLFTb;->mByQ()V

    iget-object v0, p0, Landroidx/fragment/app/Fragment;->mByQ:Landroid/view/View;

    if-eqz v0, :cond_0

    iget-object v0, p0, Landroidx/fragment/app/Fragment;->oCFDzJ:Lo/BEUaYa;

    sget-object v1, Landroidx/lifecycle/wA$mjFkc;->ON_STOP:Landroidx/lifecycle/wA$mjFkc;

    invoke-virtual {v0, v1}, Lo/BEUaYa;->AZxh(Landroidx/lifecycle/wA$mjFkc;)V

    :cond_0
    iget-object v0, p0, Landroidx/fragment/app/Fragment;->vadzgd:Landroidx/lifecycle/JHa;

    sget-object v1, Landroidx/lifecycle/wA$mjFkc;->ON_STOP:Landroidx/lifecycle/wA$mjFkc;

    invoke-virtual {v0, v1}, Landroidx/lifecycle/JHa;->lgHUyS(Landroidx/lifecycle/wA$mjFkc;)V

    const/4 v0, 0x4

    iput v0, p0, Landroidx/fragment/app/Fragment;->mjFkc:I

    const/4 v0, 0x0

    iput-boolean v0, p0, Landroidx/fragment/app/Fragment;->lB:Z

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->dm()V

    iget-boolean v0, p0, Landroidx/fragment/app/Fragment;->lB:Z

    if-eqz v0, :cond_1

    return-void

    :cond_1
    new-instance v0, Lo/s7;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "Fragment "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p0, " did not call through to super.onStop()"

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Lo/s7;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public yfx(Landroid/os/Bundle;)V
    .locals 0

    const/4 p1, 0x1

    iput-boolean p1, p0, Landroidx/fragment/app/Fragment;->lB:Z

    return-void
.end method

.method public zvd()Ljava/util/ArrayList;
    .locals 0

    iget-object p0, p0, Landroidx/fragment/app/Fragment;->CqaNbM:Landroidx/fragment/app/Fragment$wA;

    if-eqz p0, :cond_1

    iget-object p0, p0, Landroidx/fragment/app/Fragment$wA;->lgHUyS:Ljava/util/ArrayList;

    if-nez p0, :cond_0

    goto :goto_0

    :cond_0
    return-object p0

    :cond_1
    :goto_0
    new-instance p0, Ljava/util/ArrayList;

    invoke-direct {p0}, Ljava/util/ArrayList;-><init>()V

    return-object p0
.end method
