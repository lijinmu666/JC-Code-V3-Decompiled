.class public Landroidx/fragment/app/wA$JHa;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lo/BxruE$mjFkc;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Landroidx/fragment/app/wA;->Ucbh(Ljava/util/List;Ljava/util/List;ZLjava/util/Map;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic AZxh:Landroid/view/ViewGroup;

.field public final synthetic ZfxDd:Landroidx/fragment/app/wA;

.field public final synthetic mjFkc:Landroid/view/View;

.field public final synthetic wA:Landroidx/fragment/app/wA$ETF;


# direct methods
.method public constructor <init>(Landroidx/fragment/app/wA;Landroid/view/View;Landroid/view/ViewGroup;Landroidx/fragment/app/wA$ETF;)V
    .locals 0

    iput-object p1, p0, Landroidx/fragment/app/wA$JHa;->ZfxDd:Landroidx/fragment/app/wA;

    iput-object p2, p0, Landroidx/fragment/app/wA$JHa;->mjFkc:Landroid/view/View;

    iput-object p3, p0, Landroidx/fragment/app/wA$JHa;->AZxh:Landroid/view/ViewGroup;

    iput-object p4, p0, Landroidx/fragment/app/wA$JHa;->wA:Landroidx/fragment/app/wA$ETF;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public mjFkc()V
    .locals 2

    iget-object v0, p0, Landroidx/fragment/app/wA$JHa;->mjFkc:Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->clearAnimation()V

    iget-object v0, p0, Landroidx/fragment/app/wA$JHa;->AZxh:Landroid/view/ViewGroup;

    iget-object v1, p0, Landroidx/fragment/app/wA$JHa;->mjFkc:Landroid/view/View;

    invoke-virtual {v0, v1}, Landroid/view/ViewGroup;->endViewTransition(Landroid/view/View;)V

    iget-object p0, p0, Landroidx/fragment/app/wA$JHa;->wA:Landroidx/fragment/app/wA$ETF;

    invoke-virtual {p0}, Landroidx/fragment/app/wA$VA;->mjFkc()V

    return-void
.end method
