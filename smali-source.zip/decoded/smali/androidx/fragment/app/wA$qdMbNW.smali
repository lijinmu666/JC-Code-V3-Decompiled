.class public Landroidx/fragment/app/wA$qdMbNW;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Landroidx/fragment/app/wA;->huTpC(Ljava/util/List;Ljava/util/List;ZLandroidx/fragment/app/Dt$KLFTb;Landroidx/fragment/app/Dt$KLFTb;)Ljava/util/Map;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic AZxh:Landroidx/fragment/app/wA;

.field public final synthetic mjFkc:Ljava/util/ArrayList;


# direct methods
.method public constructor <init>(Landroidx/fragment/app/wA;Ljava/util/ArrayList;)V
    .locals 0

    iput-object p1, p0, Landroidx/fragment/app/wA$qdMbNW;->AZxh:Landroidx/fragment/app/wA;

    iput-object p2, p0, Landroidx/fragment/app/wA$qdMbNW;->mjFkc:Ljava/util/ArrayList;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 1

    iget-object p0, p0, Landroidx/fragment/app/wA$qdMbNW;->mjFkc:Ljava/util/ArrayList;

    const/4 v0, 0x4

    invoke-static {p0, v0}, Landroidx/fragment/app/qdMbNW;->ZfxDd(Ljava/util/ArrayList;I)V

    return-void
.end method
