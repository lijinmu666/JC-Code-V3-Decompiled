.class public Landroidx/fragment/app/xJ$mjFkc;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnAttachStateChangeListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Landroidx/fragment/app/xJ;->JHa()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic AZxh:Landroidx/fragment/app/xJ;

.field public final synthetic mjFkc:Landroid/view/View;


# direct methods
.method public constructor <init>(Landroidx/fragment/app/xJ;Landroid/view/View;)V
    .locals 0

    iput-object p1, p0, Landroidx/fragment/app/xJ$mjFkc;->AZxh:Landroidx/fragment/app/xJ;

    iput-object p2, p0, Landroidx/fragment/app/xJ$mjFkc;->mjFkc:Landroid/view/View;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onViewAttachedToWindow(Landroid/view/View;)V
    .locals 0

    iget-object p1, p0, Landroidx/fragment/app/xJ$mjFkc;->mjFkc:Landroid/view/View;

    invoke-virtual {p1, p0}, Landroid/view/View;->removeOnAttachStateChangeListener(Landroid/view/View$OnAttachStateChangeListener;)V

    iget-object p0, p0, Landroidx/fragment/app/xJ$mjFkc;->mjFkc:Landroid/view/View;

    invoke-static {p0}, Lo/T9;->Vdz(Landroid/view/View;)V

    return-void
.end method

.method public onViewDetachedFromWindow(Landroid/view/View;)V
    .locals 0

    return-void
.end method
