.class public abstract Landroidx/fragment/app/wA$VA;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/fragment/app/wA;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "VA"
.end annotation


# instance fields
.field public final AZxh:Lo/BxruE;

.field public final mjFkc:Landroidx/fragment/app/Dt$KLFTb;


# direct methods
.method public constructor <init>(Landroidx/fragment/app/Dt$KLFTb;Lo/BxruE;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/fragment/app/wA$VA;->mjFkc:Landroidx/fragment/app/Dt$KLFTb;

    iput-object p2, p0, Landroidx/fragment/app/wA$VA;->AZxh:Lo/BxruE;

    return-void
.end method


# virtual methods
.method public AZxh()Landroidx/fragment/app/Dt$KLFTb;
    .locals 0

    iget-object p0, p0, Landroidx/fragment/app/wA$VA;->mjFkc:Landroidx/fragment/app/Dt$KLFTb;

    return-object p0
.end method

.method public ZfxDd()Z
    .locals 2

    iget-object v0, p0, Landroidx/fragment/app/wA$VA;->mjFkc:Landroidx/fragment/app/Dt$KLFTb;

    invoke-virtual {v0}, Landroidx/fragment/app/Dt$KLFTb;->JHa()Landroidx/fragment/app/Fragment;

    move-result-object v0

    iget-object v0, v0, Landroidx/fragment/app/Fragment;->mByQ:Landroid/view/View;

    invoke-static {v0}, Landroidx/fragment/app/Dt$KLFTb$wA;->qdMbNW(Landroid/view/View;)Landroidx/fragment/app/Dt$KLFTb$wA;

    move-result-object v0

    iget-object p0, p0, Landroidx/fragment/app/wA$VA;->mjFkc:Landroidx/fragment/app/Dt$KLFTb;

    invoke-virtual {p0}, Landroidx/fragment/app/Dt$KLFTb;->KLFTb()Landroidx/fragment/app/Dt$KLFTb$wA;

    move-result-object p0

    if-eq v0, p0, :cond_1

    sget-object v1, Landroidx/fragment/app/Dt$KLFTb$wA;->AZxh:Landroidx/fragment/app/Dt$KLFTb$wA;

    if-eq v0, v1, :cond_0

    if-eq p0, v1, :cond_0

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    goto :goto_1

    :cond_1
    :goto_0
    const/4 p0, 0x1

    :goto_1
    return p0
.end method

.method public mjFkc()V
    .locals 1

    iget-object v0, p0, Landroidx/fragment/app/wA$VA;->mjFkc:Landroidx/fragment/app/Dt$KLFTb;

    iget-object p0, p0, Landroidx/fragment/app/wA$VA;->AZxh:Lo/BxruE;

    invoke-virtual {v0, p0}, Landroidx/fragment/app/Dt$KLFTb;->ZfxDd(Lo/BxruE;)V

    return-void
.end method

.method public wA()Lo/BxruE;
    .locals 0

    iget-object p0, p0, Landroidx/fragment/app/wA$VA;->AZxh:Lo/BxruE;

    return-object p0
.end method
