.class public abstract Landroidx/fragment/app/Dt$KLFTb;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/fragment/app/Dt;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "KLFTb"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/fragment/app/Dt$KLFTb$AZxh;,
        Landroidx/fragment/app/Dt$KLFTb$wA;
    }
.end annotation


# instance fields
.field public AZxh:Landroidx/fragment/app/Dt$KLFTb$AZxh;

.field public JHa:Z

.field public final KLFTb:Ljava/util/HashSet;

.field public final ZfxDd:Ljava/util/List;

.field public mjFkc:Landroidx/fragment/app/Dt$KLFTb$wA;

.field public final wA:Landroidx/fragment/app/Fragment;

.field public xJ:Z


# direct methods
.method public constructor <init>(Landroidx/fragment/app/Dt$KLFTb$wA;Landroidx/fragment/app/Dt$KLFTb$AZxh;Landroidx/fragment/app/Fragment;Lo/BxruE;)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Landroidx/fragment/app/Dt$KLFTb;->ZfxDd:Ljava/util/List;

    new-instance v0, Ljava/util/HashSet;

    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    iput-object v0, p0, Landroidx/fragment/app/Dt$KLFTb;->KLFTb:Ljava/util/HashSet;

    const/4 v0, 0x0

    iput-boolean v0, p0, Landroidx/fragment/app/Dt$KLFTb;->JHa:Z

    iput-boolean v0, p0, Landroidx/fragment/app/Dt$KLFTb;->xJ:Z

    iput-object p1, p0, Landroidx/fragment/app/Dt$KLFTb;->mjFkc:Landroidx/fragment/app/Dt$KLFTb$wA;

    iput-object p2, p0, Landroidx/fragment/app/Dt$KLFTb;->AZxh:Landroidx/fragment/app/Dt$KLFTb$AZxh;

    iput-object p3, p0, Landroidx/fragment/app/Dt$KLFTb;->wA:Landroidx/fragment/app/Fragment;

    new-instance p1, Landroidx/fragment/app/Dt$KLFTb$mjFkc;

    invoke-direct {p1, p0}, Landroidx/fragment/app/Dt$KLFTb$mjFkc;-><init>(Landroidx/fragment/app/Dt$KLFTb;)V

    invoke-virtual {p4, p1}, Lo/BxruE;->AZxh(Lo/BxruE$mjFkc;)V

    return-void
.end method


# virtual methods
.method public final AZxh()V
    .locals 1

    invoke-virtual {p0}, Landroidx/fragment/app/Dt$KLFTb;->lgHUyS()Z

    move-result v0

    if-eqz v0, :cond_0

    return-void

    :cond_0
    const/4 v0, 0x1

    iput-boolean v0, p0, Landroidx/fragment/app/Dt$KLFTb;->JHa:Z

    iget-object v0, p0, Landroidx/fragment/app/Dt$KLFTb;->KLFTb:Ljava/util/HashSet;

    invoke-virtual {v0}, Ljava/util/HashSet;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_1

    invoke-virtual {p0}, Landroidx/fragment/app/Dt$KLFTb;->wA()V

    goto :goto_1

    :cond_1
    new-instance v0, Ljava/util/ArrayList;

    iget-object p0, p0, Landroidx/fragment/app/Dt$KLFTb;->KLFTb:Ljava/util/HashSet;

    invoke-direct {v0, p0}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_2

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lo/BxruE;

    invoke-virtual {v0}, Lo/BxruE;->mjFkc()V

    goto :goto_0

    :cond_2
    :goto_1
    return-void
.end method

.method public final Dt(Lo/BxruE;)V
    .locals 0

    invoke-virtual {p0}, Landroidx/fragment/app/Dt$KLFTb;->VA()V

    iget-object p0, p0, Landroidx/fragment/app/Dt$KLFTb;->KLFTb:Ljava/util/HashSet;

    invoke-virtual {p0, p1}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method public final ETF(Landroidx/fragment/app/Dt$KLFTb$wA;Landroidx/fragment/app/Dt$KLFTb$AZxh;)V
    .locals 5

    sget-object v0, Landroidx/fragment/app/Dt$wA;->AZxh:[I

    invoke-virtual {p2}, Ljava/lang/Enum;->ordinal()I

    move-result p2

    aget p2, v0, p2

    const/4 v0, 0x1

    const-string v1, "SpecialEffectsController: For fragment "

    const-string v2, "FragmentManager"

    const/4 v3, 0x2

    if-eq p2, v0, :cond_4

    const-string v0, " mFinalState = "

    if-eq p2, v3, :cond_2

    const/4 v4, 0x3

    if-eq p2, v4, :cond_0

    goto/16 :goto_0

    :cond_0
    iget-object p2, p0, Landroidx/fragment/app/Dt$KLFTb;->mjFkc:Landroidx/fragment/app/Dt$KLFTb$wA;

    sget-object v4, Landroidx/fragment/app/Dt$KLFTb$wA;->mjFkc:Landroidx/fragment/app/Dt$KLFTb$wA;

    if-eq p2, v4, :cond_6

    invoke-static {v3}, Landroidx/fragment/app/KLFTb;->dm(I)Z

    move-result p2

    if-eqz p2, :cond_1

    new-instance p2, Ljava/lang/StringBuilder;

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Landroidx/fragment/app/Dt$KLFTb;->wA:Landroidx/fragment/app/Fragment;

    invoke-virtual {p2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v0, p0, Landroidx/fragment/app/Dt$KLFTb;->mjFkc:Landroidx/fragment/app/Dt$KLFTb$wA;

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v0, " -> "

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v0, ". "

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-static {v2, p2}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    :cond_1
    iput-object p1, p0, Landroidx/fragment/app/Dt$KLFTb;->mjFkc:Landroidx/fragment/app/Dt$KLFTb$wA;

    goto :goto_0

    :cond_2
    invoke-static {v3}, Landroidx/fragment/app/KLFTb;->dm(I)Z

    move-result p1

    if-eqz p1, :cond_3

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object p2, p0, Landroidx/fragment/app/Dt$KLFTb;->wA:Landroidx/fragment/app/Fragment;

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object p2, p0, Landroidx/fragment/app/Dt$KLFTb;->mjFkc:Landroidx/fragment/app/Dt$KLFTb$wA;

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p2, " -> REMOVED. mLifecycleImpact  = "

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object p2, p0, Landroidx/fragment/app/Dt$KLFTb;->AZxh:Landroidx/fragment/app/Dt$KLFTb$AZxh;

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p2, " to REMOVING."

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {v2, p1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    :cond_3
    sget-object p1, Landroidx/fragment/app/Dt$KLFTb$wA;->mjFkc:Landroidx/fragment/app/Dt$KLFTb$wA;

    iput-object p1, p0, Landroidx/fragment/app/Dt$KLFTb;->mjFkc:Landroidx/fragment/app/Dt$KLFTb$wA;

    sget-object p1, Landroidx/fragment/app/Dt$KLFTb$AZxh;->wA:Landroidx/fragment/app/Dt$KLFTb$AZxh;

    iput-object p1, p0, Landroidx/fragment/app/Dt$KLFTb;->AZxh:Landroidx/fragment/app/Dt$KLFTb$AZxh;

    goto :goto_0

    :cond_4
    iget-object p1, p0, Landroidx/fragment/app/Dt$KLFTb;->mjFkc:Landroidx/fragment/app/Dt$KLFTb$wA;

    sget-object p2, Landroidx/fragment/app/Dt$KLFTb$wA;->mjFkc:Landroidx/fragment/app/Dt$KLFTb$wA;

    if-ne p1, p2, :cond_6

    invoke-static {v3}, Landroidx/fragment/app/KLFTb;->dm(I)Z

    move-result p1

    if-eqz p1, :cond_5

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object p2, p0, Landroidx/fragment/app/Dt$KLFTb;->wA:Landroidx/fragment/app/Fragment;

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p2, " mFinalState = REMOVED -> VISIBLE. mLifecycleImpact = "

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object p2, p0, Landroidx/fragment/app/Dt$KLFTb;->AZxh:Landroidx/fragment/app/Dt$KLFTb$AZxh;

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p2, " to ADDING."

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {v2, p1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    :cond_5
    sget-object p1, Landroidx/fragment/app/Dt$KLFTb$wA;->AZxh:Landroidx/fragment/app/Dt$KLFTb$wA;

    iput-object p1, p0, Landroidx/fragment/app/Dt$KLFTb;->mjFkc:Landroidx/fragment/app/Dt$KLFTb$wA;

    sget-object p1, Landroidx/fragment/app/Dt$KLFTb$AZxh;->AZxh:Landroidx/fragment/app/Dt$KLFTb$AZxh;

    iput-object p1, p0, Landroidx/fragment/app/Dt$KLFTb;->AZxh:Landroidx/fragment/app/Dt$KLFTb$AZxh;

    :cond_6
    :goto_0
    return-void
.end method

.method public final JHa()Landroidx/fragment/app/Fragment;
    .locals 0

    iget-object p0, p0, Landroidx/fragment/app/Dt$KLFTb;->wA:Landroidx/fragment/app/Fragment;

    return-object p0
.end method

.method public KLFTb()Landroidx/fragment/app/Dt$KLFTb$wA;
    .locals 0

    iget-object p0, p0, Landroidx/fragment/app/Dt$KLFTb;->mjFkc:Landroidx/fragment/app/Dt$KLFTb$wA;

    return-object p0
.end method

.method public abstract VA()V
.end method

.method public final ZfxDd(Lo/BxruE;)V
    .locals 1

    iget-object v0, p0, Landroidx/fragment/app/Dt$KLFTb;->KLFTb:Ljava/util/HashSet;

    invoke-virtual {v0, p1}, Ljava/util/HashSet;->remove(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    iget-object p1, p0, Landroidx/fragment/app/Dt$KLFTb;->KLFTb:Ljava/util/HashSet;

    invoke-virtual {p1}, Ljava/util/HashSet;->isEmpty()Z

    move-result p1

    if-eqz p1, :cond_0

    invoke-virtual {p0}, Landroidx/fragment/app/Dt$KLFTb;->wA()V

    :cond_0
    return-void
.end method

.method public final lgHUyS()Z
    .locals 0

    iget-boolean p0, p0, Landroidx/fragment/app/Dt$KLFTb;->JHa:Z

    return p0
.end method

.method public final mjFkc(Ljava/lang/Runnable;)V
    .locals 0

    iget-object p0, p0, Landroidx/fragment/app/Dt$KLFTb;->ZfxDd:Ljava/util/List;

    invoke-interface {p0, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method public final qdMbNW()Z
    .locals 0

    iget-boolean p0, p0, Landroidx/fragment/app/Dt$KLFTb;->xJ:Z

    return p0
.end method

.method public toString()Ljava/lang/String;
    .locals 4

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "Operation "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "{"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {p0}, Ljava/lang/System;->identityHashCode(Ljava/lang/Object;)I

    move-result v2

    invoke-static {v2}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, "} "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, "mFinalState = "

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v3, p0, Landroidx/fragment/app/Dt$KLFTb;->mjFkc:Landroidx/fragment/app/Dt$KLFTb$wA;

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, "mLifecycleImpact = "

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v3, p0, Landroidx/fragment/app/Dt$KLFTb;->AZxh:Landroidx/fragment/app/Dt$KLFTb$AZxh;

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "mFragment = "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object p0, p0, Landroidx/fragment/app/Dt$KLFTb;->wA:Landroidx/fragment/app/Fragment;

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p0, "}"

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public wA()V
    .locals 2

    iget-boolean v0, p0, Landroidx/fragment/app/Dt$KLFTb;->xJ:Z

    if-eqz v0, :cond_0

    return-void

    :cond_0
    const/4 v0, 0x2

    invoke-static {v0}, Landroidx/fragment/app/KLFTb;->dm(I)Z

    move-result v0

    if-eqz v0, :cond_1

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "SpecialEffectsController: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, " has called complete."

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "FragmentManager"

    invoke-static {v1, v0}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    :cond_1
    const/4 v0, 0x1

    iput-boolean v0, p0, Landroidx/fragment/app/Dt$KLFTb;->xJ:Z

    iget-object p0, p0, Landroidx/fragment/app/Dt$KLFTb;->ZfxDd:Ljava/util/List;

    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_2

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Runnable;

    invoke-interface {v0}, Ljava/lang/Runnable;->run()V

    goto :goto_0

    :cond_2
    return-void
.end method

.method public xJ()Landroidx/fragment/app/Dt$KLFTb$AZxh;
    .locals 0

    iget-object p0, p0, Landroidx/fragment/app/Dt$KLFTb;->AZxh:Landroidx/fragment/app/Dt$KLFTb$AZxh;

    return-object p0
.end method
