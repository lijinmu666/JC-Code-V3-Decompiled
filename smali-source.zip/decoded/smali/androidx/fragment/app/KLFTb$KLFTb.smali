.class public Landroidx/fragment/app/KLFTb$KLFTb;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/fragment/app/KLFTb;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic mjFkc:Landroidx/fragment/app/KLFTb;


# direct methods
.method public constructor <init>(Landroidx/fragment/app/KLFTb;)V
    .locals 0

    iput-object p1, p0, Landroidx/fragment/app/KLFTb$KLFTb;->mjFkc:Landroidx/fragment/app/KLFTb;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 1

    iget-object p0, p0, Landroidx/fragment/app/KLFTb$KLFTb;->mjFkc:Landroidx/fragment/app/KLFTb;

    const/4 v0, 0x1

    invoke-virtual {p0, v0}, Landroidx/fragment/app/KLFTb;->zvd(Z)Z

    return-void
.end method
