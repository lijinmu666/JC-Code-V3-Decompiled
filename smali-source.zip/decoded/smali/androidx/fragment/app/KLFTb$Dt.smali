.class public Landroidx/fragment/app/KLFTb$Dt;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/fragment/app/Fragment$ZfxDd;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/fragment/app/KLFTb;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "Dt"
.end annotation


# instance fields
.field public final AZxh:Landroidx/fragment/app/mjFkc;

.field public final mjFkc:Z

.field public wA:I


# direct methods
.method public constructor <init>(Landroidx/fragment/app/mjFkc;Z)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-boolean p2, p0, Landroidx/fragment/app/KLFTb$Dt;->mjFkc:Z

    iput-object p1, p0, Landroidx/fragment/app/KLFTb$Dt;->AZxh:Landroidx/fragment/app/mjFkc;

    return-void
.end method


# virtual methods
.method public AZxh()V
    .locals 3

    iget-object v0, p0, Landroidx/fragment/app/KLFTb$Dt;->AZxh:Landroidx/fragment/app/mjFkc;

    iget-object v1, v0, Landroidx/fragment/app/mjFkc;->diqgf:Landroidx/fragment/app/KLFTb;

    iget-boolean p0, p0, Landroidx/fragment/app/KLFTb$Dt;->mjFkc:Z

    const/4 v2, 0x0

    invoke-virtual {v1, v0, p0, v2, v2}, Landroidx/fragment/app/KLFTb;->qGY(Landroidx/fragment/app/mjFkc;ZZZ)V

    return-void
.end method

.method public ZfxDd()Z
    .locals 0

    iget p0, p0, Landroidx/fragment/app/KLFTb$Dt;->wA:I

    if-nez p0, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method

.method public mjFkc()V
    .locals 1

    iget v0, p0, Landroidx/fragment/app/KLFTb$Dt;->wA:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, Landroidx/fragment/app/KLFTb$Dt;->wA:I

    return-void
.end method

.method public wA()V
    .locals 5

    iget v0, p0, Landroidx/fragment/app/KLFTb$Dt;->wA:I

    const/4 v1, 0x1

    if-lez v0, :cond_0

    move v0, v1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    iget-object v2, p0, Landroidx/fragment/app/KLFTb$Dt;->AZxh:Landroidx/fragment/app/mjFkc;

    iget-object v2, v2, Landroidx/fragment/app/mjFkc;->diqgf:Landroidx/fragment/app/KLFTb;

    invoke-virtual {v2}, Landroidx/fragment/app/KLFTb;->JrJO()Ljava/util/List;

    move-result-object v2

    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_1
    :goto_1
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_2

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroidx/fragment/app/Fragment;

    const/4 v4, 0x0

    invoke-virtual {v3, v4}, Landroidx/fragment/app/Fragment;->giT(Landroidx/fragment/app/Fragment$ZfxDd;)V

    if-eqz v0, :cond_1

    invoke-virtual {v3}, Landroidx/fragment/app/Fragment;->aqHPIZ()Z

    move-result v4

    if-eqz v4, :cond_1

    invoke-virtual {v3}, Landroidx/fragment/app/Fragment;->fLidf()V

    goto :goto_1

    :cond_2
    iget-object v2, p0, Landroidx/fragment/app/KLFTb$Dt;->AZxh:Landroidx/fragment/app/mjFkc;

    iget-object v3, v2, Landroidx/fragment/app/mjFkc;->diqgf:Landroidx/fragment/app/KLFTb;

    iget-boolean p0, p0, Landroidx/fragment/app/KLFTb$Dt;->mjFkc:Z

    xor-int/2addr v0, v1

    invoke-virtual {v3, v2, p0, v0, v1}, Landroidx/fragment/app/KLFTb;->qGY(Landroidx/fragment/app/mjFkc;ZZZ)V

    return-void
.end method
