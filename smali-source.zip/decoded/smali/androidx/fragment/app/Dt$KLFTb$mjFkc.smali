.class public Landroidx/fragment/app/Dt$KLFTb$mjFkc;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lo/BxruE$mjFkc;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Landroidx/fragment/app/Dt$KLFTb;-><init>(Landroidx/fragment/app/Dt$KLFTb$wA;Landroidx/fragment/app/Dt$KLFTb$AZxh;Landroidx/fragment/app/Fragment;Lo/BxruE;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic mjFkc:Landroidx/fragment/app/Dt$KLFTb;


# direct methods
.method public constructor <init>(Landroidx/fragment/app/Dt$KLFTb;)V
    .locals 0

    iput-object p1, p0, Landroidx/fragment/app/Dt$KLFTb$mjFkc;->mjFkc:Landroidx/fragment/app/Dt$KLFTb;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public mjFkc()V
    .locals 0

    iget-object p0, p0, Landroidx/fragment/app/Dt$KLFTb$mjFkc;->mjFkc:Landroidx/fragment/app/Dt$KLFTb;

    invoke-virtual {p0}, Landroidx/fragment/app/Dt$KLFTb;->AZxh()V

    return-void
.end method
