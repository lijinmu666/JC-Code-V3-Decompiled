.class public Landroidx/fragment/app/wA$Dt;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Landroidx/fragment/app/wA;->huTpC(Ljava/util/List;Ljava/util/List;ZLandroidx/fragment/app/Dt$KLFTb;Landroidx/fragment/app/Dt$KLFTb;)Ljava/util/Map;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic AZxh:Landroidx/fragment/app/wA;

.field public final synthetic mjFkc:Landroidx/fragment/app/wA$MiMN;


# direct methods
.method public constructor <init>(Landroidx/fragment/app/wA;Landroidx/fragment/app/wA$MiMN;)V
    .locals 0

    iput-object p1, p0, Landroidx/fragment/app/wA$Dt;->AZxh:Landroidx/fragment/app/wA;

    iput-object p2, p0, Landroidx/fragment/app/wA$Dt;->mjFkc:Landroidx/fragment/app/wA$MiMN;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 0

    iget-object p0, p0, Landroidx/fragment/app/wA$Dt;->mjFkc:Landroidx/fragment/app/wA$MiMN;

    invoke-virtual {p0}, Landroidx/fragment/app/wA$VA;->mjFkc()V

    return-void
.end method
