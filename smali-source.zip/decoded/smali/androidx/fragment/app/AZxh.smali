.class public final Landroidx/fragment/app/AZxh;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/os/Parcelable;


# static fields
.field public static final CREATOR:Landroid/os/Parcelable$Creator;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/os/Parcelable$Creator<",
            "Landroidx/fragment/app/AZxh;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field public final AZxh:Ljava/util/ArrayList;

.field public final Dt:I

.field public final ETF:Ljava/lang/CharSequence;

.field public final JHa:Ljava/lang/String;

.field public final KLFTb:I

.field public final MiMN:Ljava/util/ArrayList;

.field public final VA:Ljava/util/ArrayList;

.field public final YoKzxo:Z

.field public final ZfxDd:[I

.field public final lgHUyS:I

.field public final mjFkc:[I

.field public final qdMbNW:Ljava/lang/CharSequence;

.field public final wA:[I

.field public final xJ:I


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, Landroidx/fragment/app/AZxh$mjFkc;

    invoke-direct {v0}, Landroidx/fragment/app/AZxh$mjFkc;-><init>()V

    sput-object v0, Landroidx/fragment/app/AZxh;->CREATOR:Landroid/os/Parcelable$Creator;

    return-void
.end method

.method public constructor <init>(Landroid/os/Parcel;)V
    .locals 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    invoke-virtual {p1}, Landroid/os/Parcel;->createIntArray()[I

    move-result-object v0

    iput-object v0, p0, Landroidx/fragment/app/AZxh;->mjFkc:[I

    invoke-virtual {p1}, Landroid/os/Parcel;->createStringArrayList()Ljava/util/ArrayList;

    move-result-object v0

    iput-object v0, p0, Landroidx/fragment/app/AZxh;->AZxh:Ljava/util/ArrayList;

    invoke-virtual {p1}, Landroid/os/Parcel;->createIntArray()[I

    move-result-object v0

    iput-object v0, p0, Landroidx/fragment/app/AZxh;->wA:[I

    invoke-virtual {p1}, Landroid/os/Parcel;->createIntArray()[I

    move-result-object v0

    iput-object v0, p0, Landroidx/fragment/app/AZxh;->ZfxDd:[I

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    iput v0, p0, Landroidx/fragment/app/AZxh;->KLFTb:I

    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Landroidx/fragment/app/AZxh;->JHa:Ljava/lang/String;

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    iput v0, p0, Landroidx/fragment/app/AZxh;->xJ:I

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    iput v0, p0, Landroidx/fragment/app/AZxh;->lgHUyS:I

    sget-object v0, Landroid/text/TextUtils;->CHAR_SEQUENCE_CREATOR:Landroid/os/Parcelable$Creator;

    invoke-interface {v0, p1}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/CharSequence;

    iput-object v1, p0, Landroidx/fragment/app/AZxh;->qdMbNW:Ljava/lang/CharSequence;

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v1

    iput v1, p0, Landroidx/fragment/app/AZxh;->Dt:I

    invoke-interface {v0, p1}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/CharSequence;

    iput-object v0, p0, Landroidx/fragment/app/AZxh;->ETF:Ljava/lang/CharSequence;

    invoke-virtual {p1}, Landroid/os/Parcel;->createStringArrayList()Ljava/util/ArrayList;

    move-result-object v0

    iput-object v0, p0, Landroidx/fragment/app/AZxh;->VA:Ljava/util/ArrayList;

    invoke-virtual {p1}, Landroid/os/Parcel;->createStringArrayList()Ljava/util/ArrayList;

    move-result-object v0

    iput-object v0, p0, Landroidx/fragment/app/AZxh;->MiMN:Ljava/util/ArrayList;

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result p1

    if-eqz p1, :cond_0

    const/4 p1, 0x1

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    :goto_0
    iput-boolean p1, p0, Landroidx/fragment/app/AZxh;->YoKzxo:Z

    return-void
.end method


# virtual methods
.method public describeContents()I
    .locals 0

    const/4 p0, 0x0

    return p0
.end method

.method public mjFkc(Landroidx/fragment/app/KLFTb;)Landroidx/fragment/app/mjFkc;
    .locals 9

    new-instance v0, Landroidx/fragment/app/mjFkc;

    invoke-direct {v0, p1}, Landroidx/fragment/app/mjFkc;-><init>(Landroidx/fragment/app/KLFTb;)V

    const/4 v1, 0x0

    move v2, v1

    :goto_0
    iget-object v3, p0, Landroidx/fragment/app/AZxh;->mjFkc:[I

    array-length v3, v3

    if-ge v1, v3, :cond_2

    new-instance v3, Landroidx/fragment/app/lgHUyS$mjFkc;

    invoke-direct {v3}, Landroidx/fragment/app/lgHUyS$mjFkc;-><init>()V

    iget-object v4, p0, Landroidx/fragment/app/AZxh;->mjFkc:[I

    add-int/lit8 v5, v1, 0x1

    aget v4, v4, v1

    iput v4, v3, Landroidx/fragment/app/lgHUyS$mjFkc;->mjFkc:I

    const/4 v4, 0x2

    invoke-static {v4}, Landroidx/fragment/app/KLFTb;->dm(I)Z

    move-result v4

    if-eqz v4, :cond_0

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "Instantiate "

    invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v6, " op #"

    invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v6, " base fragment #"

    invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v6, p0, Landroidx/fragment/app/AZxh;->mjFkc:[I

    aget v6, v6, v5

    invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    const-string v6, "FragmentManager"

    invoke-static {v6, v4}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    :cond_0
    iget-object v4, p0, Landroidx/fragment/app/AZxh;->AZxh:Ljava/util/ArrayList;

    invoke-virtual {v4, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    if-eqz v4, :cond_1

    invoke-virtual {p1, v4}, Landroidx/fragment/app/KLFTb;->vadzgd(Ljava/lang/String;)Landroidx/fragment/app/Fragment;

    move-result-object v4

    iput-object v4, v3, Landroidx/fragment/app/lgHUyS$mjFkc;->AZxh:Landroidx/fragment/app/Fragment;

    goto :goto_1

    :cond_1
    const/4 v4, 0x0

    iput-object v4, v3, Landroidx/fragment/app/lgHUyS$mjFkc;->AZxh:Landroidx/fragment/app/Fragment;

    :goto_1
    invoke-static {}, Landroidx/lifecycle/wA$AZxh;->values()[Landroidx/lifecycle/wA$AZxh;

    move-result-object v4

    iget-object v6, p0, Landroidx/fragment/app/AZxh;->wA:[I

    aget v6, v6, v2

    aget-object v4, v4, v6

    iput-object v4, v3, Landroidx/fragment/app/lgHUyS$mjFkc;->xJ:Landroidx/lifecycle/wA$AZxh;

    invoke-static {}, Landroidx/lifecycle/wA$AZxh;->values()[Landroidx/lifecycle/wA$AZxh;

    move-result-object v4

    iget-object v6, p0, Landroidx/fragment/app/AZxh;->ZfxDd:[I

    aget v6, v6, v2

    aget-object v4, v4, v6

    iput-object v4, v3, Landroidx/fragment/app/lgHUyS$mjFkc;->lgHUyS:Landroidx/lifecycle/wA$AZxh;

    iget-object v4, p0, Landroidx/fragment/app/AZxh;->mjFkc:[I

    add-int/lit8 v6, v1, 0x2

    aget v5, v4, v5

    iput v5, v3, Landroidx/fragment/app/lgHUyS$mjFkc;->wA:I

    add-int/lit8 v7, v1, 0x3

    aget v6, v4, v6

    iput v6, v3, Landroidx/fragment/app/lgHUyS$mjFkc;->ZfxDd:I

    add-int/lit8 v8, v1, 0x4

    aget v7, v4, v7

    iput v7, v3, Landroidx/fragment/app/lgHUyS$mjFkc;->KLFTb:I

    add-int/lit8 v1, v1, 0x5

    aget v4, v4, v8

    iput v4, v3, Landroidx/fragment/app/lgHUyS$mjFkc;->JHa:I

    iput v5, v0, Landroidx/fragment/app/lgHUyS;->ZfxDd:I

    iput v6, v0, Landroidx/fragment/app/lgHUyS;->KLFTb:I

    iput v7, v0, Landroidx/fragment/app/lgHUyS;->JHa:I

    iput v4, v0, Landroidx/fragment/app/lgHUyS;->xJ:I

    invoke-virtual {v0, v3}, Landroidx/fragment/app/lgHUyS;->ZfxDd(Landroidx/fragment/app/lgHUyS$mjFkc;)V

    add-int/lit8 v2, v2, 0x1

    goto/16 :goto_0

    :cond_2
    iget p1, p0, Landroidx/fragment/app/AZxh;->KLFTb:I

    iput p1, v0, Landroidx/fragment/app/lgHUyS;->lgHUyS:I

    iget-object p1, p0, Landroidx/fragment/app/AZxh;->JHa:Ljava/lang/String;

    iput-object p1, v0, Landroidx/fragment/app/lgHUyS;->ETF:Ljava/lang/String;

    iget p1, p0, Landroidx/fragment/app/AZxh;->xJ:I

    iput p1, v0, Landroidx/fragment/app/mjFkc;->Ucbh:I

    const/4 p1, 0x1

    iput-boolean p1, v0, Landroidx/fragment/app/lgHUyS;->qdMbNW:Z

    iget v1, p0, Landroidx/fragment/app/AZxh;->lgHUyS:I

    iput v1, v0, Landroidx/fragment/app/lgHUyS;->VA:I

    iget-object v1, p0, Landroidx/fragment/app/AZxh;->qdMbNW:Ljava/lang/CharSequence;

    iput-object v1, v0, Landroidx/fragment/app/lgHUyS;->MiMN:Ljava/lang/CharSequence;

    iget v1, p0, Landroidx/fragment/app/AZxh;->Dt:I

    iput v1, v0, Landroidx/fragment/app/lgHUyS;->YoKzxo:I

    iget-object v1, p0, Landroidx/fragment/app/AZxh;->ETF:Ljava/lang/CharSequence;

    iput-object v1, v0, Landroidx/fragment/app/lgHUyS;->rkYL:Ljava/lang/CharSequence;

    iget-object v1, p0, Landroidx/fragment/app/AZxh;->VA:Ljava/util/ArrayList;

    iput-object v1, v0, Landroidx/fragment/app/lgHUyS;->qGY:Ljava/util/ArrayList;

    iget-object v1, p0, Landroidx/fragment/app/AZxh;->MiMN:Ljava/util/ArrayList;

    iput-object v1, v0, Landroidx/fragment/app/lgHUyS;->fehf:Ljava/util/ArrayList;

    iget-boolean p0, p0, Landroidx/fragment/app/AZxh;->YoKzxo:Z

    iput-boolean p0, v0, Landroidx/fragment/app/lgHUyS;->IEE:Z

    invoke-virtual {v0, p1}, Landroidx/fragment/app/mjFkc;->rkYL(I)V

    return-object v0
.end method

.method public writeToParcel(Landroid/os/Parcel;I)V
    .locals 1

    iget-object p2, p0, Landroidx/fragment/app/AZxh;->mjFkc:[I

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeIntArray([I)V

    iget-object p2, p0, Landroidx/fragment/app/AZxh;->AZxh:Ljava/util/ArrayList;

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeStringList(Ljava/util/List;)V

    iget-object p2, p0, Landroidx/fragment/app/AZxh;->wA:[I

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeIntArray([I)V

    iget-object p2, p0, Landroidx/fragment/app/AZxh;->ZfxDd:[I

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeIntArray([I)V

    iget p2, p0, Landroidx/fragment/app/AZxh;->KLFTb:I

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    iget-object p2, p0, Landroidx/fragment/app/AZxh;->JHa:Ljava/lang/String;

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    iget p2, p0, Landroidx/fragment/app/AZxh;->xJ:I

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    iget p2, p0, Landroidx/fragment/app/AZxh;->lgHUyS:I

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    iget-object p2, p0, Landroidx/fragment/app/AZxh;->qdMbNW:Ljava/lang/CharSequence;

    const/4 v0, 0x0

    invoke-static {p2, p1, v0}, Landroid/text/TextUtils;->writeToParcel(Ljava/lang/CharSequence;Landroid/os/Parcel;I)V

    iget p2, p0, Landroidx/fragment/app/AZxh;->Dt:I

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    iget-object p2, p0, Landroidx/fragment/app/AZxh;->ETF:Ljava/lang/CharSequence;

    invoke-static {p2, p1, v0}, Landroid/text/TextUtils;->writeToParcel(Ljava/lang/CharSequence;Landroid/os/Parcel;I)V

    iget-object p2, p0, Landroidx/fragment/app/AZxh;->VA:Ljava/util/ArrayList;

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeStringList(Ljava/util/List;)V

    iget-object p2, p0, Landroidx/fragment/app/AZxh;->MiMN:Ljava/util/ArrayList;

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeStringList(Ljava/util/List;)V

    iget-boolean p0, p0, Landroidx/fragment/app/AZxh;->YoKzxo:Z

    invoke-virtual {p1, p0}, Landroid/os/Parcel;->writeInt(I)V

    return-void
.end method
