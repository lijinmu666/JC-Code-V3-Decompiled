.class public Landroidx/fragment/app/KLFTb$wA;
.super Lo/bL;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/fragment/app/KLFTb;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic AZxh:Landroidx/fragment/app/KLFTb;


# direct methods
.method public constructor <init>(Landroidx/fragment/app/KLFTb;)V
    .locals 0

    iput-object p1, p0, Landroidx/fragment/app/KLFTb$wA;->AZxh:Landroidx/fragment/app/KLFTb;

    invoke-direct {p0}, Lo/bL;-><init>()V

    return-void
.end method


# virtual methods
.method public mjFkc(Ljava/lang/ClassLoader;Ljava/lang/String;)Landroidx/fragment/app/Fragment;
    .locals 0

    iget-object p1, p0, Landroidx/fragment/app/KLFTb$wA;->AZxh:Landroidx/fragment/app/KLFTb;

    invoke-virtual {p1}, Landroidx/fragment/app/KLFTb;->nxI()Lo/aAlqX;

    iget-object p0, p0, Landroidx/fragment/app/KLFTb$wA;->AZxh:Landroidx/fragment/app/KLFTb;

    invoke-virtual {p0}, Landroidx/fragment/app/KLFTb;->nxI()Lo/aAlqX;

    const/4 p0, 0x0

    throw p0
.end method
