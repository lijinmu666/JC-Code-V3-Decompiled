.class public Landroidx/fragment/app/Fragment$wA;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/fragment/app/Fragment;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "wA"
.end annotation


# instance fields
.field public AZxh:I

.field public Dt:Ljava/lang/Object;

.field public ETF:Ljava/lang/Object;

.field public IEE:Landroid/view/View;

.field public JHa:I

.field public KLFTb:I

.field public MiMN:Ljava/lang/Object;

.field public Pq:Z

.field public VA:Ljava/lang/Object;

.field public YoKzxo:Ljava/lang/Object;

.field public ZfxDd:I

.field public diqgf:Landroidx/fragment/app/Fragment$ZfxDd;

.field public fehf:F

.field public lgHUyS:Ljava/util/ArrayList;

.field public mjFkc:Z

.field public qGY:Ljava/lang/Boolean;

.field public qdMbNW:Ljava/lang/Object;

.field public rkYL:Ljava/lang/Boolean;

.field public wA:I

.field public xJ:Ljava/util/ArrayList;


# direct methods
.method public constructor <init>()V
    .locals 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput-object v0, p0, Landroidx/fragment/app/Fragment$wA;->qdMbNW:Ljava/lang/Object;

    sget-object v1, Landroidx/fragment/app/Fragment;->JYgkl:Ljava/lang/Object;

    iput-object v1, p0, Landroidx/fragment/app/Fragment$wA;->Dt:Ljava/lang/Object;

    iput-object v0, p0, Landroidx/fragment/app/Fragment$wA;->ETF:Ljava/lang/Object;

    iput-object v1, p0, Landroidx/fragment/app/Fragment$wA;->VA:Ljava/lang/Object;

    iput-object v0, p0, Landroidx/fragment/app/Fragment$wA;->MiMN:Ljava/lang/Object;

    iput-object v1, p0, Landroidx/fragment/app/Fragment$wA;->YoKzxo:Ljava/lang/Object;

    const/high16 v1, 0x3f800000    # 1.0f

    iput v1, p0, Landroidx/fragment/app/Fragment$wA;->fehf:F

    iput-object v0, p0, Landroidx/fragment/app/Fragment$wA;->IEE:Landroid/view/View;

    return-void
.end method
