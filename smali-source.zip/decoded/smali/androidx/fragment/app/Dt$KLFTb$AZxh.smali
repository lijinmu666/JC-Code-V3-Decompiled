.class public final enum Landroidx/fragment/app/Dt$KLFTb$AZxh;
.super Ljava/lang/Enum;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/fragment/app/Dt$KLFTb;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4019
    name = "AZxh"
.end annotation


# static fields
.field public static final enum AZxh:Landroidx/fragment/app/Dt$KLFTb$AZxh;

.field public static final synthetic ZfxDd:[Landroidx/fragment/app/Dt$KLFTb$AZxh;

.field public static final enum mjFkc:Landroidx/fragment/app/Dt$KLFTb$AZxh;

.field public static final enum wA:Landroidx/fragment/app/Dt$KLFTb$AZxh;


# direct methods
.method static constructor <clinit>()V
    .locals 5

    new-instance v0, Landroidx/fragment/app/Dt$KLFTb$AZxh;

    const-string v1, "NONE"

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2}, Landroidx/fragment/app/Dt$KLFTb$AZxh;-><init>(Ljava/lang/String;I)V

    sput-object v0, Landroidx/fragment/app/Dt$KLFTb$AZxh;->mjFkc:Landroidx/fragment/app/Dt$KLFTb$AZxh;

    new-instance v1, Landroidx/fragment/app/Dt$KLFTb$AZxh;

    const-string v2, "ADDING"

    const/4 v3, 0x1

    invoke-direct {v1, v2, v3}, Landroidx/fragment/app/Dt$KLFTb$AZxh;-><init>(Ljava/lang/String;I)V

    sput-object v1, Landroidx/fragment/app/Dt$KLFTb$AZxh;->AZxh:Landroidx/fragment/app/Dt$KLFTb$AZxh;

    new-instance v2, Landroidx/fragment/app/Dt$KLFTb$AZxh;

    const-string v3, "REMOVING"

    const/4 v4, 0x2

    invoke-direct {v2, v3, v4}, Landroidx/fragment/app/Dt$KLFTb$AZxh;-><init>(Ljava/lang/String;I)V

    sput-object v2, Landroidx/fragment/app/Dt$KLFTb$AZxh;->wA:Landroidx/fragment/app/Dt$KLFTb$AZxh;

    filled-new-array {v0, v1, v2}, [Landroidx/fragment/app/Dt$KLFTb$AZxh;

    move-result-object v0

    sput-object v0, Landroidx/fragment/app/Dt$KLFTb$AZxh;->ZfxDd:[Landroidx/fragment/app/Dt$KLFTb$AZxh;

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;I)V
    .locals 0

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    return-void
.end method

.method public static valueOf(Ljava/lang/String;)Landroidx/fragment/app/Dt$KLFTb$AZxh;
    .locals 1

    const-class v0, Landroidx/fragment/app/Dt$KLFTb$AZxh;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, Landroidx/fragment/app/Dt$KLFTb$AZxh;

    return-object p0
.end method

.method public static values()[Landroidx/fragment/app/Dt$KLFTb$AZxh;
    .locals 1

    sget-object v0, Landroidx/fragment/app/Dt$KLFTb$AZxh;->ZfxDd:[Landroidx/fragment/app/Dt$KLFTb$AZxh;

    invoke-virtual {v0}, [Landroidx/fragment/app/Dt$KLFTb$AZxh;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Landroidx/fragment/app/Dt$KLFTb$AZxh;

    return-object v0
.end method
