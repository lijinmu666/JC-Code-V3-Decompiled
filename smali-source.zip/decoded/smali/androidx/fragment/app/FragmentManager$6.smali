.class Landroidx/fragment/app/FragmentManager$6;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/lifecycle/KLFTb;


# instance fields
.field public final synthetic AZxh:Landroidx/lifecycle/wA;

.field public final synthetic mjFkc:Ljava/lang/String;

.field public final synthetic wA:Landroidx/fragment/app/KLFTb;


# virtual methods
.method public VA(Lo/W0;Landroidx/lifecycle/wA$mjFkc;)V
    .locals 1

    sget-object p1, Landroidx/lifecycle/wA$mjFkc;->ON_START:Landroidx/lifecycle/wA$mjFkc;

    if-ne p2, p1, :cond_1

    iget-object p1, p0, Landroidx/fragment/app/FragmentManager$6;->wA:Landroidx/fragment/app/KLFTb;

    invoke-static {p1}, Landroidx/fragment/app/KLFTb;->mjFkc(Landroidx/fragment/app/KLFTb;)Ljava/util/Map;

    move-result-object p1

    iget-object v0, p0, Landroidx/fragment/app/FragmentManager$6;->mjFkc:Ljava/lang/String;

    invoke-interface {p1, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/os/Bundle;

    if-nez p1, :cond_0

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    throw p0

    :cond_1
    :goto_0
    sget-object p1, Landroidx/lifecycle/wA$mjFkc;->ON_DESTROY:Landroidx/lifecycle/wA$mjFkc;

    if-ne p2, p1, :cond_2

    iget-object p1, p0, Landroidx/fragment/app/FragmentManager$6;->AZxh:Landroidx/lifecycle/wA;

    invoke-virtual {p1, p0}, Landroidx/lifecycle/wA;->wA(Lo/V0;)V

    iget-object p1, p0, Landroidx/fragment/app/FragmentManager$6;->wA:Landroidx/fragment/app/KLFTb;

    invoke-static {p1}, Landroidx/fragment/app/KLFTb;->AZxh(Landroidx/fragment/app/KLFTb;)Ljava/util/Map;

    move-result-object p1

    iget-object p0, p0, Landroidx/fragment/app/FragmentManager$6;->mjFkc:Ljava/lang/String;

    invoke-interface {p1, p0}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    :cond_2
    return-void
.end method
