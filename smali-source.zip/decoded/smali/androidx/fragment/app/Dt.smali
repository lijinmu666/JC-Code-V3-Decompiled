.class public abstract Landroidx/fragment/app/Dt;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/fragment/app/Dt$ZfxDd;,
        Landroidx/fragment/app/Dt$KLFTb;
    }
.end annotation


# instance fields
.field public final AZxh:Ljava/util/ArrayList;

.field public KLFTb:Z

.field public ZfxDd:Z

.field public final mjFkc:Landroid/view/ViewGroup;

.field public final wA:Ljava/util/ArrayList;


# direct methods
.method public constructor <init>(Landroid/view/ViewGroup;)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Landroidx/fragment/app/Dt;->AZxh:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Landroidx/fragment/app/Dt;->wA:Ljava/util/ArrayList;

    const/4 v0, 0x0

    iput-boolean v0, p0, Landroidx/fragment/app/Dt;->ZfxDd:Z

    iput-boolean v0, p0, Landroidx/fragment/app/Dt;->KLFTb:Z

    iput-object p1, p0, Landroidx/fragment/app/Dt;->mjFkc:Landroid/view/ViewGroup;

    return-void
.end method

.method public static MiMN(Landroid/view/ViewGroup;Landroidx/fragment/app/KLFTb;)Landroidx/fragment/app/Dt;
    .locals 0

    invoke-virtual {p1}, Landroidx/fragment/app/KLFTb;->SwgkN()Lo/f7;

    move-result-object p1

    invoke-static {p0, p1}, Landroidx/fragment/app/Dt;->YoKzxo(Landroid/view/ViewGroup;Lo/f7;)Landroidx/fragment/app/Dt;

    move-result-object p0

    return-object p0
.end method

.method public static YoKzxo(Landroid/view/ViewGroup;Lo/f7;)Landroidx/fragment/app/Dt;
    .locals 2

    sget v0, Lo/y4;->AZxh:I

    invoke-virtual {p0, v0}, Landroid/view/View;->getTag(I)Ljava/lang/Object;

    move-result-object v0

    instance-of v1, v0, Landroidx/fragment/app/Dt;

    if-eqz v1, :cond_0

    check-cast v0, Landroidx/fragment/app/Dt;

    return-object v0

    :cond_0
    invoke-interface {p1, p0}, Lo/f7;->mjFkc(Landroid/view/ViewGroup;)Landroidx/fragment/app/Dt;

    move-result-object p1

    sget v0, Lo/y4;->AZxh:I

    invoke-virtual {p0, v0, p1}, Landroid/view/View;->setTag(ILjava/lang/Object;)V

    return-object p1
.end method


# virtual methods
.method public AZxh(Landroidx/fragment/app/Dt$KLFTb$wA;Landroidx/fragment/app/xJ;)V
    .locals 2

    const/4 v0, 0x2

    invoke-static {v0}, Landroidx/fragment/app/KLFTb;->dm(I)Z

    move-result v0

    if-eqz v0, :cond_0

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "SpecialEffectsController: Enqueuing add operation for fragment "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Landroidx/fragment/app/xJ;->ETF()Landroidx/fragment/app/Fragment;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "FragmentManager"

    invoke-static {v1, v0}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    :cond_0
    sget-object v0, Landroidx/fragment/app/Dt$KLFTb$AZxh;->AZxh:Landroidx/fragment/app/Dt$KLFTb$AZxh;

    invoke-virtual {p0, p1, v0, p2}, Landroidx/fragment/app/Dt;->mjFkc(Landroidx/fragment/app/Dt$KLFTb$wA;Landroidx/fragment/app/Dt$KLFTb$AZxh;Landroidx/fragment/app/xJ;)V

    return-void
.end method

.method public Dt()V
    .locals 9

    iget-object v0, p0, Landroidx/fragment/app/Dt;->mjFkc:Landroid/view/ViewGroup;

    invoke-static {v0}, Lo/T9;->cMLeY(Landroid/view/View;)Z

    move-result v0

    iget-object v1, p0, Landroidx/fragment/app/Dt;->AZxh:Ljava/util/ArrayList;

    monitor-enter v1

    :try_start_0
    invoke-virtual {p0}, Landroidx/fragment/app/Dt;->qGY()V

    iget-object v2, p0, Landroidx/fragment/app/Dt;->AZxh:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_0
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_0

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroidx/fragment/app/Dt$KLFTb;

    invoke-virtual {v3}, Landroidx/fragment/app/Dt$KLFTb;->VA()V

    goto :goto_0

    :catchall_0
    move-exception p0

    goto/16 :goto_5

    :cond_0
    new-instance v2, Ljava/util/ArrayList;

    iget-object v3, p0, Landroidx/fragment/app/Dt;->wA:Ljava/util/ArrayList;

    invoke-direct {v2, v3}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    invoke-virtual {v2}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_1
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    const/4 v4, 0x2

    if-eqz v3, :cond_3

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroidx/fragment/app/Dt$KLFTb;

    invoke-static {v4}, Landroidx/fragment/app/KLFTb;->dm(I)Z

    move-result v4

    if-eqz v4, :cond_2

    const-string v4, "FragmentManager"

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "SpecialEffectsController: "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    if-eqz v0, :cond_1

    const-string v6, ""

    goto :goto_2

    :cond_1
    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const-string v7, "Container "

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v7, p0, Landroidx/fragment/app/Dt;->mjFkc:Landroid/view/ViewGroup;

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v7, " is not attached to window. "

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    :goto_2
    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v6, "Cancelling running operation "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-static {v4, v5}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    :cond_2
    invoke-virtual {v3}, Landroidx/fragment/app/Dt$KLFTb;->AZxh()V

    goto :goto_1

    :cond_3
    new-instance v2, Ljava/util/ArrayList;

    iget-object v3, p0, Landroidx/fragment/app/Dt;->AZxh:Ljava/util/ArrayList;

    invoke-direct {v2, v3}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    invoke-virtual {v2}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_3
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_6

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroidx/fragment/app/Dt$KLFTb;

    invoke-static {v4}, Landroidx/fragment/app/KLFTb;->dm(I)Z

    move-result v5

    if-eqz v5, :cond_5

    const-string v5, "FragmentManager"

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const-string v7, "SpecialEffectsController: "

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    if-eqz v0, :cond_4

    const-string v7, ""

    goto :goto_4

    :cond_4
    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    const-string v8, "Container "

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v8, p0, Landroidx/fragment/app/Dt;->mjFkc:Landroid/view/ViewGroup;

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v8, " is not attached to window. "

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    :goto_4
    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v7, "Cancelling pending operation "

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {v5, v6}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    :cond_5
    invoke-virtual {v3}, Landroidx/fragment/app/Dt$KLFTb;->AZxh()V

    goto :goto_3

    :cond_6
    monitor-exit v1

    return-void

    :goto_5
    monitor-exit v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw p0
.end method

.method public ETF(Landroidx/fragment/app/xJ;)Landroidx/fragment/app/Dt$KLFTb$AZxh;
    .locals 1

    invoke-virtual {p1}, Landroidx/fragment/app/xJ;->ETF()Landroidx/fragment/app/Fragment;

    move-result-object v0

    invoke-virtual {p0, v0}, Landroidx/fragment/app/Dt;->lgHUyS(Landroidx/fragment/app/Fragment;)Landroidx/fragment/app/Dt$KLFTb;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Landroidx/fragment/app/Dt$KLFTb;->xJ()Landroidx/fragment/app/Dt$KLFTb$AZxh;

    move-result-object v0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    invoke-virtual {p1}, Landroidx/fragment/app/xJ;->ETF()Landroidx/fragment/app/Fragment;

    move-result-object p1

    invoke-virtual {p0, p1}, Landroidx/fragment/app/Dt;->qdMbNW(Landroidx/fragment/app/Fragment;)Landroidx/fragment/app/Dt$KLFTb;

    move-result-object p0

    if-eqz p0, :cond_2

    if-eqz v0, :cond_1

    sget-object p1, Landroidx/fragment/app/Dt$KLFTb$AZxh;->mjFkc:Landroidx/fragment/app/Dt$KLFTb$AZxh;

    if-ne v0, p1, :cond_2

    :cond_1
    invoke-virtual {p0}, Landroidx/fragment/app/Dt$KLFTb;->xJ()Landroidx/fragment/app/Dt$KLFTb$AZxh;

    move-result-object p0

    return-object p0

    :cond_2
    return-object v0
.end method

.method public abstract JHa(Ljava/util/List;Z)V
.end method

.method public KLFTb(Landroidx/fragment/app/xJ;)V
    .locals 2

    const/4 v0, 0x2

    invoke-static {v0}, Landroidx/fragment/app/KLFTb;->dm(I)Z

    move-result v0

    if-eqz v0, :cond_0

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "SpecialEffectsController: Enqueuing show operation for fragment "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Landroidx/fragment/app/xJ;->ETF()Landroidx/fragment/app/Fragment;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "FragmentManager"

    invoke-static {v1, v0}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    :cond_0
    sget-object v0, Landroidx/fragment/app/Dt$KLFTb$wA;->AZxh:Landroidx/fragment/app/Dt$KLFTb$wA;

    sget-object v1, Landroidx/fragment/app/Dt$KLFTb$AZxh;->mjFkc:Landroidx/fragment/app/Dt$KLFTb$AZxh;

    invoke-virtual {p0, v0, v1, p1}, Landroidx/fragment/app/Dt;->mjFkc(Landroidx/fragment/app/Dt$KLFTb$wA;Landroidx/fragment/app/Dt$KLFTb$AZxh;Landroidx/fragment/app/xJ;)V

    return-void
.end method

.method public VA()Landroid/view/ViewGroup;
    .locals 0

    iget-object p0, p0, Landroidx/fragment/app/Dt;->mjFkc:Landroid/view/ViewGroup;

    return-object p0
.end method

.method public ZfxDd(Landroidx/fragment/app/xJ;)V
    .locals 2

    const/4 v0, 0x2

    invoke-static {v0}, Landroidx/fragment/app/KLFTb;->dm(I)Z

    move-result v0

    if-eqz v0, :cond_0

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "SpecialEffectsController: Enqueuing remove operation for fragment "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Landroidx/fragment/app/xJ;->ETF()Landroidx/fragment/app/Fragment;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "FragmentManager"

    invoke-static {v1, v0}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    :cond_0
    sget-object v0, Landroidx/fragment/app/Dt$KLFTb$wA;->mjFkc:Landroidx/fragment/app/Dt$KLFTb$wA;

    sget-object v1, Landroidx/fragment/app/Dt$KLFTb$AZxh;->wA:Landroidx/fragment/app/Dt$KLFTb$AZxh;

    invoke-virtual {p0, v0, v1, p1}, Landroidx/fragment/app/Dt;->mjFkc(Landroidx/fragment/app/Dt$KLFTb$wA;Landroidx/fragment/app/Dt$KLFTb$AZxh;Landroidx/fragment/app/xJ;)V

    return-void
.end method

.method public fehf(Z)V
    .locals 0

    iput-boolean p1, p0, Landroidx/fragment/app/Dt;->ZfxDd:Z

    return-void
.end method

.method public final lgHUyS(Landroidx/fragment/app/Fragment;)Landroidx/fragment/app/Dt$KLFTb;
    .locals 2

    iget-object p0, p0, Landroidx/fragment/app/Dt;->AZxh:Ljava/util/ArrayList;

    invoke-virtual {p0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :cond_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_1

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroidx/fragment/app/Dt$KLFTb;

    invoke-virtual {v0}, Landroidx/fragment/app/Dt$KLFTb;->JHa()Landroidx/fragment/app/Fragment;

    move-result-object v1

    invoke-virtual {v1, p1}, Landroidx/fragment/app/Fragment;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-virtual {v0}, Landroidx/fragment/app/Dt$KLFTb;->lgHUyS()Z

    move-result v1

    if-nez v1, :cond_0

    return-object v0

    :cond_1
    const/4 p0, 0x0

    return-object p0
.end method

.method public final mjFkc(Landroidx/fragment/app/Dt$KLFTb$wA;Landroidx/fragment/app/Dt$KLFTb$AZxh;Landroidx/fragment/app/xJ;)V
    .locals 3

    iget-object v0, p0, Landroidx/fragment/app/Dt;->AZxh:Ljava/util/ArrayList;

    monitor-enter v0

    :try_start_0
    new-instance v1, Lo/BxruE;

    invoke-direct {v1}, Lo/BxruE;-><init>()V

    invoke-virtual {p3}, Landroidx/fragment/app/xJ;->ETF()Landroidx/fragment/app/Fragment;

    move-result-object v2

    invoke-virtual {p0, v2}, Landroidx/fragment/app/Dt;->lgHUyS(Landroidx/fragment/app/Fragment;)Landroidx/fragment/app/Dt$KLFTb;

    move-result-object v2

    if-eqz v2, :cond_0

    invoke-virtual {v2, p1, p2}, Landroidx/fragment/app/Dt$KLFTb;->ETF(Landroidx/fragment/app/Dt$KLFTb$wA;Landroidx/fragment/app/Dt$KLFTb$AZxh;)V

    monitor-exit v0

    return-void

    :catchall_0
    move-exception p0

    goto :goto_0

    :cond_0
    new-instance v2, Landroidx/fragment/app/Dt$ZfxDd;

    invoke-direct {v2, p1, p2, p3, v1}, Landroidx/fragment/app/Dt$ZfxDd;-><init>(Landroidx/fragment/app/Dt$KLFTb$wA;Landroidx/fragment/app/Dt$KLFTb$AZxh;Landroidx/fragment/app/xJ;Lo/BxruE;)V

    iget-object p1, p0, Landroidx/fragment/app/Dt;->AZxh:Ljava/util/ArrayList;

    invoke-virtual {p1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    new-instance p1, Landroidx/fragment/app/Dt$mjFkc;

    invoke-direct {p1, p0, v2}, Landroidx/fragment/app/Dt$mjFkc;-><init>(Landroidx/fragment/app/Dt;Landroidx/fragment/app/Dt$ZfxDd;)V

    invoke-virtual {v2, p1}, Landroidx/fragment/app/Dt$KLFTb;->mjFkc(Ljava/lang/Runnable;)V

    new-instance p1, Landroidx/fragment/app/Dt$AZxh;

    invoke-direct {p1, p0, v2}, Landroidx/fragment/app/Dt$AZxh;-><init>(Landroidx/fragment/app/Dt;Landroidx/fragment/app/Dt$ZfxDd;)V

    invoke-virtual {v2, p1}, Landroidx/fragment/app/Dt$KLFTb;->mjFkc(Ljava/lang/Runnable;)V

    monitor-exit v0

    return-void

    :goto_0
    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw p0
.end method

.method public final qGY()V
    .locals 3

    iget-object p0, p0, Landroidx/fragment/app/Dt;->AZxh:Ljava/util/ArrayList;

    invoke-virtual {p0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :cond_0
    :goto_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_1

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroidx/fragment/app/Dt$KLFTb;

    invoke-virtual {v0}, Landroidx/fragment/app/Dt$KLFTb;->xJ()Landroidx/fragment/app/Dt$KLFTb$AZxh;

    move-result-object v1

    sget-object v2, Landroidx/fragment/app/Dt$KLFTb$AZxh;->AZxh:Landroidx/fragment/app/Dt$KLFTb$AZxh;

    if-ne v1, v2, :cond_0

    invoke-virtual {v0}, Landroidx/fragment/app/Dt$KLFTb;->JHa()Landroidx/fragment/app/Fragment;

    move-result-object v1

    invoke-virtual {v1}, Landroidx/fragment/app/Fragment;->XbiWeM()Landroid/view/View;

    move-result-object v1

    invoke-virtual {v1}, Landroid/view/View;->getVisibility()I

    move-result v1

    invoke-static {v1}, Landroidx/fragment/app/Dt$KLFTb$wA;->lgHUyS(I)Landroidx/fragment/app/Dt$KLFTb$wA;

    move-result-object v1

    sget-object v2, Landroidx/fragment/app/Dt$KLFTb$AZxh;->mjFkc:Landroidx/fragment/app/Dt$KLFTb$AZxh;

    invoke-virtual {v0, v1, v2}, Landroidx/fragment/app/Dt$KLFTb;->ETF(Landroidx/fragment/app/Dt$KLFTb$wA;Landroidx/fragment/app/Dt$KLFTb$AZxh;)V

    goto :goto_0

    :cond_1
    return-void
.end method

.method public final qdMbNW(Landroidx/fragment/app/Fragment;)Landroidx/fragment/app/Dt$KLFTb;
    .locals 2

    iget-object p0, p0, Landroidx/fragment/app/Dt;->wA:Ljava/util/ArrayList;

    invoke-virtual {p0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :cond_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_1

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroidx/fragment/app/Dt$KLFTb;

    invoke-virtual {v0}, Landroidx/fragment/app/Dt$KLFTb;->JHa()Landroidx/fragment/app/Fragment;

    move-result-object v1

    invoke-virtual {v1, p1}, Landroidx/fragment/app/Fragment;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-virtual {v0}, Landroidx/fragment/app/Dt$KLFTb;->lgHUyS()Z

    move-result v1

    if-nez v1, :cond_0

    return-object v0

    :cond_1
    const/4 p0, 0x0

    return-object p0
.end method

.method public rkYL()V
    .locals 6

    iget-object v0, p0, Landroidx/fragment/app/Dt;->AZxh:Ljava/util/ArrayList;

    monitor-enter v0

    :try_start_0
    invoke-virtual {p0}, Landroidx/fragment/app/Dt;->qGY()V

    const/4 v1, 0x0

    iput-boolean v1, p0, Landroidx/fragment/app/Dt;->KLFTb:Z

    iget-object v1, p0, Landroidx/fragment/app/Dt;->AZxh:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    add-int/lit8 v1, v1, -0x1

    :goto_0
    if-ltz v1, :cond_1

    iget-object v2, p0, Landroidx/fragment/app/Dt;->AZxh:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroidx/fragment/app/Dt$KLFTb;

    invoke-virtual {v2}, Landroidx/fragment/app/Dt$KLFTb;->JHa()Landroidx/fragment/app/Fragment;

    move-result-object v3

    iget-object v3, v3, Landroidx/fragment/app/Fragment;->mByQ:Landroid/view/View;

    invoke-static {v3}, Landroidx/fragment/app/Dt$KLFTb$wA;->qdMbNW(Landroid/view/View;)Landroidx/fragment/app/Dt$KLFTb$wA;

    move-result-object v3

    invoke-virtual {v2}, Landroidx/fragment/app/Dt$KLFTb;->KLFTb()Landroidx/fragment/app/Dt$KLFTb$wA;

    move-result-object v4

    sget-object v5, Landroidx/fragment/app/Dt$KLFTb$wA;->AZxh:Landroidx/fragment/app/Dt$KLFTb$wA;

    if-ne v4, v5, :cond_0

    if-eq v3, v5, :cond_0

    invoke-virtual {v2}, Landroidx/fragment/app/Dt$KLFTb;->JHa()Landroidx/fragment/app/Fragment;

    move-result-object v1

    invoke-virtual {v1}, Landroidx/fragment/app/Fragment;->aqHPIZ()Z

    move-result v1

    iput-boolean v1, p0, Landroidx/fragment/app/Dt;->KLFTb:Z

    goto :goto_1

    :catchall_0
    move-exception p0

    goto :goto_2

    :cond_0
    add-int/lit8 v1, v1, -0x1

    goto :goto_0

    :cond_1
    :goto_1
    monitor-exit v0

    return-void

    :goto_2
    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw p0
.end method

.method public wA(Landroidx/fragment/app/xJ;)V
    .locals 2

    const/4 v0, 0x2

    invoke-static {v0}, Landroidx/fragment/app/KLFTb;->dm(I)Z

    move-result v0

    if-eqz v0, :cond_0

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "SpecialEffectsController: Enqueuing hide operation for fragment "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Landroidx/fragment/app/xJ;->ETF()Landroidx/fragment/app/Fragment;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "FragmentManager"

    invoke-static {v1, v0}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    :cond_0
    sget-object v0, Landroidx/fragment/app/Dt$KLFTb$wA;->wA:Landroidx/fragment/app/Dt$KLFTb$wA;

    sget-object v1, Landroidx/fragment/app/Dt$KLFTb$AZxh;->mjFkc:Landroidx/fragment/app/Dt$KLFTb$AZxh;

    invoke-virtual {p0, v0, v1, p1}, Landroidx/fragment/app/Dt;->mjFkc(Landroidx/fragment/app/Dt$KLFTb$wA;Landroidx/fragment/app/Dt$KLFTb$AZxh;Landroidx/fragment/app/xJ;)V

    return-void
.end method

.method public xJ()V
    .locals 7

    iget-boolean v0, p0, Landroidx/fragment/app/Dt;->KLFTb:Z

    if-eqz v0, :cond_0

    return-void

    :cond_0
    iget-object v0, p0, Landroidx/fragment/app/Dt;->mjFkc:Landroid/view/ViewGroup;

    invoke-static {v0}, Lo/T9;->cMLeY(Landroid/view/View;)Z

    move-result v0

    const/4 v1, 0x0

    if-nez v0, :cond_1

    invoke-virtual {p0}, Landroidx/fragment/app/Dt;->Dt()V

    iput-boolean v1, p0, Landroidx/fragment/app/Dt;->ZfxDd:Z

    return-void

    :cond_1
    iget-object v0, p0, Landroidx/fragment/app/Dt;->AZxh:Ljava/util/ArrayList;

    monitor-enter v0

    :try_start_0
    iget-object v2, p0, Landroidx/fragment/app/Dt;->AZxh:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v2

    if-nez v2, :cond_6

    new-instance v2, Ljava/util/ArrayList;

    iget-object v3, p0, Landroidx/fragment/app/Dt;->wA:Ljava/util/ArrayList;

    invoke-direct {v2, v3}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    iget-object v3, p0, Landroidx/fragment/app/Dt;->wA:Ljava/util/ArrayList;

    invoke-virtual {v3}, Ljava/util/ArrayList;->clear()V

    invoke-virtual {v2}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_2
    :goto_0
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_4

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroidx/fragment/app/Dt$KLFTb;

    const/4 v4, 0x2

    invoke-static {v4}, Landroidx/fragment/app/KLFTb;->dm(I)Z

    move-result v4

    if-eqz v4, :cond_3

    const-string v4, "FragmentManager"

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "SpecialEffectsController: Cancelling operation "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-static {v4, v5}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_1

    :catchall_0
    move-exception p0

    goto :goto_3

    :cond_3
    :goto_1
    invoke-virtual {v3}, Landroidx/fragment/app/Dt$KLFTb;->AZxh()V

    invoke-virtual {v3}, Landroidx/fragment/app/Dt$KLFTb;->qdMbNW()Z

    move-result v4

    if-nez v4, :cond_2

    iget-object v4, p0, Landroidx/fragment/app/Dt;->wA:Ljava/util/ArrayList;

    invoke-virtual {v4, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_4
    invoke-virtual {p0}, Landroidx/fragment/app/Dt;->qGY()V

    new-instance v2, Ljava/util/ArrayList;

    iget-object v3, p0, Landroidx/fragment/app/Dt;->AZxh:Ljava/util/ArrayList;

    invoke-direct {v2, v3}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    iget-object v3, p0, Landroidx/fragment/app/Dt;->AZxh:Ljava/util/ArrayList;

    invoke-virtual {v3}, Ljava/util/ArrayList;->clear()V

    iget-object v3, p0, Landroidx/fragment/app/Dt;->wA:Ljava/util/ArrayList;

    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    invoke-virtual {v2}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_2
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_5

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Landroidx/fragment/app/Dt$KLFTb;

    invoke-virtual {v4}, Landroidx/fragment/app/Dt$KLFTb;->VA()V

    goto :goto_2

    :cond_5
    iget-boolean v3, p0, Landroidx/fragment/app/Dt;->ZfxDd:Z

    invoke-virtual {p0, v2, v3}, Landroidx/fragment/app/Dt;->JHa(Ljava/util/List;Z)V

    iput-boolean v1, p0, Landroidx/fragment/app/Dt;->ZfxDd:Z

    :cond_6
    monitor-exit v0

    return-void

    :goto_3
    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw p0
.end method
