.class public interface abstract Landroidx/fragment/app/KLFTb$lgHUyS;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/fragment/app/KLFTb;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "lgHUyS"
.end annotation


# virtual methods
.method public abstract mjFkc(Ljava/util/ArrayList;Ljava/util/ArrayList;)Z
.end method
