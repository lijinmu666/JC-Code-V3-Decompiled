.class public interface abstract Landroidx/fragment/app/Fragment$ZfxDd;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/fragment/app/Fragment;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "ZfxDd"
.end annotation


# virtual methods
.method public abstract mjFkc()V
.end method
