.class public Landroidx/fragment/app/KLFTb$qdMbNW;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/fragment/app/KLFTb$lgHUyS;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/fragment/app/KLFTb;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "qdMbNW"
.end annotation


# instance fields
.field public final AZxh:I

.field public final synthetic ZfxDd:Landroidx/fragment/app/KLFTb;

.field public final mjFkc:Ljava/lang/String;

.field public final wA:I


# direct methods
.method public constructor <init>(Landroidx/fragment/app/KLFTb;Ljava/lang/String;II)V
    .locals 0

    iput-object p1, p0, Landroidx/fragment/app/KLFTb$qdMbNW;->ZfxDd:Landroidx/fragment/app/KLFTb;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p2, p0, Landroidx/fragment/app/KLFTb$qdMbNW;->mjFkc:Ljava/lang/String;

    iput p3, p0, Landroidx/fragment/app/KLFTb$qdMbNW;->AZxh:I

    iput p4, p0, Landroidx/fragment/app/KLFTb$qdMbNW;->wA:I

    return-void
.end method


# virtual methods
.method public mjFkc(Ljava/util/ArrayList;Ljava/util/ArrayList;)Z
    .locals 6

    iget-object v0, p0, Landroidx/fragment/app/KLFTb$qdMbNW;->ZfxDd:Landroidx/fragment/app/KLFTb;

    iget-object v0, v0, Landroidx/fragment/app/KLFTb;->IEE:Landroidx/fragment/app/Fragment;

    if-eqz v0, :cond_0

    iget v1, p0, Landroidx/fragment/app/KLFTb$qdMbNW;->AZxh:I

    if-gez v1, :cond_0

    iget-object v1, p0, Landroidx/fragment/app/KLFTb$qdMbNW;->mjFkc:Ljava/lang/String;

    if-nez v1, :cond_0

    invoke-virtual {v0}, Landroidx/fragment/app/Fragment;->MiMN()Landroidx/fragment/app/KLFTb;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/fragment/app/KLFTb;->yX()Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 p0, 0x0

    return p0

    :cond_0
    iget-object v0, p0, Landroidx/fragment/app/KLFTb$qdMbNW;->ZfxDd:Landroidx/fragment/app/KLFTb;

    iget-object v3, p0, Landroidx/fragment/app/KLFTb$qdMbNW;->mjFkc:Ljava/lang/String;

    iget v4, p0, Landroidx/fragment/app/KLFTb$qdMbNW;->AZxh:I

    iget v5, p0, Landroidx/fragment/app/KLFTb$qdMbNW;->wA:I

    move-object v1, p1

    move-object v2, p2

    invoke-virtual/range {v0 .. v5}, Landroidx/fragment/app/KLFTb;->LREOK(Ljava/util/ArrayList;Ljava/util/ArrayList;Ljava/lang/String;II)Z

    move-result p0

    return p0
.end method
