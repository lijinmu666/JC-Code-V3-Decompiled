.class public Landroidx/fragment/app/KLFTb$JHa;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lo/EaLbDP;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Landroidx/fragment/app/KLFTb;->lgHUyS(Lo/aAlqX;Lo/jeHSg;Landroidx/fragment/app/Fragment;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic AZxh:Landroidx/fragment/app/KLFTb;

.field public final synthetic mjFkc:Landroidx/fragment/app/Fragment;


# direct methods
.method public constructor <init>(Landroidx/fragment/app/KLFTb;Landroidx/fragment/app/Fragment;)V
    .locals 0

    iput-object p1, p0, Landroidx/fragment/app/KLFTb$JHa;->AZxh:Landroidx/fragment/app/KLFTb;

    iput-object p2, p0, Landroidx/fragment/app/KLFTb$JHa;->mjFkc:Landroidx/fragment/app/Fragment;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
