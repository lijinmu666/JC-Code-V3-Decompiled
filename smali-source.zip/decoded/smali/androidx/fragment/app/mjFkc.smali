.class public final Landroidx/fragment/app/mjFkc;
.super Landroidx/fragment/app/lgHUyS;
.source "SourceFile"

# interfaces
.implements Landroidx/fragment/app/KLFTb$lgHUyS;


# instance fields
.field public Ucbh:I

.field public final diqgf:Landroidx/fragment/app/KLFTb;

.field public eyqo:Z


# direct methods
.method public constructor <init>(Landroidx/fragment/app/KLFTb;)V
    .locals 2

    invoke-virtual {p1}, Landroidx/fragment/app/KLFTb;->JYgkl()Lo/bL;

    move-result-object v0

    invoke-virtual {p1}, Landroidx/fragment/app/KLFTb;->nxI()Lo/aAlqX;

    const/4 v1, 0x0

    invoke-direct {p0, v0, v1}, Landroidx/fragment/app/lgHUyS;-><init>(Lo/bL;Ljava/lang/ClassLoader;)V

    const/4 v0, -0x1

    iput v0, p0, Landroidx/fragment/app/mjFkc;->Ucbh:I

    iput-object p1, p0, Landroidx/fragment/app/mjFkc;->diqgf:Landroidx/fragment/app/KLFTb;

    return-void
.end method

.method public static HGpJ(Landroidx/fragment/app/lgHUyS$mjFkc;)Z
    .locals 1

    iget-object p0, p0, Landroidx/fragment/app/lgHUyS$mjFkc;->AZxh:Landroidx/fragment/app/Fragment;

    if-eqz p0, :cond_0

    iget-boolean v0, p0, Landroidx/fragment/app/Fragment;->Dt:Z

    if-eqz v0, :cond_0

    iget-object v0, p0, Landroidx/fragment/app/Fragment;->mByQ:Landroid/view/View;

    if-eqz v0, :cond_0

    iget-boolean v0, p0, Landroidx/fragment/app/Fragment;->Gd:Z

    if-nez v0, :cond_0

    iget-boolean v0, p0, Landroidx/fragment/app/Fragment;->huTpC:Z

    if-nez v0, :cond_0

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->aqHPIZ()Z

    move-result p0

    if-eqz p0, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method


# virtual methods
.method public BAnRFn(Landroidx/fragment/app/Fragment$ZfxDd;)V
    .locals 3

    const/4 v0, 0x0

    :goto_0
    iget-object v1, p0, Landroidx/fragment/app/lgHUyS;->wA:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_1

    iget-object v1, p0, Landroidx/fragment/app/lgHUyS;->wA:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroidx/fragment/app/lgHUyS$mjFkc;

    invoke-static {v1}, Landroidx/fragment/app/mjFkc;->HGpJ(Landroidx/fragment/app/lgHUyS$mjFkc;)Z

    move-result v2

    if-eqz v2, :cond_0

    iget-object v1, v1, Landroidx/fragment/app/lgHUyS$mjFkc;->AZxh:Landroidx/fragment/app/Fragment;

    invoke-virtual {v1, p1}, Landroidx/fragment/app/Fragment;->giT(Landroidx/fragment/app/Fragment$ZfxDd;)V

    :cond_0
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    return-void
.end method

.method public Dt(ILandroidx/fragment/app/Fragment;Ljava/lang/String;I)V
    .locals 0

    invoke-super {p0, p1, p2, p3, p4}, Landroidx/fragment/app/lgHUyS;->Dt(ILandroidx/fragment/app/Fragment;Ljava/lang/String;I)V

    iget-object p0, p0, Landroidx/fragment/app/mjFkc;->diqgf:Landroidx/fragment/app/KLFTb;

    iput-object p0, p2, Landroidx/fragment/app/Fragment;->fehf:Landroidx/fragment/app/KLFTb;

    return-void
.end method

.method public ETF(Landroidx/fragment/app/Fragment;)Landroidx/fragment/app/lgHUyS;
    .locals 2

    iget-object v0, p1, Landroidx/fragment/app/Fragment;->fehf:Landroidx/fragment/app/KLFTb;

    if-eqz v0, :cond_1

    iget-object v1, p0, Landroidx/fragment/app/mjFkc;->diqgf:Landroidx/fragment/app/KLFTb;

    if-ne v0, v1, :cond_0

    goto :goto_0

    :cond_0
    new-instance p0, Ljava/lang/IllegalStateException;

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "Cannot remove Fragment attached to a different FragmentManager. Fragment "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Landroidx/fragment/app/Fragment;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p1, " is already attached to a FragmentManager."

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_1
    :goto_0
    invoke-super {p0, p1}, Landroidx/fragment/app/lgHUyS;->ETF(Landroidx/fragment/app/Fragment;)Landroidx/fragment/app/lgHUyS;

    move-result-object p0

    return-object p0
.end method

.method public Gd(Ljava/util/ArrayList;II)Z
    .locals 9

    const/4 v0, 0x0

    if-ne p3, p2, :cond_0

    return v0

    :cond_0
    iget-object v1, p0, Landroidx/fragment/app/lgHUyS;->wA:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    const/4 v2, -0x1

    move v3, v0

    :goto_0
    if-ge v3, v1, :cond_7

    iget-object v4, p0, Landroidx/fragment/app/lgHUyS;->wA:Ljava/util/ArrayList;

    invoke-virtual {v4, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Landroidx/fragment/app/lgHUyS$mjFkc;

    iget-object v4, v4, Landroidx/fragment/app/lgHUyS$mjFkc;->AZxh:Landroidx/fragment/app/Fragment;

    if-eqz v4, :cond_1

    iget v4, v4, Landroidx/fragment/app/Fragment;->eyqo:I

    goto :goto_1

    :cond_1
    move v4, v0

    :goto_1
    if-eqz v4, :cond_6

    if-eq v4, v2, :cond_6

    move v2, p2

    :goto_2
    if-ge v2, p3, :cond_5

    invoke-virtual {p1, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Landroidx/fragment/app/mjFkc;

    iget-object v6, v5, Landroidx/fragment/app/lgHUyS;->wA:Ljava/util/ArrayList;

    invoke-virtual {v6}, Ljava/util/ArrayList;->size()I

    move-result v6

    move v7, v0

    :goto_3
    if-ge v7, v6, :cond_4

    iget-object v8, v5, Landroidx/fragment/app/lgHUyS;->wA:Ljava/util/ArrayList;

    invoke-virtual {v8, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Landroidx/fragment/app/lgHUyS$mjFkc;

    iget-object v8, v8, Landroidx/fragment/app/lgHUyS$mjFkc;->AZxh:Landroidx/fragment/app/Fragment;

    if-eqz v8, :cond_2

    iget v8, v8, Landroidx/fragment/app/Fragment;->eyqo:I

    goto :goto_4

    :cond_2
    move v8, v0

    :goto_4
    if-ne v8, v4, :cond_3

    const/4 p0, 0x1

    return p0

    :cond_3
    add-int/lit8 v7, v7, 0x1

    goto :goto_3

    :cond_4
    add-int/lit8 v2, v2, 0x1

    goto :goto_2

    :cond_5
    move v2, v4

    :cond_6
    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    :cond_7
    return v0
.end method

.method public IEE(Ljava/lang/String;Ljava/io/PrintWriter;Z)V
    .locals 5

    if-eqz p3, :cond_8

    invoke-virtual {p2, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v0, "mName="

    invoke-virtual {p2, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget-object v0, p0, Landroidx/fragment/app/lgHUyS;->ETF:Ljava/lang/String;

    invoke-virtual {p2, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v0, " mIndex="

    invoke-virtual {p2, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget v0, p0, Landroidx/fragment/app/mjFkc;->Ucbh:I

    invoke-virtual {p2, v0}, Ljava/io/PrintWriter;->print(I)V

    const-string v0, " mCommitted="

    invoke-virtual {p2, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget-boolean v0, p0, Landroidx/fragment/app/mjFkc;->eyqo:Z

    invoke-virtual {p2, v0}, Ljava/io/PrintWriter;->println(Z)V

    iget v0, p0, Landroidx/fragment/app/lgHUyS;->lgHUyS:I

    if-eqz v0, :cond_0

    invoke-virtual {p2, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v0, "mTransition=#"

    invoke-virtual {p2, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget v0, p0, Landroidx/fragment/app/lgHUyS;->lgHUyS:I

    invoke-static {v0}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p2, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    :cond_0
    iget v0, p0, Landroidx/fragment/app/lgHUyS;->ZfxDd:I

    if-nez v0, :cond_1

    iget v0, p0, Landroidx/fragment/app/lgHUyS;->KLFTb:I

    if-eqz v0, :cond_2

    :cond_1
    invoke-virtual {p2, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v0, "mEnterAnim=#"

    invoke-virtual {p2, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget v0, p0, Landroidx/fragment/app/lgHUyS;->ZfxDd:I

    invoke-static {v0}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p2, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v0, " mExitAnim=#"

    invoke-virtual {p2, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget v0, p0, Landroidx/fragment/app/lgHUyS;->KLFTb:I

    invoke-static {v0}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p2, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    :cond_2
    iget v0, p0, Landroidx/fragment/app/lgHUyS;->JHa:I

    if-nez v0, :cond_3

    iget v0, p0, Landroidx/fragment/app/lgHUyS;->xJ:I

    if-eqz v0, :cond_4

    :cond_3
    invoke-virtual {p2, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v0, "mPopEnterAnim=#"

    invoke-virtual {p2, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget v0, p0, Landroidx/fragment/app/lgHUyS;->JHa:I

    invoke-static {v0}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p2, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v0, " mPopExitAnim=#"

    invoke-virtual {p2, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget v0, p0, Landroidx/fragment/app/lgHUyS;->xJ:I

    invoke-static {v0}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p2, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    :cond_4
    iget v0, p0, Landroidx/fragment/app/lgHUyS;->VA:I

    if-nez v0, :cond_5

    iget-object v0, p0, Landroidx/fragment/app/lgHUyS;->MiMN:Ljava/lang/CharSequence;

    if-eqz v0, :cond_6

    :cond_5
    invoke-virtual {p2, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v0, "mBreadCrumbTitleRes=#"

    invoke-virtual {p2, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget v0, p0, Landroidx/fragment/app/lgHUyS;->VA:I

    invoke-static {v0}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p2, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v0, " mBreadCrumbTitleText="

    invoke-virtual {p2, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget-object v0, p0, Landroidx/fragment/app/lgHUyS;->MiMN:Ljava/lang/CharSequence;

    invoke-virtual {p2, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/Object;)V

    :cond_6
    iget v0, p0, Landroidx/fragment/app/lgHUyS;->YoKzxo:I

    if-nez v0, :cond_7

    iget-object v0, p0, Landroidx/fragment/app/lgHUyS;->rkYL:Ljava/lang/CharSequence;

    if-eqz v0, :cond_8

    :cond_7
    invoke-virtual {p2, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v0, "mBreadCrumbShortTitleRes=#"

    invoke-virtual {p2, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget v0, p0, Landroidx/fragment/app/lgHUyS;->YoKzxo:I

    invoke-static {v0}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p2, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v0, " mBreadCrumbShortTitleText="

    invoke-virtual {p2, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget-object v0, p0, Landroidx/fragment/app/lgHUyS;->rkYL:Ljava/lang/CharSequence;

    invoke-virtual {p2, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/Object;)V

    :cond_8
    iget-object v0, p0, Landroidx/fragment/app/lgHUyS;->wA:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_d

    invoke-virtual {p2, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v0, "Operations:"

    invoke-virtual {p2, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    iget-object v0, p0, Landroidx/fragment/app/lgHUyS;->wA:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v1, 0x0

    :goto_0
    if-ge v1, v0, :cond_d

    iget-object v2, p0, Landroidx/fragment/app/lgHUyS;->wA:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroidx/fragment/app/lgHUyS$mjFkc;

    iget v3, v2, Landroidx/fragment/app/lgHUyS$mjFkc;->mjFkc:I

    packed-switch v3, :pswitch_data_0

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "cmd="

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v4, v2, Landroidx/fragment/app/lgHUyS$mjFkc;->mjFkc:I

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    goto :goto_1

    :pswitch_0
    const-string v3, "OP_SET_MAX_LIFECYCLE"

    goto :goto_1

    :pswitch_1
    const-string v3, "UNSET_PRIMARY_NAV"

    goto :goto_1

    :pswitch_2
    const-string v3, "SET_PRIMARY_NAV"

    goto :goto_1

    :pswitch_3
    const-string v3, "ATTACH"

    goto :goto_1

    :pswitch_4
    const-string v3, "DETACH"

    goto :goto_1

    :pswitch_5
    const-string v3, "SHOW"

    goto :goto_1

    :pswitch_6
    const-string v3, "HIDE"

    goto :goto_1

    :pswitch_7
    const-string v3, "REMOVE"

    goto :goto_1

    :pswitch_8
    const-string v3, "REPLACE"

    goto :goto_1

    :pswitch_9
    const-string v3, "ADD"

    goto :goto_1

    :pswitch_a
    const-string v3, "NULL"

    :goto_1
    invoke-virtual {p2, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v4, "  Op #"

    invoke-virtual {p2, v4}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    invoke-virtual {p2, v1}, Ljava/io/PrintWriter;->print(I)V

    const-string v4, ": "

    invoke-virtual {p2, v4}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    invoke-virtual {p2, v3}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v3, " "

    invoke-virtual {p2, v3}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget-object v3, v2, Landroidx/fragment/app/lgHUyS$mjFkc;->AZxh:Landroidx/fragment/app/Fragment;

    invoke-virtual {p2, v3}, Ljava/io/PrintWriter;->println(Ljava/lang/Object;)V

    if-eqz p3, :cond_c

    iget v3, v2, Landroidx/fragment/app/lgHUyS$mjFkc;->wA:I

    if-nez v3, :cond_9

    iget v3, v2, Landroidx/fragment/app/lgHUyS$mjFkc;->ZfxDd:I

    if-eqz v3, :cond_a

    :cond_9
    invoke-virtual {p2, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v3, "enterAnim=#"

    invoke-virtual {p2, v3}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget v3, v2, Landroidx/fragment/app/lgHUyS$mjFkc;->wA:I

    invoke-static {v3}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {p2, v3}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v3, " exitAnim=#"

    invoke-virtual {p2, v3}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget v3, v2, Landroidx/fragment/app/lgHUyS$mjFkc;->ZfxDd:I

    invoke-static {v3}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {p2, v3}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    :cond_a
    iget v3, v2, Landroidx/fragment/app/lgHUyS$mjFkc;->KLFTb:I

    if-nez v3, :cond_b

    iget v3, v2, Landroidx/fragment/app/lgHUyS$mjFkc;->JHa:I

    if-eqz v3, :cond_c

    :cond_b
    invoke-virtual {p2, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v3, "popEnterAnim=#"

    invoke-virtual {p2, v3}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget v3, v2, Landroidx/fragment/app/lgHUyS$mjFkc;->KLFTb:I

    invoke-static {v3}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {p2, v3}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v3, " popExitAnim=#"

    invoke-virtual {p2, v3}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget v2, v2, Landroidx/fragment/app/lgHUyS$mjFkc;->JHa:I

    invoke-static {v2}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {p2, v2}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    :cond_c
    add-int/lit8 v1, v1, 0x1

    goto/16 :goto_0

    :cond_d
    return-void

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public JHa()I
    .locals 1

    const/4 v0, 0x1

    invoke-virtual {p0, v0}, Landroidx/fragment/app/mjFkc;->qGY(Z)I

    move-result p0

    return p0
.end method

.method public KLFTb()I
    .locals 1

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Landroidx/fragment/app/mjFkc;->qGY(Z)I

    move-result p0

    return p0
.end method

.method public Pq()V
    .locals 10

    iget-object v0, p0, Landroidx/fragment/app/lgHUyS;->wA:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v1, 0x0

    move v2, v1

    :goto_0
    const/4 v3, 0x1

    if-ge v2, v0, :cond_2

    iget-object v4, p0, Landroidx/fragment/app/lgHUyS;->wA:Ljava/util/ArrayList;

    invoke-virtual {v4, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Landroidx/fragment/app/lgHUyS$mjFkc;

    iget-object v5, v4, Landroidx/fragment/app/lgHUyS$mjFkc;->AZxh:Landroidx/fragment/app/Fragment;

    if-eqz v5, :cond_0

    invoke-virtual {v5, v1}, Landroidx/fragment/app/Fragment;->sRqPfw(Z)V

    iget v6, p0, Landroidx/fragment/app/lgHUyS;->lgHUyS:I

    invoke-virtual {v5, v6}, Landroidx/fragment/app/Fragment;->lti(I)V

    iget-object v6, p0, Landroidx/fragment/app/lgHUyS;->qGY:Ljava/util/ArrayList;

    iget-object v7, p0, Landroidx/fragment/app/lgHUyS;->fehf:Ljava/util/ArrayList;

    invoke-virtual {v5, v6, v7}, Landroidx/fragment/app/Fragment;->gtr(Ljava/util/ArrayList;Ljava/util/ArrayList;)V

    :cond_0
    iget v6, v4, Landroidx/fragment/app/lgHUyS$mjFkc;->mjFkc:I

    packed-switch v6, :pswitch_data_0

    :pswitch_0
    new-instance p0, Ljava/lang/IllegalArgumentException;

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "Unknown cmd: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, v4, Landroidx/fragment/app/lgHUyS$mjFkc;->mjFkc:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0

    :pswitch_1
    iget-object v6, p0, Landroidx/fragment/app/mjFkc;->diqgf:Landroidx/fragment/app/KLFTb;

    iget-object v7, v4, Landroidx/fragment/app/lgHUyS$mjFkc;->lgHUyS:Landroidx/lifecycle/wA$AZxh;

    invoke-virtual {v6, v5, v7}, Landroidx/fragment/app/KLFTb;->Vgyli(Landroidx/fragment/app/Fragment;Landroidx/lifecycle/wA$AZxh;)V

    goto/16 :goto_1

    :pswitch_2
    iget-object v6, p0, Landroidx/fragment/app/mjFkc;->diqgf:Landroidx/fragment/app/KLFTb;

    const/4 v7, 0x0

    invoke-virtual {v6, v7}, Landroidx/fragment/app/KLFTb;->lti(Landroidx/fragment/app/Fragment;)V

    goto/16 :goto_1

    :pswitch_3
    iget-object v6, p0, Landroidx/fragment/app/mjFkc;->diqgf:Landroidx/fragment/app/KLFTb;

    invoke-virtual {v6, v5}, Landroidx/fragment/app/KLFTb;->lti(Landroidx/fragment/app/Fragment;)V

    goto/16 :goto_1

    :pswitch_4
    iget v6, v4, Landroidx/fragment/app/lgHUyS$mjFkc;->wA:I

    iget v7, v4, Landroidx/fragment/app/lgHUyS$mjFkc;->ZfxDd:I

    iget v8, v4, Landroidx/fragment/app/lgHUyS$mjFkc;->KLFTb:I

    iget v9, v4, Landroidx/fragment/app/lgHUyS$mjFkc;->JHa:I

    invoke-virtual {v5, v6, v7, v8, v9}, Landroidx/fragment/app/Fragment;->uH(IIII)V

    iget-object v6, p0, Landroidx/fragment/app/mjFkc;->diqgf:Landroidx/fragment/app/KLFTb;

    invoke-virtual {v6, v5, v1}, Landroidx/fragment/app/KLFTb;->tISON(Landroidx/fragment/app/Fragment;Z)V

    iget-object v6, p0, Landroidx/fragment/app/mjFkc;->diqgf:Landroidx/fragment/app/KLFTb;

    invoke-virtual {v6, v5}, Landroidx/fragment/app/KLFTb;->qdMbNW(Landroidx/fragment/app/Fragment;)V

    goto :goto_1

    :pswitch_5
    iget v6, v4, Landroidx/fragment/app/lgHUyS$mjFkc;->wA:I

    iget v7, v4, Landroidx/fragment/app/lgHUyS$mjFkc;->ZfxDd:I

    iget v8, v4, Landroidx/fragment/app/lgHUyS$mjFkc;->KLFTb:I

    iget v9, v4, Landroidx/fragment/app/lgHUyS$mjFkc;->JHa:I

    invoke-virtual {v5, v6, v7, v8, v9}, Landroidx/fragment/app/Fragment;->uH(IIII)V

    iget-object v6, p0, Landroidx/fragment/app/mjFkc;->diqgf:Landroidx/fragment/app/KLFTb;

    invoke-virtual {v6, v5}, Landroidx/fragment/app/KLFTb;->diqgf(Landroidx/fragment/app/Fragment;)V

    goto :goto_1

    :pswitch_6
    iget v6, v4, Landroidx/fragment/app/lgHUyS$mjFkc;->wA:I

    iget v7, v4, Landroidx/fragment/app/lgHUyS$mjFkc;->ZfxDd:I

    iget v8, v4, Landroidx/fragment/app/lgHUyS$mjFkc;->KLFTb:I

    iget v9, v4, Landroidx/fragment/app/lgHUyS$mjFkc;->JHa:I

    invoke-virtual {v5, v6, v7, v8, v9}, Landroidx/fragment/app/Fragment;->uH(IIII)V

    iget-object v6, p0, Landroidx/fragment/app/mjFkc;->diqgf:Landroidx/fragment/app/KLFTb;

    invoke-virtual {v6, v5, v1}, Landroidx/fragment/app/KLFTb;->tISON(Landroidx/fragment/app/Fragment;Z)V

    iget-object v6, p0, Landroidx/fragment/app/mjFkc;->diqgf:Landroidx/fragment/app/KLFTb;

    invoke-virtual {v6, v5}, Landroidx/fragment/app/KLFTb;->sRqPfw(Landroidx/fragment/app/Fragment;)V

    goto :goto_1

    :pswitch_7
    iget v6, v4, Landroidx/fragment/app/lgHUyS$mjFkc;->wA:I

    iget v7, v4, Landroidx/fragment/app/lgHUyS$mjFkc;->ZfxDd:I

    iget v8, v4, Landroidx/fragment/app/lgHUyS$mjFkc;->KLFTb:I

    iget v9, v4, Landroidx/fragment/app/lgHUyS$mjFkc;->JHa:I

    invoke-virtual {v5, v6, v7, v8, v9}, Landroidx/fragment/app/Fragment;->uH(IIII)V

    iget-object v6, p0, Landroidx/fragment/app/mjFkc;->diqgf:Landroidx/fragment/app/KLFTb;

    invoke-virtual {v6, v5}, Landroidx/fragment/app/KLFTb;->jm(Landroidx/fragment/app/Fragment;)V

    goto :goto_1

    :pswitch_8
    iget v6, v4, Landroidx/fragment/app/lgHUyS$mjFkc;->wA:I

    iget v7, v4, Landroidx/fragment/app/lgHUyS$mjFkc;->ZfxDd:I

    iget v8, v4, Landroidx/fragment/app/lgHUyS$mjFkc;->KLFTb:I

    iget v9, v4, Landroidx/fragment/app/lgHUyS$mjFkc;->JHa:I

    invoke-virtual {v5, v6, v7, v8, v9}, Landroidx/fragment/app/Fragment;->uH(IIII)V

    iget-object v6, p0, Landroidx/fragment/app/mjFkc;->diqgf:Landroidx/fragment/app/KLFTb;

    invoke-virtual {v6, v5}, Landroidx/fragment/app/KLFTb;->XbiWeM(Landroidx/fragment/app/Fragment;)V

    goto :goto_1

    :pswitch_9
    iget v6, v4, Landroidx/fragment/app/lgHUyS$mjFkc;->wA:I

    iget v7, v4, Landroidx/fragment/app/lgHUyS$mjFkc;->ZfxDd:I

    iget v8, v4, Landroidx/fragment/app/lgHUyS$mjFkc;->KLFTb:I

    iget v9, v4, Landroidx/fragment/app/lgHUyS$mjFkc;->JHa:I

    invoke-virtual {v5, v6, v7, v8, v9}, Landroidx/fragment/app/Fragment;->uH(IIII)V

    iget-object v6, p0, Landroidx/fragment/app/mjFkc;->diqgf:Landroidx/fragment/app/KLFTb;

    invoke-virtual {v6, v5, v1}, Landroidx/fragment/app/KLFTb;->tISON(Landroidx/fragment/app/Fragment;Z)V

    iget-object v6, p0, Landroidx/fragment/app/mjFkc;->diqgf:Landroidx/fragment/app/KLFTb;

    invoke-virtual {v6, v5}, Landroidx/fragment/app/KLFTb;->KLFTb(Landroidx/fragment/app/Fragment;)Landroidx/fragment/app/xJ;

    :goto_1
    iget-boolean v6, p0, Landroidx/fragment/app/lgHUyS;->IEE:Z

    if-nez v6, :cond_1

    iget v4, v4, Landroidx/fragment/app/lgHUyS$mjFkc;->mjFkc:I

    if-eq v4, v3, :cond_1

    if-eqz v5, :cond_1

    sget-boolean v3, Landroidx/fragment/app/KLFTb;->KLMXS:Z

    if-nez v3, :cond_1

    iget-object v3, p0, Landroidx/fragment/app/mjFkc;->diqgf:Landroidx/fragment/app/KLFTb;

    invoke-virtual {v3, v5}, Landroidx/fragment/app/KLFTb;->Moer(Landroidx/fragment/app/Fragment;)V

    :cond_1
    add-int/lit8 v2, v2, 0x1

    goto/16 :goto_0

    :cond_2
    iget-boolean v0, p0, Landroidx/fragment/app/lgHUyS;->IEE:Z

    if-nez v0, :cond_3

    sget-boolean v0, Landroidx/fragment/app/KLFTb;->KLMXS:Z

    if-nez v0, :cond_3

    iget-object p0, p0, Landroidx/fragment/app/mjFkc;->diqgf:Landroidx/fragment/app/KLFTb;

    iget v0, p0, Landroidx/fragment/app/KLFTb;->rkYL:I

    invoke-virtual {p0, v0, v3}, Landroidx/fragment/app/KLFTb;->SmIWf(IZ)V

    :cond_3
    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_9
        :pswitch_0
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
    .end packed-switch
.end method

.method public Ucbh()Ljava/lang/String;
    .locals 0

    iget-object p0, p0, Landroidx/fragment/app/lgHUyS;->ETF:Ljava/lang/String;

    return-object p0
.end method

.method public VocHEe()V
    .locals 2

    iget-object v0, p0, Landroidx/fragment/app/lgHUyS;->Pq:Ljava/util/ArrayList;

    if-eqz v0, :cond_1

    const/4 v0, 0x0

    :goto_0
    iget-object v1, p0, Landroidx/fragment/app/lgHUyS;->Pq:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_0

    iget-object v1, p0, Landroidx/fragment/app/lgHUyS;->Pq:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Runnable;

    invoke-interface {v1}, Ljava/lang/Runnable;->run()V

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    iput-object v0, p0, Landroidx/fragment/app/lgHUyS;->Pq:Ljava/util/ArrayList;

    :cond_1
    return-void
.end method

.method public diqgf(Z)V
    .locals 8

    iget-object v0, p0, Landroidx/fragment/app/lgHUyS;->wA:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v1, 0x1

    sub-int/2addr v0, v1

    :goto_0
    if-ltz v0, :cond_2

    iget-object v2, p0, Landroidx/fragment/app/lgHUyS;->wA:Ljava/util/ArrayList;

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroidx/fragment/app/lgHUyS$mjFkc;

    iget-object v3, v2, Landroidx/fragment/app/lgHUyS$mjFkc;->AZxh:Landroidx/fragment/app/Fragment;

    if-eqz v3, :cond_0

    invoke-virtual {v3, v1}, Landroidx/fragment/app/Fragment;->sRqPfw(Z)V

    iget v4, p0, Landroidx/fragment/app/lgHUyS;->lgHUyS:I

    invoke-static {v4}, Landroidx/fragment/app/KLFTb;->uH(I)I

    move-result v4

    invoke-virtual {v3, v4}, Landroidx/fragment/app/Fragment;->lti(I)V

    iget-object v4, p0, Landroidx/fragment/app/lgHUyS;->fehf:Ljava/util/ArrayList;

    iget-object v5, p0, Landroidx/fragment/app/lgHUyS;->qGY:Ljava/util/ArrayList;

    invoke-virtual {v3, v4, v5}, Landroidx/fragment/app/Fragment;->gtr(Ljava/util/ArrayList;Ljava/util/ArrayList;)V

    :cond_0
    iget v4, v2, Landroidx/fragment/app/lgHUyS$mjFkc;->mjFkc:I

    packed-switch v4, :pswitch_data_0

    :pswitch_0
    new-instance p0, Ljava/lang/IllegalArgumentException;

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v0, "Unknown cmd: "

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v0, v2, Landroidx/fragment/app/lgHUyS$mjFkc;->mjFkc:I

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0

    :pswitch_1
    iget-object v4, p0, Landroidx/fragment/app/mjFkc;->diqgf:Landroidx/fragment/app/KLFTb;

    iget-object v5, v2, Landroidx/fragment/app/lgHUyS$mjFkc;->xJ:Landroidx/lifecycle/wA$AZxh;

    invoke-virtual {v4, v3, v5}, Landroidx/fragment/app/KLFTb;->Vgyli(Landroidx/fragment/app/Fragment;Landroidx/lifecycle/wA$AZxh;)V

    goto/16 :goto_1

    :pswitch_2
    iget-object v4, p0, Landroidx/fragment/app/mjFkc;->diqgf:Landroidx/fragment/app/KLFTb;

    invoke-virtual {v4, v3}, Landroidx/fragment/app/KLFTb;->lti(Landroidx/fragment/app/Fragment;)V

    goto/16 :goto_1

    :pswitch_3
    iget-object v4, p0, Landroidx/fragment/app/mjFkc;->diqgf:Landroidx/fragment/app/KLFTb;

    const/4 v5, 0x0

    invoke-virtual {v4, v5}, Landroidx/fragment/app/KLFTb;->lti(Landroidx/fragment/app/Fragment;)V

    goto/16 :goto_1

    :pswitch_4
    iget v4, v2, Landroidx/fragment/app/lgHUyS$mjFkc;->wA:I

    iget v5, v2, Landroidx/fragment/app/lgHUyS$mjFkc;->ZfxDd:I

    iget v6, v2, Landroidx/fragment/app/lgHUyS$mjFkc;->KLFTb:I

    iget v7, v2, Landroidx/fragment/app/lgHUyS$mjFkc;->JHa:I

    invoke-virtual {v3, v4, v5, v6, v7}, Landroidx/fragment/app/Fragment;->uH(IIII)V

    iget-object v4, p0, Landroidx/fragment/app/mjFkc;->diqgf:Landroidx/fragment/app/KLFTb;

    invoke-virtual {v4, v3, v1}, Landroidx/fragment/app/KLFTb;->tISON(Landroidx/fragment/app/Fragment;Z)V

    iget-object v4, p0, Landroidx/fragment/app/mjFkc;->diqgf:Landroidx/fragment/app/KLFTb;

    invoke-virtual {v4, v3}, Landroidx/fragment/app/KLFTb;->diqgf(Landroidx/fragment/app/Fragment;)V

    goto :goto_1

    :pswitch_5
    iget v4, v2, Landroidx/fragment/app/lgHUyS$mjFkc;->wA:I

    iget v5, v2, Landroidx/fragment/app/lgHUyS$mjFkc;->ZfxDd:I

    iget v6, v2, Landroidx/fragment/app/lgHUyS$mjFkc;->KLFTb:I

    iget v7, v2, Landroidx/fragment/app/lgHUyS$mjFkc;->JHa:I

    invoke-virtual {v3, v4, v5, v6, v7}, Landroidx/fragment/app/Fragment;->uH(IIII)V

    iget-object v4, p0, Landroidx/fragment/app/mjFkc;->diqgf:Landroidx/fragment/app/KLFTb;

    invoke-virtual {v4, v3}, Landroidx/fragment/app/KLFTb;->qdMbNW(Landroidx/fragment/app/Fragment;)V

    goto :goto_1

    :pswitch_6
    iget v4, v2, Landroidx/fragment/app/lgHUyS$mjFkc;->wA:I

    iget v5, v2, Landroidx/fragment/app/lgHUyS$mjFkc;->ZfxDd:I

    iget v6, v2, Landroidx/fragment/app/lgHUyS$mjFkc;->KLFTb:I

    iget v7, v2, Landroidx/fragment/app/lgHUyS$mjFkc;->JHa:I

    invoke-virtual {v3, v4, v5, v6, v7}, Landroidx/fragment/app/Fragment;->uH(IIII)V

    iget-object v4, p0, Landroidx/fragment/app/mjFkc;->diqgf:Landroidx/fragment/app/KLFTb;

    invoke-virtual {v4, v3, v1}, Landroidx/fragment/app/KLFTb;->tISON(Landroidx/fragment/app/Fragment;Z)V

    iget-object v4, p0, Landroidx/fragment/app/mjFkc;->diqgf:Landroidx/fragment/app/KLFTb;

    invoke-virtual {v4, v3}, Landroidx/fragment/app/KLFTb;->jm(Landroidx/fragment/app/Fragment;)V

    goto :goto_1

    :pswitch_7
    iget v4, v2, Landroidx/fragment/app/lgHUyS$mjFkc;->wA:I

    iget v5, v2, Landroidx/fragment/app/lgHUyS$mjFkc;->ZfxDd:I

    iget v6, v2, Landroidx/fragment/app/lgHUyS$mjFkc;->KLFTb:I

    iget v7, v2, Landroidx/fragment/app/lgHUyS$mjFkc;->JHa:I

    invoke-virtual {v3, v4, v5, v6, v7}, Landroidx/fragment/app/Fragment;->uH(IIII)V

    iget-object v4, p0, Landroidx/fragment/app/mjFkc;->diqgf:Landroidx/fragment/app/KLFTb;

    invoke-virtual {v4, v3}, Landroidx/fragment/app/KLFTb;->sRqPfw(Landroidx/fragment/app/Fragment;)V

    goto :goto_1

    :pswitch_8
    iget v4, v2, Landroidx/fragment/app/lgHUyS$mjFkc;->wA:I

    iget v5, v2, Landroidx/fragment/app/lgHUyS$mjFkc;->ZfxDd:I

    iget v6, v2, Landroidx/fragment/app/lgHUyS$mjFkc;->KLFTb:I

    iget v7, v2, Landroidx/fragment/app/lgHUyS$mjFkc;->JHa:I

    invoke-virtual {v3, v4, v5, v6, v7}, Landroidx/fragment/app/Fragment;->uH(IIII)V

    iget-object v4, p0, Landroidx/fragment/app/mjFkc;->diqgf:Landroidx/fragment/app/KLFTb;

    invoke-virtual {v4, v3}, Landroidx/fragment/app/KLFTb;->KLFTb(Landroidx/fragment/app/Fragment;)Landroidx/fragment/app/xJ;

    goto :goto_1

    :pswitch_9
    iget v4, v2, Landroidx/fragment/app/lgHUyS$mjFkc;->wA:I

    iget v5, v2, Landroidx/fragment/app/lgHUyS$mjFkc;->ZfxDd:I

    iget v6, v2, Landroidx/fragment/app/lgHUyS$mjFkc;->KLFTb:I

    iget v7, v2, Landroidx/fragment/app/lgHUyS$mjFkc;->JHa:I

    invoke-virtual {v3, v4, v5, v6, v7}, Landroidx/fragment/app/Fragment;->uH(IIII)V

    iget-object v4, p0, Landroidx/fragment/app/mjFkc;->diqgf:Landroidx/fragment/app/KLFTb;

    invoke-virtual {v4, v3, v1}, Landroidx/fragment/app/KLFTb;->tISON(Landroidx/fragment/app/Fragment;Z)V

    iget-object v4, p0, Landroidx/fragment/app/mjFkc;->diqgf:Landroidx/fragment/app/KLFTb;

    invoke-virtual {v4, v3}, Landroidx/fragment/app/KLFTb;->XbiWeM(Landroidx/fragment/app/Fragment;)V

    :goto_1
    iget-boolean v4, p0, Landroidx/fragment/app/lgHUyS;->IEE:Z

    if-nez v4, :cond_1

    iget v2, v2, Landroidx/fragment/app/lgHUyS$mjFkc;->mjFkc:I

    const/4 v4, 0x3

    if-eq v2, v4, :cond_1

    if-eqz v3, :cond_1

    sget-boolean v2, Landroidx/fragment/app/KLFTb;->KLMXS:Z

    if-nez v2, :cond_1

    iget-object v2, p0, Landroidx/fragment/app/mjFkc;->diqgf:Landroidx/fragment/app/KLFTb;

    invoke-virtual {v2, v3}, Landroidx/fragment/app/KLFTb;->Moer(Landroidx/fragment/app/Fragment;)V

    :cond_1
    add-int/lit8 v0, v0, -0x1

    goto/16 :goto_0

    :cond_2
    iget-boolean v0, p0, Landroidx/fragment/app/lgHUyS;->IEE:Z

    if-nez v0, :cond_3

    if-eqz p1, :cond_3

    sget-boolean p1, Landroidx/fragment/app/KLFTb;->KLMXS:Z

    if-nez p1, :cond_3

    iget-object p0, p0, Landroidx/fragment/app/mjFkc;->diqgf:Landroidx/fragment/app/KLFTb;

    iget p1, p0, Landroidx/fragment/app/KLFTb;->rkYL:I

    invoke-virtual {p0, p1, v1}, Landroidx/fragment/app/KLFTb;->SmIWf(IZ)V

    :cond_3
    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_9
        :pswitch_0
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
    .end packed-switch
.end method

.method public eyqo(Ljava/util/ArrayList;Landroidx/fragment/app/Fragment;)Landroidx/fragment/app/Fragment;
    .locals 16

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v3, p2

    const/4 v4, 0x0

    :goto_0
    iget-object v5, v0, Landroidx/fragment/app/lgHUyS;->wA:Ljava/util/ArrayList;

    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    move-result v5

    if-ge v4, v5, :cond_a

    iget-object v5, v0, Landroidx/fragment/app/lgHUyS;->wA:Ljava/util/ArrayList;

    invoke-virtual {v5, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Landroidx/fragment/app/lgHUyS$mjFkc;

    iget v6, v5, Landroidx/fragment/app/lgHUyS$mjFkc;->mjFkc:I

    const/4 v7, 0x1

    if-eq v6, v7, :cond_8

    const/4 v8, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x3

    const/16 v11, 0x9

    if-eq v6, v8, :cond_2

    if-eq v6, v10, :cond_1

    const/4 v8, 0x6

    if-eq v6, v8, :cond_1

    const/4 v8, 0x7

    if-eq v6, v8, :cond_8

    const/16 v8, 0x8

    if-eq v6, v8, :cond_0

    goto/16 :goto_3

    :cond_0
    iget-object v6, v0, Landroidx/fragment/app/lgHUyS;->wA:Ljava/util/ArrayList;

    new-instance v8, Landroidx/fragment/app/lgHUyS$mjFkc;

    invoke-direct {v8, v11, v3}, Landroidx/fragment/app/lgHUyS$mjFkc;-><init>(ILandroidx/fragment/app/Fragment;)V

    invoke-virtual {v6, v4, v8}, Ljava/util/ArrayList;->add(ILjava/lang/Object;)V

    add-int/lit8 v4, v4, 0x1

    iget-object v3, v5, Landroidx/fragment/app/lgHUyS$mjFkc;->AZxh:Landroidx/fragment/app/Fragment;

    goto/16 :goto_3

    :cond_1
    iget-object v6, v5, Landroidx/fragment/app/lgHUyS$mjFkc;->AZxh:Landroidx/fragment/app/Fragment;

    invoke-virtual {v1, v6}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    iget-object v5, v5, Landroidx/fragment/app/lgHUyS$mjFkc;->AZxh:Landroidx/fragment/app/Fragment;

    if-ne v5, v3, :cond_9

    iget-object v3, v0, Landroidx/fragment/app/lgHUyS;->wA:Ljava/util/ArrayList;

    new-instance v6, Landroidx/fragment/app/lgHUyS$mjFkc;

    invoke-direct {v6, v11, v5}, Landroidx/fragment/app/lgHUyS$mjFkc;-><init>(ILandroidx/fragment/app/Fragment;)V

    invoke-virtual {v3, v4, v6}, Ljava/util/ArrayList;->add(ILjava/lang/Object;)V

    add-int/lit8 v4, v4, 0x1

    move-object v3, v9

    goto :goto_3

    :cond_2
    iget-object v6, v5, Landroidx/fragment/app/lgHUyS$mjFkc;->AZxh:Landroidx/fragment/app/Fragment;

    iget v8, v6, Landroidx/fragment/app/Fragment;->eyqo:I

    invoke-virtual/range {p1 .. p1}, Ljava/util/ArrayList;->size()I

    move-result v12

    sub-int/2addr v12, v7

    const/4 v13, 0x0

    :goto_1
    if-ltz v12, :cond_6

    invoke-virtual {v1, v12}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v14

    check-cast v14, Landroidx/fragment/app/Fragment;

    iget v15, v14, Landroidx/fragment/app/Fragment;->eyqo:I

    if-ne v15, v8, :cond_5

    if-ne v14, v6, :cond_3

    move v13, v7

    goto :goto_2

    :cond_3
    if-ne v14, v3, :cond_4

    iget-object v3, v0, Landroidx/fragment/app/lgHUyS;->wA:Ljava/util/ArrayList;

    new-instance v15, Landroidx/fragment/app/lgHUyS$mjFkc;

    invoke-direct {v15, v11, v14}, Landroidx/fragment/app/lgHUyS$mjFkc;-><init>(ILandroidx/fragment/app/Fragment;)V

    invoke-virtual {v3, v4, v15}, Ljava/util/ArrayList;->add(ILjava/lang/Object;)V

    add-int/lit8 v4, v4, 0x1

    move-object v3, v9

    :cond_4
    new-instance v15, Landroidx/fragment/app/lgHUyS$mjFkc;

    invoke-direct {v15, v10, v14}, Landroidx/fragment/app/lgHUyS$mjFkc;-><init>(ILandroidx/fragment/app/Fragment;)V

    iget v2, v5, Landroidx/fragment/app/lgHUyS$mjFkc;->wA:I

    iput v2, v15, Landroidx/fragment/app/lgHUyS$mjFkc;->wA:I

    iget v2, v5, Landroidx/fragment/app/lgHUyS$mjFkc;->KLFTb:I

    iput v2, v15, Landroidx/fragment/app/lgHUyS$mjFkc;->KLFTb:I

    iget v2, v5, Landroidx/fragment/app/lgHUyS$mjFkc;->ZfxDd:I

    iput v2, v15, Landroidx/fragment/app/lgHUyS$mjFkc;->ZfxDd:I

    iget v2, v5, Landroidx/fragment/app/lgHUyS$mjFkc;->JHa:I

    iput v2, v15, Landroidx/fragment/app/lgHUyS$mjFkc;->JHa:I

    iget-object v2, v0, Landroidx/fragment/app/lgHUyS;->wA:Ljava/util/ArrayList;

    invoke-virtual {v2, v4, v15}, Ljava/util/ArrayList;->add(ILjava/lang/Object;)V

    invoke-virtual {v1, v14}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    add-int/2addr v4, v7

    :cond_5
    :goto_2
    add-int/lit8 v12, v12, -0x1

    goto :goto_1

    :cond_6
    if-eqz v13, :cond_7

    iget-object v2, v0, Landroidx/fragment/app/lgHUyS;->wA:Ljava/util/ArrayList;

    invoke-virtual {v2, v4}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    add-int/lit8 v4, v4, -0x1

    goto :goto_3

    :cond_7
    iput v7, v5, Landroidx/fragment/app/lgHUyS$mjFkc;->mjFkc:I

    invoke-virtual {v1, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_3

    :cond_8
    iget-object v2, v5, Landroidx/fragment/app/lgHUyS$mjFkc;->AZxh:Landroidx/fragment/app/Fragment;

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_9
    :goto_3
    add-int/2addr v4, v7

    goto/16 :goto_0

    :cond_a
    return-object v3
.end method

.method public fehf(Ljava/lang/String;Ljava/io/PrintWriter;)V
    .locals 1

    const/4 v0, 0x1

    invoke-virtual {p0, p1, p2, v0}, Landroidx/fragment/app/mjFkc;->IEE(Ljava/lang/String;Ljava/io/PrintWriter;Z)V

    return-void
.end method

.method public huTpC(I)Z
    .locals 4

    iget-object v0, p0, Landroidx/fragment/app/lgHUyS;->wA:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v1, 0x0

    move v2, v1

    :goto_0
    if-ge v2, v0, :cond_2

    iget-object v3, p0, Landroidx/fragment/app/lgHUyS;->wA:Ljava/util/ArrayList;

    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroidx/fragment/app/lgHUyS$mjFkc;

    iget-object v3, v3, Landroidx/fragment/app/lgHUyS$mjFkc;->AZxh:Landroidx/fragment/app/Fragment;

    if-eqz v3, :cond_0

    iget v3, v3, Landroidx/fragment/app/Fragment;->eyqo:I

    goto :goto_1

    :cond_0
    move v3, v1

    :goto_1
    if-eqz v3, :cond_1

    if-ne v3, p1, :cond_1

    const/4 p0, 0x1

    return p0

    :cond_1
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_2
    return v1
.end method

.method public lB(Ljava/util/ArrayList;Landroidx/fragment/app/Fragment;)Landroidx/fragment/app/Fragment;
    .locals 5

    iget-object v0, p0, Landroidx/fragment/app/lgHUyS;->wA:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v1, 0x1

    sub-int/2addr v0, v1

    :goto_0
    if-ltz v0, :cond_2

    iget-object v2, p0, Landroidx/fragment/app/lgHUyS;->wA:Ljava/util/ArrayList;

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroidx/fragment/app/lgHUyS$mjFkc;

    iget v3, v2, Landroidx/fragment/app/lgHUyS$mjFkc;->mjFkc:I

    if-eq v3, v1, :cond_1

    const/4 v4, 0x3

    if-eq v3, v4, :cond_0

    packed-switch v3, :pswitch_data_0

    goto :goto_1

    :pswitch_0
    iget-object v3, v2, Landroidx/fragment/app/lgHUyS$mjFkc;->xJ:Landroidx/lifecycle/wA$AZxh;

    iput-object v3, v2, Landroidx/fragment/app/lgHUyS$mjFkc;->lgHUyS:Landroidx/lifecycle/wA$AZxh;

    goto :goto_1

    :pswitch_1
    iget-object p2, v2, Landroidx/fragment/app/lgHUyS$mjFkc;->AZxh:Landroidx/fragment/app/Fragment;

    goto :goto_1

    :pswitch_2
    const/4 p2, 0x0

    goto :goto_1

    :cond_0
    :pswitch_3
    iget-object v2, v2, Landroidx/fragment/app/lgHUyS$mjFkc;->AZxh:Landroidx/fragment/app/Fragment;

    invoke-virtual {p1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_1

    :cond_1
    :pswitch_4
    iget-object v2, v2, Landroidx/fragment/app/lgHUyS$mjFkc;->AZxh:Landroidx/fragment/app/Fragment;

    invoke-virtual {p1, v2}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    :goto_1
    add-int/lit8 v0, v0, -0x1

    goto :goto_0

    :cond_2
    return-object p2

    :pswitch_data_0
    .packed-switch 0x6
        :pswitch_3
        :pswitch_4
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public lgHUyS()V
    .locals 2

    invoke-virtual {p0}, Landroidx/fragment/app/lgHUyS;->qdMbNW()Landroidx/fragment/app/lgHUyS;

    iget-object v0, p0, Landroidx/fragment/app/mjFkc;->diqgf:Landroidx/fragment/app/KLFTb;

    const/4 v1, 0x1

    invoke-virtual {v0, p0, v1}, Landroidx/fragment/app/KLFTb;->cMLeY(Landroidx/fragment/app/KLFTb$lgHUyS;Z)V

    return-void
.end method

.method public mjFkc(Ljava/util/ArrayList;Ljava/util/ArrayList;)Z
    .locals 2

    const/4 v0, 0x2

    invoke-static {v0}, Landroidx/fragment/app/KLFTb;->dm(I)Z

    move-result v0

    if-eqz v0, :cond_0

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "Run: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "FragmentManager"

    invoke-static {v1, v0}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    :cond_0
    invoke-virtual {p1, p0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    sget-object p1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-virtual {p2, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-boolean p1, p0, Landroidx/fragment/app/lgHUyS;->qdMbNW:Z

    if-eqz p1, :cond_1

    iget-object p1, p0, Landroidx/fragment/app/mjFkc;->diqgf:Landroidx/fragment/app/KLFTb;

    invoke-virtual {p1, p0}, Landroidx/fragment/app/KLFTb;->ZfxDd(Landroidx/fragment/app/mjFkc;)V

    :cond_1
    const/4 p0, 0x1

    return p0
.end method

.method public qGY(Z)I
    .locals 2

    iget-boolean v0, p0, Landroidx/fragment/app/mjFkc;->eyqo:Z

    if-nez v0, :cond_2

    const/4 v0, 0x2

    invoke-static {v0}, Landroidx/fragment/app/KLFTb;->dm(I)Z

    move-result v0

    if-eqz v0, :cond_0

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "Commit: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "FragmentManager"

    invoke-static {v1, v0}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    new-instance v0, Lo/l1;

    invoke-direct {v0, v1}, Lo/l1;-><init>(Ljava/lang/String;)V

    new-instance v1, Ljava/io/PrintWriter;

    invoke-direct {v1, v0}, Ljava/io/PrintWriter;-><init>(Ljava/io/Writer;)V

    const-string v0, "  "

    invoke-virtual {p0, v0, v1}, Landroidx/fragment/app/mjFkc;->fehf(Ljava/lang/String;Ljava/io/PrintWriter;)V

    invoke-virtual {v1}, Ljava/io/PrintWriter;->close()V

    :cond_0
    const/4 v0, 0x1

    iput-boolean v0, p0, Landroidx/fragment/app/mjFkc;->eyqo:Z

    iget-boolean v0, p0, Landroidx/fragment/app/lgHUyS;->qdMbNW:Z

    if-eqz v0, :cond_1

    iget-object v0, p0, Landroidx/fragment/app/mjFkc;->diqgf:Landroidx/fragment/app/KLFTb;

    invoke-virtual {v0}, Landroidx/fragment/app/KLFTb;->xJ()I

    move-result v0

    iput v0, p0, Landroidx/fragment/app/mjFkc;->Ucbh:I

    goto :goto_0

    :cond_1
    const/4 v0, -0x1

    iput v0, p0, Landroidx/fragment/app/mjFkc;->Ucbh:I

    :goto_0
    iget-object v0, p0, Landroidx/fragment/app/mjFkc;->diqgf:Landroidx/fragment/app/KLFTb;

    invoke-virtual {v0, p0, p1}, Landroidx/fragment/app/KLFTb;->xrEuO(Landroidx/fragment/app/KLFTb$lgHUyS;Z)V

    iget p0, p0, Landroidx/fragment/app/mjFkc;->Ucbh:I

    return p0

    :cond_2
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string p1, "commit already called"

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public rkYL(I)V
    .locals 7

    iget-boolean v0, p0, Landroidx/fragment/app/lgHUyS;->qdMbNW:Z

    if-nez v0, :cond_0

    return-void

    :cond_0
    const/4 v0, 0x2

    invoke-static {v0}, Landroidx/fragment/app/KLFTb;->dm(I)Z

    move-result v1

    const-string v2, "FragmentManager"

    if-eqz v1, :cond_1

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "Bump nesting in "

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v3, " by "

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v2, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    :cond_1
    iget-object v1, p0, Landroidx/fragment/app/lgHUyS;->wA:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    const/4 v3, 0x0

    :goto_0
    if-ge v3, v1, :cond_3

    iget-object v4, p0, Landroidx/fragment/app/lgHUyS;->wA:Ljava/util/ArrayList;

    invoke-virtual {v4, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Landroidx/fragment/app/lgHUyS$mjFkc;

    iget-object v5, v4, Landroidx/fragment/app/lgHUyS$mjFkc;->AZxh:Landroidx/fragment/app/Fragment;

    if-eqz v5, :cond_2

    iget v6, v5, Landroidx/fragment/app/Fragment;->qGY:I

    add-int/2addr v6, p1

    iput v6, v5, Landroidx/fragment/app/Fragment;->qGY:I

    invoke-static {v0}, Landroidx/fragment/app/KLFTb;->dm(I)Z

    move-result v5

    if-eqz v5, :cond_2

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "Bump nesting of "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v6, v4, Landroidx/fragment/app/lgHUyS$mjFkc;->AZxh:Landroidx/fragment/app/Fragment;

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v6, " to "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v4, v4, Landroidx/fragment/app/lgHUyS$mjFkc;->AZxh:Landroidx/fragment/app/Fragment;

    iget v4, v4, Landroidx/fragment/app/Fragment;->qGY:I

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v2, v4}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    :cond_2
    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    :cond_3
    return-void
.end method

.method public toString()Ljava/lang/String;
    .locals 2

    new-instance v0, Ljava/lang/StringBuilder;

    const/16 v1, 0x80

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(I)V

    const-string v1, "BackStackEntry{"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {p0}, Ljava/lang/System;->identityHashCode(Ljava/lang/Object;)I

    move-result v1

    invoke-static {v1}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, Landroidx/fragment/app/mjFkc;->Ucbh:I

    if-ltz v1, :cond_0

    const-string v1, " #"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, Landroidx/fragment/app/mjFkc;->Ucbh:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    :cond_0
    iget-object v1, p0, Landroidx/fragment/app/lgHUyS;->ETF:Ljava/lang/String;

    if-eqz v1, :cond_1

    const-string v1, " "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object p0, p0, Landroidx/fragment/app/lgHUyS;->ETF:Ljava/lang/String;

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_1
    const-string p0, "}"

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public vI()Z
    .locals 3

    const/4 v0, 0x0

    move v1, v0

    :goto_0
    iget-object v2, p0, Landroidx/fragment/app/lgHUyS;->wA:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_1

    iget-object v2, p0, Landroidx/fragment/app/lgHUyS;->wA:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroidx/fragment/app/lgHUyS$mjFkc;

    invoke-static {v2}, Landroidx/fragment/app/mjFkc;->HGpJ(Landroidx/fragment/app/lgHUyS$mjFkc;)Z

    move-result v2

    if-eqz v2, :cond_0

    const/4 p0, 0x1

    return p0

    :cond_0
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_1
    return v0
.end method

.method public xJ()V
    .locals 2

    invoke-virtual {p0}, Landroidx/fragment/app/lgHUyS;->qdMbNW()Landroidx/fragment/app/lgHUyS;

    iget-object v0, p0, Landroidx/fragment/app/mjFkc;->diqgf:Landroidx/fragment/app/KLFTb;

    const/4 v1, 0x0

    invoke-virtual {v0, p0, v1}, Landroidx/fragment/app/KLFTb;->cMLeY(Landroidx/fragment/app/KLFTb$lgHUyS;Z)V

    return-void
.end method
