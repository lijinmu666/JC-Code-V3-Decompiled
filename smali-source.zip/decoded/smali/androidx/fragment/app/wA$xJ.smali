.class public Landroidx/fragment/app/wA$xJ;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Landroidx/fragment/app/wA;->huTpC(Ljava/util/List;Ljava/util/List;ZLandroidx/fragment/app/Dt$KLFTb;Landroidx/fragment/app/Dt$KLFTb;)Ljava/util/Map;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic AZxh:Landroidx/fragment/app/Dt$KLFTb;

.field public final synthetic KLFTb:Landroidx/fragment/app/wA;

.field public final synthetic ZfxDd:Lo/tjSezt;

.field public final synthetic mjFkc:Landroidx/fragment/app/Dt$KLFTb;

.field public final synthetic wA:Z


# direct methods
.method public constructor <init>(Landroidx/fragment/app/wA;Landroidx/fragment/app/Dt$KLFTb;Landroidx/fragment/app/Dt$KLFTb;ZLo/tjSezt;)V
    .locals 0

    iput-object p1, p0, Landroidx/fragment/app/wA$xJ;->KLFTb:Landroidx/fragment/app/wA;

    iput-object p2, p0, Landroidx/fragment/app/wA$xJ;->mjFkc:Landroidx/fragment/app/Dt$KLFTb;

    iput-object p3, p0, Landroidx/fragment/app/wA$xJ;->AZxh:Landroidx/fragment/app/Dt$KLFTb;

    iput-boolean p4, p0, Landroidx/fragment/app/wA$xJ;->wA:Z

    iput-object p5, p0, Landroidx/fragment/app/wA$xJ;->ZfxDd:Lo/tjSezt;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 4

    iget-object v0, p0, Landroidx/fragment/app/wA$xJ;->mjFkc:Landroidx/fragment/app/Dt$KLFTb;

    invoke-virtual {v0}, Landroidx/fragment/app/Dt$KLFTb;->JHa()Landroidx/fragment/app/Fragment;

    move-result-object v0

    iget-object v1, p0, Landroidx/fragment/app/wA$xJ;->AZxh:Landroidx/fragment/app/Dt$KLFTb;

    invoke-virtual {v1}, Landroidx/fragment/app/Dt$KLFTb;->JHa()Landroidx/fragment/app/Fragment;

    move-result-object v1

    iget-boolean v2, p0, Landroidx/fragment/app/wA$xJ;->wA:Z

    iget-object p0, p0, Landroidx/fragment/app/wA$xJ;->ZfxDd:Lo/tjSezt;

    const/4 v3, 0x0

    invoke-static {v0, v1, v2, p0, v3}, Landroidx/fragment/app/qdMbNW;->mjFkc(Landroidx/fragment/app/Fragment;Landroidx/fragment/app/Fragment;ZLo/tjSezt;Z)V

    return-void
.end method
