.class public Landroidx/fragment/app/KLFTb$ZfxDd;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lo/f7;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/fragment/app/KLFTb;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic mjFkc:Landroidx/fragment/app/KLFTb;


# direct methods
.method public constructor <init>(Landroidx/fragment/app/KLFTb;)V
    .locals 0

    iput-object p1, p0, Landroidx/fragment/app/KLFTb$ZfxDd;->mjFkc:Landroidx/fragment/app/KLFTb;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public mjFkc(Landroid/view/ViewGroup;)Landroidx/fragment/app/Dt;
    .locals 0

    new-instance p0, Landroidx/fragment/app/wA;

    invoke-direct {p0, p1}, Landroidx/fragment/app/wA;-><init>(Landroid/view/ViewGroup;)V

    return-object p0
.end method
