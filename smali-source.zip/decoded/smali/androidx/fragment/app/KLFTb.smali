.class public abstract Landroidx/fragment/app/KLFTb;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/fragment/app/KLFTb$xJ;,
        Landroidx/fragment/app/KLFTb$Dt;,
        Landroidx/fragment/app/KLFTb$qdMbNW;,
        Landroidx/fragment/app/KLFTb$lgHUyS;
    }
.end annotation


# static fields
.field public static KLMXS:Z = true

.field public static xrEuO:Z = false


# instance fields
.field public AZxh:Z

.field public BAnRFn:Z

.field public CqaNbM:Ljava/lang/Runnable;

.field public Dt:Ljava/util/ArrayList;

.field public ETF:Ljava/util/Map;

.field public Gd:Z

.field public HGpJ:Z

.field public IEE:Landroidx/fragment/app/Fragment;

.field public final JHa:Lo/Y2;

.field public final KLFTb:Lo/Qs;

.field public final MiMN:Lo/DanUFX;

.field public Ne:Lo/bzZHlx;

.field public OjSQV:Ljava/util/ArrayList;

.field public Pq:Lo/bL;

.field public Ucbh:Lo/f7;

.field public final VA:Landroidx/fragment/app/qdMbNW$mjFkc;

.field public VocHEe:Z

.field public final YoKzxo:Ljava/util/concurrent/CopyOnWriteArrayList;

.field public ZfxDd:Ljava/util/ArrayList;

.field public diqgf:Lo/bL;

.field public eyqo:Lo/f7;

.field public fehf:Landroidx/fragment/app/Fragment;

.field public huTpC:Ljava/util/ArrayDeque;

.field public lB:Ljava/util/ArrayList;

.field public final lgHUyS:Ljava/util/Map;

.field public mByQ:Ljava/util/ArrayList;

.field public final mjFkc:Ljava/util/ArrayList;

.field public qGY:Lo/jeHSg;

.field public final qdMbNW:Ljava/util/Map;

.field public rkYL:I

.field public vI:Z

.field public final wA:Lo/bVfe;

.field public wJVbdd:Ljava/util/ArrayList;

.field public final xJ:Ljava/util/concurrent/atomic/AtomicInteger;


# direct methods
.method static constructor <clinit>()V
    .locals 0

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Landroidx/fragment/app/KLFTb;->mjFkc:Ljava/util/ArrayList;

    new-instance v0, Lo/bVfe;

    invoke-direct {v0}, Lo/bVfe;-><init>()V

    iput-object v0, p0, Landroidx/fragment/app/KLFTb;->wA:Lo/bVfe;

    new-instance v0, Lo/Qs;

    invoke-direct {v0, p0}, Lo/Qs;-><init>(Landroidx/fragment/app/KLFTb;)V

    iput-object v0, p0, Landroidx/fragment/app/KLFTb;->KLFTb:Lo/Qs;

    new-instance v0, Landroidx/fragment/app/KLFTb$mjFkc;

    const/4 v1, 0x0

    invoke-direct {v0, p0, v1}, Landroidx/fragment/app/KLFTb$mjFkc;-><init>(Landroidx/fragment/app/KLFTb;Z)V

    iput-object v0, p0, Landroidx/fragment/app/KLFTb;->JHa:Lo/Y2;

    new-instance v0, Ljava/util/concurrent/atomic/AtomicInteger;

    invoke-direct {v0}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>()V

    iput-object v0, p0, Landroidx/fragment/app/KLFTb;->xJ:Ljava/util/concurrent/atomic/AtomicInteger;

    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    invoke-static {v0}, Ljava/util/Collections;->synchronizedMap(Ljava/util/Map;)Ljava/util/Map;

    move-result-object v0

    iput-object v0, p0, Landroidx/fragment/app/KLFTb;->lgHUyS:Ljava/util/Map;

    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    invoke-static {v0}, Ljava/util/Collections;->synchronizedMap(Ljava/util/Map;)Ljava/util/Map;

    move-result-object v0

    iput-object v0, p0, Landroidx/fragment/app/KLFTb;->qdMbNW:Ljava/util/Map;

    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    invoke-static {v0}, Ljava/util/Collections;->synchronizedMap(Ljava/util/Map;)Ljava/util/Map;

    move-result-object v0

    iput-object v0, p0, Landroidx/fragment/app/KLFTb;->ETF:Ljava/util/Map;

    new-instance v0, Landroidx/fragment/app/KLFTb$AZxh;

    invoke-direct {v0, p0}, Landroidx/fragment/app/KLFTb$AZxh;-><init>(Landroidx/fragment/app/KLFTb;)V

    iput-object v0, p0, Landroidx/fragment/app/KLFTb;->VA:Landroidx/fragment/app/qdMbNW$mjFkc;

    new-instance v0, Lo/DanUFX;

    invoke-direct {v0, p0}, Lo/DanUFX;-><init>(Landroidx/fragment/app/KLFTb;)V

    iput-object v0, p0, Landroidx/fragment/app/KLFTb;->MiMN:Lo/DanUFX;

    new-instance v0, Ljava/util/concurrent/CopyOnWriteArrayList;

    invoke-direct {v0}, Ljava/util/concurrent/CopyOnWriteArrayList;-><init>()V

    iput-object v0, p0, Landroidx/fragment/app/KLFTb;->YoKzxo:Ljava/util/concurrent/CopyOnWriteArrayList;

    const/4 v0, -0x1

    iput v0, p0, Landroidx/fragment/app/KLFTb;->rkYL:I

    const/4 v0, 0x0

    iput-object v0, p0, Landroidx/fragment/app/KLFTb;->Pq:Lo/bL;

    new-instance v1, Landroidx/fragment/app/KLFTb$wA;

    invoke-direct {v1, p0}, Landroidx/fragment/app/KLFTb$wA;-><init>(Landroidx/fragment/app/KLFTb;)V

    iput-object v1, p0, Landroidx/fragment/app/KLFTb;->diqgf:Lo/bL;

    iput-object v0, p0, Landroidx/fragment/app/KLFTb;->eyqo:Lo/f7;

    new-instance v0, Landroidx/fragment/app/KLFTb$ZfxDd;

    invoke-direct {v0, p0}, Landroidx/fragment/app/KLFTb$ZfxDd;-><init>(Landroidx/fragment/app/KLFTb;)V

    iput-object v0, p0, Landroidx/fragment/app/KLFTb;->Ucbh:Lo/f7;

    new-instance v0, Ljava/util/ArrayDeque;

    invoke-direct {v0}, Ljava/util/ArrayDeque;-><init>()V

    iput-object v0, p0, Landroidx/fragment/app/KLFTb;->huTpC:Ljava/util/ArrayDeque;

    new-instance v0, Landroidx/fragment/app/KLFTb$KLFTb;

    invoke-direct {v0, p0}, Landroidx/fragment/app/KLFTb$KLFTb;-><init>(Landroidx/fragment/app/KLFTb;)V

    iput-object v0, p0, Landroidx/fragment/app/KLFTb;->CqaNbM:Ljava/lang/Runnable;

    return-void
.end method

.method public static synthetic AZxh(Landroidx/fragment/app/KLFTb;)Ljava/util/Map;
    .locals 0

    iget-object p0, p0, Landroidx/fragment/app/KLFTb;->qdMbNW:Ljava/util/Map;

    return-object p0
.end method

.method public static JBhc(Landroid/view/View;)Landroidx/fragment/app/Fragment;
    .locals 1

    sget v0, Lo/y4;->mjFkc:I

    invoke-virtual {p0, v0}, Landroid/view/View;->getTag(I)Ljava/lang/Object;

    move-result-object p0

    instance-of v0, p0, Landroidx/fragment/app/Fragment;

    if-eqz v0, :cond_0

    check-cast p0, Landroidx/fragment/app/Fragment;

    return-object p0

    :cond_0
    const/4 p0, 0x0

    return-object p0
.end method

.method public static dm(I)Z
    .locals 1

    sget-boolean v0, Landroidx/fragment/app/KLFTb;->xrEuO:Z

    if-nez v0, :cond_1

    const-string v0, "FragmentManager"

    invoke-static {v0, p0}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    move-result p0

    if-eqz p0, :cond_0

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    goto :goto_1

    :cond_1
    :goto_0
    const/4 p0, 0x1

    :goto_1
    return p0
.end method

.method public static synthetic mjFkc(Landroidx/fragment/app/KLFTb;)Ljava/util/Map;
    .locals 0

    iget-object p0, p0, Landroidx/fragment/app/KLFTb;->lgHUyS:Ljava/util/Map;

    return-object p0
.end method

.method public static rWxwaT(Ljava/util/ArrayList;Ljava/util/ArrayList;II)V
    .locals 3

    :goto_0
    if-ge p2, p3, :cond_2

    invoke-virtual {p0, p2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroidx/fragment/app/mjFkc;

    invoke-virtual {p1, p2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Boolean;

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    const/4 v2, 0x1

    if-eqz v1, :cond_1

    const/4 v1, -0x1

    invoke-virtual {v0, v1}, Landroidx/fragment/app/mjFkc;->rkYL(I)V

    add-int/lit8 v1, p3, -0x1

    if-ne p2, v1, :cond_0

    goto :goto_1

    :cond_0
    const/4 v2, 0x0

    :goto_1
    invoke-virtual {v0, v2}, Landroidx/fragment/app/mjFkc;->diqgf(Z)V

    goto :goto_2

    :cond_1
    invoke-virtual {v0, v2}, Landroidx/fragment/app/mjFkc;->rkYL(I)V

    invoke-virtual {v0}, Landroidx/fragment/app/mjFkc;->Pq()V

    :goto_2
    add-int/lit8 p2, p2, 0x1

    goto :goto_0

    :cond_2
    return-void
.end method

.method public static uH(I)I
    .locals 3

    const/16 v0, 0x2002

    const/16 v1, 0x1001

    if-eq p0, v1, :cond_2

    const/16 v2, 0x1003

    if-eq p0, v2, :cond_1

    if-eq p0, v0, :cond_0

    const/4 v0, 0x0

    goto :goto_0

    :cond_0
    move v0, v1

    goto :goto_0

    :cond_1
    move v0, v2

    :cond_2
    :goto_0
    return v0
.end method


# virtual methods
.method public ANMGZc(Landroidx/fragment/app/Fragment;)V
    .locals 1

    iget-boolean v0, p1, Landroidx/fragment/app/Fragment;->Dt:Z

    if-eqz v0, :cond_0

    invoke-virtual {p0, p1}, Landroidx/fragment/app/KLFTb;->tQ(Landroidx/fragment/app/Fragment;)Z

    move-result p1

    if-eqz p1, :cond_0

    const/4 p1, 0x1

    iput-boolean p1, p0, Landroidx/fragment/app/KLFTb;->Gd:Z

    :cond_0
    return-void
.end method

.method public BAnRFn()V
    .locals 2

    const/4 v0, 0x0

    iput-boolean v0, p0, Landroidx/fragment/app/KLFTb;->HGpJ:Z

    iput-boolean v0, p0, Landroidx/fragment/app/KLFTb;->vI:Z

    iget-object v1, p0, Landroidx/fragment/app/KLFTb;->Ne:Lo/bzZHlx;

    invoke-virtual {v1, v0}, Lo/bzZHlx;->qdMbNW(Z)V

    const/4 v0, 0x7

    invoke-virtual {p0, v0}, Landroidx/fragment/app/KLFTb;->wJVbdd(I)V

    return-void
.end method

.method public final CqaNbM()V
    .locals 2

    sget-boolean v0, Landroidx/fragment/app/KLFTb;->KLMXS:Z

    if-eqz v0, :cond_0

    invoke-virtual {p0}, Landroidx/fragment/app/KLFTb;->YoKzxo()Ljava/util/Set;

    move-result-object p0

    invoke-interface {p0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_1

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroidx/fragment/app/Dt;

    invoke-virtual {v0}, Landroidx/fragment/app/Dt;->Dt()V

    goto :goto_0

    :cond_0
    iget-object v0, p0, Landroidx/fragment/app/KLFTb;->ETF:Ljava/util/Map;

    invoke-interface {v0}, Ljava/util/Map;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_1

    iget-object v0, p0, Landroidx/fragment/app/KLFTb;->ETF:Ljava/util/Map;

    invoke-interface {v0}, Ljava/util/Map;->keySet()Ljava/util/Set;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_1
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroidx/fragment/app/Fragment;

    invoke-virtual {p0, v1}, Landroidx/fragment/app/KLFTb;->ETF(Landroidx/fragment/app/Fragment;)V

    invoke-virtual {p0, v1}, Landroidx/fragment/app/KLFTb;->SOS(Landroidx/fragment/app/Fragment;)V

    goto :goto_1

    :cond_1
    return-void
.end method

.method public Dt()Landroidx/fragment/app/lgHUyS;
    .locals 1

    new-instance v0, Landroidx/fragment/app/mjFkc;

    invoke-direct {v0, p0}, Landroidx/fragment/app/mjFkc;-><init>(Landroidx/fragment/app/KLFTb;)V

    return-object v0
.end method

.method public final ETF(Landroidx/fragment/app/Fragment;)V
    .locals 3

    iget-object v0, p0, Landroidx/fragment/app/KLFTb;->ETF:Ljava/util/Map;

    invoke-interface {v0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/HashSet;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Ljava/util/HashSet;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_0

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lo/BxruE;

    invoke-virtual {v2}, Lo/BxruE;->mjFkc()V

    goto :goto_0

    :cond_0
    invoke-virtual {v0}, Ljava/util/HashSet;->clear()V

    invoke-virtual {p0, p1}, Landroidx/fragment/app/KLFTb;->Pq(Landroidx/fragment/app/Fragment;)V

    iget-object p0, p0, Landroidx/fragment/app/KLFTb;->ETF:Ljava/util/Map;

    invoke-interface {p0, p1}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    :cond_1
    return-void
.end method

.method public final GMIER(Landroidx/fragment/app/Fragment;)Lo/bzZHlx;
    .locals 0

    iget-object p0, p0, Landroidx/fragment/app/KLFTb;->Ne:Lo/bzZHlx;

    invoke-virtual {p0, p1}, Lo/bzZHlx;->KLFTb(Landroidx/fragment/app/Fragment;)Lo/bzZHlx;

    move-result-object p0

    return-object p0
.end method

.method public Gd()V
    .locals 1

    const/4 v0, 0x1

    invoke-virtual {p0, v0}, Landroidx/fragment/app/KLFTb;->wJVbdd(I)V

    return-void
.end method

.method public final HGpJ(Landroidx/fragment/app/Fragment;)V
    .locals 1

    if-eqz p1, :cond_0

    iget-object v0, p1, Landroidx/fragment/app/Fragment;->KLFTb:Ljava/lang/String;

    invoke-virtual {p0, v0}, Landroidx/fragment/app/KLFTb;->vadzgd(Ljava/lang/String;)Landroidx/fragment/app/Fragment;

    move-result-object p0

    invoke-virtual {p1, p0}, Landroidx/fragment/app/Fragment;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_0

    invoke-virtual {p1}, Landroidx/fragment/app/Fragment;->gtIJp()V

    :cond_0
    return-void
.end method

.method public IEE(Landroidx/fragment/app/Fragment;)Landroidx/fragment/app/xJ;
    .locals 2

    iget-object v0, p0, Landroidx/fragment/app/KLFTb;->wA:Lo/bVfe;

    iget-object v1, p1, Landroidx/fragment/app/Fragment;->KLFTb:Ljava/lang/String;

    invoke-virtual {v0, v1}, Lo/bVfe;->ETF(Ljava/lang/String;)Landroidx/fragment/app/xJ;

    move-result-object v0

    if-eqz v0, :cond_0

    return-object v0

    :cond_0
    new-instance v0, Landroidx/fragment/app/xJ;

    iget-object v1, p0, Landroidx/fragment/app/KLFTb;->MiMN:Lo/DanUFX;

    iget-object p0, p0, Landroidx/fragment/app/KLFTb;->wA:Lo/bVfe;

    invoke-direct {v0, v1, p0, p1}, Landroidx/fragment/app/xJ;-><init>(Lo/DanUFX;Lo/bVfe;Landroidx/fragment/app/Fragment;)V

    const/4 p0, 0x0

    throw p0
.end method

.method public final IVlxe(Lo/gYa;)V
    .locals 4

    invoke-virtual {p1}, Lo/gYa;->size()I

    move-result p0

    const/4 v0, 0x0

    :goto_0
    if-ge v0, p0, :cond_1

    invoke-virtual {p1, v0}, Lo/gYa;->ETF(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroidx/fragment/app/Fragment;

    iget-boolean v2, v1, Landroidx/fragment/app/Fragment;->Dt:Z

    if-nez v2, :cond_0

    invoke-virtual {v1}, Landroidx/fragment/app/Fragment;->XbiWeM()Landroid/view/View;

    move-result-object v2

    invoke-virtual {v2}, Landroid/view/View;->getAlpha()F

    move-result v3

    iput v3, v1, Landroidx/fragment/app/Fragment;->cMLeY:F

    const/4 v1, 0x0

    invoke-virtual {v2, v1}, Landroid/view/View;->setAlpha(F)V

    :cond_0
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    return-void
.end method

.method public JHa(Lo/EaLbDP;)V
    .locals 0

    iget-object p0, p0, Landroidx/fragment/app/KLFTb;->YoKzxo:Ljava/util/concurrent/CopyOnWriteArrayList;

    invoke-virtual {p0, p1}, Ljava/util/concurrent/CopyOnWriteArrayList;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method public JYgkl()Lo/bL;
    .locals 1

    iget-object v0, p0, Landroidx/fragment/app/KLFTb;->Pq:Lo/bL;

    if-eqz v0, :cond_0

    return-object v0

    :cond_0
    iget-object v0, p0, Landroidx/fragment/app/KLFTb;->fehf:Landroidx/fragment/app/Fragment;

    if-eqz v0, :cond_1

    iget-object p0, v0, Landroidx/fragment/app/Fragment;->fehf:Landroidx/fragment/app/KLFTb;

    invoke-virtual {p0}, Landroidx/fragment/app/KLFTb;->JYgkl()Lo/bL;

    move-result-object p0

    return-object p0

    :cond_1
    iget-object p0, p0, Landroidx/fragment/app/KLFTb;->diqgf:Lo/bL;

    return-object p0
.end method

.method public final JYn(Landroidx/fragment/app/Fragment;)Landroid/view/ViewGroup;
    .locals 2

    iget-object v0, p1, Landroidx/fragment/app/Fragment;->wJVbdd:Landroid/view/ViewGroup;

    if-eqz v0, :cond_0

    return-object v0

    :cond_0
    iget v0, p1, Landroidx/fragment/app/Fragment;->eyqo:I

    const/4 v1, 0x0

    if-gtz v0, :cond_1

    return-object v1

    :cond_1
    iget-object v0, p0, Landroidx/fragment/app/KLFTb;->qGY:Lo/jeHSg;

    invoke-virtual {v0}, Lo/jeHSg;->AZxh()Z

    move-result v0

    if-eqz v0, :cond_2

    iget-object p0, p0, Landroidx/fragment/app/KLFTb;->qGY:Lo/jeHSg;

    iget p1, p1, Landroidx/fragment/app/Fragment;->eyqo:I

    invoke-virtual {p0, p1}, Lo/jeHSg;->mjFkc(I)Landroid/view/View;

    move-result-object p0

    instance-of p1, p0, Landroid/view/ViewGroup;

    if-eqz p1, :cond_2

    check-cast p0, Landroid/view/ViewGroup;

    return-object p0

    :cond_2
    return-object v1
.end method

.method public JrJO()Ljava/util/List;
    .locals 0

    iget-object p0, p0, Landroidx/fragment/app/KLFTb;->wA:Lo/bVfe;

    invoke-virtual {p0}, Lo/bVfe;->VA()Ljava/util/List;

    move-result-object p0

    return-object p0
.end method

.method public KLFTb(Landroidx/fragment/app/Fragment;)Landroidx/fragment/app/xJ;
    .locals 3

    const/4 v0, 0x2

    invoke-static {v0}, Landroidx/fragment/app/KLFTb;->dm(I)Z

    move-result v0

    if-eqz v0, :cond_0

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "add: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "FragmentManager"

    invoke-static {v1, v0}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    :cond_0
    invoke-virtual {p0, p1}, Landroidx/fragment/app/KLFTb;->IEE(Landroidx/fragment/app/Fragment;)Landroidx/fragment/app/xJ;

    move-result-object v0

    iput-object p0, p1, Landroidx/fragment/app/Fragment;->fehf:Landroidx/fragment/app/KLFTb;

    iget-object v1, p0, Landroidx/fragment/app/KLFTb;->wA:Lo/bVfe;

    invoke-virtual {v1, v0}, Lo/bVfe;->YoKzxo(Landroidx/fragment/app/xJ;)V

    iget-boolean v1, p1, Landroidx/fragment/app/Fragment;->Gd:Z

    if-nez v1, :cond_2

    iget-object v1, p0, Landroidx/fragment/app/KLFTb;->wA:Lo/bVfe;

    invoke-virtual {v1, p1}, Lo/bVfe;->mjFkc(Landroidx/fragment/app/Fragment;)V

    const/4 v1, 0x0

    iput-boolean v1, p1, Landroidx/fragment/app/Fragment;->ETF:Z

    iget-object v2, p1, Landroidx/fragment/app/Fragment;->mByQ:Landroid/view/View;

    if-nez v2, :cond_1

    iput-boolean v1, p1, Landroidx/fragment/app/Fragment;->zvd:Z

    :cond_1
    invoke-virtual {p0, p1}, Landroidx/fragment/app/KLFTb;->tQ(Landroidx/fragment/app/Fragment;)Z

    move-result p1

    if-eqz p1, :cond_2

    const/4 p1, 0x1

    iput-boolean p1, p0, Landroidx/fragment/app/KLFTb;->Gd:Z

    :cond_2
    return-object v0
.end method

.method public final KLMXS(Z)V
    .locals 0

    iget-boolean p1, p0, Landroidx/fragment/app/KLFTb;->AZxh:Z

    if-nez p1, :cond_1

    iget-boolean p0, p0, Landroidx/fragment/app/KLFTb;->VocHEe:Z

    if-eqz p0, :cond_0

    new-instance p0, Ljava/lang/IllegalStateException;

    const-string p1, "FragmentManager has been destroyed"

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_0
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string p1, "FragmentManager has not been attached to a host."

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_1
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string p1, "FragmentManager is already executing transactions"

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public KRTLGT()I
    .locals 0

    iget-object p0, p0, Landroidx/fragment/app/KLFTb;->ZfxDd:Ljava/util/ArrayList;

    if-eqz p0, :cond_0

    invoke-virtual {p0}, Ljava/util/ArrayList;->size()I

    move-result p0

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method

.method public LREOK(Ljava/util/ArrayList;Ljava/util/ArrayList;Ljava/lang/String;II)Z
    .locals 5

    iget-object v0, p0, Landroidx/fragment/app/KLFTb;->ZfxDd:Ljava/util/ArrayList;

    const/4 v1, 0x0

    if-nez v0, :cond_0

    return v1

    :cond_0
    const/4 v2, 0x1

    if-nez p3, :cond_2

    if-gez p4, :cond_2

    and-int/lit8 v3, p5, 0x1

    if-nez v3, :cond_2

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result p3

    sub-int/2addr p3, v2

    if-gez p3, :cond_1

    return v1

    :cond_1
    iget-object p0, p0, Landroidx/fragment/app/KLFTb;->ZfxDd:Ljava/util/ArrayList;

    invoke-virtual {p0, p3}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    move-result-object p0

    invoke-virtual {p1, p0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    sget-object p0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    invoke-virtual {p2, p0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto/16 :goto_6

    :cond_2
    if-nez p3, :cond_4

    if-ltz p4, :cond_3

    goto :goto_0

    :cond_3
    const/4 p3, -0x1

    goto :goto_4

    :cond_4
    :goto_0
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    sub-int/2addr v0, v2

    :goto_1
    if-ltz v0, :cond_7

    iget-object v3, p0, Landroidx/fragment/app/KLFTb;->ZfxDd:Ljava/util/ArrayList;

    invoke-virtual {v3, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroidx/fragment/app/mjFkc;

    if-eqz p3, :cond_5

    invoke-virtual {v3}, Landroidx/fragment/app/mjFkc;->Ucbh()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {p3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_5

    goto :goto_2

    :cond_5
    if-ltz p4, :cond_6

    iget v3, v3, Landroidx/fragment/app/mjFkc;->Ucbh:I

    if-ne p4, v3, :cond_6

    goto :goto_2

    :cond_6
    add-int/lit8 v0, v0, -0x1

    goto :goto_1

    :cond_7
    :goto_2
    if-gez v0, :cond_8

    return v1

    :cond_8
    and-int/2addr p5, v2

    if-eqz p5, :cond_b

    :cond_9
    :goto_3
    add-int/lit8 v0, v0, -0x1

    if-ltz v0, :cond_b

    iget-object p5, p0, Landroidx/fragment/app/KLFTb;->ZfxDd:Ljava/util/ArrayList;

    invoke-virtual {p5, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p5

    check-cast p5, Landroidx/fragment/app/mjFkc;

    if-eqz p3, :cond_a

    invoke-virtual {p5}, Landroidx/fragment/app/mjFkc;->Ucbh()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {p3, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_9

    :cond_a
    if-ltz p4, :cond_b

    iget p5, p5, Landroidx/fragment/app/mjFkc;->Ucbh:I

    if-ne p4, p5, :cond_b

    goto :goto_3

    :cond_b
    move p3, v0

    :goto_4
    iget-object p4, p0, Landroidx/fragment/app/KLFTb;->ZfxDd:Ljava/util/ArrayList;

    invoke-virtual {p4}, Ljava/util/ArrayList;->size()I

    move-result p4

    sub-int/2addr p4, v2

    if-ne p3, p4, :cond_c

    return v1

    :cond_c
    iget-object p4, p0, Landroidx/fragment/app/KLFTb;->ZfxDd:Ljava/util/ArrayList;

    invoke-virtual {p4}, Ljava/util/ArrayList;->size()I

    move-result p4

    sub-int/2addr p4, v2

    :goto_5
    if-le p4, p3, :cond_d

    iget-object p5, p0, Landroidx/fragment/app/KLFTb;->ZfxDd:Ljava/util/ArrayList;

    invoke-virtual {p5, p4}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    move-result-object p5

    invoke-virtual {p1, p5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    sget-object p5, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    invoke-virtual {p2, p5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 p4, p4, -0x1

    goto :goto_5

    :cond_d
    :goto_6
    return v2
.end method

.method public final MiMN()V
    .locals 1

    const/4 v0, 0x0

    iput-boolean v0, p0, Landroidx/fragment/app/KLFTb;->AZxh:Z

    iget-object v0, p0, Landroidx/fragment/app/KLFTb;->wJVbdd:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    iget-object p0, p0, Landroidx/fragment/app/KLFTb;->lB:Ljava/util/ArrayList;

    invoke-virtual {p0}, Ljava/util/ArrayList;->clear()V

    return-void
.end method

.method public Moer(Landroidx/fragment/app/Fragment;)V
    .locals 3

    iget-object v0, p0, Landroidx/fragment/app/KLFTb;->wA:Lo/bVfe;

    iget-object v1, p1, Landroidx/fragment/app/Fragment;->KLFTb:Ljava/lang/String;

    invoke-virtual {v0, v1}, Lo/bVfe;->wA(Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_1

    const/4 v0, 0x3

    invoke-static {v0}, Landroidx/fragment/app/KLFTb;->dm(I)Z

    move-result v0

    if-eqz v0, :cond_0

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "Ignoring moving "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p1, " to state "

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget p1, p0, Landroidx/fragment/app/KLFTb;->rkYL:I

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p1, "since it is not added to "

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const-string p1, "FragmentManager"

    invoke-static {p1, p0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    :cond_0
    return-void

    :cond_1
    invoke-virtual {p0, p1}, Landroidx/fragment/app/KLFTb;->SOS(Landroidx/fragment/app/Fragment;)V

    iget-object v0, p1, Landroidx/fragment/app/Fragment;->mByQ:Landroid/view/View;

    if-eqz v0, :cond_3

    iget-boolean v1, p1, Landroidx/fragment/app/Fragment;->KLMXS:Z

    if-eqz v1, :cond_3

    iget-object v1, p1, Landroidx/fragment/app/Fragment;->wJVbdd:Landroid/view/ViewGroup;

    if-eqz v1, :cond_3

    iget p0, p1, Landroidx/fragment/app/Fragment;->cMLeY:F

    const/4 v1, 0x0

    cmpl-float v2, p0, v1

    if-lez v2, :cond_2

    invoke-virtual {v0, p0}, Landroid/view/View;->setAlpha(F)V

    :cond_2
    iput v1, p1, Landroidx/fragment/app/Fragment;->cMLeY:F

    const/4 p0, 0x0

    iput-boolean p0, p1, Landroidx/fragment/app/Fragment;->KLMXS:Z

    const/4 p0, 0x0

    throw p0

    :cond_3
    iget-boolean v0, p1, Landroidx/fragment/app/Fragment;->zvd:Z

    if-eqz v0, :cond_4

    invoke-virtual {p0, p1}, Landroidx/fragment/app/KLFTb;->fehf(Landroidx/fragment/app/Fragment;)V

    :cond_4
    return-void
.end method

.method public NKyg()V
    .locals 0

    return-void
.end method

.method public final NPj(Ljava/util/ArrayList;Ljava/util/ArrayList;)V
    .locals 7

    iget-object v0, p0, Landroidx/fragment/app/KLFTb;->OjSQV:Ljava/util/ArrayList;

    const/4 v1, 0x0

    if-nez v0, :cond_0

    move v0, v1

    goto :goto_0

    :cond_0
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    :goto_0
    move v2, v1

    :goto_1
    if-ge v2, v0, :cond_5

    iget-object v3, p0, Landroidx/fragment/app/KLFTb;->OjSQV:Ljava/util/ArrayList;

    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroidx/fragment/app/KLFTb$Dt;

    const/4 v4, -0x1

    if-eqz p1, :cond_1

    iget-boolean v5, v3, Landroidx/fragment/app/KLFTb$Dt;->mjFkc:Z

    if-nez v5, :cond_1

    iget-object v5, v3, Landroidx/fragment/app/KLFTb$Dt;->AZxh:Landroidx/fragment/app/mjFkc;

    invoke-virtual {p1, v5}, Ljava/util/ArrayList;->indexOf(Ljava/lang/Object;)I

    move-result v5

    if-eq v5, v4, :cond_1

    if-eqz p2, :cond_1

    invoke-virtual {p2, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/Boolean;

    invoke-virtual {v5}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v5

    if-eqz v5, :cond_1

    iget-object v4, p0, Landroidx/fragment/app/KLFTb;->OjSQV:Ljava/util/ArrayList;

    invoke-virtual {v4, v2}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    add-int/lit8 v2, v2, -0x1

    add-int/lit8 v0, v0, -0x1

    invoke-virtual {v3}, Landroidx/fragment/app/KLFTb$Dt;->AZxh()V

    goto :goto_2

    :cond_1
    invoke-virtual {v3}, Landroidx/fragment/app/KLFTb$Dt;->ZfxDd()Z

    move-result v5

    if-nez v5, :cond_2

    if-eqz p1, :cond_4

    iget-object v5, v3, Landroidx/fragment/app/KLFTb$Dt;->AZxh:Landroidx/fragment/app/mjFkc;

    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result v6

    invoke-virtual {v5, p1, v1, v6}, Landroidx/fragment/app/mjFkc;->Gd(Ljava/util/ArrayList;II)Z

    move-result v5

    if-eqz v5, :cond_4

    :cond_2
    iget-object v5, p0, Landroidx/fragment/app/KLFTb;->OjSQV:Ljava/util/ArrayList;

    invoke-virtual {v5, v2}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    add-int/lit8 v2, v2, -0x1

    add-int/lit8 v0, v0, -0x1

    if-eqz p1, :cond_3

    iget-boolean v5, v3, Landroidx/fragment/app/KLFTb$Dt;->mjFkc:Z

    if-nez v5, :cond_3

    iget-object v5, v3, Landroidx/fragment/app/KLFTb$Dt;->AZxh:Landroidx/fragment/app/mjFkc;

    invoke-virtual {p1, v5}, Ljava/util/ArrayList;->indexOf(Ljava/lang/Object;)I

    move-result v5

    if-eq v5, v4, :cond_3

    if-eqz p2, :cond_3

    invoke-virtual {p2, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/Boolean;

    invoke-virtual {v4}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v4

    if-eqz v4, :cond_3

    invoke-virtual {v3}, Landroidx/fragment/app/KLFTb$Dt;->AZxh()V

    goto :goto_2

    :cond_3
    invoke-virtual {v3}, Landroidx/fragment/app/KLFTb$Dt;->wA()V

    :cond_4
    :goto_2
    add-int/lit8 v2, v2, 0x1

    goto :goto_1

    :cond_5
    return-void
.end method

.method public final Ne()V
    .locals 1

    iget-boolean v0, p0, Landroidx/fragment/app/KLFTb;->BAnRFn:Z

    if-eqz v0, :cond_0

    const/4 v0, 0x0

    iput-boolean v0, p0, Landroidx/fragment/app/KLFTb;->BAnRFn:Z

    invoke-virtual {p0}, Landroidx/fragment/app/KLFTb;->XD()V

    :cond_0
    return-void
.end method

.method public OjSQV()V
    .locals 1

    const/4 v0, 0x2

    invoke-virtual {p0, v0}, Landroidx/fragment/app/KLFTb;->wJVbdd(I)V

    return-void
.end method

.method public final Pq(Landroidx/fragment/app/Fragment;)V
    .locals 2

    invoke-virtual {p1}, Landroidx/fragment/app/Fragment;->SmIWf()V

    iget-object p0, p0, Landroidx/fragment/app/KLFTb;->MiMN:Lo/DanUFX;

    const/4 v0, 0x0

    invoke-virtual {p0, p1, v0}, Lo/DanUFX;->VA(Landroidx/fragment/app/Fragment;Z)V

    const/4 p0, 0x0

    iput-object p0, p1, Landroidx/fragment/app/Fragment;->wJVbdd:Landroid/view/ViewGroup;

    iput-object p0, p1, Landroidx/fragment/app/Fragment;->mByQ:Landroid/view/View;

    iput-object p0, p1, Landroidx/fragment/app/Fragment;->oCFDzJ:Lo/BEUaYa;

    iget-object v1, p1, Landroidx/fragment/app/Fragment;->aqHPIZ:Lo/A2;

    invoke-virtual {v1, p0}, Lo/A2;->lgHUyS(Ljava/lang/Object;)V

    iput-boolean v0, p1, Landroidx/fragment/app/Fragment;->MiMN:Z

    return-void
.end method

.method public Qr(Landroidx/fragment/app/Fragment;I)V
    .locals 11

    iget-object v0, p0, Landroidx/fragment/app/KLFTb;->wA:Lo/bVfe;

    iget-object v1, p1, Landroidx/fragment/app/Fragment;->KLFTb:Ljava/lang/String;

    invoke-virtual {v0, v1}, Lo/bVfe;->ETF(Ljava/lang/String;)Landroidx/fragment/app/xJ;

    move-result-object v0

    const/4 v1, 0x1

    if-nez v0, :cond_0

    new-instance v0, Landroidx/fragment/app/xJ;

    iget-object v2, p0, Landroidx/fragment/app/KLFTb;->MiMN:Lo/DanUFX;

    iget-object v3, p0, Landroidx/fragment/app/KLFTb;->wA:Lo/bVfe;

    invoke-direct {v0, v2, v3, p1}, Landroidx/fragment/app/xJ;-><init>(Lo/DanUFX;Lo/bVfe;Landroidx/fragment/app/Fragment;)V

    invoke-virtual {v0, v1}, Landroidx/fragment/app/xJ;->fehf(I)V

    :cond_0
    iget-boolean v2, p1, Landroidx/fragment/app/Fragment;->VA:Z

    const/4 v3, 0x2

    if-eqz v2, :cond_1

    iget-boolean v2, p1, Landroidx/fragment/app/Fragment;->MiMN:Z

    if-eqz v2, :cond_1

    iget v2, p1, Landroidx/fragment/app/Fragment;->mjFkc:I

    if-ne v2, v3, :cond_1

    invoke-static {p2, v3}, Ljava/lang/Math;->max(II)I

    move-result p2

    :cond_1
    invoke-virtual {v0}, Landroidx/fragment/app/xJ;->ZfxDd()I

    move-result v2

    invoke-static {p2, v2}, Ljava/lang/Math;->min(II)I

    move-result p2

    iget v2, p1, Landroidx/fragment/app/Fragment;->mjFkc:I

    const/4 v4, 0x3

    const-string v5, "FragmentManager"

    const/4 v6, 0x5

    const/4 v7, 0x4

    const/4 v8, -0x1

    if-gt v2, p2, :cond_a

    if-ge v2, p2, :cond_2

    iget-object v2, p0, Landroidx/fragment/app/KLFTb;->ETF:Ljava/util/Map;

    invoke-interface {v2}, Ljava/util/Map;->isEmpty()Z

    move-result v2

    if-nez v2, :cond_2

    invoke-virtual {p0, p1}, Landroidx/fragment/app/KLFTb;->ETF(Landroidx/fragment/app/Fragment;)V

    :cond_2
    iget p0, p1, Landroidx/fragment/app/Fragment;->mjFkc:I

    if-eq p0, v8, :cond_3

    if-eqz p0, :cond_4

    if-eq p0, v1, :cond_5

    if-eq p0, v3, :cond_7

    if-eq p0, v7, :cond_8

    if-eq p0, v6, :cond_9

    goto/16 :goto_3

    :cond_3
    if-le p2, v8, :cond_4

    invoke-virtual {v0}, Landroidx/fragment/app/xJ;->wA()V

    :cond_4
    if-lez p2, :cond_5

    invoke-virtual {v0}, Landroidx/fragment/app/xJ;->KLFTb()V

    :cond_5
    if-le p2, v8, :cond_6

    invoke-virtual {v0}, Landroidx/fragment/app/xJ;->Dt()V

    :cond_6
    if-le p2, v1, :cond_7

    invoke-virtual {v0}, Landroidx/fragment/app/xJ;->JHa()V

    :cond_7
    if-le p2, v3, :cond_8

    invoke-virtual {v0}, Landroidx/fragment/app/xJ;->mjFkc()V

    :cond_8
    if-le p2, v7, :cond_9

    invoke-virtual {v0}, Landroidx/fragment/app/xJ;->IEE()V

    :cond_9
    if-le p2, v6, :cond_19

    invoke-virtual {v0}, Landroidx/fragment/app/xJ;->rkYL()V

    goto/16 :goto_3

    :cond_a
    if-le v2, p2, :cond_19

    if-eqz v2, :cond_17

    if-eq v2, v1, :cond_15

    const/4 v9, 0x0

    if-eq v2, v3, :cond_10

    if-eq v2, v7, :cond_d

    if-eq v2, v6, :cond_c

    const/4 v10, 0x7

    if-eq v2, v10, :cond_b

    goto/16 :goto_3

    :cond_b
    if-ge p2, v10, :cond_c

    invoke-virtual {v0}, Landroidx/fragment/app/xJ;->YoKzxo()V

    :cond_c
    if-ge p2, v6, :cond_d

    invoke-virtual {v0}, Landroidx/fragment/app/xJ;->Pq()V

    :cond_d
    if-ge p2, v7, :cond_10

    invoke-static {v4}, Landroidx/fragment/app/KLFTb;->dm(I)Z

    move-result v2

    if-eqz v2, :cond_e

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "movefrom ACTIVITY_CREATED: "

    invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v5, v2}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    :cond_e
    iget-object v2, p1, Landroidx/fragment/app/Fragment;->mByQ:Landroid/view/View;

    if-nez v2, :cond_f

    goto :goto_0

    :cond_f
    throw v9

    :cond_10
    :goto_0
    if-ge p2, v3, :cond_15

    iget-object v2, p1, Landroidx/fragment/app/Fragment;->mByQ:Landroid/view/View;

    if-eqz v2, :cond_14

    iget-object v6, p1, Landroidx/fragment/app/Fragment;->wJVbdd:Landroid/view/ViewGroup;

    if-eqz v6, :cond_14

    invoke-virtual {v6, v2}, Landroid/view/ViewGroup;->endViewTransition(Landroid/view/View;)V

    iget-object v2, p1, Landroidx/fragment/app/Fragment;->mByQ:Landroid/view/View;

    invoke-virtual {v2}, Landroid/view/View;->clearAnimation()V

    invoke-virtual {p1}, Landroidx/fragment/app/Fragment;->KRTLGT()Z

    move-result v2

    if-nez v2, :cond_14

    iget v2, p0, Landroidx/fragment/app/KLFTb;->rkYL:I

    const/4 v6, 0x0

    if-le v2, v8, :cond_12

    iget-boolean v2, p0, Landroidx/fragment/app/KLFTb;->VocHEe:Z

    if-nez v2, :cond_12

    iget-object v2, p1, Landroidx/fragment/app/Fragment;->mByQ:Landroid/view/View;

    invoke-virtual {v2}, Landroid/view/View;->getVisibility()I

    move-result v2

    if-nez v2, :cond_12

    iget v2, p1, Landroidx/fragment/app/Fragment;->cMLeY:F

    cmpl-float v2, v2, v6

    if-gez v2, :cond_11

    goto :goto_1

    :cond_11
    throw v9

    :cond_12
    :goto_1
    iput v6, p1, Landroidx/fragment/app/Fragment;->cMLeY:F

    iget-object v2, p1, Landroidx/fragment/app/Fragment;->wJVbdd:Landroid/view/ViewGroup;

    iget-object v6, p1, Landroidx/fragment/app/Fragment;->mByQ:Landroid/view/View;

    invoke-virtual {v2, v6}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    invoke-static {v3}, Landroidx/fragment/app/KLFTb;->dm(I)Z

    move-result v3

    if-eqz v3, :cond_13

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v7, "Removing view "

    invoke-virtual {v3, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v6, " for fragment "

    invoke-virtual {v3, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v6, " from container "

    invoke-virtual {v3, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v5, v3}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    :cond_13
    iget-object v3, p1, Landroidx/fragment/app/Fragment;->wJVbdd:Landroid/view/ViewGroup;

    if-eq v2, v3, :cond_14

    return-void

    :cond_14
    iget-object v2, p0, Landroidx/fragment/app/KLFTb;->ETF:Ljava/util/Map;

    invoke-interface {v2, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    if-nez v2, :cond_15

    invoke-virtual {v0}, Landroidx/fragment/app/xJ;->lgHUyS()V

    :cond_15
    if-ge p2, v1, :cond_17

    iget-object p0, p0, Landroidx/fragment/app/KLFTb;->ETF:Ljava/util/Map;

    invoke-interface {p0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    if-eqz p0, :cond_16

    goto :goto_2

    :cond_16
    invoke-virtual {v0}, Landroidx/fragment/app/xJ;->xJ()V

    :cond_17
    move v1, p2

    :goto_2
    if-gez v1, :cond_18

    invoke-virtual {v0}, Landroidx/fragment/app/xJ;->qdMbNW()V

    :cond_18
    move p2, v1

    :cond_19
    :goto_3
    iget p0, p1, Landroidx/fragment/app/Fragment;->mjFkc:I

    if-eq p0, p2, :cond_1b

    invoke-static {v4}, Landroidx/fragment/app/KLFTb;->dm(I)Z

    move-result p0

    if-eqz p0, :cond_1a

    new-instance p0, Ljava/lang/StringBuilder;

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v0, "moveToState: Fragment state for "

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v0, " not updated inline; expected state "

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v0, " found "

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v0, p1, Landroidx/fragment/app/Fragment;->mjFkc:I

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-static {v5, p0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    :cond_1a
    iput p2, p1, Landroidx/fragment/app/Fragment;->mjFkc:I

    :cond_1b
    return-void
.end method

.method public SOS(Landroidx/fragment/app/Fragment;)V
    .locals 1

    iget v0, p0, Landroidx/fragment/app/KLFTb;->rkYL:I

    invoke-virtual {p0, p1, v0}, Landroidx/fragment/app/KLFTb;->Qr(Landroidx/fragment/app/Fragment;I)V

    return-void
.end method

.method public SmIWf(IZ)V
    .locals 2

    const/4 v0, -0x1

    if-ne p1, v0, :cond_6

    if-nez p2, :cond_0

    iget p2, p0, Landroidx/fragment/app/KLFTb;->rkYL:I

    if-ne p1, p2, :cond_0

    return-void

    :cond_0
    iput p1, p0, Landroidx/fragment/app/KLFTb;->rkYL:I

    sget-boolean p1, Landroidx/fragment/app/KLFTb;->KLMXS:Z

    if-eqz p1, :cond_1

    iget-object p1, p0, Landroidx/fragment/app/KLFTb;->wA:Lo/bVfe;

    invoke-virtual {p1}, Lo/bVfe;->qGY()V

    goto :goto_2

    :cond_1
    iget-object p1, p0, Landroidx/fragment/app/KLFTb;->wA:Lo/bVfe;

    invoke-virtual {p1}, Lo/bVfe;->VA()Ljava/util/List;

    move-result-object p1

    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_0
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result p2

    if-eqz p2, :cond_2

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Landroidx/fragment/app/Fragment;

    invoke-virtual {p0, p2}, Landroidx/fragment/app/KLFTb;->Moer(Landroidx/fragment/app/Fragment;)V

    goto :goto_0

    :cond_2
    iget-object p1, p0, Landroidx/fragment/app/KLFTb;->wA:Lo/bVfe;

    invoke-virtual {p1}, Lo/bVfe;->qdMbNW()Ljava/util/List;

    move-result-object p1

    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :cond_3
    :goto_1
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result p2

    if-eqz p2, :cond_5

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Landroidx/fragment/app/xJ;

    invoke-virtual {p2}, Landroidx/fragment/app/xJ;->ETF()Landroidx/fragment/app/Fragment;

    move-result-object v0

    iget-boolean v1, v0, Landroidx/fragment/app/Fragment;->KLMXS:Z

    if-nez v1, :cond_4

    invoke-virtual {p0, v0}, Landroidx/fragment/app/KLFTb;->Moer(Landroidx/fragment/app/Fragment;)V

    :cond_4
    iget-boolean v1, v0, Landroidx/fragment/app/Fragment;->ETF:Z

    if-eqz v1, :cond_3

    invoke-virtual {v0}, Landroidx/fragment/app/Fragment;->oCFDzJ()Z

    move-result v0

    if-nez v0, :cond_3

    iget-object v0, p0, Landroidx/fragment/app/KLFTb;->wA:Lo/bVfe;

    invoke-virtual {v0, p2}, Lo/bVfe;->rkYL(Landroidx/fragment/app/xJ;)V

    goto :goto_1

    :cond_5
    :goto_2
    invoke-virtual {p0}, Landroidx/fragment/app/KLFTb;->XD()V

    return-void

    :cond_6
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string p1, "No activity"

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public SwgkN()Lo/f7;
    .locals 1

    iget-object v0, p0, Landroidx/fragment/app/KLFTb;->eyqo:Lo/f7;

    if-eqz v0, :cond_0

    return-object v0

    :cond_0
    iget-object v0, p0, Landroidx/fragment/app/KLFTb;->fehf:Landroidx/fragment/app/Fragment;

    if-eqz v0, :cond_1

    iget-object p0, v0, Landroidx/fragment/app/Fragment;->fehf:Landroidx/fragment/app/KLFTb;

    invoke-virtual {p0}, Landroidx/fragment/app/KLFTb;->SwgkN()Lo/f7;

    move-result-object p0

    return-object p0

    :cond_1
    iget-object p0, p0, Landroidx/fragment/app/KLFTb;->Ucbh:Lo/f7;

    return-object p0
.end method

.method public Ucbh()V
    .locals 2

    const/4 v0, 0x0

    iput-boolean v0, p0, Landroidx/fragment/app/KLFTb;->HGpJ:Z

    iput-boolean v0, p0, Landroidx/fragment/app/KLFTb;->vI:Z

    iget-object v1, p0, Landroidx/fragment/app/KLFTb;->Ne:Lo/bzZHlx;

    invoke-virtual {v1, v0}, Lo/bzZHlx;->qdMbNW(Z)V

    const/4 v0, 0x1

    invoke-virtual {p0, v0}, Landroidx/fragment/app/KLFTb;->wJVbdd(I)V

    return-void
.end method

.method public VA()Z
    .locals 4

    iget-object v0, p0, Landroidx/fragment/app/KLFTb;->wA:Lo/bVfe;

    invoke-virtual {v0}, Lo/bVfe;->Dt()Ljava/util/List;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    const/4 v1, 0x0

    move v2, v1

    :cond_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_2

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroidx/fragment/app/Fragment;

    if-eqz v3, :cond_1

    invoke-virtual {p0, v3}, Landroidx/fragment/app/KLFTb;->tQ(Landroidx/fragment/app/Fragment;)Z

    move-result v2

    :cond_1
    if-eqz v2, :cond_0

    const/4 p0, 0x1

    return p0

    :cond_2
    return v1
.end method

.method public Vdz(Landroidx/fragment/app/Fragment;)Lo/ia;
    .locals 0

    iget-object p0, p0, Landroidx/fragment/app/KLFTb;->Ne:Lo/bzZHlx;

    invoke-virtual {p0, p1}, Lo/bzZHlx;->xJ(Landroidx/fragment/app/Fragment;)Lo/ia;

    move-result-object p0

    return-object p0
.end method

.method public Vgyli(Landroidx/fragment/app/Fragment;Landroidx/lifecycle/wA$AZxh;)V
    .locals 2

    iget-object v0, p1, Landroidx/fragment/app/Fragment;->KLFTb:Ljava/lang/String;

    invoke-virtual {p0, v0}, Landroidx/fragment/app/KLFTb;->vadzgd(Ljava/lang/String;)Landroidx/fragment/app/Fragment;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroidx/fragment/app/Fragment;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    iput-object p2, p1, Landroidx/fragment/app/Fragment;->NPj:Landroidx/lifecycle/wA$AZxh;

    return-void

    :cond_0
    new-instance p2, Ljava/lang/IllegalArgumentException;

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "Fragment "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p1, " is not an active fragment of FragmentManager "

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {p2, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p2
.end method

.method public final Vnb(Ljava/util/ArrayList;Ljava/util/ArrayList;II)V
    .locals 16

    move-object/from16 v6, p0

    move-object/from16 v7, p1

    move-object/from16 v8, p2

    move/from16 v9, p3

    move/from16 v10, p4

    invoke-virtual {v7, v9}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroidx/fragment/app/mjFkc;

    iget-boolean v11, v0, Landroidx/fragment/app/lgHUyS;->IEE:Z

    iget-object v0, v6, Landroidx/fragment/app/KLFTb;->mByQ:Ljava/util/ArrayList;

    if-nez v0, :cond_0

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, v6, Landroidx/fragment/app/KLFTb;->mByQ:Ljava/util/ArrayList;

    goto :goto_0

    :cond_0
    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    :goto_0
    iget-object v0, v6, Landroidx/fragment/app/KLFTb;->mByQ:Ljava/util/ArrayList;

    iget-object v1, v6, Landroidx/fragment/app/KLFTb;->wA:Lo/bVfe;

    invoke-virtual {v1}, Lo/bVfe;->VA()Ljava/util/List;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    invoke-virtual/range {p0 .. p0}, Landroidx/fragment/app/KLFTb;->bbzow()Landroidx/fragment/app/Fragment;

    move-result-object v0

    const/4 v1, 0x0

    move v12, v1

    move v2, v9

    :goto_1
    const/4 v13, 0x1

    if-ge v2, v10, :cond_4

    invoke-virtual {v7, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroidx/fragment/app/mjFkc;

    invoke-virtual {v8, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/Boolean;

    invoke-virtual {v4}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v4

    if-nez v4, :cond_1

    iget-object v4, v6, Landroidx/fragment/app/KLFTb;->mByQ:Ljava/util/ArrayList;

    invoke-virtual {v3, v4, v0}, Landroidx/fragment/app/mjFkc;->eyqo(Ljava/util/ArrayList;Landroidx/fragment/app/Fragment;)Landroidx/fragment/app/Fragment;

    move-result-object v0

    goto :goto_2

    :cond_1
    iget-object v4, v6, Landroidx/fragment/app/KLFTb;->mByQ:Ljava/util/ArrayList;

    invoke-virtual {v3, v4, v0}, Landroidx/fragment/app/mjFkc;->lB(Ljava/util/ArrayList;Landroidx/fragment/app/Fragment;)Landroidx/fragment/app/Fragment;

    move-result-object v0

    :goto_2
    if-nez v12, :cond_3

    iget-boolean v3, v3, Landroidx/fragment/app/lgHUyS;->qdMbNW:Z

    if-eqz v3, :cond_2

    goto :goto_3

    :cond_2
    move v12, v1

    goto :goto_4

    :cond_3
    :goto_3
    move v12, v13

    :goto_4
    add-int/lit8 v2, v2, 0x1

    goto :goto_1

    :cond_4
    iget-object v0, v6, Landroidx/fragment/app/KLFTb;->mByQ:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    const/4 v14, 0x0

    if-nez v11, :cond_8

    iget v0, v6, Landroidx/fragment/app/KLFTb;->rkYL:I

    if-lt v0, v13, :cond_8

    sget-boolean v0, Landroidx/fragment/app/KLFTb;->KLMXS:Z

    if-eqz v0, :cond_7

    move v0, v9

    :goto_5
    if-ge v0, v10, :cond_8

    invoke-virtual {v7, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroidx/fragment/app/mjFkc;

    iget-object v1, v1, Landroidx/fragment/app/lgHUyS;->wA:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_5
    :goto_6
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_6

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroidx/fragment/app/lgHUyS$mjFkc;

    iget-object v2, v2, Landroidx/fragment/app/lgHUyS$mjFkc;->AZxh:Landroidx/fragment/app/Fragment;

    if-eqz v2, :cond_5

    iget-object v3, v2, Landroidx/fragment/app/Fragment;->fehf:Landroidx/fragment/app/KLFTb;

    if-eqz v3, :cond_5

    invoke-virtual {v6, v2}, Landroidx/fragment/app/KLFTb;->IEE(Landroidx/fragment/app/Fragment;)Landroidx/fragment/app/xJ;

    move-result-object v2

    iget-object v3, v6, Landroidx/fragment/app/KLFTb;->wA:Lo/bVfe;

    invoke-virtual {v3, v2}, Lo/bVfe;->YoKzxo(Landroidx/fragment/app/xJ;)V

    goto :goto_6

    :cond_6
    add-int/lit8 v0, v0, 0x1

    goto :goto_5

    :cond_7
    throw v14

    :cond_8
    invoke-static/range {p1 .. p4}, Landroidx/fragment/app/KLFTb;->rWxwaT(Ljava/util/ArrayList;Ljava/util/ArrayList;II)V

    sget-boolean v0, Landroidx/fragment/app/KLFTb;->KLMXS:Z

    if-eqz v0, :cond_e

    add-int/lit8 v0, v10, -0x1

    invoke-virtual {v8, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    move v1, v9

    :goto_7
    if-ge v1, v10, :cond_d

    invoke-virtual {v7, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroidx/fragment/app/mjFkc;

    if-eqz v0, :cond_a

    iget-object v3, v2, Landroidx/fragment/app/lgHUyS;->wA:Ljava/util/ArrayList;

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    sub-int/2addr v3, v13

    :goto_8
    if-ltz v3, :cond_c

    iget-object v4, v2, Landroidx/fragment/app/lgHUyS;->wA:Ljava/util/ArrayList;

    invoke-virtual {v4, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Landroidx/fragment/app/lgHUyS$mjFkc;

    iget-object v4, v4, Landroidx/fragment/app/lgHUyS$mjFkc;->AZxh:Landroidx/fragment/app/Fragment;

    if-eqz v4, :cond_9

    invoke-virtual {v6, v4}, Landroidx/fragment/app/KLFTb;->IEE(Landroidx/fragment/app/Fragment;)Landroidx/fragment/app/xJ;

    move-result-object v4

    invoke-virtual {v4}, Landroidx/fragment/app/xJ;->MiMN()V

    :cond_9
    add-int/lit8 v3, v3, -0x1

    goto :goto_8

    :cond_a
    iget-object v2, v2, Landroidx/fragment/app/lgHUyS;->wA:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_b
    :goto_9
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_c

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroidx/fragment/app/lgHUyS$mjFkc;

    iget-object v3, v3, Landroidx/fragment/app/lgHUyS$mjFkc;->AZxh:Landroidx/fragment/app/Fragment;

    if-eqz v3, :cond_b

    invoke-virtual {v6, v3}, Landroidx/fragment/app/KLFTb;->IEE(Landroidx/fragment/app/Fragment;)Landroidx/fragment/app/xJ;

    move-result-object v3

    invoke-virtual {v3}, Landroidx/fragment/app/xJ;->MiMN()V

    goto :goto_9

    :cond_c
    add-int/lit8 v1, v1, 0x1

    goto :goto_7

    :cond_d
    iget v1, v6, Landroidx/fragment/app/KLFTb;->rkYL:I

    invoke-virtual {v6, v1, v13}, Landroidx/fragment/app/KLFTb;->SmIWf(IZ)V

    invoke-virtual {v6, v7, v9, v10}, Landroidx/fragment/app/KLFTb;->rkYL(Ljava/util/ArrayList;II)Ljava/util/Set;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_a
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_11

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroidx/fragment/app/Dt;

    invoke-virtual {v2, v0}, Landroidx/fragment/app/Dt;->fehf(Z)V

    invoke-virtual {v2}, Landroidx/fragment/app/Dt;->rkYL()V

    invoke-virtual {v2}, Landroidx/fragment/app/Dt;->xJ()V

    goto :goto_a

    :cond_e
    if-eqz v11, :cond_f

    new-instance v15, Lo/gYa;

    invoke-direct {v15}, Lo/gYa;-><init>()V

    invoke-virtual {v6, v15}, Landroidx/fragment/app/KLFTb;->wA(Lo/gYa;)V

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v2, p2

    move/from16 v3, p3

    move/from16 v4, p4

    move-object v5, v15

    invoke-virtual/range {v0 .. v5}, Landroidx/fragment/app/KLFTb;->fFz(Ljava/util/ArrayList;Ljava/util/ArrayList;IILo/gYa;)I

    move-result v0

    invoke-virtual {v6, v15}, Landroidx/fragment/app/KLFTb;->IVlxe(Lo/gYa;)V

    goto :goto_b

    :cond_f
    move v0, v10

    :goto_b
    if-eq v0, v9, :cond_11

    if-eqz v11, :cond_11

    iget v0, v6, Landroidx/fragment/app/KLFTb;->rkYL:I

    if-ge v0, v13, :cond_10

    invoke-virtual {v6, v0, v13}, Landroidx/fragment/app/KLFTb;->SmIWf(IZ)V

    goto :goto_c

    :cond_10
    throw v14

    :cond_11
    :goto_c
    if-ge v9, v10, :cond_13

    invoke-virtual {v7, v9}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroidx/fragment/app/mjFkc;

    invoke-virtual {v8, v9}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Boolean;

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    if-eqz v1, :cond_12

    iget v1, v0, Landroidx/fragment/app/mjFkc;->Ucbh:I

    if-ltz v1, :cond_12

    const/4 v1, -0x1

    iput v1, v0, Landroidx/fragment/app/mjFkc;->Ucbh:I

    :cond_12
    invoke-virtual {v0}, Landroidx/fragment/app/mjFkc;->VocHEe()V

    add-int/lit8 v9, v9, 0x1

    goto :goto_c

    :cond_13
    if-eqz v12, :cond_14

    invoke-virtual/range {p0 .. p0}, Landroidx/fragment/app/KLFTb;->XtE()V

    :cond_14
    return-void
.end method

.method public VocHEe()V
    .locals 1

    invoke-virtual {p0}, Landroidx/fragment/app/KLFTb;->gtr()V

    iget-object v0, p0, Landroidx/fragment/app/KLFTb;->IEE:Landroidx/fragment/app/Fragment;

    invoke-virtual {p0, v0}, Landroidx/fragment/app/KLFTb;->HGpJ(Landroidx/fragment/app/Fragment;)V

    return-void
.end method

.method public WGXroI()Lo/DanUFX;
    .locals 0

    iget-object p0, p0, Landroidx/fragment/app/KLFTb;->MiMN:Lo/DanUFX;

    return-object p0
.end method

.method public final WrLQs(Ljava/util/ArrayList;Ljava/util/ArrayList;)Z
    .locals 4

    iget-object v0, p0, Landroidx/fragment/app/KLFTb;->mjFkc:Ljava/util/ArrayList;

    monitor-enter v0

    :try_start_0
    iget-object v1, p0, Landroidx/fragment/app/KLFTb;->mjFkc:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v1

    const/4 v2, 0x0

    if-eqz v1, :cond_0

    monitor-exit v0

    return v2

    :catchall_0
    move-exception p0

    goto :goto_1

    :cond_0
    iget-object v1, p0, Landroidx/fragment/app/KLFTb;->mjFkc:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    :goto_0
    if-ge v2, v1, :cond_1

    iget-object v3, p0, Landroidx/fragment/app/KLFTb;->mjFkc:Ljava/util/ArrayList;

    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroidx/fragment/app/KLFTb$lgHUyS;

    invoke-interface {v3, p1, p2}, Landroidx/fragment/app/KLFTb$lgHUyS;->mjFkc(Ljava/util/ArrayList;Ljava/util/ArrayList;)Z

    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_1
    iget-object p0, p0, Landroidx/fragment/app/KLFTb;->mjFkc:Ljava/util/ArrayList;

    invoke-virtual {p0}, Ljava/util/ArrayList;->clear()V

    const/4 p0, 0x0

    throw p0

    :goto_1
    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw p0
.end method

.method public final XD()V
    .locals 2

    iget-object v0, p0, Landroidx/fragment/app/KLFTb;->wA:Lo/bVfe;

    invoke-virtual {v0}, Lo/bVfe;->qdMbNW()Ljava/util/List;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroidx/fragment/app/xJ;

    invoke-virtual {p0, v1}, Landroidx/fragment/app/KLFTb;->kism(Landroidx/fragment/app/xJ;)V

    goto :goto_0

    :cond_0
    return-void
.end method

.method public final XFUzSY(Ljava/util/ArrayList;Ljava/util/ArrayList;)V
    .locals 4

    invoke-virtual {p1}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_0

    return-void

    :cond_0
    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result v0

    invoke-virtual {p2}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ne v0, v1, :cond_6

    invoke-virtual {p0, p1, p2}, Landroidx/fragment/app/KLFTb;->NPj(Ljava/util/ArrayList;Ljava/util/ArrayList;)V

    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v1, 0x0

    move v2, v1

    :goto_0
    if-ge v1, v0, :cond_4

    invoke-virtual {p1, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroidx/fragment/app/mjFkc;

    iget-boolean v3, v3, Landroidx/fragment/app/lgHUyS;->IEE:Z

    if-nez v3, :cond_3

    if-eq v2, v1, :cond_1

    invoke-virtual {p0, p1, p2, v2, v1}, Landroidx/fragment/app/KLFTb;->Vnb(Ljava/util/ArrayList;Ljava/util/ArrayList;II)V

    :cond_1
    add-int/lit8 v2, v1, 0x1

    invoke-virtual {p2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Boolean;

    invoke-virtual {v3}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v3

    if-eqz v3, :cond_2

    :goto_1
    if-ge v2, v0, :cond_2

    invoke-virtual {p2, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Boolean;

    invoke-virtual {v3}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v3

    if-eqz v3, :cond_2

    invoke-virtual {p1, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroidx/fragment/app/mjFkc;

    iget-boolean v3, v3, Landroidx/fragment/app/lgHUyS;->IEE:Z

    if-nez v3, :cond_2

    add-int/lit8 v2, v2, 0x1

    goto :goto_1

    :cond_2
    invoke-virtual {p0, p1, p2, v1, v2}, Landroidx/fragment/app/KLFTb;->Vnb(Ljava/util/ArrayList;Ljava/util/ArrayList;II)V

    add-int/lit8 v1, v2, -0x1

    :cond_3
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_4
    if-eq v2, v0, :cond_5

    invoke-virtual {p0, p1, p2, v2, v0}, Landroidx/fragment/app/KLFTb;->Vnb(Ljava/util/ArrayList;Ljava/util/ArrayList;II)V

    :cond_5
    return-void

    :cond_6
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string p1, "Internal error with the back stack records"

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public XV()Landroidx/fragment/app/Fragment;
    .locals 0

    iget-object p0, p0, Landroidx/fragment/app/KLFTb;->fehf:Landroidx/fragment/app/Fragment;

    return-object p0
.end method

.method public XbiWeM(Landroidx/fragment/app/Fragment;)V
    .locals 2

    const/4 v0, 0x2

    invoke-static {v0}, Landroidx/fragment/app/KLFTb;->dm(I)Z

    move-result v0

    if-eqz v0, :cond_0

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "remove: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, " nesting="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p1, Landroidx/fragment/app/Fragment;->qGY:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "FragmentManager"

    invoke-static {v1, v0}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    :cond_0
    invoke-virtual {p1}, Landroidx/fragment/app/Fragment;->oCFDzJ()Z

    move-result v0

    iget-boolean v1, p1, Landroidx/fragment/app/Fragment;->Gd:Z

    if-eqz v1, :cond_1

    if-nez v0, :cond_3

    :cond_1
    iget-object v0, p0, Landroidx/fragment/app/KLFTb;->wA:Lo/bVfe;

    invoke-virtual {v0, p1}, Lo/bVfe;->fehf(Landroidx/fragment/app/Fragment;)V

    invoke-virtual {p0, p1}, Landroidx/fragment/app/KLFTb;->tQ(Landroidx/fragment/app/Fragment;)Z

    move-result v0

    const/4 v1, 0x1

    if-eqz v0, :cond_2

    iput-boolean v1, p0, Landroidx/fragment/app/KLFTb;->Gd:Z

    :cond_2
    iput-boolean v1, p1, Landroidx/fragment/app/Fragment;->ETF:Z

    invoke-virtual {p0, p1}, Landroidx/fragment/app/KLFTb;->giT(Landroidx/fragment/app/Fragment;)V

    :cond_3
    return-void
.end method

.method public final XtE()V
    .locals 1

    iget-object v0, p0, Landroidx/fragment/app/KLFTb;->Dt:Ljava/util/ArrayList;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-gtz v0, :cond_0

    goto :goto_0

    :cond_0
    iget-object p0, p0, Landroidx/fragment/app/KLFTb;->Dt:Ljava/util/ArrayList;

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p0

    invoke-static {p0}, Lo/w7;->mjFkc(Ljava/lang/Object;)V

    const/4 p0, 0x0

    throw p0

    :cond_1
    :goto_0
    return-void
.end method

.method public final YoKzxo()Ljava/util/Set;
    .locals 4

    new-instance v0, Ljava/util/HashSet;

    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    iget-object v1, p0, Landroidx/fragment/app/KLFTb;->wA:Lo/bVfe;

    invoke-virtual {v1}, Lo/bVfe;->qdMbNW()Ljava/util/List;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_0
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_1

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroidx/fragment/app/xJ;

    invoke-virtual {v2}, Landroidx/fragment/app/xJ;->ETF()Landroidx/fragment/app/Fragment;

    move-result-object v2

    iget-object v2, v2, Landroidx/fragment/app/Fragment;->wJVbdd:Landroid/view/ViewGroup;

    if-eqz v2, :cond_0

    invoke-virtual {p0}, Landroidx/fragment/app/KLFTb;->SwgkN()Lo/f7;

    move-result-object v3

    invoke-static {v2, v3}, Landroidx/fragment/app/Dt;->YoKzxo(Landroid/view/ViewGroup;Lo/f7;)Landroidx/fragment/app/Dt;

    move-result-object v2

    invoke-interface {v0, v2}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_1
    return-object v0
.end method

.method public ZfxDd(Landroidx/fragment/app/mjFkc;)V
    .locals 1

    iget-object v0, p0, Landroidx/fragment/app/KLFTb;->ZfxDd:Ljava/util/ArrayList;

    if-nez v0, :cond_0

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Landroidx/fragment/app/KLFTb;->ZfxDd:Ljava/util/ArrayList;

    :cond_0
    iget-object p0, p0, Landroidx/fragment/app/KLFTb;->ZfxDd:Ljava/util/ArrayList;

    invoke-virtual {p0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method public alEkx()Z
    .locals 0

    iget-boolean p0, p0, Landroidx/fragment/app/KLFTb;->VocHEe:Z

    return p0
.end method

.method public aqHPIZ(Ljava/lang/String;)Landroidx/fragment/app/Fragment;
    .locals 0

    iget-object p0, p0, Landroidx/fragment/app/KLFTb;->wA:Lo/bVfe;

    invoke-virtual {p0, p1}, Lo/bVfe;->xJ(Ljava/lang/String;)Landroidx/fragment/app/Fragment;

    move-result-object p0

    return-object p0
.end method

.method public bbzow()Landroidx/fragment/app/Fragment;
    .locals 0

    iget-object p0, p0, Landroidx/fragment/app/KLFTb;->IEE:Landroidx/fragment/app/Fragment;

    return-object p0
.end method

.method public cMLeY(Landroidx/fragment/app/KLFTb$lgHUyS;Z)V
    .locals 1

    if-eqz p2, :cond_0

    return-void

    :cond_0
    invoke-virtual {p0, p2}, Landroidx/fragment/app/KLFTb;->KLMXS(Z)V

    iget-object p2, p0, Landroidx/fragment/app/KLFTb;->lB:Ljava/util/ArrayList;

    iget-object v0, p0, Landroidx/fragment/app/KLFTb;->wJVbdd:Ljava/util/ArrayList;

    invoke-interface {p1, p2, v0}, Landroidx/fragment/app/KLFTb$lgHUyS;->mjFkc(Ljava/util/ArrayList;Ljava/util/ArrayList;)Z

    move-result p1

    if-eqz p1, :cond_1

    const/4 p1, 0x1

    iput-boolean p1, p0, Landroidx/fragment/app/KLFTb;->AZxh:Z

    :try_start_0
    iget-object p1, p0, Landroidx/fragment/app/KLFTb;->lB:Ljava/util/ArrayList;

    iget-object p2, p0, Landroidx/fragment/app/KLFTb;->wJVbdd:Ljava/util/ArrayList;

    invoke-virtual {p0, p1, p2}, Landroidx/fragment/app/KLFTb;->XFUzSY(Ljava/util/ArrayList;Ljava/util/ArrayList;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    invoke-virtual {p0}, Landroidx/fragment/app/KLFTb;->MiMN()V

    goto :goto_0

    :catchall_0
    move-exception p1

    invoke-virtual {p0}, Landroidx/fragment/app/KLFTb;->MiMN()V

    throw p1

    :cond_1
    :goto_0
    invoke-virtual {p0}, Landroidx/fragment/app/KLFTb;->gtr()V

    invoke-virtual {p0}, Landroidx/fragment/app/KLFTb;->Ne()V

    iget-object p0, p0, Landroidx/fragment/app/KLFTb;->wA:Lo/bVfe;

    invoke-virtual {p0}, Lo/bVfe;->AZxh()V

    return-void
.end method

.method public diqgf(Landroidx/fragment/app/Fragment;)V
    .locals 4

    const/4 v0, 0x2

    invoke-static {v0}, Landroidx/fragment/app/KLFTb;->dm(I)Z

    move-result v1

    const-string v2, "FragmentManager"

    if-eqz v1, :cond_0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "detach: "

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v2, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    :cond_0
    iget-boolean v1, p1, Landroidx/fragment/app/Fragment;->Gd:Z

    if-nez v1, :cond_3

    const/4 v1, 0x1

    iput-boolean v1, p1, Landroidx/fragment/app/Fragment;->Gd:Z

    iget-boolean v3, p1, Landroidx/fragment/app/Fragment;->Dt:Z

    if-eqz v3, :cond_3

    invoke-static {v0}, Landroidx/fragment/app/KLFTb;->dm(I)Z

    move-result v0

    if-eqz v0, :cond_1

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "remove from detach: "

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v2, v0}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    :cond_1
    iget-object v0, p0, Landroidx/fragment/app/KLFTb;->wA:Lo/bVfe;

    invoke-virtual {v0, p1}, Lo/bVfe;->fehf(Landroidx/fragment/app/Fragment;)V

    invoke-virtual {p0, p1}, Landroidx/fragment/app/KLFTb;->tQ(Landroidx/fragment/app/Fragment;)Z

    move-result v0

    if-eqz v0, :cond_2

    iput-boolean v1, p0, Landroidx/fragment/app/KLFTb;->Gd:Z

    :cond_2
    invoke-virtual {p0, p1}, Landroidx/fragment/app/KLFTb;->giT(Landroidx/fragment/app/Fragment;)V

    :cond_3
    return-void
.end method

.method public eyqo()V
    .locals 2

    const/4 v0, 0x0

    iput-boolean v0, p0, Landroidx/fragment/app/KLFTb;->HGpJ:Z

    iput-boolean v0, p0, Landroidx/fragment/app/KLFTb;->vI:Z

    iget-object v1, p0, Landroidx/fragment/app/KLFTb;->Ne:Lo/bzZHlx;

    invoke-virtual {v1, v0}, Lo/bzZHlx;->qdMbNW(Z)V

    const/4 v0, 0x4

    invoke-virtual {p0, v0}, Landroidx/fragment/app/KLFTb;->wJVbdd(I)V

    return-void
.end method

.method public final fFz(Ljava/util/ArrayList;Ljava/util/ArrayList;IILo/gYa;)I
    .locals 6

    add-int/lit8 v0, p4, -0x1

    move v1, p4

    :goto_0
    if-lt v0, p3, :cond_4

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroidx/fragment/app/mjFkc;

    invoke-virtual {p2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Boolean;

    invoke-virtual {v3}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v3

    invoke-virtual {v2}, Landroidx/fragment/app/mjFkc;->vI()Z

    move-result v4

    if-eqz v4, :cond_3

    add-int/lit8 v4, v0, 0x1

    invoke-virtual {v2, p1, v4, p4}, Landroidx/fragment/app/mjFkc;->Gd(Ljava/util/ArrayList;II)Z

    move-result v4

    if-nez v4, :cond_3

    iget-object v4, p0, Landroidx/fragment/app/KLFTb;->OjSQV:Ljava/util/ArrayList;

    if-nez v4, :cond_0

    new-instance v4, Ljava/util/ArrayList;

    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    iput-object v4, p0, Landroidx/fragment/app/KLFTb;->OjSQV:Ljava/util/ArrayList;

    :cond_0
    new-instance v4, Landroidx/fragment/app/KLFTb$Dt;

    invoke-direct {v4, v2, v3}, Landroidx/fragment/app/KLFTb$Dt;-><init>(Landroidx/fragment/app/mjFkc;Z)V

    iget-object v5, p0, Landroidx/fragment/app/KLFTb;->OjSQV:Ljava/util/ArrayList;

    invoke-virtual {v5, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-virtual {v2, v4}, Landroidx/fragment/app/mjFkc;->BAnRFn(Landroidx/fragment/app/Fragment$ZfxDd;)V

    if-eqz v3, :cond_1

    invoke-virtual {v2}, Landroidx/fragment/app/mjFkc;->Pq()V

    goto :goto_1

    :cond_1
    const/4 v3, 0x0

    invoke-virtual {v2, v3}, Landroidx/fragment/app/mjFkc;->diqgf(Z)V

    :goto_1
    add-int/lit8 v1, v1, -0x1

    if-eq v0, v1, :cond_2

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    invoke-virtual {p1, v1, v2}, Ljava/util/ArrayList;->add(ILjava/lang/Object;)V

    :cond_2
    invoke-virtual {p0, p5}, Landroidx/fragment/app/KLFTb;->wA(Lo/gYa;)V

    :cond_3
    add-int/lit8 v0, v0, -0x1

    goto :goto_0

    :cond_4
    return v1
.end method

.method public final fehf(Landroidx/fragment/app/Fragment;)V
    .locals 1

    iget-object v0, p1, Landroidx/fragment/app/Fragment;->mByQ:Landroid/view/View;

    if-nez v0, :cond_0

    invoke-virtual {p0, p1}, Landroidx/fragment/app/KLFTb;->ANMGZc(Landroidx/fragment/app/Fragment;)V

    const/4 p0, 0x0

    iput-boolean p0, p1, Landroidx/fragment/app/Fragment;->zvd:Z

    iget-boolean p0, p1, Landroidx/fragment/app/Fragment;->huTpC:Z

    invoke-virtual {p1, p0}, Landroidx/fragment/app/Fragment;->SwgkN(Z)V

    return-void

    :cond_0
    const/4 p0, 0x0

    throw p0
.end method

.method public final gYa(Ljava/lang/String;II)Z
    .locals 8

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Landroidx/fragment/app/KLFTb;->zvd(Z)Z

    const/4 v0, 0x1

    invoke-virtual {p0, v0}, Landroidx/fragment/app/KLFTb;->KLMXS(Z)V

    iget-object v1, p0, Landroidx/fragment/app/KLFTb;->IEE:Landroidx/fragment/app/Fragment;

    if-eqz v1, :cond_0

    if-gez p2, :cond_0

    if-nez p1, :cond_0

    invoke-virtual {v1}, Landroidx/fragment/app/Fragment;->MiMN()Landroidx/fragment/app/KLFTb;

    move-result-object v1

    invoke-virtual {v1}, Landroidx/fragment/app/KLFTb;->yX()Z

    move-result v1

    if-eqz v1, :cond_0

    return v0

    :cond_0
    iget-object v3, p0, Landroidx/fragment/app/KLFTb;->lB:Ljava/util/ArrayList;

    iget-object v4, p0, Landroidx/fragment/app/KLFTb;->wJVbdd:Ljava/util/ArrayList;

    move-object v2, p0

    move-object v5, p1

    move v6, p2

    move v7, p3

    invoke-virtual/range {v2 .. v7}, Landroidx/fragment/app/KLFTb;->LREOK(Ljava/util/ArrayList;Ljava/util/ArrayList;Ljava/lang/String;II)Z

    move-result p1

    if-eqz p1, :cond_1

    iput-boolean v0, p0, Landroidx/fragment/app/KLFTb;->AZxh:Z

    :try_start_0
    iget-object p2, p0, Landroidx/fragment/app/KLFTb;->lB:Ljava/util/ArrayList;

    iget-object p3, p0, Landroidx/fragment/app/KLFTb;->wJVbdd:Ljava/util/ArrayList;

    invoke-virtual {p0, p2, p3}, Landroidx/fragment/app/KLFTb;->XFUzSY(Ljava/util/ArrayList;Ljava/util/ArrayList;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    invoke-virtual {p0}, Landroidx/fragment/app/KLFTb;->MiMN()V

    goto :goto_0

    :catchall_0
    move-exception p1

    invoke-virtual {p0}, Landroidx/fragment/app/KLFTb;->MiMN()V

    throw p1

    :cond_1
    :goto_0
    invoke-virtual {p0}, Landroidx/fragment/app/KLFTb;->gtr()V

    invoke-virtual {p0}, Landroidx/fragment/app/KLFTb;->Ne()V

    iget-object p0, p0, Landroidx/fragment/app/KLFTb;->wA:Lo/bVfe;

    invoke-virtual {p0}, Lo/bVfe;->AZxh()V

    return p1
.end method

.method public final giT(Landroidx/fragment/app/Fragment;)V
    .locals 2

    invoke-virtual {p0, p1}, Landroidx/fragment/app/KLFTb;->JYn(Landroidx/fragment/app/Fragment;)Landroid/view/ViewGroup;

    move-result-object p0

    if-eqz p0, :cond_1

    invoke-virtual {p1}, Landroidx/fragment/app/Fragment;->rkYL()I

    move-result v0

    invoke-virtual {p1}, Landroidx/fragment/app/Fragment;->IEE()I

    move-result v1

    add-int/2addr v0, v1

    invoke-virtual {p1}, Landroidx/fragment/app/Fragment;->BAnRFn()I

    move-result v1

    add-int/2addr v0, v1

    invoke-virtual {p1}, Landroidx/fragment/app/Fragment;->lB()I

    move-result v1

    add-int/2addr v0, v1

    if-lez v0, :cond_1

    sget v0, Lo/y4;->wA:I

    invoke-virtual {p0, v0}, Landroid/view/View;->getTag(I)Ljava/lang/Object;

    move-result-object v0

    if-nez v0, :cond_0

    sget v0, Lo/y4;->wA:I

    invoke-virtual {p0, v0, p1}, Landroid/view/View;->setTag(ILjava/lang/Object;)V

    :cond_0
    sget v0, Lo/y4;->wA:I

    invoke-virtual {p0, v0}, Landroid/view/View;->getTag(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroidx/fragment/app/Fragment;

    invoke-virtual {p1}, Landroidx/fragment/app/Fragment;->VocHEe()Z

    move-result p1

    invoke-virtual {p0, p1}, Landroidx/fragment/app/Fragment;->sRqPfw(Z)V

    :cond_1
    return-void
.end method

.method public gtIJp(Landroidx/fragment/app/FragmentContainerView;)V
    .locals 4

    iget-object p0, p0, Landroidx/fragment/app/KLFTb;->wA:Lo/bVfe;

    invoke-virtual {p0}, Lo/bVfe;->qdMbNW()Ljava/util/List;

    move-result-object p0

    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :cond_0
    :goto_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_1

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroidx/fragment/app/xJ;

    invoke-virtual {v0}, Landroidx/fragment/app/xJ;->ETF()Landroidx/fragment/app/Fragment;

    move-result-object v1

    iget v2, v1, Landroidx/fragment/app/Fragment;->eyqo:I

    invoke-virtual {p1}, Landroid/view/View;->getId()I

    move-result v3

    if-ne v2, v3, :cond_0

    iget-object v2, v1, Landroidx/fragment/app/Fragment;->mByQ:Landroid/view/View;

    if-eqz v2, :cond_0

    invoke-virtual {v2}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v2

    if-nez v2, :cond_0

    iput-object p1, v1, Landroidx/fragment/app/Fragment;->wJVbdd:Landroid/view/ViewGroup;

    invoke-virtual {v0}, Landroidx/fragment/app/xJ;->AZxh()V

    goto :goto_0

    :cond_1
    return-void
.end method

.method public final gtr()V
    .locals 3

    iget-object v0, p0, Landroidx/fragment/app/KLFTb;->mjFkc:Ljava/util/ArrayList;

    monitor-enter v0

    :try_start_0
    iget-object v1, p0, Landroidx/fragment/app/KLFTb;->mjFkc:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v1

    const/4 v2, 0x1

    if-nez v1, :cond_0

    iget-object p0, p0, Landroidx/fragment/app/KLFTb;->JHa:Lo/Y2;

    invoke-virtual {p0, v2}, Lo/Y2;->AZxh(Z)V

    monitor-exit v0

    return-void

    :catchall_0
    move-exception p0

    goto :goto_1

    :cond_0
    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    iget-object v0, p0, Landroidx/fragment/app/KLFTb;->JHa:Lo/Y2;

    invoke-virtual {p0}, Landroidx/fragment/app/KLFTb;->KRTLGT()I

    move-result v1

    if-lez v1, :cond_1

    iget-object v1, p0, Landroidx/fragment/app/KLFTb;->fehf:Landroidx/fragment/app/Fragment;

    invoke-virtual {p0, v1}, Landroidx/fragment/app/KLFTb;->yfx(Landroidx/fragment/app/Fragment;)Z

    move-result p0

    if-eqz p0, :cond_1

    goto :goto_0

    :cond_1
    const/4 v2, 0x0

    :goto_0
    invoke-virtual {v0, v2}, Lo/Y2;->AZxh(Z)V

    return-void

    :goto_1
    :try_start_1
    monitor-exit v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw p0
.end method

.method public huTpC()V
    .locals 1

    const/4 v0, 0x1

    iput-boolean v0, p0, Landroidx/fragment/app/KLFTb;->VocHEe:Z

    invoke-virtual {p0, v0}, Landroidx/fragment/app/KLFTb;->zvd(Z)Z

    invoke-virtual {p0}, Landroidx/fragment/app/KLFTb;->CqaNbM()V

    const/4 v0, -0x1

    invoke-virtual {p0, v0}, Landroidx/fragment/app/KLFTb;->wJVbdd(I)V

    const/4 v0, 0x0

    iput-object v0, p0, Landroidx/fragment/app/KLFTb;->qGY:Lo/jeHSg;

    iput-object v0, p0, Landroidx/fragment/app/KLFTb;->fehf:Landroidx/fragment/app/Fragment;

    return-void
.end method

.method public jm(Landroidx/fragment/app/Fragment;)V
    .locals 2

    const/4 v0, 0x2

    invoke-static {v0}, Landroidx/fragment/app/KLFTb;->dm(I)Z

    move-result v0

    if-eqz v0, :cond_0

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "hide: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "FragmentManager"

    invoke-static {v1, v0}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    :cond_0
    iget-boolean v0, p1, Landroidx/fragment/app/Fragment;->huTpC:Z

    if-nez v0, :cond_1

    const/4 v0, 0x1

    iput-boolean v0, p1, Landroidx/fragment/app/Fragment;->huTpC:Z

    iget-boolean v1, p1, Landroidx/fragment/app/Fragment;->zvd:Z

    xor-int/2addr v0, v1

    iput-boolean v0, p1, Landroidx/fragment/app/Fragment;->zvd:Z

    invoke-virtual {p0, p1}, Landroidx/fragment/app/KLFTb;->giT(Landroidx/fragment/app/Fragment;)V

    :cond_1
    return-void
.end method

.method public jx(Landroid/os/Parcelable;)V
    .locals 9

    if-nez p1, :cond_0

    return-void

    :cond_0
    check-cast p1, Landroidx/fragment/app/JHa;

    iget-object v0, p1, Landroidx/fragment/app/JHa;->mjFkc:Ljava/util/ArrayList;

    if-nez v0, :cond_1

    return-void

    :cond_1
    iget-object v0, p0, Landroidx/fragment/app/KLFTb;->wA:Lo/bVfe;

    invoke-virtual {v0}, Lo/bVfe;->IEE()V

    iget-object v0, p1, Landroidx/fragment/app/JHa;->mjFkc:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_2
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const-string v2, "): "

    const/4 v3, 0x0

    const/4 v4, 0x2

    const-string v5, "FragmentManager"

    if-eqz v1, :cond_5

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lo/gy;

    if-eqz v1, :cond_2

    iget-object p1, p0, Landroidx/fragment/app/KLFTb;->Ne:Lo/bzZHlx;

    iget-object v0, v1, Lo/gy;->AZxh:Ljava/lang/String;

    invoke-virtual {p1, v0}, Lo/bzZHlx;->ZfxDd(Ljava/lang/String;)Landroidx/fragment/app/Fragment;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v4}, Landroidx/fragment/app/KLFTb;->dm(I)Z

    move-result v0

    if-eqz v0, :cond_3

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "restoreSaveState: re-attaching retained "

    invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v5, v0}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    :cond_3
    new-instance v0, Landroidx/fragment/app/xJ;

    iget-object v6, p0, Landroidx/fragment/app/KLFTb;->MiMN:Lo/DanUFX;

    iget-object v7, p0, Landroidx/fragment/app/KLFTb;->wA:Lo/bVfe;

    invoke-direct {v0, v6, v7, p1, v1}, Landroidx/fragment/app/xJ;-><init>(Lo/DanUFX;Lo/bVfe;Landroidx/fragment/app/Fragment;Lo/gy;)V

    invoke-virtual {v0}, Landroidx/fragment/app/xJ;->ETF()Landroidx/fragment/app/Fragment;

    move-result-object p1

    iput-object p0, p1, Landroidx/fragment/app/Fragment;->fehf:Landroidx/fragment/app/KLFTb;

    invoke-static {v4}, Landroidx/fragment/app/KLFTb;->dm(I)Z

    move-result p0

    if-eqz p0, :cond_4

    new-instance p0, Ljava/lang/StringBuilder;

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v0, "restoreSaveState: active ("

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v0, p1, Landroidx/fragment/app/Fragment;->KLFTb:Ljava/lang/String;

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-static {v5, p0}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    :cond_4
    throw v3

    :cond_5
    iget-object v0, p0, Landroidx/fragment/app/KLFTb;->Ne:Lo/bzZHlx;

    invoke-virtual {v0}, Lo/bzZHlx;->JHa()Ljava/util/Collection;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_6
    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_8

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroidx/fragment/app/Fragment;

    iget-object v6, p0, Landroidx/fragment/app/KLFTb;->wA:Lo/bVfe;

    iget-object v7, v1, Landroidx/fragment/app/Fragment;->KLFTb:Ljava/lang/String;

    invoke-virtual {v6, v7}, Lo/bVfe;->wA(Ljava/lang/String;)Z

    move-result v6

    if-nez v6, :cond_6

    invoke-static {v4}, Landroidx/fragment/app/KLFTb;->dm(I)Z

    move-result v6

    if-eqz v6, :cond_7

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const-string v7, "Discarding retained Fragment "

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v7, " that was not found in the set of active Fragments "

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v7, p1, Landroidx/fragment/app/JHa;->mjFkc:Ljava/util/ArrayList;

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {v5, v6}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    :cond_7
    iget-object v6, p0, Landroidx/fragment/app/KLFTb;->Ne:Lo/bzZHlx;

    invoke-virtual {v6, v1}, Lo/bzZHlx;->lgHUyS(Landroidx/fragment/app/Fragment;)V

    iput-object p0, v1, Landroidx/fragment/app/Fragment;->fehf:Landroidx/fragment/app/KLFTb;

    new-instance v6, Landroidx/fragment/app/xJ;

    iget-object v7, p0, Landroidx/fragment/app/KLFTb;->MiMN:Lo/DanUFX;

    iget-object v8, p0, Landroidx/fragment/app/KLFTb;->wA:Lo/bVfe;

    invoke-direct {v6, v7, v8, v1}, Landroidx/fragment/app/xJ;-><init>(Lo/DanUFX;Lo/bVfe;Landroidx/fragment/app/Fragment;)V

    const/4 v7, 0x1

    invoke-virtual {v6, v7}, Landroidx/fragment/app/xJ;->fehf(I)V

    invoke-virtual {v6}, Landroidx/fragment/app/xJ;->MiMN()V

    iput-boolean v7, v1, Landroidx/fragment/app/Fragment;->ETF:Z

    invoke-virtual {v6}, Landroidx/fragment/app/xJ;->MiMN()V

    goto :goto_0

    :cond_8
    iget-object v0, p0, Landroidx/fragment/app/KLFTb;->wA:Lo/bVfe;

    iget-object v1, p1, Landroidx/fragment/app/JHa;->AZxh:Ljava/util/ArrayList;

    invoke-virtual {v0, v1}, Lo/bVfe;->Pq(Ljava/util/List;)V

    iget-object v0, p1, Landroidx/fragment/app/JHa;->wA:[Landroidx/fragment/app/AZxh;

    const/4 v1, 0x0

    if-eqz v0, :cond_a

    new-instance v0, Ljava/util/ArrayList;

    iget-object v6, p1, Landroidx/fragment/app/JHa;->wA:[Landroidx/fragment/app/AZxh;

    array-length v6, v6

    invoke-direct {v0, v6}, Ljava/util/ArrayList;-><init>(I)V

    iput-object v0, p0, Landroidx/fragment/app/KLFTb;->ZfxDd:Ljava/util/ArrayList;

    move v0, v1

    :goto_1
    iget-object v6, p1, Landroidx/fragment/app/JHa;->wA:[Landroidx/fragment/app/AZxh;

    array-length v7, v6

    if-ge v0, v7, :cond_b

    aget-object v6, v6, v0

    invoke-virtual {v6, p0}, Landroidx/fragment/app/AZxh;->mjFkc(Landroidx/fragment/app/KLFTb;)Landroidx/fragment/app/mjFkc;

    move-result-object v6

    invoke-static {v4}, Landroidx/fragment/app/KLFTb;->dm(I)Z

    move-result v7

    if-eqz v7, :cond_9

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    const-string v8, "restoreAllState: back stack #"

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v8, " (index "

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v8, v6, Landroidx/fragment/app/mjFkc;->Ucbh:I

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v7, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-static {v5, v7}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    new-instance v7, Lo/l1;

    invoke-direct {v7, v5}, Lo/l1;-><init>(Ljava/lang/String;)V

    new-instance v8, Ljava/io/PrintWriter;

    invoke-direct {v8, v7}, Ljava/io/PrintWriter;-><init>(Ljava/io/Writer;)V

    const-string v7, "  "

    invoke-virtual {v6, v7, v8, v1}, Landroidx/fragment/app/mjFkc;->IEE(Ljava/lang/String;Ljava/io/PrintWriter;Z)V

    invoke-virtual {v8}, Ljava/io/PrintWriter;->close()V

    :cond_9
    iget-object v7, p0, Landroidx/fragment/app/KLFTb;->ZfxDd:Ljava/util/ArrayList;

    invoke-virtual {v7, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v0, v0, 0x1

    goto :goto_1

    :cond_a
    iput-object v3, p0, Landroidx/fragment/app/KLFTb;->ZfxDd:Ljava/util/ArrayList;

    :cond_b
    iget-object v0, p0, Landroidx/fragment/app/KLFTb;->xJ:Ljava/util/concurrent/atomic/AtomicInteger;

    iget v2, p1, Landroidx/fragment/app/JHa;->ZfxDd:I

    invoke-virtual {v0, v2}, Ljava/util/concurrent/atomic/AtomicInteger;->set(I)V

    iget-object v0, p1, Landroidx/fragment/app/JHa;->KLFTb:Ljava/lang/String;

    if-eqz v0, :cond_c

    invoke-virtual {p0, v0}, Landroidx/fragment/app/KLFTb;->vadzgd(Ljava/lang/String;)Landroidx/fragment/app/Fragment;

    move-result-object v0

    iput-object v0, p0, Landroidx/fragment/app/KLFTb;->IEE:Landroidx/fragment/app/Fragment;

    invoke-virtual {p0, v0}, Landroidx/fragment/app/KLFTb;->HGpJ(Landroidx/fragment/app/Fragment;)V

    :cond_c
    iget-object v0, p1, Landroidx/fragment/app/JHa;->JHa:Ljava/util/ArrayList;

    if-eqz v0, :cond_e

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-gtz v0, :cond_d

    goto :goto_2

    :cond_d
    iget-object p0, p1, Landroidx/fragment/app/JHa;->xJ:Ljava/util/ArrayList;

    invoke-virtual {p0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/os/Bundle;

    throw v3

    :cond_e
    :goto_2
    new-instance v0, Ljava/util/ArrayDeque;

    iget-object p1, p1, Landroidx/fragment/app/JHa;->lgHUyS:Ljava/util/ArrayList;

    invoke-direct {v0, p1}, Ljava/util/ArrayDeque;-><init>(Ljava/util/Collection;)V

    iput-object v0, p0, Landroidx/fragment/app/KLFTb;->huTpC:Ljava/util/ArrayDeque;

    return-void
.end method

.method public kism(Landroidx/fragment/app/xJ;)V
    .locals 2

    invoke-virtual {p1}, Landroidx/fragment/app/xJ;->ETF()Landroidx/fragment/app/Fragment;

    move-result-object v0

    iget-boolean v1, v0, Landroidx/fragment/app/Fragment;->OjSQV:Z

    if-eqz v1, :cond_2

    iget-boolean v1, p0, Landroidx/fragment/app/KLFTb;->AZxh:Z

    if-eqz v1, :cond_0

    const/4 p1, 0x1

    iput-boolean p1, p0, Landroidx/fragment/app/KLFTb;->BAnRFn:Z

    return-void

    :cond_0
    const/4 v1, 0x0

    iput-boolean v1, v0, Landroidx/fragment/app/Fragment;->OjSQV:Z

    sget-boolean v1, Landroidx/fragment/app/KLFTb;->KLMXS:Z

    if-eqz v1, :cond_1

    invoke-virtual {p1}, Landroidx/fragment/app/xJ;->MiMN()V

    goto :goto_0

    :cond_1
    invoke-virtual {p0, v0}, Landroidx/fragment/app/KLFTb;->SOS(Landroidx/fragment/app/Fragment;)V

    :cond_2
    :goto_0
    return-void
.end method

.method public lB()V
    .locals 2

    const/4 v0, 0x0

    iput-boolean v0, p0, Landroidx/fragment/app/KLFTb;->HGpJ:Z

    iput-boolean v0, p0, Landroidx/fragment/app/KLFTb;->vI:Z

    iget-object v1, p0, Landroidx/fragment/app/KLFTb;->Ne:Lo/bzZHlx;

    invoke-virtual {v1, v0}, Lo/bzZHlx;->qdMbNW(Z)V

    const/4 v0, 0x5

    invoke-virtual {p0, v0}, Landroidx/fragment/app/KLFTb;->wJVbdd(I)V

    return-void
.end method

.method public lgHUyS(Lo/aAlqX;Lo/jeHSg;Landroidx/fragment/app/Fragment;)V
    .locals 0

    iput-object p2, p0, Landroidx/fragment/app/KLFTb;->qGY:Lo/jeHSg;

    iput-object p3, p0, Landroidx/fragment/app/KLFTb;->fehf:Landroidx/fragment/app/Fragment;

    if-eqz p3, :cond_0

    new-instance p1, Landroidx/fragment/app/KLFTb$JHa;

    invoke-direct {p1, p0, p3}, Landroidx/fragment/app/KLFTb$JHa;-><init>(Landroidx/fragment/app/KLFTb;Landroidx/fragment/app/Fragment;)V

    invoke-virtual {p0, p1}, Landroidx/fragment/app/KLFTb;->JHa(Lo/EaLbDP;)V

    :cond_0
    iget-object p1, p0, Landroidx/fragment/app/KLFTb;->fehf:Landroidx/fragment/app/Fragment;

    if-eqz p1, :cond_1

    invoke-virtual {p0}, Landroidx/fragment/app/KLFTb;->gtr()V

    :cond_1
    if-eqz p3, :cond_2

    iget-object p1, p3, Landroidx/fragment/app/Fragment;->fehf:Landroidx/fragment/app/KLFTb;

    invoke-virtual {p1, p3}, Landroidx/fragment/app/KLFTb;->GMIER(Landroidx/fragment/app/Fragment;)Lo/bzZHlx;

    move-result-object p1

    iput-object p1, p0, Landroidx/fragment/app/KLFTb;->Ne:Lo/bzZHlx;

    goto :goto_0

    :cond_2
    new-instance p1, Lo/bzZHlx;

    const/4 p2, 0x0

    invoke-direct {p1, p2}, Lo/bzZHlx;-><init>(Z)V

    iput-object p1, p0, Landroidx/fragment/app/KLFTb;->Ne:Lo/bzZHlx;

    :goto_0
    iget-object p1, p0, Landroidx/fragment/app/KLFTb;->Ne:Lo/bzZHlx;

    invoke-virtual {p0}, Landroidx/fragment/app/KLFTb;->xROA()Z

    move-result p2

    invoke-virtual {p1, p2}, Lo/bzZHlx;->qdMbNW(Z)V

    iget-object p1, p0, Landroidx/fragment/app/KLFTb;->wA:Lo/bVfe;

    iget-object p0, p0, Landroidx/fragment/app/KLFTb;->Ne:Lo/bzZHlx;

    invoke-virtual {p1, p0}, Lo/bVfe;->diqgf(Lo/bzZHlx;)V

    return-void
.end method

.method public lti(Landroidx/fragment/app/Fragment;)V
    .locals 3

    if-eqz p1, :cond_1

    iget-object v0, p1, Landroidx/fragment/app/Fragment;->KLFTb:Ljava/lang/String;

    invoke-virtual {p0, v0}, Landroidx/fragment/app/KLFTb;->vadzgd(Ljava/lang/String;)Landroidx/fragment/app/Fragment;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroidx/fragment/app/Fragment;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    goto :goto_0

    :cond_0
    new-instance v0, Ljava/lang/IllegalArgumentException;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "Fragment "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p1, " is not an active fragment of FragmentManager "

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_1
    :goto_0
    iget-object v0, p0, Landroidx/fragment/app/KLFTb;->IEE:Landroidx/fragment/app/Fragment;

    iput-object p1, p0, Landroidx/fragment/app/KLFTb;->IEE:Landroidx/fragment/app/Fragment;

    invoke-virtual {p0, v0}, Landroidx/fragment/app/KLFTb;->HGpJ(Landroidx/fragment/app/Fragment;)V

    iget-object p1, p0, Landroidx/fragment/app/KLFTb;->IEE:Landroidx/fragment/app/Fragment;

    invoke-virtual {p0, p1}, Landroidx/fragment/app/KLFTb;->HGpJ(Landroidx/fragment/app/Fragment;)V

    return-void
.end method

.method public mByQ()V
    .locals 2

    const/4 v0, 0x1

    iput-boolean v0, p0, Landroidx/fragment/app/KLFTb;->vI:Z

    iget-object v1, p0, Landroidx/fragment/app/KLFTb;->Ne:Lo/bzZHlx;

    invoke-virtual {v1, v0}, Lo/bzZHlx;->qdMbNW(Z)V

    const/4 v0, 0x4

    invoke-virtual {p0, v0}, Landroidx/fragment/app/KLFTb;->wJVbdd(I)V

    return-void
.end method

.method public nxI()Lo/aAlqX;
    .locals 0

    const/4 p0, 0x0

    return-object p0
.end method

.method public oCFDzJ(I)Landroidx/fragment/app/Fragment;
    .locals 0

    iget-object p0, p0, Landroidx/fragment/app/KLFTb;->wA:Lo/bVfe;

    invoke-virtual {p0, p1}, Lo/bVfe;->JHa(I)Landroidx/fragment/app/Fragment;

    move-result-object p0

    return-object p0
.end method

.method public qGY(Landroidx/fragment/app/mjFkc;ZZZ)V
    .locals 3

    if-eqz p2, :cond_0

    invoke-virtual {p1, p4}, Landroidx/fragment/app/mjFkc;->diqgf(Z)V

    goto :goto_0

    :cond_0
    invoke-virtual {p1}, Landroidx/fragment/app/mjFkc;->Pq()V

    :goto_0
    new-instance v0, Ljava/util/ArrayList;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2, v1}, Ljava/util/ArrayList;-><init>(I)V

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-static {p2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p2

    invoke-virtual {v2, p2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    if-eqz p3, :cond_2

    iget p2, p0, Landroidx/fragment/app/KLFTb;->rkYL:I

    if-ge p2, v1, :cond_1

    goto :goto_1

    :cond_1
    const/4 p0, 0x0

    throw p0

    :cond_2
    :goto_1
    if-eqz p4, :cond_3

    iget p2, p0, Landroidx/fragment/app/KLFTb;->rkYL:I

    invoke-virtual {p0, p2, v1}, Landroidx/fragment/app/KLFTb;->SmIWf(IZ)V

    :cond_3
    iget-object p0, p0, Landroidx/fragment/app/KLFTb;->wA:Lo/bVfe;

    invoke-virtual {p0}, Lo/bVfe;->Dt()Ljava/util/List;

    move-result-object p0

    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :cond_4
    :goto_2
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result p2

    if-eqz p2, :cond_7

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Landroidx/fragment/app/Fragment;

    if-eqz p2, :cond_4

    iget-object p3, p2, Landroidx/fragment/app/Fragment;->mByQ:Landroid/view/View;

    if-eqz p3, :cond_4

    iget-boolean p3, p2, Landroidx/fragment/app/Fragment;->KLMXS:Z

    if-eqz p3, :cond_4

    iget p3, p2, Landroidx/fragment/app/Fragment;->eyqo:I

    invoke-virtual {p1, p3}, Landroidx/fragment/app/mjFkc;->huTpC(I)Z

    move-result p3

    if-eqz p3, :cond_4

    iget p3, p2, Landroidx/fragment/app/Fragment;->cMLeY:F

    const/4 v0, 0x0

    cmpl-float v1, p3, v0

    if-lez v1, :cond_5

    iget-object v1, p2, Landroidx/fragment/app/Fragment;->mByQ:Landroid/view/View;

    invoke-virtual {v1, p3}, Landroid/view/View;->setAlpha(F)V

    :cond_5
    if-eqz p4, :cond_6

    iput v0, p2, Landroidx/fragment/app/Fragment;->cMLeY:F

    goto :goto_2

    :cond_6
    const/high16 p3, -0x40800000    # -1.0f

    iput p3, p2, Landroidx/fragment/app/Fragment;->cMLeY:F

    const/4 p3, 0x0

    iput-boolean p3, p2, Landroidx/fragment/app/Fragment;->KLMXS:Z

    goto :goto_2

    :cond_7
    return-void
.end method

.method public qdMbNW(Landroidx/fragment/app/Fragment;)V
    .locals 4

    const/4 v0, 0x2

    invoke-static {v0}, Landroidx/fragment/app/KLFTb;->dm(I)Z

    move-result v1

    const-string v2, "FragmentManager"

    if-eqz v1, :cond_0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "attach: "

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v2, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    :cond_0
    iget-boolean v1, p1, Landroidx/fragment/app/Fragment;->Gd:Z

    if-eqz v1, :cond_2

    const/4 v1, 0x0

    iput-boolean v1, p1, Landroidx/fragment/app/Fragment;->Gd:Z

    iget-boolean v1, p1, Landroidx/fragment/app/Fragment;->Dt:Z

    if-nez v1, :cond_2

    iget-object v1, p0, Landroidx/fragment/app/KLFTb;->wA:Lo/bVfe;

    invoke-virtual {v1, p1}, Lo/bVfe;->mjFkc(Landroidx/fragment/app/Fragment;)V

    invoke-static {v0}, Landroidx/fragment/app/KLFTb;->dm(I)Z

    move-result v0

    if-eqz v0, :cond_1

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "add from attach: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v2, v0}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    :cond_1
    invoke-virtual {p0, p1}, Landroidx/fragment/app/KLFTb;->tQ(Landroidx/fragment/app/Fragment;)Z

    move-result p1

    if-eqz p1, :cond_2

    const/4 p1, 0x1

    iput-boolean p1, p0, Landroidx/fragment/app/KLFTb;->Gd:Z

    :cond_2
    return-void
.end method

.method public final rkYL(Ljava/util/ArrayList;II)Ljava/util/Set;
    .locals 3

    new-instance v0, Ljava/util/HashSet;

    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    :goto_0
    if-ge p2, p3, :cond_2

    invoke-virtual {p1, p2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroidx/fragment/app/mjFkc;

    iget-object v1, v1, Landroidx/fragment/app/lgHUyS;->wA:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_0
    :goto_1
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_1

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroidx/fragment/app/lgHUyS$mjFkc;

    iget-object v2, v2, Landroidx/fragment/app/lgHUyS$mjFkc;->AZxh:Landroidx/fragment/app/Fragment;

    if-eqz v2, :cond_0

    iget-object v2, v2, Landroidx/fragment/app/Fragment;->wJVbdd:Landroid/view/ViewGroup;

    if-eqz v2, :cond_0

    invoke-static {v2, p0}, Landroidx/fragment/app/Dt;->MiMN(Landroid/view/ViewGroup;Landroidx/fragment/app/KLFTb;)Landroidx/fragment/app/Dt;

    move-result-object v2

    invoke-interface {v0, v2}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    goto :goto_1

    :cond_1
    add-int/lit8 p2, p2, 0x1

    goto :goto_0

    :cond_2
    return-object v0
.end method

.method public sRqPfw(Landroidx/fragment/app/Fragment;)V
    .locals 1

    const/4 p0, 0x2

    invoke-static {p0}, Landroidx/fragment/app/KLFTb;->dm(I)Z

    move-result p0

    if-eqz p0, :cond_0

    new-instance p0, Ljava/lang/StringBuilder;

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v0, "show: "

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const-string v0, "FragmentManager"

    invoke-static {v0, p0}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    :cond_0
    iget-boolean p0, p1, Landroidx/fragment/app/Fragment;->huTpC:Z

    if-eqz p0, :cond_1

    const/4 p0, 0x0

    iput-boolean p0, p1, Landroidx/fragment/app/Fragment;->huTpC:Z

    iget-boolean p0, p1, Landroidx/fragment/app/Fragment;->zvd:Z

    xor-int/lit8 p0, p0, 0x1

    iput-boolean p0, p1, Landroidx/fragment/app/Fragment;->zvd:Z

    :cond_1
    return-void
.end method

.method public tISON(Landroidx/fragment/app/Fragment;Z)V
    .locals 0

    invoke-virtual {p0, p1}, Landroidx/fragment/app/KLFTb;->JYn(Landroidx/fragment/app/Fragment;)Landroid/view/ViewGroup;

    move-result-object p0

    if-eqz p0, :cond_0

    instance-of p1, p0, Landroidx/fragment/app/FragmentContainerView;

    if-eqz p1, :cond_0

    check-cast p0, Landroidx/fragment/app/FragmentContainerView;

    xor-int/lit8 p1, p2, 0x1

    invoke-virtual {p0, p1}, Landroidx/fragment/app/FragmentContainerView;->setDrawDisappearingViewsLast(Z)V

    :cond_0
    return-void
.end method

.method public final tQ(Landroidx/fragment/app/Fragment;)Z
    .locals 0

    iget-boolean p0, p1, Landroidx/fragment/app/Fragment;->VocHEe:Z

    if-eqz p0, :cond_0

    iget-boolean p0, p1, Landroidx/fragment/app/Fragment;->BAnRFn:Z

    if-nez p0, :cond_1

    :cond_0
    iget-object p0, p1, Landroidx/fragment/app/Fragment;->IEE:Landroidx/fragment/app/KLFTb;

    invoke-virtual {p0}, Landroidx/fragment/app/KLFTb;->VA()Z

    move-result p0

    if-eqz p0, :cond_2

    :cond_1
    const/4 p0, 0x1

    goto :goto_0

    :cond_2
    const/4 p0, 0x0

    :goto_0
    return p0
.end method

.method public tjSezt(II)V
    .locals 2

    if-ltz p1, :cond_0

    new-instance v0, Landroidx/fragment/app/KLFTb$qdMbNW;

    const/4 v1, 0x0

    invoke-direct {v0, p0, v1, p1, p2}, Landroidx/fragment/app/KLFTb$qdMbNW;-><init>(Landroidx/fragment/app/KLFTb;Ljava/lang/String;II)V

    const/4 p1, 0x0

    invoke-virtual {p0, v0, p1}, Landroidx/fragment/app/KLFTb;->xrEuO(Landroidx/fragment/app/KLFTb$lgHUyS;Z)V

    return-void

    :cond_0
    new-instance p0, Ljava/lang/IllegalArgumentException;

    new-instance p2, Ljava/lang/StringBuilder;

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v0, "Bad id: "

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public toString()Ljava/lang/String;
    .locals 2

    new-instance v0, Ljava/lang/StringBuilder;

    const/16 v1, 0x80

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(I)V

    const-string v1, "FragmentManager{"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {p0}, Ljava/lang/System;->identityHashCode(Ljava/lang/Object;)I

    move-result v1

    invoke-static {v1}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, " in "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Landroidx/fragment/app/KLFTb;->fehf:Landroidx/fragment/app/Fragment;

    if-eqz v1, :cond_0

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "{"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object p0, p0, Landroidx/fragment/app/KLFTb;->fehf:Landroidx/fragment/app/Fragment;

    invoke-static {p0}, Ljava/lang/System;->identityHashCode(Ljava/lang/Object;)I

    move-result p0

    invoke-static {p0}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p0, "}"

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_0

    :cond_0
    const-string p0, "null"

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :goto_0
    const-string p0, "}}"

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public uHVRx()Lo/jeHSg;
    .locals 0

    iget-object p0, p0, Landroidx/fragment/app/KLFTb;->qGY:Lo/jeHSg;

    return-object p0
.end method

.method public vI()V
    .locals 1

    const/4 v0, 0x5

    invoke-virtual {p0, v0}, Landroidx/fragment/app/KLFTb;->wJVbdd(I)V

    return-void
.end method

.method public vadzgd(Ljava/lang/String;)Landroidx/fragment/app/Fragment;
    .locals 0

    iget-object p0, p0, Landroidx/fragment/app/KLFTb;->wA:Lo/bVfe;

    invoke-virtual {p0, p1}, Lo/bVfe;->KLFTb(Ljava/lang/String;)Landroidx/fragment/app/Fragment;

    move-result-object p0

    return-object p0
.end method

.method public vjlshU(I)Z
    .locals 0

    iget p0, p0, Landroidx/fragment/app/KLFTb;->rkYL:I

    if-lt p0, p1, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method

.method public final wA(Lo/gYa;)V
    .locals 4

    iget v0, p0, Landroidx/fragment/app/KLFTb;->rkYL:I

    const/4 v1, 0x1

    if-ge v0, v1, :cond_0

    return-void

    :cond_0
    const/4 v1, 0x5

    invoke-static {v0, v1}, Ljava/lang/Math;->min(II)I

    move-result v0

    iget-object v1, p0, Landroidx/fragment/app/KLFTb;->wA:Lo/bVfe;

    invoke-virtual {v1}, Lo/bVfe;->VA()Ljava/util/List;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_1
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_2

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroidx/fragment/app/Fragment;

    iget v3, v2, Landroidx/fragment/app/Fragment;->mjFkc:I

    if-ge v3, v0, :cond_1

    invoke-virtual {p0, v2, v0}, Landroidx/fragment/app/KLFTb;->Qr(Landroidx/fragment/app/Fragment;I)V

    iget-object v3, v2, Landroidx/fragment/app/Fragment;->mByQ:Landroid/view/View;

    if-eqz v3, :cond_1

    iget-boolean v3, v2, Landroidx/fragment/app/Fragment;->huTpC:Z

    if-nez v3, :cond_1

    iget-boolean v3, v2, Landroidx/fragment/app/Fragment;->KLMXS:Z

    if-eqz v3, :cond_1

    invoke-virtual {p1, v2}, Lo/gYa;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_2
    return-void
.end method

.method public final wJVbdd(I)V
    .locals 3

    const/4 v0, 0x1

    const/4 v1, 0x0

    :try_start_0
    iput-boolean v0, p0, Landroidx/fragment/app/KLFTb;->AZxh:Z

    iget-object v2, p0, Landroidx/fragment/app/KLFTb;->wA:Lo/bVfe;

    invoke-virtual {v2, p1}, Lo/bVfe;->ZfxDd(I)V

    invoke-virtual {p0, p1, v1}, Landroidx/fragment/app/KLFTb;->SmIWf(IZ)V

    sget-boolean p1, Landroidx/fragment/app/KLFTb;->KLMXS:Z

    if-eqz p1, :cond_0

    invoke-virtual {p0}, Landroidx/fragment/app/KLFTb;->YoKzxo()Ljava/util/Set;

    move-result-object p1

    invoke-interface {p1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_0
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_0

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroidx/fragment/app/Dt;

    invoke-virtual {v2}, Landroidx/fragment/app/Dt;->Dt()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception p1

    goto :goto_1

    :cond_0
    iput-boolean v1, p0, Landroidx/fragment/app/KLFTb;->AZxh:Z

    invoke-virtual {p0, v0}, Landroidx/fragment/app/KLFTb;->zvd(Z)Z

    return-void

    :goto_1
    iput-boolean v1, p0, Landroidx/fragment/app/KLFTb;->AZxh:Z

    throw p1
.end method

.method public xJ()I
    .locals 0

    iget-object p0, p0, Landroidx/fragment/app/KLFTb;->xJ:Ljava/util/concurrent/atomic/AtomicInteger;

    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicInteger;->getAndIncrement()I

    move-result p0

    return p0
.end method

.method public xROA()Z
    .locals 1

    iget-boolean v0, p0, Landroidx/fragment/app/KLFTb;->HGpJ:Z

    if-nez v0, :cond_1

    iget-boolean p0, p0, Landroidx/fragment/app/KLFTb;->vI:Z

    if-eqz p0, :cond_0

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    goto :goto_1

    :cond_1
    :goto_0
    const/4 p0, 0x1

    :goto_1
    return p0
.end method

.method public xrEuO(Landroidx/fragment/app/KLFTb$lgHUyS;Z)V
    .locals 0

    if-nez p2, :cond_1

    iget-boolean p0, p0, Landroidx/fragment/app/KLFTb;->VocHEe:Z

    if-eqz p0, :cond_0

    new-instance p0, Ljava/lang/IllegalStateException;

    const-string p1, "FragmentManager has been destroyed"

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_0
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string p1, "FragmentManager has not been attached to a host."

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_1
    iget-object p0, p0, Landroidx/fragment/app/KLFTb;->mjFkc:Ljava/util/ArrayList;

    monitor-enter p0

    if-eqz p2, :cond_2

    :try_start_0
    monitor-exit p0

    return-void

    :catchall_0
    move-exception p1

    goto :goto_0

    :cond_2
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string p2, "Activity has been destroyed"

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :goto_0
    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw p1
.end method

.method public yX()Z
    .locals 3

    const/4 v0, -0x1

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-virtual {p0, v2, v0, v1}, Landroidx/fragment/app/KLFTb;->gYa(Ljava/lang/String;II)Z

    move-result p0

    return p0
.end method

.method public yfx(Landroidx/fragment/app/Fragment;)Z
    .locals 3

    const/4 v0, 0x1

    if-nez p1, :cond_0

    return v0

    :cond_0
    iget-object v1, p1, Landroidx/fragment/app/Fragment;->fehf:Landroidx/fragment/app/KLFTb;

    invoke-virtual {v1}, Landroidx/fragment/app/KLFTb;->bbzow()Landroidx/fragment/app/Fragment;

    move-result-object v2

    invoke-virtual {p1, v2}, Landroidx/fragment/app/Fragment;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_1

    iget-object p1, v1, Landroidx/fragment/app/KLFTb;->fehf:Landroidx/fragment/app/Fragment;

    invoke-virtual {p0, p1}, Landroidx/fragment/app/KLFTb;->yfx(Landroidx/fragment/app/Fragment;)Z

    move-result p0

    if-eqz p0, :cond_1

    goto :goto_0

    :cond_1
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public zvd(Z)Z
    .locals 2

    invoke-virtual {p0, p1}, Landroidx/fragment/app/KLFTb;->KLMXS(Z)V

    const/4 p1, 0x0

    :goto_0
    iget-object v0, p0, Landroidx/fragment/app/KLFTb;->lB:Ljava/util/ArrayList;

    iget-object v1, p0, Landroidx/fragment/app/KLFTb;->wJVbdd:Ljava/util/ArrayList;

    invoke-virtual {p0, v0, v1}, Landroidx/fragment/app/KLFTb;->WrLQs(Ljava/util/ArrayList;Ljava/util/ArrayList;)Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 p1, 0x1

    iput-boolean p1, p0, Landroidx/fragment/app/KLFTb;->AZxh:Z

    :try_start_0
    iget-object v0, p0, Landroidx/fragment/app/KLFTb;->lB:Ljava/util/ArrayList;

    iget-object v1, p0, Landroidx/fragment/app/KLFTb;->wJVbdd:Ljava/util/ArrayList;

    invoke-virtual {p0, v0, v1}, Landroidx/fragment/app/KLFTb;->XFUzSY(Ljava/util/ArrayList;Ljava/util/ArrayList;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    invoke-virtual {p0}, Landroidx/fragment/app/KLFTb;->MiMN()V

    goto :goto_0

    :catchall_0
    move-exception p1

    invoke-virtual {p0}, Landroidx/fragment/app/KLFTb;->MiMN()V

    throw p1

    :cond_0
    invoke-virtual {p0}, Landroidx/fragment/app/KLFTb;->gtr()V

    invoke-virtual {p0}, Landroidx/fragment/app/KLFTb;->Ne()V

    iget-object p0, p0, Landroidx/fragment/app/KLFTb;->wA:Lo/bVfe;

    invoke-virtual {p0}, Lo/bVfe;->AZxh()V

    return p1
.end method
