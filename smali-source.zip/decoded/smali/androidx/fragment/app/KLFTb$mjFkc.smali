.class public Landroidx/fragment/app/KLFTb$mjFkc;
.super Lo/Y2;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/fragment/app/KLFTb;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic ZfxDd:Landroidx/fragment/app/KLFTb;


# direct methods
.method public constructor <init>(Landroidx/fragment/app/KLFTb;Z)V
    .locals 0

    iput-object p1, p0, Landroidx/fragment/app/KLFTb$mjFkc;->ZfxDd:Landroidx/fragment/app/KLFTb;

    invoke-direct {p0, p2}, Lo/Y2;-><init>(Z)V

    return-void
.end method
