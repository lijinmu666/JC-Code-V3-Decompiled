.class public Landroidx/fragment/app/Dt$AZxh;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Landroidx/fragment/app/Dt;->mjFkc(Landroidx/fragment/app/Dt$KLFTb$wA;Landroidx/fragment/app/Dt$KLFTb$AZxh;Landroidx/fragment/app/xJ;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic AZxh:Landroidx/fragment/app/Dt;

.field public final synthetic mjFkc:Landroidx/fragment/app/Dt$ZfxDd;


# direct methods
.method public constructor <init>(Landroidx/fragment/app/Dt;Landroidx/fragment/app/Dt$ZfxDd;)V
    .locals 0

    iput-object p1, p0, Landroidx/fragment/app/Dt$AZxh;->AZxh:Landroidx/fragment/app/Dt;

    iput-object p2, p0, Landroidx/fragment/app/Dt$AZxh;->mjFkc:Landroidx/fragment/app/Dt$ZfxDd;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 2

    iget-object v0, p0, Landroidx/fragment/app/Dt$AZxh;->AZxh:Landroidx/fragment/app/Dt;

    iget-object v0, v0, Landroidx/fragment/app/Dt;->AZxh:Ljava/util/ArrayList;

    iget-object v1, p0, Landroidx/fragment/app/Dt$AZxh;->mjFkc:Landroidx/fragment/app/Dt$ZfxDd;

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    iget-object v0, p0, Landroidx/fragment/app/Dt$AZxh;->AZxh:Landroidx/fragment/app/Dt;

    iget-object v0, v0, Landroidx/fragment/app/Dt;->wA:Ljava/util/ArrayList;

    iget-object p0, p0, Landroidx/fragment/app/Dt$AZxh;->mjFkc:Landroidx/fragment/app/Dt$ZfxDd;

    invoke-virtual {v0, p0}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    return-void
.end method
