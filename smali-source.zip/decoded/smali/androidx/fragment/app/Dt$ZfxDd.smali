.class public Landroidx/fragment/app/Dt$ZfxDd;
.super Landroidx/fragment/app/Dt$KLFTb;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/fragment/app/Dt;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "ZfxDd"
.end annotation


# instance fields
.field public final lgHUyS:Landroidx/fragment/app/xJ;


# direct methods
.method public constructor <init>(Landroidx/fragment/app/Dt$KLFTb$wA;Landroidx/fragment/app/Dt$KLFTb$AZxh;Landroidx/fragment/app/xJ;Lo/BxruE;)V
    .locals 1

    invoke-virtual {p3}, Landroidx/fragment/app/xJ;->ETF()Landroidx/fragment/app/Fragment;

    move-result-object v0

    invoke-direct {p0, p1, p2, v0, p4}, Landroidx/fragment/app/Dt$KLFTb;-><init>(Landroidx/fragment/app/Dt$KLFTb$wA;Landroidx/fragment/app/Dt$KLFTb$AZxh;Landroidx/fragment/app/Fragment;Lo/BxruE;)V

    iput-object p3, p0, Landroidx/fragment/app/Dt$ZfxDd;->lgHUyS:Landroidx/fragment/app/xJ;

    return-void
.end method


# virtual methods
.method public VA()V
    .locals 4

    invoke-virtual {p0}, Landroidx/fragment/app/Dt$KLFTb;->xJ()Landroidx/fragment/app/Dt$KLFTb$AZxh;

    move-result-object v0

    sget-object v1, Landroidx/fragment/app/Dt$KLFTb$AZxh;->AZxh:Landroidx/fragment/app/Dt$KLFTb$AZxh;

    if-ne v0, v1, :cond_3

    iget-object v0, p0, Landroidx/fragment/app/Dt$ZfxDd;->lgHUyS:Landroidx/fragment/app/xJ;

    invoke-virtual {v0}, Landroidx/fragment/app/xJ;->ETF()Landroidx/fragment/app/Fragment;

    move-result-object v0

    iget-object v1, v0, Landroidx/fragment/app/Fragment;->mByQ:Landroid/view/View;

    invoke-virtual {v1}, Landroid/view/View;->findFocus()Landroid/view/View;

    move-result-object v1

    if-eqz v1, :cond_0

    invoke-virtual {v0, v1}, Landroidx/fragment/app/Fragment;->Vgyli(Landroid/view/View;)V

    const/4 v2, 0x2

    invoke-static {v2}, Landroidx/fragment/app/KLFTb;->dm(I)Z

    move-result v2

    if-eqz v2, :cond_0

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "requestFocus: Saved focused view "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, " for Fragment "

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const-string v2, "FragmentManager"

    invoke-static {v2, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    :cond_0
    invoke-virtual {p0}, Landroidx/fragment/app/Dt$KLFTb;->JHa()Landroidx/fragment/app/Fragment;

    move-result-object v1

    invoke-virtual {v1}, Landroidx/fragment/app/Fragment;->XbiWeM()Landroid/view/View;

    move-result-object v1

    invoke-virtual {v1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v2

    const/4 v3, 0x0

    if-nez v2, :cond_1

    iget-object p0, p0, Landroidx/fragment/app/Dt$ZfxDd;->lgHUyS:Landroidx/fragment/app/xJ;

    invoke-virtual {p0}, Landroidx/fragment/app/xJ;->AZxh()V

    invoke-virtual {v1, v3}, Landroid/view/View;->setAlpha(F)V

    :cond_1
    invoke-virtual {v1}, Landroid/view/View;->getAlpha()F

    move-result p0

    cmpl-float p0, p0, v3

    if-nez p0, :cond_2

    invoke-virtual {v1}, Landroid/view/View;->getVisibility()I

    move-result p0

    if-nez p0, :cond_2

    const/4 p0, 0x4

    invoke-virtual {v1, p0}, Landroid/view/View;->setVisibility(I)V

    :cond_2
    invoke-virtual {v0}, Landroidx/fragment/app/Fragment;->wJVbdd()F

    move-result p0

    invoke-virtual {v1, p0}, Landroid/view/View;->setAlpha(F)V

    :cond_3
    return-void
.end method

.method public wA()V
    .locals 0

    invoke-super {p0}, Landroidx/fragment/app/Dt$KLFTb;->wA()V

    iget-object p0, p0, Landroidx/fragment/app/Dt$ZfxDd;->lgHUyS:Landroidx/fragment/app/xJ;

    invoke-virtual {p0}, Landroidx/fragment/app/xJ;->MiMN()V

    return-void
.end method
