.class public Landroidx/fragment/app/wA$wA;
.super Landroid/animation/AnimatorListenerAdapter;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Landroidx/fragment/app/wA;->Ucbh(Ljava/util/List;Ljava/util/List;ZLjava/util/Map;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic AZxh:Landroid/view/View;

.field public final synthetic JHa:Landroidx/fragment/app/wA;

.field public final synthetic KLFTb:Landroidx/fragment/app/wA$ETF;

.field public final synthetic ZfxDd:Landroidx/fragment/app/Dt$KLFTb;

.field public final synthetic mjFkc:Landroid/view/ViewGroup;

.field public final synthetic wA:Z


# direct methods
.method public constructor <init>(Landroidx/fragment/app/wA;Landroid/view/ViewGroup;Landroid/view/View;ZLandroidx/fragment/app/Dt$KLFTb;Landroidx/fragment/app/wA$ETF;)V
    .locals 0

    iput-object p1, p0, Landroidx/fragment/app/wA$wA;->JHa:Landroidx/fragment/app/wA;

    iput-object p2, p0, Landroidx/fragment/app/wA$wA;->mjFkc:Landroid/view/ViewGroup;

    iput-object p3, p0, Landroidx/fragment/app/wA$wA;->AZxh:Landroid/view/View;

    iput-boolean p4, p0, Landroidx/fragment/app/wA$wA;->wA:Z

    iput-object p5, p0, Landroidx/fragment/app/wA$wA;->ZfxDd:Landroidx/fragment/app/Dt$KLFTb;

    iput-object p6, p0, Landroidx/fragment/app/wA$wA;->KLFTb:Landroidx/fragment/app/wA$ETF;

    invoke-direct {p0}, Landroid/animation/AnimatorListenerAdapter;-><init>()V

    return-void
.end method


# virtual methods
.method public onAnimationEnd(Landroid/animation/Animator;)V
    .locals 1

    iget-object p1, p0, Landroidx/fragment/app/wA$wA;->mjFkc:Landroid/view/ViewGroup;

    iget-object v0, p0, Landroidx/fragment/app/wA$wA;->AZxh:Landroid/view/View;

    invoke-virtual {p1, v0}, Landroid/view/ViewGroup;->endViewTransition(Landroid/view/View;)V

    iget-boolean p1, p0, Landroidx/fragment/app/wA$wA;->wA:Z

    if-eqz p1, :cond_0

    iget-object p1, p0, Landroidx/fragment/app/wA$wA;->ZfxDd:Landroidx/fragment/app/Dt$KLFTb;

    invoke-virtual {p1}, Landroidx/fragment/app/Dt$KLFTb;->KLFTb()Landroidx/fragment/app/Dt$KLFTb$wA;

    move-result-object p1

    iget-object v0, p0, Landroidx/fragment/app/wA$wA;->AZxh:Landroid/view/View;

    invoke-virtual {p1, v0}, Landroidx/fragment/app/Dt$KLFTb$wA;->KLFTb(Landroid/view/View;)V

    :cond_0
    iget-object p0, p0, Landroidx/fragment/app/wA$wA;->KLFTb:Landroidx/fragment/app/wA$ETF;

    invoke-virtual {p0}, Landroidx/fragment/app/wA$VA;->mjFkc()V

    return-void
.end method
