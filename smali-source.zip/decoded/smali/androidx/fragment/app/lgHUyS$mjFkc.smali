.class public final Landroidx/fragment/app/lgHUyS$mjFkc;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/fragment/app/lgHUyS;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "mjFkc"
.end annotation


# instance fields
.field public AZxh:Landroidx/fragment/app/Fragment;

.field public JHa:I

.field public KLFTb:I

.field public ZfxDd:I

.field public lgHUyS:Landroidx/lifecycle/wA$AZxh;

.field public mjFkc:I

.field public wA:I

.field public xJ:Landroidx/lifecycle/wA$AZxh;


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public constructor <init>(ILandroidx/fragment/app/Fragment;)V
    .locals 0

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    iput p1, p0, Landroidx/fragment/app/lgHUyS$mjFkc;->mjFkc:I

    .line 4
    iput-object p2, p0, Landroidx/fragment/app/lgHUyS$mjFkc;->AZxh:Landroidx/fragment/app/Fragment;

    .line 5
    sget-object p1, Landroidx/lifecycle/wA$AZxh;->KLFTb:Landroidx/lifecycle/wA$AZxh;

    iput-object p1, p0, Landroidx/fragment/app/lgHUyS$mjFkc;->xJ:Landroidx/lifecycle/wA$AZxh;

    .line 6
    iput-object p1, p0, Landroidx/fragment/app/lgHUyS$mjFkc;->lgHUyS:Landroidx/lifecycle/wA$AZxh;

    return-void
.end method
