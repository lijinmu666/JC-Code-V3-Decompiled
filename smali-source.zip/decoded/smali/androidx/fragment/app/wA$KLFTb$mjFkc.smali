.class public Landroidx/fragment/app/wA$KLFTb$mjFkc;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Landroidx/fragment/app/wA$KLFTb;->onAnimationEnd(Landroid/view/animation/Animation;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic mjFkc:Landroidx/fragment/app/wA$KLFTb;


# direct methods
.method public constructor <init>(Landroidx/fragment/app/wA$KLFTb;)V
    .locals 0

    iput-object p1, p0, Landroidx/fragment/app/wA$KLFTb$mjFkc;->mjFkc:Landroidx/fragment/app/wA$KLFTb;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 2

    iget-object v0, p0, Landroidx/fragment/app/wA$KLFTb$mjFkc;->mjFkc:Landroidx/fragment/app/wA$KLFTb;

    iget-object v1, v0, Landroidx/fragment/app/wA$KLFTb;->mjFkc:Landroid/view/ViewGroup;

    iget-object v0, v0, Landroidx/fragment/app/wA$KLFTb;->AZxh:Landroid/view/View;

    invoke-virtual {v1, v0}, Landroid/view/ViewGroup;->endViewTransition(Landroid/view/View;)V

    iget-object p0, p0, Landroidx/fragment/app/wA$KLFTb$mjFkc;->mjFkc:Landroidx/fragment/app/wA$KLFTb;

    iget-object p0, p0, Landroidx/fragment/app/wA$KLFTb;->wA:Landroidx/fragment/app/wA$ETF;

    invoke-virtual {p0}, Landroidx/fragment/app/wA$VA;->mjFkc()V

    return-void
.end method
