.class public abstract Landroidx/fragment/app/lgHUyS;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/fragment/app/lgHUyS$mjFkc;
    }
.end annotation


# instance fields
.field public final AZxh:Ljava/lang/ClassLoader;

.field public Dt:Z

.field public ETF:Ljava/lang/String;

.field public IEE:Z

.field public JHa:I

.field public KLFTb:I

.field public MiMN:Ljava/lang/CharSequence;

.field public Pq:Ljava/util/ArrayList;

.field public VA:I

.field public YoKzxo:I

.field public ZfxDd:I

.field public fehf:Ljava/util/ArrayList;

.field public lgHUyS:I

.field public final mjFkc:Lo/bL;

.field public qGY:Ljava/util/ArrayList;

.field public qdMbNW:Z

.field public rkYL:Ljava/lang/CharSequence;

.field public wA:Ljava/util/ArrayList;

.field public xJ:I


# direct methods
.method public constructor <init>(Lo/bL;Ljava/lang/ClassLoader;)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Landroidx/fragment/app/lgHUyS;->wA:Ljava/util/ArrayList;

    const/4 v0, 0x1

    iput-boolean v0, p0, Landroidx/fragment/app/lgHUyS;->Dt:Z

    const/4 v0, 0x0

    iput-boolean v0, p0, Landroidx/fragment/app/lgHUyS;->IEE:Z

    iput-object p1, p0, Landroidx/fragment/app/lgHUyS;->mjFkc:Lo/bL;

    iput-object p2, p0, Landroidx/fragment/app/lgHUyS;->AZxh:Ljava/lang/ClassLoader;

    return-void
.end method


# virtual methods
.method public AZxh(ILandroidx/fragment/app/Fragment;Ljava/lang/String;)Landroidx/fragment/app/lgHUyS;
    .locals 1

    const/4 v0, 0x1

    invoke-virtual {p0, p1, p2, p3, v0}, Landroidx/fragment/app/lgHUyS;->Dt(ILandroidx/fragment/app/Fragment;Ljava/lang/String;I)V

    return-object p0
.end method

.method public Dt(ILandroidx/fragment/app/Fragment;Ljava/lang/String;I)V
    .locals 3

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Class;->getModifiers()I

    move-result v1

    invoke-virtual {v0}, Ljava/lang/Class;->isAnonymousClass()Z

    move-result v2

    if-nez v2, :cond_8

    invoke-static {v1}, Ljava/lang/reflect/Modifier;->isPublic(I)Z

    move-result v2

    if-eqz v2, :cond_8

    invoke-virtual {v0}, Ljava/lang/Class;->isMemberClass()Z

    move-result v2

    if-eqz v2, :cond_0

    invoke-static {v1}, Ljava/lang/reflect/Modifier;->isStatic(I)Z

    move-result v1

    if-eqz v1, :cond_8

    :cond_0
    const-string v0, " now "

    const-string v1, ": was "

    if-eqz p3, :cond_3

    iget-object v2, p2, Landroidx/fragment/app/Fragment;->Ucbh:Ljava/lang/String;

    if-eqz v2, :cond_2

    invoke-virtual {p3, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_1

    goto :goto_0

    :cond_1
    new-instance p0, Ljava/lang/IllegalStateException;

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const-string p4, "Can\'t change tag of fragment "

    invoke-virtual {p1, p4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object p2, p2, Landroidx/fragment/app/Fragment;->Ucbh:Ljava/lang/String;

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_2
    :goto_0
    iput-object p3, p2, Landroidx/fragment/app/Fragment;->Ucbh:Ljava/lang/String;

    :cond_3
    if-eqz p1, :cond_7

    const/4 v2, -0x1

    if-eq p1, v2, :cond_6

    iget p3, p2, Landroidx/fragment/app/Fragment;->diqgf:I

    if-eqz p3, :cond_5

    if-ne p3, p1, :cond_4

    goto :goto_1

    :cond_4
    new-instance p0, Ljava/lang/IllegalStateException;

    new-instance p3, Ljava/lang/StringBuilder;

    invoke-direct {p3}, Ljava/lang/StringBuilder;-><init>()V

    const-string p4, "Can\'t change container ID of fragment "

    invoke-virtual {p3, p4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p3, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {p3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget p2, p2, Landroidx/fragment/app/Fragment;->diqgf:I

    invoke-virtual {p3, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {p3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p3, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_5
    :goto_1
    iput p1, p2, Landroidx/fragment/app/Fragment;->diqgf:I

    iput p1, p2, Landroidx/fragment/app/Fragment;->eyqo:I

    goto :goto_2

    :cond_6
    new-instance p0, Ljava/lang/IllegalArgumentException;

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const-string p4, "Can\'t add fragment "

    invoke-virtual {p1, p4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p2, " with tag "

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p2, " to container view with no id"

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_7
    :goto_2
    new-instance p1, Landroidx/fragment/app/lgHUyS$mjFkc;

    invoke-direct {p1, p4, p2}, Landroidx/fragment/app/lgHUyS$mjFkc;-><init>(ILandroidx/fragment/app/Fragment;)V

    invoke-virtual {p0, p1}, Landroidx/fragment/app/lgHUyS;->ZfxDd(Landroidx/fragment/app/lgHUyS$mjFkc;)V

    return-void

    :cond_8
    new-instance p0, Ljava/lang/IllegalStateException;

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const-string p2, "Fragment "

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/Class;->getCanonicalName()Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p2, " must be a public static class to be  properly recreated from instance state."

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public ETF(Landroidx/fragment/app/Fragment;)Landroidx/fragment/app/lgHUyS;
    .locals 2

    new-instance v0, Landroidx/fragment/app/lgHUyS$mjFkc;

    const/4 v1, 0x3

    invoke-direct {v0, v1, p1}, Landroidx/fragment/app/lgHUyS$mjFkc;-><init>(ILandroidx/fragment/app/Fragment;)V

    invoke-virtual {p0, v0}, Landroidx/fragment/app/lgHUyS;->ZfxDd(Landroidx/fragment/app/lgHUyS$mjFkc;)V

    return-object p0
.end method

.method public abstract JHa()I
.end method

.method public abstract KLFTb()I
.end method

.method public MiMN(ILandroidx/fragment/app/Fragment;Ljava/lang/String;)Landroidx/fragment/app/lgHUyS;
    .locals 1

    if-eqz p1, :cond_0

    const/4 v0, 0x2

    invoke-virtual {p0, p1, p2, p3, v0}, Landroidx/fragment/app/lgHUyS;->Dt(ILandroidx/fragment/app/Fragment;Ljava/lang/String;I)V

    return-object p0

    :cond_0
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string p1, "Must use non-zero containerViewId"

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public VA(ILandroidx/fragment/app/Fragment;)Landroidx/fragment/app/lgHUyS;
    .locals 1

    const/4 v0, 0x0

    invoke-virtual {p0, p1, p2, v0}, Landroidx/fragment/app/lgHUyS;->MiMN(ILandroidx/fragment/app/Fragment;Ljava/lang/String;)Landroidx/fragment/app/lgHUyS;

    move-result-object p0

    return-object p0
.end method

.method public YoKzxo(Z)Landroidx/fragment/app/lgHUyS;
    .locals 0

    iput-boolean p1, p0, Landroidx/fragment/app/lgHUyS;->IEE:Z

    return-object p0
.end method

.method public ZfxDd(Landroidx/fragment/app/lgHUyS$mjFkc;)V
    .locals 1

    iget-object v0, p0, Landroidx/fragment/app/lgHUyS;->wA:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget v0, p0, Landroidx/fragment/app/lgHUyS;->ZfxDd:I

    iput v0, p1, Landroidx/fragment/app/lgHUyS$mjFkc;->wA:I

    iget v0, p0, Landroidx/fragment/app/lgHUyS;->KLFTb:I

    iput v0, p1, Landroidx/fragment/app/lgHUyS$mjFkc;->ZfxDd:I

    iget v0, p0, Landroidx/fragment/app/lgHUyS;->JHa:I

    iput v0, p1, Landroidx/fragment/app/lgHUyS$mjFkc;->KLFTb:I

    iget p0, p0, Landroidx/fragment/app/lgHUyS;->xJ:I

    iput p0, p1, Landroidx/fragment/app/lgHUyS$mjFkc;->JHa:I

    return-void
.end method

.method public abstract lgHUyS()V
.end method

.method public qdMbNW()Landroidx/fragment/app/lgHUyS;
    .locals 1

    iget-boolean v0, p0, Landroidx/fragment/app/lgHUyS;->qdMbNW:Z

    if-nez v0, :cond_0

    const/4 v0, 0x0

    iput-boolean v0, p0, Landroidx/fragment/app/lgHUyS;->Dt:Z

    return-object p0

    :cond_0
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string v0, "This transaction is already being added to the back stack"

    invoke-direct {p0, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public wA(Landroid/view/ViewGroup;Landroidx/fragment/app/Fragment;Ljava/lang/String;)Landroidx/fragment/app/lgHUyS;
    .locals 0

    iput-object p1, p2, Landroidx/fragment/app/Fragment;->wJVbdd:Landroid/view/ViewGroup;

    invoke-virtual {p1}, Landroid/view/View;->getId()I

    move-result p1

    invoke-virtual {p0, p1, p2, p3}, Landroidx/fragment/app/lgHUyS;->AZxh(ILandroidx/fragment/app/Fragment;Ljava/lang/String;)Landroidx/fragment/app/lgHUyS;

    move-result-object p0

    return-object p0
.end method

.method public abstract xJ()V
.end method
