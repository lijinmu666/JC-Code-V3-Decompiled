.class public Landroidx/fragment/app/wA$AZxh;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Landroidx/fragment/app/wA;->JHa(Ljava/util/List;Z)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic AZxh:Landroidx/fragment/app/Dt$KLFTb;

.field public final synthetic mjFkc:Ljava/util/List;

.field public final synthetic wA:Landroidx/fragment/app/wA;


# direct methods
.method public constructor <init>(Landroidx/fragment/app/wA;Ljava/util/List;Landroidx/fragment/app/Dt$KLFTb;)V
    .locals 0

    iput-object p1, p0, Landroidx/fragment/app/wA$AZxh;->wA:Landroidx/fragment/app/wA;

    iput-object p2, p0, Landroidx/fragment/app/wA$AZxh;->mjFkc:Ljava/util/List;

    iput-object p3, p0, Landroidx/fragment/app/wA$AZxh;->AZxh:Landroidx/fragment/app/Dt$KLFTb;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 2

    iget-object v0, p0, Landroidx/fragment/app/wA$AZxh;->mjFkc:Ljava/util/List;

    iget-object v1, p0, Landroidx/fragment/app/wA$AZxh;->AZxh:Landroidx/fragment/app/Dt$KLFTb;

    invoke-interface {v0, v1}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Landroidx/fragment/app/wA$AZxh;->mjFkc:Ljava/util/List;

    iget-object v1, p0, Landroidx/fragment/app/wA$AZxh;->AZxh:Landroidx/fragment/app/Dt$KLFTb;

    invoke-interface {v0, v1}, Ljava/util/List;->remove(Ljava/lang/Object;)Z

    iget-object v0, p0, Landroidx/fragment/app/wA$AZxh;->wA:Landroidx/fragment/app/wA;

    iget-object p0, p0, Landroidx/fragment/app/wA$AZxh;->AZxh:Landroidx/fragment/app/Dt$KLFTb;

    invoke-virtual {v0, p0}, Landroidx/fragment/app/wA;->IEE(Landroidx/fragment/app/Dt$KLFTb;)V

    :cond_0
    return-void
.end method
