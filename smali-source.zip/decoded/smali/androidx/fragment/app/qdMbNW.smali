.class public abstract Landroidx/fragment/app/qdMbNW;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/fragment/app/qdMbNW$mjFkc;
    }
.end annotation


# static fields
.field public static final AZxh:Lo/KbpP;

.field public static final mjFkc:[I

.field public static final wA:Lo/KbpP;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    const/16 v0, 0xb

    new-array v0, v0, [I

    fill-array-data v0, :array_0

    sput-object v0, Landroidx/fragment/app/qdMbNW;->mjFkc:[I

    new-instance v0, Lo/zo;

    invoke-direct {v0}, Lo/zo;-><init>()V

    sput-object v0, Landroidx/fragment/app/qdMbNW;->AZxh:Lo/KbpP;

    invoke-static {}, Landroidx/fragment/app/qdMbNW;->AZxh()Lo/KbpP;

    move-result-object v0

    sput-object v0, Landroidx/fragment/app/qdMbNW;->wA:Lo/KbpP;

    return-void

    nop

    :array_0
    .array-data 4
        0x0
        0x3
        0x0
        0x1
        0x5
        0x4
        0x7
        0x6
        0x9
        0x8
        0xa
    .end array-data
.end method

.method public static AZxh()Lo/KbpP;
    .locals 2

    const/4 v0, 0x0

    :try_start_0
    const-class v1, Lo/YRhJjQ;

    invoke-virtual {v1, v0}, Ljava/lang/Class;->getDeclaredConstructor([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/reflect/Constructor;->newInstance([Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lo/KbpP;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object v1

    :catch_0
    return-object v0
.end method

.method public static ZfxDd(Ljava/util/ArrayList;I)V
    .locals 2

    if-nez p0, :cond_0

    return-void

    :cond_0
    invoke-virtual {p0}, Ljava/util/ArrayList;->size()I

    move-result v0

    add-int/lit8 v0, v0, -0x1

    :goto_0
    if-ltz v0, :cond_1

    invoke-virtual {p0, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/view/View;

    invoke-virtual {v1, p1}, Landroid/view/View;->setVisibility(I)V

    add-int/lit8 v0, v0, -0x1

    goto :goto_0

    :cond_1
    return-void
.end method

.method public static mjFkc(Landroidx/fragment/app/Fragment;Landroidx/fragment/app/Fragment;ZLo/tjSezt;Z)V
    .locals 0

    if-eqz p2, :cond_0

    invoke-virtual {p1}, Landroidx/fragment/app/Fragment;->fehf()Lo/M6;

    goto :goto_0

    :cond_0
    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->fehf()Lo/M6;

    :goto_0
    return-void
.end method

.method public static wA(Lo/tjSezt;Lo/tjSezt;)V
    .locals 2

    invoke-virtual {p0}, Lo/W6;->size()I

    move-result v0

    add-int/lit8 v0, v0, -0x1

    :goto_0
    if-ltz v0, :cond_1

    invoke-virtual {p0, v0}, Lo/W6;->MiMN(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    invoke-virtual {p1, v1}, Lo/W6;->containsKey(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_0

    invoke-virtual {p0, v0}, Lo/W6;->ETF(I)Ljava/lang/Object;

    :cond_0
    add-int/lit8 v0, v0, -0x1

    goto :goto_0

    :cond_1
    return-void
.end method
