.class public abstract synthetic Landroidx/fragment/app/Dt$wA;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/fragment/app/Dt;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1009
    name = null
.end annotation


# static fields
.field public static final synthetic AZxh:[I

.field public static final synthetic mjFkc:[I


# direct methods
.method static constructor <clinit>()V
    .locals 5

    invoke-static {}, Landroidx/fragment/app/Dt$KLFTb$AZxh;->values()[Landroidx/fragment/app/Dt$KLFTb$AZxh;

    move-result-object v0

    array-length v0, v0

    new-array v0, v0, [I

    sput-object v0, Landroidx/fragment/app/Dt$wA;->AZxh:[I

    const/4 v1, 0x1

    :try_start_0
    sget-object v2, Landroidx/fragment/app/Dt$KLFTb$AZxh;->AZxh:Landroidx/fragment/app/Dt$KLFTb$AZxh;

    invoke-virtual {v2}, Ljava/lang/Enum;->ordinal()I

    move-result v2

    aput v1, v0, v2
    :try_end_0
    .catch Ljava/lang/NoSuchFieldError; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    const/4 v0, 0x2

    :try_start_1
    sget-object v2, Landroidx/fragment/app/Dt$wA;->AZxh:[I

    sget-object v3, Landroidx/fragment/app/Dt$KLFTb$AZxh;->wA:Landroidx/fragment/app/Dt$KLFTb$AZxh;

    invoke-virtual {v3}, Ljava/lang/Enum;->ordinal()I

    move-result v3

    aput v0, v2, v3
    :try_end_1
    .catch Ljava/lang/NoSuchFieldError; {:try_start_1 .. :try_end_1} :catch_1

    :catch_1
    const/4 v2, 0x3

    :try_start_2
    sget-object v3, Landroidx/fragment/app/Dt$wA;->AZxh:[I

    sget-object v4, Landroidx/fragment/app/Dt$KLFTb$AZxh;->mjFkc:Landroidx/fragment/app/Dt$KLFTb$AZxh;

    invoke-virtual {v4}, Ljava/lang/Enum;->ordinal()I

    move-result v4

    aput v2, v3, v4
    :try_end_2
    .catch Ljava/lang/NoSuchFieldError; {:try_start_2 .. :try_end_2} :catch_2

    :catch_2
    invoke-static {}, Landroidx/fragment/app/Dt$KLFTb$wA;->values()[Landroidx/fragment/app/Dt$KLFTb$wA;

    move-result-object v3

    array-length v3, v3

    new-array v3, v3, [I

    sput-object v3, Landroidx/fragment/app/Dt$wA;->mjFkc:[I

    :try_start_3
    sget-object v4, Landroidx/fragment/app/Dt$KLFTb$wA;->mjFkc:Landroidx/fragment/app/Dt$KLFTb$wA;

    invoke-virtual {v4}, Ljava/lang/Enum;->ordinal()I

    move-result v4

    aput v1, v3, v4
    :try_end_3
    .catch Ljava/lang/NoSuchFieldError; {:try_start_3 .. :try_end_3} :catch_3

    :catch_3
    :try_start_4
    sget-object v1, Landroidx/fragment/app/Dt$wA;->mjFkc:[I

    sget-object v3, Landroidx/fragment/app/Dt$KLFTb$wA;->AZxh:Landroidx/fragment/app/Dt$KLFTb$wA;

    invoke-virtual {v3}, Ljava/lang/Enum;->ordinal()I

    move-result v3

    aput v0, v1, v3
    :try_end_4
    .catch Ljava/lang/NoSuchFieldError; {:try_start_4 .. :try_end_4} :catch_4

    :catch_4
    :try_start_5
    sget-object v0, Landroidx/fragment/app/Dt$wA;->mjFkc:[I

    sget-object v1, Landroidx/fragment/app/Dt$KLFTb$wA;->wA:Landroidx/fragment/app/Dt$KLFTb$wA;

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    aput v2, v0, v1
    :try_end_5
    .catch Ljava/lang/NoSuchFieldError; {:try_start_5 .. :try_end_5} :catch_5

    :catch_5
    :try_start_6
    sget-object v0, Landroidx/fragment/app/Dt$wA;->mjFkc:[I

    sget-object v1, Landroidx/fragment/app/Dt$KLFTb$wA;->ZfxDd:Landroidx/fragment/app/Dt$KLFTb$wA;

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    const/4 v2, 0x4

    aput v2, v0, v1
    :try_end_6
    .catch Ljava/lang/NoSuchFieldError; {:try_start_6 .. :try_end_6} :catch_6

    :catch_6
    return-void
.end method
