.class public Landroidx/fragment/app/wA$ETF;
.super Landroidx/fragment/app/wA$VA;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/fragment/app/wA;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "ETF"
.end annotation


# instance fields
.field public KLFTb:Landroidx/fragment/app/ZfxDd$mjFkc;

.field public ZfxDd:Z

.field public wA:Z


# direct methods
.method public constructor <init>(Landroidx/fragment/app/Dt$KLFTb;Lo/BxruE;Z)V
    .locals 0

    invoke-direct {p0, p1, p2}, Landroidx/fragment/app/wA$VA;-><init>(Landroidx/fragment/app/Dt$KLFTb;Lo/BxruE;)V

    const/4 p1, 0x0

    iput-boolean p1, p0, Landroidx/fragment/app/wA$ETF;->ZfxDd:Z

    iput-boolean p3, p0, Landroidx/fragment/app/wA$ETF;->wA:Z

    return-void
.end method


# virtual methods
.method public KLFTb(Landroid/content/Context;)Landroidx/fragment/app/ZfxDd$mjFkc;
    .locals 4

    iget-boolean v0, p0, Landroidx/fragment/app/wA$ETF;->ZfxDd:Z

    if-eqz v0, :cond_0

    iget-object p0, p0, Landroidx/fragment/app/wA$ETF;->KLFTb:Landroidx/fragment/app/ZfxDd$mjFkc;

    return-object p0

    :cond_0
    invoke-virtual {p0}, Landroidx/fragment/app/wA$VA;->AZxh()Landroidx/fragment/app/Dt$KLFTb;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/fragment/app/Dt$KLFTb;->JHa()Landroidx/fragment/app/Fragment;

    move-result-object v0

    invoke-virtual {p0}, Landroidx/fragment/app/wA$VA;->AZxh()Landroidx/fragment/app/Dt$KLFTb;

    move-result-object v1

    invoke-virtual {v1}, Landroidx/fragment/app/Dt$KLFTb;->KLFTb()Landroidx/fragment/app/Dt$KLFTb$wA;

    move-result-object v1

    sget-object v2, Landroidx/fragment/app/Dt$KLFTb$wA;->AZxh:Landroidx/fragment/app/Dt$KLFTb$wA;

    const/4 v3, 0x1

    if-ne v1, v2, :cond_1

    move v1, v3

    goto :goto_0

    :cond_1
    const/4 v1, 0x0

    :goto_0
    iget-boolean v2, p0, Landroidx/fragment/app/wA$ETF;->wA:Z

    invoke-static {p1, v0, v1, v2}, Landroidx/fragment/app/ZfxDd;->AZxh(Landroid/content/Context;Landroidx/fragment/app/Fragment;ZZ)Landroidx/fragment/app/ZfxDd$mjFkc;

    move-result-object p1

    iput-object p1, p0, Landroidx/fragment/app/wA$ETF;->KLFTb:Landroidx/fragment/app/ZfxDd$mjFkc;

    iput-boolean v3, p0, Landroidx/fragment/app/wA$ETF;->ZfxDd:Z

    return-object p1
.end method
