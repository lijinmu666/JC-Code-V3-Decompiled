.class public Landroidx/fragment/app/wA$KLFTb;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/animation/Animation$AnimationListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Landroidx/fragment/app/wA;->Ucbh(Ljava/util/List;Ljava/util/List;ZLjava/util/Map;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic AZxh:Landroid/view/View;

.field public final synthetic ZfxDd:Landroidx/fragment/app/wA;

.field public final synthetic mjFkc:Landroid/view/ViewGroup;

.field public final synthetic wA:Landroidx/fragment/app/wA$ETF;


# direct methods
.method public constructor <init>(Landroidx/fragment/app/wA;Landroid/view/ViewGroup;Landroid/view/View;Landroidx/fragment/app/wA$ETF;)V
    .locals 0

    iput-object p1, p0, Landroidx/fragment/app/wA$KLFTb;->ZfxDd:Landroidx/fragment/app/wA;

    iput-object p2, p0, Landroidx/fragment/app/wA$KLFTb;->mjFkc:Landroid/view/ViewGroup;

    iput-object p3, p0, Landroidx/fragment/app/wA$KLFTb;->AZxh:Landroid/view/View;

    iput-object p4, p0, Landroidx/fragment/app/wA$KLFTb;->wA:Landroidx/fragment/app/wA$ETF;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onAnimationEnd(Landroid/view/animation/Animation;)V
    .locals 1

    iget-object p1, p0, Landroidx/fragment/app/wA$KLFTb;->mjFkc:Landroid/view/ViewGroup;

    new-instance v0, Landroidx/fragment/app/wA$KLFTb$mjFkc;

    invoke-direct {v0, p0}, Landroidx/fragment/app/wA$KLFTb$mjFkc;-><init>(Landroidx/fragment/app/wA$KLFTb;)V

    invoke-virtual {p1, v0}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method public onAnimationRepeat(Landroid/view/animation/Animation;)V
    .locals 0

    return-void
.end method

.method public onAnimationStart(Landroid/view/animation/Animation;)V
    .locals 0

    return-void
.end method
