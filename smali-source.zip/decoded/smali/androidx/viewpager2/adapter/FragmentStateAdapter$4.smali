.class Landroidx/viewpager2/adapter/FragmentStateAdapter$4;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/lifecycle/KLFTb;


# instance fields
.field public final synthetic AZxh:Ljava/lang/Runnable;

.field public final synthetic mjFkc:Landroid/os/Handler;


# virtual methods
.method public VA(Lo/W0;Landroidx/lifecycle/wA$mjFkc;)V
    .locals 1

    sget-object v0, Landroidx/lifecycle/wA$mjFkc;->ON_DESTROY:Landroidx/lifecycle/wA$mjFkc;

    if-ne p2, v0, :cond_0

    iget-object p2, p0, Landroidx/viewpager2/adapter/FragmentStateAdapter$4;->mjFkc:Landroid/os/Handler;

    iget-object v0, p0, Landroidx/viewpager2/adapter/FragmentStateAdapter$4;->AZxh:Ljava/lang/Runnable;

    invoke-virtual {p2, v0}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    invoke-interface {p1}, Lo/W0;->JHa()Landroidx/lifecycle/wA;

    move-result-object p1

    invoke-virtual {p1, p0}, Landroidx/lifecycle/wA;->wA(Lo/V0;)V

    :cond_0
    return-void
.end method
