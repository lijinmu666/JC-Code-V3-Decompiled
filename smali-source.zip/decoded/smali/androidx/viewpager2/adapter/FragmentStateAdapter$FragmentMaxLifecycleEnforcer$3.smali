.class Landroidx/viewpager2/adapter/FragmentStateAdapter$FragmentMaxLifecycleEnforcer$3;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/lifecycle/KLFTb;


# virtual methods
.method public VA(Lo/W0;Landroidx/lifecycle/wA$mjFkc;)V
    .locals 0

    const/4 p0, 0x0

    throw p0
.end method
